<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-07-06 04:31:05 --> Config Class Initialized
INFO - 2022-07-06 04:31:05 --> Hooks Class Initialized
DEBUG - 2022-07-06 04:31:05 --> UTF-8 Support Enabled
INFO - 2022-07-06 04:31:05 --> Utf8 Class Initialized
INFO - 2022-07-06 04:31:05 --> URI Class Initialized
INFO - 2022-07-06 04:31:05 --> Router Class Initialized
INFO - 2022-07-06 04:31:05 --> Output Class Initialized
INFO - 2022-07-06 04:31:05 --> Security Class Initialized
DEBUG - 2022-07-06 04:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 04:31:05 --> Input Class Initialized
INFO - 2022-07-06 04:31:05 --> Language Class Initialized
INFO - 2022-07-06 04:31:05 --> Loader Class Initialized
INFO - 2022-07-06 04:31:05 --> Helper loaded: url_helper
INFO - 2022-07-06 04:31:05 --> Helper loaded: file_helper
INFO - 2022-07-06 04:31:05 --> Database Driver Class Initialized
INFO - 2022-07-06 04:31:05 --> Email Class Initialized
DEBUG - 2022-07-06 04:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 04:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 04:31:05 --> Controller Class Initialized
INFO - 2022-07-06 04:31:05 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 04:31:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-06 04:31:05 --> Severity: Notice --> Undefined variable: td_id_fk C:\wamp64\www\qr\application\views\filldetails\filldetails.php 278
INFO - 2022-07-06 04:31:05 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-07-06 04:31:05 --> Final output sent to browser
DEBUG - 2022-07-06 04:31:05 --> Total execution time: 0.2960
INFO - 2022-07-06 04:31:06 --> Config Class Initialized
INFO - 2022-07-06 04:31:06 --> Hooks Class Initialized
DEBUG - 2022-07-06 04:31:06 --> UTF-8 Support Enabled
INFO - 2022-07-06 04:31:06 --> Utf8 Class Initialized
INFO - 2022-07-06 04:31:06 --> URI Class Initialized
INFO - 2022-07-06 04:31:06 --> Router Class Initialized
INFO - 2022-07-06 04:31:06 --> Output Class Initialized
INFO - 2022-07-06 04:31:06 --> Security Class Initialized
DEBUG - 2022-07-06 04:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 04:31:06 --> Input Class Initialized
INFO - 2022-07-06 04:31:06 --> Language Class Initialized
INFO - 2022-07-06 04:31:06 --> Loader Class Initialized
INFO - 2022-07-06 04:31:06 --> Helper loaded: url_helper
INFO - 2022-07-06 04:31:06 --> Helper loaded: file_helper
INFO - 2022-07-06 04:31:06 --> Database Driver Class Initialized
INFO - 2022-07-06 04:31:06 --> Email Class Initialized
DEBUG - 2022-07-06 04:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 04:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 04:31:06 --> Controller Class Initialized
INFO - 2022-07-06 04:31:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 04:31:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-06 04:31:06 --> Severity: Notice --> Undefined variable: td_id_fk C:\wamp64\www\qr\application\views\filldetails\filldetails.php 278
INFO - 2022-07-06 04:31:06 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-07-06 04:31:06 --> Final output sent to browser
DEBUG - 2022-07-06 04:31:06 --> Total execution time: 0.0175
INFO - 2022-07-06 04:31:38 --> Config Class Initialized
INFO - 2022-07-06 04:31:38 --> Hooks Class Initialized
DEBUG - 2022-07-06 04:31:38 --> UTF-8 Support Enabled
INFO - 2022-07-06 04:31:38 --> Utf8 Class Initialized
INFO - 2022-07-06 04:31:38 --> URI Class Initialized
INFO - 2022-07-06 04:31:38 --> Router Class Initialized
INFO - 2022-07-06 04:31:38 --> Output Class Initialized
INFO - 2022-07-06 04:31:38 --> Security Class Initialized
DEBUG - 2022-07-06 04:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 04:31:38 --> Input Class Initialized
INFO - 2022-07-06 04:31:38 --> Language Class Initialized
INFO - 2022-07-06 04:31:38 --> Loader Class Initialized
INFO - 2022-07-06 04:31:38 --> Helper loaded: url_helper
INFO - 2022-07-06 04:31:38 --> Helper loaded: file_helper
INFO - 2022-07-06 04:31:38 --> Database Driver Class Initialized
INFO - 2022-07-06 04:31:38 --> Email Class Initialized
DEBUG - 2022-07-06 04:31:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 04:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 04:31:38 --> Controller Class Initialized
INFO - 2022-07-06 04:31:38 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 04:31:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-06 04:31:38 --> Severity: Notice --> Undefined variable: tk C:\wamp64\www\qr\application\views\filldetails\filldetails_1.php 173
INFO - 2022-07-06 04:31:38 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails_1.php
INFO - 2022-07-06 04:31:38 --> Final output sent to browser
DEBUG - 2022-07-06 04:31:38 --> Total execution time: 0.1026
INFO - 2022-07-06 04:33:37 --> Config Class Initialized
INFO - 2022-07-06 04:33:37 --> Hooks Class Initialized
DEBUG - 2022-07-06 04:33:37 --> UTF-8 Support Enabled
INFO - 2022-07-06 04:33:37 --> Utf8 Class Initialized
INFO - 2022-07-06 04:33:37 --> URI Class Initialized
INFO - 2022-07-06 04:33:37 --> Router Class Initialized
INFO - 2022-07-06 04:33:37 --> Output Class Initialized
INFO - 2022-07-06 04:33:37 --> Security Class Initialized
DEBUG - 2022-07-06 04:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 04:33:37 --> Input Class Initialized
INFO - 2022-07-06 04:33:37 --> Language Class Initialized
INFO - 2022-07-06 04:33:37 --> Loader Class Initialized
INFO - 2022-07-06 04:33:37 --> Helper loaded: url_helper
INFO - 2022-07-06 04:33:37 --> Helper loaded: file_helper
INFO - 2022-07-06 04:33:37 --> Database Driver Class Initialized
INFO - 2022-07-06 04:33:38 --> Email Class Initialized
DEBUG - 2022-07-06 04:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 04:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 04:33:38 --> Controller Class Initialized
INFO - 2022-07-06 04:33:38 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 04:33:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-06 04:33:38 --> Severity: Notice --> Undefined variable: tk C:\wamp64\www\qr\application\views\filldetails\filldetails_1.php 174
INFO - 2022-07-06 04:33:38 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails_1.php
INFO - 2022-07-06 04:33:38 --> Final output sent to browser
DEBUG - 2022-07-06 04:33:38 --> Total execution time: 0.0660
INFO - 2022-07-06 04:37:58 --> Config Class Initialized
INFO - 2022-07-06 04:37:58 --> Hooks Class Initialized
DEBUG - 2022-07-06 04:37:58 --> UTF-8 Support Enabled
INFO - 2022-07-06 04:37:58 --> Utf8 Class Initialized
INFO - 2022-07-06 04:37:58 --> URI Class Initialized
INFO - 2022-07-06 04:37:58 --> Router Class Initialized
INFO - 2022-07-06 04:37:58 --> Output Class Initialized
INFO - 2022-07-06 04:37:58 --> Security Class Initialized
DEBUG - 2022-07-06 04:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 04:37:58 --> Input Class Initialized
INFO - 2022-07-06 04:37:58 --> Language Class Initialized
INFO - 2022-07-06 04:37:58 --> Loader Class Initialized
INFO - 2022-07-06 04:37:58 --> Helper loaded: url_helper
INFO - 2022-07-06 04:37:58 --> Helper loaded: file_helper
INFO - 2022-07-06 04:37:58 --> Database Driver Class Initialized
INFO - 2022-07-06 04:37:58 --> Email Class Initialized
DEBUG - 2022-07-06 04:37:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 04:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 04:37:58 --> Controller Class Initialized
INFO - 2022-07-06 04:37:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 04:37:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-06 04:37:58 --> Severity: Notice --> Undefined variable: tk C:\wamp64\www\qr\application\views\filldetails\filldetails_1.php 172
INFO - 2022-07-06 04:37:58 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails_1.php
INFO - 2022-07-06 04:37:58 --> Final output sent to browser
DEBUG - 2022-07-06 04:37:58 --> Total execution time: 0.1053
INFO - 2022-07-06 04:40:58 --> Config Class Initialized
INFO - 2022-07-06 04:40:58 --> Hooks Class Initialized
DEBUG - 2022-07-06 04:40:58 --> UTF-8 Support Enabled
INFO - 2022-07-06 04:40:58 --> Utf8 Class Initialized
INFO - 2022-07-06 04:40:58 --> URI Class Initialized
INFO - 2022-07-06 04:40:58 --> Router Class Initialized
INFO - 2022-07-06 04:40:58 --> Output Class Initialized
INFO - 2022-07-06 04:40:58 --> Security Class Initialized
DEBUG - 2022-07-06 04:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 04:40:58 --> Input Class Initialized
INFO - 2022-07-06 04:40:58 --> Language Class Initialized
INFO - 2022-07-06 04:40:58 --> Loader Class Initialized
INFO - 2022-07-06 04:40:58 --> Helper loaded: url_helper
INFO - 2022-07-06 04:40:58 --> Helper loaded: file_helper
INFO - 2022-07-06 04:40:58 --> Database Driver Class Initialized
INFO - 2022-07-06 04:40:58 --> Email Class Initialized
DEBUG - 2022-07-06 04:40:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 04:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 04:40:58 --> Controller Class Initialized
INFO - 2022-07-06 04:40:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 04:40:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-06 04:40:58 --> Severity: Notice --> Undefined variable: tk C:\wamp64\www\qr\application\views\filldetails\filldetails_1.php 178
INFO - 2022-07-06 04:40:58 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails_1.php
INFO - 2022-07-06 04:40:58 --> Final output sent to browser
DEBUG - 2022-07-06 04:40:58 --> Total execution time: 0.0333
INFO - 2022-07-06 04:41:57 --> Config Class Initialized
INFO - 2022-07-06 04:41:57 --> Hooks Class Initialized
DEBUG - 2022-07-06 04:41:57 --> UTF-8 Support Enabled
INFO - 2022-07-06 04:41:57 --> Utf8 Class Initialized
INFO - 2022-07-06 04:41:57 --> URI Class Initialized
INFO - 2022-07-06 04:41:57 --> Router Class Initialized
INFO - 2022-07-06 04:41:57 --> Output Class Initialized
INFO - 2022-07-06 04:41:57 --> Security Class Initialized
DEBUG - 2022-07-06 04:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 04:41:57 --> Input Class Initialized
INFO - 2022-07-06 04:41:57 --> Language Class Initialized
INFO - 2022-07-06 04:41:57 --> Loader Class Initialized
INFO - 2022-07-06 04:41:57 --> Helper loaded: url_helper
INFO - 2022-07-06 04:41:57 --> Helper loaded: file_helper
INFO - 2022-07-06 04:41:57 --> Database Driver Class Initialized
INFO - 2022-07-06 04:41:57 --> Email Class Initialized
DEBUG - 2022-07-06 04:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 04:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 04:41:57 --> Controller Class Initialized
INFO - 2022-07-06 04:41:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 04:41:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 04:41:57 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails_1.php
INFO - 2022-07-06 04:41:57 --> Final output sent to browser
DEBUG - 2022-07-06 04:41:57 --> Total execution time: 0.0762
INFO - 2022-07-06 04:42:47 --> Config Class Initialized
INFO - 2022-07-06 04:42:47 --> Hooks Class Initialized
DEBUG - 2022-07-06 04:42:47 --> UTF-8 Support Enabled
INFO - 2022-07-06 04:42:47 --> Utf8 Class Initialized
INFO - 2022-07-06 04:42:47 --> URI Class Initialized
INFO - 2022-07-06 04:42:47 --> Router Class Initialized
INFO - 2022-07-06 04:42:47 --> Output Class Initialized
INFO - 2022-07-06 04:42:47 --> Security Class Initialized
DEBUG - 2022-07-06 04:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 04:42:47 --> Input Class Initialized
INFO - 2022-07-06 04:42:47 --> Language Class Initialized
INFO - 2022-07-06 04:42:47 --> Loader Class Initialized
INFO - 2022-07-06 04:42:47 --> Helper loaded: url_helper
INFO - 2022-07-06 04:42:47 --> Helper loaded: file_helper
INFO - 2022-07-06 04:42:47 --> Database Driver Class Initialized
INFO - 2022-07-06 04:42:47 --> Email Class Initialized
DEBUG - 2022-07-06 04:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 04:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 04:42:47 --> Controller Class Initialized
INFO - 2022-07-06 04:42:47 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 04:42:47 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 04:42:47 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails_1.php
INFO - 2022-07-06 04:42:47 --> Final output sent to browser
DEBUG - 2022-07-06 04:42:47 --> Total execution time: 0.0395
INFO - 2022-07-06 04:43:58 --> Config Class Initialized
INFO - 2022-07-06 04:43:58 --> Hooks Class Initialized
DEBUG - 2022-07-06 04:43:58 --> UTF-8 Support Enabled
INFO - 2022-07-06 04:43:58 --> Utf8 Class Initialized
INFO - 2022-07-06 04:43:58 --> URI Class Initialized
INFO - 2022-07-06 04:43:58 --> Router Class Initialized
INFO - 2022-07-06 04:43:58 --> Output Class Initialized
INFO - 2022-07-06 04:43:58 --> Security Class Initialized
DEBUG - 2022-07-06 04:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 04:43:58 --> Input Class Initialized
INFO - 2022-07-06 04:43:58 --> Language Class Initialized
INFO - 2022-07-06 04:43:58 --> Loader Class Initialized
INFO - 2022-07-06 04:43:58 --> Helper loaded: url_helper
INFO - 2022-07-06 04:43:58 --> Helper loaded: file_helper
INFO - 2022-07-06 04:43:58 --> Database Driver Class Initialized
INFO - 2022-07-06 04:43:58 --> Email Class Initialized
DEBUG - 2022-07-06 04:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 04:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 04:43:58 --> Controller Class Initialized
INFO - 2022-07-06 04:43:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 04:43:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 04:43:58 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails_1.php
INFO - 2022-07-06 04:43:58 --> Final output sent to browser
DEBUG - 2022-07-06 04:43:58 --> Total execution time: 0.0426
INFO - 2022-07-06 04:45:41 --> Config Class Initialized
INFO - 2022-07-06 04:45:41 --> Hooks Class Initialized
DEBUG - 2022-07-06 04:45:41 --> UTF-8 Support Enabled
INFO - 2022-07-06 04:45:41 --> Utf8 Class Initialized
INFO - 2022-07-06 04:45:41 --> URI Class Initialized
INFO - 2022-07-06 04:45:41 --> Router Class Initialized
INFO - 2022-07-06 04:45:41 --> Output Class Initialized
INFO - 2022-07-06 04:45:41 --> Security Class Initialized
DEBUG - 2022-07-06 04:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 04:45:41 --> Input Class Initialized
INFO - 2022-07-06 04:45:41 --> Language Class Initialized
INFO - 2022-07-06 04:45:41 --> Loader Class Initialized
INFO - 2022-07-06 04:45:41 --> Helper loaded: url_helper
INFO - 2022-07-06 04:45:41 --> Helper loaded: file_helper
INFO - 2022-07-06 04:45:41 --> Database Driver Class Initialized
INFO - 2022-07-06 04:45:41 --> Email Class Initialized
DEBUG - 2022-07-06 04:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 04:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 04:45:41 --> Controller Class Initialized
INFO - 2022-07-06 04:45:41 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 04:45:41 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 04:45:41 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails_1.php
INFO - 2022-07-06 04:45:41 --> Final output sent to browser
DEBUG - 2022-07-06 04:45:41 --> Total execution time: 0.0197
INFO - 2022-07-06 04:52:27 --> Config Class Initialized
INFO - 2022-07-06 04:52:27 --> Hooks Class Initialized
DEBUG - 2022-07-06 04:52:27 --> UTF-8 Support Enabled
INFO - 2022-07-06 04:52:27 --> Utf8 Class Initialized
INFO - 2022-07-06 04:52:27 --> URI Class Initialized
INFO - 2022-07-06 04:52:27 --> Router Class Initialized
INFO - 2022-07-06 04:52:27 --> Output Class Initialized
INFO - 2022-07-06 04:52:27 --> Security Class Initialized
DEBUG - 2022-07-06 04:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 04:52:27 --> Input Class Initialized
INFO - 2022-07-06 04:52:27 --> Language Class Initialized
INFO - 2022-07-06 04:52:27 --> Loader Class Initialized
INFO - 2022-07-06 04:52:27 --> Helper loaded: url_helper
INFO - 2022-07-06 04:52:27 --> Helper loaded: file_helper
INFO - 2022-07-06 04:52:27 --> Database Driver Class Initialized
INFO - 2022-07-06 04:52:27 --> Email Class Initialized
DEBUG - 2022-07-06 04:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 04:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 04:52:27 --> Controller Class Initialized
INFO - 2022-07-06 04:52:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 04:52:27 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 04:52:27 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails_1.php
INFO - 2022-07-06 04:52:27 --> Final output sent to browser
DEBUG - 2022-07-06 04:52:27 --> Total execution time: 0.0205
INFO - 2022-07-06 04:54:36 --> Config Class Initialized
INFO - 2022-07-06 04:54:36 --> Hooks Class Initialized
DEBUG - 2022-07-06 04:54:36 --> UTF-8 Support Enabled
INFO - 2022-07-06 04:54:36 --> Utf8 Class Initialized
INFO - 2022-07-06 04:54:36 --> URI Class Initialized
INFO - 2022-07-06 04:54:36 --> Router Class Initialized
INFO - 2022-07-06 04:54:36 --> Output Class Initialized
INFO - 2022-07-06 04:54:36 --> Security Class Initialized
DEBUG - 2022-07-06 04:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 04:54:36 --> Input Class Initialized
INFO - 2022-07-06 04:54:36 --> Language Class Initialized
INFO - 2022-07-06 04:54:36 --> Loader Class Initialized
INFO - 2022-07-06 04:54:36 --> Helper loaded: url_helper
INFO - 2022-07-06 04:54:36 --> Helper loaded: file_helper
INFO - 2022-07-06 04:54:36 --> Database Driver Class Initialized
INFO - 2022-07-06 04:54:36 --> Email Class Initialized
DEBUG - 2022-07-06 04:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 04:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 04:54:36 --> Controller Class Initialized
INFO - 2022-07-06 04:54:36 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 04:54:36 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 04:54:36 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails_1.php
INFO - 2022-07-06 04:54:36 --> Final output sent to browser
DEBUG - 2022-07-06 04:54:36 --> Total execution time: 0.0218
INFO - 2022-07-06 04:58:19 --> Config Class Initialized
INFO - 2022-07-06 04:58:19 --> Hooks Class Initialized
DEBUG - 2022-07-06 04:58:19 --> UTF-8 Support Enabled
INFO - 2022-07-06 04:58:19 --> Utf8 Class Initialized
INFO - 2022-07-06 04:58:19 --> URI Class Initialized
INFO - 2022-07-06 04:58:19 --> Router Class Initialized
INFO - 2022-07-06 04:58:19 --> Output Class Initialized
INFO - 2022-07-06 04:58:19 --> Security Class Initialized
DEBUG - 2022-07-06 04:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 04:58:19 --> Input Class Initialized
INFO - 2022-07-06 04:58:19 --> Language Class Initialized
INFO - 2022-07-06 04:58:19 --> Loader Class Initialized
INFO - 2022-07-06 04:58:19 --> Helper loaded: url_helper
INFO - 2022-07-06 04:58:19 --> Helper loaded: file_helper
INFO - 2022-07-06 04:58:19 --> Database Driver Class Initialized
INFO - 2022-07-06 04:58:19 --> Email Class Initialized
DEBUG - 2022-07-06 04:58:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 04:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 04:58:19 --> Controller Class Initialized
INFO - 2022-07-06 04:58:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 04:58:19 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 04:58:19 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails_1.php
INFO - 2022-07-06 04:58:19 --> Final output sent to browser
DEBUG - 2022-07-06 04:58:19 --> Total execution time: 0.0195
INFO - 2022-07-06 05:00:35 --> Config Class Initialized
INFO - 2022-07-06 05:00:35 --> Hooks Class Initialized
DEBUG - 2022-07-06 05:00:35 --> UTF-8 Support Enabled
INFO - 2022-07-06 05:00:35 --> Utf8 Class Initialized
INFO - 2022-07-06 05:00:35 --> URI Class Initialized
INFO - 2022-07-06 05:00:35 --> Router Class Initialized
INFO - 2022-07-06 05:00:35 --> Output Class Initialized
INFO - 2022-07-06 05:00:35 --> Security Class Initialized
DEBUG - 2022-07-06 05:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 05:00:35 --> Input Class Initialized
INFO - 2022-07-06 05:00:35 --> Language Class Initialized
INFO - 2022-07-06 05:00:35 --> Loader Class Initialized
INFO - 2022-07-06 05:00:35 --> Helper loaded: url_helper
INFO - 2022-07-06 05:00:35 --> Helper loaded: file_helper
INFO - 2022-07-06 05:00:35 --> Database Driver Class Initialized
INFO - 2022-07-06 05:00:35 --> Email Class Initialized
DEBUG - 2022-07-06 05:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 05:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 05:00:35 --> Controller Class Initialized
INFO - 2022-07-06 05:00:35 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 05:00:35 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 05:00:35 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails_1.php
INFO - 2022-07-06 05:00:35 --> Final output sent to browser
DEBUG - 2022-07-06 05:00:35 --> Total execution time: 0.0578
INFO - 2022-07-06 05:00:49 --> Config Class Initialized
INFO - 2022-07-06 05:00:49 --> Hooks Class Initialized
DEBUG - 2022-07-06 05:00:49 --> UTF-8 Support Enabled
INFO - 2022-07-06 05:00:49 --> Utf8 Class Initialized
INFO - 2022-07-06 05:00:49 --> URI Class Initialized
INFO - 2022-07-06 05:00:49 --> Router Class Initialized
INFO - 2022-07-06 05:00:49 --> Output Class Initialized
INFO - 2022-07-06 05:00:49 --> Security Class Initialized
DEBUG - 2022-07-06 05:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 05:00:49 --> Input Class Initialized
INFO - 2022-07-06 05:00:49 --> Language Class Initialized
INFO - 2022-07-06 05:00:49 --> Loader Class Initialized
INFO - 2022-07-06 05:00:49 --> Helper loaded: url_helper
INFO - 2022-07-06 05:00:49 --> Helper loaded: file_helper
INFO - 2022-07-06 05:00:49 --> Database Driver Class Initialized
INFO - 2022-07-06 05:00:49 --> Email Class Initialized
DEBUG - 2022-07-06 05:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 05:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 05:00:49 --> Controller Class Initialized
INFO - 2022-07-06 05:00:49 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 05:00:49 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 05:00:49 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails_1.php
INFO - 2022-07-06 05:00:49 --> Final output sent to browser
DEBUG - 2022-07-06 05:00:49 --> Total execution time: 0.1198
INFO - 2022-07-06 05:02:02 --> Config Class Initialized
INFO - 2022-07-06 05:02:02 --> Hooks Class Initialized
DEBUG - 2022-07-06 05:02:02 --> UTF-8 Support Enabled
INFO - 2022-07-06 05:02:02 --> Utf8 Class Initialized
INFO - 2022-07-06 05:02:02 --> URI Class Initialized
INFO - 2022-07-06 05:02:02 --> Router Class Initialized
INFO - 2022-07-06 05:02:02 --> Output Class Initialized
INFO - 2022-07-06 05:02:02 --> Security Class Initialized
DEBUG - 2022-07-06 05:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 05:02:02 --> Input Class Initialized
INFO - 2022-07-06 05:02:02 --> Language Class Initialized
INFO - 2022-07-06 05:02:02 --> Loader Class Initialized
INFO - 2022-07-06 05:02:02 --> Helper loaded: url_helper
INFO - 2022-07-06 05:02:02 --> Helper loaded: file_helper
INFO - 2022-07-06 05:02:02 --> Database Driver Class Initialized
INFO - 2022-07-06 05:02:03 --> Email Class Initialized
DEBUG - 2022-07-06 05:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 05:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 05:02:03 --> Controller Class Initialized
INFO - 2022-07-06 05:02:03 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 05:02:03 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 05:02:03 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails_1.php
INFO - 2022-07-06 05:02:03 --> Final output sent to browser
DEBUG - 2022-07-06 05:02:03 --> Total execution time: 0.1246
INFO - 2022-07-06 05:05:42 --> Config Class Initialized
INFO - 2022-07-06 05:05:42 --> Hooks Class Initialized
DEBUG - 2022-07-06 05:05:42 --> UTF-8 Support Enabled
INFO - 2022-07-06 05:05:42 --> Utf8 Class Initialized
INFO - 2022-07-06 05:05:42 --> URI Class Initialized
INFO - 2022-07-06 05:05:42 --> Router Class Initialized
INFO - 2022-07-06 05:05:42 --> Output Class Initialized
INFO - 2022-07-06 05:05:42 --> Security Class Initialized
DEBUG - 2022-07-06 05:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 05:05:42 --> Input Class Initialized
INFO - 2022-07-06 05:05:42 --> Language Class Initialized
INFO - 2022-07-06 05:05:42 --> Loader Class Initialized
INFO - 2022-07-06 05:05:42 --> Helper loaded: url_helper
INFO - 2022-07-06 05:05:42 --> Helper loaded: file_helper
INFO - 2022-07-06 05:05:42 --> Database Driver Class Initialized
INFO - 2022-07-06 05:05:43 --> Email Class Initialized
DEBUG - 2022-07-06 05:05:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 05:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 05:05:43 --> Controller Class Initialized
INFO - 2022-07-06 05:05:43 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 05:05:43 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 05:05:43 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails_1.php
INFO - 2022-07-06 05:05:43 --> Final output sent to browser
DEBUG - 2022-07-06 05:05:43 --> Total execution time: 0.1403
INFO - 2022-07-06 05:07:26 --> Config Class Initialized
INFO - 2022-07-06 05:07:26 --> Hooks Class Initialized
DEBUG - 2022-07-06 05:07:26 --> UTF-8 Support Enabled
INFO - 2022-07-06 05:07:26 --> Utf8 Class Initialized
INFO - 2022-07-06 05:07:26 --> URI Class Initialized
INFO - 2022-07-06 05:07:26 --> Router Class Initialized
INFO - 2022-07-06 05:07:26 --> Output Class Initialized
INFO - 2022-07-06 05:07:26 --> Security Class Initialized
DEBUG - 2022-07-06 05:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 05:07:26 --> Input Class Initialized
INFO - 2022-07-06 05:07:26 --> Language Class Initialized
INFO - 2022-07-06 05:07:26 --> Loader Class Initialized
INFO - 2022-07-06 05:07:26 --> Helper loaded: url_helper
INFO - 2022-07-06 05:07:26 --> Helper loaded: file_helper
INFO - 2022-07-06 05:07:26 --> Database Driver Class Initialized
INFO - 2022-07-06 05:07:26 --> Email Class Initialized
DEBUG - 2022-07-06 05:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 05:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 05:07:26 --> Controller Class Initialized
INFO - 2022-07-06 05:07:26 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 05:07:26 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 05:07:26 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails_1.php
INFO - 2022-07-06 05:07:26 --> Final output sent to browser
DEBUG - 2022-07-06 05:07:26 --> Total execution time: 0.0202
INFO - 2022-07-06 05:08:03 --> Config Class Initialized
INFO - 2022-07-06 05:08:03 --> Hooks Class Initialized
DEBUG - 2022-07-06 05:08:03 --> UTF-8 Support Enabled
INFO - 2022-07-06 05:08:03 --> Utf8 Class Initialized
INFO - 2022-07-06 05:08:03 --> URI Class Initialized
INFO - 2022-07-06 05:08:03 --> Router Class Initialized
INFO - 2022-07-06 05:08:03 --> Output Class Initialized
INFO - 2022-07-06 05:08:03 --> Security Class Initialized
DEBUG - 2022-07-06 05:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 05:08:03 --> Input Class Initialized
INFO - 2022-07-06 05:08:03 --> Language Class Initialized
INFO - 2022-07-06 05:08:03 --> Loader Class Initialized
INFO - 2022-07-06 05:08:03 --> Helper loaded: url_helper
INFO - 2022-07-06 05:08:03 --> Helper loaded: file_helper
INFO - 2022-07-06 05:08:03 --> Database Driver Class Initialized
INFO - 2022-07-06 05:08:03 --> Email Class Initialized
DEBUG - 2022-07-06 05:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 05:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 05:08:03 --> Controller Class Initialized
INFO - 2022-07-06 05:08:03 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 05:08:03 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 05:08:03 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails_1.php
INFO - 2022-07-06 05:08:03 --> Final output sent to browser
DEBUG - 2022-07-06 05:08:03 --> Total execution time: 0.0241
INFO - 2022-07-06 05:09:03 --> Config Class Initialized
INFO - 2022-07-06 05:09:03 --> Hooks Class Initialized
DEBUG - 2022-07-06 05:09:03 --> UTF-8 Support Enabled
INFO - 2022-07-06 05:09:03 --> Utf8 Class Initialized
INFO - 2022-07-06 05:09:03 --> URI Class Initialized
INFO - 2022-07-06 05:09:03 --> Router Class Initialized
INFO - 2022-07-06 05:09:03 --> Output Class Initialized
INFO - 2022-07-06 05:09:03 --> Security Class Initialized
DEBUG - 2022-07-06 05:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 05:09:03 --> Input Class Initialized
INFO - 2022-07-06 05:09:03 --> Language Class Initialized
INFO - 2022-07-06 05:09:03 --> Loader Class Initialized
INFO - 2022-07-06 05:09:03 --> Helper loaded: url_helper
INFO - 2022-07-06 05:09:03 --> Helper loaded: file_helper
INFO - 2022-07-06 05:09:03 --> Database Driver Class Initialized
INFO - 2022-07-06 05:09:03 --> Email Class Initialized
DEBUG - 2022-07-06 05:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 05:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 05:09:03 --> Controller Class Initialized
INFO - 2022-07-06 05:09:03 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 05:09:03 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 05:09:03 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails_1.php
INFO - 2022-07-06 05:09:03 --> Final output sent to browser
DEBUG - 2022-07-06 05:09:03 --> Total execution time: 0.1585
INFO - 2022-07-06 05:09:30 --> Config Class Initialized
INFO - 2022-07-06 05:09:30 --> Hooks Class Initialized
DEBUG - 2022-07-06 05:09:30 --> UTF-8 Support Enabled
INFO - 2022-07-06 05:09:30 --> Utf8 Class Initialized
INFO - 2022-07-06 05:09:30 --> URI Class Initialized
INFO - 2022-07-06 05:09:30 --> Router Class Initialized
INFO - 2022-07-06 05:09:30 --> Output Class Initialized
INFO - 2022-07-06 05:09:30 --> Security Class Initialized
DEBUG - 2022-07-06 05:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 05:09:30 --> Input Class Initialized
INFO - 2022-07-06 05:09:30 --> Language Class Initialized
INFO - 2022-07-06 05:09:30 --> Loader Class Initialized
INFO - 2022-07-06 05:09:30 --> Helper loaded: url_helper
INFO - 2022-07-06 05:09:30 --> Helper loaded: file_helper
INFO - 2022-07-06 05:09:30 --> Database Driver Class Initialized
INFO - 2022-07-06 05:09:30 --> Email Class Initialized
DEBUG - 2022-07-06 05:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 05:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 05:09:30 --> Controller Class Initialized
INFO - 2022-07-06 05:09:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 05:09:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 05:09:30 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails_1.php
INFO - 2022-07-06 05:09:30 --> Final output sent to browser
DEBUG - 2022-07-06 05:09:30 --> Total execution time: 0.1329
INFO - 2022-07-06 05:10:37 --> Config Class Initialized
INFO - 2022-07-06 05:10:37 --> Hooks Class Initialized
DEBUG - 2022-07-06 05:10:37 --> UTF-8 Support Enabled
INFO - 2022-07-06 05:10:37 --> Utf8 Class Initialized
INFO - 2022-07-06 05:10:37 --> URI Class Initialized
INFO - 2022-07-06 05:10:37 --> Router Class Initialized
INFO - 2022-07-06 05:10:37 --> Output Class Initialized
INFO - 2022-07-06 05:10:37 --> Security Class Initialized
DEBUG - 2022-07-06 05:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 05:10:37 --> Input Class Initialized
INFO - 2022-07-06 05:10:37 --> Language Class Initialized
INFO - 2022-07-06 05:10:37 --> Loader Class Initialized
INFO - 2022-07-06 05:10:37 --> Helper loaded: url_helper
INFO - 2022-07-06 05:10:37 --> Helper loaded: file_helper
INFO - 2022-07-06 05:10:37 --> Database Driver Class Initialized
INFO - 2022-07-06 05:10:37 --> Email Class Initialized
DEBUG - 2022-07-06 05:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 05:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 05:10:38 --> Controller Class Initialized
INFO - 2022-07-06 05:10:38 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 05:10:38 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 05:10:38 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails_1.php
INFO - 2022-07-06 05:10:38 --> Final output sent to browser
DEBUG - 2022-07-06 05:10:38 --> Total execution time: 0.1373
INFO - 2022-07-06 05:12:54 --> Config Class Initialized
INFO - 2022-07-06 05:12:54 --> Hooks Class Initialized
DEBUG - 2022-07-06 05:12:54 --> UTF-8 Support Enabled
INFO - 2022-07-06 05:12:54 --> Utf8 Class Initialized
INFO - 2022-07-06 05:12:54 --> URI Class Initialized
INFO - 2022-07-06 05:12:54 --> Router Class Initialized
INFO - 2022-07-06 05:12:54 --> Output Class Initialized
INFO - 2022-07-06 05:12:54 --> Security Class Initialized
DEBUG - 2022-07-06 05:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 05:12:54 --> Input Class Initialized
INFO - 2022-07-06 05:12:54 --> Language Class Initialized
INFO - 2022-07-06 05:12:54 --> Loader Class Initialized
INFO - 2022-07-06 05:12:54 --> Helper loaded: url_helper
INFO - 2022-07-06 05:12:54 --> Helper loaded: file_helper
INFO - 2022-07-06 05:12:54 --> Database Driver Class Initialized
INFO - 2022-07-06 05:12:54 --> Email Class Initialized
DEBUG - 2022-07-06 05:12:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 05:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 05:12:54 --> Controller Class Initialized
INFO - 2022-07-06 05:12:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 05:12:54 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 05:12:54 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails_1.php
INFO - 2022-07-06 05:12:54 --> Final output sent to browser
DEBUG - 2022-07-06 05:12:54 --> Total execution time: 0.0366
INFO - 2022-07-06 05:12:57 --> Config Class Initialized
INFO - 2022-07-06 05:12:57 --> Hooks Class Initialized
DEBUG - 2022-07-06 05:12:57 --> UTF-8 Support Enabled
INFO - 2022-07-06 05:12:57 --> Utf8 Class Initialized
INFO - 2022-07-06 05:12:57 --> URI Class Initialized
INFO - 2022-07-06 05:12:57 --> Router Class Initialized
INFO - 2022-07-06 05:12:57 --> Output Class Initialized
INFO - 2022-07-06 05:12:57 --> Security Class Initialized
DEBUG - 2022-07-06 05:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 05:12:57 --> Input Class Initialized
INFO - 2022-07-06 05:12:57 --> Language Class Initialized
INFO - 2022-07-06 05:12:57 --> Loader Class Initialized
INFO - 2022-07-06 05:12:57 --> Helper loaded: url_helper
INFO - 2022-07-06 05:12:57 --> Helper loaded: file_helper
INFO - 2022-07-06 05:12:57 --> Database Driver Class Initialized
INFO - 2022-07-06 05:12:57 --> Email Class Initialized
DEBUG - 2022-07-06 05:12:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 05:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 05:12:57 --> Controller Class Initialized
INFO - 2022-07-06 05:12:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 05:12:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 05:12:57 --> test
ERROR - 2022-07-06 05:12:57 --> Query error: Column 'ud_token' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_name`, `ud_age`, `ud_gender`, `ud_time`, `ud_token`, `td_id_fk`) VALUES ('', '', '', '2022/7/6 10:42', NULL, NULL)
INFO - 2022-07-06 05:12:57 --> Language file loaded: language/english/db_lang.php
INFO - 2022-07-06 05:14:24 --> Config Class Initialized
INFO - 2022-07-06 05:14:24 --> Hooks Class Initialized
DEBUG - 2022-07-06 05:14:24 --> UTF-8 Support Enabled
INFO - 2022-07-06 05:14:24 --> Utf8 Class Initialized
INFO - 2022-07-06 05:14:24 --> URI Class Initialized
INFO - 2022-07-06 05:14:24 --> Router Class Initialized
INFO - 2022-07-06 05:14:24 --> Output Class Initialized
INFO - 2022-07-06 05:14:24 --> Security Class Initialized
DEBUG - 2022-07-06 05:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 05:14:24 --> Input Class Initialized
INFO - 2022-07-06 05:14:24 --> Language Class Initialized
INFO - 2022-07-06 05:14:24 --> Loader Class Initialized
INFO - 2022-07-06 05:14:24 --> Helper loaded: url_helper
INFO - 2022-07-06 05:14:24 --> Helper loaded: file_helper
INFO - 2022-07-06 05:14:24 --> Database Driver Class Initialized
INFO - 2022-07-06 05:14:24 --> Email Class Initialized
DEBUG - 2022-07-06 05:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 05:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 05:14:24 --> Controller Class Initialized
INFO - 2022-07-06 05:14:24 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 05:14:24 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 05:14:24 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails_1.php
INFO - 2022-07-06 05:14:24 --> Final output sent to browser
DEBUG - 2022-07-06 05:14:25 --> Total execution time: 0.1235
INFO - 2022-07-06 05:15:05 --> Config Class Initialized
INFO - 2022-07-06 05:15:05 --> Hooks Class Initialized
DEBUG - 2022-07-06 05:15:05 --> UTF-8 Support Enabled
INFO - 2022-07-06 05:15:05 --> Utf8 Class Initialized
INFO - 2022-07-06 05:15:05 --> URI Class Initialized
INFO - 2022-07-06 05:15:05 --> Router Class Initialized
INFO - 2022-07-06 05:15:05 --> Output Class Initialized
INFO - 2022-07-06 05:15:05 --> Security Class Initialized
DEBUG - 2022-07-06 05:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 05:15:05 --> Input Class Initialized
INFO - 2022-07-06 05:15:05 --> Language Class Initialized
INFO - 2022-07-06 05:15:05 --> Loader Class Initialized
INFO - 2022-07-06 05:15:05 --> Helper loaded: url_helper
INFO - 2022-07-06 05:15:05 --> Helper loaded: file_helper
INFO - 2022-07-06 05:15:05 --> Database Driver Class Initialized
INFO - 2022-07-06 05:15:05 --> Email Class Initialized
DEBUG - 2022-07-06 05:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 05:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 05:15:05 --> Controller Class Initialized
INFO - 2022-07-06 05:15:05 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 05:15:05 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 05:15:05 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails_1.php
INFO - 2022-07-06 05:15:05 --> Final output sent to browser
DEBUG - 2022-07-06 05:15:05 --> Total execution time: 0.0282
INFO - 2022-07-06 05:18:15 --> Config Class Initialized
INFO - 2022-07-06 05:18:15 --> Hooks Class Initialized
DEBUG - 2022-07-06 05:18:15 --> UTF-8 Support Enabled
INFO - 2022-07-06 05:18:15 --> Utf8 Class Initialized
INFO - 2022-07-06 05:18:15 --> URI Class Initialized
INFO - 2022-07-06 05:18:15 --> Router Class Initialized
INFO - 2022-07-06 05:18:15 --> Output Class Initialized
INFO - 2022-07-06 05:18:15 --> Security Class Initialized
DEBUG - 2022-07-06 05:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 05:18:15 --> Input Class Initialized
INFO - 2022-07-06 05:18:15 --> Language Class Initialized
INFO - 2022-07-06 05:18:15 --> Loader Class Initialized
INFO - 2022-07-06 05:18:15 --> Helper loaded: url_helper
INFO - 2022-07-06 05:18:15 --> Helper loaded: file_helper
INFO - 2022-07-06 05:18:15 --> Database Driver Class Initialized
INFO - 2022-07-06 05:18:15 --> Email Class Initialized
DEBUG - 2022-07-06 05:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 05:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 05:18:15 --> Controller Class Initialized
INFO - 2022-07-06 05:18:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 05:18:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 05:18:15 --> test
ERROR - 2022-07-06 05:18:15 --> Query error: Column 'ud_token' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_name`, `ud_age`, `ud_gender`, `ud_time`, `ud_token`, `td_id_fk`) VALUES ('', '', 'male', '2022/7/6 10:48', NULL, NULL)
INFO - 2022-07-06 05:18:15 --> Language file loaded: language/english/db_lang.php
INFO - 2022-07-06 05:18:23 --> Config Class Initialized
INFO - 2022-07-06 05:18:23 --> Hooks Class Initialized
DEBUG - 2022-07-06 05:18:23 --> UTF-8 Support Enabled
INFO - 2022-07-06 05:18:23 --> Utf8 Class Initialized
INFO - 2022-07-06 05:18:23 --> URI Class Initialized
INFO - 2022-07-06 05:18:23 --> Router Class Initialized
INFO - 2022-07-06 05:18:23 --> Output Class Initialized
INFO - 2022-07-06 05:18:23 --> Security Class Initialized
DEBUG - 2022-07-06 05:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 05:18:23 --> Input Class Initialized
INFO - 2022-07-06 05:18:23 --> Language Class Initialized
INFO - 2022-07-06 05:18:23 --> Loader Class Initialized
INFO - 2022-07-06 05:18:23 --> Helper loaded: url_helper
INFO - 2022-07-06 05:18:23 --> Helper loaded: file_helper
INFO - 2022-07-06 05:18:23 --> Database Driver Class Initialized
INFO - 2022-07-06 05:18:23 --> Email Class Initialized
DEBUG - 2022-07-06 05:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 05:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 05:18:23 --> Controller Class Initialized
INFO - 2022-07-06 05:18:23 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 05:18:23 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 05:18:23 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails_1.php
INFO - 2022-07-06 05:18:23 --> Final output sent to browser
DEBUG - 2022-07-06 05:18:23 --> Total execution time: 0.2047
INFO - 2022-07-06 05:18:27 --> Config Class Initialized
INFO - 2022-07-06 05:18:27 --> Hooks Class Initialized
DEBUG - 2022-07-06 05:18:27 --> UTF-8 Support Enabled
INFO - 2022-07-06 05:18:27 --> Utf8 Class Initialized
INFO - 2022-07-06 05:18:27 --> URI Class Initialized
INFO - 2022-07-06 05:18:27 --> Router Class Initialized
INFO - 2022-07-06 05:18:27 --> Output Class Initialized
INFO - 2022-07-06 05:18:27 --> Security Class Initialized
DEBUG - 2022-07-06 05:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 05:18:27 --> Input Class Initialized
INFO - 2022-07-06 05:18:27 --> Language Class Initialized
INFO - 2022-07-06 05:18:27 --> Loader Class Initialized
INFO - 2022-07-06 05:18:27 --> Helper loaded: url_helper
INFO - 2022-07-06 05:18:27 --> Helper loaded: file_helper
INFO - 2022-07-06 05:18:27 --> Database Driver Class Initialized
INFO - 2022-07-06 05:18:27 --> Email Class Initialized
DEBUG - 2022-07-06 05:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 05:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 05:18:27 --> Controller Class Initialized
INFO - 2022-07-06 05:18:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 05:18:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 05:18:27 --> test
ERROR - 2022-07-06 05:18:27 --> Query error: Column 'ud_token' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_name`, `ud_age`, `ud_gender`, `ud_time`, `ud_token`, `td_id_fk`) VALUES ('', '', '', '2022/7/6 10:48', NULL, NULL)
INFO - 2022-07-06 05:18:27 --> Language file loaded: language/english/db_lang.php
INFO - 2022-07-06 05:19:47 --> Config Class Initialized
INFO - 2022-07-06 05:19:47 --> Hooks Class Initialized
DEBUG - 2022-07-06 05:19:47 --> UTF-8 Support Enabled
INFO - 2022-07-06 05:19:47 --> Utf8 Class Initialized
INFO - 2022-07-06 05:19:47 --> URI Class Initialized
INFO - 2022-07-06 05:19:47 --> Router Class Initialized
INFO - 2022-07-06 05:19:47 --> Output Class Initialized
INFO - 2022-07-06 05:19:47 --> Security Class Initialized
DEBUG - 2022-07-06 05:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 05:19:47 --> Input Class Initialized
INFO - 2022-07-06 05:19:47 --> Language Class Initialized
INFO - 2022-07-06 05:19:47 --> Loader Class Initialized
INFO - 2022-07-06 05:19:47 --> Helper loaded: url_helper
INFO - 2022-07-06 05:19:47 --> Helper loaded: file_helper
INFO - 2022-07-06 05:19:47 --> Database Driver Class Initialized
INFO - 2022-07-06 05:19:47 --> Email Class Initialized
DEBUG - 2022-07-06 05:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 05:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 05:19:47 --> Controller Class Initialized
INFO - 2022-07-06 05:19:47 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 05:19:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 05:19:47 --> insertedINSERT INTO `tokendetails` (`td_tk`, `td_cs`, `td_visited_date`) VALUES (1, 0, '2022-07-06')
INFO - 2022-07-06 05:19:48 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-06 05:19:48 --> Final output sent to browser
DEBUG - 2022-07-06 05:19:48 --> Total execution time: 1.1858
INFO - 2022-07-06 05:19:50 --> Config Class Initialized
INFO - 2022-07-06 05:19:50 --> Hooks Class Initialized
DEBUG - 2022-07-06 05:19:50 --> UTF-8 Support Enabled
INFO - 2022-07-06 05:19:50 --> Utf8 Class Initialized
INFO - 2022-07-06 05:19:50 --> URI Class Initialized
INFO - 2022-07-06 05:19:50 --> Router Class Initialized
INFO - 2022-07-06 05:19:50 --> Output Class Initialized
INFO - 2022-07-06 05:19:50 --> Security Class Initialized
DEBUG - 2022-07-06 05:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 05:19:50 --> Input Class Initialized
INFO - 2022-07-06 05:19:50 --> Language Class Initialized
INFO - 2022-07-06 05:19:50 --> Loader Class Initialized
INFO - 2022-07-06 05:19:50 --> Helper loaded: url_helper
INFO - 2022-07-06 05:19:50 --> Helper loaded: file_helper
INFO - 2022-07-06 05:19:50 --> Database Driver Class Initialized
INFO - 2022-07-06 05:19:50 --> Email Class Initialized
DEBUG - 2022-07-06 05:19:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 05:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 05:19:50 --> Controller Class Initialized
INFO - 2022-07-06 05:19:50 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 05:19:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 05:19:50 --> insertedINSERT INTO `tokendetails` (`td_tk`, `td_cs`, `td_visited_date`) VALUES (2, 0, '2022-07-06')
INFO - 2022-07-06 05:19:50 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-06 05:19:50 --> Final output sent to browser
DEBUG - 2022-07-06 05:19:50 --> Total execution time: 0.0804
INFO - 2022-07-06 05:19:51 --> Config Class Initialized
INFO - 2022-07-06 05:19:51 --> Hooks Class Initialized
DEBUG - 2022-07-06 05:19:51 --> UTF-8 Support Enabled
INFO - 2022-07-06 05:19:51 --> Utf8 Class Initialized
INFO - 2022-07-06 05:19:51 --> URI Class Initialized
INFO - 2022-07-06 05:19:51 --> Router Class Initialized
INFO - 2022-07-06 05:19:51 --> Output Class Initialized
INFO - 2022-07-06 05:19:51 --> Security Class Initialized
DEBUG - 2022-07-06 05:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 05:19:51 --> Input Class Initialized
INFO - 2022-07-06 05:19:51 --> Language Class Initialized
INFO - 2022-07-06 05:19:51 --> Loader Class Initialized
INFO - 2022-07-06 05:19:51 --> Helper loaded: url_helper
INFO - 2022-07-06 05:19:51 --> Helper loaded: file_helper
INFO - 2022-07-06 05:19:51 --> Database Driver Class Initialized
INFO - 2022-07-06 05:19:51 --> Email Class Initialized
DEBUG - 2022-07-06 05:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 05:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 05:19:51 --> Controller Class Initialized
INFO - 2022-07-06 05:19:51 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 05:19:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 05:19:51 --> insertedINSERT INTO `tokendetails` (`td_tk`, `td_cs`, `td_visited_date`) VALUES (3, 0, '2022-07-06')
INFO - 2022-07-06 05:19:51 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-06 05:19:51 --> Final output sent to browser
DEBUG - 2022-07-06 05:19:51 --> Total execution time: 0.0946
INFO - 2022-07-06 05:19:51 --> Config Class Initialized
INFO - 2022-07-06 05:19:51 --> Hooks Class Initialized
DEBUG - 2022-07-06 05:19:51 --> UTF-8 Support Enabled
INFO - 2022-07-06 05:19:51 --> Utf8 Class Initialized
INFO - 2022-07-06 05:19:51 --> URI Class Initialized
INFO - 2022-07-06 05:19:51 --> Router Class Initialized
INFO - 2022-07-06 05:19:51 --> Output Class Initialized
INFO - 2022-07-06 05:19:51 --> Security Class Initialized
DEBUG - 2022-07-06 05:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 05:19:51 --> Input Class Initialized
INFO - 2022-07-06 05:19:51 --> Language Class Initialized
INFO - 2022-07-06 05:19:51 --> Loader Class Initialized
INFO - 2022-07-06 05:19:51 --> Helper loaded: url_helper
INFO - 2022-07-06 05:19:51 --> Helper loaded: file_helper
INFO - 2022-07-06 05:19:52 --> Database Driver Class Initialized
INFO - 2022-07-06 05:19:52 --> Email Class Initialized
DEBUG - 2022-07-06 05:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 05:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 05:19:52 --> Controller Class Initialized
INFO - 2022-07-06 05:19:52 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 05:19:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 05:19:52 --> insertedINSERT INTO `tokendetails` (`td_tk`, `td_cs`, `td_visited_date`) VALUES (4, 0, '2022-07-06')
INFO - 2022-07-06 05:19:52 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-06 05:19:52 --> Final output sent to browser
DEBUG - 2022-07-06 05:19:52 --> Total execution time: 0.1463
INFO - 2022-07-06 05:20:25 --> Config Class Initialized
INFO - 2022-07-06 05:20:25 --> Hooks Class Initialized
DEBUG - 2022-07-06 05:20:25 --> UTF-8 Support Enabled
INFO - 2022-07-06 05:20:25 --> Utf8 Class Initialized
INFO - 2022-07-06 05:20:25 --> URI Class Initialized
INFO - 2022-07-06 05:20:25 --> Router Class Initialized
INFO - 2022-07-06 05:20:25 --> Output Class Initialized
INFO - 2022-07-06 05:20:25 --> Security Class Initialized
DEBUG - 2022-07-06 05:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 05:20:25 --> Input Class Initialized
INFO - 2022-07-06 05:20:25 --> Language Class Initialized
INFO - 2022-07-06 05:20:25 --> Loader Class Initialized
INFO - 2022-07-06 05:20:25 --> Helper loaded: url_helper
INFO - 2022-07-06 05:20:25 --> Helper loaded: file_helper
INFO - 2022-07-06 05:20:25 --> Database Driver Class Initialized
INFO - 2022-07-06 05:20:25 --> Email Class Initialized
DEBUG - 2022-07-06 05:20:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 05:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 05:20:25 --> Controller Class Initialized
INFO - 2022-07-06 05:20:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 05:20:25 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 05:20:25 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-06 05:20:25 --> Final output sent to browser
DEBUG - 2022-07-06 05:20:25 --> Total execution time: 0.3078
INFO - 2022-07-06 05:20:26 --> Config Class Initialized
INFO - 2022-07-06 05:20:26 --> Hooks Class Initialized
DEBUG - 2022-07-06 05:20:26 --> UTF-8 Support Enabled
INFO - 2022-07-06 05:20:26 --> Utf8 Class Initialized
INFO - 2022-07-06 05:20:26 --> URI Class Initialized
INFO - 2022-07-06 05:20:26 --> Router Class Initialized
INFO - 2022-07-06 05:20:26 --> Output Class Initialized
INFO - 2022-07-06 05:20:26 --> Security Class Initialized
DEBUG - 2022-07-06 05:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 05:20:26 --> Input Class Initialized
INFO - 2022-07-06 05:20:26 --> Language Class Initialized
INFO - 2022-07-06 05:20:26 --> Loader Class Initialized
INFO - 2022-07-06 05:20:26 --> Helper loaded: url_helper
INFO - 2022-07-06 05:20:26 --> Helper loaded: file_helper
INFO - 2022-07-06 05:20:26 --> Database Driver Class Initialized
INFO - 2022-07-06 05:20:26 --> Email Class Initialized
DEBUG - 2022-07-06 05:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 05:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 05:20:26 --> Controller Class Initialized
INFO - 2022-07-06 05:20:26 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 05:20:26 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 05:20:26 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-06 05:20:26 --> Final output sent to browser
DEBUG - 2022-07-06 05:20:26 --> Total execution time: 0.1802
INFO - 2022-07-06 05:20:28 --> Config Class Initialized
INFO - 2022-07-06 05:20:28 --> Hooks Class Initialized
DEBUG - 2022-07-06 05:20:28 --> UTF-8 Support Enabled
INFO - 2022-07-06 05:20:28 --> Utf8 Class Initialized
INFO - 2022-07-06 05:20:28 --> URI Class Initialized
INFO - 2022-07-06 05:20:28 --> Router Class Initialized
INFO - 2022-07-06 05:20:28 --> Output Class Initialized
INFO - 2022-07-06 05:20:28 --> Security Class Initialized
DEBUG - 2022-07-06 05:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 05:20:28 --> Input Class Initialized
INFO - 2022-07-06 05:20:28 --> Language Class Initialized
INFO - 2022-07-06 05:20:28 --> Loader Class Initialized
INFO - 2022-07-06 05:20:28 --> Helper loaded: url_helper
INFO - 2022-07-06 05:20:28 --> Helper loaded: file_helper
INFO - 2022-07-06 05:20:28 --> Database Driver Class Initialized
INFO - 2022-07-06 05:20:28 --> Email Class Initialized
DEBUG - 2022-07-06 05:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 05:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 05:20:28 --> Controller Class Initialized
INFO - 2022-07-06 05:20:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 05:20:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 05:20:28 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails_1.php
INFO - 2022-07-06 05:20:28 --> Final output sent to browser
DEBUG - 2022-07-06 05:20:28 --> Total execution time: 0.0423
INFO - 2022-07-06 05:20:28 --> Config Class Initialized
INFO - 2022-07-06 05:20:28 --> Hooks Class Initialized
DEBUG - 2022-07-06 05:20:28 --> UTF-8 Support Enabled
INFO - 2022-07-06 05:20:28 --> Utf8 Class Initialized
INFO - 2022-07-06 05:20:28 --> URI Class Initialized
INFO - 2022-07-06 05:20:28 --> Router Class Initialized
INFO - 2022-07-06 05:20:28 --> Output Class Initialized
INFO - 2022-07-06 05:20:28 --> Security Class Initialized
DEBUG - 2022-07-06 05:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 05:20:28 --> Input Class Initialized
INFO - 2022-07-06 05:20:28 --> Language Class Initialized
INFO - 2022-07-06 05:20:28 --> Loader Class Initialized
INFO - 2022-07-06 05:20:28 --> Helper loaded: url_helper
INFO - 2022-07-06 05:20:28 --> Helper loaded: file_helper
INFO - 2022-07-06 05:20:28 --> Database Driver Class Initialized
INFO - 2022-07-06 05:20:28 --> Email Class Initialized
DEBUG - 2022-07-06 05:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 05:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 05:20:28 --> Controller Class Initialized
INFO - 2022-07-06 05:20:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 05:20:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 05:20:28 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails_1.php
INFO - 2022-07-06 05:20:28 --> Final output sent to browser
DEBUG - 2022-07-06 05:20:28 --> Total execution time: 0.0505
INFO - 2022-07-06 05:20:37 --> Config Class Initialized
INFO - 2022-07-06 05:20:37 --> Hooks Class Initialized
DEBUG - 2022-07-06 05:20:37 --> UTF-8 Support Enabled
INFO - 2022-07-06 05:20:37 --> Utf8 Class Initialized
INFO - 2022-07-06 05:20:37 --> URI Class Initialized
INFO - 2022-07-06 05:20:37 --> Router Class Initialized
INFO - 2022-07-06 05:20:37 --> Output Class Initialized
INFO - 2022-07-06 05:20:37 --> Security Class Initialized
DEBUG - 2022-07-06 05:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 05:20:37 --> Input Class Initialized
INFO - 2022-07-06 05:20:37 --> Language Class Initialized
INFO - 2022-07-06 05:20:37 --> Loader Class Initialized
INFO - 2022-07-06 05:20:37 --> Helper loaded: url_helper
INFO - 2022-07-06 05:20:37 --> Helper loaded: file_helper
INFO - 2022-07-06 05:20:37 --> Database Driver Class Initialized
INFO - 2022-07-06 05:20:37 --> Email Class Initialized
DEBUG - 2022-07-06 05:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 05:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 05:20:37 --> Controller Class Initialized
INFO - 2022-07-06 05:20:37 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 05:20:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 05:20:37 --> test
INFO - 2022-07-06 05:20:38 --> Final output sent to browser
DEBUG - 2022-07-06 05:20:38 --> Total execution time: 0.5147
INFO - 2022-07-06 05:20:38 --> Config Class Initialized
INFO - 2022-07-06 05:20:38 --> Hooks Class Initialized
DEBUG - 2022-07-06 05:20:38 --> UTF-8 Support Enabled
INFO - 2022-07-06 05:20:38 --> Utf8 Class Initialized
INFO - 2022-07-06 05:20:38 --> URI Class Initialized
INFO - 2022-07-06 05:20:38 --> Router Class Initialized
INFO - 2022-07-06 05:20:38 --> Output Class Initialized
INFO - 2022-07-06 05:20:38 --> Security Class Initialized
DEBUG - 2022-07-06 05:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 05:20:38 --> Input Class Initialized
INFO - 2022-07-06 05:20:38 --> Language Class Initialized
INFO - 2022-07-06 05:20:38 --> Loader Class Initialized
INFO - 2022-07-06 05:20:38 --> Helper loaded: url_helper
INFO - 2022-07-06 05:20:38 --> Helper loaded: file_helper
INFO - 2022-07-06 05:20:38 --> Database Driver Class Initialized
INFO - 2022-07-06 05:20:38 --> Email Class Initialized
DEBUG - 2022-07-06 05:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 05:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 05:20:38 --> Controller Class Initialized
INFO - 2022-07-06 05:20:38 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 05:20:38 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 05:20:38 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-07-06 05:20:38 --> Final output sent to browser
DEBUG - 2022-07-06 05:20:38 --> Total execution time: 0.0501
INFO - 2022-07-06 05:38:43 --> Config Class Initialized
INFO - 2022-07-06 05:38:43 --> Hooks Class Initialized
DEBUG - 2022-07-06 05:38:43 --> UTF-8 Support Enabled
INFO - 2022-07-06 05:38:43 --> Utf8 Class Initialized
INFO - 2022-07-06 05:38:43 --> URI Class Initialized
INFO - 2022-07-06 05:38:43 --> Router Class Initialized
INFO - 2022-07-06 05:38:43 --> Output Class Initialized
INFO - 2022-07-06 05:38:43 --> Security Class Initialized
DEBUG - 2022-07-06 05:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 05:38:43 --> Input Class Initialized
INFO - 2022-07-06 05:38:43 --> Language Class Initialized
INFO - 2022-07-06 05:38:43 --> Loader Class Initialized
INFO - 2022-07-06 05:38:43 --> Helper loaded: url_helper
INFO - 2022-07-06 05:38:43 --> Helper loaded: file_helper
INFO - 2022-07-06 05:38:43 --> Database Driver Class Initialized
INFO - 2022-07-06 05:38:44 --> Email Class Initialized
DEBUG - 2022-07-06 05:38:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 05:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 05:38:44 --> Controller Class Initialized
INFO - 2022-07-06 05:38:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 05:38:44 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 05:38:44 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-06 05:38:44 --> Final output sent to browser
DEBUG - 2022-07-06 05:38:44 --> Total execution time: 0.1964
INFO - 2022-07-06 05:40:22 --> Config Class Initialized
INFO - 2022-07-06 05:40:22 --> Hooks Class Initialized
DEBUG - 2022-07-06 05:40:22 --> UTF-8 Support Enabled
INFO - 2022-07-06 05:40:22 --> Utf8 Class Initialized
INFO - 2022-07-06 05:40:22 --> URI Class Initialized
INFO - 2022-07-06 05:40:22 --> Router Class Initialized
INFO - 2022-07-06 05:40:22 --> Output Class Initialized
INFO - 2022-07-06 05:40:22 --> Security Class Initialized
DEBUG - 2022-07-06 05:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 05:40:22 --> Input Class Initialized
INFO - 2022-07-06 05:40:22 --> Language Class Initialized
INFO - 2022-07-06 05:40:22 --> Loader Class Initialized
INFO - 2022-07-06 05:40:22 --> Helper loaded: url_helper
INFO - 2022-07-06 05:40:22 --> Helper loaded: file_helper
INFO - 2022-07-06 05:40:22 --> Database Driver Class Initialized
INFO - 2022-07-06 05:40:22 --> Email Class Initialized
DEBUG - 2022-07-06 05:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 05:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 05:40:22 --> Controller Class Initialized
INFO - 2022-07-06 05:40:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 05:40:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 05:40:22 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-06 05:40:22 --> Final output sent to browser
DEBUG - 2022-07-06 05:40:22 --> Total execution time: 0.1162
INFO - 2022-07-06 05:41:45 --> Config Class Initialized
INFO - 2022-07-06 05:41:45 --> Hooks Class Initialized
DEBUG - 2022-07-06 05:41:45 --> UTF-8 Support Enabled
INFO - 2022-07-06 05:41:45 --> Utf8 Class Initialized
INFO - 2022-07-06 05:41:45 --> URI Class Initialized
INFO - 2022-07-06 05:41:45 --> Router Class Initialized
INFO - 2022-07-06 05:41:45 --> Output Class Initialized
INFO - 2022-07-06 05:41:45 --> Security Class Initialized
DEBUG - 2022-07-06 05:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 05:41:45 --> Input Class Initialized
INFO - 2022-07-06 05:41:45 --> Language Class Initialized
INFO - 2022-07-06 05:41:45 --> Loader Class Initialized
INFO - 2022-07-06 05:41:45 --> Helper loaded: url_helper
INFO - 2022-07-06 05:41:45 --> Helper loaded: file_helper
INFO - 2022-07-06 05:41:45 --> Database Driver Class Initialized
INFO - 2022-07-06 05:41:45 --> Email Class Initialized
DEBUG - 2022-07-06 05:41:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 05:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 05:41:45 --> Controller Class Initialized
INFO - 2022-07-06 05:41:45 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 05:41:45 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 05:41:45 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-06 05:41:45 --> Final output sent to browser
DEBUG - 2022-07-06 05:41:45 --> Total execution time: 0.0826
INFO - 2022-07-06 05:42:37 --> Config Class Initialized
INFO - 2022-07-06 05:42:37 --> Hooks Class Initialized
DEBUG - 2022-07-06 05:42:37 --> UTF-8 Support Enabled
INFO - 2022-07-06 05:42:37 --> Utf8 Class Initialized
INFO - 2022-07-06 05:42:37 --> URI Class Initialized
INFO - 2022-07-06 05:42:37 --> Router Class Initialized
INFO - 2022-07-06 05:42:37 --> Output Class Initialized
INFO - 2022-07-06 05:42:37 --> Security Class Initialized
DEBUG - 2022-07-06 05:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 05:42:37 --> Input Class Initialized
INFO - 2022-07-06 05:42:37 --> Language Class Initialized
INFO - 2022-07-06 05:42:37 --> Loader Class Initialized
INFO - 2022-07-06 05:42:37 --> Helper loaded: url_helper
INFO - 2022-07-06 05:42:37 --> Helper loaded: file_helper
INFO - 2022-07-06 05:42:37 --> Database Driver Class Initialized
INFO - 2022-07-06 05:42:37 --> Email Class Initialized
DEBUG - 2022-07-06 05:42:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 05:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 05:42:37 --> Controller Class Initialized
INFO - 2022-07-06 05:42:37 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 05:42:37 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 05:42:37 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-06 05:42:37 --> Final output sent to browser
DEBUG - 2022-07-06 05:42:37 --> Total execution time: 0.1791
INFO - 2022-07-06 05:43:43 --> Config Class Initialized
INFO - 2022-07-06 05:43:43 --> Hooks Class Initialized
DEBUG - 2022-07-06 05:43:43 --> UTF-8 Support Enabled
INFO - 2022-07-06 05:43:43 --> Utf8 Class Initialized
INFO - 2022-07-06 05:43:43 --> URI Class Initialized
INFO - 2022-07-06 05:43:43 --> Router Class Initialized
INFO - 2022-07-06 05:43:43 --> Output Class Initialized
INFO - 2022-07-06 05:43:43 --> Security Class Initialized
DEBUG - 2022-07-06 05:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 05:43:43 --> Input Class Initialized
INFO - 2022-07-06 05:43:43 --> Language Class Initialized
INFO - 2022-07-06 05:43:43 --> Loader Class Initialized
INFO - 2022-07-06 05:43:43 --> Helper loaded: url_helper
INFO - 2022-07-06 05:43:43 --> Helper loaded: file_helper
INFO - 2022-07-06 05:43:43 --> Database Driver Class Initialized
INFO - 2022-07-06 05:43:43 --> Email Class Initialized
DEBUG - 2022-07-06 05:43:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 05:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 05:43:43 --> Controller Class Initialized
INFO - 2022-07-06 05:43:43 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 05:43:43 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 05:43:43 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-06 05:43:43 --> Final output sent to browser
DEBUG - 2022-07-06 05:43:43 --> Total execution time: 0.1361
INFO - 2022-07-06 05:44:50 --> Config Class Initialized
INFO - 2022-07-06 05:44:50 --> Hooks Class Initialized
DEBUG - 2022-07-06 05:44:50 --> UTF-8 Support Enabled
INFO - 2022-07-06 05:44:50 --> Utf8 Class Initialized
INFO - 2022-07-06 05:44:50 --> URI Class Initialized
INFO - 2022-07-06 05:44:50 --> Router Class Initialized
INFO - 2022-07-06 05:44:50 --> Output Class Initialized
INFO - 2022-07-06 05:44:50 --> Security Class Initialized
DEBUG - 2022-07-06 05:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 05:44:50 --> Input Class Initialized
INFO - 2022-07-06 05:44:50 --> Language Class Initialized
INFO - 2022-07-06 05:44:50 --> Loader Class Initialized
INFO - 2022-07-06 05:44:50 --> Helper loaded: url_helper
INFO - 2022-07-06 05:44:50 --> Helper loaded: file_helper
INFO - 2022-07-06 05:44:50 --> Database Driver Class Initialized
INFO - 2022-07-06 05:44:50 --> Email Class Initialized
DEBUG - 2022-07-06 05:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 05:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 05:44:50 --> Controller Class Initialized
INFO - 2022-07-06 05:44:50 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 05:44:50 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 05:44:50 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-06 05:44:50 --> Final output sent to browser
DEBUG - 2022-07-06 05:44:50 --> Total execution time: 0.1541
INFO - 2022-07-06 05:46:31 --> Config Class Initialized
INFO - 2022-07-06 05:46:31 --> Hooks Class Initialized
DEBUG - 2022-07-06 05:46:31 --> UTF-8 Support Enabled
INFO - 2022-07-06 05:46:31 --> Utf8 Class Initialized
INFO - 2022-07-06 05:46:31 --> URI Class Initialized
INFO - 2022-07-06 05:46:31 --> Router Class Initialized
INFO - 2022-07-06 05:46:31 --> Output Class Initialized
INFO - 2022-07-06 05:46:31 --> Security Class Initialized
DEBUG - 2022-07-06 05:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 05:46:31 --> Input Class Initialized
INFO - 2022-07-06 05:46:31 --> Language Class Initialized
INFO - 2022-07-06 05:46:31 --> Loader Class Initialized
INFO - 2022-07-06 05:46:31 --> Helper loaded: url_helper
INFO - 2022-07-06 05:46:31 --> Helper loaded: file_helper
INFO - 2022-07-06 05:46:31 --> Database Driver Class Initialized
INFO - 2022-07-06 05:46:31 --> Email Class Initialized
DEBUG - 2022-07-06 05:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 05:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 05:46:31 --> Controller Class Initialized
INFO - 2022-07-06 05:46:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 05:46:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 05:46:31 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-06 05:46:31 --> Final output sent to browser
DEBUG - 2022-07-06 05:46:31 --> Total execution time: 0.0381
INFO - 2022-07-06 05:49:41 --> Config Class Initialized
INFO - 2022-07-06 05:49:41 --> Hooks Class Initialized
DEBUG - 2022-07-06 05:49:41 --> UTF-8 Support Enabled
INFO - 2022-07-06 05:49:41 --> Utf8 Class Initialized
INFO - 2022-07-06 05:49:41 --> URI Class Initialized
INFO - 2022-07-06 05:49:41 --> Router Class Initialized
INFO - 2022-07-06 05:49:41 --> Output Class Initialized
INFO - 2022-07-06 05:49:41 --> Security Class Initialized
DEBUG - 2022-07-06 05:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 05:49:41 --> Input Class Initialized
INFO - 2022-07-06 05:49:41 --> Language Class Initialized
INFO - 2022-07-06 05:49:41 --> Loader Class Initialized
INFO - 2022-07-06 05:49:41 --> Helper loaded: url_helper
INFO - 2022-07-06 05:49:41 --> Helper loaded: file_helper
INFO - 2022-07-06 05:49:41 --> Database Driver Class Initialized
INFO - 2022-07-06 05:49:41 --> Email Class Initialized
DEBUG - 2022-07-06 05:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 05:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 05:49:41 --> Controller Class Initialized
INFO - 2022-07-06 05:49:41 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 05:49:41 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 05:49:41 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-06 05:49:41 --> Final output sent to browser
DEBUG - 2022-07-06 05:49:41 --> Total execution time: 0.1270
INFO - 2022-07-06 05:50:35 --> Config Class Initialized
INFO - 2022-07-06 05:50:35 --> Hooks Class Initialized
DEBUG - 2022-07-06 05:50:35 --> UTF-8 Support Enabled
INFO - 2022-07-06 05:50:35 --> Utf8 Class Initialized
INFO - 2022-07-06 05:50:35 --> URI Class Initialized
INFO - 2022-07-06 05:50:35 --> Router Class Initialized
INFO - 2022-07-06 05:50:35 --> Output Class Initialized
INFO - 2022-07-06 05:50:35 --> Security Class Initialized
DEBUG - 2022-07-06 05:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 05:50:35 --> Input Class Initialized
INFO - 2022-07-06 05:50:35 --> Language Class Initialized
INFO - 2022-07-06 05:50:35 --> Loader Class Initialized
INFO - 2022-07-06 05:50:35 --> Helper loaded: url_helper
INFO - 2022-07-06 05:50:35 --> Helper loaded: file_helper
INFO - 2022-07-06 05:50:35 --> Database Driver Class Initialized
INFO - 2022-07-06 05:50:35 --> Email Class Initialized
DEBUG - 2022-07-06 05:50:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 05:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 05:50:35 --> Controller Class Initialized
INFO - 2022-07-06 05:50:35 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 05:50:35 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 05:50:35 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-06 05:50:35 --> Final output sent to browser
DEBUG - 2022-07-06 05:50:35 --> Total execution time: 0.1696
INFO - 2022-07-06 05:52:46 --> Config Class Initialized
INFO - 2022-07-06 05:52:46 --> Hooks Class Initialized
DEBUG - 2022-07-06 05:52:46 --> UTF-8 Support Enabled
INFO - 2022-07-06 05:52:46 --> Utf8 Class Initialized
INFO - 2022-07-06 05:52:46 --> URI Class Initialized
INFO - 2022-07-06 05:52:46 --> Router Class Initialized
INFO - 2022-07-06 05:52:46 --> Output Class Initialized
INFO - 2022-07-06 05:52:46 --> Security Class Initialized
DEBUG - 2022-07-06 05:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 05:52:46 --> Input Class Initialized
INFO - 2022-07-06 05:52:46 --> Language Class Initialized
INFO - 2022-07-06 05:52:46 --> Loader Class Initialized
INFO - 2022-07-06 05:52:46 --> Helper loaded: url_helper
INFO - 2022-07-06 05:52:46 --> Helper loaded: file_helper
INFO - 2022-07-06 05:52:46 --> Database Driver Class Initialized
INFO - 2022-07-06 05:52:46 --> Email Class Initialized
DEBUG - 2022-07-06 05:52:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 05:52:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 05:52:46 --> Controller Class Initialized
INFO - 2022-07-06 05:52:46 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 05:52:46 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 05:52:46 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-06 05:52:46 --> Final output sent to browser
DEBUG - 2022-07-06 05:52:46 --> Total execution time: 0.0518
INFO - 2022-07-06 05:53:15 --> Config Class Initialized
INFO - 2022-07-06 05:53:15 --> Hooks Class Initialized
DEBUG - 2022-07-06 05:53:15 --> UTF-8 Support Enabled
INFO - 2022-07-06 05:53:15 --> Utf8 Class Initialized
INFO - 2022-07-06 05:53:15 --> URI Class Initialized
INFO - 2022-07-06 05:53:15 --> Router Class Initialized
INFO - 2022-07-06 05:53:15 --> Output Class Initialized
INFO - 2022-07-06 05:53:15 --> Security Class Initialized
DEBUG - 2022-07-06 05:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 05:53:15 --> Input Class Initialized
INFO - 2022-07-06 05:53:15 --> Language Class Initialized
INFO - 2022-07-06 05:53:15 --> Loader Class Initialized
INFO - 2022-07-06 05:53:15 --> Helper loaded: url_helper
INFO - 2022-07-06 05:53:15 --> Helper loaded: file_helper
INFO - 2022-07-06 05:53:15 --> Database Driver Class Initialized
INFO - 2022-07-06 05:53:15 --> Email Class Initialized
DEBUG - 2022-07-06 05:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 05:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 05:53:15 --> Controller Class Initialized
INFO - 2022-07-06 05:53:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 05:53:15 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 05:53:15 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-06 05:53:15 --> Final output sent to browser
DEBUG - 2022-07-06 05:53:15 --> Total execution time: 0.1357
INFO - 2022-07-06 05:55:08 --> Config Class Initialized
INFO - 2022-07-06 05:55:08 --> Hooks Class Initialized
DEBUG - 2022-07-06 05:55:08 --> UTF-8 Support Enabled
INFO - 2022-07-06 05:55:08 --> Utf8 Class Initialized
INFO - 2022-07-06 05:55:08 --> URI Class Initialized
INFO - 2022-07-06 05:55:08 --> Router Class Initialized
INFO - 2022-07-06 05:55:08 --> Output Class Initialized
INFO - 2022-07-06 05:55:08 --> Security Class Initialized
DEBUG - 2022-07-06 05:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 05:55:08 --> Input Class Initialized
INFO - 2022-07-06 05:55:08 --> Language Class Initialized
INFO - 2022-07-06 05:55:08 --> Loader Class Initialized
INFO - 2022-07-06 05:55:08 --> Helper loaded: url_helper
INFO - 2022-07-06 05:55:08 --> Helper loaded: file_helper
INFO - 2022-07-06 05:55:08 --> Database Driver Class Initialized
INFO - 2022-07-06 05:55:08 --> Email Class Initialized
DEBUG - 2022-07-06 05:55:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 05:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 05:55:08 --> Controller Class Initialized
INFO - 2022-07-06 05:55:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 05:55:08 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 05:55:08 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-06 05:55:08 --> Final output sent to browser
DEBUG - 2022-07-06 05:55:08 --> Total execution time: 0.1440
INFO - 2022-07-06 05:55:56 --> Config Class Initialized
INFO - 2022-07-06 05:55:56 --> Hooks Class Initialized
DEBUG - 2022-07-06 05:55:56 --> UTF-8 Support Enabled
INFO - 2022-07-06 05:55:56 --> Utf8 Class Initialized
INFO - 2022-07-06 05:55:56 --> URI Class Initialized
INFO - 2022-07-06 05:55:56 --> Router Class Initialized
INFO - 2022-07-06 05:55:56 --> Output Class Initialized
INFO - 2022-07-06 05:55:56 --> Security Class Initialized
DEBUG - 2022-07-06 05:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 05:55:56 --> Input Class Initialized
INFO - 2022-07-06 05:55:56 --> Language Class Initialized
INFO - 2022-07-06 05:55:56 --> Loader Class Initialized
INFO - 2022-07-06 05:55:56 --> Helper loaded: url_helper
INFO - 2022-07-06 05:55:56 --> Helper loaded: file_helper
INFO - 2022-07-06 05:55:56 --> Database Driver Class Initialized
INFO - 2022-07-06 05:55:56 --> Email Class Initialized
DEBUG - 2022-07-06 05:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 05:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 05:55:56 --> Controller Class Initialized
INFO - 2022-07-06 05:55:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 05:55:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 05:55:56 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-06 05:55:56 --> Final output sent to browser
DEBUG - 2022-07-06 05:55:56 --> Total execution time: 0.0315
INFO - 2022-07-06 05:58:08 --> Config Class Initialized
INFO - 2022-07-06 05:58:08 --> Hooks Class Initialized
DEBUG - 2022-07-06 05:58:08 --> UTF-8 Support Enabled
INFO - 2022-07-06 05:58:08 --> Utf8 Class Initialized
INFO - 2022-07-06 05:58:08 --> URI Class Initialized
INFO - 2022-07-06 05:58:08 --> Router Class Initialized
INFO - 2022-07-06 05:58:08 --> Output Class Initialized
INFO - 2022-07-06 05:58:08 --> Security Class Initialized
DEBUG - 2022-07-06 05:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 05:58:08 --> Input Class Initialized
INFO - 2022-07-06 05:58:08 --> Language Class Initialized
INFO - 2022-07-06 05:58:08 --> Loader Class Initialized
INFO - 2022-07-06 05:58:08 --> Helper loaded: url_helper
INFO - 2022-07-06 05:58:08 --> Helper loaded: file_helper
INFO - 2022-07-06 05:58:08 --> Database Driver Class Initialized
INFO - 2022-07-06 05:58:08 --> Email Class Initialized
DEBUG - 2022-07-06 05:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 05:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 05:58:08 --> Controller Class Initialized
INFO - 2022-07-06 05:58:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 05:58:08 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 05:58:08 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-06 05:58:08 --> Final output sent to browser
DEBUG - 2022-07-06 05:58:08 --> Total execution time: 0.1328
INFO - 2022-07-06 06:02:43 --> Config Class Initialized
INFO - 2022-07-06 06:02:43 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:02:43 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:02:43 --> Utf8 Class Initialized
INFO - 2022-07-06 06:02:43 --> URI Class Initialized
INFO - 2022-07-06 06:02:43 --> Router Class Initialized
INFO - 2022-07-06 06:02:43 --> Output Class Initialized
INFO - 2022-07-06 06:02:43 --> Security Class Initialized
DEBUG - 2022-07-06 06:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:02:43 --> Input Class Initialized
INFO - 2022-07-06 06:02:43 --> Language Class Initialized
INFO - 2022-07-06 06:02:43 --> Loader Class Initialized
INFO - 2022-07-06 06:02:43 --> Helper loaded: url_helper
INFO - 2022-07-06 06:02:43 --> Helper loaded: file_helper
INFO - 2022-07-06 06:02:43 --> Database Driver Class Initialized
INFO - 2022-07-06 06:02:43 --> Email Class Initialized
DEBUG - 2022-07-06 06:02:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:02:43 --> Controller Class Initialized
INFO - 2022-07-06 06:02:43 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:02:43 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:02:43 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-06 06:02:43 --> Final output sent to browser
DEBUG - 2022-07-06 06:02:43 --> Total execution time: 0.0231
INFO - 2022-07-06 06:04:40 --> Config Class Initialized
INFO - 2022-07-06 06:04:40 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:04:40 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:04:40 --> Utf8 Class Initialized
INFO - 2022-07-06 06:04:40 --> URI Class Initialized
INFO - 2022-07-06 06:04:40 --> Router Class Initialized
INFO - 2022-07-06 06:04:40 --> Output Class Initialized
INFO - 2022-07-06 06:04:40 --> Security Class Initialized
DEBUG - 2022-07-06 06:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:04:40 --> Input Class Initialized
INFO - 2022-07-06 06:04:40 --> Language Class Initialized
INFO - 2022-07-06 06:04:40 --> Loader Class Initialized
INFO - 2022-07-06 06:04:40 --> Helper loaded: url_helper
INFO - 2022-07-06 06:04:40 --> Helper loaded: file_helper
INFO - 2022-07-06 06:04:40 --> Database Driver Class Initialized
INFO - 2022-07-06 06:04:40 --> Email Class Initialized
DEBUG - 2022-07-06 06:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:04:40 --> Controller Class Initialized
INFO - 2022-07-06 06:04:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:04:40 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:04:40 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-06 06:04:40 --> Final output sent to browser
DEBUG - 2022-07-06 06:04:40 --> Total execution time: 0.0694
INFO - 2022-07-06 06:04:54 --> Config Class Initialized
INFO - 2022-07-06 06:04:54 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:04:54 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:04:54 --> Utf8 Class Initialized
INFO - 2022-07-06 06:04:54 --> URI Class Initialized
INFO - 2022-07-06 06:04:54 --> Router Class Initialized
INFO - 2022-07-06 06:04:54 --> Output Class Initialized
INFO - 2022-07-06 06:04:54 --> Security Class Initialized
DEBUG - 2022-07-06 06:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:04:54 --> Input Class Initialized
INFO - 2022-07-06 06:04:54 --> Language Class Initialized
INFO - 2022-07-06 06:04:54 --> Loader Class Initialized
INFO - 2022-07-06 06:04:54 --> Helper loaded: url_helper
INFO - 2022-07-06 06:04:54 --> Helper loaded: file_helper
INFO - 2022-07-06 06:04:54 --> Database Driver Class Initialized
INFO - 2022-07-06 06:04:54 --> Email Class Initialized
DEBUG - 2022-07-06 06:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:04:54 --> Controller Class Initialized
INFO - 2022-07-06 06:04:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:04:54 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:05:01 --> Config Class Initialized
INFO - 2022-07-06 06:05:01 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:05:01 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:05:01 --> Utf8 Class Initialized
INFO - 2022-07-06 06:05:01 --> URI Class Initialized
INFO - 2022-07-06 06:05:01 --> Router Class Initialized
INFO - 2022-07-06 06:05:01 --> Output Class Initialized
INFO - 2022-07-06 06:05:01 --> Security Class Initialized
DEBUG - 2022-07-06 06:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:05:01 --> Input Class Initialized
INFO - 2022-07-06 06:05:01 --> Language Class Initialized
INFO - 2022-07-06 06:05:01 --> Loader Class Initialized
INFO - 2022-07-06 06:05:01 --> Helper loaded: url_helper
INFO - 2022-07-06 06:05:01 --> Helper loaded: file_helper
INFO - 2022-07-06 06:05:01 --> Database Driver Class Initialized
INFO - 2022-07-06 06:05:01 --> Email Class Initialized
DEBUG - 2022-07-06 06:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:05:01 --> Controller Class Initialized
INFO - 2022-07-06 06:05:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:05:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:05:01 --> Final output sent to browser
DEBUG - 2022-07-06 06:05:01 --> Total execution time: 0.1275
INFO - 2022-07-06 06:05:01 --> Config Class Initialized
INFO - 2022-07-06 06:05:01 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:05:01 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:05:01 --> Utf8 Class Initialized
INFO - 2022-07-06 06:05:01 --> URI Class Initialized
INFO - 2022-07-06 06:05:01 --> Router Class Initialized
INFO - 2022-07-06 06:05:01 --> Output Class Initialized
INFO - 2022-07-06 06:05:01 --> Security Class Initialized
DEBUG - 2022-07-06 06:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:05:01 --> Input Class Initialized
INFO - 2022-07-06 06:05:01 --> Language Class Initialized
INFO - 2022-07-06 06:05:01 --> Loader Class Initialized
INFO - 2022-07-06 06:05:01 --> Helper loaded: url_helper
INFO - 2022-07-06 06:05:01 --> Helper loaded: file_helper
INFO - 2022-07-06 06:05:01 --> Database Driver Class Initialized
INFO - 2022-07-06 06:05:01 --> Email Class Initialized
DEBUG - 2022-07-06 06:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:05:01 --> Controller Class Initialized
INFO - 2022-07-06 06:05:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:05:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:05:01 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-06 06:05:01 --> Final output sent to browser
DEBUG - 2022-07-06 06:05:01 --> Total execution time: 0.0611
INFO - 2022-07-06 06:05:04 --> Config Class Initialized
INFO - 2022-07-06 06:05:04 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:05:04 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:05:04 --> Utf8 Class Initialized
INFO - 2022-07-06 06:05:04 --> URI Class Initialized
INFO - 2022-07-06 06:05:04 --> Router Class Initialized
INFO - 2022-07-06 06:05:04 --> Output Class Initialized
INFO - 2022-07-06 06:05:04 --> Security Class Initialized
DEBUG - 2022-07-06 06:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:05:04 --> Input Class Initialized
INFO - 2022-07-06 06:05:04 --> Language Class Initialized
INFO - 2022-07-06 06:05:04 --> Loader Class Initialized
INFO - 2022-07-06 06:05:04 --> Helper loaded: url_helper
INFO - 2022-07-06 06:05:04 --> Helper loaded: file_helper
INFO - 2022-07-06 06:05:04 --> Database Driver Class Initialized
INFO - 2022-07-06 06:05:04 --> Email Class Initialized
DEBUG - 2022-07-06 06:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:05:04 --> Controller Class Initialized
INFO - 2022-07-06 06:05:04 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:05:04 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:05:04 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-06 06:05:04 --> Final output sent to browser
DEBUG - 2022-07-06 06:05:04 --> Total execution time: 0.0416
INFO - 2022-07-06 06:08:30 --> Config Class Initialized
INFO - 2022-07-06 06:08:30 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:08:30 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:08:30 --> Utf8 Class Initialized
INFO - 2022-07-06 06:08:30 --> URI Class Initialized
INFO - 2022-07-06 06:08:30 --> Router Class Initialized
INFO - 2022-07-06 06:08:30 --> Output Class Initialized
INFO - 2022-07-06 06:08:30 --> Security Class Initialized
DEBUG - 2022-07-06 06:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:08:30 --> Input Class Initialized
INFO - 2022-07-06 06:08:30 --> Language Class Initialized
INFO - 2022-07-06 06:08:30 --> Loader Class Initialized
INFO - 2022-07-06 06:08:30 --> Helper loaded: url_helper
INFO - 2022-07-06 06:08:30 --> Helper loaded: file_helper
INFO - 2022-07-06 06:08:30 --> Database Driver Class Initialized
INFO - 2022-07-06 06:08:30 --> Email Class Initialized
DEBUG - 2022-07-06 06:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:08:30 --> Controller Class Initialized
INFO - 2022-07-06 06:08:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:08:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:08:30 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails_1.php
INFO - 2022-07-06 06:08:30 --> Final output sent to browser
DEBUG - 2022-07-06 06:08:30 --> Total execution time: 0.0253
INFO - 2022-07-06 06:08:30 --> Config Class Initialized
INFO - 2022-07-06 06:08:30 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:08:30 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:08:30 --> Utf8 Class Initialized
INFO - 2022-07-06 06:08:30 --> URI Class Initialized
INFO - 2022-07-06 06:08:30 --> Router Class Initialized
INFO - 2022-07-06 06:08:30 --> Output Class Initialized
INFO - 2022-07-06 06:08:30 --> Security Class Initialized
DEBUG - 2022-07-06 06:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:08:30 --> Input Class Initialized
INFO - 2022-07-06 06:08:30 --> Language Class Initialized
INFO - 2022-07-06 06:08:30 --> Loader Class Initialized
INFO - 2022-07-06 06:08:30 --> Helper loaded: url_helper
INFO - 2022-07-06 06:08:30 --> Helper loaded: file_helper
INFO - 2022-07-06 06:08:30 --> Database Driver Class Initialized
INFO - 2022-07-06 06:08:31 --> Email Class Initialized
DEBUG - 2022-07-06 06:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:08:31 --> Controller Class Initialized
INFO - 2022-07-06 06:08:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:08:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:08:31 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails_1.php
INFO - 2022-07-06 06:08:31 --> Final output sent to browser
DEBUG - 2022-07-06 06:08:31 --> Total execution time: 0.1471
INFO - 2022-07-06 06:08:36 --> Config Class Initialized
INFO - 2022-07-06 06:08:36 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:08:36 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:08:36 --> Utf8 Class Initialized
INFO - 2022-07-06 06:08:36 --> URI Class Initialized
INFO - 2022-07-06 06:08:36 --> Router Class Initialized
INFO - 2022-07-06 06:08:36 --> Output Class Initialized
INFO - 2022-07-06 06:08:36 --> Security Class Initialized
DEBUG - 2022-07-06 06:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:08:36 --> Input Class Initialized
INFO - 2022-07-06 06:08:36 --> Language Class Initialized
INFO - 2022-07-06 06:08:36 --> Loader Class Initialized
INFO - 2022-07-06 06:08:36 --> Helper loaded: url_helper
INFO - 2022-07-06 06:08:36 --> Helper loaded: file_helper
INFO - 2022-07-06 06:08:36 --> Database Driver Class Initialized
INFO - 2022-07-06 06:08:36 --> Email Class Initialized
DEBUG - 2022-07-06 06:08:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:08:36 --> Controller Class Initialized
INFO - 2022-07-06 06:08:36 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:08:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 06:08:36 --> test
INFO - 2022-07-06 06:08:36 --> Final output sent to browser
DEBUG - 2022-07-06 06:08:36 --> Total execution time: 0.1346
INFO - 2022-07-06 06:08:36 --> Config Class Initialized
INFO - 2022-07-06 06:08:36 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:08:36 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:08:36 --> Utf8 Class Initialized
INFO - 2022-07-06 06:08:36 --> URI Class Initialized
INFO - 2022-07-06 06:08:36 --> Router Class Initialized
INFO - 2022-07-06 06:08:36 --> Output Class Initialized
INFO - 2022-07-06 06:08:36 --> Security Class Initialized
DEBUG - 2022-07-06 06:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:08:36 --> Input Class Initialized
INFO - 2022-07-06 06:08:36 --> Language Class Initialized
INFO - 2022-07-06 06:08:36 --> Loader Class Initialized
INFO - 2022-07-06 06:08:36 --> Helper loaded: url_helper
INFO - 2022-07-06 06:08:36 --> Helper loaded: file_helper
INFO - 2022-07-06 06:08:36 --> Database Driver Class Initialized
INFO - 2022-07-06 06:08:36 --> Email Class Initialized
DEBUG - 2022-07-06 06:08:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:08:36 --> Controller Class Initialized
INFO - 2022-07-06 06:08:36 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:08:36 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:08:36 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-06 06:08:36 --> Final output sent to browser
DEBUG - 2022-07-06 06:08:36 --> Total execution time: 0.0460
INFO - 2022-07-06 06:11:25 --> Config Class Initialized
INFO - 2022-07-06 06:11:25 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:11:25 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:11:25 --> Utf8 Class Initialized
INFO - 2022-07-06 06:11:25 --> URI Class Initialized
INFO - 2022-07-06 06:11:25 --> Router Class Initialized
INFO - 2022-07-06 06:11:25 --> Output Class Initialized
INFO - 2022-07-06 06:11:25 --> Security Class Initialized
DEBUG - 2022-07-06 06:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:11:25 --> Input Class Initialized
INFO - 2022-07-06 06:11:25 --> Language Class Initialized
INFO - 2022-07-06 06:11:25 --> Loader Class Initialized
INFO - 2022-07-06 06:11:25 --> Helper loaded: url_helper
INFO - 2022-07-06 06:11:25 --> Helper loaded: file_helper
INFO - 2022-07-06 06:11:25 --> Database Driver Class Initialized
INFO - 2022-07-06 06:11:25 --> Email Class Initialized
DEBUG - 2022-07-06 06:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:11:25 --> Controller Class Initialized
INFO - 2022-07-06 06:11:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:11:25 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:11:25 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails_1.php
INFO - 2022-07-06 06:11:25 --> Final output sent to browser
DEBUG - 2022-07-06 06:11:25 --> Total execution time: 0.1864
INFO - 2022-07-06 06:13:42 --> Config Class Initialized
INFO - 2022-07-06 06:13:42 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:13:42 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:13:42 --> Utf8 Class Initialized
INFO - 2022-07-06 06:13:42 --> URI Class Initialized
INFO - 2022-07-06 06:13:42 --> Router Class Initialized
INFO - 2022-07-06 06:13:42 --> Output Class Initialized
INFO - 2022-07-06 06:13:42 --> Security Class Initialized
DEBUG - 2022-07-06 06:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:13:42 --> Input Class Initialized
INFO - 2022-07-06 06:13:42 --> Language Class Initialized
INFO - 2022-07-06 06:13:42 --> Loader Class Initialized
INFO - 2022-07-06 06:13:42 --> Helper loaded: url_helper
INFO - 2022-07-06 06:13:42 --> Helper loaded: file_helper
INFO - 2022-07-06 06:13:42 --> Database Driver Class Initialized
INFO - 2022-07-06 06:13:42 --> Email Class Initialized
DEBUG - 2022-07-06 06:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:13:42 --> Controller Class Initialized
INFO - 2022-07-06 06:13:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:13:42 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:13:42 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails_1.php
INFO - 2022-07-06 06:13:42 --> Final output sent to browser
DEBUG - 2022-07-06 06:13:42 --> Total execution time: 0.0203
INFO - 2022-07-06 06:32:16 --> Config Class Initialized
INFO - 2022-07-06 06:32:16 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:32:16 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:32:16 --> Utf8 Class Initialized
INFO - 2022-07-06 06:32:16 --> URI Class Initialized
INFO - 2022-07-06 06:32:16 --> Router Class Initialized
INFO - 2022-07-06 06:32:16 --> Output Class Initialized
INFO - 2022-07-06 06:32:16 --> Security Class Initialized
DEBUG - 2022-07-06 06:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:32:16 --> Input Class Initialized
INFO - 2022-07-06 06:32:16 --> Language Class Initialized
INFO - 2022-07-06 06:32:16 --> Loader Class Initialized
INFO - 2022-07-06 06:32:16 --> Helper loaded: url_helper
INFO - 2022-07-06 06:32:16 --> Helper loaded: file_helper
INFO - 2022-07-06 06:32:16 --> Database Driver Class Initialized
INFO - 2022-07-06 06:32:16 --> Email Class Initialized
DEBUG - 2022-07-06 06:32:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:32:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:32:16 --> Controller Class Initialized
INFO - 2022-07-06 06:32:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:32:16 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:32:16 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails_1.php
INFO - 2022-07-06 06:32:16 --> Final output sent to browser
DEBUG - 2022-07-06 06:32:16 --> Total execution time: 0.0504
INFO - 2022-07-06 06:32:27 --> Config Class Initialized
INFO - 2022-07-06 06:32:27 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:32:27 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:32:27 --> Utf8 Class Initialized
INFO - 2022-07-06 06:32:27 --> URI Class Initialized
INFO - 2022-07-06 06:32:27 --> Router Class Initialized
INFO - 2022-07-06 06:32:27 --> Output Class Initialized
INFO - 2022-07-06 06:32:27 --> Security Class Initialized
DEBUG - 2022-07-06 06:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:32:27 --> Input Class Initialized
INFO - 2022-07-06 06:32:27 --> Language Class Initialized
INFO - 2022-07-06 06:32:27 --> Loader Class Initialized
INFO - 2022-07-06 06:32:27 --> Helper loaded: url_helper
INFO - 2022-07-06 06:32:27 --> Helper loaded: file_helper
INFO - 2022-07-06 06:32:27 --> Database Driver Class Initialized
INFO - 2022-07-06 06:32:27 --> Email Class Initialized
DEBUG - 2022-07-06 06:32:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:32:27 --> Controller Class Initialized
INFO - 2022-07-06 06:32:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:32:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 06:32:27 --> test
INFO - 2022-07-06 06:32:27 --> Final output sent to browser
DEBUG - 2022-07-06 06:32:27 --> Total execution time: 0.1558
INFO - 2022-07-06 06:32:27 --> Config Class Initialized
INFO - 2022-07-06 06:32:27 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:32:27 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:32:27 --> Utf8 Class Initialized
INFO - 2022-07-06 06:32:27 --> URI Class Initialized
INFO - 2022-07-06 06:32:27 --> Router Class Initialized
INFO - 2022-07-06 06:32:27 --> Output Class Initialized
INFO - 2022-07-06 06:32:27 --> Security Class Initialized
DEBUG - 2022-07-06 06:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:32:27 --> Input Class Initialized
INFO - 2022-07-06 06:32:27 --> Language Class Initialized
INFO - 2022-07-06 06:32:27 --> Loader Class Initialized
INFO - 2022-07-06 06:32:27 --> Helper loaded: url_helper
INFO - 2022-07-06 06:32:27 --> Helper loaded: file_helper
INFO - 2022-07-06 06:32:27 --> Database Driver Class Initialized
INFO - 2022-07-06 06:32:27 --> Email Class Initialized
DEBUG - 2022-07-06 06:32:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:32:27 --> Controller Class Initialized
INFO - 2022-07-06 06:32:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:32:27 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:32:27 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-06 06:32:27 --> Final output sent to browser
DEBUG - 2022-07-06 06:32:27 --> Total execution time: 0.0425
INFO - 2022-07-06 06:32:36 --> Config Class Initialized
INFO - 2022-07-06 06:32:36 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:32:36 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:32:36 --> Utf8 Class Initialized
INFO - 2022-07-06 06:32:36 --> URI Class Initialized
INFO - 2022-07-06 06:32:36 --> Router Class Initialized
INFO - 2022-07-06 06:32:36 --> Output Class Initialized
INFO - 2022-07-06 06:32:36 --> Security Class Initialized
DEBUG - 2022-07-06 06:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:32:36 --> Input Class Initialized
INFO - 2022-07-06 06:32:36 --> Language Class Initialized
INFO - 2022-07-06 06:32:36 --> Loader Class Initialized
INFO - 2022-07-06 06:32:36 --> Helper loaded: url_helper
INFO - 2022-07-06 06:32:36 --> Helper loaded: file_helper
INFO - 2022-07-06 06:32:36 --> Database Driver Class Initialized
INFO - 2022-07-06 06:32:36 --> Email Class Initialized
DEBUG - 2022-07-06 06:32:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:32:36 --> Controller Class Initialized
INFO - 2022-07-06 06:32:36 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:32:36 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:32:43 --> Config Class Initialized
INFO - 2022-07-06 06:32:43 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:32:43 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:32:43 --> Utf8 Class Initialized
INFO - 2022-07-06 06:32:43 --> URI Class Initialized
INFO - 2022-07-06 06:32:43 --> Router Class Initialized
INFO - 2022-07-06 06:32:43 --> Output Class Initialized
INFO - 2022-07-06 06:32:43 --> Security Class Initialized
DEBUG - 2022-07-06 06:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:32:43 --> Input Class Initialized
INFO - 2022-07-06 06:32:43 --> Language Class Initialized
INFO - 2022-07-06 06:32:43 --> Loader Class Initialized
INFO - 2022-07-06 06:32:43 --> Helper loaded: url_helper
INFO - 2022-07-06 06:32:43 --> Helper loaded: file_helper
INFO - 2022-07-06 06:32:43 --> Database Driver Class Initialized
INFO - 2022-07-06 06:32:44 --> Email Class Initialized
DEBUG - 2022-07-06 06:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:32:44 --> Controller Class Initialized
INFO - 2022-07-06 06:32:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:32:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-06 06:32:44 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\qr\application\models\Tokenmodel.php 182
INFO - 2022-07-06 06:32:44 --> Language file loaded: language/english/db_lang.php
INFO - 2022-07-06 06:32:44 --> Config Class Initialized
INFO - 2022-07-06 06:32:44 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:32:44 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:32:44 --> Utf8 Class Initialized
INFO - 2022-07-06 06:32:44 --> URI Class Initialized
INFO - 2022-07-06 06:32:44 --> Router Class Initialized
INFO - 2022-07-06 06:32:44 --> Output Class Initialized
INFO - 2022-07-06 06:32:44 --> Security Class Initialized
DEBUG - 2022-07-06 06:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:32:44 --> Input Class Initialized
INFO - 2022-07-06 06:32:44 --> Language Class Initialized
INFO - 2022-07-06 06:32:44 --> Loader Class Initialized
INFO - 2022-07-06 06:32:44 --> Helper loaded: url_helper
INFO - 2022-07-06 06:32:44 --> Helper loaded: file_helper
INFO - 2022-07-06 06:32:44 --> Database Driver Class Initialized
INFO - 2022-07-06 06:32:44 --> Email Class Initialized
DEBUG - 2022-07-06 06:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:32:44 --> Controller Class Initialized
INFO - 2022-07-06 06:32:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:32:44 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:32:44 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-06 06:32:44 --> Final output sent to browser
DEBUG - 2022-07-06 06:32:44 --> Total execution time: 0.0757
INFO - 2022-07-06 06:33:13 --> Config Class Initialized
INFO - 2022-07-06 06:33:13 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:33:13 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:33:13 --> Utf8 Class Initialized
INFO - 2022-07-06 06:33:13 --> URI Class Initialized
INFO - 2022-07-06 06:33:13 --> Router Class Initialized
INFO - 2022-07-06 06:33:13 --> Output Class Initialized
INFO - 2022-07-06 06:33:13 --> Security Class Initialized
DEBUG - 2022-07-06 06:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:33:13 --> Input Class Initialized
INFO - 2022-07-06 06:33:13 --> Language Class Initialized
INFO - 2022-07-06 06:33:13 --> Loader Class Initialized
INFO - 2022-07-06 06:33:13 --> Helper loaded: url_helper
INFO - 2022-07-06 06:33:13 --> Helper loaded: file_helper
INFO - 2022-07-06 06:33:13 --> Database Driver Class Initialized
INFO - 2022-07-06 06:33:13 --> Email Class Initialized
DEBUG - 2022-07-06 06:33:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:33:13 --> Controller Class Initialized
INFO - 2022-07-06 06:33:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:33:13 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:33:19 --> Config Class Initialized
INFO - 2022-07-06 06:33:19 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:33:19 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:33:19 --> Utf8 Class Initialized
INFO - 2022-07-06 06:33:19 --> URI Class Initialized
INFO - 2022-07-06 06:33:19 --> Router Class Initialized
INFO - 2022-07-06 06:33:19 --> Output Class Initialized
INFO - 2022-07-06 06:33:19 --> Security Class Initialized
DEBUG - 2022-07-06 06:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:33:19 --> Input Class Initialized
INFO - 2022-07-06 06:33:19 --> Language Class Initialized
INFO - 2022-07-06 06:33:19 --> Loader Class Initialized
INFO - 2022-07-06 06:33:19 --> Helper loaded: url_helper
INFO - 2022-07-06 06:33:19 --> Helper loaded: file_helper
INFO - 2022-07-06 06:33:19 --> Database Driver Class Initialized
INFO - 2022-07-06 06:33:19 --> Config Class Initialized
INFO - 2022-07-06 06:33:19 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:33:19 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:33:19 --> Utf8 Class Initialized
INFO - 2022-07-06 06:33:19 --> URI Class Initialized
INFO - 2022-07-06 06:33:19 --> Router Class Initialized
INFO - 2022-07-06 06:33:19 --> Output Class Initialized
INFO - 2022-07-06 06:33:19 --> Security Class Initialized
DEBUG - 2022-07-06 06:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:33:19 --> Input Class Initialized
INFO - 2022-07-06 06:33:19 --> Language Class Initialized
INFO - 2022-07-06 06:33:19 --> Loader Class Initialized
INFO - 2022-07-06 06:33:19 --> Helper loaded: url_helper
INFO - 2022-07-06 06:33:19 --> Helper loaded: file_helper
INFO - 2022-07-06 06:33:19 --> Database Driver Class Initialized
INFO - 2022-07-06 06:33:19 --> Email Class Initialized
DEBUG - 2022-07-06 06:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:33:19 --> Controller Class Initialized
INFO - 2022-07-06 06:33:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:33:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-06 06:33:19 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\qr\application\models\Tokenmodel.php 182
INFO - 2022-07-06 06:33:19 --> Language file loaded: language/english/db_lang.php
INFO - 2022-07-06 06:33:19 --> Email Class Initialized
DEBUG - 2022-07-06 06:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:33:19 --> Controller Class Initialized
INFO - 2022-07-06 06:33:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:33:19 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:33:19 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-06 06:33:19 --> Final output sent to browser
DEBUG - 2022-07-06 06:33:19 --> Total execution time: 0.2819
INFO - 2022-07-06 06:33:58 --> Config Class Initialized
INFO - 2022-07-06 06:33:58 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:33:58 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:33:58 --> Utf8 Class Initialized
INFO - 2022-07-06 06:33:58 --> URI Class Initialized
INFO - 2022-07-06 06:33:58 --> Router Class Initialized
INFO - 2022-07-06 06:33:58 --> Output Class Initialized
INFO - 2022-07-06 06:33:58 --> Security Class Initialized
DEBUG - 2022-07-06 06:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:33:58 --> Input Class Initialized
INFO - 2022-07-06 06:33:58 --> Language Class Initialized
INFO - 2022-07-06 06:33:58 --> Loader Class Initialized
INFO - 2022-07-06 06:33:58 --> Helper loaded: url_helper
INFO - 2022-07-06 06:33:58 --> Helper loaded: file_helper
INFO - 2022-07-06 06:33:58 --> Database Driver Class Initialized
INFO - 2022-07-06 06:33:58 --> Email Class Initialized
DEBUG - 2022-07-06 06:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:33:58 --> Controller Class Initialized
INFO - 2022-07-06 06:33:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:33:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:33:58 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-06 06:33:58 --> Final output sent to browser
DEBUG - 2022-07-06 06:33:58 --> Total execution time: 0.1816
INFO - 2022-07-06 06:34:06 --> Config Class Initialized
INFO - 2022-07-06 06:34:06 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:34:06 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:34:06 --> Utf8 Class Initialized
INFO - 2022-07-06 06:34:06 --> URI Class Initialized
INFO - 2022-07-06 06:34:06 --> Router Class Initialized
INFO - 2022-07-06 06:34:06 --> Output Class Initialized
INFO - 2022-07-06 06:34:06 --> Security Class Initialized
DEBUG - 2022-07-06 06:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:34:06 --> Input Class Initialized
INFO - 2022-07-06 06:34:06 --> Language Class Initialized
INFO - 2022-07-06 06:34:06 --> Loader Class Initialized
INFO - 2022-07-06 06:34:06 --> Helper loaded: url_helper
INFO - 2022-07-06 06:34:06 --> Helper loaded: file_helper
INFO - 2022-07-06 06:34:06 --> Database Driver Class Initialized
INFO - 2022-07-06 06:34:06 --> Email Class Initialized
DEBUG - 2022-07-06 06:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:34:06 --> Controller Class Initialized
INFO - 2022-07-06 06:34:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:34:06 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:34:12 --> Config Class Initialized
INFO - 2022-07-06 06:34:12 --> Config Class Initialized
INFO - 2022-07-06 06:34:12 --> Hooks Class Initialized
INFO - 2022-07-06 06:34:12 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:34:12 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:34:12 --> Utf8 Class Initialized
INFO - 2022-07-06 06:34:12 --> Utf8 Class Initialized
INFO - 2022-07-06 06:34:12 --> URI Class Initialized
INFO - 2022-07-06 06:34:12 --> URI Class Initialized
INFO - 2022-07-06 06:34:12 --> Router Class Initialized
INFO - 2022-07-06 06:34:12 --> Router Class Initialized
INFO - 2022-07-06 06:34:12 --> Output Class Initialized
INFO - 2022-07-06 06:34:12 --> Security Class Initialized
INFO - 2022-07-06 06:34:12 --> Output Class Initialized
DEBUG - 2022-07-06 06:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:34:12 --> Security Class Initialized
INFO - 2022-07-06 06:34:12 --> Input Class Initialized
DEBUG - 2022-07-06 06:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:34:12 --> Language Class Initialized
INFO - 2022-07-06 06:34:12 --> Input Class Initialized
INFO - 2022-07-06 06:34:12 --> Language Class Initialized
INFO - 2022-07-06 06:34:12 --> Loader Class Initialized
INFO - 2022-07-06 06:34:12 --> Loader Class Initialized
INFO - 2022-07-06 06:34:12 --> Helper loaded: url_helper
INFO - 2022-07-06 06:34:12 --> Helper loaded: url_helper
INFO - 2022-07-06 06:34:12 --> Helper loaded: file_helper
INFO - 2022-07-06 06:34:12 --> Helper loaded: file_helper
INFO - 2022-07-06 06:34:12 --> Database Driver Class Initialized
INFO - 2022-07-06 06:34:12 --> Database Driver Class Initialized
INFO - 2022-07-06 06:34:12 --> Email Class Initialized
INFO - 2022-07-06 06:34:12 --> Email Class Initialized
DEBUG - 2022-07-06 06:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-06 06:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:34:12 --> Controller Class Initialized
INFO - 2022-07-06 06:34:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:34:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-06 06:34:12 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\qr\application\models\Tokenmodel.php 182
INFO - 2022-07-06 06:34:12 --> Language file loaded: language/english/db_lang.php
INFO - 2022-07-06 06:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:34:12 --> Controller Class Initialized
INFO - 2022-07-06 06:34:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:34:12 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:34:12 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-06 06:34:12 --> Final output sent to browser
DEBUG - 2022-07-06 06:34:12 --> Total execution time: 0.1290
INFO - 2022-07-06 06:36:23 --> Config Class Initialized
INFO - 2022-07-06 06:36:23 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:36:23 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:36:23 --> Utf8 Class Initialized
INFO - 2022-07-06 06:36:23 --> URI Class Initialized
INFO - 2022-07-06 06:36:23 --> Router Class Initialized
INFO - 2022-07-06 06:36:23 --> Output Class Initialized
INFO - 2022-07-06 06:36:23 --> Security Class Initialized
DEBUG - 2022-07-06 06:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:36:23 --> Input Class Initialized
INFO - 2022-07-06 06:36:23 --> Language Class Initialized
INFO - 2022-07-06 06:36:23 --> Loader Class Initialized
INFO - 2022-07-06 06:36:23 --> Helper loaded: url_helper
INFO - 2022-07-06 06:36:23 --> Helper loaded: file_helper
INFO - 2022-07-06 06:36:23 --> Database Driver Class Initialized
INFO - 2022-07-06 06:36:23 --> Email Class Initialized
DEBUG - 2022-07-06 06:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:36:23 --> Controller Class Initialized
INFO - 2022-07-06 06:36:23 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:36:23 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:36:23 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-06 06:36:23 --> Final output sent to browser
DEBUG - 2022-07-06 06:36:23 --> Total execution time: 0.1801
INFO - 2022-07-06 06:36:33 --> Config Class Initialized
INFO - 2022-07-06 06:36:33 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:36:33 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:36:33 --> Utf8 Class Initialized
INFO - 2022-07-06 06:36:33 --> URI Class Initialized
INFO - 2022-07-06 06:36:33 --> Router Class Initialized
INFO - 2022-07-06 06:36:33 --> Output Class Initialized
INFO - 2022-07-06 06:36:33 --> Security Class Initialized
DEBUG - 2022-07-06 06:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:36:33 --> Input Class Initialized
INFO - 2022-07-06 06:36:33 --> Language Class Initialized
INFO - 2022-07-06 06:36:33 --> Loader Class Initialized
INFO - 2022-07-06 06:36:33 --> Helper loaded: url_helper
INFO - 2022-07-06 06:36:33 --> Helper loaded: file_helper
INFO - 2022-07-06 06:36:33 --> Database Driver Class Initialized
INFO - 2022-07-06 06:36:33 --> Email Class Initialized
DEBUG - 2022-07-06 06:36:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:36:33 --> Controller Class Initialized
INFO - 2022-07-06 06:36:33 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:36:33 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:36:38 --> Config Class Initialized
INFO - 2022-07-06 06:36:38 --> Config Class Initialized
INFO - 2022-07-06 06:36:38 --> Hooks Class Initialized
INFO - 2022-07-06 06:36:38 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:36:38 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:36:38 --> Utf8 Class Initialized
INFO - 2022-07-06 06:36:38 --> URI Class Initialized
INFO - 2022-07-06 06:36:38 --> Router Class Initialized
INFO - 2022-07-06 06:36:38 --> Output Class Initialized
INFO - 2022-07-06 06:36:38 --> Security Class Initialized
DEBUG - 2022-07-06 06:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:36:38 --> Input Class Initialized
INFO - 2022-07-06 06:36:38 --> Language Class Initialized
INFO - 2022-07-06 06:36:38 --> Loader Class Initialized
INFO - 2022-07-06 06:36:38 --> Utf8 Class Initialized
INFO - 2022-07-06 06:36:38 --> URI Class Initialized
INFO - 2022-07-06 06:36:38 --> Helper loaded: url_helper
INFO - 2022-07-06 06:36:38 --> Helper loaded: file_helper
INFO - 2022-07-06 06:36:38 --> Router Class Initialized
INFO - 2022-07-06 06:36:38 --> Output Class Initialized
INFO - 2022-07-06 06:36:38 --> Database Driver Class Initialized
INFO - 2022-07-06 06:36:38 --> Security Class Initialized
DEBUG - 2022-07-06 06:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:36:38 --> Input Class Initialized
INFO - 2022-07-06 06:36:38 --> Language Class Initialized
INFO - 2022-07-06 06:36:38 --> Loader Class Initialized
INFO - 2022-07-06 06:36:38 --> Helper loaded: url_helper
INFO - 2022-07-06 06:36:38 --> Helper loaded: file_helper
INFO - 2022-07-06 06:36:38 --> Database Driver Class Initialized
INFO - 2022-07-06 06:36:38 --> Email Class Initialized
DEBUG - 2022-07-06 06:36:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:36:38 --> Controller Class Initialized
INFO - 2022-07-06 06:36:38 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:36:38 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:36:38 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-06 06:36:38 --> Final output sent to browser
DEBUG - 2022-07-06 06:36:38 --> Total execution time: 0.0576
INFO - 2022-07-06 06:36:38 --> Email Class Initialized
DEBUG - 2022-07-06 06:36:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:36:38 --> Controller Class Initialized
INFO - 2022-07-06 06:36:38 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:36:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-06 06:36:38 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\qr\application\models\Tokenmodel.php 182
INFO - 2022-07-06 06:36:38 --> Language file loaded: language/english/db_lang.php
INFO - 2022-07-06 06:37:06 --> Config Class Initialized
INFO - 2022-07-06 06:37:06 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:37:06 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:37:06 --> Utf8 Class Initialized
INFO - 2022-07-06 06:37:06 --> URI Class Initialized
INFO - 2022-07-06 06:37:06 --> Router Class Initialized
INFO - 2022-07-06 06:37:06 --> Output Class Initialized
INFO - 2022-07-06 06:37:06 --> Security Class Initialized
DEBUG - 2022-07-06 06:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:37:06 --> Input Class Initialized
INFO - 2022-07-06 06:37:06 --> Language Class Initialized
INFO - 2022-07-06 06:37:06 --> Loader Class Initialized
INFO - 2022-07-06 06:37:06 --> Helper loaded: url_helper
INFO - 2022-07-06 06:37:06 --> Helper loaded: file_helper
INFO - 2022-07-06 06:37:06 --> Database Driver Class Initialized
INFO - 2022-07-06 06:37:06 --> Email Class Initialized
DEBUG - 2022-07-06 06:37:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:37:06 --> Controller Class Initialized
INFO - 2022-07-06 06:37:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:37:06 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:37:13 --> Config Class Initialized
INFO - 2022-07-06 06:37:13 --> Hooks Class Initialized
INFO - 2022-07-06 06:37:13 --> Config Class Initialized
INFO - 2022-07-06 06:37:13 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:37:13 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:37:13 --> Utf8 Class Initialized
DEBUG - 2022-07-06 06:37:13 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:37:13 --> Utf8 Class Initialized
INFO - 2022-07-06 06:37:13 --> URI Class Initialized
INFO - 2022-07-06 06:37:13 --> URI Class Initialized
INFO - 2022-07-06 06:37:13 --> Router Class Initialized
INFO - 2022-07-06 06:37:13 --> Router Class Initialized
INFO - 2022-07-06 06:37:13 --> Output Class Initialized
INFO - 2022-07-06 06:37:13 --> Output Class Initialized
INFO - 2022-07-06 06:37:13 --> Security Class Initialized
INFO - 2022-07-06 06:37:13 --> Security Class Initialized
DEBUG - 2022-07-06 06:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:37:13 --> Input Class Initialized
INFO - 2022-07-06 06:37:13 --> Input Class Initialized
INFO - 2022-07-06 06:37:13 --> Language Class Initialized
INFO - 2022-07-06 06:37:13 --> Language Class Initialized
INFO - 2022-07-06 06:37:13 --> Loader Class Initialized
INFO - 2022-07-06 06:37:13 --> Loader Class Initialized
INFO - 2022-07-06 06:37:13 --> Helper loaded: url_helper
INFO - 2022-07-06 06:37:13 --> Helper loaded: url_helper
INFO - 2022-07-06 06:37:13 --> Helper loaded: file_helper
INFO - 2022-07-06 06:37:13 --> Helper loaded: file_helper
INFO - 2022-07-06 06:37:13 --> Database Driver Class Initialized
INFO - 2022-07-06 06:37:13 --> Database Driver Class Initialized
INFO - 2022-07-06 06:37:13 --> Email Class Initialized
DEBUG - 2022-07-06 06:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:37:13 --> Controller Class Initialized
INFO - 2022-07-06 06:37:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:37:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-06 06:37:13 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\qr\application\models\Tokenmodel.php 182
INFO - 2022-07-06 06:37:13 --> Language file loaded: language/english/db_lang.php
INFO - 2022-07-06 06:37:13 --> Email Class Initialized
DEBUG - 2022-07-06 06:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:37:13 --> Controller Class Initialized
INFO - 2022-07-06 06:37:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:37:13 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:37:13 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-06 06:37:13 --> Final output sent to browser
DEBUG - 2022-07-06 06:37:13 --> Total execution time: 0.2191
INFO - 2022-07-06 06:40:35 --> Config Class Initialized
INFO - 2022-07-06 06:40:35 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:40:35 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:40:35 --> Utf8 Class Initialized
INFO - 2022-07-06 06:40:35 --> URI Class Initialized
INFO - 2022-07-06 06:40:35 --> Router Class Initialized
INFO - 2022-07-06 06:40:35 --> Output Class Initialized
INFO - 2022-07-06 06:40:35 --> Security Class Initialized
DEBUG - 2022-07-06 06:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:40:35 --> Input Class Initialized
INFO - 2022-07-06 06:40:35 --> Language Class Initialized
INFO - 2022-07-06 06:40:35 --> Loader Class Initialized
INFO - 2022-07-06 06:40:35 --> Helper loaded: url_helper
INFO - 2022-07-06 06:40:35 --> Helper loaded: file_helper
INFO - 2022-07-06 06:40:35 --> Database Driver Class Initialized
INFO - 2022-07-06 06:40:35 --> Email Class Initialized
DEBUG - 2022-07-06 06:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:40:35 --> Controller Class Initialized
INFO - 2022-07-06 06:40:35 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:40:35 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:40:35 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-06 06:40:35 --> Final output sent to browser
DEBUG - 2022-07-06 06:40:35 --> Total execution time: 0.0449
INFO - 2022-07-06 06:40:45 --> Config Class Initialized
INFO - 2022-07-06 06:40:45 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:40:45 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:40:45 --> Utf8 Class Initialized
INFO - 2022-07-06 06:40:45 --> URI Class Initialized
INFO - 2022-07-06 06:40:45 --> Router Class Initialized
INFO - 2022-07-06 06:40:45 --> Output Class Initialized
INFO - 2022-07-06 06:40:45 --> Security Class Initialized
DEBUG - 2022-07-06 06:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:40:45 --> Input Class Initialized
INFO - 2022-07-06 06:40:45 --> Language Class Initialized
INFO - 2022-07-06 06:40:45 --> Loader Class Initialized
INFO - 2022-07-06 06:40:45 --> Helper loaded: url_helper
INFO - 2022-07-06 06:40:45 --> Helper loaded: file_helper
INFO - 2022-07-06 06:40:45 --> Database Driver Class Initialized
INFO - 2022-07-06 06:40:45 --> Email Class Initialized
DEBUG - 2022-07-06 06:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:40:45 --> Controller Class Initialized
INFO - 2022-07-06 06:40:45 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:40:45 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:40:51 --> Config Class Initialized
INFO - 2022-07-06 06:40:51 --> Hooks Class Initialized
INFO - 2022-07-06 06:40:51 --> Config Class Initialized
INFO - 2022-07-06 06:40:51 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:40:51 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:40:51 --> Utf8 Class Initialized
DEBUG - 2022-07-06 06:40:51 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:40:51 --> URI Class Initialized
INFO - 2022-07-06 06:40:51 --> Utf8 Class Initialized
INFO - 2022-07-06 06:40:51 --> URI Class Initialized
INFO - 2022-07-06 06:40:51 --> Router Class Initialized
INFO - 2022-07-06 06:40:51 --> Router Class Initialized
INFO - 2022-07-06 06:40:51 --> Output Class Initialized
INFO - 2022-07-06 06:40:51 --> Output Class Initialized
INFO - 2022-07-06 06:40:51 --> Security Class Initialized
INFO - 2022-07-06 06:40:51 --> Security Class Initialized
DEBUG - 2022-07-06 06:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:40:51 --> Input Class Initialized
INFO - 2022-07-06 06:40:51 --> Input Class Initialized
INFO - 2022-07-06 06:40:51 --> Language Class Initialized
INFO - 2022-07-06 06:40:51 --> Language Class Initialized
INFO - 2022-07-06 06:40:51 --> Loader Class Initialized
INFO - 2022-07-06 06:40:51 --> Loader Class Initialized
INFO - 2022-07-06 06:40:51 --> Helper loaded: url_helper
INFO - 2022-07-06 06:40:51 --> Helper loaded: url_helper
INFO - 2022-07-06 06:40:51 --> Helper loaded: file_helper
INFO - 2022-07-06 06:40:51 --> Helper loaded: file_helper
INFO - 2022-07-06 06:40:51 --> Database Driver Class Initialized
INFO - 2022-07-06 06:40:51 --> Database Driver Class Initialized
INFO - 2022-07-06 06:40:51 --> Email Class Initialized
DEBUG - 2022-07-06 06:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:40:51 --> Controller Class Initialized
INFO - 2022-07-06 06:40:51 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:40:51 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:40:51 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-06 06:40:51 --> Final output sent to browser
DEBUG - 2022-07-06 06:40:51 --> Total execution time: 0.0252
INFO - 2022-07-06 06:40:52 --> Email Class Initialized
DEBUG - 2022-07-06 06:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:40:52 --> Controller Class Initialized
INFO - 2022-07-06 06:40:52 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:40:52 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:40:52 --> Final output sent to browser
DEBUG - 2022-07-06 06:40:52 --> Total execution time: 0.1610
INFO - 2022-07-06 06:42:06 --> Config Class Initialized
INFO - 2022-07-06 06:42:06 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:42:06 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:42:06 --> Utf8 Class Initialized
INFO - 2022-07-06 06:42:06 --> URI Class Initialized
INFO - 2022-07-06 06:42:06 --> Router Class Initialized
INFO - 2022-07-06 06:42:06 --> Output Class Initialized
INFO - 2022-07-06 06:42:06 --> Security Class Initialized
DEBUG - 2022-07-06 06:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:42:06 --> Input Class Initialized
INFO - 2022-07-06 06:42:06 --> Language Class Initialized
INFO - 2022-07-06 06:42:06 --> Loader Class Initialized
INFO - 2022-07-06 06:42:06 --> Helper loaded: url_helper
INFO - 2022-07-06 06:42:06 --> Helper loaded: file_helper
INFO - 2022-07-06 06:42:06 --> Database Driver Class Initialized
INFO - 2022-07-06 06:42:06 --> Email Class Initialized
DEBUG - 2022-07-06 06:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:42:06 --> Controller Class Initialized
INFO - 2022-07-06 06:42:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:42:06 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:42:06 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-06 06:42:06 --> Final output sent to browser
DEBUG - 2022-07-06 06:42:06 --> Total execution time: 0.2102
INFO - 2022-07-06 06:42:16 --> Config Class Initialized
INFO - 2022-07-06 06:42:16 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:42:16 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:42:16 --> Utf8 Class Initialized
INFO - 2022-07-06 06:42:16 --> URI Class Initialized
INFO - 2022-07-06 06:42:16 --> Router Class Initialized
INFO - 2022-07-06 06:42:16 --> Output Class Initialized
INFO - 2022-07-06 06:42:16 --> Security Class Initialized
DEBUG - 2022-07-06 06:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:42:16 --> Input Class Initialized
INFO - 2022-07-06 06:42:16 --> Language Class Initialized
INFO - 2022-07-06 06:42:16 --> Loader Class Initialized
INFO - 2022-07-06 06:42:16 --> Helper loaded: url_helper
INFO - 2022-07-06 06:42:16 --> Helper loaded: file_helper
INFO - 2022-07-06 06:42:16 --> Database Driver Class Initialized
INFO - 2022-07-06 06:42:16 --> Email Class Initialized
DEBUG - 2022-07-06 06:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:42:16 --> Controller Class Initialized
INFO - 2022-07-06 06:42:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:42:16 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:42:44 --> Config Class Initialized
INFO - 2022-07-06 06:42:44 --> Hooks Class Initialized
INFO - 2022-07-06 06:42:44 --> Config Class Initialized
INFO - 2022-07-06 06:42:44 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:42:44 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:42:44 --> Utf8 Class Initialized
INFO - 2022-07-06 06:42:44 --> Utf8 Class Initialized
INFO - 2022-07-06 06:42:44 --> URI Class Initialized
INFO - 2022-07-06 06:42:44 --> URI Class Initialized
INFO - 2022-07-06 06:42:44 --> Router Class Initialized
INFO - 2022-07-06 06:42:44 --> Router Class Initialized
INFO - 2022-07-06 06:42:44 --> Output Class Initialized
INFO - 2022-07-06 06:42:44 --> Output Class Initialized
INFO - 2022-07-06 06:42:44 --> Security Class Initialized
INFO - 2022-07-06 06:42:44 --> Security Class Initialized
DEBUG - 2022-07-06 06:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:42:44 --> Input Class Initialized
DEBUG - 2022-07-06 06:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:42:44 --> Language Class Initialized
INFO - 2022-07-06 06:42:44 --> Input Class Initialized
INFO - 2022-07-06 06:42:44 --> Loader Class Initialized
INFO - 2022-07-06 06:42:44 --> Language Class Initialized
INFO - 2022-07-06 06:42:44 --> Helper loaded: url_helper
INFO - 2022-07-06 06:42:44 --> Loader Class Initialized
INFO - 2022-07-06 06:42:44 --> Helper loaded: file_helper
INFO - 2022-07-06 06:42:44 --> Helper loaded: url_helper
INFO - 2022-07-06 06:42:44 --> Database Driver Class Initialized
INFO - 2022-07-06 06:42:44 --> Helper loaded: file_helper
INFO - 2022-07-06 06:42:44 --> Database Driver Class Initialized
INFO - 2022-07-06 06:42:44 --> Email Class Initialized
DEBUG - 2022-07-06 06:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:42:44 --> Controller Class Initialized
INFO - 2022-07-06 06:42:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:42:44 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:42:44 --> Final output sent to browser
DEBUG - 2022-07-06 06:42:44 --> Total execution time: 0.1304
INFO - 2022-07-06 06:42:44 --> Email Class Initialized
DEBUG - 2022-07-06 06:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:42:44 --> Controller Class Initialized
INFO - 2022-07-06 06:42:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:42:44 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:42:44 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-06 06:42:44 --> Final output sent to browser
DEBUG - 2022-07-06 06:42:44 --> Total execution time: 0.1684
INFO - 2022-07-06 06:43:03 --> Config Class Initialized
INFO - 2022-07-06 06:43:03 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:43:03 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:43:03 --> Utf8 Class Initialized
INFO - 2022-07-06 06:43:03 --> URI Class Initialized
INFO - 2022-07-06 06:43:03 --> Router Class Initialized
INFO - 2022-07-06 06:43:03 --> Output Class Initialized
INFO - 2022-07-06 06:43:03 --> Security Class Initialized
DEBUG - 2022-07-06 06:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:43:03 --> Input Class Initialized
INFO - 2022-07-06 06:43:03 --> Language Class Initialized
INFO - 2022-07-06 06:43:03 --> Loader Class Initialized
INFO - 2022-07-06 06:43:03 --> Helper loaded: url_helper
INFO - 2022-07-06 06:43:03 --> Helper loaded: file_helper
INFO - 2022-07-06 06:43:03 --> Database Driver Class Initialized
INFO - 2022-07-06 06:43:03 --> Email Class Initialized
DEBUG - 2022-07-06 06:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:43:03 --> Controller Class Initialized
INFO - 2022-07-06 06:43:03 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:43:03 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:43:03 --> Final output sent to browser
DEBUG - 2022-07-06 06:43:03 --> Total execution time: 0.0214
INFO - 2022-07-06 06:43:04 --> Config Class Initialized
INFO - 2022-07-06 06:43:04 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:43:04 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:43:04 --> Utf8 Class Initialized
INFO - 2022-07-06 06:43:04 --> URI Class Initialized
INFO - 2022-07-06 06:43:04 --> Router Class Initialized
INFO - 2022-07-06 06:43:04 --> Output Class Initialized
INFO - 2022-07-06 06:43:04 --> Security Class Initialized
DEBUG - 2022-07-06 06:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:43:04 --> Input Class Initialized
INFO - 2022-07-06 06:43:04 --> Language Class Initialized
INFO - 2022-07-06 06:43:04 --> Loader Class Initialized
INFO - 2022-07-06 06:43:04 --> Helper loaded: url_helper
INFO - 2022-07-06 06:43:04 --> Helper loaded: file_helper
INFO - 2022-07-06 06:43:04 --> Database Driver Class Initialized
INFO - 2022-07-06 06:43:04 --> Email Class Initialized
DEBUG - 2022-07-06 06:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:43:04 --> Controller Class Initialized
INFO - 2022-07-06 06:43:04 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:43:04 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:43:04 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-06 06:43:04 --> Final output sent to browser
DEBUG - 2022-07-06 06:43:04 --> Total execution time: 0.0324
INFO - 2022-07-06 06:43:14 --> Config Class Initialized
INFO - 2022-07-06 06:43:14 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:43:14 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:43:14 --> Utf8 Class Initialized
INFO - 2022-07-06 06:43:14 --> URI Class Initialized
INFO - 2022-07-06 06:43:14 --> Router Class Initialized
INFO - 2022-07-06 06:43:14 --> Output Class Initialized
INFO - 2022-07-06 06:43:14 --> Security Class Initialized
DEBUG - 2022-07-06 06:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:43:14 --> Input Class Initialized
INFO - 2022-07-06 06:43:14 --> Language Class Initialized
INFO - 2022-07-06 06:43:14 --> Loader Class Initialized
INFO - 2022-07-06 06:43:14 --> Helper loaded: url_helper
INFO - 2022-07-06 06:43:14 --> Helper loaded: file_helper
INFO - 2022-07-06 06:43:14 --> Database Driver Class Initialized
INFO - 2022-07-06 06:43:14 --> Email Class Initialized
DEBUG - 2022-07-06 06:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:43:14 --> Controller Class Initialized
INFO - 2022-07-06 06:43:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:43:14 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:43:14 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails_1.php
INFO - 2022-07-06 06:43:14 --> Final output sent to browser
DEBUG - 2022-07-06 06:43:14 --> Total execution time: 0.0524
INFO - 2022-07-06 06:43:14 --> Config Class Initialized
INFO - 2022-07-06 06:43:14 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:43:14 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:43:14 --> Utf8 Class Initialized
INFO - 2022-07-06 06:43:14 --> URI Class Initialized
INFO - 2022-07-06 06:43:14 --> Router Class Initialized
INFO - 2022-07-06 06:43:14 --> Output Class Initialized
INFO - 2022-07-06 06:43:14 --> Security Class Initialized
DEBUG - 2022-07-06 06:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:43:14 --> Input Class Initialized
INFO - 2022-07-06 06:43:14 --> Language Class Initialized
INFO - 2022-07-06 06:43:14 --> Loader Class Initialized
INFO - 2022-07-06 06:43:14 --> Helper loaded: url_helper
INFO - 2022-07-06 06:43:14 --> Helper loaded: file_helper
INFO - 2022-07-06 06:43:14 --> Database Driver Class Initialized
INFO - 2022-07-06 06:43:14 --> Email Class Initialized
DEBUG - 2022-07-06 06:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:43:14 --> Controller Class Initialized
INFO - 2022-07-06 06:43:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:43:14 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:43:14 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails_1.php
INFO - 2022-07-06 06:43:14 --> Final output sent to browser
DEBUG - 2022-07-06 06:43:14 --> Total execution time: 0.0214
INFO - 2022-07-06 06:43:22 --> Config Class Initialized
INFO - 2022-07-06 06:43:22 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:43:22 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:43:22 --> Utf8 Class Initialized
INFO - 2022-07-06 06:43:22 --> URI Class Initialized
INFO - 2022-07-06 06:43:22 --> Router Class Initialized
INFO - 2022-07-06 06:43:22 --> Output Class Initialized
INFO - 2022-07-06 06:43:22 --> Security Class Initialized
DEBUG - 2022-07-06 06:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:43:22 --> Input Class Initialized
INFO - 2022-07-06 06:43:22 --> Language Class Initialized
INFO - 2022-07-06 06:43:22 --> Loader Class Initialized
INFO - 2022-07-06 06:43:22 --> Helper loaded: url_helper
INFO - 2022-07-06 06:43:22 --> Helper loaded: file_helper
INFO - 2022-07-06 06:43:22 --> Database Driver Class Initialized
INFO - 2022-07-06 06:43:22 --> Email Class Initialized
DEBUG - 2022-07-06 06:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:43:22 --> Controller Class Initialized
INFO - 2022-07-06 06:43:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:43:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 06:43:22 --> test
INFO - 2022-07-06 06:43:22 --> Final output sent to browser
DEBUG - 2022-07-06 06:43:22 --> Total execution time: 0.0425
INFO - 2022-07-06 06:43:22 --> Config Class Initialized
INFO - 2022-07-06 06:43:22 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:43:22 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:43:22 --> Utf8 Class Initialized
INFO - 2022-07-06 06:43:22 --> URI Class Initialized
INFO - 2022-07-06 06:43:22 --> Router Class Initialized
INFO - 2022-07-06 06:43:22 --> Output Class Initialized
INFO - 2022-07-06 06:43:22 --> Security Class Initialized
DEBUG - 2022-07-06 06:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:43:22 --> Input Class Initialized
INFO - 2022-07-06 06:43:22 --> Language Class Initialized
INFO - 2022-07-06 06:43:22 --> Loader Class Initialized
INFO - 2022-07-06 06:43:22 --> Helper loaded: url_helper
INFO - 2022-07-06 06:43:22 --> Helper loaded: file_helper
INFO - 2022-07-06 06:43:22 --> Database Driver Class Initialized
INFO - 2022-07-06 06:43:22 --> Email Class Initialized
DEBUG - 2022-07-06 06:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:43:22 --> Controller Class Initialized
INFO - 2022-07-06 06:43:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:43:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:43:22 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-06 06:43:22 --> Final output sent to browser
DEBUG - 2022-07-06 06:43:22 --> Total execution time: 0.0403
INFO - 2022-07-06 06:48:29 --> Config Class Initialized
INFO - 2022-07-06 06:48:29 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:48:29 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:48:29 --> Utf8 Class Initialized
INFO - 2022-07-06 06:48:29 --> URI Class Initialized
INFO - 2022-07-06 06:48:29 --> Router Class Initialized
INFO - 2022-07-06 06:48:29 --> Output Class Initialized
INFO - 2022-07-06 06:48:29 --> Security Class Initialized
DEBUG - 2022-07-06 06:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:48:29 --> Input Class Initialized
INFO - 2022-07-06 06:48:29 --> Language Class Initialized
INFO - 2022-07-06 06:48:29 --> Loader Class Initialized
INFO - 2022-07-06 06:48:29 --> Helper loaded: url_helper
INFO - 2022-07-06 06:48:29 --> Helper loaded: file_helper
INFO - 2022-07-06 06:48:29 --> Database Driver Class Initialized
INFO - 2022-07-06 06:48:29 --> Email Class Initialized
DEBUG - 2022-07-06 06:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:48:29 --> Controller Class Initialized
INFO - 2022-07-06 06:48:29 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:48:29 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:48:29 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-06 06:48:29 --> Final output sent to browser
DEBUG - 2022-07-06 06:48:29 --> Total execution time: 0.0304
INFO - 2022-07-06 06:48:39 --> Config Class Initialized
INFO - 2022-07-06 06:48:39 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:48:39 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:48:39 --> Utf8 Class Initialized
INFO - 2022-07-06 06:48:39 --> URI Class Initialized
INFO - 2022-07-06 06:48:39 --> Router Class Initialized
INFO - 2022-07-06 06:48:39 --> Output Class Initialized
INFO - 2022-07-06 06:48:39 --> Security Class Initialized
DEBUG - 2022-07-06 06:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:48:39 --> Input Class Initialized
INFO - 2022-07-06 06:48:39 --> Language Class Initialized
INFO - 2022-07-06 06:48:39 --> Loader Class Initialized
INFO - 2022-07-06 06:48:39 --> Helper loaded: url_helper
INFO - 2022-07-06 06:48:39 --> Helper loaded: file_helper
INFO - 2022-07-06 06:48:39 --> Database Driver Class Initialized
INFO - 2022-07-06 06:48:39 --> Email Class Initialized
DEBUG - 2022-07-06 06:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:48:39 --> Controller Class Initialized
INFO - 2022-07-06 06:48:39 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:48:39 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:49:33 --> Config Class Initialized
INFO - 2022-07-06 06:49:33 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:49:33 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:49:33 --> Utf8 Class Initialized
INFO - 2022-07-06 06:49:33 --> URI Class Initialized
INFO - 2022-07-06 06:49:33 --> Router Class Initialized
INFO - 2022-07-06 06:49:33 --> Output Class Initialized
INFO - 2022-07-06 06:49:33 --> Security Class Initialized
DEBUG - 2022-07-06 06:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:49:33 --> Input Class Initialized
INFO - 2022-07-06 06:49:33 --> Language Class Initialized
INFO - 2022-07-06 06:49:33 --> Loader Class Initialized
INFO - 2022-07-06 06:49:33 --> Helper loaded: url_helper
INFO - 2022-07-06 06:49:33 --> Helper loaded: file_helper
INFO - 2022-07-06 06:49:33 --> Database Driver Class Initialized
INFO - 2022-07-06 06:49:33 --> Email Class Initialized
DEBUG - 2022-07-06 06:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:49:33 --> Controller Class Initialized
INFO - 2022-07-06 06:49:33 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:49:33 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:49:33 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-06 06:49:33 --> Final output sent to browser
DEBUG - 2022-07-06 06:49:33 --> Total execution time: 0.1498
INFO - 2022-07-06 06:49:52 --> Config Class Initialized
INFO - 2022-07-06 06:49:52 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:49:52 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:49:52 --> Utf8 Class Initialized
INFO - 2022-07-06 06:49:52 --> URI Class Initialized
INFO - 2022-07-06 06:49:52 --> Router Class Initialized
INFO - 2022-07-06 06:49:52 --> Output Class Initialized
INFO - 2022-07-06 06:49:52 --> Security Class Initialized
DEBUG - 2022-07-06 06:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:49:52 --> Input Class Initialized
INFO - 2022-07-06 06:49:52 --> Language Class Initialized
INFO - 2022-07-06 06:49:52 --> Loader Class Initialized
INFO - 2022-07-06 06:49:52 --> Helper loaded: url_helper
INFO - 2022-07-06 06:49:52 --> Helper loaded: file_helper
INFO - 2022-07-06 06:49:52 --> Database Driver Class Initialized
INFO - 2022-07-06 06:49:52 --> Email Class Initialized
DEBUG - 2022-07-06 06:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:49:52 --> Controller Class Initialized
INFO - 2022-07-06 06:49:52 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:49:52 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:52:06 --> Config Class Initialized
INFO - 2022-07-06 06:52:06 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:52:06 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:52:06 --> Utf8 Class Initialized
INFO - 2022-07-06 06:52:06 --> URI Class Initialized
INFO - 2022-07-06 06:52:06 --> Router Class Initialized
INFO - 2022-07-06 06:52:06 --> Output Class Initialized
INFO - 2022-07-06 06:52:06 --> Security Class Initialized
DEBUG - 2022-07-06 06:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:52:06 --> Input Class Initialized
INFO - 2022-07-06 06:52:06 --> Language Class Initialized
INFO - 2022-07-06 06:52:06 --> Loader Class Initialized
INFO - 2022-07-06 06:52:06 --> Helper loaded: url_helper
INFO - 2022-07-06 06:52:06 --> Helper loaded: file_helper
INFO - 2022-07-06 06:52:06 --> Database Driver Class Initialized
INFO - 2022-07-06 06:52:06 --> Email Class Initialized
DEBUG - 2022-07-06 06:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:52:06 --> Controller Class Initialized
INFO - 2022-07-06 06:52:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:52:06 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:52:06 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-06 06:52:06 --> Final output sent to browser
DEBUG - 2022-07-06 06:52:06 --> Total execution time: 0.0185
INFO - 2022-07-06 06:52:13 --> Config Class Initialized
INFO - 2022-07-06 06:52:13 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:52:13 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:52:13 --> Utf8 Class Initialized
INFO - 2022-07-06 06:52:13 --> URI Class Initialized
INFO - 2022-07-06 06:52:13 --> Router Class Initialized
INFO - 2022-07-06 06:52:13 --> Output Class Initialized
INFO - 2022-07-06 06:52:13 --> Security Class Initialized
DEBUG - 2022-07-06 06:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:52:13 --> Input Class Initialized
INFO - 2022-07-06 06:52:13 --> Language Class Initialized
INFO - 2022-07-06 06:52:13 --> Loader Class Initialized
INFO - 2022-07-06 06:52:13 --> Helper loaded: url_helper
INFO - 2022-07-06 06:52:13 --> Helper loaded: file_helper
INFO - 2022-07-06 06:52:13 --> Database Driver Class Initialized
INFO - 2022-07-06 06:52:13 --> Email Class Initialized
DEBUG - 2022-07-06 06:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:52:13 --> Controller Class Initialized
INFO - 2022-07-06 06:52:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:52:13 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:52:22 --> Config Class Initialized
INFO - 2022-07-06 06:52:22 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:52:22 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:52:22 --> Utf8 Class Initialized
INFO - 2022-07-06 06:52:22 --> URI Class Initialized
INFO - 2022-07-06 06:52:22 --> Router Class Initialized
INFO - 2022-07-06 06:52:22 --> Output Class Initialized
INFO - 2022-07-06 06:52:22 --> Security Class Initialized
DEBUG - 2022-07-06 06:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:52:22 --> Input Class Initialized
INFO - 2022-07-06 06:52:22 --> Language Class Initialized
INFO - 2022-07-06 06:52:22 --> Loader Class Initialized
INFO - 2022-07-06 06:52:22 --> Helper loaded: url_helper
INFO - 2022-07-06 06:52:22 --> Helper loaded: file_helper
INFO - 2022-07-06 06:52:22 --> Database Driver Class Initialized
INFO - 2022-07-06 06:52:22 --> Email Class Initialized
DEBUG - 2022-07-06 06:52:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:52:22 --> Controller Class Initialized
INFO - 2022-07-06 06:52:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:52:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:52:22 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-06 06:52:22 --> Final output sent to browser
DEBUG - 2022-07-06 06:52:22 --> Total execution time: 0.0869
INFO - 2022-07-06 06:52:27 --> Config Class Initialized
INFO - 2022-07-06 06:52:27 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:52:27 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:52:27 --> Utf8 Class Initialized
INFO - 2022-07-06 06:52:27 --> URI Class Initialized
INFO - 2022-07-06 06:52:27 --> Router Class Initialized
INFO - 2022-07-06 06:52:27 --> Output Class Initialized
INFO - 2022-07-06 06:52:27 --> Security Class Initialized
DEBUG - 2022-07-06 06:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:52:27 --> Input Class Initialized
INFO - 2022-07-06 06:52:27 --> Language Class Initialized
INFO - 2022-07-06 06:52:27 --> Loader Class Initialized
INFO - 2022-07-06 06:52:27 --> Helper loaded: url_helper
INFO - 2022-07-06 06:52:27 --> Helper loaded: file_helper
INFO - 2022-07-06 06:52:27 --> Database Driver Class Initialized
INFO - 2022-07-06 06:52:27 --> Email Class Initialized
DEBUG - 2022-07-06 06:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:52:27 --> Controller Class Initialized
INFO - 2022-07-06 06:52:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:52:27 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:52:27 --> Final output sent to browser
DEBUG - 2022-07-06 06:52:27 --> Total execution time: 0.0191
INFO - 2022-07-06 06:52:27 --> Config Class Initialized
INFO - 2022-07-06 06:52:27 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:52:27 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:52:27 --> Utf8 Class Initialized
INFO - 2022-07-06 06:52:27 --> URI Class Initialized
INFO - 2022-07-06 06:52:27 --> Router Class Initialized
INFO - 2022-07-06 06:52:27 --> Output Class Initialized
INFO - 2022-07-06 06:52:27 --> Security Class Initialized
DEBUG - 2022-07-06 06:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:52:27 --> Input Class Initialized
INFO - 2022-07-06 06:52:27 --> Language Class Initialized
INFO - 2022-07-06 06:52:27 --> Loader Class Initialized
INFO - 2022-07-06 06:52:27 --> Helper loaded: url_helper
INFO - 2022-07-06 06:52:27 --> Helper loaded: file_helper
INFO - 2022-07-06 06:52:27 --> Database Driver Class Initialized
INFO - 2022-07-06 06:52:27 --> Email Class Initialized
DEBUG - 2022-07-06 06:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:52:27 --> Controller Class Initialized
INFO - 2022-07-06 06:52:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:52:27 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:52:27 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-06 06:52:27 --> Final output sent to browser
DEBUG - 2022-07-06 06:52:27 --> Total execution time: 0.0327
INFO - 2022-07-06 06:52:30 --> Config Class Initialized
INFO - 2022-07-06 06:52:30 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:52:30 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:52:30 --> Utf8 Class Initialized
INFO - 2022-07-06 06:52:30 --> URI Class Initialized
INFO - 2022-07-06 06:52:30 --> Router Class Initialized
INFO - 2022-07-06 06:52:30 --> Output Class Initialized
INFO - 2022-07-06 06:52:30 --> Security Class Initialized
DEBUG - 2022-07-06 06:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:52:30 --> Input Class Initialized
INFO - 2022-07-06 06:52:30 --> Language Class Initialized
INFO - 2022-07-06 06:52:30 --> Loader Class Initialized
INFO - 2022-07-06 06:52:30 --> Helper loaded: url_helper
INFO - 2022-07-06 06:52:30 --> Helper loaded: file_helper
INFO - 2022-07-06 06:52:30 --> Database Driver Class Initialized
INFO - 2022-07-06 06:52:30 --> Email Class Initialized
DEBUG - 2022-07-06 06:52:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:52:30 --> Controller Class Initialized
INFO - 2022-07-06 06:52:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:52:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:52:30 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-06 06:52:30 --> Final output sent to browser
DEBUG - 2022-07-06 06:52:30 --> Total execution time: 0.0195
INFO - 2022-07-06 06:53:08 --> Config Class Initialized
INFO - 2022-07-06 06:53:08 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:53:08 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:53:08 --> Utf8 Class Initialized
INFO - 2022-07-06 06:53:08 --> URI Class Initialized
INFO - 2022-07-06 06:53:08 --> Router Class Initialized
INFO - 2022-07-06 06:53:08 --> Output Class Initialized
INFO - 2022-07-06 06:53:08 --> Security Class Initialized
DEBUG - 2022-07-06 06:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:53:08 --> Input Class Initialized
INFO - 2022-07-06 06:53:08 --> Language Class Initialized
INFO - 2022-07-06 06:53:08 --> Loader Class Initialized
INFO - 2022-07-06 06:53:08 --> Helper loaded: url_helper
INFO - 2022-07-06 06:53:08 --> Helper loaded: file_helper
INFO - 2022-07-06 06:53:08 --> Database Driver Class Initialized
INFO - 2022-07-06 06:53:08 --> Email Class Initialized
DEBUG - 2022-07-06 06:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:53:08 --> Controller Class Initialized
INFO - 2022-07-06 06:53:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:53:08 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:53:08 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-06 06:53:08 --> Final output sent to browser
DEBUG - 2022-07-06 06:53:08 --> Total execution time: 0.0414
INFO - 2022-07-06 06:53:11 --> Config Class Initialized
INFO - 2022-07-06 06:53:11 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:53:11 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:53:11 --> Utf8 Class Initialized
INFO - 2022-07-06 06:53:11 --> URI Class Initialized
INFO - 2022-07-06 06:53:11 --> Router Class Initialized
INFO - 2022-07-06 06:53:11 --> Output Class Initialized
INFO - 2022-07-06 06:53:11 --> Security Class Initialized
DEBUG - 2022-07-06 06:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:53:11 --> Input Class Initialized
INFO - 2022-07-06 06:53:11 --> Language Class Initialized
INFO - 2022-07-06 06:53:11 --> Loader Class Initialized
INFO - 2022-07-06 06:53:11 --> Helper loaded: url_helper
INFO - 2022-07-06 06:53:11 --> Helper loaded: file_helper
INFO - 2022-07-06 06:53:11 --> Database Driver Class Initialized
INFO - 2022-07-06 06:53:11 --> Email Class Initialized
DEBUG - 2022-07-06 06:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:53:11 --> Controller Class Initialized
INFO - 2022-07-06 06:53:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:53:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:53:11 --> Final output sent to browser
DEBUG - 2022-07-06 06:53:11 --> Total execution time: 0.1192
INFO - 2022-07-06 06:53:11 --> Config Class Initialized
INFO - 2022-07-06 06:53:11 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:53:11 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:53:11 --> Utf8 Class Initialized
INFO - 2022-07-06 06:53:11 --> URI Class Initialized
INFO - 2022-07-06 06:53:11 --> Router Class Initialized
INFO - 2022-07-06 06:53:11 --> Output Class Initialized
INFO - 2022-07-06 06:53:11 --> Security Class Initialized
DEBUG - 2022-07-06 06:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:53:11 --> Input Class Initialized
INFO - 2022-07-06 06:53:11 --> Language Class Initialized
INFO - 2022-07-06 06:53:11 --> Loader Class Initialized
INFO - 2022-07-06 06:53:11 --> Helper loaded: url_helper
INFO - 2022-07-06 06:53:11 --> Helper loaded: file_helper
INFO - 2022-07-06 06:53:11 --> Database Driver Class Initialized
INFO - 2022-07-06 06:53:11 --> Email Class Initialized
DEBUG - 2022-07-06 06:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:53:11 --> Controller Class Initialized
INFO - 2022-07-06 06:53:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:53:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:53:11 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-06 06:53:11 --> Final output sent to browser
DEBUG - 2022-07-06 06:53:11 --> Total execution time: 0.0231
INFO - 2022-07-06 06:53:15 --> Config Class Initialized
INFO - 2022-07-06 06:53:15 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:53:15 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:53:15 --> Utf8 Class Initialized
INFO - 2022-07-06 06:53:15 --> URI Class Initialized
INFO - 2022-07-06 06:53:15 --> Router Class Initialized
INFO - 2022-07-06 06:53:15 --> Output Class Initialized
INFO - 2022-07-06 06:53:15 --> Security Class Initialized
DEBUG - 2022-07-06 06:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:53:15 --> Input Class Initialized
INFO - 2022-07-06 06:53:15 --> Language Class Initialized
INFO - 2022-07-06 06:53:15 --> Loader Class Initialized
INFO - 2022-07-06 06:53:15 --> Helper loaded: url_helper
INFO - 2022-07-06 06:53:15 --> Helper loaded: file_helper
INFO - 2022-07-06 06:53:15 --> Database Driver Class Initialized
INFO - 2022-07-06 06:53:15 --> Email Class Initialized
DEBUG - 2022-07-06 06:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:53:15 --> Controller Class Initialized
INFO - 2022-07-06 06:53:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:53:15 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:53:15 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-06 06:53:15 --> Final output sent to browser
DEBUG - 2022-07-06 06:53:15 --> Total execution time: 0.0402
INFO - 2022-07-06 06:53:20 --> Config Class Initialized
INFO - 2022-07-06 06:53:20 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:53:20 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:53:20 --> Utf8 Class Initialized
INFO - 2022-07-06 06:53:20 --> URI Class Initialized
INFO - 2022-07-06 06:53:20 --> Router Class Initialized
INFO - 2022-07-06 06:53:20 --> Output Class Initialized
INFO - 2022-07-06 06:53:20 --> Security Class Initialized
DEBUG - 2022-07-06 06:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:53:20 --> Input Class Initialized
INFO - 2022-07-06 06:53:20 --> Language Class Initialized
INFO - 2022-07-06 06:53:20 --> Loader Class Initialized
INFO - 2022-07-06 06:53:20 --> Helper loaded: url_helper
INFO - 2022-07-06 06:53:20 --> Helper loaded: file_helper
INFO - 2022-07-06 06:53:20 --> Database Driver Class Initialized
INFO - 2022-07-06 06:53:20 --> Email Class Initialized
DEBUG - 2022-07-06 06:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:53:20 --> Controller Class Initialized
INFO - 2022-07-06 06:53:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:53:20 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:53:20 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-06 06:53:20 --> Final output sent to browser
DEBUG - 2022-07-06 06:53:20 --> Total execution time: 0.0207
INFO - 2022-07-06 06:53:28 --> Config Class Initialized
INFO - 2022-07-06 06:53:28 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:53:28 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:53:28 --> Utf8 Class Initialized
INFO - 2022-07-06 06:53:28 --> URI Class Initialized
INFO - 2022-07-06 06:53:28 --> Router Class Initialized
INFO - 2022-07-06 06:53:28 --> Output Class Initialized
INFO - 2022-07-06 06:53:28 --> Security Class Initialized
DEBUG - 2022-07-06 06:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:53:28 --> Input Class Initialized
INFO - 2022-07-06 06:53:28 --> Language Class Initialized
INFO - 2022-07-06 06:53:28 --> Loader Class Initialized
INFO - 2022-07-06 06:53:28 --> Helper loaded: url_helper
INFO - 2022-07-06 06:53:28 --> Helper loaded: file_helper
INFO - 2022-07-06 06:53:28 --> Database Driver Class Initialized
INFO - 2022-07-06 06:53:28 --> Email Class Initialized
DEBUG - 2022-07-06 06:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:53:28 --> Controller Class Initialized
INFO - 2022-07-06 06:53:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:53:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:53:28 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-06 06:53:28 --> Final output sent to browser
DEBUG - 2022-07-06 06:53:28 --> Total execution time: 0.0338
INFO - 2022-07-06 06:53:29 --> Config Class Initialized
INFO - 2022-07-06 06:53:29 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:53:29 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:53:29 --> Utf8 Class Initialized
INFO - 2022-07-06 06:53:29 --> URI Class Initialized
INFO - 2022-07-06 06:53:29 --> Router Class Initialized
INFO - 2022-07-06 06:53:29 --> Output Class Initialized
INFO - 2022-07-06 06:53:29 --> Security Class Initialized
DEBUG - 2022-07-06 06:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:53:29 --> Input Class Initialized
INFO - 2022-07-06 06:53:29 --> Language Class Initialized
INFO - 2022-07-06 06:53:29 --> Loader Class Initialized
INFO - 2022-07-06 06:53:29 --> Helper loaded: url_helper
INFO - 2022-07-06 06:53:29 --> Helper loaded: file_helper
INFO - 2022-07-06 06:53:29 --> Database Driver Class Initialized
INFO - 2022-07-06 06:53:29 --> Email Class Initialized
DEBUG - 2022-07-06 06:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:53:29 --> Controller Class Initialized
INFO - 2022-07-06 06:53:29 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:53:29 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:53:29 --> Final output sent to browser
DEBUG - 2022-07-06 06:53:29 --> Total execution time: 0.0271
INFO - 2022-07-06 06:53:29 --> Config Class Initialized
INFO - 2022-07-06 06:53:29 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:53:29 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:53:29 --> Utf8 Class Initialized
INFO - 2022-07-06 06:53:29 --> URI Class Initialized
INFO - 2022-07-06 06:53:29 --> Router Class Initialized
INFO - 2022-07-06 06:53:29 --> Output Class Initialized
INFO - 2022-07-06 06:53:29 --> Security Class Initialized
DEBUG - 2022-07-06 06:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:53:29 --> Input Class Initialized
INFO - 2022-07-06 06:53:29 --> Language Class Initialized
INFO - 2022-07-06 06:53:29 --> Loader Class Initialized
INFO - 2022-07-06 06:53:29 --> Helper loaded: url_helper
INFO - 2022-07-06 06:53:29 --> Helper loaded: file_helper
INFO - 2022-07-06 06:53:29 --> Database Driver Class Initialized
INFO - 2022-07-06 06:53:29 --> Email Class Initialized
DEBUG - 2022-07-06 06:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:53:29 --> Controller Class Initialized
INFO - 2022-07-06 06:53:29 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:53:29 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:53:29 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-06 06:53:29 --> Final output sent to browser
DEBUG - 2022-07-06 06:53:29 --> Total execution time: 0.0157
INFO - 2022-07-06 06:53:31 --> Config Class Initialized
INFO - 2022-07-06 06:53:31 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:53:31 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:53:31 --> Utf8 Class Initialized
INFO - 2022-07-06 06:53:31 --> URI Class Initialized
INFO - 2022-07-06 06:53:31 --> Router Class Initialized
INFO - 2022-07-06 06:53:31 --> Output Class Initialized
INFO - 2022-07-06 06:53:31 --> Security Class Initialized
DEBUG - 2022-07-06 06:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:53:31 --> Input Class Initialized
INFO - 2022-07-06 06:53:31 --> Language Class Initialized
INFO - 2022-07-06 06:53:31 --> Loader Class Initialized
INFO - 2022-07-06 06:53:31 --> Helper loaded: url_helper
INFO - 2022-07-06 06:53:31 --> Helper loaded: file_helper
INFO - 2022-07-06 06:53:31 --> Database Driver Class Initialized
INFO - 2022-07-06 06:53:31 --> Email Class Initialized
DEBUG - 2022-07-06 06:53:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:53:31 --> Controller Class Initialized
INFO - 2022-07-06 06:53:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:53:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:53:31 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-06 06:53:31 --> Final output sent to browser
DEBUG - 2022-07-06 06:53:31 --> Total execution time: 0.0207
INFO - 2022-07-06 06:54:04 --> Config Class Initialized
INFO - 2022-07-06 06:54:04 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:54:04 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:54:04 --> Utf8 Class Initialized
INFO - 2022-07-06 06:54:04 --> URI Class Initialized
INFO - 2022-07-06 06:54:04 --> Router Class Initialized
INFO - 2022-07-06 06:54:04 --> Output Class Initialized
INFO - 2022-07-06 06:54:04 --> Security Class Initialized
DEBUG - 2022-07-06 06:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:54:04 --> Input Class Initialized
INFO - 2022-07-06 06:54:04 --> Language Class Initialized
INFO - 2022-07-06 06:54:04 --> Loader Class Initialized
INFO - 2022-07-06 06:54:04 --> Helper loaded: url_helper
INFO - 2022-07-06 06:54:04 --> Helper loaded: file_helper
INFO - 2022-07-06 06:54:04 --> Database Driver Class Initialized
INFO - 2022-07-06 06:54:04 --> Email Class Initialized
DEBUG - 2022-07-06 06:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:54:04 --> Controller Class Initialized
INFO - 2022-07-06 06:54:04 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:54:04 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:54:04 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-06 06:54:04 --> Final output sent to browser
DEBUG - 2022-07-06 06:54:04 --> Total execution time: 0.0295
INFO - 2022-07-06 06:57:15 --> Config Class Initialized
INFO - 2022-07-06 06:57:15 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:57:15 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:57:15 --> Utf8 Class Initialized
INFO - 2022-07-06 06:57:15 --> URI Class Initialized
INFO - 2022-07-06 06:57:15 --> Router Class Initialized
INFO - 2022-07-06 06:57:15 --> Output Class Initialized
INFO - 2022-07-06 06:57:15 --> Security Class Initialized
DEBUG - 2022-07-06 06:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:57:15 --> Input Class Initialized
INFO - 2022-07-06 06:57:15 --> Language Class Initialized
INFO - 2022-07-06 06:57:15 --> Loader Class Initialized
INFO - 2022-07-06 06:57:15 --> Helper loaded: url_helper
INFO - 2022-07-06 06:57:15 --> Helper loaded: file_helper
INFO - 2022-07-06 06:57:15 --> Database Driver Class Initialized
INFO - 2022-07-06 06:57:16 --> Email Class Initialized
DEBUG - 2022-07-06 06:57:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:57:16 --> Controller Class Initialized
INFO - 2022-07-06 06:57:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:57:16 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 06:57:16 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-06 06:57:16 --> Final output sent to browser
DEBUG - 2022-07-06 06:57:16 --> Total execution time: 0.2128
INFO - 2022-07-06 06:57:25 --> Config Class Initialized
INFO - 2022-07-06 06:57:25 --> Hooks Class Initialized
DEBUG - 2022-07-06 06:57:25 --> UTF-8 Support Enabled
INFO - 2022-07-06 06:57:25 --> Utf8 Class Initialized
INFO - 2022-07-06 06:57:25 --> URI Class Initialized
INFO - 2022-07-06 06:57:25 --> Router Class Initialized
INFO - 2022-07-06 06:57:25 --> Output Class Initialized
INFO - 2022-07-06 06:57:25 --> Security Class Initialized
DEBUG - 2022-07-06 06:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 06:57:25 --> Input Class Initialized
INFO - 2022-07-06 06:57:25 --> Language Class Initialized
INFO - 2022-07-06 06:57:25 --> Loader Class Initialized
INFO - 2022-07-06 06:57:25 --> Helper loaded: url_helper
INFO - 2022-07-06 06:57:25 --> Helper loaded: file_helper
INFO - 2022-07-06 06:57:25 --> Database Driver Class Initialized
INFO - 2022-07-06 06:57:25 --> Email Class Initialized
DEBUG - 2022-07-06 06:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 06:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 06:57:25 --> Controller Class Initialized
INFO - 2022-07-06 06:57:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 06:57:25 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:14:57 --> Config Class Initialized
INFO - 2022-07-06 07:14:57 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:14:57 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:14:57 --> Utf8 Class Initialized
INFO - 2022-07-06 07:14:57 --> URI Class Initialized
INFO - 2022-07-06 07:14:57 --> Router Class Initialized
INFO - 2022-07-06 07:14:57 --> Output Class Initialized
INFO - 2022-07-06 07:14:57 --> Security Class Initialized
DEBUG - 2022-07-06 07:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:14:57 --> Input Class Initialized
INFO - 2022-07-06 07:14:57 --> Language Class Initialized
INFO - 2022-07-06 07:14:57 --> Loader Class Initialized
INFO - 2022-07-06 07:14:57 --> Helper loaded: url_helper
INFO - 2022-07-06 07:14:57 --> Helper loaded: file_helper
INFO - 2022-07-06 07:14:57 --> Database Driver Class Initialized
INFO - 2022-07-06 07:14:57 --> Email Class Initialized
DEBUG - 2022-07-06 07:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:14:57 --> Controller Class Initialized
INFO - 2022-07-06 07:14:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:14:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:14:57 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-07-06 07:14:57 --> Final output sent to browser
DEBUG - 2022-07-06 07:14:57 --> Total execution time: 0.1746
INFO - 2022-07-06 07:14:59 --> Config Class Initialized
INFO - 2022-07-06 07:14:59 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:14:59 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:14:59 --> Utf8 Class Initialized
INFO - 2022-07-06 07:14:59 --> URI Class Initialized
INFO - 2022-07-06 07:14:59 --> Router Class Initialized
INFO - 2022-07-06 07:14:59 --> Output Class Initialized
INFO - 2022-07-06 07:14:59 --> Security Class Initialized
DEBUG - 2022-07-06 07:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:14:59 --> Input Class Initialized
INFO - 2022-07-06 07:14:59 --> Language Class Initialized
INFO - 2022-07-06 07:14:59 --> Loader Class Initialized
INFO - 2022-07-06 07:14:59 --> Helper loaded: url_helper
INFO - 2022-07-06 07:14:59 --> Helper loaded: file_helper
INFO - 2022-07-06 07:14:59 --> Database Driver Class Initialized
INFO - 2022-07-06 07:14:59 --> Email Class Initialized
DEBUG - 2022-07-06 07:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:14:59 --> Controller Class Initialized
INFO - 2022-07-06 07:14:59 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:14:59 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:14:59 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-07-06 07:14:59 --> Final output sent to browser
DEBUG - 2022-07-06 07:14:59 --> Total execution time: 0.2026
INFO - 2022-07-06 07:15:00 --> Config Class Initialized
INFO - 2022-07-06 07:15:00 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:15:00 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:15:00 --> Utf8 Class Initialized
INFO - 2022-07-06 07:15:00 --> URI Class Initialized
INFO - 2022-07-06 07:15:00 --> Router Class Initialized
INFO - 2022-07-06 07:15:00 --> Output Class Initialized
INFO - 2022-07-06 07:15:00 --> Security Class Initialized
DEBUG - 2022-07-06 07:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:15:00 --> Input Class Initialized
INFO - 2022-07-06 07:15:00 --> Language Class Initialized
INFO - 2022-07-06 07:15:00 --> Loader Class Initialized
INFO - 2022-07-06 07:15:00 --> Helper loaded: url_helper
INFO - 2022-07-06 07:15:00 --> Helper loaded: file_helper
INFO - 2022-07-06 07:15:00 --> Database Driver Class Initialized
INFO - 2022-07-06 07:15:00 --> Email Class Initialized
DEBUG - 2022-07-06 07:15:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:15:00 --> Controller Class Initialized
INFO - 2022-07-06 07:15:00 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:15:00 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:15:00 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-07-06 07:15:00 --> Final output sent to browser
DEBUG - 2022-07-06 07:15:00 --> Total execution time: 0.1471
INFO - 2022-07-06 07:15:01 --> Config Class Initialized
INFO - 2022-07-06 07:15:01 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:15:01 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:15:01 --> Utf8 Class Initialized
INFO - 2022-07-06 07:15:01 --> URI Class Initialized
INFO - 2022-07-06 07:15:01 --> Router Class Initialized
INFO - 2022-07-06 07:15:01 --> Output Class Initialized
INFO - 2022-07-06 07:15:01 --> Security Class Initialized
DEBUG - 2022-07-06 07:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:15:01 --> Input Class Initialized
INFO - 2022-07-06 07:15:01 --> Language Class Initialized
INFO - 2022-07-06 07:15:01 --> Loader Class Initialized
INFO - 2022-07-06 07:15:01 --> Helper loaded: url_helper
INFO - 2022-07-06 07:15:01 --> Helper loaded: file_helper
INFO - 2022-07-06 07:15:01 --> Database Driver Class Initialized
INFO - 2022-07-06 07:15:01 --> Email Class Initialized
DEBUG - 2022-07-06 07:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:15:01 --> Controller Class Initialized
INFO - 2022-07-06 07:15:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:15:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:15:01 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-07-06 07:15:01 --> Final output sent to browser
DEBUG - 2022-07-06 07:15:01 --> Total execution time: 0.0412
INFO - 2022-07-06 07:15:01 --> Config Class Initialized
INFO - 2022-07-06 07:15:01 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:15:01 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:15:01 --> Utf8 Class Initialized
INFO - 2022-07-06 07:15:01 --> URI Class Initialized
INFO - 2022-07-06 07:15:01 --> Router Class Initialized
INFO - 2022-07-06 07:15:01 --> Output Class Initialized
INFO - 2022-07-06 07:15:01 --> Security Class Initialized
DEBUG - 2022-07-06 07:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:15:01 --> Input Class Initialized
INFO - 2022-07-06 07:15:01 --> Language Class Initialized
INFO - 2022-07-06 07:15:01 --> Loader Class Initialized
INFO - 2022-07-06 07:15:01 --> Helper loaded: url_helper
INFO - 2022-07-06 07:15:01 --> Helper loaded: file_helper
INFO - 2022-07-06 07:15:01 --> Database Driver Class Initialized
INFO - 2022-07-06 07:15:01 --> Email Class Initialized
DEBUG - 2022-07-06 07:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:15:01 --> Controller Class Initialized
INFO - 2022-07-06 07:15:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:15:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:15:01 --> Final output sent to browser
DEBUG - 2022-07-06 07:15:01 --> Total execution time: 0.0487
INFO - 2022-07-06 07:15:02 --> Config Class Initialized
INFO - 2022-07-06 07:15:02 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:15:02 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:15:02 --> Utf8 Class Initialized
INFO - 2022-07-06 07:15:02 --> URI Class Initialized
INFO - 2022-07-06 07:15:02 --> Router Class Initialized
INFO - 2022-07-06 07:15:02 --> Output Class Initialized
INFO - 2022-07-06 07:15:02 --> Security Class Initialized
DEBUG - 2022-07-06 07:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:15:02 --> Input Class Initialized
INFO - 2022-07-06 07:15:02 --> Language Class Initialized
INFO - 2022-07-06 07:15:02 --> Loader Class Initialized
INFO - 2022-07-06 07:15:02 --> Helper loaded: url_helper
INFO - 2022-07-06 07:15:02 --> Helper loaded: file_helper
INFO - 2022-07-06 07:15:02 --> Database Driver Class Initialized
INFO - 2022-07-06 07:15:02 --> Email Class Initialized
DEBUG - 2022-07-06 07:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:15:02 --> Controller Class Initialized
INFO - 2022-07-06 07:15:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:15:02 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:15:02 --> Final output sent to browser
DEBUG - 2022-07-06 07:15:02 --> Total execution time: 0.1966
INFO - 2022-07-06 07:15:03 --> Config Class Initialized
INFO - 2022-07-06 07:15:03 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:15:03 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:15:03 --> Utf8 Class Initialized
INFO - 2022-07-06 07:15:03 --> URI Class Initialized
INFO - 2022-07-06 07:15:03 --> Router Class Initialized
INFO - 2022-07-06 07:15:03 --> Output Class Initialized
INFO - 2022-07-06 07:15:03 --> Security Class Initialized
DEBUG - 2022-07-06 07:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:15:03 --> Input Class Initialized
INFO - 2022-07-06 07:15:03 --> Language Class Initialized
INFO - 2022-07-06 07:15:03 --> Loader Class Initialized
INFO - 2022-07-06 07:15:03 --> Helper loaded: url_helper
INFO - 2022-07-06 07:15:03 --> Helper loaded: file_helper
INFO - 2022-07-06 07:15:03 --> Database Driver Class Initialized
INFO - 2022-07-06 07:15:03 --> Email Class Initialized
DEBUG - 2022-07-06 07:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:15:03 --> Controller Class Initialized
INFO - 2022-07-06 07:15:03 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:15:03 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:15:03 --> Final output sent to browser
DEBUG - 2022-07-06 07:15:03 --> Total execution time: 0.1500
INFO - 2022-07-06 07:15:03 --> Config Class Initialized
INFO - 2022-07-06 07:15:03 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:15:03 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:15:03 --> Utf8 Class Initialized
INFO - 2022-07-06 07:15:03 --> URI Class Initialized
INFO - 2022-07-06 07:15:03 --> Router Class Initialized
INFO - 2022-07-06 07:15:03 --> Output Class Initialized
INFO - 2022-07-06 07:15:03 --> Security Class Initialized
DEBUG - 2022-07-06 07:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:15:03 --> Input Class Initialized
INFO - 2022-07-06 07:15:03 --> Language Class Initialized
INFO - 2022-07-06 07:15:03 --> Loader Class Initialized
INFO - 2022-07-06 07:15:03 --> Helper loaded: url_helper
INFO - 2022-07-06 07:15:03 --> Helper loaded: file_helper
INFO - 2022-07-06 07:15:03 --> Database Driver Class Initialized
INFO - 2022-07-06 07:15:03 --> Email Class Initialized
DEBUG - 2022-07-06 07:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:15:03 --> Controller Class Initialized
INFO - 2022-07-06 07:15:03 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:15:03 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:15:03 --> Final output sent to browser
DEBUG - 2022-07-06 07:15:03 --> Total execution time: 0.0451
INFO - 2022-07-06 07:15:03 --> Config Class Initialized
INFO - 2022-07-06 07:15:03 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:15:03 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:15:03 --> Utf8 Class Initialized
INFO - 2022-07-06 07:15:03 --> URI Class Initialized
INFO - 2022-07-06 07:15:03 --> Router Class Initialized
INFO - 2022-07-06 07:15:03 --> Output Class Initialized
INFO - 2022-07-06 07:15:03 --> Security Class Initialized
DEBUG - 2022-07-06 07:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:15:03 --> Input Class Initialized
INFO - 2022-07-06 07:15:03 --> Language Class Initialized
INFO - 2022-07-06 07:15:03 --> Loader Class Initialized
INFO - 2022-07-06 07:15:03 --> Helper loaded: url_helper
INFO - 2022-07-06 07:15:03 --> Helper loaded: file_helper
INFO - 2022-07-06 07:15:03 --> Database Driver Class Initialized
INFO - 2022-07-06 07:15:03 --> Email Class Initialized
DEBUG - 2022-07-06 07:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:15:03 --> Controller Class Initialized
INFO - 2022-07-06 07:15:03 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:15:03 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:15:03 --> Final output sent to browser
DEBUG - 2022-07-06 07:15:03 --> Total execution time: 0.0316
INFO - 2022-07-06 07:15:03 --> Config Class Initialized
INFO - 2022-07-06 07:15:03 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:15:03 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:15:03 --> Utf8 Class Initialized
INFO - 2022-07-06 07:15:03 --> URI Class Initialized
INFO - 2022-07-06 07:15:03 --> Router Class Initialized
INFO - 2022-07-06 07:15:03 --> Output Class Initialized
INFO - 2022-07-06 07:15:03 --> Security Class Initialized
DEBUG - 2022-07-06 07:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:15:03 --> Input Class Initialized
INFO - 2022-07-06 07:15:03 --> Language Class Initialized
INFO - 2022-07-06 07:15:03 --> Loader Class Initialized
INFO - 2022-07-06 07:15:03 --> Helper loaded: url_helper
INFO - 2022-07-06 07:15:03 --> Helper loaded: file_helper
INFO - 2022-07-06 07:15:03 --> Database Driver Class Initialized
INFO - 2022-07-06 07:15:03 --> Email Class Initialized
DEBUG - 2022-07-06 07:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:15:04 --> Controller Class Initialized
INFO - 2022-07-06 07:15:04 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:15:04 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:15:04 --> Final output sent to browser
DEBUG - 2022-07-06 07:15:04 --> Total execution time: 0.0169
INFO - 2022-07-06 07:15:04 --> Config Class Initialized
INFO - 2022-07-06 07:15:04 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:15:04 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:15:04 --> Utf8 Class Initialized
INFO - 2022-07-06 07:15:04 --> URI Class Initialized
INFO - 2022-07-06 07:15:04 --> Router Class Initialized
INFO - 2022-07-06 07:15:04 --> Output Class Initialized
INFO - 2022-07-06 07:15:04 --> Security Class Initialized
DEBUG - 2022-07-06 07:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:15:04 --> Input Class Initialized
INFO - 2022-07-06 07:15:04 --> Language Class Initialized
INFO - 2022-07-06 07:15:04 --> Loader Class Initialized
INFO - 2022-07-06 07:15:04 --> Helper loaded: url_helper
INFO - 2022-07-06 07:15:04 --> Helper loaded: file_helper
INFO - 2022-07-06 07:15:04 --> Database Driver Class Initialized
INFO - 2022-07-06 07:15:04 --> Email Class Initialized
DEBUG - 2022-07-06 07:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:15:04 --> Controller Class Initialized
INFO - 2022-07-06 07:15:04 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:15:04 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:15:04 --> Final output sent to browser
DEBUG - 2022-07-06 07:15:04 --> Total execution time: 0.0340
INFO - 2022-07-06 07:15:04 --> Config Class Initialized
INFO - 2022-07-06 07:15:04 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:15:04 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:15:04 --> Utf8 Class Initialized
INFO - 2022-07-06 07:15:04 --> URI Class Initialized
INFO - 2022-07-06 07:15:04 --> Router Class Initialized
INFO - 2022-07-06 07:15:04 --> Output Class Initialized
INFO - 2022-07-06 07:15:04 --> Security Class Initialized
DEBUG - 2022-07-06 07:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:15:04 --> Input Class Initialized
INFO - 2022-07-06 07:15:04 --> Language Class Initialized
INFO - 2022-07-06 07:15:04 --> Loader Class Initialized
INFO - 2022-07-06 07:15:04 --> Helper loaded: url_helper
INFO - 2022-07-06 07:15:04 --> Helper loaded: file_helper
INFO - 2022-07-06 07:15:04 --> Database Driver Class Initialized
INFO - 2022-07-06 07:15:04 --> Email Class Initialized
DEBUG - 2022-07-06 07:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:15:04 --> Controller Class Initialized
INFO - 2022-07-06 07:15:04 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:15:04 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:15:04 --> Final output sent to browser
DEBUG - 2022-07-06 07:15:04 --> Total execution time: 0.0242
INFO - 2022-07-06 07:15:04 --> Config Class Initialized
INFO - 2022-07-06 07:15:04 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:15:04 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:15:04 --> Utf8 Class Initialized
INFO - 2022-07-06 07:15:04 --> URI Class Initialized
INFO - 2022-07-06 07:15:04 --> Router Class Initialized
INFO - 2022-07-06 07:15:04 --> Output Class Initialized
INFO - 2022-07-06 07:15:04 --> Security Class Initialized
DEBUG - 2022-07-06 07:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:15:04 --> Input Class Initialized
INFO - 2022-07-06 07:15:04 --> Language Class Initialized
INFO - 2022-07-06 07:15:04 --> Loader Class Initialized
INFO - 2022-07-06 07:15:04 --> Helper loaded: url_helper
INFO - 2022-07-06 07:15:04 --> Helper loaded: file_helper
INFO - 2022-07-06 07:15:04 --> Database Driver Class Initialized
INFO - 2022-07-06 07:15:04 --> Email Class Initialized
DEBUG - 2022-07-06 07:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:15:04 --> Controller Class Initialized
INFO - 2022-07-06 07:15:04 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:15:04 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:15:04 --> Final output sent to browser
DEBUG - 2022-07-06 07:15:04 --> Total execution time: 0.0170
INFO - 2022-07-06 07:15:04 --> Config Class Initialized
INFO - 2022-07-06 07:15:04 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:15:04 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:15:04 --> Utf8 Class Initialized
INFO - 2022-07-06 07:15:04 --> URI Class Initialized
INFO - 2022-07-06 07:15:04 --> Router Class Initialized
INFO - 2022-07-06 07:15:04 --> Output Class Initialized
INFO - 2022-07-06 07:15:04 --> Security Class Initialized
DEBUG - 2022-07-06 07:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:15:04 --> Input Class Initialized
INFO - 2022-07-06 07:15:04 --> Language Class Initialized
INFO - 2022-07-06 07:15:04 --> Loader Class Initialized
INFO - 2022-07-06 07:15:04 --> Helper loaded: url_helper
INFO - 2022-07-06 07:15:04 --> Helper loaded: file_helper
INFO - 2022-07-06 07:15:04 --> Database Driver Class Initialized
INFO - 2022-07-06 07:15:04 --> Email Class Initialized
DEBUG - 2022-07-06 07:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:15:04 --> Controller Class Initialized
INFO - 2022-07-06 07:15:04 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:15:04 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:15:04 --> Final output sent to browser
DEBUG - 2022-07-06 07:15:04 --> Total execution time: 0.1469
INFO - 2022-07-06 07:15:04 --> Config Class Initialized
INFO - 2022-07-06 07:15:04 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:15:04 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:15:04 --> Utf8 Class Initialized
INFO - 2022-07-06 07:15:04 --> URI Class Initialized
INFO - 2022-07-06 07:15:04 --> Router Class Initialized
INFO - 2022-07-06 07:15:04 --> Output Class Initialized
INFO - 2022-07-06 07:15:04 --> Security Class Initialized
DEBUG - 2022-07-06 07:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:15:04 --> Input Class Initialized
INFO - 2022-07-06 07:15:04 --> Language Class Initialized
INFO - 2022-07-06 07:15:04 --> Loader Class Initialized
INFO - 2022-07-06 07:15:04 --> Helper loaded: url_helper
INFO - 2022-07-06 07:15:04 --> Helper loaded: file_helper
INFO - 2022-07-06 07:15:04 --> Database Driver Class Initialized
INFO - 2022-07-06 07:15:04 --> Email Class Initialized
DEBUG - 2022-07-06 07:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:15:04 --> Controller Class Initialized
INFO - 2022-07-06 07:15:04 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:15:04 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:15:04 --> Final output sent to browser
DEBUG - 2022-07-06 07:15:04 --> Total execution time: 0.0519
INFO - 2022-07-06 07:15:06 --> Config Class Initialized
INFO - 2022-07-06 07:15:06 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:15:06 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:15:06 --> Utf8 Class Initialized
INFO - 2022-07-06 07:15:06 --> URI Class Initialized
INFO - 2022-07-06 07:15:06 --> Router Class Initialized
INFO - 2022-07-06 07:15:06 --> Output Class Initialized
INFO - 2022-07-06 07:15:06 --> Security Class Initialized
DEBUG - 2022-07-06 07:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:15:06 --> Input Class Initialized
INFO - 2022-07-06 07:15:06 --> Language Class Initialized
INFO - 2022-07-06 07:15:06 --> Loader Class Initialized
INFO - 2022-07-06 07:15:06 --> Helper loaded: url_helper
INFO - 2022-07-06 07:15:06 --> Helper loaded: file_helper
INFO - 2022-07-06 07:15:06 --> Database Driver Class Initialized
INFO - 2022-07-06 07:15:06 --> Email Class Initialized
DEBUG - 2022-07-06 07:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:15:06 --> Controller Class Initialized
INFO - 2022-07-06 07:15:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:15:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-06 07:15:06 --> Severity: Notice --> Undefined variable: total C:\wamp64\www\qr\application\views\doc_screen\doctor.php 359
INFO - 2022-07-06 07:15:06 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-07-06 07:15:06 --> Final output sent to browser
DEBUG - 2022-07-06 07:15:06 --> Total execution time: 0.0500
INFO - 2022-07-06 07:15:09 --> Config Class Initialized
INFO - 2022-07-06 07:15:09 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:15:09 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:15:09 --> Utf8 Class Initialized
INFO - 2022-07-06 07:15:09 --> URI Class Initialized
INFO - 2022-07-06 07:15:09 --> Router Class Initialized
INFO - 2022-07-06 07:15:09 --> Output Class Initialized
INFO - 2022-07-06 07:15:09 --> Security Class Initialized
DEBUG - 2022-07-06 07:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:15:09 --> Input Class Initialized
INFO - 2022-07-06 07:15:09 --> Language Class Initialized
INFO - 2022-07-06 07:15:09 --> Loader Class Initialized
INFO - 2022-07-06 07:15:09 --> Helper loaded: url_helper
INFO - 2022-07-06 07:15:09 --> Helper loaded: file_helper
INFO - 2022-07-06 07:15:09 --> Database Driver Class Initialized
INFO - 2022-07-06 07:15:09 --> Email Class Initialized
DEBUG - 2022-07-06 07:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:15:09 --> Controller Class Initialized
INFO - 2022-07-06 07:15:09 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:15:09 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:15:09 --> Final output sent to browser
DEBUG - 2022-07-06 07:15:09 --> Total execution time: 0.0744
INFO - 2022-07-06 07:15:10 --> Config Class Initialized
INFO - 2022-07-06 07:15:10 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:15:10 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:15:10 --> Utf8 Class Initialized
INFO - 2022-07-06 07:15:10 --> URI Class Initialized
INFO - 2022-07-06 07:15:10 --> Router Class Initialized
INFO - 2022-07-06 07:15:10 --> Output Class Initialized
INFO - 2022-07-06 07:15:10 --> Security Class Initialized
DEBUG - 2022-07-06 07:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:15:10 --> Input Class Initialized
INFO - 2022-07-06 07:15:10 --> Language Class Initialized
INFO - 2022-07-06 07:15:10 --> Loader Class Initialized
INFO - 2022-07-06 07:15:10 --> Helper loaded: url_helper
INFO - 2022-07-06 07:15:10 --> Helper loaded: file_helper
INFO - 2022-07-06 07:15:10 --> Database Driver Class Initialized
INFO - 2022-07-06 07:15:10 --> Email Class Initialized
DEBUG - 2022-07-06 07:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:15:10 --> Controller Class Initialized
INFO - 2022-07-06 07:15:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:15:10 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:15:10 --> Final output sent to browser
DEBUG - 2022-07-06 07:15:10 --> Total execution time: 0.0398
INFO - 2022-07-06 07:15:10 --> Config Class Initialized
INFO - 2022-07-06 07:15:10 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:15:10 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:15:10 --> Utf8 Class Initialized
INFO - 2022-07-06 07:15:10 --> URI Class Initialized
INFO - 2022-07-06 07:15:10 --> Router Class Initialized
INFO - 2022-07-06 07:15:10 --> Output Class Initialized
INFO - 2022-07-06 07:15:10 --> Security Class Initialized
DEBUG - 2022-07-06 07:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:15:10 --> Input Class Initialized
INFO - 2022-07-06 07:15:10 --> Language Class Initialized
INFO - 2022-07-06 07:15:10 --> Loader Class Initialized
INFO - 2022-07-06 07:15:10 --> Helper loaded: url_helper
INFO - 2022-07-06 07:15:10 --> Helper loaded: file_helper
INFO - 2022-07-06 07:15:10 --> Database Driver Class Initialized
INFO - 2022-07-06 07:15:11 --> Email Class Initialized
DEBUG - 2022-07-06 07:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:15:11 --> Controller Class Initialized
INFO - 2022-07-06 07:15:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:15:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:15:11 --> Final output sent to browser
DEBUG - 2022-07-06 07:15:11 --> Total execution time: 0.1498
INFO - 2022-07-06 07:15:11 --> Config Class Initialized
INFO - 2022-07-06 07:15:11 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:15:11 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:15:11 --> Utf8 Class Initialized
INFO - 2022-07-06 07:15:11 --> URI Class Initialized
INFO - 2022-07-06 07:15:11 --> Router Class Initialized
INFO - 2022-07-06 07:15:11 --> Output Class Initialized
INFO - 2022-07-06 07:15:11 --> Security Class Initialized
DEBUG - 2022-07-06 07:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:15:11 --> Input Class Initialized
INFO - 2022-07-06 07:15:11 --> Language Class Initialized
INFO - 2022-07-06 07:15:11 --> Loader Class Initialized
INFO - 2022-07-06 07:15:11 --> Helper loaded: url_helper
INFO - 2022-07-06 07:15:11 --> Helper loaded: file_helper
INFO - 2022-07-06 07:15:11 --> Database Driver Class Initialized
INFO - 2022-07-06 07:15:11 --> Email Class Initialized
DEBUG - 2022-07-06 07:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:15:11 --> Controller Class Initialized
INFO - 2022-07-06 07:15:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:15:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:15:11 --> Final output sent to browser
DEBUG - 2022-07-06 07:15:11 --> Total execution time: 0.0412
INFO - 2022-07-06 07:15:11 --> Config Class Initialized
INFO - 2022-07-06 07:15:11 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:15:11 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:15:11 --> Utf8 Class Initialized
INFO - 2022-07-06 07:15:11 --> URI Class Initialized
INFO - 2022-07-06 07:15:11 --> Router Class Initialized
INFO - 2022-07-06 07:15:11 --> Output Class Initialized
INFO - 2022-07-06 07:15:11 --> Security Class Initialized
DEBUG - 2022-07-06 07:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:15:11 --> Input Class Initialized
INFO - 2022-07-06 07:15:11 --> Language Class Initialized
INFO - 2022-07-06 07:15:11 --> Loader Class Initialized
INFO - 2022-07-06 07:15:11 --> Helper loaded: url_helper
INFO - 2022-07-06 07:15:11 --> Helper loaded: file_helper
INFO - 2022-07-06 07:15:11 --> Database Driver Class Initialized
INFO - 2022-07-06 07:15:11 --> Email Class Initialized
DEBUG - 2022-07-06 07:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:15:11 --> Controller Class Initialized
INFO - 2022-07-06 07:15:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:15:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:15:11 --> Final output sent to browser
DEBUG - 2022-07-06 07:15:11 --> Total execution time: 0.0397
INFO - 2022-07-06 07:15:11 --> Config Class Initialized
INFO - 2022-07-06 07:15:11 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:15:11 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:15:11 --> Utf8 Class Initialized
INFO - 2022-07-06 07:15:11 --> URI Class Initialized
INFO - 2022-07-06 07:15:11 --> Router Class Initialized
INFO - 2022-07-06 07:15:11 --> Output Class Initialized
INFO - 2022-07-06 07:15:11 --> Security Class Initialized
DEBUG - 2022-07-06 07:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:15:11 --> Input Class Initialized
INFO - 2022-07-06 07:15:11 --> Language Class Initialized
INFO - 2022-07-06 07:15:11 --> Loader Class Initialized
INFO - 2022-07-06 07:15:11 --> Helper loaded: url_helper
INFO - 2022-07-06 07:15:11 --> Helper loaded: file_helper
INFO - 2022-07-06 07:15:11 --> Database Driver Class Initialized
INFO - 2022-07-06 07:15:11 --> Email Class Initialized
DEBUG - 2022-07-06 07:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:15:11 --> Controller Class Initialized
INFO - 2022-07-06 07:15:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:15:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:15:11 --> Final output sent to browser
DEBUG - 2022-07-06 07:15:11 --> Total execution time: 0.1144
INFO - 2022-07-06 07:15:11 --> Config Class Initialized
INFO - 2022-07-06 07:15:11 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:15:11 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:15:11 --> Utf8 Class Initialized
INFO - 2022-07-06 07:15:11 --> URI Class Initialized
INFO - 2022-07-06 07:15:11 --> Router Class Initialized
INFO - 2022-07-06 07:15:11 --> Output Class Initialized
INFO - 2022-07-06 07:15:11 --> Security Class Initialized
DEBUG - 2022-07-06 07:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:15:11 --> Input Class Initialized
INFO - 2022-07-06 07:15:11 --> Language Class Initialized
INFO - 2022-07-06 07:15:11 --> Loader Class Initialized
INFO - 2022-07-06 07:15:11 --> Helper loaded: url_helper
INFO - 2022-07-06 07:15:11 --> Helper loaded: file_helper
INFO - 2022-07-06 07:15:11 --> Database Driver Class Initialized
INFO - 2022-07-06 07:15:11 --> Email Class Initialized
DEBUG - 2022-07-06 07:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:15:11 --> Controller Class Initialized
INFO - 2022-07-06 07:15:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:15:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:15:11 --> Final output sent to browser
DEBUG - 2022-07-06 07:15:11 --> Total execution time: 0.0362
INFO - 2022-07-06 07:15:11 --> Config Class Initialized
INFO - 2022-07-06 07:15:11 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:15:11 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:15:11 --> Utf8 Class Initialized
INFO - 2022-07-06 07:15:11 --> URI Class Initialized
INFO - 2022-07-06 07:15:11 --> Router Class Initialized
INFO - 2022-07-06 07:15:11 --> Output Class Initialized
INFO - 2022-07-06 07:15:11 --> Security Class Initialized
DEBUG - 2022-07-06 07:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:15:11 --> Input Class Initialized
INFO - 2022-07-06 07:15:11 --> Language Class Initialized
INFO - 2022-07-06 07:15:11 --> Loader Class Initialized
INFO - 2022-07-06 07:15:11 --> Helper loaded: url_helper
INFO - 2022-07-06 07:15:11 --> Helper loaded: file_helper
INFO - 2022-07-06 07:15:11 --> Database Driver Class Initialized
INFO - 2022-07-06 07:15:11 --> Email Class Initialized
DEBUG - 2022-07-06 07:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:15:11 --> Controller Class Initialized
INFO - 2022-07-06 07:15:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:15:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:15:11 --> Final output sent to browser
DEBUG - 2022-07-06 07:15:11 --> Total execution time: 0.0552
INFO - 2022-07-06 07:15:12 --> Config Class Initialized
INFO - 2022-07-06 07:15:12 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:15:12 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:15:12 --> Utf8 Class Initialized
INFO - 2022-07-06 07:15:12 --> URI Class Initialized
INFO - 2022-07-06 07:15:12 --> Router Class Initialized
INFO - 2022-07-06 07:15:12 --> Output Class Initialized
INFO - 2022-07-06 07:15:12 --> Security Class Initialized
DEBUG - 2022-07-06 07:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:15:12 --> Input Class Initialized
INFO - 2022-07-06 07:15:12 --> Language Class Initialized
INFO - 2022-07-06 07:15:12 --> Loader Class Initialized
INFO - 2022-07-06 07:15:12 --> Helper loaded: url_helper
INFO - 2022-07-06 07:15:12 --> Helper loaded: file_helper
INFO - 2022-07-06 07:15:12 --> Database Driver Class Initialized
INFO - 2022-07-06 07:15:12 --> Email Class Initialized
DEBUG - 2022-07-06 07:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:15:12 --> Controller Class Initialized
INFO - 2022-07-06 07:15:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:15:12 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:15:12 --> Final output sent to browser
DEBUG - 2022-07-06 07:15:12 --> Total execution time: 0.0735
INFO - 2022-07-06 07:15:12 --> Config Class Initialized
INFO - 2022-07-06 07:15:12 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:15:12 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:15:12 --> Utf8 Class Initialized
INFO - 2022-07-06 07:15:12 --> URI Class Initialized
INFO - 2022-07-06 07:15:12 --> Router Class Initialized
INFO - 2022-07-06 07:15:12 --> Output Class Initialized
INFO - 2022-07-06 07:15:12 --> Security Class Initialized
DEBUG - 2022-07-06 07:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:15:12 --> Input Class Initialized
INFO - 2022-07-06 07:15:12 --> Language Class Initialized
INFO - 2022-07-06 07:15:12 --> Loader Class Initialized
INFO - 2022-07-06 07:15:12 --> Helper loaded: url_helper
INFO - 2022-07-06 07:15:12 --> Helper loaded: file_helper
INFO - 2022-07-06 07:15:12 --> Database Driver Class Initialized
INFO - 2022-07-06 07:15:12 --> Email Class Initialized
DEBUG - 2022-07-06 07:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:15:12 --> Controller Class Initialized
INFO - 2022-07-06 07:15:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:15:12 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:15:12 --> Final output sent to browser
DEBUG - 2022-07-06 07:15:12 --> Total execution time: 0.0158
INFO - 2022-07-06 07:15:48 --> Config Class Initialized
INFO - 2022-07-06 07:15:48 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:15:48 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:15:48 --> Utf8 Class Initialized
INFO - 2022-07-06 07:15:48 --> URI Class Initialized
INFO - 2022-07-06 07:15:48 --> Router Class Initialized
INFO - 2022-07-06 07:15:48 --> Output Class Initialized
INFO - 2022-07-06 07:15:48 --> Security Class Initialized
DEBUG - 2022-07-06 07:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:15:48 --> Input Class Initialized
INFO - 2022-07-06 07:15:48 --> Language Class Initialized
INFO - 2022-07-06 07:15:48 --> Loader Class Initialized
INFO - 2022-07-06 07:15:48 --> Helper loaded: url_helper
INFO - 2022-07-06 07:15:48 --> Helper loaded: file_helper
INFO - 2022-07-06 07:15:48 --> Database Driver Class Initialized
INFO - 2022-07-06 07:15:48 --> Email Class Initialized
DEBUG - 2022-07-06 07:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:15:48 --> Controller Class Initialized
INFO - 2022-07-06 07:15:48 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:15:48 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:15:48 --> Final output sent to browser
DEBUG - 2022-07-06 07:15:48 --> Total execution time: 0.1407
INFO - 2022-07-06 07:15:50 --> Config Class Initialized
INFO - 2022-07-06 07:15:50 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:15:50 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:15:50 --> Utf8 Class Initialized
INFO - 2022-07-06 07:15:50 --> URI Class Initialized
INFO - 2022-07-06 07:15:50 --> Router Class Initialized
INFO - 2022-07-06 07:15:50 --> Output Class Initialized
INFO - 2022-07-06 07:15:50 --> Security Class Initialized
DEBUG - 2022-07-06 07:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:15:50 --> Input Class Initialized
INFO - 2022-07-06 07:15:50 --> Language Class Initialized
INFO - 2022-07-06 07:15:50 --> Loader Class Initialized
INFO - 2022-07-06 07:15:50 --> Helper loaded: url_helper
INFO - 2022-07-06 07:15:50 --> Helper loaded: file_helper
INFO - 2022-07-06 07:15:50 --> Database Driver Class Initialized
INFO - 2022-07-06 07:15:50 --> Email Class Initialized
DEBUG - 2022-07-06 07:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:15:50 --> Controller Class Initialized
INFO - 2022-07-06 07:15:50 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:15:50 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:15:50 --> Final output sent to browser
DEBUG - 2022-07-06 07:15:50 --> Total execution time: 0.1191
INFO - 2022-07-06 07:15:52 --> Config Class Initialized
INFO - 2022-07-06 07:15:52 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:15:52 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:15:52 --> Utf8 Class Initialized
INFO - 2022-07-06 07:15:52 --> URI Class Initialized
INFO - 2022-07-06 07:15:52 --> Router Class Initialized
INFO - 2022-07-06 07:15:52 --> Output Class Initialized
INFO - 2022-07-06 07:15:52 --> Security Class Initialized
DEBUG - 2022-07-06 07:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:15:52 --> Input Class Initialized
INFO - 2022-07-06 07:15:52 --> Language Class Initialized
INFO - 2022-07-06 07:15:52 --> Loader Class Initialized
INFO - 2022-07-06 07:15:52 --> Helper loaded: url_helper
INFO - 2022-07-06 07:15:52 --> Helper loaded: file_helper
INFO - 2022-07-06 07:15:52 --> Database Driver Class Initialized
INFO - 2022-07-06 07:15:52 --> Email Class Initialized
DEBUG - 2022-07-06 07:15:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:15:52 --> Controller Class Initialized
INFO - 2022-07-06 07:15:52 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:15:52 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:15:52 --> Final output sent to browser
DEBUG - 2022-07-06 07:15:52 --> Total execution time: 0.0473
INFO - 2022-07-06 07:15:52 --> Config Class Initialized
INFO - 2022-07-06 07:15:52 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:15:52 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:15:52 --> Utf8 Class Initialized
INFO - 2022-07-06 07:15:52 --> URI Class Initialized
INFO - 2022-07-06 07:15:52 --> Router Class Initialized
INFO - 2022-07-06 07:15:52 --> Output Class Initialized
INFO - 2022-07-06 07:15:52 --> Security Class Initialized
DEBUG - 2022-07-06 07:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:15:52 --> Input Class Initialized
INFO - 2022-07-06 07:15:52 --> Language Class Initialized
INFO - 2022-07-06 07:15:52 --> Loader Class Initialized
INFO - 2022-07-06 07:15:52 --> Helper loaded: url_helper
INFO - 2022-07-06 07:15:52 --> Helper loaded: file_helper
INFO - 2022-07-06 07:15:52 --> Database Driver Class Initialized
INFO - 2022-07-06 07:15:52 --> Email Class Initialized
DEBUG - 2022-07-06 07:15:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:15:52 --> Controller Class Initialized
INFO - 2022-07-06 07:15:52 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:15:52 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:15:52 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-06 07:15:52 --> Final output sent to browser
DEBUG - 2022-07-06 07:15:52 --> Total execution time: 0.0240
INFO - 2022-07-06 07:15:54 --> Config Class Initialized
INFO - 2022-07-06 07:15:54 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:15:54 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:15:54 --> Utf8 Class Initialized
INFO - 2022-07-06 07:15:54 --> URI Class Initialized
INFO - 2022-07-06 07:15:54 --> Router Class Initialized
INFO - 2022-07-06 07:15:54 --> Output Class Initialized
INFO - 2022-07-06 07:15:54 --> Security Class Initialized
DEBUG - 2022-07-06 07:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:15:54 --> Input Class Initialized
INFO - 2022-07-06 07:15:54 --> Language Class Initialized
INFO - 2022-07-06 07:15:54 --> Loader Class Initialized
INFO - 2022-07-06 07:15:54 --> Helper loaded: url_helper
INFO - 2022-07-06 07:15:54 --> Helper loaded: file_helper
INFO - 2022-07-06 07:15:54 --> Database Driver Class Initialized
INFO - 2022-07-06 07:15:54 --> Email Class Initialized
DEBUG - 2022-07-06 07:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:15:54 --> Controller Class Initialized
INFO - 2022-07-06 07:15:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:15:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-06 07:15:54 --> Severity: Notice --> Undefined variable: total C:\wamp64\www\qr\application\views\doc_screen\doctor.php 359
INFO - 2022-07-06 07:15:54 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-07-06 07:15:54 --> Final output sent to browser
DEBUG - 2022-07-06 07:15:54 --> Total execution time: 0.0481
INFO - 2022-07-06 07:15:56 --> Config Class Initialized
INFO - 2022-07-06 07:15:56 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:15:56 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:15:56 --> Utf8 Class Initialized
INFO - 2022-07-06 07:15:56 --> URI Class Initialized
INFO - 2022-07-06 07:15:56 --> Router Class Initialized
INFO - 2022-07-06 07:15:56 --> Output Class Initialized
INFO - 2022-07-06 07:15:56 --> Security Class Initialized
DEBUG - 2022-07-06 07:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:15:56 --> Input Class Initialized
INFO - 2022-07-06 07:15:56 --> Language Class Initialized
INFO - 2022-07-06 07:15:56 --> Loader Class Initialized
INFO - 2022-07-06 07:15:56 --> Helper loaded: url_helper
INFO - 2022-07-06 07:15:56 --> Helper loaded: file_helper
INFO - 2022-07-06 07:15:56 --> Database Driver Class Initialized
INFO - 2022-07-06 07:15:56 --> Email Class Initialized
DEBUG - 2022-07-06 07:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:15:56 --> Controller Class Initialized
INFO - 2022-07-06 07:15:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:15:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:15:56 --> Final output sent to browser
DEBUG - 2022-07-06 07:15:56 --> Total execution time: 0.0402
INFO - 2022-07-06 07:15:58 --> Config Class Initialized
INFO - 2022-07-06 07:15:58 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:15:58 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:15:58 --> Utf8 Class Initialized
INFO - 2022-07-06 07:15:58 --> URI Class Initialized
INFO - 2022-07-06 07:15:58 --> Router Class Initialized
INFO - 2022-07-06 07:15:58 --> Output Class Initialized
INFO - 2022-07-06 07:15:58 --> Security Class Initialized
DEBUG - 2022-07-06 07:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:15:58 --> Input Class Initialized
INFO - 2022-07-06 07:15:58 --> Language Class Initialized
INFO - 2022-07-06 07:15:58 --> Loader Class Initialized
INFO - 2022-07-06 07:15:58 --> Helper loaded: url_helper
INFO - 2022-07-06 07:15:58 --> Helper loaded: file_helper
INFO - 2022-07-06 07:15:58 --> Database Driver Class Initialized
INFO - 2022-07-06 07:15:58 --> Email Class Initialized
DEBUG - 2022-07-06 07:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:15:58 --> Controller Class Initialized
INFO - 2022-07-06 07:15:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:15:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:15:58 --> Final output sent to browser
DEBUG - 2022-07-06 07:15:58 --> Total execution time: 0.0151
INFO - 2022-07-06 07:15:58 --> Config Class Initialized
INFO - 2022-07-06 07:15:58 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:15:58 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:15:58 --> Utf8 Class Initialized
INFO - 2022-07-06 07:15:58 --> URI Class Initialized
INFO - 2022-07-06 07:15:58 --> Router Class Initialized
INFO - 2022-07-06 07:15:58 --> Output Class Initialized
INFO - 2022-07-06 07:15:58 --> Security Class Initialized
DEBUG - 2022-07-06 07:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:15:58 --> Input Class Initialized
INFO - 2022-07-06 07:15:58 --> Language Class Initialized
INFO - 2022-07-06 07:15:58 --> Loader Class Initialized
INFO - 2022-07-06 07:15:58 --> Helper loaded: url_helper
INFO - 2022-07-06 07:15:58 --> Helper loaded: file_helper
INFO - 2022-07-06 07:15:58 --> Database Driver Class Initialized
INFO - 2022-07-06 07:15:58 --> Email Class Initialized
DEBUG - 2022-07-06 07:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:15:58 --> Controller Class Initialized
INFO - 2022-07-06 07:15:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:15:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:15:58 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-06 07:15:58 --> Final output sent to browser
DEBUG - 2022-07-06 07:15:58 --> Total execution time: 0.0164
INFO - 2022-07-06 07:20:12 --> Config Class Initialized
INFO - 2022-07-06 07:20:12 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:20:12 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:20:12 --> Utf8 Class Initialized
INFO - 2022-07-06 07:20:12 --> URI Class Initialized
INFO - 2022-07-06 07:20:12 --> Router Class Initialized
INFO - 2022-07-06 07:20:12 --> Output Class Initialized
INFO - 2022-07-06 07:20:12 --> Security Class Initialized
DEBUG - 2022-07-06 07:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:20:12 --> Input Class Initialized
INFO - 2022-07-06 07:20:12 --> Language Class Initialized
INFO - 2022-07-06 07:20:12 --> Loader Class Initialized
INFO - 2022-07-06 07:20:12 --> Helper loaded: url_helper
INFO - 2022-07-06 07:20:12 --> Helper loaded: file_helper
INFO - 2022-07-06 07:20:12 --> Database Driver Class Initialized
INFO - 2022-07-06 07:20:12 --> Email Class Initialized
DEBUG - 2022-07-06 07:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:20:12 --> Controller Class Initialized
INFO - 2022-07-06 07:20:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:20:12 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:20:12 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-06 07:20:12 --> Final output sent to browser
DEBUG - 2022-07-06 07:20:12 --> Total execution time: 0.1556
INFO - 2022-07-06 07:21:34 --> Config Class Initialized
INFO - 2022-07-06 07:21:34 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:21:34 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:21:34 --> Utf8 Class Initialized
INFO - 2022-07-06 07:21:34 --> URI Class Initialized
INFO - 2022-07-06 07:21:34 --> Router Class Initialized
INFO - 2022-07-06 07:21:34 --> Output Class Initialized
INFO - 2022-07-06 07:21:34 --> Security Class Initialized
DEBUG - 2022-07-06 07:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:21:34 --> Input Class Initialized
INFO - 2022-07-06 07:21:34 --> Language Class Initialized
INFO - 2022-07-06 07:21:34 --> Loader Class Initialized
INFO - 2022-07-06 07:21:34 --> Helper loaded: url_helper
INFO - 2022-07-06 07:21:34 --> Helper loaded: file_helper
INFO - 2022-07-06 07:21:34 --> Database Driver Class Initialized
INFO - 2022-07-06 07:21:34 --> Email Class Initialized
DEBUG - 2022-07-06 07:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:21:34 --> Controller Class Initialized
INFO - 2022-07-06 07:21:34 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:21:34 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:21:34 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-06 07:21:34 --> Final output sent to browser
DEBUG - 2022-07-06 07:21:34 --> Total execution time: 0.0196
INFO - 2022-07-06 07:30:34 --> Config Class Initialized
INFO - 2022-07-06 07:30:34 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:30:34 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:30:34 --> Utf8 Class Initialized
INFO - 2022-07-06 07:30:34 --> URI Class Initialized
INFO - 2022-07-06 07:30:34 --> Router Class Initialized
INFO - 2022-07-06 07:30:34 --> Output Class Initialized
INFO - 2022-07-06 07:30:34 --> Security Class Initialized
DEBUG - 2022-07-06 07:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:30:34 --> Input Class Initialized
INFO - 2022-07-06 07:30:34 --> Language Class Initialized
INFO - 2022-07-06 07:30:34 --> Loader Class Initialized
INFO - 2022-07-06 07:30:34 --> Helper loaded: url_helper
INFO - 2022-07-06 07:30:34 --> Helper loaded: file_helper
INFO - 2022-07-06 07:30:34 --> Database Driver Class Initialized
INFO - 2022-07-06 07:30:34 --> Email Class Initialized
DEBUG - 2022-07-06 07:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:30:34 --> Controller Class Initialized
INFO - 2022-07-06 07:30:34 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:30:34 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:30:34 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-06 07:30:34 --> Final output sent to browser
DEBUG - 2022-07-06 07:30:34 --> Total execution time: 0.0261
INFO - 2022-07-06 07:31:49 --> Config Class Initialized
INFO - 2022-07-06 07:31:49 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:31:49 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:31:49 --> Utf8 Class Initialized
INFO - 2022-07-06 07:31:49 --> URI Class Initialized
INFO - 2022-07-06 07:31:49 --> Router Class Initialized
INFO - 2022-07-06 07:31:49 --> Output Class Initialized
INFO - 2022-07-06 07:31:49 --> Security Class Initialized
DEBUG - 2022-07-06 07:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:31:49 --> Input Class Initialized
INFO - 2022-07-06 07:31:49 --> Language Class Initialized
INFO - 2022-07-06 07:31:49 --> Loader Class Initialized
INFO - 2022-07-06 07:31:49 --> Helper loaded: url_helper
INFO - 2022-07-06 07:31:49 --> Helper loaded: file_helper
INFO - 2022-07-06 07:31:49 --> Database Driver Class Initialized
INFO - 2022-07-06 07:31:50 --> Email Class Initialized
DEBUG - 2022-07-06 07:31:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:31:50 --> Controller Class Initialized
INFO - 2022-07-06 07:31:50 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:31:50 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:31:50 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-06 07:31:50 --> Final output sent to browser
DEBUG - 2022-07-06 07:31:50 --> Total execution time: 0.1362
INFO - 2022-07-06 07:32:09 --> Config Class Initialized
INFO - 2022-07-06 07:32:09 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:32:09 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:32:09 --> Utf8 Class Initialized
INFO - 2022-07-06 07:32:09 --> URI Class Initialized
INFO - 2022-07-06 07:32:09 --> Router Class Initialized
INFO - 2022-07-06 07:32:09 --> Output Class Initialized
INFO - 2022-07-06 07:32:09 --> Security Class Initialized
DEBUG - 2022-07-06 07:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:32:09 --> Input Class Initialized
INFO - 2022-07-06 07:32:09 --> Language Class Initialized
INFO - 2022-07-06 07:32:09 --> Loader Class Initialized
INFO - 2022-07-06 07:32:09 --> Helper loaded: url_helper
INFO - 2022-07-06 07:32:09 --> Helper loaded: file_helper
INFO - 2022-07-06 07:32:09 --> Database Driver Class Initialized
INFO - 2022-07-06 07:32:09 --> Email Class Initialized
DEBUG - 2022-07-06 07:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:32:09 --> Controller Class Initialized
INFO - 2022-07-06 07:32:09 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:32:09 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:32:09 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-06 07:32:09 --> Final output sent to browser
DEBUG - 2022-07-06 07:32:09 --> Total execution time: 0.0206
INFO - 2022-07-06 07:33:47 --> Config Class Initialized
INFO - 2022-07-06 07:33:47 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:33:47 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:33:47 --> Utf8 Class Initialized
INFO - 2022-07-06 07:33:47 --> URI Class Initialized
INFO - 2022-07-06 07:33:47 --> Router Class Initialized
INFO - 2022-07-06 07:33:47 --> Output Class Initialized
INFO - 2022-07-06 07:33:47 --> Security Class Initialized
DEBUG - 2022-07-06 07:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:33:47 --> Input Class Initialized
INFO - 2022-07-06 07:33:47 --> Language Class Initialized
INFO - 2022-07-06 07:33:47 --> Loader Class Initialized
INFO - 2022-07-06 07:33:47 --> Helper loaded: url_helper
INFO - 2022-07-06 07:33:47 --> Helper loaded: file_helper
INFO - 2022-07-06 07:33:47 --> Database Driver Class Initialized
INFO - 2022-07-06 07:33:47 --> Email Class Initialized
DEBUG - 2022-07-06 07:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:33:47 --> Controller Class Initialized
INFO - 2022-07-06 07:33:47 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:33:47 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:33:47 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-06 07:33:47 --> Final output sent to browser
DEBUG - 2022-07-06 07:33:47 --> Total execution time: 0.1417
INFO - 2022-07-06 07:35:51 --> Config Class Initialized
INFO - 2022-07-06 07:35:51 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:35:51 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:35:51 --> Utf8 Class Initialized
INFO - 2022-07-06 07:35:51 --> URI Class Initialized
INFO - 2022-07-06 07:35:51 --> Router Class Initialized
INFO - 2022-07-06 07:35:51 --> Output Class Initialized
INFO - 2022-07-06 07:35:51 --> Security Class Initialized
DEBUG - 2022-07-06 07:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:35:51 --> Input Class Initialized
INFO - 2022-07-06 07:35:51 --> Language Class Initialized
INFO - 2022-07-06 07:35:51 --> Loader Class Initialized
INFO - 2022-07-06 07:35:51 --> Helper loaded: url_helper
INFO - 2022-07-06 07:35:52 --> Helper loaded: file_helper
INFO - 2022-07-06 07:35:52 --> Database Driver Class Initialized
INFO - 2022-07-06 07:35:52 --> Email Class Initialized
DEBUG - 2022-07-06 07:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:35:52 --> Controller Class Initialized
INFO - 2022-07-06 07:35:52 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:35:52 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:35:52 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-06 07:35:52 --> Final output sent to browser
DEBUG - 2022-07-06 07:35:52 --> Total execution time: 0.0412
INFO - 2022-07-06 07:35:53 --> Config Class Initialized
INFO - 2022-07-06 07:35:53 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:35:53 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:35:53 --> Utf8 Class Initialized
INFO - 2022-07-06 07:35:53 --> URI Class Initialized
INFO - 2022-07-06 07:35:53 --> Router Class Initialized
INFO - 2022-07-06 07:35:53 --> Output Class Initialized
INFO - 2022-07-06 07:35:53 --> Security Class Initialized
DEBUG - 2022-07-06 07:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:35:53 --> Input Class Initialized
INFO - 2022-07-06 07:35:53 --> Language Class Initialized
INFO - 2022-07-06 07:35:53 --> Loader Class Initialized
INFO - 2022-07-06 07:35:53 --> Helper loaded: url_helper
INFO - 2022-07-06 07:35:53 --> Helper loaded: file_helper
INFO - 2022-07-06 07:35:53 --> Database Driver Class Initialized
INFO - 2022-07-06 07:35:53 --> Email Class Initialized
DEBUG - 2022-07-06 07:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:35:53 --> Controller Class Initialized
INFO - 2022-07-06 07:35:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:35:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-06 07:35:53 --> Severity: Notice --> Undefined variable: total C:\wamp64\www\qr\application\views\doc_screen\doctor.php 359
INFO - 2022-07-06 07:35:53 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-07-06 07:35:53 --> Final output sent to browser
DEBUG - 2022-07-06 07:35:53 --> Total execution time: 0.0424
INFO - 2022-07-06 07:35:56 --> Config Class Initialized
INFO - 2022-07-06 07:35:56 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:35:56 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:35:56 --> Utf8 Class Initialized
INFO - 2022-07-06 07:35:56 --> URI Class Initialized
INFO - 2022-07-06 07:35:56 --> Router Class Initialized
INFO - 2022-07-06 07:35:56 --> Output Class Initialized
INFO - 2022-07-06 07:35:56 --> Security Class Initialized
DEBUG - 2022-07-06 07:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:35:56 --> Input Class Initialized
INFO - 2022-07-06 07:35:56 --> Language Class Initialized
INFO - 2022-07-06 07:35:56 --> Loader Class Initialized
INFO - 2022-07-06 07:35:56 --> Helper loaded: url_helper
INFO - 2022-07-06 07:35:56 --> Helper loaded: file_helper
INFO - 2022-07-06 07:35:56 --> Database Driver Class Initialized
INFO - 2022-07-06 07:35:56 --> Email Class Initialized
DEBUG - 2022-07-06 07:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:35:56 --> Controller Class Initialized
INFO - 2022-07-06 07:35:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:35:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:35:56 --> Final output sent to browser
DEBUG - 2022-07-06 07:35:56 --> Total execution time: 0.1258
INFO - 2022-07-06 07:35:58 --> Config Class Initialized
INFO - 2022-07-06 07:35:58 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:35:58 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:35:58 --> Utf8 Class Initialized
INFO - 2022-07-06 07:35:58 --> URI Class Initialized
INFO - 2022-07-06 07:35:58 --> Router Class Initialized
INFO - 2022-07-06 07:35:58 --> Output Class Initialized
INFO - 2022-07-06 07:35:58 --> Security Class Initialized
DEBUG - 2022-07-06 07:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:35:58 --> Input Class Initialized
INFO - 2022-07-06 07:35:58 --> Language Class Initialized
INFO - 2022-07-06 07:35:58 --> Loader Class Initialized
INFO - 2022-07-06 07:35:58 --> Helper loaded: url_helper
INFO - 2022-07-06 07:35:58 --> Helper loaded: file_helper
INFO - 2022-07-06 07:35:58 --> Database Driver Class Initialized
INFO - 2022-07-06 07:35:58 --> Email Class Initialized
DEBUG - 2022-07-06 07:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:35:58 --> Controller Class Initialized
INFO - 2022-07-06 07:35:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:35:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:35:58 --> Final output sent to browser
DEBUG - 2022-07-06 07:35:58 --> Total execution time: 0.0155
INFO - 2022-07-06 07:35:58 --> Config Class Initialized
INFO - 2022-07-06 07:35:58 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:35:58 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:35:58 --> Utf8 Class Initialized
INFO - 2022-07-06 07:35:58 --> URI Class Initialized
INFO - 2022-07-06 07:35:58 --> Router Class Initialized
INFO - 2022-07-06 07:35:58 --> Output Class Initialized
INFO - 2022-07-06 07:35:58 --> Security Class Initialized
DEBUG - 2022-07-06 07:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:35:58 --> Input Class Initialized
INFO - 2022-07-06 07:35:58 --> Language Class Initialized
INFO - 2022-07-06 07:35:58 --> Loader Class Initialized
INFO - 2022-07-06 07:35:58 --> Helper loaded: url_helper
INFO - 2022-07-06 07:35:58 --> Helper loaded: file_helper
INFO - 2022-07-06 07:35:58 --> Database Driver Class Initialized
INFO - 2022-07-06 07:35:58 --> Email Class Initialized
DEBUG - 2022-07-06 07:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:35:58 --> Controller Class Initialized
INFO - 2022-07-06 07:35:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:35:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:35:58 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-06 07:35:58 --> Final output sent to browser
DEBUG - 2022-07-06 07:35:58 --> Total execution time: 0.1478
INFO - 2022-07-06 07:37:58 --> Config Class Initialized
INFO - 2022-07-06 07:37:58 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:37:58 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:37:58 --> Utf8 Class Initialized
INFO - 2022-07-06 07:37:58 --> URI Class Initialized
INFO - 2022-07-06 07:37:58 --> Router Class Initialized
INFO - 2022-07-06 07:37:58 --> Output Class Initialized
INFO - 2022-07-06 07:37:58 --> Security Class Initialized
DEBUG - 2022-07-06 07:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:37:58 --> Input Class Initialized
INFO - 2022-07-06 07:37:58 --> Language Class Initialized
INFO - 2022-07-06 07:37:58 --> Loader Class Initialized
INFO - 2022-07-06 07:37:58 --> Helper loaded: url_helper
INFO - 2022-07-06 07:37:58 --> Helper loaded: file_helper
INFO - 2022-07-06 07:37:58 --> Database Driver Class Initialized
INFO - 2022-07-06 07:37:58 --> Email Class Initialized
DEBUG - 2022-07-06 07:37:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:37:58 --> Controller Class Initialized
INFO - 2022-07-06 07:37:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:37:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:37:58 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-06 07:37:58 --> Final output sent to browser
DEBUG - 2022-07-06 07:37:58 --> Total execution time: 0.1486
INFO - 2022-07-06 07:40:57 --> Config Class Initialized
INFO - 2022-07-06 07:40:57 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:40:57 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:40:57 --> Utf8 Class Initialized
INFO - 2022-07-06 07:40:57 --> URI Class Initialized
INFO - 2022-07-06 07:40:57 --> Router Class Initialized
INFO - 2022-07-06 07:40:57 --> Output Class Initialized
INFO - 2022-07-06 07:40:57 --> Security Class Initialized
DEBUG - 2022-07-06 07:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:40:57 --> Input Class Initialized
INFO - 2022-07-06 07:40:57 --> Language Class Initialized
INFO - 2022-07-06 07:40:57 --> Loader Class Initialized
INFO - 2022-07-06 07:40:57 --> Helper loaded: url_helper
INFO - 2022-07-06 07:40:57 --> Helper loaded: file_helper
INFO - 2022-07-06 07:40:57 --> Database Driver Class Initialized
INFO - 2022-07-06 07:40:57 --> Email Class Initialized
DEBUG - 2022-07-06 07:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:40:57 --> Controller Class Initialized
INFO - 2022-07-06 07:40:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:40:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:40:57 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-06 07:40:57 --> Final output sent to browser
DEBUG - 2022-07-06 07:40:57 --> Total execution time: 0.1515
INFO - 2022-07-06 07:40:58 --> Config Class Initialized
INFO - 2022-07-06 07:40:58 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:40:58 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:40:58 --> Utf8 Class Initialized
INFO - 2022-07-06 07:40:58 --> URI Class Initialized
INFO - 2022-07-06 07:40:58 --> Router Class Initialized
INFO - 2022-07-06 07:40:58 --> Output Class Initialized
INFO - 2022-07-06 07:40:58 --> Security Class Initialized
DEBUG - 2022-07-06 07:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:40:58 --> Input Class Initialized
INFO - 2022-07-06 07:40:58 --> Language Class Initialized
INFO - 2022-07-06 07:40:58 --> Loader Class Initialized
INFO - 2022-07-06 07:40:58 --> Helper loaded: url_helper
INFO - 2022-07-06 07:40:58 --> Helper loaded: file_helper
INFO - 2022-07-06 07:40:58 --> Database Driver Class Initialized
INFO - 2022-07-06 07:40:58 --> Email Class Initialized
DEBUG - 2022-07-06 07:40:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:40:58 --> Controller Class Initialized
INFO - 2022-07-06 07:40:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:40:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:40:58 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-06 07:40:58 --> Final output sent to browser
DEBUG - 2022-07-06 07:40:58 --> Total execution time: 0.1226
INFO - 2022-07-06 07:43:17 --> Config Class Initialized
INFO - 2022-07-06 07:43:17 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:43:17 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:43:17 --> Utf8 Class Initialized
INFO - 2022-07-06 07:43:17 --> URI Class Initialized
INFO - 2022-07-06 07:43:17 --> Router Class Initialized
INFO - 2022-07-06 07:43:17 --> Output Class Initialized
INFO - 2022-07-06 07:43:17 --> Security Class Initialized
DEBUG - 2022-07-06 07:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:43:17 --> Input Class Initialized
INFO - 2022-07-06 07:43:17 --> Language Class Initialized
INFO - 2022-07-06 07:43:17 --> Loader Class Initialized
INFO - 2022-07-06 07:43:17 --> Helper loaded: url_helper
INFO - 2022-07-06 07:43:17 --> Helper loaded: file_helper
INFO - 2022-07-06 07:43:17 --> Database Driver Class Initialized
INFO - 2022-07-06 07:43:17 --> Email Class Initialized
DEBUG - 2022-07-06 07:43:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:43:17 --> Controller Class Initialized
INFO - 2022-07-06 07:43:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:43:17 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-06 07:43:17 --> Final output sent to browser
DEBUG - 2022-07-06 07:43:17 --> Total execution time: 0.0761
INFO - 2022-07-06 07:43:17 --> Config Class Initialized
INFO - 2022-07-06 07:43:17 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:43:17 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:43:17 --> Utf8 Class Initialized
INFO - 2022-07-06 07:43:17 --> URI Class Initialized
INFO - 2022-07-06 07:43:17 --> Router Class Initialized
INFO - 2022-07-06 07:43:17 --> Output Class Initialized
INFO - 2022-07-06 07:43:17 --> Security Class Initialized
DEBUG - 2022-07-06 07:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:43:17 --> Input Class Initialized
INFO - 2022-07-06 07:43:17 --> Language Class Initialized
INFO - 2022-07-06 07:43:17 --> Loader Class Initialized
INFO - 2022-07-06 07:43:17 --> Helper loaded: url_helper
INFO - 2022-07-06 07:43:17 --> Helper loaded: file_helper
INFO - 2022-07-06 07:43:17 --> Database Driver Class Initialized
INFO - 2022-07-06 07:43:17 --> Email Class Initialized
DEBUG - 2022-07-06 07:43:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:43:17 --> Controller Class Initialized
INFO - 2022-07-06 07:43:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:43:17 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-06 07:43:17 --> Final output sent to browser
DEBUG - 2022-07-06 07:43:17 --> Total execution time: 0.0270
INFO - 2022-07-06 07:45:01 --> Config Class Initialized
INFO - 2022-07-06 07:45:01 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:45:01 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:45:01 --> Utf8 Class Initialized
INFO - 2022-07-06 07:45:01 --> URI Class Initialized
INFO - 2022-07-06 07:45:01 --> Router Class Initialized
INFO - 2022-07-06 07:45:01 --> Output Class Initialized
INFO - 2022-07-06 07:45:01 --> Security Class Initialized
DEBUG - 2022-07-06 07:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:45:01 --> Input Class Initialized
INFO - 2022-07-06 07:45:01 --> Language Class Initialized
INFO - 2022-07-06 07:45:01 --> Loader Class Initialized
INFO - 2022-07-06 07:45:01 --> Helper loaded: url_helper
INFO - 2022-07-06 07:45:01 --> Helper loaded: file_helper
INFO - 2022-07-06 07:45:01 --> Database Driver Class Initialized
INFO - 2022-07-06 07:45:01 --> Email Class Initialized
DEBUG - 2022-07-06 07:45:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:45:01 --> Controller Class Initialized
INFO - 2022-07-06 07:45:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:45:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:45:01 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-06 07:45:01 --> Final output sent to browser
DEBUG - 2022-07-06 07:45:01 --> Total execution time: 0.1196
INFO - 2022-07-06 07:45:06 --> Config Class Initialized
INFO - 2022-07-06 07:45:06 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:45:06 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:45:06 --> Utf8 Class Initialized
INFO - 2022-07-06 07:45:06 --> URI Class Initialized
INFO - 2022-07-06 07:45:06 --> Router Class Initialized
INFO - 2022-07-06 07:45:06 --> Output Class Initialized
INFO - 2022-07-06 07:45:06 --> Security Class Initialized
DEBUG - 2022-07-06 07:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:45:06 --> Input Class Initialized
INFO - 2022-07-06 07:45:06 --> Language Class Initialized
INFO - 2022-07-06 07:45:06 --> Loader Class Initialized
INFO - 2022-07-06 07:45:06 --> Helper loaded: url_helper
INFO - 2022-07-06 07:45:06 --> Helper loaded: file_helper
INFO - 2022-07-06 07:45:06 --> Database Driver Class Initialized
INFO - 2022-07-06 07:45:06 --> Email Class Initialized
DEBUG - 2022-07-06 07:45:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:45:06 --> Controller Class Initialized
INFO - 2022-07-06 07:45:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:45:06 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:45:06 --> Final output sent to browser
DEBUG - 2022-07-06 07:45:06 --> Total execution time: 0.1437
INFO - 2022-07-06 07:45:33 --> Config Class Initialized
INFO - 2022-07-06 07:45:33 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:45:33 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:45:33 --> Utf8 Class Initialized
INFO - 2022-07-06 07:45:33 --> URI Class Initialized
INFO - 2022-07-06 07:45:33 --> Router Class Initialized
INFO - 2022-07-06 07:45:33 --> Output Class Initialized
INFO - 2022-07-06 07:45:33 --> Security Class Initialized
DEBUG - 2022-07-06 07:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:45:33 --> Input Class Initialized
INFO - 2022-07-06 07:45:33 --> Language Class Initialized
INFO - 2022-07-06 07:45:33 --> Loader Class Initialized
INFO - 2022-07-06 07:45:33 --> Helper loaded: url_helper
INFO - 2022-07-06 07:45:33 --> Helper loaded: file_helper
INFO - 2022-07-06 07:45:33 --> Database Driver Class Initialized
INFO - 2022-07-06 07:45:33 --> Email Class Initialized
DEBUG - 2022-07-06 07:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:45:33 --> Controller Class Initialized
INFO - 2022-07-06 07:45:33 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:45:33 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:45:33 --> Final output sent to browser
DEBUG - 2022-07-06 07:45:33 --> Total execution time: 0.0276
INFO - 2022-07-06 07:45:35 --> Config Class Initialized
INFO - 2022-07-06 07:45:35 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:45:35 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:45:35 --> Utf8 Class Initialized
INFO - 2022-07-06 07:45:35 --> URI Class Initialized
INFO - 2022-07-06 07:45:35 --> Router Class Initialized
INFO - 2022-07-06 07:45:35 --> Output Class Initialized
INFO - 2022-07-06 07:45:35 --> Security Class Initialized
DEBUG - 2022-07-06 07:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:45:35 --> Input Class Initialized
INFO - 2022-07-06 07:45:35 --> Language Class Initialized
INFO - 2022-07-06 07:45:35 --> Loader Class Initialized
INFO - 2022-07-06 07:45:35 --> Helper loaded: url_helper
INFO - 2022-07-06 07:45:35 --> Helper loaded: file_helper
INFO - 2022-07-06 07:45:35 --> Database Driver Class Initialized
INFO - 2022-07-06 07:45:35 --> Email Class Initialized
DEBUG - 2022-07-06 07:45:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:45:35 --> Controller Class Initialized
INFO - 2022-07-06 07:45:35 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:45:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-06 07:45:35 --> Severity: Notice --> Undefined variable: total C:\wamp64\www\qr\application\views\doc_screen\doctor.php 359
INFO - 2022-07-06 07:45:35 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-07-06 07:45:35 --> Final output sent to browser
DEBUG - 2022-07-06 07:45:35 --> Total execution time: 0.0187
INFO - 2022-07-06 07:45:39 --> Config Class Initialized
INFO - 2022-07-06 07:45:39 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:45:39 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:45:39 --> Utf8 Class Initialized
INFO - 2022-07-06 07:45:39 --> URI Class Initialized
INFO - 2022-07-06 07:45:39 --> Router Class Initialized
INFO - 2022-07-06 07:45:39 --> Output Class Initialized
INFO - 2022-07-06 07:45:39 --> Security Class Initialized
DEBUG - 2022-07-06 07:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:45:39 --> Input Class Initialized
INFO - 2022-07-06 07:45:39 --> Language Class Initialized
INFO - 2022-07-06 07:45:39 --> Loader Class Initialized
INFO - 2022-07-06 07:45:39 --> Helper loaded: url_helper
INFO - 2022-07-06 07:45:39 --> Helper loaded: file_helper
INFO - 2022-07-06 07:45:39 --> Database Driver Class Initialized
INFO - 2022-07-06 07:45:39 --> Email Class Initialized
DEBUG - 2022-07-06 07:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:45:39 --> Controller Class Initialized
INFO - 2022-07-06 07:45:39 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:45:39 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:45:39 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-07-06 07:45:39 --> Final output sent to browser
DEBUG - 2022-07-06 07:45:39 --> Total execution time: 0.1158
INFO - 2022-07-06 07:45:40 --> Config Class Initialized
INFO - 2022-07-06 07:45:40 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:45:40 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:45:40 --> Utf8 Class Initialized
INFO - 2022-07-06 07:45:40 --> URI Class Initialized
INFO - 2022-07-06 07:45:40 --> Router Class Initialized
INFO - 2022-07-06 07:45:40 --> Output Class Initialized
INFO - 2022-07-06 07:45:40 --> Security Class Initialized
DEBUG - 2022-07-06 07:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:45:40 --> Input Class Initialized
INFO - 2022-07-06 07:45:40 --> Language Class Initialized
INFO - 2022-07-06 07:45:40 --> Loader Class Initialized
INFO - 2022-07-06 07:45:40 --> Helper loaded: url_helper
INFO - 2022-07-06 07:45:40 --> Helper loaded: file_helper
INFO - 2022-07-06 07:45:40 --> Database Driver Class Initialized
INFO - 2022-07-06 07:45:40 --> Email Class Initialized
DEBUG - 2022-07-06 07:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:45:40 --> Controller Class Initialized
INFO - 2022-07-06 07:45:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:45:40 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:45:40 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-07-06 07:45:40 --> Final output sent to browser
DEBUG - 2022-07-06 07:45:40 --> Total execution time: 0.1390
INFO - 2022-07-06 07:45:40 --> Config Class Initialized
INFO - 2022-07-06 07:45:40 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:45:40 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:45:40 --> Utf8 Class Initialized
INFO - 2022-07-06 07:45:40 --> URI Class Initialized
INFO - 2022-07-06 07:45:40 --> Router Class Initialized
INFO - 2022-07-06 07:45:40 --> Output Class Initialized
INFO - 2022-07-06 07:45:40 --> Security Class Initialized
DEBUG - 2022-07-06 07:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:45:40 --> Input Class Initialized
INFO - 2022-07-06 07:45:40 --> Language Class Initialized
INFO - 2022-07-06 07:45:40 --> Loader Class Initialized
INFO - 2022-07-06 07:45:40 --> Helper loaded: url_helper
INFO - 2022-07-06 07:45:40 --> Helper loaded: file_helper
INFO - 2022-07-06 07:45:40 --> Database Driver Class Initialized
INFO - 2022-07-06 07:45:40 --> Email Class Initialized
DEBUG - 2022-07-06 07:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:45:40 --> Controller Class Initialized
INFO - 2022-07-06 07:45:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:45:40 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:45:40 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-07-06 07:45:40 --> Final output sent to browser
DEBUG - 2022-07-06 07:45:40 --> Total execution time: 0.0181
INFO - 2022-07-06 07:45:41 --> Config Class Initialized
INFO - 2022-07-06 07:45:41 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:45:41 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:45:41 --> Utf8 Class Initialized
INFO - 2022-07-06 07:45:41 --> URI Class Initialized
INFO - 2022-07-06 07:45:41 --> Router Class Initialized
INFO - 2022-07-06 07:45:41 --> Output Class Initialized
INFO - 2022-07-06 07:45:41 --> Security Class Initialized
DEBUG - 2022-07-06 07:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:45:41 --> Input Class Initialized
INFO - 2022-07-06 07:45:41 --> Language Class Initialized
INFO - 2022-07-06 07:45:41 --> Loader Class Initialized
INFO - 2022-07-06 07:45:41 --> Helper loaded: url_helper
INFO - 2022-07-06 07:45:41 --> Helper loaded: file_helper
INFO - 2022-07-06 07:45:41 --> Database Driver Class Initialized
INFO - 2022-07-06 07:45:41 --> Email Class Initialized
DEBUG - 2022-07-06 07:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:45:41 --> Controller Class Initialized
INFO - 2022-07-06 07:45:41 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:45:41 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:45:41 --> Final output sent to browser
DEBUG - 2022-07-06 07:45:41 --> Total execution time: 0.1424
INFO - 2022-07-06 07:45:41 --> Config Class Initialized
INFO - 2022-07-06 07:45:41 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:45:41 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:45:41 --> Utf8 Class Initialized
INFO - 2022-07-06 07:45:41 --> URI Class Initialized
INFO - 2022-07-06 07:45:41 --> Router Class Initialized
INFO - 2022-07-06 07:45:41 --> Output Class Initialized
INFO - 2022-07-06 07:45:41 --> Security Class Initialized
DEBUG - 2022-07-06 07:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:45:41 --> Input Class Initialized
INFO - 2022-07-06 07:45:41 --> Language Class Initialized
INFO - 2022-07-06 07:45:41 --> Loader Class Initialized
INFO - 2022-07-06 07:45:41 --> Helper loaded: url_helper
INFO - 2022-07-06 07:45:41 --> Helper loaded: file_helper
INFO - 2022-07-06 07:45:41 --> Database Driver Class Initialized
INFO - 2022-07-06 07:45:41 --> Email Class Initialized
DEBUG - 2022-07-06 07:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:45:41 --> Controller Class Initialized
INFO - 2022-07-06 07:45:41 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:45:41 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:45:41 --> Final output sent to browser
DEBUG - 2022-07-06 07:45:41 --> Total execution time: 0.1375
INFO - 2022-07-06 07:45:42 --> Config Class Initialized
INFO - 2022-07-06 07:45:42 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:45:42 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:45:42 --> Utf8 Class Initialized
INFO - 2022-07-06 07:45:42 --> URI Class Initialized
INFO - 2022-07-06 07:45:42 --> Router Class Initialized
INFO - 2022-07-06 07:45:42 --> Output Class Initialized
INFO - 2022-07-06 07:45:42 --> Security Class Initialized
DEBUG - 2022-07-06 07:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:45:42 --> Input Class Initialized
INFO - 2022-07-06 07:45:42 --> Language Class Initialized
INFO - 2022-07-06 07:45:42 --> Loader Class Initialized
INFO - 2022-07-06 07:45:42 --> Helper loaded: url_helper
INFO - 2022-07-06 07:45:42 --> Helper loaded: file_helper
INFO - 2022-07-06 07:45:42 --> Database Driver Class Initialized
INFO - 2022-07-06 07:45:42 --> Email Class Initialized
DEBUG - 2022-07-06 07:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:45:42 --> Controller Class Initialized
INFO - 2022-07-06 07:45:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:45:42 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:45:42 --> Final output sent to browser
DEBUG - 2022-07-06 07:45:42 --> Total execution time: 0.1204
INFO - 2022-07-06 07:45:42 --> Config Class Initialized
INFO - 2022-07-06 07:45:42 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:45:42 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:45:42 --> Utf8 Class Initialized
INFO - 2022-07-06 07:45:42 --> URI Class Initialized
INFO - 2022-07-06 07:45:42 --> Router Class Initialized
INFO - 2022-07-06 07:45:42 --> Output Class Initialized
INFO - 2022-07-06 07:45:42 --> Security Class Initialized
DEBUG - 2022-07-06 07:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:45:42 --> Input Class Initialized
INFO - 2022-07-06 07:45:42 --> Language Class Initialized
INFO - 2022-07-06 07:45:42 --> Loader Class Initialized
INFO - 2022-07-06 07:45:42 --> Helper loaded: url_helper
INFO - 2022-07-06 07:45:42 --> Helper loaded: file_helper
INFO - 2022-07-06 07:45:42 --> Database Driver Class Initialized
INFO - 2022-07-06 07:45:42 --> Email Class Initialized
DEBUG - 2022-07-06 07:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:45:42 --> Controller Class Initialized
INFO - 2022-07-06 07:45:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:45:42 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:45:42 --> Final output sent to browser
DEBUG - 2022-07-06 07:45:42 --> Total execution time: 0.0388
INFO - 2022-07-06 07:45:44 --> Config Class Initialized
INFO - 2022-07-06 07:45:44 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:45:44 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:45:44 --> Utf8 Class Initialized
INFO - 2022-07-06 07:45:44 --> URI Class Initialized
INFO - 2022-07-06 07:45:44 --> Router Class Initialized
INFO - 2022-07-06 07:45:44 --> Output Class Initialized
INFO - 2022-07-06 07:45:44 --> Security Class Initialized
DEBUG - 2022-07-06 07:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:45:44 --> Input Class Initialized
INFO - 2022-07-06 07:45:44 --> Language Class Initialized
INFO - 2022-07-06 07:45:44 --> Loader Class Initialized
INFO - 2022-07-06 07:45:44 --> Helper loaded: url_helper
INFO - 2022-07-06 07:45:44 --> Helper loaded: file_helper
INFO - 2022-07-06 07:45:44 --> Database Driver Class Initialized
INFO - 2022-07-06 07:45:44 --> Email Class Initialized
DEBUG - 2022-07-06 07:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:45:44 --> Controller Class Initialized
INFO - 2022-07-06 07:45:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:45:44 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:45:44 --> Final output sent to browser
DEBUG - 2022-07-06 07:45:44 --> Total execution time: 0.0404
INFO - 2022-07-06 07:45:44 --> Config Class Initialized
INFO - 2022-07-06 07:45:44 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:45:44 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:45:44 --> Utf8 Class Initialized
INFO - 2022-07-06 07:45:44 --> URI Class Initialized
INFO - 2022-07-06 07:45:44 --> Router Class Initialized
INFO - 2022-07-06 07:45:44 --> Output Class Initialized
INFO - 2022-07-06 07:45:44 --> Security Class Initialized
DEBUG - 2022-07-06 07:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:45:44 --> Input Class Initialized
INFO - 2022-07-06 07:45:44 --> Language Class Initialized
INFO - 2022-07-06 07:45:44 --> Loader Class Initialized
INFO - 2022-07-06 07:45:44 --> Helper loaded: url_helper
INFO - 2022-07-06 07:45:44 --> Helper loaded: file_helper
INFO - 2022-07-06 07:45:44 --> Database Driver Class Initialized
INFO - 2022-07-06 07:45:44 --> Email Class Initialized
DEBUG - 2022-07-06 07:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:45:44 --> Controller Class Initialized
INFO - 2022-07-06 07:45:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:45:44 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:45:44 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-06 07:45:44 --> Final output sent to browser
DEBUG - 2022-07-06 07:45:44 --> Total execution time: 0.0163
INFO - 2022-07-06 07:45:46 --> Config Class Initialized
INFO - 2022-07-06 07:45:46 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:45:46 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:45:46 --> Utf8 Class Initialized
INFO - 2022-07-06 07:45:46 --> URI Class Initialized
INFO - 2022-07-06 07:45:46 --> Router Class Initialized
INFO - 2022-07-06 07:45:46 --> Output Class Initialized
INFO - 2022-07-06 07:45:46 --> Security Class Initialized
DEBUG - 2022-07-06 07:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:45:46 --> Input Class Initialized
INFO - 2022-07-06 07:45:46 --> Language Class Initialized
INFO - 2022-07-06 07:45:46 --> Loader Class Initialized
INFO - 2022-07-06 07:45:46 --> Helper loaded: url_helper
INFO - 2022-07-06 07:45:46 --> Helper loaded: file_helper
INFO - 2022-07-06 07:45:46 --> Database Driver Class Initialized
INFO - 2022-07-06 07:45:46 --> Email Class Initialized
DEBUG - 2022-07-06 07:45:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:45:46 --> Controller Class Initialized
INFO - 2022-07-06 07:45:46 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:45:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-06 07:45:46 --> Severity: Notice --> Undefined variable: total C:\wamp64\www\qr\application\views\doc_screen\doctor.php 359
INFO - 2022-07-06 07:45:46 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-07-06 07:45:46 --> Final output sent to browser
DEBUG - 2022-07-06 07:45:46 --> Total execution time: 0.1564
INFO - 2022-07-06 07:45:48 --> Config Class Initialized
INFO - 2022-07-06 07:45:48 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:45:48 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:45:48 --> Utf8 Class Initialized
INFO - 2022-07-06 07:45:48 --> URI Class Initialized
INFO - 2022-07-06 07:45:48 --> Router Class Initialized
INFO - 2022-07-06 07:45:48 --> Output Class Initialized
INFO - 2022-07-06 07:45:48 --> Security Class Initialized
DEBUG - 2022-07-06 07:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:45:48 --> Input Class Initialized
INFO - 2022-07-06 07:45:48 --> Language Class Initialized
INFO - 2022-07-06 07:45:48 --> Loader Class Initialized
INFO - 2022-07-06 07:45:48 --> Helper loaded: url_helper
INFO - 2022-07-06 07:45:48 --> Helper loaded: file_helper
INFO - 2022-07-06 07:45:48 --> Database Driver Class Initialized
INFO - 2022-07-06 07:45:48 --> Email Class Initialized
DEBUG - 2022-07-06 07:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:45:48 --> Controller Class Initialized
INFO - 2022-07-06 07:45:48 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:45:48 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:45:48 --> Final output sent to browser
DEBUG - 2022-07-06 07:45:48 --> Total execution time: 0.1427
INFO - 2022-07-06 07:45:48 --> Config Class Initialized
INFO - 2022-07-06 07:45:48 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:45:48 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:45:48 --> Utf8 Class Initialized
INFO - 2022-07-06 07:45:48 --> URI Class Initialized
INFO - 2022-07-06 07:45:48 --> Router Class Initialized
INFO - 2022-07-06 07:45:48 --> Output Class Initialized
INFO - 2022-07-06 07:45:48 --> Security Class Initialized
DEBUG - 2022-07-06 07:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:45:48 --> Input Class Initialized
INFO - 2022-07-06 07:45:48 --> Language Class Initialized
INFO - 2022-07-06 07:45:48 --> Loader Class Initialized
INFO - 2022-07-06 07:45:48 --> Helper loaded: url_helper
INFO - 2022-07-06 07:45:48 --> Helper loaded: file_helper
INFO - 2022-07-06 07:45:48 --> Database Driver Class Initialized
INFO - 2022-07-06 07:45:48 --> Email Class Initialized
DEBUG - 2022-07-06 07:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:45:48 --> Controller Class Initialized
INFO - 2022-07-06 07:45:48 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:45:48 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:45:48 --> Final output sent to browser
DEBUG - 2022-07-06 07:45:48 --> Total execution time: 0.1288
INFO - 2022-07-06 07:45:50 --> Config Class Initialized
INFO - 2022-07-06 07:45:50 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:45:50 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:45:50 --> Utf8 Class Initialized
INFO - 2022-07-06 07:45:50 --> URI Class Initialized
INFO - 2022-07-06 07:45:50 --> Router Class Initialized
INFO - 2022-07-06 07:45:50 --> Output Class Initialized
INFO - 2022-07-06 07:45:50 --> Security Class Initialized
DEBUG - 2022-07-06 07:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:45:50 --> Input Class Initialized
INFO - 2022-07-06 07:45:50 --> Language Class Initialized
INFO - 2022-07-06 07:45:50 --> Loader Class Initialized
INFO - 2022-07-06 07:45:50 --> Helper loaded: url_helper
INFO - 2022-07-06 07:45:50 --> Helper loaded: file_helper
INFO - 2022-07-06 07:45:50 --> Database Driver Class Initialized
INFO - 2022-07-06 07:45:50 --> Email Class Initialized
DEBUG - 2022-07-06 07:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:45:50 --> Controller Class Initialized
INFO - 2022-07-06 07:45:50 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:45:50 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:45:50 --> Final output sent to browser
DEBUG - 2022-07-06 07:45:50 --> Total execution time: 0.1205
INFO - 2022-07-06 07:45:50 --> Config Class Initialized
INFO - 2022-07-06 07:45:50 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:45:50 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:45:50 --> Utf8 Class Initialized
INFO - 2022-07-06 07:45:50 --> URI Class Initialized
INFO - 2022-07-06 07:45:50 --> Router Class Initialized
INFO - 2022-07-06 07:45:50 --> Output Class Initialized
INFO - 2022-07-06 07:45:50 --> Security Class Initialized
DEBUG - 2022-07-06 07:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:45:50 --> Input Class Initialized
INFO - 2022-07-06 07:45:50 --> Language Class Initialized
INFO - 2022-07-06 07:45:50 --> Loader Class Initialized
INFO - 2022-07-06 07:45:50 --> Helper loaded: url_helper
INFO - 2022-07-06 07:45:50 --> Helper loaded: file_helper
INFO - 2022-07-06 07:45:50 --> Database Driver Class Initialized
INFO - 2022-07-06 07:45:50 --> Email Class Initialized
DEBUG - 2022-07-06 07:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:45:50 --> Controller Class Initialized
INFO - 2022-07-06 07:45:50 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:45:50 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:45:50 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-06 07:45:50 --> Final output sent to browser
DEBUG - 2022-07-06 07:45:50 --> Total execution time: 0.0293
INFO - 2022-07-06 07:45:52 --> Config Class Initialized
INFO - 2022-07-06 07:45:52 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:45:52 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:45:52 --> Utf8 Class Initialized
INFO - 2022-07-06 07:45:52 --> URI Class Initialized
INFO - 2022-07-06 07:45:52 --> Router Class Initialized
INFO - 2022-07-06 07:45:52 --> Output Class Initialized
INFO - 2022-07-06 07:45:52 --> Security Class Initialized
DEBUG - 2022-07-06 07:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:45:52 --> Input Class Initialized
INFO - 2022-07-06 07:45:52 --> Language Class Initialized
INFO - 2022-07-06 07:45:52 --> Loader Class Initialized
INFO - 2022-07-06 07:45:52 --> Helper loaded: url_helper
INFO - 2022-07-06 07:45:52 --> Helper loaded: file_helper
INFO - 2022-07-06 07:45:52 --> Database Driver Class Initialized
INFO - 2022-07-06 07:45:52 --> Email Class Initialized
DEBUG - 2022-07-06 07:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:45:52 --> Controller Class Initialized
INFO - 2022-07-06 07:45:52 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:45:52 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:45:52 --> Final output sent to browser
DEBUG - 2022-07-06 07:45:52 --> Total execution time: 0.1531
INFO - 2022-07-06 07:45:55 --> Config Class Initialized
INFO - 2022-07-06 07:45:55 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:45:55 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:45:55 --> Utf8 Class Initialized
INFO - 2022-07-06 07:45:55 --> URI Class Initialized
INFO - 2022-07-06 07:45:55 --> Router Class Initialized
INFO - 2022-07-06 07:45:55 --> Output Class Initialized
INFO - 2022-07-06 07:45:55 --> Security Class Initialized
DEBUG - 2022-07-06 07:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:45:55 --> Input Class Initialized
INFO - 2022-07-06 07:45:55 --> Language Class Initialized
INFO - 2022-07-06 07:45:55 --> Loader Class Initialized
INFO - 2022-07-06 07:45:55 --> Helper loaded: url_helper
INFO - 2022-07-06 07:45:55 --> Helper loaded: file_helper
INFO - 2022-07-06 07:45:55 --> Database Driver Class Initialized
INFO - 2022-07-06 07:45:55 --> Email Class Initialized
DEBUG - 2022-07-06 07:45:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:45:55 --> Controller Class Initialized
INFO - 2022-07-06 07:45:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:45:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-06 07:45:55 --> Severity: Notice --> Undefined variable: total C:\wamp64\www\qr\application\views\doc_screen\doctor.php 359
INFO - 2022-07-06 07:45:55 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-07-06 07:45:55 --> Final output sent to browser
DEBUG - 2022-07-06 07:45:55 --> Total execution time: 0.0214
INFO - 2022-07-06 07:45:57 --> Config Class Initialized
INFO - 2022-07-06 07:45:57 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:45:57 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:45:57 --> Utf8 Class Initialized
INFO - 2022-07-06 07:45:57 --> URI Class Initialized
INFO - 2022-07-06 07:45:57 --> Router Class Initialized
INFO - 2022-07-06 07:45:57 --> Output Class Initialized
INFO - 2022-07-06 07:45:57 --> Security Class Initialized
DEBUG - 2022-07-06 07:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:45:57 --> Input Class Initialized
INFO - 2022-07-06 07:45:57 --> Language Class Initialized
INFO - 2022-07-06 07:45:57 --> Loader Class Initialized
INFO - 2022-07-06 07:45:57 --> Helper loaded: url_helper
INFO - 2022-07-06 07:45:57 --> Helper loaded: file_helper
INFO - 2022-07-06 07:45:57 --> Database Driver Class Initialized
INFO - 2022-07-06 07:45:57 --> Email Class Initialized
DEBUG - 2022-07-06 07:45:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:45:57 --> Controller Class Initialized
INFO - 2022-07-06 07:45:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:45:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:45:57 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-07-06 07:45:57 --> Final output sent to browser
DEBUG - 2022-07-06 07:45:57 --> Total execution time: 0.1130
INFO - 2022-07-06 07:45:57 --> Config Class Initialized
INFO - 2022-07-06 07:45:57 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:45:57 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:45:57 --> Utf8 Class Initialized
INFO - 2022-07-06 07:45:57 --> URI Class Initialized
INFO - 2022-07-06 07:45:57 --> Router Class Initialized
INFO - 2022-07-06 07:45:57 --> Output Class Initialized
INFO - 2022-07-06 07:45:57 --> Security Class Initialized
DEBUG - 2022-07-06 07:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:45:57 --> Input Class Initialized
INFO - 2022-07-06 07:45:57 --> Language Class Initialized
INFO - 2022-07-06 07:45:57 --> Loader Class Initialized
INFO - 2022-07-06 07:45:57 --> Helper loaded: url_helper
INFO - 2022-07-06 07:45:57 --> Helper loaded: file_helper
INFO - 2022-07-06 07:45:57 --> Database Driver Class Initialized
INFO - 2022-07-06 07:45:57 --> Email Class Initialized
DEBUG - 2022-07-06 07:45:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:45:57 --> Controller Class Initialized
INFO - 2022-07-06 07:45:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:45:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:45:57 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-07-06 07:45:57 --> Final output sent to browser
DEBUG - 2022-07-06 07:45:57 --> Total execution time: 0.0182
INFO - 2022-07-06 07:45:57 --> Config Class Initialized
INFO - 2022-07-06 07:45:57 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:45:57 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:45:57 --> Utf8 Class Initialized
INFO - 2022-07-06 07:45:57 --> URI Class Initialized
INFO - 2022-07-06 07:45:57 --> Router Class Initialized
INFO - 2022-07-06 07:45:57 --> Output Class Initialized
INFO - 2022-07-06 07:45:57 --> Security Class Initialized
DEBUG - 2022-07-06 07:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:45:57 --> Input Class Initialized
INFO - 2022-07-06 07:45:57 --> Language Class Initialized
INFO - 2022-07-06 07:45:57 --> Loader Class Initialized
INFO - 2022-07-06 07:45:57 --> Helper loaded: url_helper
INFO - 2022-07-06 07:45:57 --> Helper loaded: file_helper
INFO - 2022-07-06 07:45:57 --> Database Driver Class Initialized
INFO - 2022-07-06 07:45:57 --> Email Class Initialized
DEBUG - 2022-07-06 07:45:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:45:57 --> Controller Class Initialized
INFO - 2022-07-06 07:45:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:45:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:45:58 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-07-06 07:45:58 --> Final output sent to browser
DEBUG - 2022-07-06 07:45:58 --> Total execution time: 0.1216
INFO - 2022-07-06 07:54:41 --> Config Class Initialized
INFO - 2022-07-06 07:54:41 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:54:41 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:54:41 --> Utf8 Class Initialized
INFO - 2022-07-06 07:54:41 --> URI Class Initialized
INFO - 2022-07-06 07:54:41 --> Router Class Initialized
INFO - 2022-07-06 07:54:41 --> Output Class Initialized
INFO - 2022-07-06 07:54:41 --> Security Class Initialized
DEBUG - 2022-07-06 07:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:54:41 --> Input Class Initialized
INFO - 2022-07-06 07:54:41 --> Language Class Initialized
INFO - 2022-07-06 07:54:41 --> Loader Class Initialized
INFO - 2022-07-06 07:54:41 --> Helper loaded: url_helper
INFO - 2022-07-06 07:54:41 --> Helper loaded: file_helper
INFO - 2022-07-06 07:54:41 --> Database Driver Class Initialized
INFO - 2022-07-06 07:54:41 --> Email Class Initialized
DEBUG - 2022-07-06 07:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:54:41 --> Controller Class Initialized
INFO - 2022-07-06 07:54:41 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:54:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-06 07:54:41 --> Query error: Unknown column 'td_id' in 'field list' - Invalid query: select count(td_id) from tokendetails where td_ss =1 and td_visited_date ='2022-07-06' 
INFO - 2022-07-06 07:54:41 --> Language file loaded: language/english/db_lang.php
INFO - 2022-07-06 07:55:08 --> Config Class Initialized
INFO - 2022-07-06 07:55:08 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:55:08 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:55:08 --> Utf8 Class Initialized
INFO - 2022-07-06 07:55:08 --> URI Class Initialized
INFO - 2022-07-06 07:55:08 --> Router Class Initialized
INFO - 2022-07-06 07:55:08 --> Output Class Initialized
INFO - 2022-07-06 07:55:08 --> Security Class Initialized
DEBUG - 2022-07-06 07:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:55:08 --> Input Class Initialized
INFO - 2022-07-06 07:55:08 --> Language Class Initialized
INFO - 2022-07-06 07:55:08 --> Loader Class Initialized
INFO - 2022-07-06 07:55:08 --> Helper loaded: url_helper
INFO - 2022-07-06 07:55:08 --> Helper loaded: file_helper
INFO - 2022-07-06 07:55:08 --> Database Driver Class Initialized
INFO - 2022-07-06 07:55:08 --> Email Class Initialized
DEBUG - 2022-07-06 07:55:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:55:08 --> Controller Class Initialized
INFO - 2022-07-06 07:55:09 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:55:09 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:55:38 --> Config Class Initialized
INFO - 2022-07-06 07:55:38 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:55:38 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:55:38 --> Utf8 Class Initialized
INFO - 2022-07-06 07:55:38 --> URI Class Initialized
INFO - 2022-07-06 07:55:38 --> Router Class Initialized
INFO - 2022-07-06 07:55:38 --> Output Class Initialized
INFO - 2022-07-06 07:55:38 --> Security Class Initialized
DEBUG - 2022-07-06 07:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:55:38 --> Input Class Initialized
INFO - 2022-07-06 07:55:38 --> Language Class Initialized
INFO - 2022-07-06 07:55:38 --> Loader Class Initialized
INFO - 2022-07-06 07:55:38 --> Helper loaded: url_helper
INFO - 2022-07-06 07:55:38 --> Helper loaded: file_helper
INFO - 2022-07-06 07:55:38 --> Database Driver Class Initialized
INFO - 2022-07-06 07:55:38 --> Email Class Initialized
DEBUG - 2022-07-06 07:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:55:38 --> Controller Class Initialized
INFO - 2022-07-06 07:55:38 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:55:38 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:56:11 --> Config Class Initialized
INFO - 2022-07-06 07:56:11 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:56:11 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:56:11 --> Utf8 Class Initialized
INFO - 2022-07-06 07:56:11 --> URI Class Initialized
INFO - 2022-07-06 07:56:11 --> Router Class Initialized
INFO - 2022-07-06 07:56:11 --> Output Class Initialized
INFO - 2022-07-06 07:56:11 --> Security Class Initialized
DEBUG - 2022-07-06 07:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:56:11 --> Input Class Initialized
INFO - 2022-07-06 07:56:11 --> Language Class Initialized
INFO - 2022-07-06 07:56:11 --> Loader Class Initialized
INFO - 2022-07-06 07:56:11 --> Helper loaded: url_helper
INFO - 2022-07-06 07:56:11 --> Helper loaded: file_helper
INFO - 2022-07-06 07:56:11 --> Database Driver Class Initialized
INFO - 2022-07-06 07:56:11 --> Email Class Initialized
DEBUG - 2022-07-06 07:56:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:56:11 --> Controller Class Initialized
INFO - 2022-07-06 07:56:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:56:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:57:32 --> Config Class Initialized
INFO - 2022-07-06 07:57:32 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:57:32 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:57:32 --> Utf8 Class Initialized
INFO - 2022-07-06 07:57:32 --> URI Class Initialized
INFO - 2022-07-06 07:57:32 --> Router Class Initialized
INFO - 2022-07-06 07:57:32 --> Output Class Initialized
INFO - 2022-07-06 07:57:32 --> Security Class Initialized
DEBUG - 2022-07-06 07:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:57:32 --> Input Class Initialized
INFO - 2022-07-06 07:57:32 --> Language Class Initialized
INFO - 2022-07-06 07:57:32 --> Loader Class Initialized
INFO - 2022-07-06 07:57:32 --> Helper loaded: url_helper
INFO - 2022-07-06 07:57:32 --> Helper loaded: file_helper
INFO - 2022-07-06 07:57:32 --> Database Driver Class Initialized
INFO - 2022-07-06 07:57:32 --> Email Class Initialized
DEBUG - 2022-07-06 07:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:57:32 --> Controller Class Initialized
INFO - 2022-07-06 07:57:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:57:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-06 07:57:32 --> Severity: Notice --> Undefined variable: total C:\wamp64\www\qr\application\views\doc_screen\doctor.php 359
ERROR - 2022-07-06 07:57:32 --> Severity: Notice --> Undefined variable: skip_count C:\wamp64\www\qr\application\views\doc_screen\doctor.php 361
INFO - 2022-07-06 07:57:32 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-07-06 07:57:32 --> Final output sent to browser
DEBUG - 2022-07-06 07:57:32 --> Total execution time: 0.1399
INFO - 2022-07-06 07:58:09 --> Config Class Initialized
INFO - 2022-07-06 07:58:09 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:58:09 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:58:09 --> Utf8 Class Initialized
INFO - 2022-07-06 07:58:09 --> URI Class Initialized
INFO - 2022-07-06 07:58:09 --> Router Class Initialized
INFO - 2022-07-06 07:58:09 --> Output Class Initialized
INFO - 2022-07-06 07:58:09 --> Security Class Initialized
DEBUG - 2022-07-06 07:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:58:09 --> Input Class Initialized
INFO - 2022-07-06 07:58:09 --> Language Class Initialized
INFO - 2022-07-06 07:58:09 --> Loader Class Initialized
INFO - 2022-07-06 07:58:09 --> Helper loaded: url_helper
INFO - 2022-07-06 07:58:09 --> Helper loaded: file_helper
INFO - 2022-07-06 07:58:09 --> Database Driver Class Initialized
INFO - 2022-07-06 07:58:09 --> Email Class Initialized
DEBUG - 2022-07-06 07:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:58:09 --> Controller Class Initialized
INFO - 2022-07-06 07:58:09 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:58:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-06 07:58:09 --> Severity: Notice --> Undefined variable: total C:\wamp64\www\qr\application\views\doc_screen\doctor.php 359
ERROR - 2022-07-06 07:58:09 --> Severity: Notice --> Undefined variable: skip_count C:\wamp64\www\qr\application\views\doc_screen\doctor.php 361
INFO - 2022-07-06 07:58:09 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-07-06 07:58:09 --> Final output sent to browser
DEBUG - 2022-07-06 07:58:09 --> Total execution time: 0.1549
INFO - 2022-07-06 07:59:10 --> Config Class Initialized
INFO - 2022-07-06 07:59:10 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:59:10 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:59:10 --> Utf8 Class Initialized
INFO - 2022-07-06 07:59:10 --> URI Class Initialized
INFO - 2022-07-06 07:59:10 --> Router Class Initialized
INFO - 2022-07-06 07:59:10 --> Output Class Initialized
INFO - 2022-07-06 07:59:10 --> Security Class Initialized
DEBUG - 2022-07-06 07:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:59:10 --> Input Class Initialized
INFO - 2022-07-06 07:59:10 --> Language Class Initialized
INFO - 2022-07-06 07:59:10 --> Loader Class Initialized
INFO - 2022-07-06 07:59:10 --> Helper loaded: url_helper
INFO - 2022-07-06 07:59:10 --> Helper loaded: file_helper
INFO - 2022-07-06 07:59:10 --> Database Driver Class Initialized
INFO - 2022-07-06 07:59:10 --> Email Class Initialized
DEBUG - 2022-07-06 07:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:59:10 --> Controller Class Initialized
INFO - 2022-07-06 07:59:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:59:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-06 07:59:10 --> Severity: Notice --> Undefined variable: total C:\wamp64\www\qr\application\views\doc_screen\doctor.php 359
INFO - 2022-07-06 07:59:10 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-07-06 07:59:10 --> Final output sent to browser
DEBUG - 2022-07-06 07:59:10 --> Total execution time: 0.3838
INFO - 2022-07-06 07:59:13 --> Config Class Initialized
INFO - 2022-07-06 07:59:13 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:59:13 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:59:13 --> Utf8 Class Initialized
INFO - 2022-07-06 07:59:13 --> URI Class Initialized
INFO - 2022-07-06 07:59:13 --> Router Class Initialized
INFO - 2022-07-06 07:59:13 --> Output Class Initialized
INFO - 2022-07-06 07:59:13 --> Security Class Initialized
DEBUG - 2022-07-06 07:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:59:13 --> Input Class Initialized
INFO - 2022-07-06 07:59:13 --> Language Class Initialized
INFO - 2022-07-06 07:59:13 --> Loader Class Initialized
INFO - 2022-07-06 07:59:13 --> Helper loaded: url_helper
INFO - 2022-07-06 07:59:13 --> Helper loaded: file_helper
INFO - 2022-07-06 07:59:13 --> Database Driver Class Initialized
INFO - 2022-07-06 07:59:13 --> Email Class Initialized
DEBUG - 2022-07-06 07:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:59:13 --> Controller Class Initialized
INFO - 2022-07-06 07:59:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:59:13 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:59:13 --> Final output sent to browser
DEBUG - 2022-07-06 07:59:13 --> Total execution time: 0.0291
INFO - 2022-07-06 07:59:14 --> Config Class Initialized
INFO - 2022-07-06 07:59:14 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:59:14 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:59:14 --> Utf8 Class Initialized
INFO - 2022-07-06 07:59:14 --> URI Class Initialized
INFO - 2022-07-06 07:59:14 --> Router Class Initialized
INFO - 2022-07-06 07:59:14 --> Output Class Initialized
INFO - 2022-07-06 07:59:14 --> Security Class Initialized
DEBUG - 2022-07-06 07:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:59:14 --> Input Class Initialized
INFO - 2022-07-06 07:59:14 --> Language Class Initialized
INFO - 2022-07-06 07:59:14 --> Loader Class Initialized
INFO - 2022-07-06 07:59:14 --> Helper loaded: url_helper
INFO - 2022-07-06 07:59:14 --> Helper loaded: file_helper
INFO - 2022-07-06 07:59:14 --> Database Driver Class Initialized
INFO - 2022-07-06 07:59:14 --> Email Class Initialized
DEBUG - 2022-07-06 07:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:59:14 --> Controller Class Initialized
INFO - 2022-07-06 07:59:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:59:14 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:59:14 --> Final output sent to browser
DEBUG - 2022-07-06 07:59:14 --> Total execution time: 0.0157
INFO - 2022-07-06 07:59:16 --> Config Class Initialized
INFO - 2022-07-06 07:59:16 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:59:16 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:59:16 --> Utf8 Class Initialized
INFO - 2022-07-06 07:59:16 --> URI Class Initialized
INFO - 2022-07-06 07:59:16 --> Router Class Initialized
INFO - 2022-07-06 07:59:16 --> Output Class Initialized
INFO - 2022-07-06 07:59:16 --> Security Class Initialized
DEBUG - 2022-07-06 07:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:59:16 --> Input Class Initialized
INFO - 2022-07-06 07:59:16 --> Language Class Initialized
INFO - 2022-07-06 07:59:16 --> Loader Class Initialized
INFO - 2022-07-06 07:59:16 --> Helper loaded: url_helper
INFO - 2022-07-06 07:59:16 --> Helper loaded: file_helper
INFO - 2022-07-06 07:59:16 --> Database Driver Class Initialized
INFO - 2022-07-06 07:59:16 --> Email Class Initialized
DEBUG - 2022-07-06 07:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:59:16 --> Controller Class Initialized
INFO - 2022-07-06 07:59:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:59:16 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:59:16 --> Final output sent to browser
DEBUG - 2022-07-06 07:59:16 --> Total execution time: 0.0164
INFO - 2022-07-06 07:59:16 --> Config Class Initialized
INFO - 2022-07-06 07:59:16 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:59:16 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:59:16 --> Utf8 Class Initialized
INFO - 2022-07-06 07:59:16 --> URI Class Initialized
INFO - 2022-07-06 07:59:16 --> Router Class Initialized
INFO - 2022-07-06 07:59:16 --> Output Class Initialized
INFO - 2022-07-06 07:59:16 --> Security Class Initialized
DEBUG - 2022-07-06 07:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:59:16 --> Input Class Initialized
INFO - 2022-07-06 07:59:16 --> Language Class Initialized
INFO - 2022-07-06 07:59:16 --> Loader Class Initialized
INFO - 2022-07-06 07:59:16 --> Helper loaded: url_helper
INFO - 2022-07-06 07:59:16 --> Helper loaded: file_helper
INFO - 2022-07-06 07:59:16 --> Database Driver Class Initialized
INFO - 2022-07-06 07:59:16 --> Email Class Initialized
DEBUG - 2022-07-06 07:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:59:16 --> Controller Class Initialized
INFO - 2022-07-06 07:59:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:59:16 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:59:16 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-06 07:59:16 --> Final output sent to browser
DEBUG - 2022-07-06 07:59:16 --> Total execution time: 0.0155
INFO - 2022-07-06 07:59:19 --> Config Class Initialized
INFO - 2022-07-06 07:59:19 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:59:19 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:59:19 --> Utf8 Class Initialized
INFO - 2022-07-06 07:59:19 --> URI Class Initialized
INFO - 2022-07-06 07:59:19 --> Router Class Initialized
INFO - 2022-07-06 07:59:19 --> Output Class Initialized
INFO - 2022-07-06 07:59:19 --> Security Class Initialized
DEBUG - 2022-07-06 07:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:59:19 --> Input Class Initialized
INFO - 2022-07-06 07:59:19 --> Language Class Initialized
INFO - 2022-07-06 07:59:19 --> Loader Class Initialized
INFO - 2022-07-06 07:59:19 --> Helper loaded: url_helper
INFO - 2022-07-06 07:59:19 --> Helper loaded: file_helper
INFO - 2022-07-06 07:59:19 --> Database Driver Class Initialized
INFO - 2022-07-06 07:59:19 --> Email Class Initialized
DEBUG - 2022-07-06 07:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:59:19 --> Controller Class Initialized
INFO - 2022-07-06 07:59:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:59:19 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:59:19 --> Final output sent to browser
DEBUG - 2022-07-06 07:59:19 --> Total execution time: 0.1525
INFO - 2022-07-06 07:59:22 --> Config Class Initialized
INFO - 2022-07-06 07:59:22 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:59:22 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:59:22 --> Utf8 Class Initialized
INFO - 2022-07-06 07:59:22 --> URI Class Initialized
INFO - 2022-07-06 07:59:22 --> Router Class Initialized
INFO - 2022-07-06 07:59:22 --> Output Class Initialized
INFO - 2022-07-06 07:59:22 --> Security Class Initialized
DEBUG - 2022-07-06 07:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:59:22 --> Input Class Initialized
INFO - 2022-07-06 07:59:22 --> Language Class Initialized
INFO - 2022-07-06 07:59:22 --> Loader Class Initialized
INFO - 2022-07-06 07:59:22 --> Helper loaded: url_helper
INFO - 2022-07-06 07:59:22 --> Helper loaded: file_helper
INFO - 2022-07-06 07:59:22 --> Database Driver Class Initialized
INFO - 2022-07-06 07:59:22 --> Email Class Initialized
DEBUG - 2022-07-06 07:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:59:22 --> Controller Class Initialized
INFO - 2022-07-06 07:59:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:59:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-06 07:59:22 --> Severity: Notice --> Undefined variable: total C:\wamp64\www\qr\application\views\doc_screen\doctor.php 359
INFO - 2022-07-06 07:59:22 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-07-06 07:59:22 --> Final output sent to browser
DEBUG - 2022-07-06 07:59:22 --> Total execution time: 0.0192
INFO - 2022-07-06 07:59:24 --> Config Class Initialized
INFO - 2022-07-06 07:59:24 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:59:24 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:59:24 --> Utf8 Class Initialized
INFO - 2022-07-06 07:59:24 --> URI Class Initialized
INFO - 2022-07-06 07:59:24 --> Router Class Initialized
INFO - 2022-07-06 07:59:24 --> Output Class Initialized
INFO - 2022-07-06 07:59:24 --> Security Class Initialized
DEBUG - 2022-07-06 07:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:59:24 --> Input Class Initialized
INFO - 2022-07-06 07:59:24 --> Language Class Initialized
INFO - 2022-07-06 07:59:24 --> Loader Class Initialized
INFO - 2022-07-06 07:59:24 --> Helper loaded: url_helper
INFO - 2022-07-06 07:59:24 --> Helper loaded: file_helper
INFO - 2022-07-06 07:59:24 --> Database Driver Class Initialized
INFO - 2022-07-06 07:59:24 --> Email Class Initialized
DEBUG - 2022-07-06 07:59:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:59:24 --> Controller Class Initialized
INFO - 2022-07-06 07:59:24 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:59:24 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:59:24 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-07-06 07:59:24 --> Final output sent to browser
DEBUG - 2022-07-06 07:59:24 --> Total execution time: 0.1208
INFO - 2022-07-06 07:59:26 --> Config Class Initialized
INFO - 2022-07-06 07:59:26 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:59:26 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:59:26 --> Utf8 Class Initialized
INFO - 2022-07-06 07:59:26 --> URI Class Initialized
INFO - 2022-07-06 07:59:26 --> Router Class Initialized
INFO - 2022-07-06 07:59:26 --> Output Class Initialized
INFO - 2022-07-06 07:59:26 --> Security Class Initialized
DEBUG - 2022-07-06 07:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:59:26 --> Input Class Initialized
INFO - 2022-07-06 07:59:26 --> Language Class Initialized
INFO - 2022-07-06 07:59:26 --> Loader Class Initialized
INFO - 2022-07-06 07:59:26 --> Helper loaded: url_helper
INFO - 2022-07-06 07:59:26 --> Helper loaded: file_helper
INFO - 2022-07-06 07:59:26 --> Database Driver Class Initialized
INFO - 2022-07-06 07:59:26 --> Email Class Initialized
DEBUG - 2022-07-06 07:59:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:59:26 --> Controller Class Initialized
INFO - 2022-07-06 07:59:26 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:59:26 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:59:26 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-07-06 07:59:26 --> Final output sent to browser
DEBUG - 2022-07-06 07:59:26 --> Total execution time: 0.0418
INFO - 2022-07-06 07:59:27 --> Config Class Initialized
INFO - 2022-07-06 07:59:27 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:59:27 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:59:27 --> Utf8 Class Initialized
INFO - 2022-07-06 07:59:27 --> URI Class Initialized
INFO - 2022-07-06 07:59:27 --> Router Class Initialized
INFO - 2022-07-06 07:59:27 --> Output Class Initialized
INFO - 2022-07-06 07:59:27 --> Security Class Initialized
DEBUG - 2022-07-06 07:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:59:27 --> Input Class Initialized
INFO - 2022-07-06 07:59:27 --> Language Class Initialized
INFO - 2022-07-06 07:59:27 --> Loader Class Initialized
INFO - 2022-07-06 07:59:27 --> Helper loaded: url_helper
INFO - 2022-07-06 07:59:27 --> Helper loaded: file_helper
INFO - 2022-07-06 07:59:27 --> Database Driver Class Initialized
INFO - 2022-07-06 07:59:27 --> Email Class Initialized
DEBUG - 2022-07-06 07:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:59:27 --> Controller Class Initialized
INFO - 2022-07-06 07:59:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:59:27 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:59:27 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-07-06 07:59:27 --> Final output sent to browser
DEBUG - 2022-07-06 07:59:27 --> Total execution time: 0.1746
INFO - 2022-07-06 07:59:29 --> Config Class Initialized
INFO - 2022-07-06 07:59:29 --> Hooks Class Initialized
DEBUG - 2022-07-06 07:59:29 --> UTF-8 Support Enabled
INFO - 2022-07-06 07:59:29 --> Utf8 Class Initialized
INFO - 2022-07-06 07:59:29 --> URI Class Initialized
INFO - 2022-07-06 07:59:29 --> Router Class Initialized
INFO - 2022-07-06 07:59:29 --> Output Class Initialized
INFO - 2022-07-06 07:59:29 --> Security Class Initialized
DEBUG - 2022-07-06 07:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 07:59:29 --> Input Class Initialized
INFO - 2022-07-06 07:59:29 --> Language Class Initialized
INFO - 2022-07-06 07:59:29 --> Loader Class Initialized
INFO - 2022-07-06 07:59:29 --> Helper loaded: url_helper
INFO - 2022-07-06 07:59:29 --> Helper loaded: file_helper
INFO - 2022-07-06 07:59:29 --> Database Driver Class Initialized
INFO - 2022-07-06 07:59:29 --> Email Class Initialized
DEBUG - 2022-07-06 07:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 07:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 07:59:29 --> Controller Class Initialized
INFO - 2022-07-06 07:59:29 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 07:59:29 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 07:59:29 --> Final output sent to browser
DEBUG - 2022-07-06 07:59:29 --> Total execution time: 0.0399
INFO - 2022-07-06 08:22:03 --> Config Class Initialized
INFO - 2022-07-06 08:22:03 --> Hooks Class Initialized
DEBUG - 2022-07-06 08:22:03 --> UTF-8 Support Enabled
INFO - 2022-07-06 08:22:03 --> Utf8 Class Initialized
INFO - 2022-07-06 08:22:03 --> URI Class Initialized
INFO - 2022-07-06 08:22:03 --> Router Class Initialized
INFO - 2022-07-06 08:22:03 --> Output Class Initialized
INFO - 2022-07-06 08:22:03 --> Security Class Initialized
DEBUG - 2022-07-06 08:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 08:22:03 --> Input Class Initialized
INFO - 2022-07-06 08:22:03 --> Language Class Initialized
INFO - 2022-07-06 08:22:03 --> Loader Class Initialized
INFO - 2022-07-06 08:22:03 --> Helper loaded: url_helper
INFO - 2022-07-06 08:22:03 --> Helper loaded: file_helper
INFO - 2022-07-06 08:22:03 --> Database Driver Class Initialized
INFO - 2022-07-06 08:22:03 --> Email Class Initialized
DEBUG - 2022-07-06 08:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 08:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 08:22:03 --> Controller Class Initialized
INFO - 2022-07-06 08:22:03 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 08:22:03 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 08:22:03 --> Final output sent to browser
DEBUG - 2022-07-06 08:22:03 --> Total execution time: 0.0397
INFO - 2022-07-06 08:22:03 --> Config Class Initialized
INFO - 2022-07-06 08:22:03 --> Hooks Class Initialized
DEBUG - 2022-07-06 08:22:03 --> UTF-8 Support Enabled
INFO - 2022-07-06 08:22:03 --> Utf8 Class Initialized
INFO - 2022-07-06 08:22:03 --> URI Class Initialized
INFO - 2022-07-06 08:22:03 --> Router Class Initialized
INFO - 2022-07-06 08:22:03 --> Output Class Initialized
INFO - 2022-07-06 08:22:03 --> Security Class Initialized
DEBUG - 2022-07-06 08:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 08:22:03 --> Input Class Initialized
INFO - 2022-07-06 08:22:03 --> Language Class Initialized
INFO - 2022-07-06 08:22:03 --> Loader Class Initialized
INFO - 2022-07-06 08:22:03 --> Helper loaded: url_helper
INFO - 2022-07-06 08:22:03 --> Helper loaded: file_helper
INFO - 2022-07-06 08:22:03 --> Database Driver Class Initialized
INFO - 2022-07-06 08:22:03 --> Email Class Initialized
DEBUG - 2022-07-06 08:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 08:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 08:22:03 --> Controller Class Initialized
INFO - 2022-07-06 08:22:03 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 08:22:03 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 08:22:03 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-06 08:22:03 --> Final output sent to browser
DEBUG - 2022-07-06 08:22:03 --> Total execution time: 0.1087
INFO - 2022-07-06 08:22:12 --> Config Class Initialized
INFO - 2022-07-06 08:22:12 --> Hooks Class Initialized
DEBUG - 2022-07-06 08:22:12 --> UTF-8 Support Enabled
INFO - 2022-07-06 08:22:12 --> Utf8 Class Initialized
INFO - 2022-07-06 08:22:12 --> URI Class Initialized
INFO - 2022-07-06 08:22:12 --> Router Class Initialized
INFO - 2022-07-06 08:22:12 --> Output Class Initialized
INFO - 2022-07-06 08:22:12 --> Security Class Initialized
DEBUG - 2022-07-06 08:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 08:22:12 --> Input Class Initialized
INFO - 2022-07-06 08:22:12 --> Language Class Initialized
INFO - 2022-07-06 08:22:12 --> Loader Class Initialized
INFO - 2022-07-06 08:22:12 --> Helper loaded: url_helper
INFO - 2022-07-06 08:22:12 --> Helper loaded: file_helper
INFO - 2022-07-06 08:22:12 --> Database Driver Class Initialized
INFO - 2022-07-06 08:22:12 --> Email Class Initialized
DEBUG - 2022-07-06 08:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 08:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 08:22:12 --> Controller Class Initialized
INFO - 2022-07-06 08:22:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 08:22:12 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 08:22:12 --> Final output sent to browser
DEBUG - 2022-07-06 08:22:12 --> Total execution time: 0.1309
INFO - 2022-07-06 08:22:15 --> Config Class Initialized
INFO - 2022-07-06 08:22:15 --> Hooks Class Initialized
DEBUG - 2022-07-06 08:22:15 --> UTF-8 Support Enabled
INFO - 2022-07-06 08:22:15 --> Utf8 Class Initialized
INFO - 2022-07-06 08:22:15 --> URI Class Initialized
INFO - 2022-07-06 08:22:15 --> Router Class Initialized
INFO - 2022-07-06 08:22:15 --> Output Class Initialized
INFO - 2022-07-06 08:22:15 --> Security Class Initialized
DEBUG - 2022-07-06 08:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 08:22:15 --> Input Class Initialized
INFO - 2022-07-06 08:22:15 --> Language Class Initialized
INFO - 2022-07-06 08:22:15 --> Loader Class Initialized
INFO - 2022-07-06 08:22:15 --> Helper loaded: url_helper
INFO - 2022-07-06 08:22:15 --> Helper loaded: file_helper
INFO - 2022-07-06 08:22:15 --> Database Driver Class Initialized
INFO - 2022-07-06 08:22:15 --> Email Class Initialized
DEBUG - 2022-07-06 08:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 08:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 08:22:15 --> Controller Class Initialized
INFO - 2022-07-06 08:22:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 08:22:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-06 08:22:16 --> Severity: Notice --> Undefined variable: total C:\wamp64\www\qr\application\views\doc_screen\doctor.php 359
INFO - 2022-07-06 08:22:16 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-07-06 08:22:16 --> Final output sent to browser
DEBUG - 2022-07-06 08:22:16 --> Total execution time: 0.8150
INFO - 2022-07-06 08:22:18 --> Config Class Initialized
INFO - 2022-07-06 08:22:18 --> Hooks Class Initialized
DEBUG - 2022-07-06 08:22:18 --> UTF-8 Support Enabled
INFO - 2022-07-06 08:22:18 --> Utf8 Class Initialized
INFO - 2022-07-06 08:22:18 --> URI Class Initialized
INFO - 2022-07-06 08:22:18 --> Router Class Initialized
INFO - 2022-07-06 08:22:18 --> Output Class Initialized
INFO - 2022-07-06 08:22:18 --> Security Class Initialized
DEBUG - 2022-07-06 08:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 08:22:18 --> Input Class Initialized
INFO - 2022-07-06 08:22:18 --> Language Class Initialized
INFO - 2022-07-06 08:22:18 --> Loader Class Initialized
INFO - 2022-07-06 08:22:18 --> Helper loaded: url_helper
INFO - 2022-07-06 08:22:18 --> Helper loaded: file_helper
INFO - 2022-07-06 08:22:18 --> Database Driver Class Initialized
INFO - 2022-07-06 08:22:18 --> Email Class Initialized
DEBUG - 2022-07-06 08:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 08:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 08:22:18 --> Controller Class Initialized
INFO - 2022-07-06 08:22:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 08:22:18 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 08:22:19 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-07-06 08:22:19 --> Final output sent to browser
DEBUG - 2022-07-06 08:22:19 --> Total execution time: 0.1129
INFO - 2022-07-06 08:22:19 --> Config Class Initialized
INFO - 2022-07-06 08:22:19 --> Hooks Class Initialized
DEBUG - 2022-07-06 08:22:19 --> UTF-8 Support Enabled
INFO - 2022-07-06 08:22:19 --> Utf8 Class Initialized
INFO - 2022-07-06 08:22:19 --> URI Class Initialized
INFO - 2022-07-06 08:22:19 --> Router Class Initialized
INFO - 2022-07-06 08:22:19 --> Output Class Initialized
INFO - 2022-07-06 08:22:19 --> Security Class Initialized
DEBUG - 2022-07-06 08:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 08:22:19 --> Input Class Initialized
INFO - 2022-07-06 08:22:19 --> Language Class Initialized
INFO - 2022-07-06 08:22:19 --> Loader Class Initialized
INFO - 2022-07-06 08:22:19 --> Helper loaded: url_helper
INFO - 2022-07-06 08:22:19 --> Helper loaded: file_helper
INFO - 2022-07-06 08:22:19 --> Database Driver Class Initialized
INFO - 2022-07-06 08:22:19 --> Email Class Initialized
DEBUG - 2022-07-06 08:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 08:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 08:22:19 --> Controller Class Initialized
INFO - 2022-07-06 08:22:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 08:22:19 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 08:22:19 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-07-06 08:22:19 --> Final output sent to browser
DEBUG - 2022-07-06 08:22:19 --> Total execution time: 0.0171
INFO - 2022-07-06 10:43:32 --> Config Class Initialized
INFO - 2022-07-06 10:43:32 --> Hooks Class Initialized
DEBUG - 2022-07-06 10:43:32 --> UTF-8 Support Enabled
INFO - 2022-07-06 10:43:32 --> Utf8 Class Initialized
INFO - 2022-07-06 10:43:32 --> URI Class Initialized
INFO - 2022-07-06 10:43:32 --> Router Class Initialized
INFO - 2022-07-06 10:43:32 --> Output Class Initialized
INFO - 2022-07-06 10:43:32 --> Security Class Initialized
DEBUG - 2022-07-06 10:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 10:43:32 --> Input Class Initialized
INFO - 2022-07-06 10:43:32 --> Language Class Initialized
INFO - 2022-07-06 10:43:33 --> Loader Class Initialized
INFO - 2022-07-06 10:43:33 --> Helper loaded: url_helper
INFO - 2022-07-06 10:43:33 --> Helper loaded: file_helper
INFO - 2022-07-06 10:43:33 --> Database Driver Class Initialized
INFO - 2022-07-06 10:43:33 --> Email Class Initialized
DEBUG - 2022-07-06 10:43:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 10:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 10:43:33 --> Controller Class Initialized
INFO - 2022-07-06 10:43:33 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 10:43:33 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 10:43:33 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 10:43:33 --> Final output sent to browser
DEBUG - 2022-07-06 10:43:33 --> Total execution time: 0.8840
INFO - 2022-07-06 10:45:30 --> Config Class Initialized
INFO - 2022-07-06 10:45:30 --> Hooks Class Initialized
DEBUG - 2022-07-06 10:45:30 --> UTF-8 Support Enabled
INFO - 2022-07-06 10:45:30 --> Utf8 Class Initialized
INFO - 2022-07-06 10:45:30 --> URI Class Initialized
INFO - 2022-07-06 10:45:30 --> Router Class Initialized
INFO - 2022-07-06 10:45:30 --> Output Class Initialized
INFO - 2022-07-06 10:45:30 --> Security Class Initialized
DEBUG - 2022-07-06 10:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 10:45:30 --> Input Class Initialized
INFO - 2022-07-06 10:45:30 --> Language Class Initialized
INFO - 2022-07-06 10:45:30 --> Loader Class Initialized
INFO - 2022-07-06 10:45:30 --> Helper loaded: url_helper
INFO - 2022-07-06 10:45:30 --> Helper loaded: file_helper
INFO - 2022-07-06 10:45:30 --> Database Driver Class Initialized
INFO - 2022-07-06 10:45:30 --> Email Class Initialized
DEBUG - 2022-07-06 10:45:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 10:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 10:45:30 --> Controller Class Initialized
INFO - 2022-07-06 10:45:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 10:45:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 10:45:30 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 10:45:30 --> Final output sent to browser
DEBUG - 2022-07-06 10:45:30 --> Total execution time: 0.2384
INFO - 2022-07-06 10:46:21 --> Config Class Initialized
INFO - 2022-07-06 10:46:21 --> Hooks Class Initialized
DEBUG - 2022-07-06 10:46:21 --> UTF-8 Support Enabled
INFO - 2022-07-06 10:46:21 --> Utf8 Class Initialized
INFO - 2022-07-06 10:46:21 --> URI Class Initialized
INFO - 2022-07-06 10:46:21 --> Router Class Initialized
INFO - 2022-07-06 10:46:21 --> Output Class Initialized
INFO - 2022-07-06 10:46:21 --> Security Class Initialized
DEBUG - 2022-07-06 10:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 10:46:21 --> Input Class Initialized
INFO - 2022-07-06 10:46:21 --> Language Class Initialized
INFO - 2022-07-06 10:46:21 --> Loader Class Initialized
INFO - 2022-07-06 10:46:21 --> Helper loaded: url_helper
INFO - 2022-07-06 10:46:21 --> Helper loaded: file_helper
INFO - 2022-07-06 10:46:21 --> Database Driver Class Initialized
INFO - 2022-07-06 10:46:21 --> Email Class Initialized
DEBUG - 2022-07-06 10:46:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 10:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 10:46:21 --> Controller Class Initialized
INFO - 2022-07-06 10:46:21 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 10:46:21 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 10:46:21 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 10:46:21 --> Final output sent to browser
DEBUG - 2022-07-06 10:46:21 --> Total execution time: 0.0821
INFO - 2022-07-06 10:47:31 --> Config Class Initialized
INFO - 2022-07-06 10:47:31 --> Hooks Class Initialized
DEBUG - 2022-07-06 10:47:31 --> UTF-8 Support Enabled
INFO - 2022-07-06 10:47:31 --> Utf8 Class Initialized
INFO - 2022-07-06 10:47:31 --> URI Class Initialized
INFO - 2022-07-06 10:47:31 --> Router Class Initialized
INFO - 2022-07-06 10:47:31 --> Output Class Initialized
INFO - 2022-07-06 10:47:31 --> Security Class Initialized
DEBUG - 2022-07-06 10:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 10:47:31 --> Input Class Initialized
INFO - 2022-07-06 10:47:31 --> Language Class Initialized
INFO - 2022-07-06 10:47:31 --> Loader Class Initialized
INFO - 2022-07-06 10:47:31 --> Helper loaded: url_helper
INFO - 2022-07-06 10:47:31 --> Helper loaded: file_helper
INFO - 2022-07-06 10:47:31 --> Database Driver Class Initialized
INFO - 2022-07-06 10:47:31 --> Email Class Initialized
DEBUG - 2022-07-06 10:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 10:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 10:47:31 --> Controller Class Initialized
INFO - 2022-07-06 10:47:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 10:47:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 10:47:31 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 10:47:31 --> Final output sent to browser
DEBUG - 2022-07-06 10:47:32 --> Total execution time: 0.2058
INFO - 2022-07-06 10:48:57 --> Config Class Initialized
INFO - 2022-07-06 10:48:57 --> Hooks Class Initialized
DEBUG - 2022-07-06 10:48:57 --> UTF-8 Support Enabled
INFO - 2022-07-06 10:48:57 --> Utf8 Class Initialized
INFO - 2022-07-06 10:48:57 --> URI Class Initialized
INFO - 2022-07-06 10:48:57 --> Router Class Initialized
INFO - 2022-07-06 10:48:57 --> Output Class Initialized
INFO - 2022-07-06 10:48:57 --> Security Class Initialized
DEBUG - 2022-07-06 10:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 10:48:57 --> Input Class Initialized
INFO - 2022-07-06 10:48:57 --> Language Class Initialized
INFO - 2022-07-06 10:48:57 --> Loader Class Initialized
INFO - 2022-07-06 10:48:57 --> Helper loaded: url_helper
INFO - 2022-07-06 10:48:57 --> Helper loaded: file_helper
INFO - 2022-07-06 10:48:57 --> Database Driver Class Initialized
INFO - 2022-07-06 10:48:57 --> Email Class Initialized
DEBUG - 2022-07-06 10:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 10:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 10:48:57 --> Controller Class Initialized
INFO - 2022-07-06 10:48:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 10:48:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 10:48:57 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 10:48:57 --> Final output sent to browser
DEBUG - 2022-07-06 10:48:57 --> Total execution time: 0.0811
INFO - 2022-07-06 10:48:58 --> Config Class Initialized
INFO - 2022-07-06 10:48:58 --> Hooks Class Initialized
DEBUG - 2022-07-06 10:48:58 --> UTF-8 Support Enabled
INFO - 2022-07-06 10:48:58 --> Utf8 Class Initialized
INFO - 2022-07-06 10:48:58 --> URI Class Initialized
INFO - 2022-07-06 10:48:58 --> Router Class Initialized
INFO - 2022-07-06 10:48:58 --> Output Class Initialized
INFO - 2022-07-06 10:48:58 --> Security Class Initialized
DEBUG - 2022-07-06 10:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 10:48:58 --> Input Class Initialized
INFO - 2022-07-06 10:48:58 --> Language Class Initialized
INFO - 2022-07-06 10:48:58 --> Loader Class Initialized
INFO - 2022-07-06 10:48:58 --> Helper loaded: url_helper
INFO - 2022-07-06 10:48:58 --> Helper loaded: file_helper
INFO - 2022-07-06 10:48:58 --> Database Driver Class Initialized
INFO - 2022-07-06 10:48:58 --> Email Class Initialized
DEBUG - 2022-07-06 10:48:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 10:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 10:48:58 --> Controller Class Initialized
INFO - 2022-07-06 10:48:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 10:48:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 10:48:58 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 10:48:58 --> Final output sent to browser
DEBUG - 2022-07-06 10:48:58 --> Total execution time: 0.0854
INFO - 2022-07-06 10:50:44 --> Config Class Initialized
INFO - 2022-07-06 10:50:44 --> Hooks Class Initialized
DEBUG - 2022-07-06 10:50:44 --> UTF-8 Support Enabled
INFO - 2022-07-06 10:50:44 --> Utf8 Class Initialized
INFO - 2022-07-06 10:50:44 --> URI Class Initialized
INFO - 2022-07-06 10:50:44 --> Router Class Initialized
INFO - 2022-07-06 10:50:44 --> Output Class Initialized
INFO - 2022-07-06 10:50:44 --> Security Class Initialized
DEBUG - 2022-07-06 10:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 10:50:44 --> Input Class Initialized
INFO - 2022-07-06 10:50:44 --> Language Class Initialized
INFO - 2022-07-06 10:50:44 --> Loader Class Initialized
INFO - 2022-07-06 10:50:44 --> Helper loaded: url_helper
INFO - 2022-07-06 10:50:44 --> Helper loaded: file_helper
INFO - 2022-07-06 10:50:44 --> Database Driver Class Initialized
INFO - 2022-07-06 10:50:44 --> Email Class Initialized
DEBUG - 2022-07-06 10:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 10:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 10:50:44 --> Controller Class Initialized
INFO - 2022-07-06 10:50:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 10:50:44 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 10:50:44 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 10:50:44 --> Final output sent to browser
DEBUG - 2022-07-06 10:50:44 --> Total execution time: 0.0743
INFO - 2022-07-06 10:51:06 --> Config Class Initialized
INFO - 2022-07-06 10:51:06 --> Hooks Class Initialized
DEBUG - 2022-07-06 10:51:06 --> UTF-8 Support Enabled
INFO - 2022-07-06 10:51:06 --> Utf8 Class Initialized
INFO - 2022-07-06 10:51:06 --> URI Class Initialized
INFO - 2022-07-06 10:51:06 --> Router Class Initialized
INFO - 2022-07-06 10:51:06 --> Output Class Initialized
INFO - 2022-07-06 10:51:06 --> Security Class Initialized
DEBUG - 2022-07-06 10:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 10:51:06 --> Input Class Initialized
INFO - 2022-07-06 10:51:06 --> Language Class Initialized
INFO - 2022-07-06 10:51:06 --> Loader Class Initialized
INFO - 2022-07-06 10:51:06 --> Helper loaded: url_helper
INFO - 2022-07-06 10:51:06 --> Helper loaded: file_helper
INFO - 2022-07-06 10:51:06 --> Database Driver Class Initialized
INFO - 2022-07-06 10:51:06 --> Email Class Initialized
DEBUG - 2022-07-06 10:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 10:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 10:51:06 --> Controller Class Initialized
INFO - 2022-07-06 10:51:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 10:51:06 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 10:51:06 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 10:51:06 --> Final output sent to browser
DEBUG - 2022-07-06 10:51:06 --> Total execution time: 0.0220
INFO - 2022-07-06 10:51:45 --> Config Class Initialized
INFO - 2022-07-06 10:51:45 --> Hooks Class Initialized
DEBUG - 2022-07-06 10:51:45 --> UTF-8 Support Enabled
INFO - 2022-07-06 10:51:45 --> Utf8 Class Initialized
INFO - 2022-07-06 10:51:45 --> URI Class Initialized
INFO - 2022-07-06 10:51:45 --> Router Class Initialized
INFO - 2022-07-06 10:51:45 --> Output Class Initialized
INFO - 2022-07-06 10:51:45 --> Security Class Initialized
DEBUG - 2022-07-06 10:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 10:51:45 --> Input Class Initialized
INFO - 2022-07-06 10:51:45 --> Language Class Initialized
INFO - 2022-07-06 10:51:45 --> Loader Class Initialized
INFO - 2022-07-06 10:51:45 --> Helper loaded: url_helper
INFO - 2022-07-06 10:51:45 --> Helper loaded: file_helper
INFO - 2022-07-06 10:51:45 --> Database Driver Class Initialized
INFO - 2022-07-06 10:51:45 --> Email Class Initialized
DEBUG - 2022-07-06 10:51:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 10:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 10:51:45 --> Controller Class Initialized
INFO - 2022-07-06 10:51:45 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 10:51:45 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 10:51:45 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 10:51:45 --> Final output sent to browser
DEBUG - 2022-07-06 10:51:45 --> Total execution time: 0.1179
INFO - 2022-07-06 10:51:46 --> Config Class Initialized
INFO - 2022-07-06 10:51:46 --> Hooks Class Initialized
DEBUG - 2022-07-06 10:51:46 --> UTF-8 Support Enabled
INFO - 2022-07-06 10:51:46 --> Utf8 Class Initialized
INFO - 2022-07-06 10:51:46 --> URI Class Initialized
INFO - 2022-07-06 10:51:46 --> Router Class Initialized
INFO - 2022-07-06 10:51:46 --> Output Class Initialized
INFO - 2022-07-06 10:51:46 --> Security Class Initialized
DEBUG - 2022-07-06 10:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 10:51:46 --> Input Class Initialized
INFO - 2022-07-06 10:51:46 --> Language Class Initialized
INFO - 2022-07-06 10:51:46 --> Loader Class Initialized
INFO - 2022-07-06 10:51:46 --> Helper loaded: url_helper
INFO - 2022-07-06 10:51:46 --> Helper loaded: file_helper
INFO - 2022-07-06 10:51:46 --> Database Driver Class Initialized
INFO - 2022-07-06 10:51:46 --> Email Class Initialized
DEBUG - 2022-07-06 10:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 10:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 10:51:46 --> Controller Class Initialized
INFO - 2022-07-06 10:51:46 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 10:51:46 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 10:51:46 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 10:51:46 --> Final output sent to browser
DEBUG - 2022-07-06 10:51:46 --> Total execution time: 0.0363
INFO - 2022-07-06 10:51:57 --> Config Class Initialized
INFO - 2022-07-06 10:51:57 --> Hooks Class Initialized
DEBUG - 2022-07-06 10:51:57 --> UTF-8 Support Enabled
INFO - 2022-07-06 10:51:57 --> Utf8 Class Initialized
INFO - 2022-07-06 10:51:57 --> URI Class Initialized
INFO - 2022-07-06 10:51:57 --> Router Class Initialized
INFO - 2022-07-06 10:51:57 --> Output Class Initialized
INFO - 2022-07-06 10:51:57 --> Security Class Initialized
DEBUG - 2022-07-06 10:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 10:51:57 --> Input Class Initialized
INFO - 2022-07-06 10:51:57 --> Language Class Initialized
INFO - 2022-07-06 10:51:57 --> Loader Class Initialized
INFO - 2022-07-06 10:51:57 --> Helper loaded: url_helper
INFO - 2022-07-06 10:51:57 --> Helper loaded: file_helper
INFO - 2022-07-06 10:51:57 --> Database Driver Class Initialized
INFO - 2022-07-06 10:51:57 --> Email Class Initialized
DEBUG - 2022-07-06 10:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 10:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 10:51:57 --> Controller Class Initialized
INFO - 2022-07-06 10:51:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 10:51:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 10:51:57 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 10:51:57 --> Final output sent to browser
DEBUG - 2022-07-06 10:51:57 --> Total execution time: 0.1380
INFO - 2022-07-06 10:53:42 --> Config Class Initialized
INFO - 2022-07-06 10:53:42 --> Hooks Class Initialized
DEBUG - 2022-07-06 10:53:42 --> UTF-8 Support Enabled
INFO - 2022-07-06 10:53:42 --> Utf8 Class Initialized
INFO - 2022-07-06 10:53:42 --> URI Class Initialized
INFO - 2022-07-06 10:53:42 --> Router Class Initialized
INFO - 2022-07-06 10:53:42 --> Output Class Initialized
INFO - 2022-07-06 10:53:42 --> Security Class Initialized
DEBUG - 2022-07-06 10:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 10:53:42 --> Input Class Initialized
INFO - 2022-07-06 10:53:42 --> Language Class Initialized
INFO - 2022-07-06 10:53:42 --> Loader Class Initialized
INFO - 2022-07-06 10:53:42 --> Helper loaded: url_helper
INFO - 2022-07-06 10:53:42 --> Helper loaded: file_helper
INFO - 2022-07-06 10:53:42 --> Database Driver Class Initialized
INFO - 2022-07-06 10:53:42 --> Email Class Initialized
DEBUG - 2022-07-06 10:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 10:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 10:53:42 --> Controller Class Initialized
INFO - 2022-07-06 10:53:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 10:53:42 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 10:53:42 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 10:53:42 --> Final output sent to browser
DEBUG - 2022-07-06 10:53:42 --> Total execution time: 0.0504
INFO - 2022-07-06 10:54:01 --> Config Class Initialized
INFO - 2022-07-06 10:54:01 --> Hooks Class Initialized
DEBUG - 2022-07-06 10:54:01 --> UTF-8 Support Enabled
INFO - 2022-07-06 10:54:01 --> Utf8 Class Initialized
INFO - 2022-07-06 10:54:01 --> URI Class Initialized
INFO - 2022-07-06 10:54:01 --> Router Class Initialized
INFO - 2022-07-06 10:54:01 --> Output Class Initialized
INFO - 2022-07-06 10:54:01 --> Security Class Initialized
DEBUG - 2022-07-06 10:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 10:54:01 --> Input Class Initialized
INFO - 2022-07-06 10:54:01 --> Language Class Initialized
INFO - 2022-07-06 10:54:01 --> Loader Class Initialized
INFO - 2022-07-06 10:54:01 --> Helper loaded: url_helper
INFO - 2022-07-06 10:54:01 --> Helper loaded: file_helper
INFO - 2022-07-06 10:54:01 --> Database Driver Class Initialized
INFO - 2022-07-06 10:54:01 --> Email Class Initialized
DEBUG - 2022-07-06 10:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 10:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 10:54:01 --> Controller Class Initialized
INFO - 2022-07-06 10:54:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 10:54:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 10:54:01 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 10:54:01 --> Final output sent to browser
DEBUG - 2022-07-06 10:54:01 --> Total execution time: 0.1845
INFO - 2022-07-06 10:55:01 --> Config Class Initialized
INFO - 2022-07-06 10:55:01 --> Hooks Class Initialized
DEBUG - 2022-07-06 10:55:01 --> UTF-8 Support Enabled
INFO - 2022-07-06 10:55:01 --> Utf8 Class Initialized
INFO - 2022-07-06 10:55:01 --> URI Class Initialized
INFO - 2022-07-06 10:55:01 --> Router Class Initialized
INFO - 2022-07-06 10:55:01 --> Output Class Initialized
INFO - 2022-07-06 10:55:01 --> Security Class Initialized
DEBUG - 2022-07-06 10:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 10:55:01 --> Input Class Initialized
INFO - 2022-07-06 10:55:01 --> Language Class Initialized
INFO - 2022-07-06 10:55:01 --> Loader Class Initialized
INFO - 2022-07-06 10:55:01 --> Helper loaded: url_helper
INFO - 2022-07-06 10:55:01 --> Helper loaded: file_helper
INFO - 2022-07-06 10:55:01 --> Database Driver Class Initialized
INFO - 2022-07-06 10:55:01 --> Email Class Initialized
DEBUG - 2022-07-06 10:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 10:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 10:55:01 --> Controller Class Initialized
INFO - 2022-07-06 10:55:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 10:55:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 10:55:01 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 10:55:01 --> Final output sent to browser
DEBUG - 2022-07-06 10:55:01 --> Total execution time: 0.1004
INFO - 2022-07-06 10:55:29 --> Config Class Initialized
INFO - 2022-07-06 10:55:29 --> Hooks Class Initialized
DEBUG - 2022-07-06 10:55:29 --> UTF-8 Support Enabled
INFO - 2022-07-06 10:55:29 --> Utf8 Class Initialized
INFO - 2022-07-06 10:55:29 --> URI Class Initialized
INFO - 2022-07-06 10:55:29 --> Router Class Initialized
INFO - 2022-07-06 10:55:29 --> Output Class Initialized
INFO - 2022-07-06 10:55:29 --> Security Class Initialized
DEBUG - 2022-07-06 10:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 10:55:29 --> Input Class Initialized
INFO - 2022-07-06 10:55:29 --> Language Class Initialized
INFO - 2022-07-06 10:55:29 --> Loader Class Initialized
INFO - 2022-07-06 10:55:29 --> Helper loaded: url_helper
INFO - 2022-07-06 10:55:29 --> Helper loaded: file_helper
INFO - 2022-07-06 10:55:29 --> Database Driver Class Initialized
INFO - 2022-07-06 10:55:29 --> Email Class Initialized
DEBUG - 2022-07-06 10:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 10:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 10:55:29 --> Controller Class Initialized
INFO - 2022-07-06 10:55:29 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 10:55:29 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 10:55:29 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 10:55:29 --> Final output sent to browser
DEBUG - 2022-07-06 10:55:29 --> Total execution time: 0.1239
INFO - 2022-07-06 10:56:09 --> Config Class Initialized
INFO - 2022-07-06 10:56:09 --> Hooks Class Initialized
DEBUG - 2022-07-06 10:56:09 --> UTF-8 Support Enabled
INFO - 2022-07-06 10:56:09 --> Utf8 Class Initialized
INFO - 2022-07-06 10:56:09 --> URI Class Initialized
INFO - 2022-07-06 10:56:09 --> Router Class Initialized
INFO - 2022-07-06 10:56:09 --> Output Class Initialized
INFO - 2022-07-06 10:56:09 --> Security Class Initialized
DEBUG - 2022-07-06 10:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 10:56:09 --> Input Class Initialized
INFO - 2022-07-06 10:56:09 --> Language Class Initialized
INFO - 2022-07-06 10:56:09 --> Loader Class Initialized
INFO - 2022-07-06 10:56:09 --> Helper loaded: url_helper
INFO - 2022-07-06 10:56:09 --> Helper loaded: file_helper
INFO - 2022-07-06 10:56:09 --> Database Driver Class Initialized
INFO - 2022-07-06 10:56:09 --> Email Class Initialized
DEBUG - 2022-07-06 10:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 10:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 10:56:09 --> Controller Class Initialized
INFO - 2022-07-06 10:56:09 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 10:56:09 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 10:56:09 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 10:56:09 --> Final output sent to browser
DEBUG - 2022-07-06 10:56:09 --> Total execution time: 0.0579
INFO - 2022-07-06 10:56:25 --> Config Class Initialized
INFO - 2022-07-06 10:56:25 --> Hooks Class Initialized
DEBUG - 2022-07-06 10:56:25 --> UTF-8 Support Enabled
INFO - 2022-07-06 10:56:25 --> Utf8 Class Initialized
INFO - 2022-07-06 10:56:25 --> URI Class Initialized
INFO - 2022-07-06 10:56:25 --> Router Class Initialized
INFO - 2022-07-06 10:56:25 --> Output Class Initialized
INFO - 2022-07-06 10:56:25 --> Security Class Initialized
DEBUG - 2022-07-06 10:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 10:56:25 --> Input Class Initialized
INFO - 2022-07-06 10:56:25 --> Language Class Initialized
INFO - 2022-07-06 10:56:25 --> Loader Class Initialized
INFO - 2022-07-06 10:56:25 --> Helper loaded: url_helper
INFO - 2022-07-06 10:56:25 --> Helper loaded: file_helper
INFO - 2022-07-06 10:56:25 --> Database Driver Class Initialized
INFO - 2022-07-06 10:56:25 --> Email Class Initialized
DEBUG - 2022-07-06 10:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 10:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 10:56:25 --> Controller Class Initialized
INFO - 2022-07-06 10:56:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 10:56:25 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 10:56:25 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 10:56:25 --> Final output sent to browser
DEBUG - 2022-07-06 10:56:25 --> Total execution time: 0.1185
INFO - 2022-07-06 10:57:19 --> Config Class Initialized
INFO - 2022-07-06 10:57:19 --> Hooks Class Initialized
DEBUG - 2022-07-06 10:57:19 --> UTF-8 Support Enabled
INFO - 2022-07-06 10:57:19 --> Utf8 Class Initialized
INFO - 2022-07-06 10:57:19 --> URI Class Initialized
INFO - 2022-07-06 10:57:19 --> Router Class Initialized
INFO - 2022-07-06 10:57:19 --> Output Class Initialized
INFO - 2022-07-06 10:57:19 --> Security Class Initialized
DEBUG - 2022-07-06 10:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 10:57:19 --> Input Class Initialized
INFO - 2022-07-06 10:57:19 --> Language Class Initialized
INFO - 2022-07-06 10:57:19 --> Loader Class Initialized
INFO - 2022-07-06 10:57:19 --> Helper loaded: url_helper
INFO - 2022-07-06 10:57:19 --> Helper loaded: file_helper
INFO - 2022-07-06 10:57:19 --> Database Driver Class Initialized
INFO - 2022-07-06 10:57:19 --> Email Class Initialized
DEBUG - 2022-07-06 10:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 10:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 10:57:19 --> Controller Class Initialized
INFO - 2022-07-06 10:57:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 10:57:19 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 10:57:19 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 10:57:19 --> Final output sent to browser
DEBUG - 2022-07-06 10:57:19 --> Total execution time: 0.1361
INFO - 2022-07-06 10:57:20 --> Config Class Initialized
INFO - 2022-07-06 10:57:20 --> Hooks Class Initialized
DEBUG - 2022-07-06 10:57:20 --> UTF-8 Support Enabled
INFO - 2022-07-06 10:57:20 --> Utf8 Class Initialized
INFO - 2022-07-06 10:57:20 --> URI Class Initialized
INFO - 2022-07-06 10:57:20 --> Router Class Initialized
INFO - 2022-07-06 10:57:20 --> Output Class Initialized
INFO - 2022-07-06 10:57:20 --> Security Class Initialized
DEBUG - 2022-07-06 10:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 10:57:20 --> Input Class Initialized
INFO - 2022-07-06 10:57:20 --> Language Class Initialized
INFO - 2022-07-06 10:57:20 --> Loader Class Initialized
INFO - 2022-07-06 10:57:20 --> Helper loaded: url_helper
INFO - 2022-07-06 10:57:20 --> Helper loaded: file_helper
INFO - 2022-07-06 10:57:21 --> Database Driver Class Initialized
INFO - 2022-07-06 10:57:21 --> Email Class Initialized
DEBUG - 2022-07-06 10:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 10:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 10:57:21 --> Controller Class Initialized
INFO - 2022-07-06 10:57:21 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 10:57:21 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 10:57:21 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 10:57:21 --> Final output sent to browser
DEBUG - 2022-07-06 10:57:21 --> Total execution time: 0.0373
INFO - 2022-07-06 10:58:02 --> Config Class Initialized
INFO - 2022-07-06 10:58:02 --> Hooks Class Initialized
DEBUG - 2022-07-06 10:58:02 --> UTF-8 Support Enabled
INFO - 2022-07-06 10:58:02 --> Utf8 Class Initialized
INFO - 2022-07-06 10:58:02 --> URI Class Initialized
INFO - 2022-07-06 10:58:02 --> Router Class Initialized
INFO - 2022-07-06 10:58:02 --> Output Class Initialized
INFO - 2022-07-06 10:58:02 --> Security Class Initialized
DEBUG - 2022-07-06 10:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 10:58:02 --> Input Class Initialized
INFO - 2022-07-06 10:58:02 --> Language Class Initialized
INFO - 2022-07-06 10:58:02 --> Loader Class Initialized
INFO - 2022-07-06 10:58:02 --> Helper loaded: url_helper
INFO - 2022-07-06 10:58:02 --> Helper loaded: file_helper
INFO - 2022-07-06 10:58:02 --> Database Driver Class Initialized
INFO - 2022-07-06 10:58:02 --> Email Class Initialized
DEBUG - 2022-07-06 10:58:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 10:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 10:58:02 --> Controller Class Initialized
INFO - 2022-07-06 10:58:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 10:58:02 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 10:58:02 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 10:58:02 --> Final output sent to browser
DEBUG - 2022-07-06 10:58:02 --> Total execution time: 0.1436
INFO - 2022-07-06 10:59:34 --> Config Class Initialized
INFO - 2022-07-06 10:59:34 --> Hooks Class Initialized
DEBUG - 2022-07-06 10:59:34 --> UTF-8 Support Enabled
INFO - 2022-07-06 10:59:34 --> Utf8 Class Initialized
INFO - 2022-07-06 10:59:34 --> URI Class Initialized
INFO - 2022-07-06 10:59:34 --> Router Class Initialized
INFO - 2022-07-06 10:59:34 --> Output Class Initialized
INFO - 2022-07-06 10:59:34 --> Security Class Initialized
DEBUG - 2022-07-06 10:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 10:59:34 --> Input Class Initialized
INFO - 2022-07-06 10:59:34 --> Language Class Initialized
INFO - 2022-07-06 10:59:34 --> Loader Class Initialized
INFO - 2022-07-06 10:59:34 --> Helper loaded: url_helper
INFO - 2022-07-06 10:59:34 --> Helper loaded: file_helper
INFO - 2022-07-06 10:59:34 --> Database Driver Class Initialized
INFO - 2022-07-06 10:59:34 --> Email Class Initialized
DEBUG - 2022-07-06 10:59:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 10:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 10:59:34 --> Controller Class Initialized
INFO - 2022-07-06 10:59:34 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 10:59:34 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 10:59:34 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 10:59:34 --> Final output sent to browser
DEBUG - 2022-07-06 10:59:34 --> Total execution time: 0.0673
INFO - 2022-07-06 11:00:16 --> Config Class Initialized
INFO - 2022-07-06 11:00:16 --> Hooks Class Initialized
DEBUG - 2022-07-06 11:00:16 --> UTF-8 Support Enabled
INFO - 2022-07-06 11:00:16 --> Utf8 Class Initialized
INFO - 2022-07-06 11:00:16 --> URI Class Initialized
INFO - 2022-07-06 11:00:16 --> Router Class Initialized
INFO - 2022-07-06 11:00:16 --> Output Class Initialized
INFO - 2022-07-06 11:00:16 --> Security Class Initialized
DEBUG - 2022-07-06 11:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 11:00:16 --> Input Class Initialized
INFO - 2022-07-06 11:00:16 --> Language Class Initialized
INFO - 2022-07-06 11:00:16 --> Loader Class Initialized
INFO - 2022-07-06 11:00:16 --> Helper loaded: url_helper
INFO - 2022-07-06 11:00:16 --> Helper loaded: file_helper
INFO - 2022-07-06 11:00:16 --> Database Driver Class Initialized
INFO - 2022-07-06 11:00:16 --> Email Class Initialized
DEBUG - 2022-07-06 11:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 11:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 11:00:16 --> Controller Class Initialized
INFO - 2022-07-06 11:00:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 11:00:16 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 11:00:16 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 11:00:16 --> Final output sent to browser
DEBUG - 2022-07-06 11:00:16 --> Total execution time: 0.1622
INFO - 2022-07-06 11:03:31 --> Config Class Initialized
INFO - 2022-07-06 11:03:31 --> Hooks Class Initialized
DEBUG - 2022-07-06 11:03:31 --> UTF-8 Support Enabled
INFO - 2022-07-06 11:03:31 --> Utf8 Class Initialized
INFO - 2022-07-06 11:03:31 --> URI Class Initialized
INFO - 2022-07-06 11:03:31 --> Router Class Initialized
INFO - 2022-07-06 11:03:31 --> Output Class Initialized
INFO - 2022-07-06 11:03:31 --> Security Class Initialized
DEBUG - 2022-07-06 11:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 11:03:31 --> Input Class Initialized
INFO - 2022-07-06 11:03:31 --> Language Class Initialized
INFO - 2022-07-06 11:03:31 --> Loader Class Initialized
INFO - 2022-07-06 11:03:31 --> Helper loaded: url_helper
INFO - 2022-07-06 11:03:31 --> Helper loaded: file_helper
INFO - 2022-07-06 11:03:31 --> Database Driver Class Initialized
INFO - 2022-07-06 11:03:31 --> Email Class Initialized
DEBUG - 2022-07-06 11:03:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 11:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 11:03:31 --> Controller Class Initialized
INFO - 2022-07-06 11:03:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 11:03:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 11:03:31 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 11:03:31 --> Final output sent to browser
DEBUG - 2022-07-06 11:03:31 --> Total execution time: 0.1826
INFO - 2022-07-06 11:03:33 --> Config Class Initialized
INFO - 2022-07-06 11:03:33 --> Hooks Class Initialized
DEBUG - 2022-07-06 11:03:33 --> UTF-8 Support Enabled
INFO - 2022-07-06 11:03:33 --> Utf8 Class Initialized
INFO - 2022-07-06 11:03:33 --> URI Class Initialized
INFO - 2022-07-06 11:03:33 --> Router Class Initialized
INFO - 2022-07-06 11:03:33 --> Output Class Initialized
INFO - 2022-07-06 11:03:33 --> Security Class Initialized
DEBUG - 2022-07-06 11:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 11:03:33 --> Input Class Initialized
INFO - 2022-07-06 11:03:33 --> Language Class Initialized
INFO - 2022-07-06 11:03:33 --> Loader Class Initialized
INFO - 2022-07-06 11:03:33 --> Helper loaded: url_helper
INFO - 2022-07-06 11:03:33 --> Helper loaded: file_helper
INFO - 2022-07-06 11:03:33 --> Database Driver Class Initialized
INFO - 2022-07-06 11:03:33 --> Email Class Initialized
DEBUG - 2022-07-06 11:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 11:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 11:03:33 --> Controller Class Initialized
INFO - 2022-07-06 11:03:33 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 11:03:33 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 11:03:33 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 11:03:33 --> Final output sent to browser
DEBUG - 2022-07-06 11:03:33 --> Total execution time: 0.1415
INFO - 2022-07-06 11:16:02 --> Config Class Initialized
INFO - 2022-07-06 11:16:02 --> Hooks Class Initialized
DEBUG - 2022-07-06 11:16:02 --> UTF-8 Support Enabled
INFO - 2022-07-06 11:16:02 --> Utf8 Class Initialized
INFO - 2022-07-06 11:16:02 --> URI Class Initialized
INFO - 2022-07-06 11:16:02 --> Router Class Initialized
INFO - 2022-07-06 11:16:02 --> Output Class Initialized
INFO - 2022-07-06 11:16:02 --> Security Class Initialized
DEBUG - 2022-07-06 11:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 11:16:02 --> Input Class Initialized
INFO - 2022-07-06 11:16:02 --> Language Class Initialized
INFO - 2022-07-06 11:16:02 --> Loader Class Initialized
INFO - 2022-07-06 11:16:02 --> Helper loaded: url_helper
INFO - 2022-07-06 11:16:02 --> Helper loaded: file_helper
INFO - 2022-07-06 11:16:02 --> Database Driver Class Initialized
INFO - 2022-07-06 11:16:02 --> Email Class Initialized
DEBUG - 2022-07-06 11:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 11:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 11:16:02 --> Controller Class Initialized
INFO - 2022-07-06 11:16:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 11:16:02 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 11:16:02 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 11:16:02 --> Final output sent to browser
DEBUG - 2022-07-06 11:16:02 --> Total execution time: 0.0512
INFO - 2022-07-06 11:17:31 --> Config Class Initialized
INFO - 2022-07-06 11:17:31 --> Hooks Class Initialized
DEBUG - 2022-07-06 11:17:31 --> UTF-8 Support Enabled
INFO - 2022-07-06 11:17:31 --> Utf8 Class Initialized
INFO - 2022-07-06 11:17:31 --> URI Class Initialized
INFO - 2022-07-06 11:17:31 --> Router Class Initialized
INFO - 2022-07-06 11:17:31 --> Output Class Initialized
INFO - 2022-07-06 11:17:31 --> Security Class Initialized
DEBUG - 2022-07-06 11:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 11:17:31 --> Input Class Initialized
INFO - 2022-07-06 11:17:31 --> Language Class Initialized
INFO - 2022-07-06 11:17:31 --> Loader Class Initialized
INFO - 2022-07-06 11:17:31 --> Helper loaded: url_helper
INFO - 2022-07-06 11:17:31 --> Helper loaded: file_helper
INFO - 2022-07-06 11:17:31 --> Database Driver Class Initialized
INFO - 2022-07-06 11:17:31 --> Email Class Initialized
DEBUG - 2022-07-06 11:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 11:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 11:17:31 --> Controller Class Initialized
INFO - 2022-07-06 11:17:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 11:17:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 11:17:31 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 11:17:31 --> Final output sent to browser
DEBUG - 2022-07-06 11:17:31 --> Total execution time: 0.1757
INFO - 2022-07-06 11:29:20 --> Config Class Initialized
INFO - 2022-07-06 11:29:20 --> Hooks Class Initialized
DEBUG - 2022-07-06 11:29:20 --> UTF-8 Support Enabled
INFO - 2022-07-06 11:29:20 --> Utf8 Class Initialized
INFO - 2022-07-06 11:29:20 --> URI Class Initialized
INFO - 2022-07-06 11:29:20 --> Router Class Initialized
INFO - 2022-07-06 11:29:20 --> Output Class Initialized
INFO - 2022-07-06 11:29:20 --> Security Class Initialized
DEBUG - 2022-07-06 11:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 11:29:20 --> Input Class Initialized
INFO - 2022-07-06 11:29:20 --> Language Class Initialized
INFO - 2022-07-06 11:29:20 --> Loader Class Initialized
INFO - 2022-07-06 11:29:20 --> Helper loaded: url_helper
INFO - 2022-07-06 11:29:20 --> Helper loaded: file_helper
INFO - 2022-07-06 11:29:20 --> Database Driver Class Initialized
INFO - 2022-07-06 11:29:21 --> Email Class Initialized
DEBUG - 2022-07-06 11:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 11:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 11:29:21 --> Controller Class Initialized
INFO - 2022-07-06 11:29:21 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 11:29:21 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 11:29:21 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 11:29:21 --> Final output sent to browser
DEBUG - 2022-07-06 11:29:21 --> Total execution time: 0.1596
INFO - 2022-07-06 11:29:46 --> Config Class Initialized
INFO - 2022-07-06 11:29:46 --> Hooks Class Initialized
DEBUG - 2022-07-06 11:29:46 --> UTF-8 Support Enabled
INFO - 2022-07-06 11:29:46 --> Utf8 Class Initialized
INFO - 2022-07-06 11:29:46 --> URI Class Initialized
INFO - 2022-07-06 11:29:46 --> Router Class Initialized
INFO - 2022-07-06 11:29:46 --> Output Class Initialized
INFO - 2022-07-06 11:29:46 --> Security Class Initialized
DEBUG - 2022-07-06 11:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 11:29:46 --> Input Class Initialized
INFO - 2022-07-06 11:29:46 --> Language Class Initialized
INFO - 2022-07-06 11:29:46 --> Loader Class Initialized
INFO - 2022-07-06 11:29:46 --> Helper loaded: url_helper
INFO - 2022-07-06 11:29:46 --> Helper loaded: file_helper
INFO - 2022-07-06 11:29:46 --> Database Driver Class Initialized
INFO - 2022-07-06 11:29:47 --> Email Class Initialized
DEBUG - 2022-07-06 11:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 11:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 11:29:47 --> Controller Class Initialized
INFO - 2022-07-06 11:29:47 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 11:29:47 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 11:29:47 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 11:29:47 --> Final output sent to browser
DEBUG - 2022-07-06 11:29:47 --> Total execution time: 0.1240
INFO - 2022-07-06 11:30:41 --> Config Class Initialized
INFO - 2022-07-06 11:30:41 --> Hooks Class Initialized
DEBUG - 2022-07-06 11:30:41 --> UTF-8 Support Enabled
INFO - 2022-07-06 11:30:41 --> Utf8 Class Initialized
INFO - 2022-07-06 11:30:41 --> URI Class Initialized
INFO - 2022-07-06 11:30:41 --> Router Class Initialized
INFO - 2022-07-06 11:30:41 --> Output Class Initialized
INFO - 2022-07-06 11:30:41 --> Security Class Initialized
DEBUG - 2022-07-06 11:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 11:30:41 --> Input Class Initialized
INFO - 2022-07-06 11:30:41 --> Language Class Initialized
INFO - 2022-07-06 11:30:41 --> Loader Class Initialized
INFO - 2022-07-06 11:30:41 --> Helper loaded: url_helper
INFO - 2022-07-06 11:30:41 --> Helper loaded: file_helper
INFO - 2022-07-06 11:30:41 --> Database Driver Class Initialized
INFO - 2022-07-06 11:30:41 --> Email Class Initialized
DEBUG - 2022-07-06 11:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 11:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 11:30:41 --> Controller Class Initialized
INFO - 2022-07-06 11:30:41 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 11:30:41 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 11:30:41 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 11:30:41 --> Final output sent to browser
DEBUG - 2022-07-06 11:30:41 --> Total execution time: 0.1267
INFO - 2022-07-06 11:44:27 --> Config Class Initialized
INFO - 2022-07-06 11:44:27 --> Hooks Class Initialized
DEBUG - 2022-07-06 11:44:27 --> UTF-8 Support Enabled
INFO - 2022-07-06 11:44:27 --> Utf8 Class Initialized
INFO - 2022-07-06 11:44:27 --> URI Class Initialized
INFO - 2022-07-06 11:44:27 --> Router Class Initialized
INFO - 2022-07-06 11:44:27 --> Output Class Initialized
INFO - 2022-07-06 11:44:27 --> Security Class Initialized
DEBUG - 2022-07-06 11:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 11:44:27 --> Input Class Initialized
INFO - 2022-07-06 11:44:27 --> Language Class Initialized
INFO - 2022-07-06 11:44:27 --> Loader Class Initialized
INFO - 2022-07-06 11:44:27 --> Helper loaded: url_helper
INFO - 2022-07-06 11:44:27 --> Helper loaded: file_helper
INFO - 2022-07-06 11:44:27 --> Database Driver Class Initialized
INFO - 2022-07-06 11:44:27 --> Email Class Initialized
DEBUG - 2022-07-06 11:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 11:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 11:44:27 --> Controller Class Initialized
INFO - 2022-07-06 11:44:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 11:44:27 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 11:44:27 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 11:44:27 --> Final output sent to browser
DEBUG - 2022-07-06 11:44:27 --> Total execution time: 0.2692
INFO - 2022-07-06 11:44:28 --> Config Class Initialized
INFO - 2022-07-06 11:44:28 --> Hooks Class Initialized
DEBUG - 2022-07-06 11:44:28 --> UTF-8 Support Enabled
INFO - 2022-07-06 11:44:28 --> Utf8 Class Initialized
INFO - 2022-07-06 11:44:28 --> URI Class Initialized
INFO - 2022-07-06 11:44:28 --> Router Class Initialized
INFO - 2022-07-06 11:44:28 --> Output Class Initialized
INFO - 2022-07-06 11:44:28 --> Security Class Initialized
DEBUG - 2022-07-06 11:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 11:44:28 --> Input Class Initialized
INFO - 2022-07-06 11:44:28 --> Language Class Initialized
INFO - 2022-07-06 11:44:28 --> Loader Class Initialized
INFO - 2022-07-06 11:44:28 --> Helper loaded: url_helper
INFO - 2022-07-06 11:44:28 --> Helper loaded: file_helper
INFO - 2022-07-06 11:44:28 --> Database Driver Class Initialized
INFO - 2022-07-06 11:44:28 --> Email Class Initialized
DEBUG - 2022-07-06 11:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 11:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 11:44:28 --> Controller Class Initialized
INFO - 2022-07-06 11:44:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 11:44:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 11:44:28 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 11:44:28 --> Final output sent to browser
DEBUG - 2022-07-06 11:44:28 --> Total execution time: 0.1702
INFO - 2022-07-06 11:44:29 --> Config Class Initialized
INFO - 2022-07-06 11:44:29 --> Hooks Class Initialized
DEBUG - 2022-07-06 11:44:29 --> UTF-8 Support Enabled
INFO - 2022-07-06 11:44:29 --> Utf8 Class Initialized
INFO - 2022-07-06 11:44:29 --> URI Class Initialized
INFO - 2022-07-06 11:44:29 --> Router Class Initialized
INFO - 2022-07-06 11:44:29 --> Output Class Initialized
INFO - 2022-07-06 11:44:29 --> Security Class Initialized
DEBUG - 2022-07-06 11:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 11:44:29 --> Input Class Initialized
INFO - 2022-07-06 11:44:29 --> Language Class Initialized
INFO - 2022-07-06 11:44:29 --> Loader Class Initialized
INFO - 2022-07-06 11:44:29 --> Helper loaded: url_helper
INFO - 2022-07-06 11:44:29 --> Helper loaded: file_helper
INFO - 2022-07-06 11:44:29 --> Database Driver Class Initialized
INFO - 2022-07-06 11:44:29 --> Email Class Initialized
DEBUG - 2022-07-06 11:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 11:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 11:44:29 --> Controller Class Initialized
INFO - 2022-07-06 11:44:29 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 11:44:29 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 11:44:29 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 11:44:29 --> Final output sent to browser
DEBUG - 2022-07-06 11:44:29 --> Total execution time: 0.1568
INFO - 2022-07-06 11:44:30 --> Config Class Initialized
INFO - 2022-07-06 11:44:30 --> Hooks Class Initialized
DEBUG - 2022-07-06 11:44:30 --> UTF-8 Support Enabled
INFO - 2022-07-06 11:44:30 --> Utf8 Class Initialized
INFO - 2022-07-06 11:44:30 --> URI Class Initialized
INFO - 2022-07-06 11:44:30 --> Router Class Initialized
INFO - 2022-07-06 11:44:30 --> Output Class Initialized
INFO - 2022-07-06 11:44:30 --> Security Class Initialized
DEBUG - 2022-07-06 11:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 11:44:30 --> Input Class Initialized
INFO - 2022-07-06 11:44:30 --> Language Class Initialized
INFO - 2022-07-06 11:44:30 --> Loader Class Initialized
INFO - 2022-07-06 11:44:30 --> Helper loaded: url_helper
INFO - 2022-07-06 11:44:30 --> Helper loaded: file_helper
INFO - 2022-07-06 11:44:30 --> Database Driver Class Initialized
INFO - 2022-07-06 11:44:30 --> Email Class Initialized
DEBUG - 2022-07-06 11:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 11:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 11:44:30 --> Controller Class Initialized
INFO - 2022-07-06 11:44:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 11:44:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 11:44:30 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 11:44:30 --> Final output sent to browser
DEBUG - 2022-07-06 11:44:30 --> Total execution time: 0.1549
INFO - 2022-07-06 11:44:31 --> Config Class Initialized
INFO - 2022-07-06 11:44:31 --> Hooks Class Initialized
DEBUG - 2022-07-06 11:44:31 --> UTF-8 Support Enabled
INFO - 2022-07-06 11:44:31 --> Utf8 Class Initialized
INFO - 2022-07-06 11:44:31 --> URI Class Initialized
INFO - 2022-07-06 11:44:31 --> Router Class Initialized
INFO - 2022-07-06 11:44:31 --> Output Class Initialized
INFO - 2022-07-06 11:44:31 --> Security Class Initialized
DEBUG - 2022-07-06 11:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 11:44:31 --> Input Class Initialized
INFO - 2022-07-06 11:44:31 --> Language Class Initialized
INFO - 2022-07-06 11:44:31 --> Loader Class Initialized
INFO - 2022-07-06 11:44:31 --> Helper loaded: url_helper
INFO - 2022-07-06 11:44:31 --> Helper loaded: file_helper
INFO - 2022-07-06 11:44:31 --> Database Driver Class Initialized
INFO - 2022-07-06 11:44:31 --> Email Class Initialized
DEBUG - 2022-07-06 11:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 11:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 11:44:31 --> Controller Class Initialized
INFO - 2022-07-06 11:44:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 11:44:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 11:44:31 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 11:44:31 --> Final output sent to browser
DEBUG - 2022-07-06 11:44:31 --> Total execution time: 0.0303
INFO - 2022-07-06 11:44:31 --> Config Class Initialized
INFO - 2022-07-06 11:44:31 --> Hooks Class Initialized
DEBUG - 2022-07-06 11:44:31 --> UTF-8 Support Enabled
INFO - 2022-07-06 11:44:31 --> Utf8 Class Initialized
INFO - 2022-07-06 11:44:31 --> URI Class Initialized
INFO - 2022-07-06 11:44:31 --> Router Class Initialized
INFO - 2022-07-06 11:44:31 --> Output Class Initialized
INFO - 2022-07-06 11:44:31 --> Security Class Initialized
DEBUG - 2022-07-06 11:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 11:44:31 --> Input Class Initialized
INFO - 2022-07-06 11:44:31 --> Language Class Initialized
INFO - 2022-07-06 11:44:31 --> Loader Class Initialized
INFO - 2022-07-06 11:44:31 --> Helper loaded: url_helper
INFO - 2022-07-06 11:44:31 --> Helper loaded: file_helper
INFO - 2022-07-06 11:44:31 --> Database Driver Class Initialized
INFO - 2022-07-06 11:44:31 --> Email Class Initialized
DEBUG - 2022-07-06 11:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 11:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 11:44:31 --> Controller Class Initialized
INFO - 2022-07-06 11:44:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 11:44:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 11:44:31 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 11:44:31 --> Final output sent to browser
DEBUG - 2022-07-06 11:44:31 --> Total execution time: 0.1616
INFO - 2022-07-06 11:44:31 --> Config Class Initialized
INFO - 2022-07-06 11:44:31 --> Hooks Class Initialized
DEBUG - 2022-07-06 11:44:31 --> UTF-8 Support Enabled
INFO - 2022-07-06 11:44:31 --> Utf8 Class Initialized
INFO - 2022-07-06 11:44:31 --> URI Class Initialized
INFO - 2022-07-06 11:44:31 --> Router Class Initialized
INFO - 2022-07-06 11:44:31 --> Output Class Initialized
INFO - 2022-07-06 11:44:31 --> Security Class Initialized
DEBUG - 2022-07-06 11:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 11:44:31 --> Input Class Initialized
INFO - 2022-07-06 11:44:31 --> Language Class Initialized
INFO - 2022-07-06 11:44:31 --> Loader Class Initialized
INFO - 2022-07-06 11:44:31 --> Helper loaded: url_helper
INFO - 2022-07-06 11:44:31 --> Helper loaded: file_helper
INFO - 2022-07-06 11:44:31 --> Database Driver Class Initialized
INFO - 2022-07-06 11:44:31 --> Email Class Initialized
DEBUG - 2022-07-06 11:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 11:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 11:44:31 --> Controller Class Initialized
INFO - 2022-07-06 11:44:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 11:44:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 11:44:32 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 11:44:32 --> Final output sent to browser
DEBUG - 2022-07-06 11:44:32 --> Total execution time: 0.2655
INFO - 2022-07-06 11:44:32 --> Config Class Initialized
INFO - 2022-07-06 11:44:32 --> Hooks Class Initialized
DEBUG - 2022-07-06 11:44:32 --> UTF-8 Support Enabled
INFO - 2022-07-06 11:44:32 --> Utf8 Class Initialized
INFO - 2022-07-06 11:44:32 --> URI Class Initialized
INFO - 2022-07-06 11:44:32 --> Router Class Initialized
INFO - 2022-07-06 11:44:32 --> Output Class Initialized
INFO - 2022-07-06 11:44:32 --> Security Class Initialized
DEBUG - 2022-07-06 11:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 11:44:32 --> Input Class Initialized
INFO - 2022-07-06 11:44:32 --> Language Class Initialized
INFO - 2022-07-06 11:44:32 --> Loader Class Initialized
INFO - 2022-07-06 11:44:32 --> Helper loaded: url_helper
INFO - 2022-07-06 11:44:32 --> Helper loaded: file_helper
INFO - 2022-07-06 11:44:32 --> Database Driver Class Initialized
INFO - 2022-07-06 11:44:32 --> Email Class Initialized
DEBUG - 2022-07-06 11:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 11:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 11:44:32 --> Controller Class Initialized
INFO - 2022-07-06 11:44:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 11:44:32 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 11:44:32 --> Config Class Initialized
INFO - 2022-07-06 11:44:32 --> Hooks Class Initialized
DEBUG - 2022-07-06 11:44:32 --> UTF-8 Support Enabled
INFO - 2022-07-06 11:44:32 --> Utf8 Class Initialized
INFO - 2022-07-06 11:44:32 --> Config Class Initialized
INFO - 2022-07-06 11:44:32 --> Hooks Class Initialized
INFO - 2022-07-06 11:44:32 --> URI Class Initialized
INFO - 2022-07-06 11:44:32 --> Router Class Initialized
INFO - 2022-07-06 11:44:32 --> Output Class Initialized
INFO - 2022-07-06 11:44:32 --> Security Class Initialized
DEBUG - 2022-07-06 11:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 11:44:32 --> Input Class Initialized
INFO - 2022-07-06 11:44:32 --> Language Class Initialized
INFO - 2022-07-06 11:44:32 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 11:44:32 --> Final output sent to browser
DEBUG - 2022-07-06 11:44:32 --> Total execution time: 0.3038
DEBUG - 2022-07-06 11:44:32 --> UTF-8 Support Enabled
INFO - 2022-07-06 11:44:32 --> Utf8 Class Initialized
INFO - 2022-07-06 11:44:32 --> URI Class Initialized
INFO - 2022-07-06 11:44:32 --> Router Class Initialized
INFO - 2022-07-06 11:44:32 --> Output Class Initialized
INFO - 2022-07-06 11:44:32 --> Security Class Initialized
DEBUG - 2022-07-06 11:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 11:44:32 --> Input Class Initialized
INFO - 2022-07-06 11:44:32 --> Language Class Initialized
INFO - 2022-07-06 11:44:32 --> Loader Class Initialized
INFO - 2022-07-06 11:44:32 --> Helper loaded: url_helper
INFO - 2022-07-06 11:44:32 --> Helper loaded: file_helper
INFO - 2022-07-06 11:44:32 --> Config Class Initialized
INFO - 2022-07-06 11:44:32 --> Hooks Class Initialized
DEBUG - 2022-07-06 11:44:32 --> UTF-8 Support Enabled
INFO - 2022-07-06 11:44:32 --> Utf8 Class Initialized
INFO - 2022-07-06 11:44:32 --> URI Class Initialized
INFO - 2022-07-06 11:44:32 --> Router Class Initialized
INFO - 2022-07-06 11:44:32 --> Output Class Initialized
INFO - 2022-07-06 11:44:32 --> Security Class Initialized
DEBUG - 2022-07-06 11:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 11:44:32 --> Input Class Initialized
INFO - 2022-07-06 11:44:32 --> Language Class Initialized
INFO - 2022-07-06 11:44:32 --> Loader Class Initialized
INFO - 2022-07-06 11:44:32 --> Helper loaded: url_helper
INFO - 2022-07-06 11:44:32 --> Helper loaded: file_helper
INFO - 2022-07-06 11:44:32 --> Database Driver Class Initialized
INFO - 2022-07-06 11:44:32 --> Email Class Initialized
DEBUG - 2022-07-06 11:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 11:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 11:44:32 --> Controller Class Initialized
INFO - 2022-07-06 11:44:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 11:44:32 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 11:44:32 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 11:44:32 --> Final output sent to browser
DEBUG - 2022-07-06 11:44:32 --> Total execution time: 0.0178
INFO - 2022-07-06 11:44:32 --> Database Driver Class Initialized
INFO - 2022-07-06 11:44:32 --> Email Class Initialized
DEBUG - 2022-07-06 11:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 11:44:32 --> Loader Class Initialized
INFO - 2022-07-06 11:44:32 --> Helper loaded: url_helper
INFO - 2022-07-06 11:44:32 --> Helper loaded: file_helper
INFO - 2022-07-06 11:44:32 --> Database Driver Class Initialized
INFO - 2022-07-06 11:44:32 --> Email Class Initialized
DEBUG - 2022-07-06 11:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 11:44:32 --> Config Class Initialized
INFO - 2022-07-06 11:44:32 --> Hooks Class Initialized
DEBUG - 2022-07-06 11:44:32 --> UTF-8 Support Enabled
INFO - 2022-07-06 11:44:32 --> Utf8 Class Initialized
INFO - 2022-07-06 11:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 11:44:32 --> Controller Class Initialized
INFO - 2022-07-06 11:44:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 11:44:32 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 11:44:32 --> Config Class Initialized
INFO - 2022-07-06 11:44:32 --> Hooks Class Initialized
DEBUG - 2022-07-06 11:44:32 --> UTF-8 Support Enabled
INFO - 2022-07-06 11:44:32 --> Utf8 Class Initialized
INFO - 2022-07-06 11:44:32 --> URI Class Initialized
INFO - 2022-07-06 11:44:32 --> Router Class Initialized
INFO - 2022-07-06 11:44:32 --> Output Class Initialized
INFO - 2022-07-06 11:44:32 --> Security Class Initialized
DEBUG - 2022-07-06 11:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 11:44:32 --> Input Class Initialized
INFO - 2022-07-06 11:44:32 --> Language Class Initialized
INFO - 2022-07-06 11:44:32 --> Loader Class Initialized
INFO - 2022-07-06 11:44:32 --> Helper loaded: url_helper
INFO - 2022-07-06 11:44:32 --> Helper loaded: file_helper
INFO - 2022-07-06 11:44:32 --> Database Driver Class Initialized
INFO - 2022-07-06 11:44:32 --> URI Class Initialized
INFO - 2022-07-06 11:44:32 --> Router Class Initialized
INFO - 2022-07-06 11:44:32 --> Output Class Initialized
INFO - 2022-07-06 11:44:32 --> Security Class Initialized
DEBUG - 2022-07-06 11:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 11:44:32 --> Input Class Initialized
INFO - 2022-07-06 11:44:32 --> Language Class Initialized
INFO - 2022-07-06 11:44:32 --> Loader Class Initialized
INFO - 2022-07-06 11:44:32 --> Helper loaded: url_helper
INFO - 2022-07-06 11:44:32 --> Helper loaded: file_helper
INFO - 2022-07-06 11:44:32 --> Database Driver Class Initialized
INFO - 2022-07-06 11:44:32 --> Email Class Initialized
DEBUG - 2022-07-06 11:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 11:44:32 --> Email Class Initialized
DEBUG - 2022-07-06 11:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 11:44:32 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 11:44:32 --> Final output sent to browser
DEBUG - 2022-07-06 11:44:32 --> Total execution time: 0.6627
INFO - 2022-07-06 11:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 11:44:32 --> Controller Class Initialized
INFO - 2022-07-06 11:44:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 11:44:32 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 11:44:32 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 11:44:32 --> Final output sent to browser
DEBUG - 2022-07-06 11:44:32 --> Total execution time: 0.8880
INFO - 2022-07-06 11:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 11:44:32 --> Controller Class Initialized
INFO - 2022-07-06 11:44:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 11:44:32 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 11:44:32 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 11:44:32 --> Final output sent to browser
DEBUG - 2022-07-06 11:44:32 --> Total execution time: 0.2048
INFO - 2022-07-06 11:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 11:44:32 --> Controller Class Initialized
INFO - 2022-07-06 11:44:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 11:44:32 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 11:44:32 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 11:44:32 --> Final output sent to browser
DEBUG - 2022-07-06 11:44:32 --> Total execution time: 0.2496
INFO - 2022-07-06 11:44:33 --> Config Class Initialized
INFO - 2022-07-06 11:44:33 --> Hooks Class Initialized
DEBUG - 2022-07-06 11:44:33 --> UTF-8 Support Enabled
INFO - 2022-07-06 11:44:33 --> Utf8 Class Initialized
INFO - 2022-07-06 11:44:33 --> URI Class Initialized
INFO - 2022-07-06 11:44:33 --> Router Class Initialized
INFO - 2022-07-06 11:44:33 --> Output Class Initialized
INFO - 2022-07-06 11:44:33 --> Security Class Initialized
DEBUG - 2022-07-06 11:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 11:44:33 --> Input Class Initialized
INFO - 2022-07-06 11:44:33 --> Language Class Initialized
INFO - 2022-07-06 11:44:33 --> Loader Class Initialized
INFO - 2022-07-06 11:44:33 --> Helper loaded: url_helper
INFO - 2022-07-06 11:44:33 --> Helper loaded: file_helper
INFO - 2022-07-06 11:44:33 --> Database Driver Class Initialized
INFO - 2022-07-06 11:44:33 --> Email Class Initialized
DEBUG - 2022-07-06 11:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 11:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 11:44:33 --> Controller Class Initialized
INFO - 2022-07-06 11:44:33 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 11:44:33 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 11:44:34 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 11:44:34 --> Final output sent to browser
DEBUG - 2022-07-06 11:44:34 --> Total execution time: 0.7945
INFO - 2022-07-06 11:44:34 --> Config Class Initialized
INFO - 2022-07-06 11:44:34 --> Hooks Class Initialized
DEBUG - 2022-07-06 11:44:34 --> UTF-8 Support Enabled
INFO - 2022-07-06 11:44:34 --> Utf8 Class Initialized
INFO - 2022-07-06 11:44:34 --> URI Class Initialized
INFO - 2022-07-06 11:44:34 --> Router Class Initialized
INFO - 2022-07-06 11:44:34 --> Output Class Initialized
INFO - 2022-07-06 11:44:34 --> Security Class Initialized
DEBUG - 2022-07-06 11:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 11:44:34 --> Input Class Initialized
INFO - 2022-07-06 11:44:34 --> Language Class Initialized
INFO - 2022-07-06 11:44:34 --> Loader Class Initialized
INFO - 2022-07-06 11:44:34 --> Helper loaded: url_helper
INFO - 2022-07-06 11:44:34 --> Helper loaded: file_helper
INFO - 2022-07-06 11:44:34 --> Database Driver Class Initialized
INFO - 2022-07-06 11:44:34 --> Email Class Initialized
DEBUG - 2022-07-06 11:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 11:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 11:44:34 --> Controller Class Initialized
INFO - 2022-07-06 11:44:34 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 11:44:34 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 11:44:34 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 11:44:34 --> Final output sent to browser
DEBUG - 2022-07-06 11:44:34 --> Total execution time: 0.4198
INFO - 2022-07-06 11:44:35 --> Config Class Initialized
INFO - 2022-07-06 11:44:35 --> Hooks Class Initialized
DEBUG - 2022-07-06 11:44:35 --> UTF-8 Support Enabled
INFO - 2022-07-06 11:44:35 --> Utf8 Class Initialized
INFO - 2022-07-06 11:44:35 --> URI Class Initialized
INFO - 2022-07-06 11:44:35 --> Router Class Initialized
INFO - 2022-07-06 11:44:35 --> Output Class Initialized
INFO - 2022-07-06 11:44:35 --> Security Class Initialized
DEBUG - 2022-07-06 11:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 11:44:35 --> Input Class Initialized
INFO - 2022-07-06 11:44:35 --> Language Class Initialized
INFO - 2022-07-06 11:44:35 --> Loader Class Initialized
INFO - 2022-07-06 11:44:35 --> Helper loaded: url_helper
INFO - 2022-07-06 11:44:35 --> Helper loaded: file_helper
INFO - 2022-07-06 11:44:35 --> Database Driver Class Initialized
INFO - 2022-07-06 11:44:35 --> Email Class Initialized
DEBUG - 2022-07-06 11:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 11:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 11:44:35 --> Controller Class Initialized
INFO - 2022-07-06 11:44:35 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 11:44:35 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 11:44:35 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 11:44:35 --> Final output sent to browser
DEBUG - 2022-07-06 11:44:35 --> Total execution time: 0.0733
INFO - 2022-07-06 11:45:43 --> Config Class Initialized
INFO - 2022-07-06 11:45:43 --> Hooks Class Initialized
DEBUG - 2022-07-06 11:45:43 --> UTF-8 Support Enabled
INFO - 2022-07-06 11:45:43 --> Utf8 Class Initialized
INFO - 2022-07-06 11:45:43 --> URI Class Initialized
INFO - 2022-07-06 11:45:43 --> Router Class Initialized
INFO - 2022-07-06 11:45:43 --> Output Class Initialized
INFO - 2022-07-06 11:45:43 --> Security Class Initialized
DEBUG - 2022-07-06 11:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 11:45:43 --> Input Class Initialized
INFO - 2022-07-06 11:45:43 --> Language Class Initialized
INFO - 2022-07-06 11:45:43 --> Loader Class Initialized
INFO - 2022-07-06 11:45:43 --> Helper loaded: url_helper
INFO - 2022-07-06 11:45:43 --> Helper loaded: file_helper
INFO - 2022-07-06 11:45:43 --> Database Driver Class Initialized
INFO - 2022-07-06 11:45:43 --> Email Class Initialized
DEBUG - 2022-07-06 11:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 11:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 11:45:43 --> Controller Class Initialized
INFO - 2022-07-06 11:45:43 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 11:45:43 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 11:45:43 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 11:45:43 --> Final output sent to browser
DEBUG - 2022-07-06 11:45:43 --> Total execution time: 0.0842
INFO - 2022-07-06 11:46:49 --> Config Class Initialized
INFO - 2022-07-06 11:46:49 --> Hooks Class Initialized
DEBUG - 2022-07-06 11:46:49 --> UTF-8 Support Enabled
INFO - 2022-07-06 11:46:49 --> Utf8 Class Initialized
INFO - 2022-07-06 11:46:49 --> URI Class Initialized
INFO - 2022-07-06 11:46:49 --> Router Class Initialized
INFO - 2022-07-06 11:46:49 --> Output Class Initialized
INFO - 2022-07-06 11:46:49 --> Security Class Initialized
DEBUG - 2022-07-06 11:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 11:46:49 --> Input Class Initialized
INFO - 2022-07-06 11:46:49 --> Language Class Initialized
INFO - 2022-07-06 11:46:49 --> Loader Class Initialized
INFO - 2022-07-06 11:46:49 --> Helper loaded: url_helper
INFO - 2022-07-06 11:46:49 --> Helper loaded: file_helper
INFO - 2022-07-06 11:46:49 --> Database Driver Class Initialized
INFO - 2022-07-06 11:46:50 --> Email Class Initialized
DEBUG - 2022-07-06 11:46:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 11:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 11:46:50 --> Controller Class Initialized
INFO - 2022-07-06 11:46:50 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 11:46:50 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 11:46:50 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 11:46:50 --> Final output sent to browser
DEBUG - 2022-07-06 11:46:50 --> Total execution time: 0.1492
INFO - 2022-07-06 11:51:35 --> Config Class Initialized
INFO - 2022-07-06 11:51:35 --> Hooks Class Initialized
DEBUG - 2022-07-06 11:51:36 --> UTF-8 Support Enabled
INFO - 2022-07-06 11:51:36 --> Utf8 Class Initialized
INFO - 2022-07-06 11:51:36 --> URI Class Initialized
INFO - 2022-07-06 11:51:36 --> Router Class Initialized
INFO - 2022-07-06 11:51:36 --> Output Class Initialized
INFO - 2022-07-06 11:51:36 --> Security Class Initialized
DEBUG - 2022-07-06 11:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 11:51:36 --> Input Class Initialized
INFO - 2022-07-06 11:51:36 --> Language Class Initialized
INFO - 2022-07-06 11:51:36 --> Loader Class Initialized
INFO - 2022-07-06 11:51:36 --> Helper loaded: url_helper
INFO - 2022-07-06 11:51:36 --> Helper loaded: file_helper
INFO - 2022-07-06 11:51:36 --> Database Driver Class Initialized
INFO - 2022-07-06 11:51:36 --> Email Class Initialized
DEBUG - 2022-07-06 11:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 11:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 11:51:36 --> Controller Class Initialized
INFO - 2022-07-06 11:51:36 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 11:51:36 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 11:51:36 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 11:51:36 --> Final output sent to browser
DEBUG - 2022-07-06 11:51:36 --> Total execution time: 0.3716
INFO - 2022-07-06 11:56:12 --> Config Class Initialized
INFO - 2022-07-06 11:56:12 --> Hooks Class Initialized
DEBUG - 2022-07-06 11:56:13 --> UTF-8 Support Enabled
INFO - 2022-07-06 11:56:13 --> Utf8 Class Initialized
INFO - 2022-07-06 11:56:13 --> URI Class Initialized
INFO - 2022-07-06 11:56:13 --> Router Class Initialized
INFO - 2022-07-06 11:56:13 --> Output Class Initialized
INFO - 2022-07-06 11:56:13 --> Security Class Initialized
DEBUG - 2022-07-06 11:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 11:56:13 --> Input Class Initialized
INFO - 2022-07-06 11:56:13 --> Language Class Initialized
INFO - 2022-07-06 11:56:13 --> Loader Class Initialized
INFO - 2022-07-06 11:56:13 --> Helper loaded: url_helper
INFO - 2022-07-06 11:56:13 --> Helper loaded: file_helper
INFO - 2022-07-06 11:56:13 --> Database Driver Class Initialized
INFO - 2022-07-06 11:56:13 --> Email Class Initialized
DEBUG - 2022-07-06 11:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 11:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 11:56:13 --> Controller Class Initialized
INFO - 2022-07-06 11:56:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 11:56:13 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 11:56:13 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 11:56:13 --> Final output sent to browser
DEBUG - 2022-07-06 11:56:13 --> Total execution time: 0.0809
INFO - 2022-07-06 12:18:06 --> Config Class Initialized
INFO - 2022-07-06 12:18:06 --> Hooks Class Initialized
DEBUG - 2022-07-06 12:18:06 --> UTF-8 Support Enabled
INFO - 2022-07-06 12:18:06 --> Utf8 Class Initialized
INFO - 2022-07-06 12:18:06 --> URI Class Initialized
INFO - 2022-07-06 12:18:06 --> Router Class Initialized
INFO - 2022-07-06 12:18:06 --> Output Class Initialized
INFO - 2022-07-06 12:18:06 --> Security Class Initialized
DEBUG - 2022-07-06 12:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 12:18:06 --> Input Class Initialized
INFO - 2022-07-06 12:18:06 --> Language Class Initialized
INFO - 2022-07-06 12:18:06 --> Loader Class Initialized
INFO - 2022-07-06 12:18:06 --> Helper loaded: url_helper
INFO - 2022-07-06 12:18:06 --> Helper loaded: file_helper
INFO - 2022-07-06 12:18:06 --> Database Driver Class Initialized
INFO - 2022-07-06 12:18:06 --> Email Class Initialized
DEBUG - 2022-07-06 12:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 12:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 12:18:06 --> Controller Class Initialized
INFO - 2022-07-06 12:18:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 12:18:06 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 12:18:06 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 12:18:06 --> Final output sent to browser
DEBUG - 2022-07-06 12:18:06 --> Total execution time: 0.1581
INFO - 2022-07-06 12:19:39 --> Config Class Initialized
INFO - 2022-07-06 12:19:39 --> Hooks Class Initialized
DEBUG - 2022-07-06 12:19:39 --> UTF-8 Support Enabled
INFO - 2022-07-06 12:19:39 --> Utf8 Class Initialized
INFO - 2022-07-06 12:19:39 --> URI Class Initialized
INFO - 2022-07-06 12:19:39 --> Router Class Initialized
INFO - 2022-07-06 12:19:39 --> Output Class Initialized
INFO - 2022-07-06 12:19:39 --> Security Class Initialized
DEBUG - 2022-07-06 12:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 12:19:39 --> Input Class Initialized
INFO - 2022-07-06 12:19:39 --> Language Class Initialized
INFO - 2022-07-06 12:19:39 --> Loader Class Initialized
INFO - 2022-07-06 12:19:39 --> Helper loaded: url_helper
INFO - 2022-07-06 12:19:39 --> Helper loaded: file_helper
INFO - 2022-07-06 12:19:39 --> Database Driver Class Initialized
INFO - 2022-07-06 12:19:39 --> Email Class Initialized
DEBUG - 2022-07-06 12:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 12:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 12:19:39 --> Controller Class Initialized
INFO - 2022-07-06 12:19:39 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 12:19:39 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 12:19:39 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 12:19:39 --> Final output sent to browser
DEBUG - 2022-07-06 12:19:39 --> Total execution time: 0.2123
INFO - 2022-07-06 12:23:24 --> Config Class Initialized
INFO - 2022-07-06 12:23:24 --> Hooks Class Initialized
DEBUG - 2022-07-06 12:23:24 --> UTF-8 Support Enabled
INFO - 2022-07-06 12:23:24 --> Utf8 Class Initialized
INFO - 2022-07-06 12:23:24 --> URI Class Initialized
INFO - 2022-07-06 12:23:24 --> Router Class Initialized
INFO - 2022-07-06 12:23:24 --> Output Class Initialized
INFO - 2022-07-06 12:23:24 --> Security Class Initialized
DEBUG - 2022-07-06 12:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 12:23:24 --> Input Class Initialized
INFO - 2022-07-06 12:23:24 --> Language Class Initialized
INFO - 2022-07-06 12:23:24 --> Loader Class Initialized
INFO - 2022-07-06 12:23:24 --> Helper loaded: url_helper
INFO - 2022-07-06 12:23:24 --> Helper loaded: file_helper
INFO - 2022-07-06 12:23:24 --> Database Driver Class Initialized
INFO - 2022-07-06 12:23:24 --> Email Class Initialized
DEBUG - 2022-07-06 12:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 12:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 12:23:24 --> Controller Class Initialized
INFO - 2022-07-06 12:23:24 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 12:23:24 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 12:23:24 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 12:23:24 --> Final output sent to browser
DEBUG - 2022-07-06 12:23:24 --> Total execution time: 0.1830
INFO - 2022-07-06 12:24:16 --> Config Class Initialized
INFO - 2022-07-06 12:24:16 --> Hooks Class Initialized
DEBUG - 2022-07-06 12:24:16 --> UTF-8 Support Enabled
INFO - 2022-07-06 12:24:16 --> Utf8 Class Initialized
INFO - 2022-07-06 12:24:16 --> URI Class Initialized
INFO - 2022-07-06 12:24:16 --> Router Class Initialized
INFO - 2022-07-06 12:24:16 --> Output Class Initialized
INFO - 2022-07-06 12:24:16 --> Security Class Initialized
DEBUG - 2022-07-06 12:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 12:24:16 --> Input Class Initialized
INFO - 2022-07-06 12:24:16 --> Language Class Initialized
INFO - 2022-07-06 12:24:16 --> Loader Class Initialized
INFO - 2022-07-06 12:24:16 --> Helper loaded: url_helper
INFO - 2022-07-06 12:24:16 --> Helper loaded: file_helper
INFO - 2022-07-06 12:24:16 --> Database Driver Class Initialized
INFO - 2022-07-06 12:24:16 --> Email Class Initialized
DEBUG - 2022-07-06 12:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 12:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 12:24:16 --> Controller Class Initialized
INFO - 2022-07-06 12:24:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 12:24:16 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 12:24:16 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 12:24:16 --> Final output sent to browser
DEBUG - 2022-07-06 12:24:16 --> Total execution time: 0.2183
INFO - 2022-07-06 12:26:26 --> Config Class Initialized
INFO - 2022-07-06 12:26:26 --> Hooks Class Initialized
DEBUG - 2022-07-06 12:26:26 --> UTF-8 Support Enabled
INFO - 2022-07-06 12:26:26 --> Utf8 Class Initialized
INFO - 2022-07-06 12:26:26 --> URI Class Initialized
INFO - 2022-07-06 12:26:26 --> Router Class Initialized
INFO - 2022-07-06 12:26:26 --> Output Class Initialized
INFO - 2022-07-06 12:26:26 --> Security Class Initialized
DEBUG - 2022-07-06 12:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 12:26:26 --> Input Class Initialized
INFO - 2022-07-06 12:26:26 --> Language Class Initialized
INFO - 2022-07-06 12:26:26 --> Loader Class Initialized
INFO - 2022-07-06 12:26:26 --> Helper loaded: url_helper
INFO - 2022-07-06 12:26:26 --> Helper loaded: file_helper
INFO - 2022-07-06 12:26:26 --> Database Driver Class Initialized
INFO - 2022-07-06 12:26:26 --> Email Class Initialized
DEBUG - 2022-07-06 12:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 12:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 12:26:26 --> Controller Class Initialized
INFO - 2022-07-06 12:26:26 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 12:26:26 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 12:26:26 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 12:26:26 --> Final output sent to browser
DEBUG - 2022-07-06 12:26:26 --> Total execution time: 0.1149
INFO - 2022-07-06 12:27:22 --> Config Class Initialized
INFO - 2022-07-06 12:27:22 --> Hooks Class Initialized
DEBUG - 2022-07-06 12:27:22 --> UTF-8 Support Enabled
INFO - 2022-07-06 12:27:22 --> Utf8 Class Initialized
INFO - 2022-07-06 12:27:22 --> URI Class Initialized
INFO - 2022-07-06 12:27:22 --> Router Class Initialized
INFO - 2022-07-06 12:27:22 --> Output Class Initialized
INFO - 2022-07-06 12:27:22 --> Security Class Initialized
DEBUG - 2022-07-06 12:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 12:27:22 --> Input Class Initialized
INFO - 2022-07-06 12:27:22 --> Language Class Initialized
INFO - 2022-07-06 12:27:22 --> Loader Class Initialized
INFO - 2022-07-06 12:27:22 --> Helper loaded: url_helper
INFO - 2022-07-06 12:27:22 --> Helper loaded: file_helper
INFO - 2022-07-06 12:27:22 --> Database Driver Class Initialized
INFO - 2022-07-06 12:27:22 --> Email Class Initialized
DEBUG - 2022-07-06 12:27:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 12:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 12:27:22 --> Controller Class Initialized
INFO - 2022-07-06 12:27:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 12:27:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 12:27:22 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 12:27:22 --> Final output sent to browser
DEBUG - 2022-07-06 12:27:22 --> Total execution time: 0.1416
INFO - 2022-07-06 12:28:45 --> Config Class Initialized
INFO - 2022-07-06 12:28:45 --> Hooks Class Initialized
DEBUG - 2022-07-06 12:28:45 --> UTF-8 Support Enabled
INFO - 2022-07-06 12:28:45 --> Utf8 Class Initialized
INFO - 2022-07-06 12:28:45 --> URI Class Initialized
INFO - 2022-07-06 12:28:45 --> Router Class Initialized
INFO - 2022-07-06 12:28:45 --> Output Class Initialized
INFO - 2022-07-06 12:28:45 --> Security Class Initialized
DEBUG - 2022-07-06 12:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 12:28:45 --> Input Class Initialized
INFO - 2022-07-06 12:28:45 --> Language Class Initialized
INFO - 2022-07-06 12:28:45 --> Loader Class Initialized
INFO - 2022-07-06 12:28:45 --> Helper loaded: url_helper
INFO - 2022-07-06 12:28:45 --> Helper loaded: file_helper
INFO - 2022-07-06 12:28:45 --> Database Driver Class Initialized
INFO - 2022-07-06 12:28:45 --> Email Class Initialized
DEBUG - 2022-07-06 12:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 12:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 12:28:45 --> Controller Class Initialized
INFO - 2022-07-06 12:28:45 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 12:28:45 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 12:28:45 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 12:28:45 --> Final output sent to browser
DEBUG - 2022-07-06 12:28:45 --> Total execution time: 0.1326
INFO - 2022-07-06 12:29:49 --> Config Class Initialized
INFO - 2022-07-06 12:29:49 --> Hooks Class Initialized
DEBUG - 2022-07-06 12:29:49 --> UTF-8 Support Enabled
INFO - 2022-07-06 12:29:49 --> Utf8 Class Initialized
INFO - 2022-07-06 12:29:49 --> URI Class Initialized
INFO - 2022-07-06 12:29:49 --> Router Class Initialized
INFO - 2022-07-06 12:29:49 --> Output Class Initialized
INFO - 2022-07-06 12:29:49 --> Security Class Initialized
DEBUG - 2022-07-06 12:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 12:29:49 --> Input Class Initialized
INFO - 2022-07-06 12:29:49 --> Language Class Initialized
INFO - 2022-07-06 12:29:49 --> Loader Class Initialized
INFO - 2022-07-06 12:29:49 --> Helper loaded: url_helper
INFO - 2022-07-06 12:29:49 --> Helper loaded: file_helper
INFO - 2022-07-06 12:29:49 --> Database Driver Class Initialized
INFO - 2022-07-06 12:29:49 --> Email Class Initialized
DEBUG - 2022-07-06 12:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 12:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 12:29:49 --> Controller Class Initialized
INFO - 2022-07-06 12:29:49 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 12:29:49 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 12:29:49 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 12:29:49 --> Final output sent to browser
DEBUG - 2022-07-06 12:29:49 --> Total execution time: 0.1350
INFO - 2022-07-06 12:33:43 --> Config Class Initialized
INFO - 2022-07-06 12:33:43 --> Hooks Class Initialized
DEBUG - 2022-07-06 12:33:43 --> UTF-8 Support Enabled
INFO - 2022-07-06 12:33:43 --> Utf8 Class Initialized
INFO - 2022-07-06 12:33:43 --> URI Class Initialized
INFO - 2022-07-06 12:33:43 --> Router Class Initialized
INFO - 2022-07-06 12:33:43 --> Output Class Initialized
INFO - 2022-07-06 12:33:43 --> Security Class Initialized
DEBUG - 2022-07-06 12:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 12:33:43 --> Input Class Initialized
INFO - 2022-07-06 12:33:43 --> Language Class Initialized
INFO - 2022-07-06 12:33:43 --> Loader Class Initialized
INFO - 2022-07-06 12:33:43 --> Helper loaded: url_helper
INFO - 2022-07-06 12:33:43 --> Helper loaded: file_helper
INFO - 2022-07-06 12:33:43 --> Database Driver Class Initialized
INFO - 2022-07-06 12:33:43 --> Email Class Initialized
DEBUG - 2022-07-06 12:33:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 12:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 12:33:43 --> Controller Class Initialized
INFO - 2022-07-06 12:33:43 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 12:33:43 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 12:33:43 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 12:33:43 --> Final output sent to browser
DEBUG - 2022-07-06 12:33:43 --> Total execution time: 0.1342
INFO - 2022-07-06 12:34:40 --> Config Class Initialized
INFO - 2022-07-06 12:34:40 --> Hooks Class Initialized
DEBUG - 2022-07-06 12:34:40 --> UTF-8 Support Enabled
INFO - 2022-07-06 12:34:40 --> Utf8 Class Initialized
INFO - 2022-07-06 12:34:40 --> URI Class Initialized
INFO - 2022-07-06 12:34:40 --> Router Class Initialized
INFO - 2022-07-06 12:34:40 --> Output Class Initialized
INFO - 2022-07-06 12:34:40 --> Security Class Initialized
DEBUG - 2022-07-06 12:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 12:34:40 --> Input Class Initialized
INFO - 2022-07-06 12:34:40 --> Language Class Initialized
INFO - 2022-07-06 12:34:40 --> Loader Class Initialized
INFO - 2022-07-06 12:34:40 --> Helper loaded: url_helper
INFO - 2022-07-06 12:34:40 --> Helper loaded: file_helper
INFO - 2022-07-06 12:34:40 --> Database Driver Class Initialized
INFO - 2022-07-06 12:34:40 --> Email Class Initialized
DEBUG - 2022-07-06 12:34:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 12:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 12:34:40 --> Controller Class Initialized
INFO - 2022-07-06 12:34:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 12:34:40 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 12:34:40 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 12:34:40 --> Final output sent to browser
DEBUG - 2022-07-06 12:34:40 --> Total execution time: 0.1286
INFO - 2022-07-06 12:34:41 --> Config Class Initialized
INFO - 2022-07-06 12:34:41 --> Hooks Class Initialized
DEBUG - 2022-07-06 12:34:41 --> UTF-8 Support Enabled
INFO - 2022-07-06 12:34:41 --> Utf8 Class Initialized
INFO - 2022-07-06 12:34:41 --> URI Class Initialized
INFO - 2022-07-06 12:34:41 --> Router Class Initialized
INFO - 2022-07-06 12:34:41 --> Output Class Initialized
INFO - 2022-07-06 12:34:41 --> Security Class Initialized
DEBUG - 2022-07-06 12:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 12:34:41 --> Input Class Initialized
INFO - 2022-07-06 12:34:41 --> Language Class Initialized
INFO - 2022-07-06 12:34:41 --> Loader Class Initialized
INFO - 2022-07-06 12:34:41 --> Helper loaded: url_helper
INFO - 2022-07-06 12:34:41 --> Helper loaded: file_helper
INFO - 2022-07-06 12:34:41 --> Database Driver Class Initialized
INFO - 2022-07-06 12:34:41 --> Email Class Initialized
DEBUG - 2022-07-06 12:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 12:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 12:34:41 --> Controller Class Initialized
INFO - 2022-07-06 12:34:41 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 12:34:41 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 12:34:41 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 12:34:41 --> Final output sent to browser
DEBUG - 2022-07-06 12:34:41 --> Total execution time: 0.1571
INFO - 2022-07-06 12:34:41 --> Config Class Initialized
INFO - 2022-07-06 12:34:41 --> Hooks Class Initialized
DEBUG - 2022-07-06 12:34:41 --> UTF-8 Support Enabled
INFO - 2022-07-06 12:34:41 --> Utf8 Class Initialized
INFO - 2022-07-06 12:34:41 --> URI Class Initialized
INFO - 2022-07-06 12:34:41 --> Router Class Initialized
INFO - 2022-07-06 12:34:41 --> Output Class Initialized
INFO - 2022-07-06 12:34:41 --> Security Class Initialized
DEBUG - 2022-07-06 12:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 12:34:41 --> Input Class Initialized
INFO - 2022-07-06 12:34:41 --> Language Class Initialized
INFO - 2022-07-06 12:34:41 --> Loader Class Initialized
INFO - 2022-07-06 12:34:41 --> Helper loaded: url_helper
INFO - 2022-07-06 12:34:41 --> Helper loaded: file_helper
INFO - 2022-07-06 12:34:41 --> Database Driver Class Initialized
INFO - 2022-07-06 12:34:42 --> Email Class Initialized
DEBUG - 2022-07-06 12:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 12:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 12:34:42 --> Controller Class Initialized
INFO - 2022-07-06 12:34:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 12:34:42 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 12:34:42 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 12:34:42 --> Final output sent to browser
DEBUG - 2022-07-06 12:34:42 --> Total execution time: 0.0515
INFO - 2022-07-06 12:34:42 --> Config Class Initialized
INFO - 2022-07-06 12:34:42 --> Hooks Class Initialized
DEBUG - 2022-07-06 12:34:42 --> UTF-8 Support Enabled
INFO - 2022-07-06 12:34:42 --> Utf8 Class Initialized
INFO - 2022-07-06 12:34:42 --> URI Class Initialized
INFO - 2022-07-06 12:34:42 --> Router Class Initialized
INFO - 2022-07-06 12:34:42 --> Output Class Initialized
INFO - 2022-07-06 12:34:42 --> Security Class Initialized
DEBUG - 2022-07-06 12:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 12:34:42 --> Input Class Initialized
INFO - 2022-07-06 12:34:42 --> Language Class Initialized
INFO - 2022-07-06 12:34:42 --> Loader Class Initialized
INFO - 2022-07-06 12:34:42 --> Helper loaded: url_helper
INFO - 2022-07-06 12:34:42 --> Helper loaded: file_helper
INFO - 2022-07-06 12:34:42 --> Database Driver Class Initialized
INFO - 2022-07-06 12:34:42 --> Email Class Initialized
DEBUG - 2022-07-06 12:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 12:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 12:34:42 --> Controller Class Initialized
INFO - 2022-07-06 12:34:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 12:34:42 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 12:34:42 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 12:34:42 --> Final output sent to browser
DEBUG - 2022-07-06 12:34:42 --> Total execution time: 0.0497
INFO - 2022-07-06 12:35:16 --> Config Class Initialized
INFO - 2022-07-06 12:35:16 --> Hooks Class Initialized
DEBUG - 2022-07-06 12:35:16 --> UTF-8 Support Enabled
INFO - 2022-07-06 12:35:16 --> Utf8 Class Initialized
INFO - 2022-07-06 12:35:16 --> URI Class Initialized
INFO - 2022-07-06 12:35:16 --> Router Class Initialized
INFO - 2022-07-06 12:35:16 --> Output Class Initialized
INFO - 2022-07-06 12:35:16 --> Security Class Initialized
DEBUG - 2022-07-06 12:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 12:35:16 --> Input Class Initialized
INFO - 2022-07-06 12:35:16 --> Language Class Initialized
INFO - 2022-07-06 12:35:16 --> Loader Class Initialized
INFO - 2022-07-06 12:35:16 --> Helper loaded: url_helper
INFO - 2022-07-06 12:35:16 --> Helper loaded: file_helper
INFO - 2022-07-06 12:35:16 --> Database Driver Class Initialized
INFO - 2022-07-06 12:35:16 --> Email Class Initialized
DEBUG - 2022-07-06 12:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 12:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 12:35:16 --> Controller Class Initialized
INFO - 2022-07-06 12:35:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 12:35:16 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 12:35:16 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 12:35:16 --> Final output sent to browser
DEBUG - 2022-07-06 12:35:16 --> Total execution time: 0.1354
INFO - 2022-07-06 12:35:17 --> Config Class Initialized
INFO - 2022-07-06 12:35:17 --> Hooks Class Initialized
DEBUG - 2022-07-06 12:35:17 --> UTF-8 Support Enabled
INFO - 2022-07-06 12:35:17 --> Utf8 Class Initialized
INFO - 2022-07-06 12:35:17 --> URI Class Initialized
INFO - 2022-07-06 12:35:17 --> Router Class Initialized
INFO - 2022-07-06 12:35:17 --> Output Class Initialized
INFO - 2022-07-06 12:35:17 --> Security Class Initialized
DEBUG - 2022-07-06 12:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 12:35:17 --> Input Class Initialized
INFO - 2022-07-06 12:35:17 --> Language Class Initialized
INFO - 2022-07-06 12:35:17 --> Loader Class Initialized
INFO - 2022-07-06 12:35:17 --> Helper loaded: url_helper
INFO - 2022-07-06 12:35:17 --> Helper loaded: file_helper
INFO - 2022-07-06 12:35:17 --> Database Driver Class Initialized
INFO - 2022-07-06 12:35:17 --> Email Class Initialized
DEBUG - 2022-07-06 12:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 12:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 12:35:17 --> Controller Class Initialized
INFO - 2022-07-06 12:35:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 12:35:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 12:35:17 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 12:35:17 --> Final output sent to browser
DEBUG - 2022-07-06 12:35:17 --> Total execution time: 0.1149
INFO - 2022-07-06 12:35:34 --> Config Class Initialized
INFO - 2022-07-06 12:35:34 --> Hooks Class Initialized
DEBUG - 2022-07-06 12:35:34 --> UTF-8 Support Enabled
INFO - 2022-07-06 12:35:34 --> Utf8 Class Initialized
INFO - 2022-07-06 12:35:34 --> URI Class Initialized
INFO - 2022-07-06 12:35:34 --> Router Class Initialized
INFO - 2022-07-06 12:35:34 --> Output Class Initialized
INFO - 2022-07-06 12:35:34 --> Security Class Initialized
DEBUG - 2022-07-06 12:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 12:35:34 --> Input Class Initialized
INFO - 2022-07-06 12:35:34 --> Language Class Initialized
INFO - 2022-07-06 12:35:34 --> Loader Class Initialized
INFO - 2022-07-06 12:35:34 --> Helper loaded: url_helper
INFO - 2022-07-06 12:35:34 --> Helper loaded: file_helper
INFO - 2022-07-06 12:35:34 --> Database Driver Class Initialized
INFO - 2022-07-06 12:35:34 --> Email Class Initialized
DEBUG - 2022-07-06 12:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 12:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 12:35:34 --> Controller Class Initialized
INFO - 2022-07-06 12:35:34 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 12:35:34 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 12:35:34 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 12:35:34 --> Final output sent to browser
DEBUG - 2022-07-06 12:35:34 --> Total execution time: 0.1588
INFO - 2022-07-06 12:36:27 --> Config Class Initialized
INFO - 2022-07-06 12:36:27 --> Hooks Class Initialized
DEBUG - 2022-07-06 12:36:27 --> UTF-8 Support Enabled
INFO - 2022-07-06 12:36:27 --> Utf8 Class Initialized
INFO - 2022-07-06 12:36:27 --> URI Class Initialized
INFO - 2022-07-06 12:36:27 --> Router Class Initialized
INFO - 2022-07-06 12:36:27 --> Output Class Initialized
INFO - 2022-07-06 12:36:27 --> Security Class Initialized
DEBUG - 2022-07-06 12:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 12:36:27 --> Input Class Initialized
INFO - 2022-07-06 12:36:27 --> Language Class Initialized
INFO - 2022-07-06 12:36:27 --> Loader Class Initialized
INFO - 2022-07-06 12:36:27 --> Helper loaded: url_helper
INFO - 2022-07-06 12:36:27 --> Helper loaded: file_helper
INFO - 2022-07-06 12:36:27 --> Database Driver Class Initialized
INFO - 2022-07-06 12:36:27 --> Email Class Initialized
DEBUG - 2022-07-06 12:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 12:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 12:36:27 --> Controller Class Initialized
INFO - 2022-07-06 12:36:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 12:36:27 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 12:36:27 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 12:36:27 --> Final output sent to browser
DEBUG - 2022-07-06 12:36:27 --> Total execution time: 0.1429
INFO - 2022-07-06 12:38:08 --> Config Class Initialized
INFO - 2022-07-06 12:38:08 --> Hooks Class Initialized
DEBUG - 2022-07-06 12:38:08 --> UTF-8 Support Enabled
INFO - 2022-07-06 12:38:08 --> Utf8 Class Initialized
INFO - 2022-07-06 12:38:08 --> URI Class Initialized
INFO - 2022-07-06 12:38:08 --> Router Class Initialized
INFO - 2022-07-06 12:38:08 --> Output Class Initialized
INFO - 2022-07-06 12:38:08 --> Security Class Initialized
DEBUG - 2022-07-06 12:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 12:38:08 --> Input Class Initialized
INFO - 2022-07-06 12:38:08 --> Language Class Initialized
INFO - 2022-07-06 12:38:08 --> Loader Class Initialized
INFO - 2022-07-06 12:38:08 --> Helper loaded: url_helper
INFO - 2022-07-06 12:38:08 --> Helper loaded: file_helper
INFO - 2022-07-06 12:38:08 --> Database Driver Class Initialized
INFO - 2022-07-06 12:38:08 --> Email Class Initialized
DEBUG - 2022-07-06 12:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 12:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 12:38:08 --> Controller Class Initialized
INFO - 2022-07-06 12:38:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 12:38:08 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 12:38:08 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 12:38:08 --> Final output sent to browser
DEBUG - 2022-07-06 12:38:08 --> Total execution time: 0.2364
INFO - 2022-07-06 12:39:30 --> Config Class Initialized
INFO - 2022-07-06 12:39:30 --> Hooks Class Initialized
DEBUG - 2022-07-06 12:39:30 --> UTF-8 Support Enabled
INFO - 2022-07-06 12:39:30 --> Utf8 Class Initialized
INFO - 2022-07-06 12:39:30 --> URI Class Initialized
INFO - 2022-07-06 12:39:30 --> Router Class Initialized
INFO - 2022-07-06 12:39:30 --> Output Class Initialized
INFO - 2022-07-06 12:39:30 --> Security Class Initialized
DEBUG - 2022-07-06 12:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 12:39:30 --> Input Class Initialized
INFO - 2022-07-06 12:39:30 --> Language Class Initialized
INFO - 2022-07-06 12:39:30 --> Loader Class Initialized
INFO - 2022-07-06 12:39:30 --> Helper loaded: url_helper
INFO - 2022-07-06 12:39:30 --> Helper loaded: file_helper
INFO - 2022-07-06 12:39:30 --> Database Driver Class Initialized
INFO - 2022-07-06 12:39:30 --> Email Class Initialized
DEBUG - 2022-07-06 12:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 12:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 12:39:30 --> Controller Class Initialized
INFO - 2022-07-06 12:39:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 12:39:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 12:39:30 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 12:39:30 --> Final output sent to browser
DEBUG - 2022-07-06 12:39:30 --> Total execution time: 0.0622
INFO - 2022-07-06 12:40:02 --> Config Class Initialized
INFO - 2022-07-06 12:40:02 --> Hooks Class Initialized
DEBUG - 2022-07-06 12:40:02 --> UTF-8 Support Enabled
INFO - 2022-07-06 12:40:02 --> Utf8 Class Initialized
INFO - 2022-07-06 12:40:02 --> URI Class Initialized
INFO - 2022-07-06 12:40:02 --> Router Class Initialized
INFO - 2022-07-06 12:40:02 --> Output Class Initialized
INFO - 2022-07-06 12:40:02 --> Security Class Initialized
DEBUG - 2022-07-06 12:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 12:40:02 --> Input Class Initialized
INFO - 2022-07-06 12:40:02 --> Language Class Initialized
INFO - 2022-07-06 12:40:02 --> Loader Class Initialized
INFO - 2022-07-06 12:40:02 --> Helper loaded: url_helper
INFO - 2022-07-06 12:40:02 --> Helper loaded: file_helper
INFO - 2022-07-06 12:40:02 --> Database Driver Class Initialized
INFO - 2022-07-06 12:40:02 --> Email Class Initialized
DEBUG - 2022-07-06 12:40:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 12:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 12:40:02 --> Controller Class Initialized
INFO - 2022-07-06 12:40:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 12:40:02 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 12:40:02 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 12:40:02 --> Final output sent to browser
DEBUG - 2022-07-06 12:40:02 --> Total execution time: 0.2079
INFO - 2022-07-06 12:41:44 --> Config Class Initialized
INFO - 2022-07-06 12:41:44 --> Hooks Class Initialized
DEBUG - 2022-07-06 12:41:44 --> UTF-8 Support Enabled
INFO - 2022-07-06 12:41:44 --> Utf8 Class Initialized
INFO - 2022-07-06 12:41:44 --> URI Class Initialized
INFO - 2022-07-06 12:41:44 --> Router Class Initialized
INFO - 2022-07-06 12:41:44 --> Output Class Initialized
INFO - 2022-07-06 12:41:44 --> Security Class Initialized
DEBUG - 2022-07-06 12:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 12:41:44 --> Input Class Initialized
INFO - 2022-07-06 12:41:44 --> Language Class Initialized
INFO - 2022-07-06 12:41:44 --> Loader Class Initialized
INFO - 2022-07-06 12:41:44 --> Helper loaded: url_helper
INFO - 2022-07-06 12:41:44 --> Helper loaded: file_helper
INFO - 2022-07-06 12:41:44 --> Database Driver Class Initialized
INFO - 2022-07-06 12:41:44 --> Email Class Initialized
DEBUG - 2022-07-06 12:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 12:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 12:41:44 --> Controller Class Initialized
INFO - 2022-07-06 12:41:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 12:41:44 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 12:41:44 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 12:41:44 --> Final output sent to browser
DEBUG - 2022-07-06 12:41:44 --> Total execution time: 0.1948
INFO - 2022-07-06 12:41:45 --> Config Class Initialized
INFO - 2022-07-06 12:41:45 --> Hooks Class Initialized
DEBUG - 2022-07-06 12:41:45 --> UTF-8 Support Enabled
INFO - 2022-07-06 12:41:45 --> Utf8 Class Initialized
INFO - 2022-07-06 12:41:45 --> URI Class Initialized
INFO - 2022-07-06 12:41:45 --> Router Class Initialized
INFO - 2022-07-06 12:41:45 --> Output Class Initialized
INFO - 2022-07-06 12:41:45 --> Security Class Initialized
DEBUG - 2022-07-06 12:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 12:41:45 --> Input Class Initialized
INFO - 2022-07-06 12:41:45 --> Language Class Initialized
INFO - 2022-07-06 12:41:45 --> Loader Class Initialized
INFO - 2022-07-06 12:41:45 --> Helper loaded: url_helper
INFO - 2022-07-06 12:41:45 --> Helper loaded: file_helper
INFO - 2022-07-06 12:41:45 --> Database Driver Class Initialized
INFO - 2022-07-06 12:41:45 --> Email Class Initialized
DEBUG - 2022-07-06 12:41:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 12:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 12:41:45 --> Controller Class Initialized
INFO - 2022-07-06 12:41:45 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 12:41:45 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 12:41:45 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 12:41:45 --> Final output sent to browser
DEBUG - 2022-07-06 12:41:45 --> Total execution time: 0.1790
INFO - 2022-07-06 12:41:46 --> Config Class Initialized
INFO - 2022-07-06 12:41:46 --> Hooks Class Initialized
DEBUG - 2022-07-06 12:41:46 --> UTF-8 Support Enabled
INFO - 2022-07-06 12:41:46 --> Utf8 Class Initialized
INFO - 2022-07-06 12:41:46 --> URI Class Initialized
INFO - 2022-07-06 12:41:46 --> Router Class Initialized
INFO - 2022-07-06 12:41:46 --> Output Class Initialized
INFO - 2022-07-06 12:41:46 --> Security Class Initialized
DEBUG - 2022-07-06 12:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 12:41:46 --> Input Class Initialized
INFO - 2022-07-06 12:41:46 --> Language Class Initialized
INFO - 2022-07-06 12:41:46 --> Loader Class Initialized
INFO - 2022-07-06 12:41:46 --> Helper loaded: url_helper
INFO - 2022-07-06 12:41:46 --> Helper loaded: file_helper
INFO - 2022-07-06 12:41:46 --> Database Driver Class Initialized
INFO - 2022-07-06 12:41:46 --> Email Class Initialized
DEBUG - 2022-07-06 12:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 12:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 12:41:46 --> Controller Class Initialized
INFO - 2022-07-06 12:41:46 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 12:41:46 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 12:41:46 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 12:41:46 --> Final output sent to browser
DEBUG - 2022-07-06 12:41:46 --> Total execution time: 0.1391
INFO - 2022-07-06 12:41:49 --> Config Class Initialized
INFO - 2022-07-06 12:41:49 --> Hooks Class Initialized
DEBUG - 2022-07-06 12:41:49 --> UTF-8 Support Enabled
INFO - 2022-07-06 12:41:49 --> Utf8 Class Initialized
INFO - 2022-07-06 12:41:49 --> URI Class Initialized
INFO - 2022-07-06 12:41:49 --> Router Class Initialized
INFO - 2022-07-06 12:41:49 --> Output Class Initialized
INFO - 2022-07-06 12:41:49 --> Security Class Initialized
DEBUG - 2022-07-06 12:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-06 12:41:49 --> Input Class Initialized
INFO - 2022-07-06 12:41:49 --> Language Class Initialized
INFO - 2022-07-06 12:41:49 --> Loader Class Initialized
INFO - 2022-07-06 12:41:49 --> Helper loaded: url_helper
INFO - 2022-07-06 12:41:49 --> Helper loaded: file_helper
INFO - 2022-07-06 12:41:49 --> Database Driver Class Initialized
INFO - 2022-07-06 12:41:49 --> Email Class Initialized
DEBUG - 2022-07-06 12:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-06 12:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-06 12:41:49 --> Controller Class Initialized
INFO - 2022-07-06 12:41:49 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-06 12:41:49 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-06 12:41:49 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-06 12:41:49 --> Final output sent to browser
DEBUG - 2022-07-06 12:41:49 --> Total execution time: 0.0459
