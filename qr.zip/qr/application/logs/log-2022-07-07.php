<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-07-07 04:27:00 --> Config Class Initialized
INFO - 2022-07-07 04:27:00 --> Hooks Class Initialized
DEBUG - 2022-07-07 04:27:01 --> UTF-8 Support Enabled
INFO - 2022-07-07 04:27:01 --> Utf8 Class Initialized
INFO - 2022-07-07 04:27:01 --> URI Class Initialized
INFO - 2022-07-07 04:27:01 --> Router Class Initialized
INFO - 2022-07-07 04:27:01 --> Output Class Initialized
INFO - 2022-07-07 04:27:01 --> Security Class Initialized
DEBUG - 2022-07-07 04:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 04:27:01 --> Input Class Initialized
INFO - 2022-07-07 04:27:01 --> Language Class Initialized
INFO - 2022-07-07 04:27:01 --> Loader Class Initialized
INFO - 2022-07-07 04:27:01 --> Helper loaded: url_helper
INFO - 2022-07-07 04:27:01 --> Helper loaded: file_helper
INFO - 2022-07-07 04:27:01 --> Database Driver Class Initialized
INFO - 2022-07-07 04:27:02 --> Email Class Initialized
DEBUG - 2022-07-07 04:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 04:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 04:27:02 --> Controller Class Initialized
INFO - 2022-07-07 04:27:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-07 04:27:02 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-07 04:27:05 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-07 04:27:05 --> Final output sent to browser
DEBUG - 2022-07-07 04:27:05 --> Total execution time: 5.0783
