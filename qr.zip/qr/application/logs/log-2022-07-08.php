<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-07-08 17:15:44 --> Config Class Initialized
INFO - 2022-07-08 17:15:44 --> Hooks Class Initialized
DEBUG - 2022-07-08 17:15:44 --> UTF-8 Support Enabled
INFO - 2022-07-08 17:15:44 --> Utf8 Class Initialized
INFO - 2022-07-08 17:15:44 --> URI Class Initialized
INFO - 2022-07-08 17:15:44 --> Router Class Initialized
INFO - 2022-07-08 17:15:44 --> Output Class Initialized
INFO - 2022-07-08 17:15:44 --> Security Class Initialized
DEBUG - 2022-07-08 17:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-08 17:15:44 --> Input Class Initialized
INFO - 2022-07-08 17:15:44 --> Language Class Initialized
INFO - 2022-07-08 17:15:44 --> Loader Class Initialized
INFO - 2022-07-08 17:15:44 --> Helper loaded: url_helper
INFO - 2022-07-08 17:15:44 --> Helper loaded: file_helper
INFO - 2022-07-08 17:15:44 --> Database Driver Class Initialized
INFO - 2022-07-08 17:15:45 --> Email Class Initialized
DEBUG - 2022-07-08 17:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-08 17:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-08 17:15:45 --> Controller Class Initialized
INFO - 2022-07-08 17:15:45 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-08 17:15:45 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-08 17:15:45 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-08 17:15:45 --> Final output sent to browser
DEBUG - 2022-07-08 17:15:45 --> Total execution time: 0.6714
INFO - 2022-07-08 17:15:48 --> Config Class Initialized
INFO - 2022-07-08 17:15:48 --> Hooks Class Initialized
DEBUG - 2022-07-08 17:15:48 --> UTF-8 Support Enabled
INFO - 2022-07-08 17:15:48 --> Utf8 Class Initialized
INFO - 2022-07-08 17:15:48 --> URI Class Initialized
INFO - 2022-07-08 17:15:48 --> Router Class Initialized
INFO - 2022-07-08 17:15:48 --> Output Class Initialized
INFO - 2022-07-08 17:15:48 --> Security Class Initialized
DEBUG - 2022-07-08 17:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-08 17:15:48 --> Input Class Initialized
INFO - 2022-07-08 17:15:48 --> Language Class Initialized
INFO - 2022-07-08 17:15:48 --> Loader Class Initialized
INFO - 2022-07-08 17:15:48 --> Helper loaded: url_helper
INFO - 2022-07-08 17:15:48 --> Helper loaded: file_helper
INFO - 2022-07-08 17:15:48 --> Database Driver Class Initialized
INFO - 2022-07-08 17:15:48 --> Email Class Initialized
DEBUG - 2022-07-08 17:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-08 17:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-08 17:15:48 --> Controller Class Initialized
INFO - 2022-07-08 17:15:48 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-08 17:15:48 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-08 17:15:48 --> Final output sent to browser
DEBUG - 2022-07-08 17:15:48 --> Total execution time: 0.0707
INFO - 2022-07-08 17:15:51 --> Config Class Initialized
INFO - 2022-07-08 17:15:51 --> Hooks Class Initialized
DEBUG - 2022-07-08 17:15:51 --> UTF-8 Support Enabled
INFO - 2022-07-08 17:15:51 --> Utf8 Class Initialized
INFO - 2022-07-08 17:15:51 --> URI Class Initialized
INFO - 2022-07-08 17:15:51 --> Router Class Initialized
INFO - 2022-07-08 17:15:51 --> Output Class Initialized
INFO - 2022-07-08 17:15:51 --> Security Class Initialized
DEBUG - 2022-07-08 17:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-08 17:15:51 --> Input Class Initialized
INFO - 2022-07-08 17:15:51 --> Language Class Initialized
INFO - 2022-07-08 17:15:51 --> Loader Class Initialized
INFO - 2022-07-08 17:15:51 --> Helper loaded: url_helper
INFO - 2022-07-08 17:15:51 --> Helper loaded: file_helper
INFO - 2022-07-08 17:15:51 --> Database Driver Class Initialized
INFO - 2022-07-08 17:15:51 --> Email Class Initialized
DEBUG - 2022-07-08 17:15:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-08 17:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-08 17:15:51 --> Controller Class Initialized
INFO - 2022-07-08 17:15:51 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-08 17:15:51 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-08 17:15:51 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor_1.php
INFO - 2022-07-08 17:15:51 --> Final output sent to browser
DEBUG - 2022-07-08 17:15:51 --> Total execution time: 0.1800
INFO - 2022-07-08 17:16:16 --> Config Class Initialized
INFO - 2022-07-08 17:16:16 --> Hooks Class Initialized
DEBUG - 2022-07-08 17:16:16 --> UTF-8 Support Enabled
INFO - 2022-07-08 17:16:16 --> Utf8 Class Initialized
INFO - 2022-07-08 17:16:16 --> URI Class Initialized
INFO - 2022-07-08 17:16:16 --> Router Class Initialized
INFO - 2022-07-08 17:16:16 --> Output Class Initialized
INFO - 2022-07-08 17:16:16 --> Security Class Initialized
DEBUG - 2022-07-08 17:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-08 17:16:16 --> Input Class Initialized
INFO - 2022-07-08 17:16:16 --> Language Class Initialized
INFO - 2022-07-08 17:16:16 --> Loader Class Initialized
INFO - 2022-07-08 17:16:16 --> Helper loaded: url_helper
INFO - 2022-07-08 17:16:16 --> Helper loaded: file_helper
INFO - 2022-07-08 17:16:16 --> Database Driver Class Initialized
INFO - 2022-07-08 17:16:16 --> Email Class Initialized
DEBUG - 2022-07-08 17:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-08 17:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-08 17:16:16 --> Controller Class Initialized
INFO - 2022-07-08 17:16:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-08 17:16:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 17:16:16 --> insertedINSERT INTO `tokendetails` (`td_tk`, `td_cs`, `td_visited_date`) VALUES (1, 0, '2022-07-08')
INFO - 2022-07-08 17:16:16 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-08 17:16:16 --> Final output sent to browser
DEBUG - 2022-07-08 17:16:16 --> Total execution time: 0.0224
INFO - 2022-07-08 17:17:13 --> Config Class Initialized
INFO - 2022-07-08 17:17:13 --> Hooks Class Initialized
DEBUG - 2022-07-08 17:17:13 --> UTF-8 Support Enabled
INFO - 2022-07-08 17:17:13 --> Utf8 Class Initialized
INFO - 2022-07-08 17:17:13 --> URI Class Initialized
INFO - 2022-07-08 17:17:13 --> Router Class Initialized
INFO - 2022-07-08 17:17:13 --> Output Class Initialized
INFO - 2022-07-08 17:17:13 --> Security Class Initialized
DEBUG - 2022-07-08 17:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-08 17:17:13 --> Input Class Initialized
INFO - 2022-07-08 17:17:13 --> Language Class Initialized
INFO - 2022-07-08 17:17:13 --> Loader Class Initialized
INFO - 2022-07-08 17:17:13 --> Helper loaded: url_helper
INFO - 2022-07-08 17:17:13 --> Helper loaded: file_helper
INFO - 2022-07-08 17:17:13 --> Database Driver Class Initialized
INFO - 2022-07-08 17:17:13 --> Email Class Initialized
DEBUG - 2022-07-08 17:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-08 17:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-08 17:17:13 --> Controller Class Initialized
INFO - 2022-07-08 17:17:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-08 17:17:13 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-08 17:17:13 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails_1.php
INFO - 2022-07-08 17:17:13 --> Final output sent to browser
DEBUG - 2022-07-08 17:17:13 --> Total execution time: 0.0590
INFO - 2022-07-08 17:17:13 --> Config Class Initialized
INFO - 2022-07-08 17:17:13 --> Hooks Class Initialized
DEBUG - 2022-07-08 17:17:13 --> UTF-8 Support Enabled
INFO - 2022-07-08 17:17:13 --> Utf8 Class Initialized
INFO - 2022-07-08 17:17:13 --> URI Class Initialized
INFO - 2022-07-08 17:17:13 --> Router Class Initialized
INFO - 2022-07-08 17:17:13 --> Output Class Initialized
INFO - 2022-07-08 17:17:13 --> Security Class Initialized
DEBUG - 2022-07-08 17:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-08 17:17:13 --> Input Class Initialized
INFO - 2022-07-08 17:17:13 --> Language Class Initialized
INFO - 2022-07-08 17:17:13 --> Loader Class Initialized
INFO - 2022-07-08 17:17:13 --> Helper loaded: url_helper
INFO - 2022-07-08 17:17:13 --> Helper loaded: file_helper
INFO - 2022-07-08 17:17:13 --> Database Driver Class Initialized
INFO - 2022-07-08 17:17:13 --> Email Class Initialized
DEBUG - 2022-07-08 17:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-08 17:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-08 17:17:13 --> Controller Class Initialized
INFO - 2022-07-08 17:17:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-08 17:17:13 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-08 17:17:13 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails_1.php
INFO - 2022-07-08 17:17:13 --> Final output sent to browser
DEBUG - 2022-07-08 17:17:13 --> Total execution time: 0.0194
INFO - 2022-07-08 17:17:33 --> Config Class Initialized
INFO - 2022-07-08 17:17:33 --> Hooks Class Initialized
DEBUG - 2022-07-08 17:17:33 --> UTF-8 Support Enabled
INFO - 2022-07-08 17:17:33 --> Utf8 Class Initialized
INFO - 2022-07-08 17:17:33 --> URI Class Initialized
INFO - 2022-07-08 17:17:33 --> Router Class Initialized
INFO - 2022-07-08 17:17:33 --> Output Class Initialized
INFO - 2022-07-08 17:17:33 --> Security Class Initialized
DEBUG - 2022-07-08 17:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-08 17:17:33 --> Input Class Initialized
INFO - 2022-07-08 17:17:33 --> Language Class Initialized
INFO - 2022-07-08 17:17:33 --> Loader Class Initialized
INFO - 2022-07-08 17:17:33 --> Helper loaded: url_helper
INFO - 2022-07-08 17:17:33 --> Helper loaded: file_helper
INFO - 2022-07-08 17:17:33 --> Database Driver Class Initialized
INFO - 2022-07-08 17:17:33 --> Email Class Initialized
DEBUG - 2022-07-08 17:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-08 17:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-08 17:17:33 --> Controller Class Initialized
INFO - 2022-07-08 17:17:33 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-08 17:17:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 17:17:33 --> test
INFO - 2022-07-08 17:17:33 --> Final output sent to browser
DEBUG - 2022-07-08 17:17:33 --> Total execution time: 0.0314
INFO - 2022-07-08 17:17:33 --> Config Class Initialized
INFO - 2022-07-08 17:17:33 --> Hooks Class Initialized
DEBUG - 2022-07-08 17:17:33 --> UTF-8 Support Enabled
INFO - 2022-07-08 17:17:33 --> Utf8 Class Initialized
INFO - 2022-07-08 17:17:33 --> URI Class Initialized
INFO - 2022-07-08 17:17:33 --> Router Class Initialized
INFO - 2022-07-08 17:17:33 --> Output Class Initialized
INFO - 2022-07-08 17:17:33 --> Security Class Initialized
DEBUG - 2022-07-08 17:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-08 17:17:33 --> Input Class Initialized
INFO - 2022-07-08 17:17:33 --> Language Class Initialized
INFO - 2022-07-08 17:17:33 --> Loader Class Initialized
INFO - 2022-07-08 17:17:33 --> Helper loaded: url_helper
INFO - 2022-07-08 17:17:33 --> Helper loaded: file_helper
INFO - 2022-07-08 17:17:33 --> Database Driver Class Initialized
INFO - 2022-07-08 17:17:33 --> Email Class Initialized
DEBUG - 2022-07-08 17:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-08 17:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-08 17:17:33 --> Controller Class Initialized
INFO - 2022-07-08 17:17:33 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-08 17:17:33 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-08 17:17:33 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-08 17:17:33 --> Final output sent to browser
DEBUG - 2022-07-08 17:17:33 --> Total execution time: 0.0420
INFO - 2022-07-08 17:17:42 --> Config Class Initialized
INFO - 2022-07-08 17:17:42 --> Hooks Class Initialized
DEBUG - 2022-07-08 17:17:42 --> UTF-8 Support Enabled
INFO - 2022-07-08 17:17:42 --> Utf8 Class Initialized
INFO - 2022-07-08 17:17:42 --> URI Class Initialized
INFO - 2022-07-08 17:17:42 --> Router Class Initialized
INFO - 2022-07-08 17:17:42 --> Output Class Initialized
INFO - 2022-07-08 17:17:42 --> Security Class Initialized
DEBUG - 2022-07-08 17:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-08 17:17:42 --> Input Class Initialized
INFO - 2022-07-08 17:17:42 --> Language Class Initialized
INFO - 2022-07-08 17:17:42 --> Loader Class Initialized
INFO - 2022-07-08 17:17:42 --> Helper loaded: url_helper
INFO - 2022-07-08 17:17:42 --> Helper loaded: file_helper
INFO - 2022-07-08 17:17:42 --> Database Driver Class Initialized
INFO - 2022-07-08 17:17:42 --> Email Class Initialized
DEBUG - 2022-07-08 17:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-08 17:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-08 17:17:42 --> Controller Class Initialized
INFO - 2022-07-08 17:17:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-08 17:17:42 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-08 17:20:25 --> Config Class Initialized
INFO - 2022-07-08 17:20:25 --> Hooks Class Initialized
DEBUG - 2022-07-08 17:20:25 --> UTF-8 Support Enabled
INFO - 2022-07-08 17:20:25 --> Utf8 Class Initialized
INFO - 2022-07-08 17:20:25 --> URI Class Initialized
INFO - 2022-07-08 17:20:25 --> Router Class Initialized
INFO - 2022-07-08 17:20:25 --> Output Class Initialized
INFO - 2022-07-08 17:20:25 --> Security Class Initialized
DEBUG - 2022-07-08 17:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-08 17:20:25 --> Input Class Initialized
INFO - 2022-07-08 17:20:25 --> Language Class Initialized
INFO - 2022-07-08 17:20:25 --> Loader Class Initialized
INFO - 2022-07-08 17:20:25 --> Helper loaded: url_helper
INFO - 2022-07-08 17:20:25 --> Helper loaded: file_helper
INFO - 2022-07-08 17:20:25 --> Database Driver Class Initialized
INFO - 2022-07-08 17:20:25 --> Email Class Initialized
DEBUG - 2022-07-08 17:20:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-08 17:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-08 17:20:25 --> Controller Class Initialized
INFO - 2022-07-08 17:20:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-08 17:20:25 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-08 17:20:25 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp_1.php
INFO - 2022-07-08 17:20:25 --> Final output sent to browser
DEBUG - 2022-07-08 17:20:25 --> Total execution time: 0.0659
INFO - 2022-07-08 17:20:35 --> Config Class Initialized
INFO - 2022-07-08 17:20:35 --> Hooks Class Initialized
DEBUG - 2022-07-08 17:20:35 --> UTF-8 Support Enabled
INFO - 2022-07-08 17:20:35 --> Utf8 Class Initialized
INFO - 2022-07-08 17:20:35 --> URI Class Initialized
INFO - 2022-07-08 17:20:35 --> Router Class Initialized
INFO - 2022-07-08 17:20:35 --> Output Class Initialized
INFO - 2022-07-08 17:20:35 --> Security Class Initialized
DEBUG - 2022-07-08 17:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-08 17:20:35 --> Input Class Initialized
INFO - 2022-07-08 17:20:35 --> Language Class Initialized
INFO - 2022-07-08 17:20:35 --> Loader Class Initialized
INFO - 2022-07-08 17:20:35 --> Helper loaded: url_helper
INFO - 2022-07-08 17:20:35 --> Helper loaded: file_helper
INFO - 2022-07-08 17:20:35 --> Database Driver Class Initialized
INFO - 2022-07-08 17:20:35 --> Email Class Initialized
DEBUG - 2022-07-08 17:20:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-08 17:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-08 17:20:35 --> Controller Class Initialized
INFO - 2022-07-08 17:20:35 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-08 17:20:35 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-08 17:20:43 --> Config Class Initialized
INFO - 2022-07-08 17:20:43 --> Hooks Class Initialized
DEBUG - 2022-07-08 17:20:43 --> UTF-8 Support Enabled
INFO - 2022-07-08 17:20:43 --> Utf8 Class Initialized
INFO - 2022-07-08 17:20:43 --> URI Class Initialized
INFO - 2022-07-08 17:20:43 --> Router Class Initialized
INFO - 2022-07-08 17:20:43 --> Output Class Initialized
INFO - 2022-07-08 17:20:43 --> Security Class Initialized
DEBUG - 2022-07-08 17:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-08 17:20:43 --> Input Class Initialized
INFO - 2022-07-08 17:20:43 --> Language Class Initialized
INFO - 2022-07-08 17:20:43 --> Loader Class Initialized
INFO - 2022-07-08 17:20:43 --> Helper loaded: url_helper
INFO - 2022-07-08 17:20:43 --> Helper loaded: file_helper
INFO - 2022-07-08 17:20:43 --> Database Driver Class Initialized
INFO - 2022-07-08 17:20:43 --> Email Class Initialized
DEBUG - 2022-07-08 17:20:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-08 17:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-08 17:20:43 --> Controller Class Initialized
INFO - 2022-07-08 17:20:43 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-08 17:20:43 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-08 17:20:43 --> Final output sent to browser
DEBUG - 2022-07-08 17:20:43 --> Total execution time: 0.0655
INFO - 2022-07-08 17:20:43 --> Config Class Initialized
INFO - 2022-07-08 17:20:43 --> Hooks Class Initialized
DEBUG - 2022-07-08 17:20:43 --> UTF-8 Support Enabled
INFO - 2022-07-08 17:20:43 --> Utf8 Class Initialized
INFO - 2022-07-08 17:20:43 --> URI Class Initialized
INFO - 2022-07-08 17:20:43 --> Router Class Initialized
INFO - 2022-07-08 17:20:43 --> Output Class Initialized
INFO - 2022-07-08 17:20:43 --> Security Class Initialized
DEBUG - 2022-07-08 17:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-08 17:20:43 --> Input Class Initialized
INFO - 2022-07-08 17:20:43 --> Language Class Initialized
INFO - 2022-07-08 17:20:43 --> Loader Class Initialized
INFO - 2022-07-08 17:20:43 --> Helper loaded: url_helper
INFO - 2022-07-08 17:20:43 --> Helper loaded: file_helper
INFO - 2022-07-08 17:20:43 --> Database Driver Class Initialized
INFO - 2022-07-08 17:20:43 --> Email Class Initialized
DEBUG - 2022-07-08 17:20:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-08 17:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-08 17:20:43 --> Controller Class Initialized
INFO - 2022-07-08 17:20:43 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-08 17:20:43 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-08 17:20:43 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-08 17:20:43 --> Final output sent to browser
DEBUG - 2022-07-08 17:20:43 --> Total execution time: 0.0297
INFO - 2022-07-08 17:38:50 --> Config Class Initialized
INFO - 2022-07-08 17:38:50 --> Hooks Class Initialized
DEBUG - 2022-07-08 17:38:50 --> UTF-8 Support Enabled
INFO - 2022-07-08 17:38:50 --> Utf8 Class Initialized
INFO - 2022-07-08 17:38:50 --> URI Class Initialized
INFO - 2022-07-08 17:38:50 --> Router Class Initialized
INFO - 2022-07-08 17:38:50 --> Output Class Initialized
INFO - 2022-07-08 17:38:50 --> Security Class Initialized
DEBUG - 2022-07-08 17:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-08 17:38:50 --> Input Class Initialized
INFO - 2022-07-08 17:38:50 --> Language Class Initialized
INFO - 2022-07-08 17:38:50 --> Loader Class Initialized
INFO - 2022-07-08 17:38:50 --> Helper loaded: url_helper
INFO - 2022-07-08 17:38:50 --> Helper loaded: file_helper
INFO - 2022-07-08 17:38:50 --> Database Driver Class Initialized
INFO - 2022-07-08 17:38:50 --> Email Class Initialized
DEBUG - 2022-07-08 17:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-08 17:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-08 17:38:50 --> Controller Class Initialized
INFO - 2022-07-08 17:38:50 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-08 17:38:50 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-08 17:38:50 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-08 17:38:50 --> Final output sent to browser
DEBUG - 2022-07-08 17:38:50 --> Total execution time: 0.0268
INFO - 2022-07-08 17:41:17 --> Config Class Initialized
INFO - 2022-07-08 17:41:17 --> Hooks Class Initialized
DEBUG - 2022-07-08 17:41:17 --> UTF-8 Support Enabled
INFO - 2022-07-08 17:41:17 --> Utf8 Class Initialized
INFO - 2022-07-08 17:41:17 --> URI Class Initialized
INFO - 2022-07-08 17:41:17 --> Router Class Initialized
INFO - 2022-07-08 17:41:17 --> Output Class Initialized
INFO - 2022-07-08 17:41:17 --> Security Class Initialized
DEBUG - 2022-07-08 17:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-08 17:41:17 --> Input Class Initialized
INFO - 2022-07-08 17:41:17 --> Language Class Initialized
INFO - 2022-07-08 17:41:17 --> Loader Class Initialized
INFO - 2022-07-08 17:41:17 --> Helper loaded: url_helper
INFO - 2022-07-08 17:41:17 --> Helper loaded: file_helper
INFO - 2022-07-08 17:41:17 --> Database Driver Class Initialized
INFO - 2022-07-08 17:41:17 --> Email Class Initialized
DEBUG - 2022-07-08 17:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-08 17:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-08 17:41:17 --> Controller Class Initialized
INFO - 2022-07-08 17:41:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-08 17:41:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-08 17:41:17 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-08 17:41:17 --> Final output sent to browser
DEBUG - 2022-07-08 17:41:17 --> Total execution time: 0.0263
INFO - 2022-07-08 17:41:18 --> Config Class Initialized
INFO - 2022-07-08 17:41:18 --> Hooks Class Initialized
DEBUG - 2022-07-08 17:41:18 --> UTF-8 Support Enabled
INFO - 2022-07-08 17:41:18 --> Utf8 Class Initialized
INFO - 2022-07-08 17:41:18 --> URI Class Initialized
INFO - 2022-07-08 17:41:18 --> Router Class Initialized
INFO - 2022-07-08 17:41:18 --> Output Class Initialized
INFO - 2022-07-08 17:41:18 --> Security Class Initialized
DEBUG - 2022-07-08 17:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-08 17:41:18 --> Input Class Initialized
INFO - 2022-07-08 17:41:18 --> Language Class Initialized
INFO - 2022-07-08 17:41:18 --> Loader Class Initialized
INFO - 2022-07-08 17:41:18 --> Helper loaded: url_helper
INFO - 2022-07-08 17:41:18 --> Helper loaded: file_helper
INFO - 2022-07-08 17:41:18 --> Database Driver Class Initialized
INFO - 2022-07-08 17:41:18 --> Email Class Initialized
DEBUG - 2022-07-08 17:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-08 17:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-08 17:41:18 --> Controller Class Initialized
INFO - 2022-07-08 17:41:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-08 17:41:18 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-08 17:41:18 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-08 17:41:18 --> Final output sent to browser
DEBUG - 2022-07-08 17:41:18 --> Total execution time: 0.0943
INFO - 2022-07-08 18:40:28 --> Config Class Initialized
INFO - 2022-07-08 18:40:28 --> Hooks Class Initialized
DEBUG - 2022-07-08 18:40:28 --> UTF-8 Support Enabled
INFO - 2022-07-08 18:40:28 --> Utf8 Class Initialized
INFO - 2022-07-08 18:40:28 --> URI Class Initialized
INFO - 2022-07-08 18:40:28 --> Router Class Initialized
INFO - 2022-07-08 18:40:28 --> Output Class Initialized
INFO - 2022-07-08 18:40:28 --> Security Class Initialized
DEBUG - 2022-07-08 18:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-08 18:40:28 --> Input Class Initialized
INFO - 2022-07-08 18:40:28 --> Language Class Initialized
INFO - 2022-07-08 18:40:28 --> Loader Class Initialized
INFO - 2022-07-08 18:40:28 --> Helper loaded: url_helper
INFO - 2022-07-08 18:40:28 --> Helper loaded: file_helper
INFO - 2022-07-08 18:40:28 --> Database Driver Class Initialized
INFO - 2022-07-08 18:40:28 --> Email Class Initialized
DEBUG - 2022-07-08 18:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-08 18:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-08 18:40:28 --> Controller Class Initialized
INFO - 2022-07-08 18:40:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-08 18:40:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-08 18:40:28 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-08 18:40:28 --> Final output sent to browser
DEBUG - 2022-07-08 18:40:28 --> Total execution time: 0.1874
