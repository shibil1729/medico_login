<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-07-18 04:54:29 --> Config Class Initialized
INFO - 2022-07-18 04:54:29 --> Hooks Class Initialized
DEBUG - 2022-07-18 04:54:29 --> UTF-8 Support Enabled
INFO - 2022-07-18 04:54:29 --> Utf8 Class Initialized
INFO - 2022-07-18 04:54:29 --> URI Class Initialized
INFO - 2022-07-18 04:54:29 --> Router Class Initialized
INFO - 2022-07-18 04:54:29 --> Output Class Initialized
INFO - 2022-07-18 04:54:29 --> Security Class Initialized
DEBUG - 2022-07-18 04:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 04:54:29 --> Input Class Initialized
INFO - 2022-07-18 04:54:29 --> Language Class Initialized
INFO - 2022-07-18 04:54:29 --> Loader Class Initialized
INFO - 2022-07-18 04:54:29 --> Helper loaded: url_helper
INFO - 2022-07-18 04:54:29 --> Helper loaded: file_helper
INFO - 2022-07-18 04:54:29 --> Database Driver Class Initialized
INFO - 2022-07-18 04:54:29 --> Email Class Initialized
DEBUG - 2022-07-18 04:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 04:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 04:54:29 --> Controller Class Initialized
INFO - 2022-07-18 04:54:29 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 04:54:29 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 10:24:29 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-07-18 10:24:29 --> Final output sent to browser
DEBUG - 2022-07-18 10:24:29 --> Total execution time: 0.4731
INFO - 2022-07-18 04:54:34 --> Config Class Initialized
INFO - 2022-07-18 04:54:34 --> Hooks Class Initialized
DEBUG - 2022-07-18 04:54:34 --> UTF-8 Support Enabled
INFO - 2022-07-18 04:54:34 --> Utf8 Class Initialized
INFO - 2022-07-18 04:54:34 --> URI Class Initialized
INFO - 2022-07-18 04:54:34 --> Router Class Initialized
INFO - 2022-07-18 04:54:34 --> Output Class Initialized
INFO - 2022-07-18 04:54:34 --> Security Class Initialized
DEBUG - 2022-07-18 04:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 04:54:34 --> Input Class Initialized
INFO - 2022-07-18 04:54:34 --> Language Class Initialized
INFO - 2022-07-18 04:54:34 --> Loader Class Initialized
INFO - 2022-07-18 04:54:34 --> Helper loaded: url_helper
INFO - 2022-07-18 04:54:34 --> Helper loaded: file_helper
INFO - 2022-07-18 04:54:34 --> Database Driver Class Initialized
INFO - 2022-07-18 04:54:35 --> Email Class Initialized
DEBUG - 2022-07-18 04:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 04:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 04:54:35 --> Controller Class Initialized
INFO - 2022-07-18 04:54:35 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 04:54:35 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 04:54:35 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-18 04:54:35 --> Final output sent to browser
DEBUG - 2022-07-18 04:54:35 --> Total execution time: 0.0301
INFO - 2022-07-18 04:58:31 --> Config Class Initialized
INFO - 2022-07-18 04:58:31 --> Hooks Class Initialized
DEBUG - 2022-07-18 04:58:31 --> UTF-8 Support Enabled
INFO - 2022-07-18 04:58:31 --> Utf8 Class Initialized
INFO - 2022-07-18 04:58:31 --> URI Class Initialized
INFO - 2022-07-18 04:58:31 --> Router Class Initialized
INFO - 2022-07-18 04:58:31 --> Output Class Initialized
INFO - 2022-07-18 04:58:31 --> Security Class Initialized
DEBUG - 2022-07-18 04:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 04:58:31 --> Input Class Initialized
INFO - 2022-07-18 04:58:31 --> Language Class Initialized
INFO - 2022-07-18 04:58:31 --> Loader Class Initialized
INFO - 2022-07-18 04:58:31 --> Helper loaded: url_helper
INFO - 2022-07-18 04:58:31 --> Helper loaded: file_helper
INFO - 2022-07-18 04:58:31 --> Database Driver Class Initialized
INFO - 2022-07-18 04:58:31 --> Email Class Initialized
DEBUG - 2022-07-18 04:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 04:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 04:58:31 --> Controller Class Initialized
INFO - 2022-07-18 04:58:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 04:58:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 04:58:31 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 520
ERROR - 2022-07-18 04:58:31 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 528
ERROR - 2022-07-18 04:58:31 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 598
ERROR - 2022-07-18 04:58:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 598
ERROR - 2022-07-18 04:58:31 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 616
ERROR - 2022-07-18 04:58:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 616
ERROR - 2022-07-18 04:58:31 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 634
ERROR - 2022-07-18 04:58:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 634
INFO - 2022-07-18 04:58:31 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 04:58:31 --> Final output sent to browser
DEBUG - 2022-07-18 04:58:31 --> Total execution time: 0.2012
INFO - 2022-07-18 04:58:34 --> Config Class Initialized
INFO - 2022-07-18 04:58:34 --> Hooks Class Initialized
DEBUG - 2022-07-18 04:58:34 --> UTF-8 Support Enabled
INFO - 2022-07-18 04:58:34 --> Utf8 Class Initialized
INFO - 2022-07-18 04:58:34 --> URI Class Initialized
INFO - 2022-07-18 04:58:34 --> Router Class Initialized
INFO - 2022-07-18 04:58:34 --> Output Class Initialized
INFO - 2022-07-18 04:58:34 --> Security Class Initialized
DEBUG - 2022-07-18 04:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 04:58:34 --> Input Class Initialized
INFO - 2022-07-18 04:58:34 --> Language Class Initialized
INFO - 2022-07-18 04:58:34 --> Loader Class Initialized
INFO - 2022-07-18 04:58:34 --> Helper loaded: url_helper
INFO - 2022-07-18 04:58:34 --> Helper loaded: file_helper
INFO - 2022-07-18 04:58:34 --> Database Driver Class Initialized
INFO - 2022-07-18 04:58:34 --> Email Class Initialized
DEBUG - 2022-07-18 04:58:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 04:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 04:58:34 --> Controller Class Initialized
INFO - 2022-07-18 04:58:34 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 04:58:34 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 10:28:34 --> Final output sent to browser
DEBUG - 2022-07-18 10:28:34 --> Total execution time: 0.3124
INFO - 2022-07-18 04:58:36 --> Config Class Initialized
INFO - 2022-07-18 04:58:36 --> Hooks Class Initialized
DEBUG - 2022-07-18 04:58:36 --> UTF-8 Support Enabled
INFO - 2022-07-18 04:58:36 --> Utf8 Class Initialized
INFO - 2022-07-18 04:58:36 --> URI Class Initialized
INFO - 2022-07-18 04:58:36 --> Router Class Initialized
INFO - 2022-07-18 04:58:36 --> Output Class Initialized
INFO - 2022-07-18 04:58:36 --> Security Class Initialized
DEBUG - 2022-07-18 04:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 04:58:36 --> Input Class Initialized
INFO - 2022-07-18 04:58:36 --> Language Class Initialized
INFO - 2022-07-18 04:58:36 --> Loader Class Initialized
INFO - 2022-07-18 04:58:36 --> Helper loaded: url_helper
INFO - 2022-07-18 04:58:36 --> Helper loaded: file_helper
INFO - 2022-07-18 04:58:36 --> Database Driver Class Initialized
INFO - 2022-07-18 04:58:36 --> Email Class Initialized
DEBUG - 2022-07-18 04:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 04:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 04:58:36 --> Controller Class Initialized
INFO - 2022-07-18 04:58:36 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 04:58:36 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 04:58:36 --> Final output sent to browser
DEBUG - 2022-07-18 04:58:36 --> Total execution time: 0.0433
INFO - 2022-07-18 04:58:38 --> Config Class Initialized
INFO - 2022-07-18 04:58:38 --> Hooks Class Initialized
DEBUG - 2022-07-18 04:58:38 --> UTF-8 Support Enabled
INFO - 2022-07-18 04:58:38 --> Utf8 Class Initialized
INFO - 2022-07-18 04:58:38 --> URI Class Initialized
INFO - 2022-07-18 04:58:38 --> Router Class Initialized
INFO - 2022-07-18 04:58:38 --> Output Class Initialized
INFO - 2022-07-18 04:58:38 --> Security Class Initialized
DEBUG - 2022-07-18 04:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 04:58:38 --> Input Class Initialized
INFO - 2022-07-18 04:58:38 --> Language Class Initialized
INFO - 2022-07-18 04:58:38 --> Loader Class Initialized
INFO - 2022-07-18 04:58:38 --> Helper loaded: url_helper
INFO - 2022-07-18 04:58:38 --> Helper loaded: file_helper
INFO - 2022-07-18 04:58:38 --> Database Driver Class Initialized
INFO - 2022-07-18 04:58:38 --> Email Class Initialized
DEBUG - 2022-07-18 04:58:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 04:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 04:58:38 --> Controller Class Initialized
INFO - 2022-07-18 04:58:38 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 04:58:38 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 10:28:38 --> Final output sent to browser
DEBUG - 2022-07-18 10:28:38 --> Total execution time: 0.2669
INFO - 2022-07-18 04:58:39 --> Config Class Initialized
INFO - 2022-07-18 04:58:39 --> Hooks Class Initialized
DEBUG - 2022-07-18 04:58:39 --> UTF-8 Support Enabled
INFO - 2022-07-18 04:58:39 --> Utf8 Class Initialized
INFO - 2022-07-18 04:58:39 --> URI Class Initialized
INFO - 2022-07-18 04:58:39 --> Router Class Initialized
INFO - 2022-07-18 04:58:39 --> Output Class Initialized
INFO - 2022-07-18 04:58:39 --> Security Class Initialized
DEBUG - 2022-07-18 04:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 04:58:39 --> Input Class Initialized
INFO - 2022-07-18 04:58:39 --> Language Class Initialized
INFO - 2022-07-18 04:58:39 --> Loader Class Initialized
INFO - 2022-07-18 04:58:39 --> Helper loaded: url_helper
INFO - 2022-07-18 04:58:39 --> Helper loaded: file_helper
INFO - 2022-07-18 04:58:39 --> Database Driver Class Initialized
INFO - 2022-07-18 04:58:39 --> Email Class Initialized
DEBUG - 2022-07-18 04:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 04:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 04:58:39 --> Controller Class Initialized
INFO - 2022-07-18 04:58:39 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 04:58:39 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 04:58:39 --> Final output sent to browser
DEBUG - 2022-07-18 04:58:39 --> Total execution time: 0.0653
INFO - 2022-07-18 04:59:44 --> Config Class Initialized
INFO - 2022-07-18 04:59:44 --> Hooks Class Initialized
DEBUG - 2022-07-18 04:59:44 --> UTF-8 Support Enabled
INFO - 2022-07-18 04:59:44 --> Utf8 Class Initialized
INFO - 2022-07-18 04:59:44 --> URI Class Initialized
INFO - 2022-07-18 04:59:44 --> Router Class Initialized
INFO - 2022-07-18 04:59:44 --> Output Class Initialized
INFO - 2022-07-18 04:59:44 --> Security Class Initialized
DEBUG - 2022-07-18 04:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 04:59:44 --> Input Class Initialized
INFO - 2022-07-18 04:59:44 --> Language Class Initialized
INFO - 2022-07-18 04:59:44 --> Loader Class Initialized
INFO - 2022-07-18 04:59:44 --> Helper loaded: url_helper
INFO - 2022-07-18 04:59:44 --> Helper loaded: file_helper
INFO - 2022-07-18 04:59:44 --> Database Driver Class Initialized
INFO - 2022-07-18 04:59:44 --> Email Class Initialized
DEBUG - 2022-07-18 04:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 04:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 04:59:44 --> Controller Class Initialized
INFO - 2022-07-18 04:59:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 04:59:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 04:59:44 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 520
ERROR - 2022-07-18 04:59:44 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 528
ERROR - 2022-07-18 04:59:44 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 598
ERROR - 2022-07-18 04:59:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 598
ERROR - 2022-07-18 04:59:44 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 616
ERROR - 2022-07-18 04:59:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 616
ERROR - 2022-07-18 04:59:44 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 634
ERROR - 2022-07-18 04:59:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 634
INFO - 2022-07-18 04:59:44 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 04:59:44 --> Final output sent to browser
DEBUG - 2022-07-18 04:59:44 --> Total execution time: 0.1838
INFO - 2022-07-18 04:59:47 --> Config Class Initialized
INFO - 2022-07-18 04:59:47 --> Hooks Class Initialized
DEBUG - 2022-07-18 04:59:47 --> UTF-8 Support Enabled
INFO - 2022-07-18 04:59:47 --> Utf8 Class Initialized
INFO - 2022-07-18 04:59:47 --> URI Class Initialized
INFO - 2022-07-18 04:59:47 --> Router Class Initialized
INFO - 2022-07-18 04:59:47 --> Output Class Initialized
INFO - 2022-07-18 04:59:47 --> Security Class Initialized
DEBUG - 2022-07-18 04:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 04:59:47 --> Input Class Initialized
INFO - 2022-07-18 04:59:47 --> Language Class Initialized
INFO - 2022-07-18 04:59:47 --> Loader Class Initialized
INFO - 2022-07-18 04:59:47 --> Helper loaded: url_helper
INFO - 2022-07-18 04:59:47 --> Helper loaded: file_helper
INFO - 2022-07-18 04:59:47 --> Database Driver Class Initialized
INFO - 2022-07-18 04:59:47 --> Email Class Initialized
DEBUG - 2022-07-18 04:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 04:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 04:59:47 --> Controller Class Initialized
INFO - 2022-07-18 04:59:47 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 04:59:47 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 10:29:47 --> Final output sent to browser
DEBUG - 2022-07-18 10:29:47 --> Total execution time: 0.0417
INFO - 2022-07-18 04:59:48 --> Config Class Initialized
INFO - 2022-07-18 04:59:48 --> Hooks Class Initialized
DEBUG - 2022-07-18 04:59:48 --> UTF-8 Support Enabled
INFO - 2022-07-18 04:59:48 --> Utf8 Class Initialized
INFO - 2022-07-18 04:59:48 --> URI Class Initialized
INFO - 2022-07-18 04:59:48 --> Router Class Initialized
INFO - 2022-07-18 04:59:48 --> Output Class Initialized
INFO - 2022-07-18 04:59:48 --> Security Class Initialized
DEBUG - 2022-07-18 04:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 04:59:48 --> Input Class Initialized
INFO - 2022-07-18 04:59:48 --> Language Class Initialized
INFO - 2022-07-18 04:59:48 --> Loader Class Initialized
INFO - 2022-07-18 04:59:48 --> Helper loaded: url_helper
INFO - 2022-07-18 04:59:48 --> Helper loaded: file_helper
INFO - 2022-07-18 04:59:48 --> Database Driver Class Initialized
INFO - 2022-07-18 04:59:48 --> Email Class Initialized
DEBUG - 2022-07-18 04:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 04:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 04:59:48 --> Controller Class Initialized
INFO - 2022-07-18 04:59:48 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 04:59:48 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 04:59:48 --> Final output sent to browser
DEBUG - 2022-07-18 04:59:48 --> Total execution time: 0.1163
INFO - 2022-07-18 04:59:52 --> Config Class Initialized
INFO - 2022-07-18 04:59:52 --> Hooks Class Initialized
DEBUG - 2022-07-18 04:59:52 --> UTF-8 Support Enabled
INFO - 2022-07-18 04:59:52 --> Utf8 Class Initialized
INFO - 2022-07-18 04:59:52 --> URI Class Initialized
INFO - 2022-07-18 04:59:52 --> Router Class Initialized
INFO - 2022-07-18 04:59:52 --> Output Class Initialized
INFO - 2022-07-18 04:59:52 --> Security Class Initialized
DEBUG - 2022-07-18 04:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 04:59:52 --> Input Class Initialized
INFO - 2022-07-18 04:59:52 --> Language Class Initialized
INFO - 2022-07-18 04:59:52 --> Loader Class Initialized
INFO - 2022-07-18 04:59:52 --> Helper loaded: url_helper
INFO - 2022-07-18 04:59:52 --> Helper loaded: file_helper
INFO - 2022-07-18 04:59:52 --> Database Driver Class Initialized
INFO - 2022-07-18 04:59:52 --> Email Class Initialized
DEBUG - 2022-07-18 04:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 04:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 04:59:52 --> Controller Class Initialized
INFO - 2022-07-18 04:59:52 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 04:59:52 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 10:29:52 --> Final output sent to browser
DEBUG - 2022-07-18 10:29:52 --> Total execution time: 0.1559
INFO - 2022-07-18 04:59:54 --> Config Class Initialized
INFO - 2022-07-18 04:59:54 --> Hooks Class Initialized
DEBUG - 2022-07-18 04:59:54 --> UTF-8 Support Enabled
INFO - 2022-07-18 04:59:54 --> Utf8 Class Initialized
INFO - 2022-07-18 04:59:54 --> URI Class Initialized
INFO - 2022-07-18 04:59:54 --> Router Class Initialized
INFO - 2022-07-18 04:59:54 --> Output Class Initialized
INFO - 2022-07-18 04:59:54 --> Security Class Initialized
DEBUG - 2022-07-18 04:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 04:59:54 --> Input Class Initialized
INFO - 2022-07-18 04:59:54 --> Language Class Initialized
INFO - 2022-07-18 04:59:54 --> Loader Class Initialized
INFO - 2022-07-18 04:59:54 --> Helper loaded: url_helper
INFO - 2022-07-18 04:59:54 --> Helper loaded: file_helper
INFO - 2022-07-18 04:59:54 --> Database Driver Class Initialized
INFO - 2022-07-18 04:59:54 --> Email Class Initialized
DEBUG - 2022-07-18 04:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 04:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 04:59:54 --> Controller Class Initialized
INFO - 2022-07-18 04:59:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 04:59:54 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 04:59:54 --> Final output sent to browser
DEBUG - 2022-07-18 04:59:54 --> Total execution time: 0.1129
INFO - 2022-07-18 04:59:54 --> Config Class Initialized
INFO - 2022-07-18 04:59:54 --> Hooks Class Initialized
DEBUG - 2022-07-18 04:59:54 --> UTF-8 Support Enabled
INFO - 2022-07-18 04:59:54 --> Utf8 Class Initialized
INFO - 2022-07-18 04:59:54 --> URI Class Initialized
INFO - 2022-07-18 04:59:54 --> Router Class Initialized
INFO - 2022-07-18 04:59:54 --> Output Class Initialized
INFO - 2022-07-18 04:59:54 --> Security Class Initialized
DEBUG - 2022-07-18 04:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 04:59:54 --> Input Class Initialized
INFO - 2022-07-18 04:59:54 --> Language Class Initialized
INFO - 2022-07-18 04:59:54 --> Loader Class Initialized
INFO - 2022-07-18 04:59:54 --> Helper loaded: url_helper
INFO - 2022-07-18 04:59:54 --> Helper loaded: file_helper
INFO - 2022-07-18 04:59:54 --> Database Driver Class Initialized
INFO - 2022-07-18 04:59:54 --> Email Class Initialized
DEBUG - 2022-07-18 04:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 04:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 04:59:54 --> Controller Class Initialized
INFO - 2022-07-18 04:59:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 04:59:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 04:59:54 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 520
ERROR - 2022-07-18 04:59:54 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 528
ERROR - 2022-07-18 04:59:54 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 598
ERROR - 2022-07-18 04:59:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 598
ERROR - 2022-07-18 04:59:54 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 616
ERROR - 2022-07-18 04:59:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 616
ERROR - 2022-07-18 04:59:54 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 634
ERROR - 2022-07-18 04:59:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 634
INFO - 2022-07-18 04:59:54 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 04:59:54 --> Final output sent to browser
DEBUG - 2022-07-18 04:59:54 --> Total execution time: 0.0314
INFO - 2022-07-18 05:01:52 --> Config Class Initialized
INFO - 2022-07-18 05:01:52 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:01:52 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:01:52 --> Utf8 Class Initialized
INFO - 2022-07-18 05:01:52 --> URI Class Initialized
INFO - 2022-07-18 05:01:52 --> Router Class Initialized
INFO - 2022-07-18 05:01:52 --> Output Class Initialized
INFO - 2022-07-18 05:01:52 --> Security Class Initialized
DEBUG - 2022-07-18 05:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:01:52 --> Input Class Initialized
INFO - 2022-07-18 05:01:52 --> Language Class Initialized
INFO - 2022-07-18 05:01:52 --> Loader Class Initialized
INFO - 2022-07-18 05:01:52 --> Helper loaded: url_helper
INFO - 2022-07-18 05:01:52 --> Helper loaded: file_helper
INFO - 2022-07-18 05:01:52 --> Database Driver Class Initialized
INFO - 2022-07-18 05:01:52 --> Email Class Initialized
DEBUG - 2022-07-18 05:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:01:52 --> Controller Class Initialized
INFO - 2022-07-18 05:01:52 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:01:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 05:01:52 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 520
ERROR - 2022-07-18 05:01:52 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 528
ERROR - 2022-07-18 05:01:52 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 598
ERROR - 2022-07-18 05:01:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 598
ERROR - 2022-07-18 05:01:52 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 616
ERROR - 2022-07-18 05:01:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 616
ERROR - 2022-07-18 05:01:52 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 634
ERROR - 2022-07-18 05:01:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 634
INFO - 2022-07-18 05:01:52 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 05:01:52 --> Final output sent to browser
DEBUG - 2022-07-18 05:01:52 --> Total execution time: 0.0234
INFO - 2022-07-18 05:01:54 --> Config Class Initialized
INFO - 2022-07-18 05:01:54 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:01:54 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:01:54 --> Utf8 Class Initialized
INFO - 2022-07-18 05:01:54 --> URI Class Initialized
INFO - 2022-07-18 05:01:54 --> Router Class Initialized
INFO - 2022-07-18 05:01:54 --> Output Class Initialized
INFO - 2022-07-18 05:01:54 --> Security Class Initialized
DEBUG - 2022-07-18 05:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:01:54 --> Input Class Initialized
INFO - 2022-07-18 05:01:54 --> Language Class Initialized
INFO - 2022-07-18 05:01:54 --> Loader Class Initialized
INFO - 2022-07-18 05:01:54 --> Helper loaded: url_helper
INFO - 2022-07-18 05:01:54 --> Helper loaded: file_helper
INFO - 2022-07-18 05:01:54 --> Database Driver Class Initialized
INFO - 2022-07-18 05:01:54 --> Email Class Initialized
DEBUG - 2022-07-18 05:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:01:54 --> Controller Class Initialized
INFO - 2022-07-18 05:01:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:01:54 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 10:31:54 --> Final output sent to browser
DEBUG - 2022-07-18 10:31:54 --> Total execution time: 0.2134
INFO - 2022-07-18 05:01:56 --> Config Class Initialized
INFO - 2022-07-18 05:01:56 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:01:56 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:01:56 --> Utf8 Class Initialized
INFO - 2022-07-18 05:01:56 --> URI Class Initialized
INFO - 2022-07-18 05:01:56 --> Router Class Initialized
INFO - 2022-07-18 05:01:56 --> Output Class Initialized
INFO - 2022-07-18 05:01:56 --> Security Class Initialized
DEBUG - 2022-07-18 05:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:01:56 --> Input Class Initialized
INFO - 2022-07-18 05:01:56 --> Language Class Initialized
INFO - 2022-07-18 05:01:56 --> Loader Class Initialized
INFO - 2022-07-18 05:01:56 --> Helper loaded: url_helper
INFO - 2022-07-18 05:01:56 --> Helper loaded: file_helper
INFO - 2022-07-18 05:01:56 --> Database Driver Class Initialized
INFO - 2022-07-18 05:01:56 --> Email Class Initialized
DEBUG - 2022-07-18 05:01:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:01:56 --> Controller Class Initialized
INFO - 2022-07-18 05:01:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:01:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:01:56 --> Final output sent to browser
DEBUG - 2022-07-18 05:01:56 --> Total execution time: 0.1111
INFO - 2022-07-18 05:01:58 --> Config Class Initialized
INFO - 2022-07-18 05:01:58 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:01:58 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:01:58 --> Utf8 Class Initialized
INFO - 2022-07-18 05:01:58 --> URI Class Initialized
INFO - 2022-07-18 05:01:58 --> Router Class Initialized
INFO - 2022-07-18 05:01:58 --> Output Class Initialized
INFO - 2022-07-18 05:01:58 --> Security Class Initialized
DEBUG - 2022-07-18 05:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:01:58 --> Input Class Initialized
INFO - 2022-07-18 05:01:58 --> Language Class Initialized
INFO - 2022-07-18 05:01:58 --> Loader Class Initialized
INFO - 2022-07-18 05:01:58 --> Helper loaded: url_helper
INFO - 2022-07-18 05:01:58 --> Helper loaded: file_helper
INFO - 2022-07-18 05:01:58 --> Database Driver Class Initialized
INFO - 2022-07-18 05:01:59 --> Email Class Initialized
DEBUG - 2022-07-18 05:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:01:59 --> Controller Class Initialized
INFO - 2022-07-18 05:01:59 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:01:59 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 10:31:59 --> Final output sent to browser
DEBUG - 2022-07-18 10:31:59 --> Total execution time: 0.1605
INFO - 2022-07-18 05:02:00 --> Config Class Initialized
INFO - 2022-07-18 05:02:00 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:02:00 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:02:00 --> Utf8 Class Initialized
INFO - 2022-07-18 05:02:00 --> URI Class Initialized
INFO - 2022-07-18 05:02:00 --> Router Class Initialized
INFO - 2022-07-18 05:02:00 --> Output Class Initialized
INFO - 2022-07-18 05:02:00 --> Security Class Initialized
DEBUG - 2022-07-18 05:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:02:00 --> Input Class Initialized
INFO - 2022-07-18 05:02:00 --> Language Class Initialized
INFO - 2022-07-18 05:02:00 --> Loader Class Initialized
INFO - 2022-07-18 05:02:00 --> Helper loaded: url_helper
INFO - 2022-07-18 05:02:00 --> Helper loaded: file_helper
INFO - 2022-07-18 05:02:00 --> Database Driver Class Initialized
INFO - 2022-07-18 05:02:00 --> Email Class Initialized
DEBUG - 2022-07-18 05:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:02:00 --> Controller Class Initialized
INFO - 2022-07-18 05:02:00 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:02:00 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:02:00 --> Final output sent to browser
DEBUG - 2022-07-18 05:02:00 --> Total execution time: 0.1176
INFO - 2022-07-18 05:02:01 --> Config Class Initialized
INFO - 2022-07-18 05:02:01 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:02:01 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:02:01 --> Utf8 Class Initialized
INFO - 2022-07-18 05:02:01 --> URI Class Initialized
INFO - 2022-07-18 05:02:01 --> Router Class Initialized
INFO - 2022-07-18 05:02:01 --> Output Class Initialized
INFO - 2022-07-18 05:02:01 --> Security Class Initialized
DEBUG - 2022-07-18 05:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:02:01 --> Input Class Initialized
INFO - 2022-07-18 05:02:01 --> Language Class Initialized
INFO - 2022-07-18 05:02:01 --> Loader Class Initialized
INFO - 2022-07-18 05:02:01 --> Helper loaded: url_helper
INFO - 2022-07-18 05:02:01 --> Helper loaded: file_helper
INFO - 2022-07-18 05:02:01 --> Database Driver Class Initialized
INFO - 2022-07-18 05:02:01 --> Email Class Initialized
DEBUG - 2022-07-18 05:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:02:01 --> Controller Class Initialized
INFO - 2022-07-18 05:02:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:02:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 10:32:01 --> Final output sent to browser
DEBUG - 2022-07-18 10:32:01 --> Total execution time: 0.1297
INFO - 2022-07-18 05:02:02 --> Config Class Initialized
INFO - 2022-07-18 05:02:02 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:02:02 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:02:02 --> Utf8 Class Initialized
INFO - 2022-07-18 05:02:02 --> URI Class Initialized
INFO - 2022-07-18 05:02:02 --> Router Class Initialized
INFO - 2022-07-18 05:02:02 --> Output Class Initialized
INFO - 2022-07-18 05:02:02 --> Security Class Initialized
DEBUG - 2022-07-18 05:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:02:02 --> Input Class Initialized
INFO - 2022-07-18 05:02:02 --> Language Class Initialized
INFO - 2022-07-18 05:02:02 --> Loader Class Initialized
INFO - 2022-07-18 05:02:02 --> Helper loaded: url_helper
INFO - 2022-07-18 05:02:02 --> Helper loaded: file_helper
INFO - 2022-07-18 05:02:02 --> Database Driver Class Initialized
INFO - 2022-07-18 05:02:02 --> Email Class Initialized
DEBUG - 2022-07-18 05:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:02:02 --> Controller Class Initialized
INFO - 2022-07-18 05:02:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:02:02 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:02:02 --> Final output sent to browser
DEBUG - 2022-07-18 05:02:02 --> Total execution time: 0.0148
INFO - 2022-07-18 05:02:24 --> Config Class Initialized
INFO - 2022-07-18 05:02:24 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:02:24 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:02:24 --> Utf8 Class Initialized
INFO - 2022-07-18 05:02:24 --> URI Class Initialized
INFO - 2022-07-18 05:02:24 --> Router Class Initialized
INFO - 2022-07-18 05:02:24 --> Output Class Initialized
INFO - 2022-07-18 05:02:24 --> Security Class Initialized
DEBUG - 2022-07-18 05:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:02:24 --> Input Class Initialized
INFO - 2022-07-18 05:02:24 --> Language Class Initialized
INFO - 2022-07-18 05:02:24 --> Loader Class Initialized
INFO - 2022-07-18 05:02:24 --> Helper loaded: url_helper
INFO - 2022-07-18 05:02:24 --> Helper loaded: file_helper
INFO - 2022-07-18 05:02:24 --> Database Driver Class Initialized
INFO - 2022-07-18 05:02:24 --> Email Class Initialized
DEBUG - 2022-07-18 05:02:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:02:24 --> Controller Class Initialized
INFO - 2022-07-18 05:02:24 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:02:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 05:02:24 --> Severity: Notice --> Trying to get property 'td_tk' of non-object C:\wamp64\www\qr\application\controllers\Tokenctrl.php 493
DEBUG - 2022-07-18 10:32:24 --> insertedINSERT INTO `tokendetails` (`td_tk`, `td_cs`, `td_visited_date`, `td_est_time`) VALUES (1, 0, '2022-07-18', '05:30:00')
INFO - 2022-07-18 10:32:24 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-18 10:32:24 --> Final output sent to browser
DEBUG - 2022-07-18 10:32:24 --> Total execution time: 0.2058
INFO - 2022-07-18 05:02:57 --> Config Class Initialized
INFO - 2022-07-18 05:02:57 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:02:57 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:02:57 --> Utf8 Class Initialized
INFO - 2022-07-18 05:02:57 --> URI Class Initialized
INFO - 2022-07-18 05:02:57 --> Router Class Initialized
INFO - 2022-07-18 05:02:57 --> Output Class Initialized
INFO - 2022-07-18 05:02:57 --> Security Class Initialized
DEBUG - 2022-07-18 05:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:02:57 --> Input Class Initialized
INFO - 2022-07-18 05:02:57 --> Language Class Initialized
INFO - 2022-07-18 05:02:57 --> Loader Class Initialized
INFO - 2022-07-18 05:02:57 --> Helper loaded: url_helper
INFO - 2022-07-18 05:02:57 --> Helper loaded: file_helper
INFO - 2022-07-18 05:02:57 --> Database Driver Class Initialized
INFO - 2022-07-18 05:02:57 --> Email Class Initialized
DEBUG - 2022-07-18 05:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:02:57 --> Controller Class Initialized
INFO - 2022-07-18 05:02:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:02:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 05:02:57 --> Severity: Notice --> Trying to get property 'td_tk' of non-object C:\wamp64\www\qr\application\controllers\Tokenctrl.php 493
DEBUG - 2022-07-18 10:32:57 --> insertedINSERT INTO `tokendetails` (`td_tk`, `td_cs`, `td_visited_date`, `td_est_time`) VALUES (2, 0, '2022-07-18', '05:30:00')
INFO - 2022-07-18 10:32:57 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-18 10:32:57 --> Final output sent to browser
DEBUG - 2022-07-18 10:32:57 --> Total execution time: 0.3292
INFO - 2022-07-18 05:03:23 --> Config Class Initialized
INFO - 2022-07-18 05:03:23 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:03:23 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:03:23 --> Utf8 Class Initialized
INFO - 2022-07-18 05:03:23 --> URI Class Initialized
INFO - 2022-07-18 05:03:23 --> Router Class Initialized
INFO - 2022-07-18 05:03:23 --> Output Class Initialized
INFO - 2022-07-18 05:03:23 --> Security Class Initialized
DEBUG - 2022-07-18 05:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:03:23 --> Input Class Initialized
INFO - 2022-07-18 05:03:23 --> Language Class Initialized
INFO - 2022-07-18 05:03:23 --> Loader Class Initialized
INFO - 2022-07-18 05:03:23 --> Helper loaded: url_helper
INFO - 2022-07-18 05:03:23 --> Helper loaded: file_helper
INFO - 2022-07-18 05:03:23 --> Database Driver Class Initialized
INFO - 2022-07-18 05:03:23 --> Email Class Initialized
DEBUG - 2022-07-18 05:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:03:23 --> Controller Class Initialized
INFO - 2022-07-18 05:03:23 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:03:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 05:03:23 --> Severity: Notice --> Trying to get property 'td_tk' of non-object C:\wamp64\www\qr\application\controllers\Tokenctrl.php 493
DEBUG - 2022-07-18 10:33:23 --> insertedINSERT INTO `tokendetails` (`td_tk`, `td_cs`, `td_visited_date`, `td_est_time`) VALUES (3, 0, '2022-07-18', '05:30:00')
INFO - 2022-07-18 10:33:23 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-18 10:33:23 --> Final output sent to browser
DEBUG - 2022-07-18 10:33:23 --> Total execution time: 0.2975
INFO - 2022-07-18 05:03:34 --> Config Class Initialized
INFO - 2022-07-18 05:03:34 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:03:34 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:03:34 --> Utf8 Class Initialized
INFO - 2022-07-18 05:03:34 --> URI Class Initialized
INFO - 2022-07-18 05:03:34 --> Router Class Initialized
INFO - 2022-07-18 05:03:34 --> Output Class Initialized
INFO - 2022-07-18 05:03:34 --> Security Class Initialized
DEBUG - 2022-07-18 05:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:03:34 --> Input Class Initialized
INFO - 2022-07-18 05:03:34 --> Language Class Initialized
INFO - 2022-07-18 05:03:34 --> Loader Class Initialized
INFO - 2022-07-18 05:03:34 --> Helper loaded: url_helper
INFO - 2022-07-18 05:03:34 --> Helper loaded: file_helper
INFO - 2022-07-18 05:03:34 --> Database Driver Class Initialized
INFO - 2022-07-18 05:03:35 --> Email Class Initialized
DEBUG - 2022-07-18 05:03:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:03:35 --> Controller Class Initialized
INFO - 2022-07-18 05:03:35 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:03:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 05:03:35 --> Severity: Notice --> Trying to get property 'td_tk' of non-object C:\wamp64\www\qr\application\controllers\Tokenctrl.php 493
DEBUG - 2022-07-18 10:33:35 --> insertedINSERT INTO `tokendetails` (`td_tk`, `td_cs`, `td_visited_date`, `td_est_time`) VALUES (4, 0, '2022-07-18', '05:30:00')
INFO - 2022-07-18 10:33:35 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-18 10:33:35 --> Final output sent to browser
DEBUG - 2022-07-18 10:33:35 --> Total execution time: 0.2452
INFO - 2022-07-18 05:03:51 --> Config Class Initialized
INFO - 2022-07-18 05:03:51 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:03:51 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:03:51 --> Utf8 Class Initialized
INFO - 2022-07-18 05:03:51 --> URI Class Initialized
INFO - 2022-07-18 05:03:51 --> Router Class Initialized
INFO - 2022-07-18 05:03:51 --> Output Class Initialized
INFO - 2022-07-18 05:03:51 --> Security Class Initialized
DEBUG - 2022-07-18 05:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:03:51 --> Input Class Initialized
INFO - 2022-07-18 05:03:51 --> Language Class Initialized
INFO - 2022-07-18 05:03:51 --> Loader Class Initialized
INFO - 2022-07-18 05:03:51 --> Helper loaded: url_helper
INFO - 2022-07-18 05:03:51 --> Helper loaded: file_helper
INFO - 2022-07-18 05:03:51 --> Database Driver Class Initialized
INFO - 2022-07-18 05:03:51 --> Email Class Initialized
DEBUG - 2022-07-18 05:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:03:51 --> Controller Class Initialized
INFO - 2022-07-18 05:03:51 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:03:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 05:03:51 --> Severity: Notice --> Trying to get property 'td_tk' of non-object C:\wamp64\www\qr\application\controllers\Tokenctrl.php 493
DEBUG - 2022-07-18 10:33:51 --> insertedINSERT INTO `tokendetails` (`td_tk`, `td_cs`, `td_visited_date`, `td_est_time`) VALUES (5, 0, '2022-07-18', '05:30:00')
INFO - 2022-07-18 10:33:51 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-18 10:33:51 --> Final output sent to browser
DEBUG - 2022-07-18 10:33:51 --> Total execution time: 0.4582
INFO - 2022-07-18 05:03:58 --> Config Class Initialized
INFO - 2022-07-18 05:03:58 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:03:58 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:03:58 --> Utf8 Class Initialized
INFO - 2022-07-18 05:03:58 --> URI Class Initialized
INFO - 2022-07-18 05:03:58 --> Router Class Initialized
INFO - 2022-07-18 05:03:58 --> Output Class Initialized
INFO - 2022-07-18 05:03:58 --> Security Class Initialized
DEBUG - 2022-07-18 05:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:03:58 --> Input Class Initialized
INFO - 2022-07-18 05:03:58 --> Language Class Initialized
INFO - 2022-07-18 05:03:58 --> Loader Class Initialized
INFO - 2022-07-18 05:03:58 --> Helper loaded: url_helper
INFO - 2022-07-18 05:03:58 --> Helper loaded: file_helper
INFO - 2022-07-18 05:03:58 --> Database Driver Class Initialized
INFO - 2022-07-18 05:03:58 --> Email Class Initialized
DEBUG - 2022-07-18 05:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:03:58 --> Controller Class Initialized
INFO - 2022-07-18 05:03:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:03:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 05:03:58 --> Severity: Notice --> Trying to get property 'td_tk' of non-object C:\wamp64\www\qr\application\controllers\Tokenctrl.php 493
DEBUG - 2022-07-18 10:33:58 --> insertedINSERT INTO `tokendetails` (`td_tk`, `td_cs`, `td_visited_date`, `td_est_time`) VALUES (6, 0, '2022-07-18', '05:30:00')
INFO - 2022-07-18 10:33:58 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-18 10:33:58 --> Final output sent to browser
DEBUG - 2022-07-18 10:33:58 --> Total execution time: 0.2176
INFO - 2022-07-18 05:04:51 --> Config Class Initialized
INFO - 2022-07-18 05:04:51 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:04:51 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:04:51 --> Utf8 Class Initialized
INFO - 2022-07-18 05:04:51 --> URI Class Initialized
INFO - 2022-07-18 05:04:51 --> Router Class Initialized
INFO - 2022-07-18 05:04:51 --> Output Class Initialized
INFO - 2022-07-18 05:04:51 --> Security Class Initialized
DEBUG - 2022-07-18 05:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:04:51 --> Input Class Initialized
INFO - 2022-07-18 05:04:51 --> Language Class Initialized
INFO - 2022-07-18 05:04:51 --> Loader Class Initialized
INFO - 2022-07-18 05:04:51 --> Helper loaded: url_helper
INFO - 2022-07-18 05:04:51 --> Helper loaded: file_helper
INFO - 2022-07-18 05:04:51 --> Database Driver Class Initialized
INFO - 2022-07-18 05:04:51 --> Email Class Initialized
DEBUG - 2022-07-18 05:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:04:51 --> Controller Class Initialized
INFO - 2022-07-18 05:04:51 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:04:51 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:04:51 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-18 05:04:51 --> Final output sent to browser
DEBUG - 2022-07-18 05:04:51 --> Total execution time: 0.0206
INFO - 2022-07-18 05:04:52 --> Config Class Initialized
INFO - 2022-07-18 05:04:52 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:04:52 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:04:52 --> Utf8 Class Initialized
INFO - 2022-07-18 05:04:52 --> URI Class Initialized
INFO - 2022-07-18 05:04:52 --> Router Class Initialized
INFO - 2022-07-18 05:04:52 --> Output Class Initialized
INFO - 2022-07-18 05:04:52 --> Security Class Initialized
DEBUG - 2022-07-18 05:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:04:52 --> Input Class Initialized
INFO - 2022-07-18 05:04:52 --> Language Class Initialized
INFO - 2022-07-18 05:04:52 --> Loader Class Initialized
INFO - 2022-07-18 05:04:52 --> Helper loaded: url_helper
INFO - 2022-07-18 05:04:52 --> Helper loaded: file_helper
INFO - 2022-07-18 05:04:52 --> Database Driver Class Initialized
INFO - 2022-07-18 05:04:52 --> Email Class Initialized
DEBUG - 2022-07-18 05:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:04:52 --> Controller Class Initialized
INFO - 2022-07-18 05:04:52 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:04:52 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 10:34:53 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-07-18 10:34:53 --> Final output sent to browser
DEBUG - 2022-07-18 10:34:53 --> Total execution time: 0.0653
INFO - 2022-07-18 05:05:01 --> Config Class Initialized
INFO - 2022-07-18 05:05:01 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:05:01 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:05:01 --> Utf8 Class Initialized
INFO - 2022-07-18 05:05:01 --> URI Class Initialized
INFO - 2022-07-18 05:05:01 --> Router Class Initialized
INFO - 2022-07-18 05:05:01 --> Output Class Initialized
INFO - 2022-07-18 05:05:01 --> Security Class Initialized
DEBUG - 2022-07-18 05:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:05:01 --> Input Class Initialized
INFO - 2022-07-18 05:05:01 --> Language Class Initialized
INFO - 2022-07-18 05:05:01 --> Loader Class Initialized
INFO - 2022-07-18 05:05:01 --> Helper loaded: url_helper
INFO - 2022-07-18 05:05:01 --> Helper loaded: file_helper
INFO - 2022-07-18 05:05:01 --> Database Driver Class Initialized
INFO - 2022-07-18 05:05:01 --> Email Class Initialized
DEBUG - 2022-07-18 05:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:05:01 --> Controller Class Initialized
INFO - 2022-07-18 05:05:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:05:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 10:35:01 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-07-18 10:35:01 --> Final output sent to browser
DEBUG - 2022-07-18 10:35:01 --> Total execution time: 0.0806
INFO - 2022-07-18 05:05:03 --> Config Class Initialized
INFO - 2022-07-18 05:05:03 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:05:03 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:05:03 --> Utf8 Class Initialized
INFO - 2022-07-18 05:05:03 --> URI Class Initialized
INFO - 2022-07-18 05:05:03 --> Router Class Initialized
INFO - 2022-07-18 05:05:03 --> Output Class Initialized
INFO - 2022-07-18 05:05:03 --> Security Class Initialized
DEBUG - 2022-07-18 05:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:05:03 --> Input Class Initialized
INFO - 2022-07-18 05:05:03 --> Language Class Initialized
INFO - 2022-07-18 05:05:03 --> Loader Class Initialized
INFO - 2022-07-18 05:05:03 --> Helper loaded: url_helper
INFO - 2022-07-18 05:05:03 --> Helper loaded: file_helper
INFO - 2022-07-18 05:05:03 --> Database Driver Class Initialized
INFO - 2022-07-18 05:05:03 --> Email Class Initialized
DEBUG - 2022-07-18 05:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:05:03 --> Controller Class Initialized
INFO - 2022-07-18 05:05:03 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:05:03 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 10:35:03 --> Final output sent to browser
DEBUG - 2022-07-18 10:35:03 --> Total execution time: 0.0170
INFO - 2022-07-18 05:13:55 --> Config Class Initialized
INFO - 2022-07-18 05:13:55 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:13:55 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:13:55 --> Utf8 Class Initialized
INFO - 2022-07-18 05:13:55 --> URI Class Initialized
INFO - 2022-07-18 05:13:55 --> Router Class Initialized
INFO - 2022-07-18 05:13:55 --> Output Class Initialized
INFO - 2022-07-18 05:13:55 --> Security Class Initialized
DEBUG - 2022-07-18 05:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:13:55 --> Input Class Initialized
INFO - 2022-07-18 05:13:55 --> Language Class Initialized
INFO - 2022-07-18 05:13:55 --> Loader Class Initialized
INFO - 2022-07-18 05:13:55 --> Helper loaded: url_helper
INFO - 2022-07-18 05:13:55 --> Helper loaded: file_helper
INFO - 2022-07-18 05:13:55 --> Database Driver Class Initialized
INFO - 2022-07-18 05:13:55 --> Email Class Initialized
DEBUG - 2022-07-18 05:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:13:55 --> Controller Class Initialized
INFO - 2022-07-18 05:13:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:13:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 10:43:55 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 10:43:55 --> Final output sent to browser
DEBUG - 2022-07-18 10:43:55 --> Total execution time: 0.2516
INFO - 2022-07-18 05:13:59 --> Config Class Initialized
INFO - 2022-07-18 05:13:59 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:13:59 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:13:59 --> Utf8 Class Initialized
INFO - 2022-07-18 05:13:59 --> URI Class Initialized
INFO - 2022-07-18 05:13:59 --> Router Class Initialized
INFO - 2022-07-18 05:13:59 --> Output Class Initialized
INFO - 2022-07-18 05:13:59 --> Security Class Initialized
DEBUG - 2022-07-18 05:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:13:59 --> Input Class Initialized
INFO - 2022-07-18 05:13:59 --> Language Class Initialized
INFO - 2022-07-18 05:13:59 --> Loader Class Initialized
INFO - 2022-07-18 05:13:59 --> Helper loaded: url_helper
INFO - 2022-07-18 05:13:59 --> Helper loaded: file_helper
INFO - 2022-07-18 05:13:59 --> Database Driver Class Initialized
INFO - 2022-07-18 05:13:59 --> Email Class Initialized
DEBUG - 2022-07-18 05:13:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:13:59 --> Controller Class Initialized
INFO - 2022-07-18 05:13:59 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:13:59 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 10:43:59 --> Final output sent to browser
DEBUG - 2022-07-18 10:43:59 --> Total execution time: 0.0174
INFO - 2022-07-18 05:14:00 --> Config Class Initialized
INFO - 2022-07-18 05:14:00 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:14:00 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:14:00 --> Utf8 Class Initialized
INFO - 2022-07-18 05:14:00 --> URI Class Initialized
INFO - 2022-07-18 05:14:00 --> Router Class Initialized
INFO - 2022-07-18 05:14:00 --> Output Class Initialized
INFO - 2022-07-18 05:14:00 --> Security Class Initialized
DEBUG - 2022-07-18 05:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:14:00 --> Input Class Initialized
INFO - 2022-07-18 05:14:00 --> Language Class Initialized
INFO - 2022-07-18 05:14:00 --> Loader Class Initialized
INFO - 2022-07-18 05:14:00 --> Helper loaded: url_helper
INFO - 2022-07-18 05:14:00 --> Helper loaded: file_helper
INFO - 2022-07-18 05:14:00 --> Database Driver Class Initialized
INFO - 2022-07-18 05:14:00 --> Email Class Initialized
DEBUG - 2022-07-18 05:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:14:00 --> Controller Class Initialized
INFO - 2022-07-18 05:14:00 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:14:00 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:14:00 --> Final output sent to browser
DEBUG - 2022-07-18 05:14:00 --> Total execution time: 0.0281
INFO - 2022-07-18 05:14:02 --> Config Class Initialized
INFO - 2022-07-18 05:14:02 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:14:02 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:14:02 --> Utf8 Class Initialized
INFO - 2022-07-18 05:14:02 --> URI Class Initialized
INFO - 2022-07-18 05:14:02 --> Router Class Initialized
INFO - 2022-07-18 05:14:02 --> Output Class Initialized
INFO - 2022-07-18 05:14:02 --> Security Class Initialized
DEBUG - 2022-07-18 05:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:14:02 --> Input Class Initialized
INFO - 2022-07-18 05:14:02 --> Language Class Initialized
INFO - 2022-07-18 05:14:02 --> Loader Class Initialized
INFO - 2022-07-18 05:14:02 --> Helper loaded: url_helper
INFO - 2022-07-18 05:14:02 --> Helper loaded: file_helper
INFO - 2022-07-18 05:14:02 --> Database Driver Class Initialized
INFO - 2022-07-18 05:14:02 --> Email Class Initialized
DEBUG - 2022-07-18 05:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:14:02 --> Controller Class Initialized
INFO - 2022-07-18 05:14:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:14:02 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:14:02 --> Final output sent to browser
DEBUG - 2022-07-18 05:14:02 --> Total execution time: 0.0455
INFO - 2022-07-18 05:14:02 --> Config Class Initialized
INFO - 2022-07-18 05:14:02 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:14:02 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:14:02 --> Utf8 Class Initialized
INFO - 2022-07-18 05:14:02 --> URI Class Initialized
INFO - 2022-07-18 05:14:02 --> Router Class Initialized
INFO - 2022-07-18 05:14:02 --> Output Class Initialized
INFO - 2022-07-18 05:14:02 --> Security Class Initialized
DEBUG - 2022-07-18 05:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:14:02 --> Input Class Initialized
INFO - 2022-07-18 05:14:02 --> Language Class Initialized
INFO - 2022-07-18 05:14:02 --> Loader Class Initialized
INFO - 2022-07-18 05:14:02 --> Helper loaded: url_helper
INFO - 2022-07-18 05:14:02 --> Helper loaded: file_helper
INFO - 2022-07-18 05:14:02 --> Database Driver Class Initialized
INFO - 2022-07-18 05:14:02 --> Email Class Initialized
DEBUG - 2022-07-18 05:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:14:02 --> Controller Class Initialized
INFO - 2022-07-18 05:14:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:14:02 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:14:02 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-18 05:14:02 --> Final output sent to browser
DEBUG - 2022-07-18 05:14:02 --> Total execution time: 0.0160
INFO - 2022-07-18 05:14:04 --> Config Class Initialized
INFO - 2022-07-18 05:14:04 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:14:04 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:14:04 --> Utf8 Class Initialized
INFO - 2022-07-18 05:14:04 --> URI Class Initialized
INFO - 2022-07-18 05:14:04 --> Router Class Initialized
INFO - 2022-07-18 05:14:04 --> Output Class Initialized
INFO - 2022-07-18 05:14:04 --> Security Class Initialized
DEBUG - 2022-07-18 05:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:14:04 --> Input Class Initialized
INFO - 2022-07-18 05:14:04 --> Language Class Initialized
INFO - 2022-07-18 05:14:04 --> Loader Class Initialized
INFO - 2022-07-18 05:14:04 --> Helper loaded: url_helper
INFO - 2022-07-18 05:14:04 --> Helper loaded: file_helper
INFO - 2022-07-18 05:14:04 --> Database Driver Class Initialized
INFO - 2022-07-18 05:14:04 --> Email Class Initialized
DEBUG - 2022-07-18 05:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:14:04 --> Controller Class Initialized
INFO - 2022-07-18 05:14:04 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:14:04 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:14:04 --> Final output sent to browser
DEBUG - 2022-07-18 05:14:04 --> Total execution time: 0.0322
INFO - 2022-07-18 05:14:09 --> Config Class Initialized
INFO - 2022-07-18 05:14:09 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:14:09 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:14:09 --> Utf8 Class Initialized
INFO - 2022-07-18 05:14:09 --> URI Class Initialized
INFO - 2022-07-18 05:14:09 --> Router Class Initialized
INFO - 2022-07-18 05:14:09 --> Output Class Initialized
INFO - 2022-07-18 05:14:09 --> Security Class Initialized
DEBUG - 2022-07-18 05:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:14:09 --> Input Class Initialized
INFO - 2022-07-18 05:14:09 --> Language Class Initialized
INFO - 2022-07-18 05:14:09 --> Loader Class Initialized
INFO - 2022-07-18 05:14:09 --> Helper loaded: url_helper
INFO - 2022-07-18 05:14:09 --> Helper loaded: file_helper
INFO - 2022-07-18 05:14:09 --> Database Driver Class Initialized
INFO - 2022-07-18 05:14:09 --> Email Class Initialized
DEBUG - 2022-07-18 05:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:14:09 --> Controller Class Initialized
INFO - 2022-07-18 05:14:09 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:14:09 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 10:44:09 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 10:44:09 --> Final output sent to browser
DEBUG - 2022-07-18 10:44:09 --> Total execution time: 0.1783
INFO - 2022-07-18 05:14:48 --> Config Class Initialized
INFO - 2022-07-18 05:14:48 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:14:48 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:14:48 --> Utf8 Class Initialized
INFO - 2022-07-18 05:14:48 --> URI Class Initialized
INFO - 2022-07-18 05:14:48 --> Router Class Initialized
INFO - 2022-07-18 05:14:48 --> Output Class Initialized
INFO - 2022-07-18 05:14:48 --> Security Class Initialized
DEBUG - 2022-07-18 05:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:14:48 --> Input Class Initialized
INFO - 2022-07-18 05:14:48 --> Language Class Initialized
INFO - 2022-07-18 05:14:48 --> Loader Class Initialized
INFO - 2022-07-18 05:14:48 --> Helper loaded: url_helper
INFO - 2022-07-18 05:14:48 --> Helper loaded: file_helper
INFO - 2022-07-18 05:14:48 --> Database Driver Class Initialized
INFO - 2022-07-18 05:14:48 --> Email Class Initialized
DEBUG - 2022-07-18 05:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:14:48 --> Controller Class Initialized
INFO - 2022-07-18 05:14:48 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:14:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 10:44:48 --> Severity: Notice --> Trying to get property 'td_start_time' of non-object C:\wamp64\www\qr\application\controllers\Tokenctrl.php 121
INFO - 2022-07-18 10:44:48 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 10:44:48 --> Final output sent to browser
DEBUG - 2022-07-18 10:44:48 --> Total execution time: 0.1359
INFO - 2022-07-18 05:16:03 --> Config Class Initialized
INFO - 2022-07-18 05:16:03 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:16:03 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:16:03 --> Utf8 Class Initialized
INFO - 2022-07-18 05:16:03 --> URI Class Initialized
INFO - 2022-07-18 05:16:03 --> Router Class Initialized
INFO - 2022-07-18 05:16:03 --> Output Class Initialized
INFO - 2022-07-18 05:16:03 --> Security Class Initialized
DEBUG - 2022-07-18 05:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:16:03 --> Input Class Initialized
INFO - 2022-07-18 05:16:03 --> Language Class Initialized
INFO - 2022-07-18 05:16:03 --> Loader Class Initialized
INFO - 2022-07-18 05:16:03 --> Helper loaded: url_helper
INFO - 2022-07-18 05:16:03 --> Helper loaded: file_helper
INFO - 2022-07-18 05:16:03 --> Database Driver Class Initialized
INFO - 2022-07-18 05:16:03 --> Email Class Initialized
DEBUG - 2022-07-18 05:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:16:03 --> Controller Class Initialized
INFO - 2022-07-18 05:16:03 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:16:03 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:16:03 --> Final output sent to browser
DEBUG - 2022-07-18 05:16:03 --> Total execution time: 0.1281
INFO - 2022-07-18 05:16:03 --> Config Class Initialized
INFO - 2022-07-18 05:16:03 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:16:03 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:16:03 --> Utf8 Class Initialized
INFO - 2022-07-18 05:16:03 --> URI Class Initialized
INFO - 2022-07-18 05:16:03 --> Router Class Initialized
INFO - 2022-07-18 05:16:03 --> Output Class Initialized
INFO - 2022-07-18 05:16:03 --> Security Class Initialized
DEBUG - 2022-07-18 05:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:16:03 --> Input Class Initialized
INFO - 2022-07-18 05:16:03 --> Language Class Initialized
INFO - 2022-07-18 05:16:03 --> Loader Class Initialized
INFO - 2022-07-18 05:16:03 --> Helper loaded: url_helper
INFO - 2022-07-18 05:16:03 --> Helper loaded: file_helper
INFO - 2022-07-18 05:16:03 --> Database Driver Class Initialized
INFO - 2022-07-18 05:16:03 --> Email Class Initialized
DEBUG - 2022-07-18 05:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:16:03 --> Controller Class Initialized
INFO - 2022-07-18 05:16:03 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:16:03 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:16:03 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-18 05:16:03 --> Final output sent to browser
DEBUG - 2022-07-18 05:16:03 --> Total execution time: 0.0559
INFO - 2022-07-18 05:16:05 --> Config Class Initialized
INFO - 2022-07-18 05:16:05 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:16:05 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:16:05 --> Utf8 Class Initialized
INFO - 2022-07-18 05:16:05 --> URI Class Initialized
INFO - 2022-07-18 05:16:05 --> Router Class Initialized
INFO - 2022-07-18 05:16:05 --> Output Class Initialized
INFO - 2022-07-18 05:16:05 --> Security Class Initialized
DEBUG - 2022-07-18 05:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:16:05 --> Input Class Initialized
INFO - 2022-07-18 05:16:05 --> Language Class Initialized
INFO - 2022-07-18 05:16:05 --> Loader Class Initialized
INFO - 2022-07-18 05:16:05 --> Helper loaded: url_helper
INFO - 2022-07-18 05:16:05 --> Helper loaded: file_helper
INFO - 2022-07-18 05:16:05 --> Database Driver Class Initialized
INFO - 2022-07-18 05:16:05 --> Email Class Initialized
DEBUG - 2022-07-18 05:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:16:05 --> Controller Class Initialized
INFO - 2022-07-18 05:16:05 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:16:05 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:16:05 --> Final output sent to browser
DEBUG - 2022-07-18 05:16:05 --> Total execution time: 0.0168
INFO - 2022-07-18 05:16:07 --> Config Class Initialized
INFO - 2022-07-18 05:16:07 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:16:07 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:16:07 --> Utf8 Class Initialized
INFO - 2022-07-18 05:16:07 --> URI Class Initialized
INFO - 2022-07-18 05:16:07 --> Router Class Initialized
INFO - 2022-07-18 05:16:07 --> Output Class Initialized
INFO - 2022-07-18 05:16:07 --> Security Class Initialized
DEBUG - 2022-07-18 05:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:16:07 --> Input Class Initialized
INFO - 2022-07-18 05:16:07 --> Language Class Initialized
INFO - 2022-07-18 05:16:07 --> Loader Class Initialized
INFO - 2022-07-18 05:16:07 --> Helper loaded: url_helper
INFO - 2022-07-18 05:16:07 --> Helper loaded: file_helper
INFO - 2022-07-18 05:16:07 --> Database Driver Class Initialized
INFO - 2022-07-18 05:16:07 --> Email Class Initialized
DEBUG - 2022-07-18 05:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:16:07 --> Controller Class Initialized
INFO - 2022-07-18 05:16:07 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:16:07 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 10:46:08 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 10:46:08 --> Final output sent to browser
DEBUG - 2022-07-18 10:46:08 --> Total execution time: 0.1421
INFO - 2022-07-18 05:16:12 --> Config Class Initialized
INFO - 2022-07-18 05:16:12 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:16:12 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:16:12 --> Utf8 Class Initialized
INFO - 2022-07-18 05:16:12 --> URI Class Initialized
INFO - 2022-07-18 05:16:12 --> Router Class Initialized
INFO - 2022-07-18 05:16:12 --> Output Class Initialized
INFO - 2022-07-18 05:16:12 --> Security Class Initialized
DEBUG - 2022-07-18 05:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:16:12 --> Input Class Initialized
INFO - 2022-07-18 05:16:12 --> Language Class Initialized
INFO - 2022-07-18 05:16:12 --> Loader Class Initialized
INFO - 2022-07-18 05:16:12 --> Helper loaded: url_helper
INFO - 2022-07-18 05:16:12 --> Helper loaded: file_helper
INFO - 2022-07-18 05:16:12 --> Database Driver Class Initialized
INFO - 2022-07-18 05:16:12 --> Email Class Initialized
DEBUG - 2022-07-18 05:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:16:12 --> Controller Class Initialized
INFO - 2022-07-18 05:16:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:16:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 10:46:12 --> Severity: Notice --> Trying to get property 'td_start_time' of non-object C:\wamp64\www\qr\application\controllers\Tokenctrl.php 121
INFO - 2022-07-18 10:46:12 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 10:46:12 --> Final output sent to browser
DEBUG - 2022-07-18 10:46:12 --> Total execution time: 0.1697
INFO - 2022-07-18 05:16:57 --> Config Class Initialized
INFO - 2022-07-18 05:16:57 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:16:57 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:16:57 --> Utf8 Class Initialized
INFO - 2022-07-18 05:16:57 --> URI Class Initialized
INFO - 2022-07-18 05:16:57 --> Router Class Initialized
INFO - 2022-07-18 05:16:57 --> Output Class Initialized
INFO - 2022-07-18 05:16:57 --> Security Class Initialized
DEBUG - 2022-07-18 05:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:16:57 --> Input Class Initialized
INFO - 2022-07-18 05:16:57 --> Language Class Initialized
INFO - 2022-07-18 05:16:57 --> Loader Class Initialized
INFO - 2022-07-18 05:16:57 --> Helper loaded: url_helper
INFO - 2022-07-18 05:16:57 --> Helper loaded: file_helper
INFO - 2022-07-18 05:16:57 --> Database Driver Class Initialized
INFO - 2022-07-18 05:16:57 --> Email Class Initialized
DEBUG - 2022-07-18 05:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:16:57 --> Controller Class Initialized
INFO - 2022-07-18 05:16:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:16:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:16:57 --> Final output sent to browser
DEBUG - 2022-07-18 05:16:57 --> Total execution time: 0.1170
INFO - 2022-07-18 05:16:57 --> Config Class Initialized
INFO - 2022-07-18 05:16:57 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:16:57 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:16:57 --> Utf8 Class Initialized
INFO - 2022-07-18 05:16:57 --> URI Class Initialized
INFO - 2022-07-18 05:16:57 --> Router Class Initialized
INFO - 2022-07-18 05:16:57 --> Output Class Initialized
INFO - 2022-07-18 05:16:57 --> Security Class Initialized
DEBUG - 2022-07-18 05:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:16:57 --> Input Class Initialized
INFO - 2022-07-18 05:16:57 --> Language Class Initialized
INFO - 2022-07-18 05:16:57 --> Loader Class Initialized
INFO - 2022-07-18 05:16:57 --> Helper loaded: url_helper
INFO - 2022-07-18 05:16:57 --> Helper loaded: file_helper
INFO - 2022-07-18 05:16:57 --> Database Driver Class Initialized
INFO - 2022-07-18 05:16:57 --> Email Class Initialized
DEBUG - 2022-07-18 05:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:16:57 --> Controller Class Initialized
INFO - 2022-07-18 05:16:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:16:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:16:57 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-18 05:16:57 --> Final output sent to browser
DEBUG - 2022-07-18 05:16:57 --> Total execution time: 0.0165
INFO - 2022-07-18 05:17:01 --> Config Class Initialized
INFO - 2022-07-18 05:17:01 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:17:01 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:17:01 --> Utf8 Class Initialized
INFO - 2022-07-18 05:17:01 --> URI Class Initialized
INFO - 2022-07-18 05:17:01 --> Router Class Initialized
INFO - 2022-07-18 05:17:01 --> Output Class Initialized
INFO - 2022-07-18 05:17:01 --> Security Class Initialized
DEBUG - 2022-07-18 05:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:17:01 --> Input Class Initialized
INFO - 2022-07-18 05:17:01 --> Language Class Initialized
INFO - 2022-07-18 05:17:01 --> Loader Class Initialized
INFO - 2022-07-18 05:17:01 --> Helper loaded: url_helper
INFO - 2022-07-18 05:17:01 --> Helper loaded: file_helper
INFO - 2022-07-18 05:17:01 --> Database Driver Class Initialized
INFO - 2022-07-18 05:17:01 --> Email Class Initialized
DEBUG - 2022-07-18 05:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:17:01 --> Controller Class Initialized
INFO - 2022-07-18 05:17:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:17:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:17:01 --> Final output sent to browser
DEBUG - 2022-07-18 05:17:01 --> Total execution time: 0.0169
INFO - 2022-07-18 05:17:03 --> Config Class Initialized
INFO - 2022-07-18 05:17:03 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:17:03 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:17:03 --> Utf8 Class Initialized
INFO - 2022-07-18 05:17:03 --> URI Class Initialized
INFO - 2022-07-18 05:17:03 --> Router Class Initialized
INFO - 2022-07-18 05:17:03 --> Output Class Initialized
INFO - 2022-07-18 05:17:03 --> Security Class Initialized
DEBUG - 2022-07-18 05:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:17:03 --> Input Class Initialized
INFO - 2022-07-18 05:17:03 --> Language Class Initialized
INFO - 2022-07-18 05:17:03 --> Loader Class Initialized
INFO - 2022-07-18 05:17:03 --> Helper loaded: url_helper
INFO - 2022-07-18 05:17:03 --> Helper loaded: file_helper
INFO - 2022-07-18 05:17:03 --> Database Driver Class Initialized
INFO - 2022-07-18 05:17:03 --> Email Class Initialized
DEBUG - 2022-07-18 05:17:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:17:03 --> Controller Class Initialized
INFO - 2022-07-18 05:17:03 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:17:03 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 10:47:03 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 10:47:03 --> Final output sent to browser
DEBUG - 2022-07-18 10:47:03 --> Total execution time: 0.1160
INFO - 2022-07-18 05:17:19 --> Config Class Initialized
INFO - 2022-07-18 05:17:19 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:17:19 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:17:19 --> Utf8 Class Initialized
INFO - 2022-07-18 05:17:19 --> URI Class Initialized
INFO - 2022-07-18 05:17:19 --> Router Class Initialized
INFO - 2022-07-18 05:17:19 --> Output Class Initialized
INFO - 2022-07-18 05:17:19 --> Security Class Initialized
DEBUG - 2022-07-18 05:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:17:19 --> Input Class Initialized
INFO - 2022-07-18 05:17:19 --> Language Class Initialized
INFO - 2022-07-18 05:17:19 --> Loader Class Initialized
INFO - 2022-07-18 05:17:19 --> Helper loaded: url_helper
INFO - 2022-07-18 05:17:19 --> Helper loaded: file_helper
INFO - 2022-07-18 05:17:19 --> Database Driver Class Initialized
INFO - 2022-07-18 05:17:19 --> Email Class Initialized
DEBUG - 2022-07-18 05:17:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:17:19 --> Controller Class Initialized
INFO - 2022-07-18 05:17:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:17:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 10:47:19 --> Severity: Notice --> Trying to get property 'td_start_time' of non-object C:\wamp64\www\qr\application\controllers\Tokenctrl.php 121
INFO - 2022-07-18 10:47:19 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 10:47:19 --> Final output sent to browser
DEBUG - 2022-07-18 10:47:19 --> Total execution time: 0.3694
INFO - 2022-07-18 05:18:18 --> Config Class Initialized
INFO - 2022-07-18 05:18:18 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:18:18 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:18:18 --> Utf8 Class Initialized
INFO - 2022-07-18 05:18:18 --> URI Class Initialized
INFO - 2022-07-18 05:18:18 --> Router Class Initialized
INFO - 2022-07-18 05:18:18 --> Output Class Initialized
INFO - 2022-07-18 05:18:18 --> Security Class Initialized
DEBUG - 2022-07-18 05:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:18:18 --> Input Class Initialized
INFO - 2022-07-18 05:18:18 --> Language Class Initialized
INFO - 2022-07-18 05:18:18 --> Loader Class Initialized
INFO - 2022-07-18 05:18:18 --> Helper loaded: url_helper
INFO - 2022-07-18 05:18:18 --> Helper loaded: file_helper
INFO - 2022-07-18 05:18:18 --> Database Driver Class Initialized
INFO - 2022-07-18 05:18:18 --> Email Class Initialized
DEBUG - 2022-07-18 05:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:18:18 --> Controller Class Initialized
INFO - 2022-07-18 05:18:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:18:18 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:18:18 --> Final output sent to browser
DEBUG - 2022-07-18 05:18:18 --> Total execution time: 0.0839
INFO - 2022-07-18 05:18:18 --> Config Class Initialized
INFO - 2022-07-18 05:18:18 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:18:18 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:18:18 --> Utf8 Class Initialized
INFO - 2022-07-18 05:18:18 --> URI Class Initialized
INFO - 2022-07-18 05:18:18 --> Router Class Initialized
INFO - 2022-07-18 05:18:18 --> Output Class Initialized
INFO - 2022-07-18 05:18:18 --> Security Class Initialized
DEBUG - 2022-07-18 05:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:18:18 --> Input Class Initialized
INFO - 2022-07-18 05:18:18 --> Language Class Initialized
INFO - 2022-07-18 05:18:18 --> Loader Class Initialized
INFO - 2022-07-18 05:18:18 --> Helper loaded: url_helper
INFO - 2022-07-18 05:18:18 --> Helper loaded: file_helper
INFO - 2022-07-18 05:18:18 --> Database Driver Class Initialized
INFO - 2022-07-18 05:18:18 --> Email Class Initialized
DEBUG - 2022-07-18 05:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:18:18 --> Controller Class Initialized
INFO - 2022-07-18 05:18:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:18:18 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:18:18 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-18 05:18:18 --> Final output sent to browser
DEBUG - 2022-07-18 05:18:18 --> Total execution time: 0.0544
INFO - 2022-07-18 05:18:20 --> Config Class Initialized
INFO - 2022-07-18 05:18:20 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:18:20 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:18:20 --> Utf8 Class Initialized
INFO - 2022-07-18 05:18:20 --> URI Class Initialized
INFO - 2022-07-18 05:18:20 --> Router Class Initialized
INFO - 2022-07-18 05:18:20 --> Output Class Initialized
INFO - 2022-07-18 05:18:20 --> Security Class Initialized
DEBUG - 2022-07-18 05:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:18:20 --> Input Class Initialized
INFO - 2022-07-18 05:18:20 --> Language Class Initialized
INFO - 2022-07-18 05:18:20 --> Loader Class Initialized
INFO - 2022-07-18 05:18:20 --> Helper loaded: url_helper
INFO - 2022-07-18 05:18:20 --> Helper loaded: file_helper
INFO - 2022-07-18 05:18:20 --> Database Driver Class Initialized
INFO - 2022-07-18 05:18:20 --> Email Class Initialized
DEBUG - 2022-07-18 05:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:18:20 --> Controller Class Initialized
INFO - 2022-07-18 05:18:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:18:20 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:18:20 --> Final output sent to browser
DEBUG - 2022-07-18 05:18:20 --> Total execution time: 0.0165
INFO - 2022-07-18 05:18:23 --> Config Class Initialized
INFO - 2022-07-18 05:18:23 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:18:23 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:18:23 --> Utf8 Class Initialized
INFO - 2022-07-18 05:18:23 --> URI Class Initialized
INFO - 2022-07-18 05:18:23 --> Router Class Initialized
INFO - 2022-07-18 05:18:23 --> Output Class Initialized
INFO - 2022-07-18 05:18:23 --> Security Class Initialized
DEBUG - 2022-07-18 05:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:18:23 --> Input Class Initialized
INFO - 2022-07-18 05:18:23 --> Language Class Initialized
INFO - 2022-07-18 05:18:23 --> Loader Class Initialized
INFO - 2022-07-18 05:18:23 --> Helper loaded: url_helper
INFO - 2022-07-18 05:18:23 --> Helper loaded: file_helper
INFO - 2022-07-18 05:18:23 --> Database Driver Class Initialized
INFO - 2022-07-18 05:18:23 --> Email Class Initialized
DEBUG - 2022-07-18 05:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:18:23 --> Controller Class Initialized
INFO - 2022-07-18 05:18:23 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:18:23 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 10:48:23 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 10:48:23 --> Final output sent to browser
DEBUG - 2022-07-18 10:48:23 --> Total execution time: 0.1452
INFO - 2022-07-18 05:26:10 --> Config Class Initialized
INFO - 2022-07-18 05:26:10 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:26:10 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:26:10 --> Utf8 Class Initialized
INFO - 2022-07-18 05:26:10 --> URI Class Initialized
INFO - 2022-07-18 05:26:10 --> Router Class Initialized
INFO - 2022-07-18 05:26:10 --> Output Class Initialized
INFO - 2022-07-18 05:26:10 --> Security Class Initialized
DEBUG - 2022-07-18 05:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:26:10 --> Input Class Initialized
INFO - 2022-07-18 05:26:10 --> Language Class Initialized
INFO - 2022-07-18 05:26:10 --> Loader Class Initialized
INFO - 2022-07-18 05:26:10 --> Helper loaded: url_helper
INFO - 2022-07-18 05:26:10 --> Helper loaded: file_helper
INFO - 2022-07-18 05:26:10 --> Database Driver Class Initialized
INFO - 2022-07-18 05:26:10 --> Email Class Initialized
DEBUG - 2022-07-18 05:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:26:10 --> Controller Class Initialized
INFO - 2022-07-18 05:26:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:26:10 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 10:56:10 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 10:56:10 --> Final output sent to browser
DEBUG - 2022-07-18 10:56:10 --> Total execution time: 0.0757
INFO - 2022-07-18 05:27:09 --> Config Class Initialized
INFO - 2022-07-18 05:27:09 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:27:09 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:27:09 --> Utf8 Class Initialized
INFO - 2022-07-18 05:27:09 --> URI Class Initialized
INFO - 2022-07-18 05:27:09 --> Router Class Initialized
INFO - 2022-07-18 05:27:09 --> Output Class Initialized
INFO - 2022-07-18 05:27:09 --> Security Class Initialized
DEBUG - 2022-07-18 05:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:27:09 --> Input Class Initialized
INFO - 2022-07-18 05:27:09 --> Language Class Initialized
INFO - 2022-07-18 05:27:09 --> Loader Class Initialized
INFO - 2022-07-18 05:27:09 --> Helper loaded: url_helper
INFO - 2022-07-18 05:27:09 --> Helper loaded: file_helper
INFO - 2022-07-18 05:27:09 --> Database Driver Class Initialized
INFO - 2022-07-18 05:27:09 --> Email Class Initialized
DEBUG - 2022-07-18 05:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:27:09 --> Controller Class Initialized
INFO - 2022-07-18 05:27:09 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:27:09 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 10:57:09 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 10:57:09 --> Final output sent to browser
DEBUG - 2022-07-18 10:57:09 --> Total execution time: 0.1786
INFO - 2022-07-18 05:30:15 --> Config Class Initialized
INFO - 2022-07-18 05:30:15 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:30:15 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:30:15 --> Utf8 Class Initialized
INFO - 2022-07-18 05:30:15 --> URI Class Initialized
INFO - 2022-07-18 05:30:15 --> Router Class Initialized
INFO - 2022-07-18 05:30:15 --> Output Class Initialized
INFO - 2022-07-18 05:30:15 --> Security Class Initialized
DEBUG - 2022-07-18 05:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:30:15 --> Input Class Initialized
INFO - 2022-07-18 05:30:15 --> Language Class Initialized
INFO - 2022-07-18 05:30:15 --> Loader Class Initialized
INFO - 2022-07-18 05:30:15 --> Helper loaded: url_helper
INFO - 2022-07-18 05:30:15 --> Helper loaded: file_helper
INFO - 2022-07-18 05:30:15 --> Database Driver Class Initialized
INFO - 2022-07-18 05:30:15 --> Email Class Initialized
DEBUG - 2022-07-18 05:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:30:15 --> Controller Class Initialized
INFO - 2022-07-18 05:30:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:30:15 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:00:15 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:00:15 --> Final output sent to browser
DEBUG - 2022-07-18 11:00:15 --> Total execution time: 0.0627
INFO - 2022-07-18 05:30:26 --> Config Class Initialized
INFO - 2022-07-18 05:30:26 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:30:26 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:30:26 --> Utf8 Class Initialized
INFO - 2022-07-18 05:30:26 --> URI Class Initialized
INFO - 2022-07-18 05:30:26 --> Router Class Initialized
INFO - 2022-07-18 05:30:26 --> Output Class Initialized
INFO - 2022-07-18 05:30:26 --> Security Class Initialized
DEBUG - 2022-07-18 05:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:30:26 --> Input Class Initialized
INFO - 2022-07-18 05:30:26 --> Language Class Initialized
INFO - 2022-07-18 05:30:26 --> Loader Class Initialized
INFO - 2022-07-18 05:30:26 --> Helper loaded: url_helper
INFO - 2022-07-18 05:30:26 --> Helper loaded: file_helper
INFO - 2022-07-18 05:30:26 --> Database Driver Class Initialized
INFO - 2022-07-18 05:30:26 --> Email Class Initialized
DEBUG - 2022-07-18 05:30:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:30:26 --> Controller Class Initialized
INFO - 2022-07-18 05:30:26 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:30:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-07-18 11:00:26 --> insertedINSERT INTO `tokendetails` (`td_tk`, `td_cs`, `td_visited_date`, `td_est_time`) VALUES (7, 0, '2022-07-18', '05:30:00')
INFO - 2022-07-18 11:00:26 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-18 11:00:26 --> Final output sent to browser
DEBUG - 2022-07-18 11:00:26 --> Total execution time: 0.1457
INFO - 2022-07-18 05:30:55 --> Config Class Initialized
INFO - 2022-07-18 05:30:55 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:30:55 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:30:55 --> Utf8 Class Initialized
INFO - 2022-07-18 05:30:55 --> URI Class Initialized
INFO - 2022-07-18 05:30:55 --> Router Class Initialized
INFO - 2022-07-18 05:30:55 --> Output Class Initialized
INFO - 2022-07-18 05:30:55 --> Security Class Initialized
DEBUG - 2022-07-18 05:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:30:55 --> Input Class Initialized
INFO - 2022-07-18 05:30:55 --> Language Class Initialized
INFO - 2022-07-18 05:30:55 --> Loader Class Initialized
INFO - 2022-07-18 05:30:55 --> Helper loaded: url_helper
INFO - 2022-07-18 05:30:55 --> Helper loaded: file_helper
INFO - 2022-07-18 05:30:55 --> Database Driver Class Initialized
INFO - 2022-07-18 05:30:55 --> Email Class Initialized
DEBUG - 2022-07-18 05:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:30:55 --> Controller Class Initialized
INFO - 2022-07-18 05:30:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:30:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:30:56 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-18 05:30:56 --> Final output sent to browser
DEBUG - 2022-07-18 05:30:56 --> Total execution time: 0.1294
INFO - 2022-07-18 05:38:01 --> Config Class Initialized
INFO - 2022-07-18 05:38:01 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:38:01 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:38:01 --> Utf8 Class Initialized
INFO - 2022-07-18 05:38:01 --> URI Class Initialized
INFO - 2022-07-18 05:38:01 --> Router Class Initialized
INFO - 2022-07-18 05:38:01 --> Output Class Initialized
INFO - 2022-07-18 05:38:01 --> Security Class Initialized
DEBUG - 2022-07-18 05:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:38:01 --> Input Class Initialized
INFO - 2022-07-18 05:38:01 --> Language Class Initialized
INFO - 2022-07-18 05:38:01 --> Loader Class Initialized
INFO - 2022-07-18 05:38:01 --> Helper loaded: url_helper
INFO - 2022-07-18 05:38:01 --> Helper loaded: file_helper
INFO - 2022-07-18 05:38:01 --> Database Driver Class Initialized
INFO - 2022-07-18 05:38:01 --> Email Class Initialized
DEBUG - 2022-07-18 05:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:38:01 --> Controller Class Initialized
INFO - 2022-07-18 05:38:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:38:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:38:01 --> Final output sent to browser
DEBUG - 2022-07-18 05:38:01 --> Total execution time: 0.0428
INFO - 2022-07-18 05:38:01 --> Config Class Initialized
INFO - 2022-07-18 05:38:01 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:38:01 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:38:01 --> Utf8 Class Initialized
INFO - 2022-07-18 05:38:01 --> URI Class Initialized
INFO - 2022-07-18 05:38:01 --> Router Class Initialized
INFO - 2022-07-18 05:38:01 --> Output Class Initialized
INFO - 2022-07-18 05:38:01 --> Security Class Initialized
DEBUG - 2022-07-18 05:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:38:01 --> Input Class Initialized
INFO - 2022-07-18 05:38:01 --> Language Class Initialized
INFO - 2022-07-18 05:38:01 --> Loader Class Initialized
INFO - 2022-07-18 05:38:01 --> Helper loaded: url_helper
INFO - 2022-07-18 05:38:01 --> Helper loaded: file_helper
INFO - 2022-07-18 05:38:01 --> Database Driver Class Initialized
INFO - 2022-07-18 05:38:01 --> Email Class Initialized
DEBUG - 2022-07-18 05:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:38:01 --> Controller Class Initialized
INFO - 2022-07-18 05:38:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:38:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:38:01 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-18 05:38:01 --> Final output sent to browser
DEBUG - 2022-07-18 05:38:01 --> Total execution time: 0.0169
INFO - 2022-07-18 05:38:03 --> Config Class Initialized
INFO - 2022-07-18 05:38:03 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:38:03 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:38:03 --> Utf8 Class Initialized
INFO - 2022-07-18 05:38:03 --> URI Class Initialized
INFO - 2022-07-18 05:38:03 --> Router Class Initialized
INFO - 2022-07-18 05:38:03 --> Output Class Initialized
INFO - 2022-07-18 05:38:03 --> Security Class Initialized
DEBUG - 2022-07-18 05:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:38:03 --> Input Class Initialized
INFO - 2022-07-18 05:38:03 --> Language Class Initialized
INFO - 2022-07-18 05:38:03 --> Loader Class Initialized
INFO - 2022-07-18 05:38:03 --> Helper loaded: url_helper
INFO - 2022-07-18 05:38:03 --> Helper loaded: file_helper
INFO - 2022-07-18 05:38:03 --> Database Driver Class Initialized
INFO - 2022-07-18 05:38:03 --> Email Class Initialized
DEBUG - 2022-07-18 05:38:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:38:03 --> Controller Class Initialized
INFO - 2022-07-18 05:38:03 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:38:03 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:38:03 --> Final output sent to browser
DEBUG - 2022-07-18 05:38:03 --> Total execution time: 0.0170
INFO - 2022-07-18 05:38:09 --> Config Class Initialized
INFO - 2022-07-18 05:38:09 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:38:09 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:38:09 --> Utf8 Class Initialized
INFO - 2022-07-18 05:38:09 --> URI Class Initialized
INFO - 2022-07-18 05:38:09 --> Router Class Initialized
INFO - 2022-07-18 05:38:09 --> Output Class Initialized
INFO - 2022-07-18 05:38:09 --> Security Class Initialized
DEBUG - 2022-07-18 05:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:38:09 --> Input Class Initialized
INFO - 2022-07-18 05:38:09 --> Language Class Initialized
INFO - 2022-07-18 05:38:09 --> Loader Class Initialized
INFO - 2022-07-18 05:38:09 --> Helper loaded: url_helper
INFO - 2022-07-18 05:38:09 --> Helper loaded: file_helper
INFO - 2022-07-18 05:38:09 --> Database Driver Class Initialized
INFO - 2022-07-18 05:38:09 --> Email Class Initialized
DEBUG - 2022-07-18 05:38:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:38:09 --> Controller Class Initialized
INFO - 2022-07-18 05:38:09 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:38:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 05:38:09 --> Severity: Notice --> Trying to get property 'td_tk' of non-object C:\wamp64\www\qr\application\controllers\Tokenctrl.php 493
DEBUG - 2022-07-18 11:08:09 --> insertedINSERT INTO `tokendetails` (`td_tk`, `td_cs`, `td_visited_date`, `td_est_time`) VALUES (1, 0, '2022-07-18', '05:30:00')
INFO - 2022-07-18 11:08:09 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-18 11:08:09 --> Final output sent to browser
DEBUG - 2022-07-18 11:08:09 --> Total execution time: 0.1437
INFO - 2022-07-18 05:38:11 --> Config Class Initialized
INFO - 2022-07-18 05:38:11 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:38:11 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:38:11 --> Utf8 Class Initialized
INFO - 2022-07-18 05:38:11 --> URI Class Initialized
INFO - 2022-07-18 05:38:11 --> Router Class Initialized
INFO - 2022-07-18 05:38:11 --> Output Class Initialized
INFO - 2022-07-18 05:38:11 --> Security Class Initialized
DEBUG - 2022-07-18 05:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:38:11 --> Input Class Initialized
INFO - 2022-07-18 05:38:11 --> Language Class Initialized
INFO - 2022-07-18 05:38:11 --> Loader Class Initialized
INFO - 2022-07-18 05:38:11 --> Helper loaded: url_helper
INFO - 2022-07-18 05:38:11 --> Helper loaded: file_helper
INFO - 2022-07-18 05:38:11 --> Database Driver Class Initialized
INFO - 2022-07-18 05:38:11 --> Email Class Initialized
DEBUG - 2022-07-18 05:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:38:11 --> Controller Class Initialized
INFO - 2022-07-18 05:38:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:38:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:38:11 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-18 05:38:11 --> Final output sent to browser
DEBUG - 2022-07-18 05:38:11 --> Total execution time: 0.1249
INFO - 2022-07-18 05:38:55 --> Config Class Initialized
INFO - 2022-07-18 05:38:55 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:38:55 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:38:55 --> Utf8 Class Initialized
INFO - 2022-07-18 05:38:55 --> URI Class Initialized
INFO - 2022-07-18 05:38:55 --> Router Class Initialized
INFO - 2022-07-18 05:38:55 --> Output Class Initialized
INFO - 2022-07-18 05:38:55 --> Security Class Initialized
DEBUG - 2022-07-18 05:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:38:55 --> Input Class Initialized
INFO - 2022-07-18 05:38:55 --> Language Class Initialized
INFO - 2022-07-18 05:38:55 --> Loader Class Initialized
INFO - 2022-07-18 05:38:55 --> Helper loaded: url_helper
INFO - 2022-07-18 05:38:55 --> Helper loaded: file_helper
INFO - 2022-07-18 05:38:55 --> Database Driver Class Initialized
INFO - 2022-07-18 05:38:55 --> Email Class Initialized
DEBUG - 2022-07-18 05:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:38:55 --> Controller Class Initialized
INFO - 2022-07-18 05:38:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:38:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 05:38:55 --> Severity: Notice --> Trying to get property 'td_tk' of non-object C:\wamp64\www\qr\application\controllers\Tokenctrl.php 493
DEBUG - 2022-07-18 11:08:55 --> insertedINSERT INTO `tokendetails` (`td_tk`, `td_cs`, `td_visited_date`, `td_est_time`) VALUES (2, 0, '2022-07-18', '05:30:00')
INFO - 2022-07-18 11:08:55 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-18 11:08:55 --> Final output sent to browser
DEBUG - 2022-07-18 11:08:55 --> Total execution time: 0.1212
INFO - 2022-07-18 05:38:58 --> Config Class Initialized
INFO - 2022-07-18 05:38:58 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:38:58 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:38:58 --> Utf8 Class Initialized
INFO - 2022-07-18 05:38:58 --> URI Class Initialized
INFO - 2022-07-18 05:38:58 --> Router Class Initialized
INFO - 2022-07-18 05:38:58 --> Output Class Initialized
INFO - 2022-07-18 05:38:58 --> Security Class Initialized
DEBUG - 2022-07-18 05:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:38:58 --> Input Class Initialized
INFO - 2022-07-18 05:38:58 --> Language Class Initialized
INFO - 2022-07-18 05:38:58 --> Loader Class Initialized
INFO - 2022-07-18 05:38:58 --> Helper loaded: url_helper
INFO - 2022-07-18 05:38:58 --> Helper loaded: file_helper
INFO - 2022-07-18 05:38:58 --> Database Driver Class Initialized
INFO - 2022-07-18 05:38:58 --> Email Class Initialized
DEBUG - 2022-07-18 05:38:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:38:58 --> Controller Class Initialized
INFO - 2022-07-18 05:38:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:38:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:38:58 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-18 05:38:58 --> Final output sent to browser
DEBUG - 2022-07-18 05:38:58 --> Total execution time: 0.1240
INFO - 2022-07-18 05:39:51 --> Config Class Initialized
INFO - 2022-07-18 05:39:51 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:39:51 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:39:51 --> Utf8 Class Initialized
INFO - 2022-07-18 05:39:51 --> URI Class Initialized
INFO - 2022-07-18 05:39:51 --> Router Class Initialized
INFO - 2022-07-18 05:39:51 --> Output Class Initialized
INFO - 2022-07-18 05:39:51 --> Security Class Initialized
DEBUG - 2022-07-18 05:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:39:51 --> Input Class Initialized
INFO - 2022-07-18 05:39:51 --> Language Class Initialized
INFO - 2022-07-18 05:39:51 --> Loader Class Initialized
INFO - 2022-07-18 05:39:51 --> Helper loaded: url_helper
INFO - 2022-07-18 05:39:51 --> Helper loaded: file_helper
INFO - 2022-07-18 05:39:51 --> Database Driver Class Initialized
INFO - 2022-07-18 05:39:51 --> Email Class Initialized
DEBUG - 2022-07-18 05:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:39:51 --> Controller Class Initialized
INFO - 2022-07-18 05:39:51 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:39:51 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:39:51 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-18 05:39:51 --> Final output sent to browser
DEBUG - 2022-07-18 05:39:51 --> Total execution time: 0.1439
INFO - 2022-07-18 05:40:20 --> Config Class Initialized
INFO - 2022-07-18 05:40:20 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:40:20 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:40:20 --> Utf8 Class Initialized
INFO - 2022-07-18 05:40:20 --> URI Class Initialized
INFO - 2022-07-18 05:40:20 --> Router Class Initialized
INFO - 2022-07-18 05:40:20 --> Output Class Initialized
INFO - 2022-07-18 05:40:20 --> Security Class Initialized
DEBUG - 2022-07-18 05:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:40:20 --> Input Class Initialized
INFO - 2022-07-18 05:40:20 --> Language Class Initialized
INFO - 2022-07-18 05:40:20 --> Loader Class Initialized
INFO - 2022-07-18 05:40:20 --> Helper loaded: url_helper
INFO - 2022-07-18 05:40:20 --> Helper loaded: file_helper
INFO - 2022-07-18 05:40:20 --> Database Driver Class Initialized
INFO - 2022-07-18 05:40:20 --> Email Class Initialized
DEBUG - 2022-07-18 05:40:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:40:20 --> Controller Class Initialized
INFO - 2022-07-18 05:40:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:40:20 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:40:20 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-18 05:40:20 --> Final output sent to browser
DEBUG - 2022-07-18 05:40:20 --> Total execution time: 0.1263
INFO - 2022-07-18 05:40:22 --> Config Class Initialized
INFO - 2022-07-18 05:40:22 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:40:22 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:40:22 --> Utf8 Class Initialized
INFO - 2022-07-18 05:40:22 --> URI Class Initialized
INFO - 2022-07-18 05:40:22 --> Router Class Initialized
INFO - 2022-07-18 05:40:22 --> Output Class Initialized
INFO - 2022-07-18 05:40:22 --> Security Class Initialized
DEBUG - 2022-07-18 05:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:40:22 --> Input Class Initialized
INFO - 2022-07-18 05:40:22 --> Language Class Initialized
INFO - 2022-07-18 05:40:22 --> Loader Class Initialized
INFO - 2022-07-18 05:40:22 --> Helper loaded: url_helper
INFO - 2022-07-18 05:40:22 --> Helper loaded: file_helper
INFO - 2022-07-18 05:40:22 --> Database Driver Class Initialized
INFO - 2022-07-18 05:40:22 --> Email Class Initialized
DEBUG - 2022-07-18 05:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:40:22 --> Controller Class Initialized
INFO - 2022-07-18 05:40:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:40:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:40:22 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-18 05:40:22 --> Final output sent to browser
DEBUG - 2022-07-18 05:40:22 --> Total execution time: 0.1420
INFO - 2022-07-18 05:41:54 --> Config Class Initialized
INFO - 2022-07-18 05:41:54 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:41:54 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:41:54 --> Utf8 Class Initialized
INFO - 2022-07-18 05:41:54 --> URI Class Initialized
INFO - 2022-07-18 05:41:54 --> Router Class Initialized
INFO - 2022-07-18 05:41:54 --> Output Class Initialized
INFO - 2022-07-18 05:41:54 --> Security Class Initialized
DEBUG - 2022-07-18 05:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:41:54 --> Input Class Initialized
INFO - 2022-07-18 05:41:54 --> Language Class Initialized
INFO - 2022-07-18 05:41:54 --> Loader Class Initialized
INFO - 2022-07-18 05:41:54 --> Helper loaded: url_helper
INFO - 2022-07-18 05:41:54 --> Helper loaded: file_helper
INFO - 2022-07-18 05:41:54 --> Database Driver Class Initialized
INFO - 2022-07-18 05:41:54 --> Email Class Initialized
DEBUG - 2022-07-18 05:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:41:54 --> Controller Class Initialized
INFO - 2022-07-18 05:41:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:41:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 05:41:54 --> Severity: Notice --> Trying to get property 'td_tk' of non-object C:\wamp64\www\qr\application\controllers\Tokenctrl.php 488
DEBUG - 2022-07-18 11:11:54 --> insertedINSERT INTO `tokendetails` (`td_tk`, `td_cs`, `td_visited_date`, `td_est_time`) VALUES (3, 0, '2022-07-18', '05:30:00')
INFO - 2022-07-18 11:11:54 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-18 11:11:54 --> Final output sent to browser
DEBUG - 2022-07-18 11:11:54 --> Total execution time: 0.1073
INFO - 2022-07-18 05:41:57 --> Config Class Initialized
INFO - 2022-07-18 05:41:57 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:41:57 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:41:57 --> Utf8 Class Initialized
INFO - 2022-07-18 05:41:57 --> URI Class Initialized
INFO - 2022-07-18 05:41:57 --> Router Class Initialized
INFO - 2022-07-18 05:41:57 --> Output Class Initialized
INFO - 2022-07-18 05:41:57 --> Security Class Initialized
DEBUG - 2022-07-18 05:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:41:57 --> Input Class Initialized
INFO - 2022-07-18 05:41:57 --> Language Class Initialized
INFO - 2022-07-18 05:41:57 --> Loader Class Initialized
INFO - 2022-07-18 05:41:57 --> Helper loaded: url_helper
INFO - 2022-07-18 05:41:57 --> Helper loaded: file_helper
INFO - 2022-07-18 05:41:57 --> Database Driver Class Initialized
INFO - 2022-07-18 05:41:57 --> Email Class Initialized
DEBUG - 2022-07-18 05:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:41:57 --> Controller Class Initialized
INFO - 2022-07-18 05:41:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:41:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:41:57 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-18 05:41:57 --> Final output sent to browser
DEBUG - 2022-07-18 05:41:57 --> Total execution time: 0.1406
INFO - 2022-07-18 05:41:57 --> Config Class Initialized
INFO - 2022-07-18 05:41:57 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:41:57 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:41:57 --> Utf8 Class Initialized
INFO - 2022-07-18 05:41:57 --> URI Class Initialized
INFO - 2022-07-18 05:41:57 --> Router Class Initialized
INFO - 2022-07-18 05:41:57 --> Output Class Initialized
INFO - 2022-07-18 05:41:57 --> Security Class Initialized
DEBUG - 2022-07-18 05:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:41:57 --> Input Class Initialized
INFO - 2022-07-18 05:41:57 --> Language Class Initialized
INFO - 2022-07-18 05:41:57 --> Loader Class Initialized
INFO - 2022-07-18 05:41:57 --> Helper loaded: url_helper
INFO - 2022-07-18 05:41:57 --> Helper loaded: file_helper
INFO - 2022-07-18 05:41:57 --> Database Driver Class Initialized
INFO - 2022-07-18 05:41:57 --> Email Class Initialized
DEBUG - 2022-07-18 05:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:41:57 --> Controller Class Initialized
INFO - 2022-07-18 05:41:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:41:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:41:57 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-18 05:41:57 --> Final output sent to browser
DEBUG - 2022-07-18 05:41:57 --> Total execution time: 0.0210
INFO - 2022-07-18 05:41:57 --> Config Class Initialized
INFO - 2022-07-18 05:41:57 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:41:57 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:41:57 --> Utf8 Class Initialized
INFO - 2022-07-18 05:41:57 --> URI Class Initialized
INFO - 2022-07-18 05:41:57 --> Router Class Initialized
INFO - 2022-07-18 05:41:57 --> Output Class Initialized
INFO - 2022-07-18 05:41:57 --> Security Class Initialized
DEBUG - 2022-07-18 05:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:41:57 --> Input Class Initialized
INFO - 2022-07-18 05:41:57 --> Language Class Initialized
INFO - 2022-07-18 05:41:57 --> Loader Class Initialized
INFO - 2022-07-18 05:41:57 --> Helper loaded: url_helper
INFO - 2022-07-18 05:41:57 --> Helper loaded: file_helper
INFO - 2022-07-18 05:41:57 --> Database Driver Class Initialized
INFO - 2022-07-18 05:41:58 --> Email Class Initialized
DEBUG - 2022-07-18 05:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:41:58 --> Controller Class Initialized
INFO - 2022-07-18 05:41:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:41:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:41:58 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-18 05:41:58 --> Final output sent to browser
DEBUG - 2022-07-18 05:41:58 --> Total execution time: 0.0465
INFO - 2022-07-18 05:42:11 --> Config Class Initialized
INFO - 2022-07-18 05:42:11 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:42:11 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:42:11 --> Utf8 Class Initialized
INFO - 2022-07-18 05:42:11 --> URI Class Initialized
INFO - 2022-07-18 05:42:11 --> Router Class Initialized
INFO - 2022-07-18 05:42:11 --> Output Class Initialized
INFO - 2022-07-18 05:42:11 --> Security Class Initialized
DEBUG - 2022-07-18 05:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:42:11 --> Input Class Initialized
INFO - 2022-07-18 05:42:11 --> Language Class Initialized
INFO - 2022-07-18 05:42:11 --> Loader Class Initialized
INFO - 2022-07-18 05:42:11 --> Helper loaded: url_helper
INFO - 2022-07-18 05:42:11 --> Helper loaded: file_helper
INFO - 2022-07-18 05:42:11 --> Database Driver Class Initialized
INFO - 2022-07-18 05:42:11 --> Email Class Initialized
DEBUG - 2022-07-18 05:42:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:42:11 --> Controller Class Initialized
INFO - 2022-07-18 05:42:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:42:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:42:11 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-18 05:42:11 --> Final output sent to browser
DEBUG - 2022-07-18 05:42:11 --> Total execution time: 0.0483
INFO - 2022-07-18 05:42:13 --> Config Class Initialized
INFO - 2022-07-18 05:42:13 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:42:13 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:42:13 --> Utf8 Class Initialized
INFO - 2022-07-18 05:42:13 --> URI Class Initialized
INFO - 2022-07-18 05:42:13 --> Router Class Initialized
INFO - 2022-07-18 05:42:13 --> Output Class Initialized
INFO - 2022-07-18 05:42:13 --> Security Class Initialized
DEBUG - 2022-07-18 05:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:42:13 --> Input Class Initialized
INFO - 2022-07-18 05:42:13 --> Language Class Initialized
INFO - 2022-07-18 05:42:13 --> Loader Class Initialized
INFO - 2022-07-18 05:42:13 --> Helper loaded: url_helper
INFO - 2022-07-18 05:42:13 --> Helper loaded: file_helper
INFO - 2022-07-18 05:42:13 --> Database Driver Class Initialized
INFO - 2022-07-18 05:42:13 --> Email Class Initialized
DEBUG - 2022-07-18 05:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:42:13 --> Controller Class Initialized
INFO - 2022-07-18 05:42:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:42:13 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:42:13 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-18 05:42:13 --> Final output sent to browser
DEBUG - 2022-07-18 05:42:13 --> Total execution time: 0.0179
INFO - 2022-07-18 05:44:27 --> Config Class Initialized
INFO - 2022-07-18 05:44:27 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:44:27 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:44:27 --> Utf8 Class Initialized
INFO - 2022-07-18 05:44:27 --> URI Class Initialized
INFO - 2022-07-18 05:44:27 --> Router Class Initialized
INFO - 2022-07-18 05:44:27 --> Output Class Initialized
INFO - 2022-07-18 05:44:27 --> Security Class Initialized
DEBUG - 2022-07-18 05:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:44:27 --> Input Class Initialized
INFO - 2022-07-18 05:44:27 --> Language Class Initialized
INFO - 2022-07-18 05:44:27 --> Loader Class Initialized
INFO - 2022-07-18 05:44:27 --> Helper loaded: url_helper
INFO - 2022-07-18 05:44:27 --> Helper loaded: file_helper
INFO - 2022-07-18 05:44:27 --> Database Driver Class Initialized
INFO - 2022-07-18 05:44:27 --> Email Class Initialized
DEBUG - 2022-07-18 05:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:44:27 --> Controller Class Initialized
INFO - 2022-07-18 05:44:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:44:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 05:44:27 --> Severity: Notice --> Undefined variable: time_est C:\wamp64\www\qr\application\controllers\Tokenctrl.php 504
ERROR - 2022-07-18 05:44:27 --> Query error: Column 'td_est_time' cannot be null - Invalid query: INSERT INTO `tokendetails` (`td_tk`, `td_cs`, `td_visited_date`, `td_est_time`) VALUES (4, 0, '2022-07-18', NULL)
INFO - 2022-07-18 05:44:27 --> Language file loaded: language/english/db_lang.php
INFO - 2022-07-18 05:45:14 --> Config Class Initialized
INFO - 2022-07-18 05:45:14 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:45:14 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:45:14 --> Utf8 Class Initialized
INFO - 2022-07-18 05:45:14 --> URI Class Initialized
INFO - 2022-07-18 05:45:14 --> Router Class Initialized
INFO - 2022-07-18 05:45:14 --> Output Class Initialized
INFO - 2022-07-18 05:45:14 --> Security Class Initialized
DEBUG - 2022-07-18 05:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:45:14 --> Input Class Initialized
INFO - 2022-07-18 05:45:14 --> Language Class Initialized
INFO - 2022-07-18 05:45:14 --> Loader Class Initialized
INFO - 2022-07-18 05:45:14 --> Helper loaded: url_helper
INFO - 2022-07-18 05:45:14 --> Helper loaded: file_helper
INFO - 2022-07-18 05:45:14 --> Database Driver Class Initialized
INFO - 2022-07-18 05:45:14 --> Email Class Initialized
DEBUG - 2022-07-18 05:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:45:14 --> Controller Class Initialized
INFO - 2022-07-18 05:45:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:45:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-07-18 05:45:14 --> insertedINSERT INTO `tokendetails` (`td_tk`, `td_cs`, `td_visited_date`) VALUES (4, 0, '2022-07-18')
ERROR - 2022-07-18 05:45:14 --> Severity: Notice --> Undefined variable: time_est C:\wamp64\www\qr\application\controllers\Tokenctrl.php 508
ERROR - 2022-07-18 05:45:14 --> Severity: Notice --> Undefined variable: time_est C:\wamp64\www\qr\application\controllers\Tokenctrl.php 512
INFO - 2022-07-18 05:45:14 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-18 05:45:14 --> Final output sent to browser
DEBUG - 2022-07-18 05:45:14 --> Total execution time: 0.1373
INFO - 2022-07-18 05:45:16 --> Config Class Initialized
INFO - 2022-07-18 05:45:16 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:45:16 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:45:16 --> Utf8 Class Initialized
INFO - 2022-07-18 05:45:16 --> URI Class Initialized
INFO - 2022-07-18 05:45:16 --> Router Class Initialized
INFO - 2022-07-18 05:45:16 --> Output Class Initialized
INFO - 2022-07-18 05:45:16 --> Security Class Initialized
DEBUG - 2022-07-18 05:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:45:16 --> Input Class Initialized
INFO - 2022-07-18 05:45:16 --> Language Class Initialized
INFO - 2022-07-18 05:45:16 --> Loader Class Initialized
INFO - 2022-07-18 05:45:16 --> Helper loaded: url_helper
INFO - 2022-07-18 05:45:16 --> Helper loaded: file_helper
INFO - 2022-07-18 05:45:16 --> Database Driver Class Initialized
INFO - 2022-07-18 05:45:16 --> Email Class Initialized
DEBUG - 2022-07-18 05:45:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:45:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:45:16 --> Controller Class Initialized
INFO - 2022-07-18 05:45:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:45:16 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:45:16 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-18 05:45:16 --> Final output sent to browser
DEBUG - 2022-07-18 05:45:16 --> Total execution time: 0.1790
INFO - 2022-07-18 05:45:17 --> Config Class Initialized
INFO - 2022-07-18 05:45:17 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:45:17 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:45:17 --> Utf8 Class Initialized
INFO - 2022-07-18 05:45:17 --> URI Class Initialized
INFO - 2022-07-18 05:45:17 --> Router Class Initialized
INFO - 2022-07-18 05:45:17 --> Output Class Initialized
INFO - 2022-07-18 05:45:17 --> Security Class Initialized
DEBUG - 2022-07-18 05:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:45:17 --> Input Class Initialized
INFO - 2022-07-18 05:45:17 --> Language Class Initialized
INFO - 2022-07-18 05:45:17 --> Loader Class Initialized
INFO - 2022-07-18 05:45:17 --> Helper loaded: url_helper
INFO - 2022-07-18 05:45:17 --> Helper loaded: file_helper
INFO - 2022-07-18 05:45:17 --> Database Driver Class Initialized
INFO - 2022-07-18 05:45:17 --> Email Class Initialized
DEBUG - 2022-07-18 05:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:45:17 --> Controller Class Initialized
INFO - 2022-07-18 05:45:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:45:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:45:17 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-18 05:45:17 --> Final output sent to browser
DEBUG - 2022-07-18 05:45:17 --> Total execution time: 0.0181
INFO - 2022-07-18 05:47:13 --> Config Class Initialized
INFO - 2022-07-18 05:47:13 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:47:13 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:47:13 --> Utf8 Class Initialized
INFO - 2022-07-18 05:47:13 --> URI Class Initialized
INFO - 2022-07-18 05:47:13 --> Router Class Initialized
INFO - 2022-07-18 05:47:13 --> Output Class Initialized
INFO - 2022-07-18 05:47:13 --> Security Class Initialized
DEBUG - 2022-07-18 05:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:47:13 --> Input Class Initialized
INFO - 2022-07-18 05:47:13 --> Language Class Initialized
INFO - 2022-07-18 05:47:13 --> Loader Class Initialized
INFO - 2022-07-18 05:47:13 --> Helper loaded: url_helper
INFO - 2022-07-18 05:47:13 --> Helper loaded: file_helper
INFO - 2022-07-18 05:47:13 --> Database Driver Class Initialized
INFO - 2022-07-18 05:47:13 --> Email Class Initialized
DEBUG - 2022-07-18 05:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:47:13 --> Controller Class Initialized
INFO - 2022-07-18 05:47:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:47:13 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:47:13 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-18 05:47:13 --> Final output sent to browser
DEBUG - 2022-07-18 05:47:13 --> Total execution time: 0.1523
INFO - 2022-07-18 05:47:15 --> Config Class Initialized
INFO - 2022-07-18 05:47:15 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:47:15 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:47:15 --> Utf8 Class Initialized
INFO - 2022-07-18 05:47:15 --> URI Class Initialized
INFO - 2022-07-18 05:47:15 --> Router Class Initialized
INFO - 2022-07-18 05:47:15 --> Output Class Initialized
INFO - 2022-07-18 05:47:15 --> Security Class Initialized
DEBUG - 2022-07-18 05:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:47:15 --> Input Class Initialized
INFO - 2022-07-18 05:47:15 --> Language Class Initialized
INFO - 2022-07-18 05:47:15 --> Loader Class Initialized
INFO - 2022-07-18 05:47:15 --> Helper loaded: url_helper
INFO - 2022-07-18 05:47:15 --> Helper loaded: file_helper
INFO - 2022-07-18 05:47:15 --> Database Driver Class Initialized
INFO - 2022-07-18 05:47:15 --> Email Class Initialized
DEBUG - 2022-07-18 05:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:47:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:47:15 --> Controller Class Initialized
INFO - 2022-07-18 05:47:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:47:15 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:47:15 --> Final output sent to browser
DEBUG - 2022-07-18 05:47:15 --> Total execution time: 0.0192
INFO - 2022-07-18 05:47:25 --> Config Class Initialized
INFO - 2022-07-18 05:47:25 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:47:25 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:47:25 --> Utf8 Class Initialized
INFO - 2022-07-18 05:47:25 --> URI Class Initialized
INFO - 2022-07-18 05:47:25 --> Router Class Initialized
INFO - 2022-07-18 05:47:25 --> Output Class Initialized
INFO - 2022-07-18 05:47:25 --> Security Class Initialized
DEBUG - 2022-07-18 05:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:47:25 --> Input Class Initialized
INFO - 2022-07-18 05:47:25 --> Language Class Initialized
INFO - 2022-07-18 05:47:25 --> Loader Class Initialized
INFO - 2022-07-18 05:47:25 --> Helper loaded: url_helper
INFO - 2022-07-18 05:47:25 --> Helper loaded: file_helper
INFO - 2022-07-18 05:47:25 --> Database Driver Class Initialized
INFO - 2022-07-18 05:47:25 --> Email Class Initialized
DEBUG - 2022-07-18 05:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:47:25 --> Controller Class Initialized
INFO - 2022-07-18 05:47:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:47:25 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:17:26 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:17:26 --> Final output sent to browser
DEBUG - 2022-07-18 11:17:26 --> Total execution time: 0.1613
INFO - 2022-07-18 05:47:28 --> Config Class Initialized
INFO - 2022-07-18 05:47:28 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:47:28 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:47:28 --> Utf8 Class Initialized
INFO - 2022-07-18 05:47:28 --> URI Class Initialized
INFO - 2022-07-18 05:47:28 --> Router Class Initialized
INFO - 2022-07-18 05:47:28 --> Output Class Initialized
INFO - 2022-07-18 05:47:28 --> Security Class Initialized
DEBUG - 2022-07-18 05:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:47:28 --> Input Class Initialized
INFO - 2022-07-18 05:47:28 --> Language Class Initialized
INFO - 2022-07-18 05:47:28 --> Loader Class Initialized
INFO - 2022-07-18 05:47:28 --> Helper loaded: url_helper
INFO - 2022-07-18 05:47:28 --> Helper loaded: file_helper
INFO - 2022-07-18 05:47:28 --> Database Driver Class Initialized
INFO - 2022-07-18 05:47:28 --> Email Class Initialized
DEBUG - 2022-07-18 05:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:47:28 --> Controller Class Initialized
INFO - 2022-07-18 05:47:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:47:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 11:17:28 --> Severity: Notice --> Trying to get property 'td_start_time' of non-object C:\wamp64\www\qr\application\controllers\Tokenctrl.php 121
INFO - 2022-07-18 11:17:28 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:17:28 --> Final output sent to browser
DEBUG - 2022-07-18 11:17:28 --> Total execution time: 0.0196
INFO - 2022-07-18 05:47:42 --> Config Class Initialized
INFO - 2022-07-18 05:47:42 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:47:42 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:47:42 --> Utf8 Class Initialized
INFO - 2022-07-18 05:47:42 --> URI Class Initialized
INFO - 2022-07-18 05:47:42 --> Router Class Initialized
INFO - 2022-07-18 05:47:42 --> Output Class Initialized
INFO - 2022-07-18 05:47:42 --> Security Class Initialized
DEBUG - 2022-07-18 05:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:47:42 --> Input Class Initialized
INFO - 2022-07-18 05:47:42 --> Language Class Initialized
INFO - 2022-07-18 05:47:42 --> Loader Class Initialized
INFO - 2022-07-18 05:47:42 --> Helper loaded: url_helper
INFO - 2022-07-18 05:47:42 --> Helper loaded: file_helper
INFO - 2022-07-18 05:47:42 --> Database Driver Class Initialized
INFO - 2022-07-18 05:47:42 --> Email Class Initialized
DEBUG - 2022-07-18 05:47:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:47:42 --> Controller Class Initialized
INFO - 2022-07-18 05:47:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:47:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 11:17:42 --> Severity: Notice --> Trying to get property 'td_start_time' of non-object C:\wamp64\www\qr\application\controllers\Tokenctrl.php 121
INFO - 2022-07-18 11:17:42 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:17:42 --> Final output sent to browser
DEBUG - 2022-07-18 11:17:42 --> Total execution time: 0.1452
INFO - 2022-07-18 05:47:59 --> Config Class Initialized
INFO - 2022-07-18 05:47:59 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:47:59 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:47:59 --> Utf8 Class Initialized
INFO - 2022-07-18 05:47:59 --> URI Class Initialized
INFO - 2022-07-18 05:47:59 --> Router Class Initialized
INFO - 2022-07-18 05:47:59 --> Output Class Initialized
INFO - 2022-07-18 05:47:59 --> Security Class Initialized
DEBUG - 2022-07-18 05:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:47:59 --> Input Class Initialized
INFO - 2022-07-18 05:47:59 --> Language Class Initialized
INFO - 2022-07-18 05:47:59 --> Loader Class Initialized
INFO - 2022-07-18 05:47:59 --> Helper loaded: url_helper
INFO - 2022-07-18 05:47:59 --> Helper loaded: file_helper
INFO - 2022-07-18 05:47:59 --> Database Driver Class Initialized
INFO - 2022-07-18 05:47:59 --> Email Class Initialized
DEBUG - 2022-07-18 05:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:47:59 --> Controller Class Initialized
INFO - 2022-07-18 05:47:59 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:47:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 11:17:59 --> Severity: Notice --> Trying to get property 'td_start_time' of non-object C:\wamp64\www\qr\application\controllers\Tokenctrl.php 121
INFO - 2022-07-18 11:17:59 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:17:59 --> Final output sent to browser
DEBUG - 2022-07-18 11:17:59 --> Total execution time: 0.0200
INFO - 2022-07-18 05:51:13 --> Config Class Initialized
INFO - 2022-07-18 05:51:13 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:51:13 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:51:13 --> Utf8 Class Initialized
INFO - 2022-07-18 05:51:13 --> URI Class Initialized
INFO - 2022-07-18 05:51:13 --> Router Class Initialized
INFO - 2022-07-18 05:51:13 --> Output Class Initialized
INFO - 2022-07-18 05:51:13 --> Security Class Initialized
DEBUG - 2022-07-18 05:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:51:13 --> Input Class Initialized
INFO - 2022-07-18 05:51:13 --> Language Class Initialized
INFO - 2022-07-18 05:51:13 --> Loader Class Initialized
INFO - 2022-07-18 05:51:13 --> Helper loaded: url_helper
INFO - 2022-07-18 05:51:13 --> Helper loaded: file_helper
INFO - 2022-07-18 05:51:13 --> Database Driver Class Initialized
INFO - 2022-07-18 05:51:13 --> Email Class Initialized
DEBUG - 2022-07-18 05:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:51:13 --> Controller Class Initialized
INFO - 2022-07-18 05:51:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:51:13 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:51:13 --> Final output sent to browser
DEBUG - 2022-07-18 05:51:13 --> Total execution time: 0.0425
INFO - 2022-07-18 05:51:13 --> Config Class Initialized
INFO - 2022-07-18 05:51:13 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:51:13 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:51:13 --> Utf8 Class Initialized
INFO - 2022-07-18 05:51:13 --> URI Class Initialized
INFO - 2022-07-18 05:51:13 --> Router Class Initialized
INFO - 2022-07-18 05:51:13 --> Output Class Initialized
INFO - 2022-07-18 05:51:13 --> Security Class Initialized
DEBUG - 2022-07-18 05:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:51:13 --> Input Class Initialized
INFO - 2022-07-18 05:51:13 --> Language Class Initialized
INFO - 2022-07-18 05:51:13 --> Loader Class Initialized
INFO - 2022-07-18 05:51:13 --> Helper loaded: url_helper
INFO - 2022-07-18 05:51:13 --> Helper loaded: file_helper
INFO - 2022-07-18 05:51:13 --> Database Driver Class Initialized
INFO - 2022-07-18 05:51:13 --> Email Class Initialized
DEBUG - 2022-07-18 05:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:51:13 --> Controller Class Initialized
INFO - 2022-07-18 05:51:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:51:13 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:51:13 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-18 05:51:13 --> Final output sent to browser
DEBUG - 2022-07-18 05:51:13 --> Total execution time: 0.0165
INFO - 2022-07-18 05:51:15 --> Config Class Initialized
INFO - 2022-07-18 05:51:15 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:51:15 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:51:15 --> Utf8 Class Initialized
INFO - 2022-07-18 05:51:15 --> URI Class Initialized
INFO - 2022-07-18 05:51:15 --> Router Class Initialized
INFO - 2022-07-18 05:51:15 --> Output Class Initialized
INFO - 2022-07-18 05:51:15 --> Security Class Initialized
DEBUG - 2022-07-18 05:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:51:15 --> Input Class Initialized
INFO - 2022-07-18 05:51:15 --> Language Class Initialized
INFO - 2022-07-18 05:51:15 --> Loader Class Initialized
INFO - 2022-07-18 05:51:15 --> Helper loaded: url_helper
INFO - 2022-07-18 05:51:15 --> Helper loaded: file_helper
INFO - 2022-07-18 05:51:15 --> Database Driver Class Initialized
INFO - 2022-07-18 05:51:15 --> Email Class Initialized
DEBUG - 2022-07-18 05:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:51:15 --> Controller Class Initialized
INFO - 2022-07-18 05:51:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:51:15 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:51:15 --> Final output sent to browser
DEBUG - 2022-07-18 05:51:15 --> Total execution time: 0.0473
INFO - 2022-07-18 05:51:18 --> Config Class Initialized
INFO - 2022-07-18 05:51:18 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:51:18 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:51:18 --> Utf8 Class Initialized
INFO - 2022-07-18 05:51:18 --> URI Class Initialized
INFO - 2022-07-18 05:51:18 --> Router Class Initialized
INFO - 2022-07-18 05:51:18 --> Output Class Initialized
INFO - 2022-07-18 05:51:18 --> Security Class Initialized
DEBUG - 2022-07-18 05:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:51:18 --> Input Class Initialized
INFO - 2022-07-18 05:51:18 --> Language Class Initialized
INFO - 2022-07-18 05:51:18 --> Loader Class Initialized
INFO - 2022-07-18 05:51:18 --> Helper loaded: url_helper
INFO - 2022-07-18 05:51:18 --> Helper loaded: file_helper
INFO - 2022-07-18 05:51:18 --> Database Driver Class Initialized
INFO - 2022-07-18 05:51:18 --> Email Class Initialized
DEBUG - 2022-07-18 05:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:51:18 --> Controller Class Initialized
INFO - 2022-07-18 05:51:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:51:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 11:21:18 --> Severity: error --> Exception: syntax error, unexpected ')' C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 527
INFO - 2022-07-18 05:52:37 --> Config Class Initialized
INFO - 2022-07-18 05:52:37 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:52:37 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:52:37 --> Utf8 Class Initialized
INFO - 2022-07-18 05:52:37 --> URI Class Initialized
INFO - 2022-07-18 05:52:37 --> Router Class Initialized
INFO - 2022-07-18 05:52:37 --> Output Class Initialized
INFO - 2022-07-18 05:52:37 --> Security Class Initialized
DEBUG - 2022-07-18 05:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:52:37 --> Input Class Initialized
INFO - 2022-07-18 05:52:37 --> Language Class Initialized
INFO - 2022-07-18 05:52:37 --> Loader Class Initialized
INFO - 2022-07-18 05:52:37 --> Helper loaded: url_helper
INFO - 2022-07-18 05:52:37 --> Helper loaded: file_helper
INFO - 2022-07-18 05:52:37 --> Database Driver Class Initialized
INFO - 2022-07-18 05:52:37 --> Email Class Initialized
DEBUG - 2022-07-18 05:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:52:37 --> Controller Class Initialized
INFO - 2022-07-18 05:52:37 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:52:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 11:22:37 --> Severity: error --> Exception: syntax error, unexpected '?>' C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 527
INFO - 2022-07-18 05:52:38 --> Config Class Initialized
INFO - 2022-07-18 05:52:38 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:52:38 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:52:38 --> Utf8 Class Initialized
INFO - 2022-07-18 05:52:38 --> URI Class Initialized
INFO - 2022-07-18 05:52:38 --> Router Class Initialized
INFO - 2022-07-18 05:52:38 --> Output Class Initialized
INFO - 2022-07-18 05:52:38 --> Security Class Initialized
DEBUG - 2022-07-18 05:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:52:38 --> Input Class Initialized
INFO - 2022-07-18 05:52:38 --> Language Class Initialized
INFO - 2022-07-18 05:52:38 --> Loader Class Initialized
INFO - 2022-07-18 05:52:38 --> Helper loaded: url_helper
INFO - 2022-07-18 05:52:38 --> Helper loaded: file_helper
INFO - 2022-07-18 05:52:38 --> Database Driver Class Initialized
INFO - 2022-07-18 05:52:38 --> Email Class Initialized
DEBUG - 2022-07-18 05:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:52:38 --> Controller Class Initialized
INFO - 2022-07-18 05:52:38 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:52:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 11:22:38 --> Severity: error --> Exception: syntax error, unexpected '?>' C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 527
INFO - 2022-07-18 05:53:15 --> Config Class Initialized
INFO - 2022-07-18 05:53:15 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:53:15 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:53:15 --> Utf8 Class Initialized
INFO - 2022-07-18 05:53:15 --> URI Class Initialized
INFO - 2022-07-18 05:53:15 --> Router Class Initialized
INFO - 2022-07-18 05:53:15 --> Output Class Initialized
INFO - 2022-07-18 05:53:15 --> Security Class Initialized
DEBUG - 2022-07-18 05:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:53:15 --> Input Class Initialized
INFO - 2022-07-18 05:53:15 --> Language Class Initialized
INFO - 2022-07-18 05:53:15 --> Loader Class Initialized
INFO - 2022-07-18 05:53:15 --> Helper loaded: url_helper
INFO - 2022-07-18 05:53:15 --> Helper loaded: file_helper
INFO - 2022-07-18 05:53:15 --> Database Driver Class Initialized
INFO - 2022-07-18 05:53:15 --> Email Class Initialized
DEBUG - 2022-07-18 05:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:53:15 --> Controller Class Initialized
INFO - 2022-07-18 05:53:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:53:15 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:23:15 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:23:15 --> Final output sent to browser
DEBUG - 2022-07-18 11:23:15 --> Total execution time: 0.1987
INFO - 2022-07-18 05:53:18 --> Config Class Initialized
INFO - 2022-07-18 05:53:18 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:53:18 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:53:18 --> Utf8 Class Initialized
INFO - 2022-07-18 05:53:18 --> URI Class Initialized
INFO - 2022-07-18 05:53:18 --> Router Class Initialized
INFO - 2022-07-18 05:53:18 --> Output Class Initialized
INFO - 2022-07-18 05:53:18 --> Security Class Initialized
DEBUG - 2022-07-18 05:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:53:18 --> Input Class Initialized
INFO - 2022-07-18 05:53:18 --> Language Class Initialized
INFO - 2022-07-18 05:53:18 --> Loader Class Initialized
INFO - 2022-07-18 05:53:18 --> Helper loaded: url_helper
INFO - 2022-07-18 05:53:18 --> Helper loaded: file_helper
INFO - 2022-07-18 05:53:18 --> Database Driver Class Initialized
INFO - 2022-07-18 05:53:18 --> Email Class Initialized
DEBUG - 2022-07-18 05:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:53:18 --> Controller Class Initialized
INFO - 2022-07-18 05:53:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:53:18 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:53:18 --> Final output sent to browser
DEBUG - 2022-07-18 05:53:18 --> Total execution time: 0.0170
INFO - 2022-07-18 05:53:18 --> Config Class Initialized
INFO - 2022-07-18 05:53:18 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:53:18 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:53:18 --> Utf8 Class Initialized
INFO - 2022-07-18 05:53:18 --> URI Class Initialized
INFO - 2022-07-18 05:53:18 --> Router Class Initialized
INFO - 2022-07-18 05:53:18 --> Output Class Initialized
INFO - 2022-07-18 05:53:18 --> Security Class Initialized
DEBUG - 2022-07-18 05:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:53:18 --> Input Class Initialized
INFO - 2022-07-18 05:53:18 --> Language Class Initialized
INFO - 2022-07-18 05:53:18 --> Loader Class Initialized
INFO - 2022-07-18 05:53:18 --> Helper loaded: url_helper
INFO - 2022-07-18 05:53:18 --> Helper loaded: file_helper
INFO - 2022-07-18 05:53:18 --> Database Driver Class Initialized
INFO - 2022-07-18 05:53:18 --> Email Class Initialized
DEBUG - 2022-07-18 05:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:53:18 --> Controller Class Initialized
INFO - 2022-07-18 05:53:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:53:18 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:53:18 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-18 05:53:18 --> Final output sent to browser
DEBUG - 2022-07-18 05:53:18 --> Total execution time: 0.1921
INFO - 2022-07-18 05:53:20 --> Config Class Initialized
INFO - 2022-07-18 05:53:20 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:53:20 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:53:20 --> Utf8 Class Initialized
INFO - 2022-07-18 05:53:20 --> URI Class Initialized
INFO - 2022-07-18 05:53:20 --> Router Class Initialized
INFO - 2022-07-18 05:53:20 --> Output Class Initialized
INFO - 2022-07-18 05:53:20 --> Security Class Initialized
DEBUG - 2022-07-18 05:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:53:20 --> Input Class Initialized
INFO - 2022-07-18 05:53:20 --> Language Class Initialized
INFO - 2022-07-18 05:53:20 --> Loader Class Initialized
INFO - 2022-07-18 05:53:20 --> Helper loaded: url_helper
INFO - 2022-07-18 05:53:20 --> Helper loaded: file_helper
INFO - 2022-07-18 05:53:20 --> Database Driver Class Initialized
INFO - 2022-07-18 05:53:20 --> Email Class Initialized
DEBUG - 2022-07-18 05:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:53:20 --> Controller Class Initialized
INFO - 2022-07-18 05:53:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:53:20 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:53:20 --> Final output sent to browser
DEBUG - 2022-07-18 05:53:20 --> Total execution time: 0.0167
INFO - 2022-07-18 05:53:23 --> Config Class Initialized
INFO - 2022-07-18 05:53:23 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:53:23 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:53:23 --> Utf8 Class Initialized
INFO - 2022-07-18 05:53:23 --> URI Class Initialized
INFO - 2022-07-18 05:53:23 --> Router Class Initialized
INFO - 2022-07-18 05:53:23 --> Output Class Initialized
INFO - 2022-07-18 05:53:23 --> Security Class Initialized
DEBUG - 2022-07-18 05:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:53:23 --> Input Class Initialized
INFO - 2022-07-18 05:53:23 --> Language Class Initialized
INFO - 2022-07-18 05:53:23 --> Loader Class Initialized
INFO - 2022-07-18 05:53:23 --> Helper loaded: url_helper
INFO - 2022-07-18 05:53:23 --> Helper loaded: file_helper
INFO - 2022-07-18 05:53:23 --> Database Driver Class Initialized
INFO - 2022-07-18 05:53:23 --> Email Class Initialized
DEBUG - 2022-07-18 05:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:53:23 --> Controller Class Initialized
INFO - 2022-07-18 05:53:23 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:53:23 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:23:23 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:23:23 --> Final output sent to browser
DEBUG - 2022-07-18 11:23:23 --> Total execution time: 0.1461
INFO - 2022-07-18 05:53:25 --> Config Class Initialized
INFO - 2022-07-18 05:53:25 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:53:25 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:53:25 --> Utf8 Class Initialized
INFO - 2022-07-18 05:53:25 --> URI Class Initialized
INFO - 2022-07-18 05:53:25 --> Router Class Initialized
INFO - 2022-07-18 05:53:25 --> Output Class Initialized
INFO - 2022-07-18 05:53:25 --> Security Class Initialized
DEBUG - 2022-07-18 05:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:53:25 --> Input Class Initialized
INFO - 2022-07-18 05:53:25 --> Language Class Initialized
INFO - 2022-07-18 05:53:25 --> Loader Class Initialized
INFO - 2022-07-18 05:53:25 --> Helper loaded: url_helper
INFO - 2022-07-18 05:53:25 --> Helper loaded: file_helper
INFO - 2022-07-18 05:53:25 --> Database Driver Class Initialized
INFO - 2022-07-18 05:53:25 --> Email Class Initialized
DEBUG - 2022-07-18 05:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:53:25 --> Controller Class Initialized
INFO - 2022-07-18 05:53:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:53:25 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:23:25 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:23:25 --> Final output sent to browser
DEBUG - 2022-07-18 11:23:25 --> Total execution time: 0.0492
INFO - 2022-07-18 05:55:17 --> Config Class Initialized
INFO - 2022-07-18 05:55:17 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:55:17 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:55:17 --> Utf8 Class Initialized
INFO - 2022-07-18 05:55:17 --> URI Class Initialized
INFO - 2022-07-18 05:55:17 --> Router Class Initialized
INFO - 2022-07-18 05:55:17 --> Output Class Initialized
INFO - 2022-07-18 05:55:17 --> Security Class Initialized
DEBUG - 2022-07-18 05:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:55:17 --> Input Class Initialized
INFO - 2022-07-18 05:55:17 --> Language Class Initialized
INFO - 2022-07-18 05:55:17 --> Loader Class Initialized
INFO - 2022-07-18 05:55:17 --> Helper loaded: url_helper
INFO - 2022-07-18 05:55:17 --> Helper loaded: file_helper
INFO - 2022-07-18 05:55:17 --> Database Driver Class Initialized
INFO - 2022-07-18 05:55:18 --> Email Class Initialized
DEBUG - 2022-07-18 05:55:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:55:18 --> Controller Class Initialized
INFO - 2022-07-18 05:55:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:55:18 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:25:18 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:25:18 --> Final output sent to browser
DEBUG - 2022-07-18 11:25:18 --> Total execution time: 0.1060
INFO - 2022-07-18 05:55:19 --> Config Class Initialized
INFO - 2022-07-18 05:55:19 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:55:19 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:55:19 --> Utf8 Class Initialized
INFO - 2022-07-18 05:55:19 --> URI Class Initialized
INFO - 2022-07-18 05:55:19 --> Router Class Initialized
INFO - 2022-07-18 05:55:19 --> Output Class Initialized
INFO - 2022-07-18 05:55:19 --> Security Class Initialized
DEBUG - 2022-07-18 05:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:55:19 --> Input Class Initialized
INFO - 2022-07-18 05:55:19 --> Language Class Initialized
INFO - 2022-07-18 05:55:19 --> Loader Class Initialized
INFO - 2022-07-18 05:55:19 --> Helper loaded: url_helper
INFO - 2022-07-18 05:55:19 --> Helper loaded: file_helper
INFO - 2022-07-18 05:55:19 --> Database Driver Class Initialized
INFO - 2022-07-18 05:55:19 --> Email Class Initialized
DEBUG - 2022-07-18 05:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:55:19 --> Controller Class Initialized
INFO - 2022-07-18 05:55:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:55:19 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:25:19 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:25:19 --> Final output sent to browser
DEBUG - 2022-07-18 11:25:19 --> Total execution time: 0.1818
INFO - 2022-07-18 05:55:32 --> Config Class Initialized
INFO - 2022-07-18 05:55:32 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:55:32 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:55:32 --> Utf8 Class Initialized
INFO - 2022-07-18 05:55:32 --> URI Class Initialized
INFO - 2022-07-18 05:55:32 --> Router Class Initialized
INFO - 2022-07-18 05:55:32 --> Output Class Initialized
INFO - 2022-07-18 05:55:32 --> Security Class Initialized
DEBUG - 2022-07-18 05:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:55:32 --> Input Class Initialized
INFO - 2022-07-18 05:55:32 --> Language Class Initialized
INFO - 2022-07-18 05:55:32 --> Loader Class Initialized
INFO - 2022-07-18 05:55:32 --> Helper loaded: url_helper
INFO - 2022-07-18 05:55:32 --> Helper loaded: file_helper
INFO - 2022-07-18 05:55:32 --> Database Driver Class Initialized
INFO - 2022-07-18 05:55:32 --> Email Class Initialized
DEBUG - 2022-07-18 05:55:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:55:32 --> Controller Class Initialized
INFO - 2022-07-18 05:55:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:55:32 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:55:32 --> Final output sent to browser
DEBUG - 2022-07-18 05:55:32 --> Total execution time: 0.1539
INFO - 2022-07-18 05:55:32 --> Config Class Initialized
INFO - 2022-07-18 05:55:32 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:55:32 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:55:32 --> Utf8 Class Initialized
INFO - 2022-07-18 05:55:32 --> URI Class Initialized
INFO - 2022-07-18 05:55:32 --> Router Class Initialized
INFO - 2022-07-18 05:55:32 --> Output Class Initialized
INFO - 2022-07-18 05:55:32 --> Security Class Initialized
DEBUG - 2022-07-18 05:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:55:32 --> Input Class Initialized
INFO - 2022-07-18 05:55:32 --> Language Class Initialized
INFO - 2022-07-18 05:55:32 --> Loader Class Initialized
INFO - 2022-07-18 05:55:32 --> Helper loaded: url_helper
INFO - 2022-07-18 05:55:32 --> Helper loaded: file_helper
INFO - 2022-07-18 05:55:32 --> Database Driver Class Initialized
INFO - 2022-07-18 05:55:32 --> Email Class Initialized
DEBUG - 2022-07-18 05:55:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:55:32 --> Controller Class Initialized
INFO - 2022-07-18 05:55:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:55:32 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:55:32 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-18 05:55:32 --> Final output sent to browser
DEBUG - 2022-07-18 05:55:32 --> Total execution time: 0.0155
INFO - 2022-07-18 05:55:36 --> Config Class Initialized
INFO - 2022-07-18 05:55:36 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:55:36 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:55:36 --> Utf8 Class Initialized
INFO - 2022-07-18 05:55:36 --> URI Class Initialized
INFO - 2022-07-18 05:55:36 --> Router Class Initialized
INFO - 2022-07-18 05:55:36 --> Output Class Initialized
INFO - 2022-07-18 05:55:36 --> Security Class Initialized
DEBUG - 2022-07-18 05:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:55:36 --> Input Class Initialized
INFO - 2022-07-18 05:55:36 --> Language Class Initialized
INFO - 2022-07-18 05:55:36 --> Loader Class Initialized
INFO - 2022-07-18 05:55:36 --> Helper loaded: url_helper
INFO - 2022-07-18 05:55:36 --> Helper loaded: file_helper
INFO - 2022-07-18 05:55:36 --> Database Driver Class Initialized
INFO - 2022-07-18 05:55:36 --> Email Class Initialized
DEBUG - 2022-07-18 05:55:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:55:36 --> Controller Class Initialized
INFO - 2022-07-18 05:55:36 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:55:36 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:55:36 --> Final output sent to browser
DEBUG - 2022-07-18 05:55:36 --> Total execution time: 0.0174
INFO - 2022-07-18 05:55:38 --> Config Class Initialized
INFO - 2022-07-18 05:55:38 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:55:38 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:55:38 --> Utf8 Class Initialized
INFO - 2022-07-18 05:55:38 --> URI Class Initialized
INFO - 2022-07-18 05:55:38 --> Router Class Initialized
INFO - 2022-07-18 05:55:38 --> Output Class Initialized
INFO - 2022-07-18 05:55:38 --> Security Class Initialized
DEBUG - 2022-07-18 05:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:55:38 --> Input Class Initialized
INFO - 2022-07-18 05:55:38 --> Language Class Initialized
INFO - 2022-07-18 05:55:38 --> Loader Class Initialized
INFO - 2022-07-18 05:55:38 --> Helper loaded: url_helper
INFO - 2022-07-18 05:55:38 --> Helper loaded: file_helper
INFO - 2022-07-18 05:55:38 --> Database Driver Class Initialized
INFO - 2022-07-18 05:55:38 --> Email Class Initialized
DEBUG - 2022-07-18 05:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:55:38 --> Controller Class Initialized
INFO - 2022-07-18 05:55:38 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:55:38 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:25:38 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:25:38 --> Final output sent to browser
DEBUG - 2022-07-18 11:25:38 --> Total execution time: 0.0414
INFO - 2022-07-18 05:55:46 --> Config Class Initialized
INFO - 2022-07-18 05:55:46 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:55:46 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:55:46 --> Utf8 Class Initialized
INFO - 2022-07-18 05:55:46 --> URI Class Initialized
INFO - 2022-07-18 05:55:46 --> Router Class Initialized
INFO - 2022-07-18 05:55:46 --> Output Class Initialized
INFO - 2022-07-18 05:55:46 --> Security Class Initialized
DEBUG - 2022-07-18 05:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:55:46 --> Input Class Initialized
INFO - 2022-07-18 05:55:46 --> Language Class Initialized
INFO - 2022-07-18 05:55:46 --> Loader Class Initialized
INFO - 2022-07-18 05:55:46 --> Helper loaded: url_helper
INFO - 2022-07-18 05:55:46 --> Helper loaded: file_helper
INFO - 2022-07-18 05:55:46 --> Database Driver Class Initialized
INFO - 2022-07-18 05:55:46 --> Email Class Initialized
DEBUG - 2022-07-18 05:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:55:46 --> Controller Class Initialized
INFO - 2022-07-18 05:55:46 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:55:46 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:25:46 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:25:46 --> Final output sent to browser
DEBUG - 2022-07-18 11:25:46 --> Total execution time: 0.0298
INFO - 2022-07-18 05:55:55 --> Config Class Initialized
INFO - 2022-07-18 05:55:55 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:55:55 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:55:55 --> Utf8 Class Initialized
INFO - 2022-07-18 05:55:55 --> URI Class Initialized
INFO - 2022-07-18 05:55:55 --> Router Class Initialized
INFO - 2022-07-18 05:55:55 --> Output Class Initialized
INFO - 2022-07-18 05:55:55 --> Security Class Initialized
DEBUG - 2022-07-18 05:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:55:55 --> Input Class Initialized
INFO - 2022-07-18 05:55:55 --> Language Class Initialized
INFO - 2022-07-18 05:55:55 --> Loader Class Initialized
INFO - 2022-07-18 05:55:55 --> Helper loaded: url_helper
INFO - 2022-07-18 05:55:55 --> Helper loaded: file_helper
INFO - 2022-07-18 05:55:55 --> Database Driver Class Initialized
INFO - 2022-07-18 05:55:55 --> Email Class Initialized
DEBUG - 2022-07-18 05:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:55:55 --> Controller Class Initialized
INFO - 2022-07-18 05:55:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:55:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:55:55 --> Final output sent to browser
DEBUG - 2022-07-18 05:55:55 --> Total execution time: 0.0161
INFO - 2022-07-18 05:55:55 --> Config Class Initialized
INFO - 2022-07-18 05:55:55 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:55:55 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:55:55 --> Utf8 Class Initialized
INFO - 2022-07-18 05:55:55 --> URI Class Initialized
INFO - 2022-07-18 05:55:55 --> Router Class Initialized
INFO - 2022-07-18 05:55:55 --> Output Class Initialized
INFO - 2022-07-18 05:55:55 --> Security Class Initialized
DEBUG - 2022-07-18 05:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:55:55 --> Input Class Initialized
INFO - 2022-07-18 05:55:55 --> Language Class Initialized
INFO - 2022-07-18 05:55:55 --> Loader Class Initialized
INFO - 2022-07-18 05:55:55 --> Helper loaded: url_helper
INFO - 2022-07-18 05:55:55 --> Helper loaded: file_helper
INFO - 2022-07-18 05:55:55 --> Database Driver Class Initialized
INFO - 2022-07-18 05:55:55 --> Email Class Initialized
DEBUG - 2022-07-18 05:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:55:55 --> Controller Class Initialized
INFO - 2022-07-18 05:55:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:55:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:55:55 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-18 05:55:55 --> Final output sent to browser
DEBUG - 2022-07-18 05:55:55 --> Total execution time: 0.0281
INFO - 2022-07-18 05:55:58 --> Config Class Initialized
INFO - 2022-07-18 05:55:58 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:55:58 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:55:58 --> Utf8 Class Initialized
INFO - 2022-07-18 05:55:58 --> URI Class Initialized
INFO - 2022-07-18 05:55:58 --> Router Class Initialized
INFO - 2022-07-18 05:55:58 --> Output Class Initialized
INFO - 2022-07-18 05:55:58 --> Security Class Initialized
DEBUG - 2022-07-18 05:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:55:58 --> Input Class Initialized
INFO - 2022-07-18 05:55:58 --> Language Class Initialized
INFO - 2022-07-18 05:55:58 --> Loader Class Initialized
INFO - 2022-07-18 05:55:58 --> Helper loaded: url_helper
INFO - 2022-07-18 05:55:58 --> Helper loaded: file_helper
INFO - 2022-07-18 05:55:58 --> Database Driver Class Initialized
INFO - 2022-07-18 05:55:58 --> Email Class Initialized
DEBUG - 2022-07-18 05:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:55:58 --> Controller Class Initialized
INFO - 2022-07-18 05:55:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:55:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:55:58 --> Final output sent to browser
DEBUG - 2022-07-18 05:55:58 --> Total execution time: 0.1244
INFO - 2022-07-18 05:56:01 --> Config Class Initialized
INFO - 2022-07-18 05:56:01 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:56:01 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:56:01 --> Utf8 Class Initialized
INFO - 2022-07-18 05:56:01 --> URI Class Initialized
INFO - 2022-07-18 05:56:01 --> Router Class Initialized
INFO - 2022-07-18 05:56:01 --> Output Class Initialized
INFO - 2022-07-18 05:56:01 --> Security Class Initialized
DEBUG - 2022-07-18 05:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:56:01 --> Input Class Initialized
INFO - 2022-07-18 05:56:01 --> Language Class Initialized
INFO - 2022-07-18 05:56:01 --> Loader Class Initialized
INFO - 2022-07-18 05:56:01 --> Helper loaded: url_helper
INFO - 2022-07-18 05:56:01 --> Helper loaded: file_helper
INFO - 2022-07-18 05:56:01 --> Database Driver Class Initialized
INFO - 2022-07-18 05:56:01 --> Email Class Initialized
DEBUG - 2022-07-18 05:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:56:01 --> Controller Class Initialized
INFO - 2022-07-18 05:56:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:56:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:26:01 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:26:01 --> Final output sent to browser
DEBUG - 2022-07-18 11:26:01 --> Total execution time: 0.0579
INFO - 2022-07-18 05:56:18 --> Config Class Initialized
INFO - 2022-07-18 05:56:18 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:56:18 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:56:18 --> Utf8 Class Initialized
INFO - 2022-07-18 05:56:18 --> URI Class Initialized
INFO - 2022-07-18 05:56:18 --> Router Class Initialized
INFO - 2022-07-18 05:56:18 --> Output Class Initialized
INFO - 2022-07-18 05:56:18 --> Security Class Initialized
DEBUG - 2022-07-18 05:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:56:18 --> Input Class Initialized
INFO - 2022-07-18 05:56:18 --> Language Class Initialized
INFO - 2022-07-18 05:56:18 --> Loader Class Initialized
INFO - 2022-07-18 05:56:18 --> Helper loaded: url_helper
INFO - 2022-07-18 05:56:18 --> Helper loaded: file_helper
INFO - 2022-07-18 05:56:18 --> Database Driver Class Initialized
INFO - 2022-07-18 05:56:18 --> Email Class Initialized
DEBUG - 2022-07-18 05:56:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:56:18 --> Controller Class Initialized
INFO - 2022-07-18 05:56:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:56:18 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:26:18 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:26:18 --> Final output sent to browser
DEBUG - 2022-07-18 11:26:18 --> Total execution time: 0.1294
INFO - 2022-07-18 05:59:24 --> Config Class Initialized
INFO - 2022-07-18 05:59:24 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:59:24 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:59:24 --> Utf8 Class Initialized
INFO - 2022-07-18 05:59:24 --> URI Class Initialized
INFO - 2022-07-18 05:59:24 --> Router Class Initialized
INFO - 2022-07-18 05:59:24 --> Output Class Initialized
INFO - 2022-07-18 05:59:24 --> Security Class Initialized
DEBUG - 2022-07-18 05:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:59:24 --> Input Class Initialized
INFO - 2022-07-18 05:59:24 --> Language Class Initialized
INFO - 2022-07-18 05:59:24 --> Loader Class Initialized
INFO - 2022-07-18 05:59:24 --> Helper loaded: url_helper
INFO - 2022-07-18 05:59:24 --> Helper loaded: file_helper
INFO - 2022-07-18 05:59:24 --> Database Driver Class Initialized
INFO - 2022-07-18 05:59:24 --> Email Class Initialized
DEBUG - 2022-07-18 05:59:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:59:24 --> Controller Class Initialized
INFO - 2022-07-18 05:59:24 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:59:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 11:29:24 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 523
INFO - 2022-07-18 05:59:26 --> Config Class Initialized
INFO - 2022-07-18 05:59:26 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:59:26 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:59:26 --> Utf8 Class Initialized
INFO - 2022-07-18 05:59:26 --> URI Class Initialized
INFO - 2022-07-18 05:59:26 --> Router Class Initialized
INFO - 2022-07-18 05:59:26 --> Output Class Initialized
INFO - 2022-07-18 05:59:26 --> Security Class Initialized
DEBUG - 2022-07-18 05:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:59:26 --> Input Class Initialized
INFO - 2022-07-18 05:59:26 --> Language Class Initialized
INFO - 2022-07-18 05:59:26 --> Loader Class Initialized
INFO - 2022-07-18 05:59:26 --> Helper loaded: url_helper
INFO - 2022-07-18 05:59:26 --> Helper loaded: file_helper
INFO - 2022-07-18 05:59:26 --> Database Driver Class Initialized
INFO - 2022-07-18 05:59:26 --> Email Class Initialized
DEBUG - 2022-07-18 05:59:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:59:26 --> Controller Class Initialized
INFO - 2022-07-18 05:59:26 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:59:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 11:29:26 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 523
INFO - 2022-07-18 05:59:44 --> Config Class Initialized
INFO - 2022-07-18 05:59:44 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:59:44 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:59:44 --> Utf8 Class Initialized
INFO - 2022-07-18 05:59:44 --> URI Class Initialized
INFO - 2022-07-18 05:59:44 --> Router Class Initialized
INFO - 2022-07-18 05:59:44 --> Output Class Initialized
INFO - 2022-07-18 05:59:44 --> Security Class Initialized
DEBUG - 2022-07-18 05:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:59:44 --> Input Class Initialized
INFO - 2022-07-18 05:59:44 --> Language Class Initialized
INFO - 2022-07-18 05:59:44 --> Loader Class Initialized
INFO - 2022-07-18 05:59:44 --> Helper loaded: url_helper
INFO - 2022-07-18 05:59:44 --> Helper loaded: file_helper
INFO - 2022-07-18 05:59:44 --> Database Driver Class Initialized
INFO - 2022-07-18 05:59:44 --> Email Class Initialized
DEBUG - 2022-07-18 05:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:59:44 --> Controller Class Initialized
INFO - 2022-07-18 05:59:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:59:44 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:59:45 --> Config Class Initialized
INFO - 2022-07-18 05:59:45 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:59:45 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:59:45 --> Utf8 Class Initialized
INFO - 2022-07-18 05:59:45 --> URI Class Initialized
INFO - 2022-07-18 05:59:45 --> Router Class Initialized
INFO - 2022-07-18 05:59:45 --> Output Class Initialized
INFO - 2022-07-18 05:59:45 --> Security Class Initialized
DEBUG - 2022-07-18 05:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:59:45 --> Input Class Initialized
INFO - 2022-07-18 05:59:45 --> Language Class Initialized
INFO - 2022-07-18 05:59:45 --> Loader Class Initialized
INFO - 2022-07-18 05:59:45 --> Helper loaded: url_helper
INFO - 2022-07-18 05:59:45 --> Helper loaded: file_helper
INFO - 2022-07-18 05:59:45 --> Database Driver Class Initialized
INFO - 2022-07-18 05:59:45 --> Email Class Initialized
DEBUG - 2022-07-18 05:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:59:45 --> Controller Class Initialized
INFO - 2022-07-18 05:59:45 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:59:45 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:59:46 --> Config Class Initialized
INFO - 2022-07-18 05:59:46 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:59:46 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:59:46 --> Utf8 Class Initialized
INFO - 2022-07-18 05:59:46 --> URI Class Initialized
INFO - 2022-07-18 05:59:46 --> Router Class Initialized
INFO - 2022-07-18 05:59:46 --> Output Class Initialized
INFO - 2022-07-18 05:59:46 --> Security Class Initialized
DEBUG - 2022-07-18 05:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:59:46 --> Input Class Initialized
INFO - 2022-07-18 05:59:46 --> Language Class Initialized
INFO - 2022-07-18 05:59:46 --> Loader Class Initialized
INFO - 2022-07-18 05:59:46 --> Helper loaded: url_helper
INFO - 2022-07-18 05:59:46 --> Helper loaded: file_helper
INFO - 2022-07-18 05:59:46 --> Database Driver Class Initialized
INFO - 2022-07-18 05:59:46 --> Email Class Initialized
DEBUG - 2022-07-18 05:59:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:59:46 --> Controller Class Initialized
INFO - 2022-07-18 05:59:46 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:59:46 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:59:46 --> Config Class Initialized
INFO - 2022-07-18 05:59:46 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:59:46 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:59:46 --> Utf8 Class Initialized
INFO - 2022-07-18 05:59:46 --> URI Class Initialized
INFO - 2022-07-18 05:59:46 --> Router Class Initialized
INFO - 2022-07-18 05:59:46 --> Output Class Initialized
INFO - 2022-07-18 05:59:46 --> Security Class Initialized
DEBUG - 2022-07-18 05:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:59:46 --> Input Class Initialized
INFO - 2022-07-18 05:59:46 --> Language Class Initialized
INFO - 2022-07-18 05:59:46 --> Loader Class Initialized
INFO - 2022-07-18 05:59:46 --> Helper loaded: url_helper
INFO - 2022-07-18 05:59:46 --> Helper loaded: file_helper
INFO - 2022-07-18 05:59:46 --> Database Driver Class Initialized
INFO - 2022-07-18 05:59:46 --> Email Class Initialized
DEBUG - 2022-07-18 05:59:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:59:46 --> Controller Class Initialized
INFO - 2022-07-18 05:59:46 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:59:46 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:59:47 --> Config Class Initialized
INFO - 2022-07-18 05:59:47 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:59:47 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:59:47 --> Utf8 Class Initialized
INFO - 2022-07-18 05:59:47 --> URI Class Initialized
INFO - 2022-07-18 05:59:47 --> Router Class Initialized
INFO - 2022-07-18 05:59:47 --> Output Class Initialized
INFO - 2022-07-18 05:59:47 --> Security Class Initialized
DEBUG - 2022-07-18 05:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:59:47 --> Input Class Initialized
INFO - 2022-07-18 05:59:47 --> Language Class Initialized
INFO - 2022-07-18 05:59:47 --> Loader Class Initialized
INFO - 2022-07-18 05:59:47 --> Helper loaded: url_helper
INFO - 2022-07-18 05:59:47 --> Helper loaded: file_helper
INFO - 2022-07-18 05:59:47 --> Database Driver Class Initialized
INFO - 2022-07-18 05:59:47 --> Email Class Initialized
DEBUG - 2022-07-18 05:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:59:47 --> Controller Class Initialized
INFO - 2022-07-18 05:59:47 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:59:47 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:59:47 --> Config Class Initialized
INFO - 2022-07-18 05:59:47 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:59:47 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:59:47 --> Utf8 Class Initialized
INFO - 2022-07-18 05:59:47 --> URI Class Initialized
INFO - 2022-07-18 05:59:47 --> Router Class Initialized
INFO - 2022-07-18 05:59:47 --> Output Class Initialized
INFO - 2022-07-18 05:59:47 --> Security Class Initialized
DEBUG - 2022-07-18 05:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:59:47 --> Input Class Initialized
INFO - 2022-07-18 05:59:47 --> Language Class Initialized
INFO - 2022-07-18 05:59:47 --> Loader Class Initialized
INFO - 2022-07-18 05:59:47 --> Helper loaded: url_helper
INFO - 2022-07-18 05:59:47 --> Helper loaded: file_helper
INFO - 2022-07-18 05:59:47 --> Database Driver Class Initialized
INFO - 2022-07-18 05:59:47 --> Email Class Initialized
DEBUG - 2022-07-18 05:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:59:47 --> Controller Class Initialized
INFO - 2022-07-18 05:59:47 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:59:47 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:59:47 --> Config Class Initialized
INFO - 2022-07-18 05:59:47 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:59:47 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:59:47 --> Utf8 Class Initialized
INFO - 2022-07-18 05:59:47 --> URI Class Initialized
INFO - 2022-07-18 05:59:47 --> Router Class Initialized
INFO - 2022-07-18 05:59:47 --> Output Class Initialized
INFO - 2022-07-18 05:59:47 --> Security Class Initialized
DEBUG - 2022-07-18 05:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:59:47 --> Input Class Initialized
INFO - 2022-07-18 05:59:47 --> Language Class Initialized
INFO - 2022-07-18 05:59:47 --> Loader Class Initialized
INFO - 2022-07-18 05:59:47 --> Helper loaded: url_helper
INFO - 2022-07-18 05:59:47 --> Helper loaded: file_helper
INFO - 2022-07-18 05:59:47 --> Database Driver Class Initialized
INFO - 2022-07-18 05:59:47 --> Email Class Initialized
DEBUG - 2022-07-18 05:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:59:47 --> Controller Class Initialized
INFO - 2022-07-18 05:59:47 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:59:47 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:59:47 --> Config Class Initialized
INFO - 2022-07-18 05:59:47 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:59:47 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:59:47 --> Utf8 Class Initialized
INFO - 2022-07-18 05:59:47 --> URI Class Initialized
INFO - 2022-07-18 05:59:47 --> Router Class Initialized
INFO - 2022-07-18 05:59:47 --> Output Class Initialized
INFO - 2022-07-18 05:59:47 --> Security Class Initialized
DEBUG - 2022-07-18 05:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:59:47 --> Input Class Initialized
INFO - 2022-07-18 05:59:47 --> Language Class Initialized
INFO - 2022-07-18 05:59:47 --> Loader Class Initialized
INFO - 2022-07-18 05:59:47 --> Helper loaded: url_helper
INFO - 2022-07-18 05:59:47 --> Helper loaded: file_helper
INFO - 2022-07-18 05:59:47 --> Database Driver Class Initialized
INFO - 2022-07-18 05:59:47 --> Email Class Initialized
DEBUG - 2022-07-18 05:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:59:47 --> Controller Class Initialized
INFO - 2022-07-18 05:59:47 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:59:47 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:59:47 --> Config Class Initialized
INFO - 2022-07-18 05:59:47 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:59:47 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:59:47 --> Utf8 Class Initialized
INFO - 2022-07-18 05:59:47 --> URI Class Initialized
INFO - 2022-07-18 05:59:47 --> Router Class Initialized
INFO - 2022-07-18 05:59:47 --> Output Class Initialized
INFO - 2022-07-18 05:59:47 --> Security Class Initialized
DEBUG - 2022-07-18 05:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:59:47 --> Input Class Initialized
INFO - 2022-07-18 05:59:47 --> Language Class Initialized
INFO - 2022-07-18 05:59:47 --> Loader Class Initialized
INFO - 2022-07-18 05:59:47 --> Helper loaded: url_helper
INFO - 2022-07-18 05:59:47 --> Helper loaded: file_helper
INFO - 2022-07-18 05:59:47 --> Database Driver Class Initialized
INFO - 2022-07-18 05:59:47 --> Email Class Initialized
DEBUG - 2022-07-18 05:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:59:47 --> Controller Class Initialized
INFO - 2022-07-18 05:59:47 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:59:47 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:59:47 --> Config Class Initialized
INFO - 2022-07-18 05:59:47 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:59:47 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:59:47 --> Utf8 Class Initialized
INFO - 2022-07-18 05:59:47 --> URI Class Initialized
INFO - 2022-07-18 05:59:47 --> Router Class Initialized
INFO - 2022-07-18 05:59:47 --> Output Class Initialized
INFO - 2022-07-18 05:59:47 --> Security Class Initialized
DEBUG - 2022-07-18 05:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:59:47 --> Input Class Initialized
INFO - 2022-07-18 05:59:47 --> Language Class Initialized
INFO - 2022-07-18 05:59:47 --> Loader Class Initialized
INFO - 2022-07-18 05:59:47 --> Helper loaded: url_helper
INFO - 2022-07-18 05:59:47 --> Helper loaded: file_helper
INFO - 2022-07-18 05:59:47 --> Database Driver Class Initialized
INFO - 2022-07-18 05:59:47 --> Email Class Initialized
DEBUG - 2022-07-18 05:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:59:47 --> Controller Class Initialized
INFO - 2022-07-18 05:59:47 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:59:47 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:59:57 --> Config Class Initialized
INFO - 2022-07-18 05:59:57 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:59:57 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:59:57 --> Utf8 Class Initialized
INFO - 2022-07-18 05:59:57 --> URI Class Initialized
INFO - 2022-07-18 05:59:57 --> Router Class Initialized
INFO - 2022-07-18 05:59:57 --> Output Class Initialized
INFO - 2022-07-18 05:59:57 --> Security Class Initialized
DEBUG - 2022-07-18 05:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:59:57 --> Input Class Initialized
INFO - 2022-07-18 05:59:57 --> Language Class Initialized
INFO - 2022-07-18 05:59:57 --> Loader Class Initialized
INFO - 2022-07-18 05:59:57 --> Helper loaded: url_helper
INFO - 2022-07-18 05:59:57 --> Helper loaded: file_helper
INFO - 2022-07-18 05:59:57 --> Database Driver Class Initialized
INFO - 2022-07-18 05:59:57 --> Email Class Initialized
DEBUG - 2022-07-18 05:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:59:57 --> Controller Class Initialized
INFO - 2022-07-18 05:59:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:59:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:59:57 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-18 05:59:57 --> Final output sent to browser
DEBUG - 2022-07-18 05:59:57 --> Total execution time: 0.1289
INFO - 2022-07-18 05:59:59 --> Config Class Initialized
INFO - 2022-07-18 05:59:59 --> Hooks Class Initialized
DEBUG - 2022-07-18 05:59:59 --> UTF-8 Support Enabled
INFO - 2022-07-18 05:59:59 --> Utf8 Class Initialized
INFO - 2022-07-18 05:59:59 --> URI Class Initialized
INFO - 2022-07-18 05:59:59 --> Router Class Initialized
INFO - 2022-07-18 05:59:59 --> Output Class Initialized
INFO - 2022-07-18 05:59:59 --> Security Class Initialized
DEBUG - 2022-07-18 05:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 05:59:59 --> Input Class Initialized
INFO - 2022-07-18 05:59:59 --> Language Class Initialized
INFO - 2022-07-18 05:59:59 --> Loader Class Initialized
INFO - 2022-07-18 05:59:59 --> Helper loaded: url_helper
INFO - 2022-07-18 05:59:59 --> Helper loaded: file_helper
INFO - 2022-07-18 05:59:59 --> Database Driver Class Initialized
INFO - 2022-07-18 05:59:59 --> Email Class Initialized
DEBUG - 2022-07-18 05:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 05:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 05:59:59 --> Controller Class Initialized
INFO - 2022-07-18 05:59:59 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 05:59:59 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 05:59:59 --> Final output sent to browser
DEBUG - 2022-07-18 05:59:59 --> Total execution time: 0.0429
INFO - 2022-07-18 06:00:05 --> Config Class Initialized
INFO - 2022-07-18 06:00:05 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:00:05 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:00:05 --> Utf8 Class Initialized
INFO - 2022-07-18 06:00:05 --> URI Class Initialized
INFO - 2022-07-18 06:00:05 --> Router Class Initialized
INFO - 2022-07-18 06:00:05 --> Output Class Initialized
INFO - 2022-07-18 06:00:05 --> Security Class Initialized
DEBUG - 2022-07-18 06:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:00:05 --> Input Class Initialized
INFO - 2022-07-18 06:00:05 --> Language Class Initialized
INFO - 2022-07-18 06:00:05 --> Loader Class Initialized
INFO - 2022-07-18 06:00:05 --> Helper loaded: url_helper
INFO - 2022-07-18 06:00:05 --> Helper loaded: file_helper
INFO - 2022-07-18 06:00:05 --> Database Driver Class Initialized
INFO - 2022-07-18 06:00:05 --> Email Class Initialized
DEBUG - 2022-07-18 06:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:00:05 --> Controller Class Initialized
INFO - 2022-07-18 06:00:05 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:00:05 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:00:10 --> Config Class Initialized
INFO - 2022-07-18 06:00:10 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:00:10 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:00:10 --> Utf8 Class Initialized
INFO - 2022-07-18 06:00:10 --> URI Class Initialized
INFO - 2022-07-18 06:00:10 --> Router Class Initialized
INFO - 2022-07-18 06:00:10 --> Output Class Initialized
INFO - 2022-07-18 06:00:10 --> Security Class Initialized
DEBUG - 2022-07-18 06:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:00:10 --> Input Class Initialized
INFO - 2022-07-18 06:00:10 --> Language Class Initialized
INFO - 2022-07-18 06:00:10 --> Loader Class Initialized
INFO - 2022-07-18 06:00:10 --> Helper loaded: url_helper
INFO - 2022-07-18 06:00:10 --> Helper loaded: file_helper
INFO - 2022-07-18 06:00:10 --> Database Driver Class Initialized
INFO - 2022-07-18 06:00:10 --> Email Class Initialized
DEBUG - 2022-07-18 06:00:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:00:10 --> Controller Class Initialized
INFO - 2022-07-18 06:00:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:00:10 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:00:11 --> Config Class Initialized
INFO - 2022-07-18 06:00:11 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:00:11 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:00:11 --> Utf8 Class Initialized
INFO - 2022-07-18 06:00:11 --> URI Class Initialized
INFO - 2022-07-18 06:00:11 --> Router Class Initialized
INFO - 2022-07-18 06:00:11 --> Output Class Initialized
INFO - 2022-07-18 06:00:11 --> Security Class Initialized
DEBUG - 2022-07-18 06:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:00:11 --> Input Class Initialized
INFO - 2022-07-18 06:00:11 --> Language Class Initialized
INFO - 2022-07-18 06:00:11 --> Loader Class Initialized
INFO - 2022-07-18 06:00:11 --> Helper loaded: url_helper
INFO - 2022-07-18 06:00:11 --> Helper loaded: file_helper
INFO - 2022-07-18 06:00:11 --> Database Driver Class Initialized
INFO - 2022-07-18 06:00:11 --> Email Class Initialized
DEBUG - 2022-07-18 06:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:00:11 --> Controller Class Initialized
INFO - 2022-07-18 06:00:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:00:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:00:12 --> Config Class Initialized
INFO - 2022-07-18 06:00:12 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:00:12 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:00:12 --> Utf8 Class Initialized
INFO - 2022-07-18 06:00:12 --> URI Class Initialized
INFO - 2022-07-18 06:00:12 --> Router Class Initialized
INFO - 2022-07-18 06:00:12 --> Output Class Initialized
INFO - 2022-07-18 06:00:12 --> Security Class Initialized
DEBUG - 2022-07-18 06:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:00:12 --> Input Class Initialized
INFO - 2022-07-18 06:00:12 --> Language Class Initialized
INFO - 2022-07-18 06:00:12 --> Loader Class Initialized
INFO - 2022-07-18 06:00:12 --> Helper loaded: url_helper
INFO - 2022-07-18 06:00:12 --> Helper loaded: file_helper
INFO - 2022-07-18 06:00:12 --> Database Driver Class Initialized
INFO - 2022-07-18 06:00:12 --> Email Class Initialized
DEBUG - 2022-07-18 06:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:00:12 --> Controller Class Initialized
INFO - 2022-07-18 06:00:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:00:12 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:00:13 --> Config Class Initialized
INFO - 2022-07-18 06:00:13 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:00:13 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:00:13 --> Utf8 Class Initialized
INFO - 2022-07-18 06:00:13 --> URI Class Initialized
INFO - 2022-07-18 06:00:13 --> Router Class Initialized
INFO - 2022-07-18 06:00:13 --> Output Class Initialized
INFO - 2022-07-18 06:00:13 --> Security Class Initialized
DEBUG - 2022-07-18 06:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:00:13 --> Input Class Initialized
INFO - 2022-07-18 06:00:13 --> Language Class Initialized
INFO - 2022-07-18 06:00:13 --> Loader Class Initialized
INFO - 2022-07-18 06:00:13 --> Helper loaded: url_helper
INFO - 2022-07-18 06:00:13 --> Helper loaded: file_helper
INFO - 2022-07-18 06:00:13 --> Database Driver Class Initialized
INFO - 2022-07-18 06:00:13 --> Email Class Initialized
DEBUG - 2022-07-18 06:00:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:00:13 --> Controller Class Initialized
INFO - 2022-07-18 06:00:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:00:13 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:00:57 --> Config Class Initialized
INFO - 2022-07-18 06:00:57 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:00:57 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:00:57 --> Utf8 Class Initialized
INFO - 2022-07-18 06:00:57 --> URI Class Initialized
INFO - 2022-07-18 06:00:57 --> Router Class Initialized
INFO - 2022-07-18 06:00:57 --> Output Class Initialized
INFO - 2022-07-18 06:00:57 --> Security Class Initialized
DEBUG - 2022-07-18 06:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:00:57 --> Input Class Initialized
INFO - 2022-07-18 06:00:57 --> Language Class Initialized
INFO - 2022-07-18 06:00:57 --> Loader Class Initialized
INFO - 2022-07-18 06:00:57 --> Helper loaded: url_helper
INFO - 2022-07-18 06:00:57 --> Helper loaded: file_helper
INFO - 2022-07-18 06:00:57 --> Database Driver Class Initialized
INFO - 2022-07-18 06:00:57 --> Email Class Initialized
DEBUG - 2022-07-18 06:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:00:57 --> Controller Class Initialized
INFO - 2022-07-18 06:00:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:00:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:01:01 --> Config Class Initialized
INFO - 2022-07-18 06:01:01 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:01:01 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:01:01 --> Utf8 Class Initialized
INFO - 2022-07-18 06:01:01 --> URI Class Initialized
INFO - 2022-07-18 06:01:01 --> Router Class Initialized
INFO - 2022-07-18 06:01:01 --> Output Class Initialized
INFO - 2022-07-18 06:01:01 --> Security Class Initialized
DEBUG - 2022-07-18 06:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:01:01 --> Input Class Initialized
INFO - 2022-07-18 06:01:01 --> Language Class Initialized
INFO - 2022-07-18 06:01:01 --> Loader Class Initialized
INFO - 2022-07-18 06:01:01 --> Helper loaded: url_helper
INFO - 2022-07-18 06:01:01 --> Helper loaded: file_helper
INFO - 2022-07-18 06:01:01 --> Database Driver Class Initialized
INFO - 2022-07-18 06:01:01 --> Email Class Initialized
DEBUG - 2022-07-18 06:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:01:01 --> Controller Class Initialized
INFO - 2022-07-18 06:01:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:01:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:01:07 --> Config Class Initialized
INFO - 2022-07-18 06:01:07 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:01:07 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:01:07 --> Utf8 Class Initialized
INFO - 2022-07-18 06:01:07 --> URI Class Initialized
INFO - 2022-07-18 06:01:07 --> Router Class Initialized
INFO - 2022-07-18 06:01:07 --> Output Class Initialized
INFO - 2022-07-18 06:01:07 --> Security Class Initialized
DEBUG - 2022-07-18 06:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:01:07 --> Input Class Initialized
INFO - 2022-07-18 06:01:07 --> Language Class Initialized
INFO - 2022-07-18 06:01:07 --> Loader Class Initialized
INFO - 2022-07-18 06:01:07 --> Helper loaded: url_helper
INFO - 2022-07-18 06:01:07 --> Helper loaded: file_helper
INFO - 2022-07-18 06:01:07 --> Database Driver Class Initialized
INFO - 2022-07-18 06:01:07 --> Email Class Initialized
DEBUG - 2022-07-18 06:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:01:07 --> Controller Class Initialized
INFO - 2022-07-18 06:01:07 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:01:07 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:01:07 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-18 06:01:07 --> Final output sent to browser
DEBUG - 2022-07-18 06:01:07 --> Total execution time: 0.0177
INFO - 2022-07-18 06:01:09 --> Config Class Initialized
INFO - 2022-07-18 06:01:09 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:01:09 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:01:09 --> Utf8 Class Initialized
INFO - 2022-07-18 06:01:09 --> URI Class Initialized
INFO - 2022-07-18 06:01:09 --> Router Class Initialized
INFO - 2022-07-18 06:01:09 --> Output Class Initialized
INFO - 2022-07-18 06:01:09 --> Security Class Initialized
DEBUG - 2022-07-18 06:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:01:09 --> Input Class Initialized
INFO - 2022-07-18 06:01:09 --> Language Class Initialized
INFO - 2022-07-18 06:01:09 --> Loader Class Initialized
INFO - 2022-07-18 06:01:09 --> Helper loaded: url_helper
INFO - 2022-07-18 06:01:09 --> Helper loaded: file_helper
INFO - 2022-07-18 06:01:09 --> Database Driver Class Initialized
INFO - 2022-07-18 06:01:09 --> Email Class Initialized
DEBUG - 2022-07-18 06:01:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:01:09 --> Controller Class Initialized
INFO - 2022-07-18 06:01:09 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:01:09 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:01:09 --> Final output sent to browser
DEBUG - 2022-07-18 06:01:09 --> Total execution time: 0.1245
INFO - 2022-07-18 06:01:12 --> Config Class Initialized
INFO - 2022-07-18 06:01:12 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:01:12 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:01:12 --> Utf8 Class Initialized
INFO - 2022-07-18 06:01:12 --> URI Class Initialized
INFO - 2022-07-18 06:01:12 --> Router Class Initialized
INFO - 2022-07-18 06:01:12 --> Output Class Initialized
INFO - 2022-07-18 06:01:12 --> Security Class Initialized
DEBUG - 2022-07-18 06:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:01:12 --> Input Class Initialized
INFO - 2022-07-18 06:01:12 --> Language Class Initialized
INFO - 2022-07-18 06:01:12 --> Loader Class Initialized
INFO - 2022-07-18 06:01:12 --> Helper loaded: url_helper
INFO - 2022-07-18 06:01:12 --> Helper loaded: file_helper
INFO - 2022-07-18 06:01:12 --> Database Driver Class Initialized
INFO - 2022-07-18 06:01:12 --> Email Class Initialized
DEBUG - 2022-07-18 06:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:01:12 --> Controller Class Initialized
INFO - 2022-07-18 06:01:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:01:12 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:01:49 --> Config Class Initialized
INFO - 2022-07-18 06:01:49 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:01:49 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:01:49 --> Utf8 Class Initialized
INFO - 2022-07-18 06:01:49 --> URI Class Initialized
INFO - 2022-07-18 06:01:49 --> Router Class Initialized
INFO - 2022-07-18 06:01:49 --> Output Class Initialized
INFO - 2022-07-18 06:01:49 --> Security Class Initialized
DEBUG - 2022-07-18 06:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:01:49 --> Input Class Initialized
INFO - 2022-07-18 06:01:49 --> Language Class Initialized
INFO - 2022-07-18 06:01:49 --> Loader Class Initialized
INFO - 2022-07-18 06:01:49 --> Helper loaded: url_helper
INFO - 2022-07-18 06:01:49 --> Helper loaded: file_helper
INFO - 2022-07-18 06:01:49 --> Database Driver Class Initialized
INFO - 2022-07-18 06:01:49 --> Email Class Initialized
DEBUG - 2022-07-18 06:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:01:49 --> Controller Class Initialized
INFO - 2022-07-18 06:01:49 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:01:49 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:31:49 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:31:49 --> Final output sent to browser
DEBUG - 2022-07-18 11:31:49 --> Total execution time: 0.0508
INFO - 2022-07-18 06:04:22 --> Config Class Initialized
INFO - 2022-07-18 06:04:22 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:04:22 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:04:22 --> Utf8 Class Initialized
INFO - 2022-07-18 06:04:22 --> URI Class Initialized
INFO - 2022-07-18 06:04:22 --> Router Class Initialized
INFO - 2022-07-18 06:04:22 --> Output Class Initialized
INFO - 2022-07-18 06:04:22 --> Security Class Initialized
DEBUG - 2022-07-18 06:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:04:22 --> Input Class Initialized
INFO - 2022-07-18 06:04:22 --> Language Class Initialized
INFO - 2022-07-18 06:04:22 --> Loader Class Initialized
INFO - 2022-07-18 06:04:22 --> Helper loaded: url_helper
INFO - 2022-07-18 06:04:22 --> Helper loaded: file_helper
INFO - 2022-07-18 06:04:22 --> Database Driver Class Initialized
INFO - 2022-07-18 06:04:22 --> Email Class Initialized
DEBUG - 2022-07-18 06:04:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:04:22 --> Controller Class Initialized
INFO - 2022-07-18 06:04:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:04:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:34:22 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:34:22 --> Final output sent to browser
DEBUG - 2022-07-18 11:34:22 --> Total execution time: 0.0605
INFO - 2022-07-18 06:04:25 --> Config Class Initialized
INFO - 2022-07-18 06:04:25 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:04:25 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:04:25 --> Utf8 Class Initialized
INFO - 2022-07-18 06:04:25 --> URI Class Initialized
INFO - 2022-07-18 06:04:25 --> Router Class Initialized
INFO - 2022-07-18 06:04:25 --> Output Class Initialized
INFO - 2022-07-18 06:04:25 --> Security Class Initialized
DEBUG - 2022-07-18 06:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:04:25 --> Input Class Initialized
INFO - 2022-07-18 06:04:25 --> Language Class Initialized
INFO - 2022-07-18 06:04:25 --> Loader Class Initialized
INFO - 2022-07-18 06:04:25 --> Helper loaded: url_helper
INFO - 2022-07-18 06:04:25 --> Helper loaded: file_helper
INFO - 2022-07-18 06:04:25 --> Database Driver Class Initialized
INFO - 2022-07-18 06:04:25 --> Email Class Initialized
DEBUG - 2022-07-18 06:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:04:25 --> Controller Class Initialized
INFO - 2022-07-18 06:04:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:04:25 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:04:25 --> Final output sent to browser
DEBUG - 2022-07-18 06:04:25 --> Total execution time: 0.0167
INFO - 2022-07-18 06:04:25 --> Config Class Initialized
INFO - 2022-07-18 06:04:25 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:04:25 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:04:25 --> Utf8 Class Initialized
INFO - 2022-07-18 06:04:25 --> URI Class Initialized
INFO - 2022-07-18 06:04:25 --> Router Class Initialized
INFO - 2022-07-18 06:04:25 --> Output Class Initialized
INFO - 2022-07-18 06:04:25 --> Security Class Initialized
DEBUG - 2022-07-18 06:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:04:25 --> Input Class Initialized
INFO - 2022-07-18 06:04:25 --> Language Class Initialized
INFO - 2022-07-18 06:04:25 --> Loader Class Initialized
INFO - 2022-07-18 06:04:25 --> Helper loaded: url_helper
INFO - 2022-07-18 06:04:25 --> Helper loaded: file_helper
INFO - 2022-07-18 06:04:25 --> Database Driver Class Initialized
INFO - 2022-07-18 06:04:25 --> Email Class Initialized
DEBUG - 2022-07-18 06:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:04:25 --> Controller Class Initialized
INFO - 2022-07-18 06:04:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:04:25 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:04:25 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-18 06:04:25 --> Final output sent to browser
DEBUG - 2022-07-18 06:04:25 --> Total execution time: 0.0159
INFO - 2022-07-18 06:04:28 --> Config Class Initialized
INFO - 2022-07-18 06:04:28 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:04:28 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:04:28 --> Utf8 Class Initialized
INFO - 2022-07-18 06:04:28 --> URI Class Initialized
INFO - 2022-07-18 06:04:28 --> Router Class Initialized
INFO - 2022-07-18 06:04:28 --> Output Class Initialized
INFO - 2022-07-18 06:04:28 --> Security Class Initialized
DEBUG - 2022-07-18 06:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:04:28 --> Input Class Initialized
INFO - 2022-07-18 06:04:28 --> Language Class Initialized
INFO - 2022-07-18 06:04:28 --> Loader Class Initialized
INFO - 2022-07-18 06:04:28 --> Helper loaded: url_helper
INFO - 2022-07-18 06:04:28 --> Helper loaded: file_helper
INFO - 2022-07-18 06:04:28 --> Database Driver Class Initialized
INFO - 2022-07-18 06:04:28 --> Email Class Initialized
DEBUG - 2022-07-18 06:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:04:28 --> Controller Class Initialized
INFO - 2022-07-18 06:04:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:04:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:04:28 --> Final output sent to browser
DEBUG - 2022-07-18 06:04:28 --> Total execution time: 0.0207
INFO - 2022-07-18 06:04:30 --> Config Class Initialized
INFO - 2022-07-18 06:04:30 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:04:30 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:04:30 --> Utf8 Class Initialized
INFO - 2022-07-18 06:04:30 --> URI Class Initialized
INFO - 2022-07-18 06:04:30 --> Router Class Initialized
INFO - 2022-07-18 06:04:30 --> Output Class Initialized
INFO - 2022-07-18 06:04:30 --> Security Class Initialized
DEBUG - 2022-07-18 06:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:04:30 --> Input Class Initialized
INFO - 2022-07-18 06:04:30 --> Language Class Initialized
INFO - 2022-07-18 06:04:30 --> Loader Class Initialized
INFO - 2022-07-18 06:04:30 --> Helper loaded: url_helper
INFO - 2022-07-18 06:04:30 --> Helper loaded: file_helper
INFO - 2022-07-18 06:04:30 --> Database Driver Class Initialized
INFO - 2022-07-18 06:04:30 --> Email Class Initialized
DEBUG - 2022-07-18 06:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:04:30 --> Controller Class Initialized
INFO - 2022-07-18 06:04:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:04:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:34:30 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:34:30 --> Final output sent to browser
DEBUG - 2022-07-18 11:34:30 --> Total execution time: 0.0232
INFO - 2022-07-18 06:04:56 --> Config Class Initialized
INFO - 2022-07-18 06:04:56 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:04:56 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:04:56 --> Utf8 Class Initialized
INFO - 2022-07-18 06:04:56 --> URI Class Initialized
INFO - 2022-07-18 06:04:56 --> Router Class Initialized
INFO - 2022-07-18 06:04:56 --> Output Class Initialized
INFO - 2022-07-18 06:04:56 --> Security Class Initialized
DEBUG - 2022-07-18 06:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:04:56 --> Input Class Initialized
INFO - 2022-07-18 06:04:56 --> Language Class Initialized
INFO - 2022-07-18 06:04:56 --> Loader Class Initialized
INFO - 2022-07-18 06:04:56 --> Helper loaded: url_helper
INFO - 2022-07-18 06:04:56 --> Helper loaded: file_helper
INFO - 2022-07-18 06:04:56 --> Database Driver Class Initialized
INFO - 2022-07-18 06:04:56 --> Email Class Initialized
DEBUG - 2022-07-18 06:04:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:04:56 --> Controller Class Initialized
INFO - 2022-07-18 06:04:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:04:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:04:56 --> Final output sent to browser
DEBUG - 2022-07-18 06:04:56 --> Total execution time: 0.0701
INFO - 2022-07-18 06:05:17 --> Config Class Initialized
INFO - 2022-07-18 06:05:17 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:05:17 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:05:17 --> Utf8 Class Initialized
INFO - 2022-07-18 06:05:17 --> URI Class Initialized
INFO - 2022-07-18 06:05:17 --> Router Class Initialized
INFO - 2022-07-18 06:05:17 --> Output Class Initialized
INFO - 2022-07-18 06:05:17 --> Security Class Initialized
DEBUG - 2022-07-18 06:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:05:17 --> Input Class Initialized
INFO - 2022-07-18 06:05:17 --> Language Class Initialized
INFO - 2022-07-18 06:05:17 --> Loader Class Initialized
INFO - 2022-07-18 06:05:17 --> Helper loaded: url_helper
INFO - 2022-07-18 06:05:17 --> Helper loaded: file_helper
INFO - 2022-07-18 06:05:17 --> Database Driver Class Initialized
INFO - 2022-07-18 06:05:17 --> Email Class Initialized
DEBUG - 2022-07-18 06:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:05:17 --> Controller Class Initialized
INFO - 2022-07-18 06:05:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:05:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:35:17 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:35:17 --> Final output sent to browser
DEBUG - 2022-07-18 11:35:17 --> Total execution time: 0.0180
INFO - 2022-07-18 06:07:06 --> Config Class Initialized
INFO - 2022-07-18 06:07:06 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:07:06 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:07:06 --> Utf8 Class Initialized
INFO - 2022-07-18 06:07:06 --> URI Class Initialized
INFO - 2022-07-18 06:07:06 --> Router Class Initialized
INFO - 2022-07-18 06:07:06 --> Output Class Initialized
INFO - 2022-07-18 06:07:06 --> Security Class Initialized
DEBUG - 2022-07-18 06:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:07:06 --> Input Class Initialized
INFO - 2022-07-18 06:07:06 --> Language Class Initialized
INFO - 2022-07-18 06:07:06 --> Loader Class Initialized
INFO - 2022-07-18 06:07:06 --> Helper loaded: url_helper
INFO - 2022-07-18 06:07:06 --> Helper loaded: file_helper
INFO - 2022-07-18 06:07:06 --> Database Driver Class Initialized
INFO - 2022-07-18 06:07:06 --> Email Class Initialized
DEBUG - 2022-07-18 06:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:07:06 --> Controller Class Initialized
INFO - 2022-07-18 06:07:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:07:06 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:07:06 --> Final output sent to browser
DEBUG - 2022-07-18 06:07:06 --> Total execution time: 0.0165
INFO - 2022-07-18 06:07:06 --> Config Class Initialized
INFO - 2022-07-18 06:07:06 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:07:06 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:07:06 --> Utf8 Class Initialized
INFO - 2022-07-18 06:07:06 --> URI Class Initialized
INFO - 2022-07-18 06:07:06 --> Router Class Initialized
INFO - 2022-07-18 06:07:06 --> Output Class Initialized
INFO - 2022-07-18 06:07:06 --> Security Class Initialized
DEBUG - 2022-07-18 06:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:07:06 --> Input Class Initialized
INFO - 2022-07-18 06:07:06 --> Language Class Initialized
INFO - 2022-07-18 06:07:06 --> Loader Class Initialized
INFO - 2022-07-18 06:07:06 --> Helper loaded: url_helper
INFO - 2022-07-18 06:07:06 --> Helper loaded: file_helper
INFO - 2022-07-18 06:07:06 --> Database Driver Class Initialized
INFO - 2022-07-18 06:07:06 --> Email Class Initialized
DEBUG - 2022-07-18 06:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:07:06 --> Controller Class Initialized
INFO - 2022-07-18 06:07:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:07:06 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:07:06 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-18 06:07:06 --> Final output sent to browser
DEBUG - 2022-07-18 06:07:06 --> Total execution time: 0.0411
INFO - 2022-07-18 06:07:08 --> Config Class Initialized
INFO - 2022-07-18 06:07:08 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:07:08 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:07:08 --> Utf8 Class Initialized
INFO - 2022-07-18 06:07:08 --> URI Class Initialized
INFO - 2022-07-18 06:07:08 --> Router Class Initialized
INFO - 2022-07-18 06:07:08 --> Output Class Initialized
INFO - 2022-07-18 06:07:08 --> Security Class Initialized
DEBUG - 2022-07-18 06:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:07:08 --> Input Class Initialized
INFO - 2022-07-18 06:07:08 --> Language Class Initialized
INFO - 2022-07-18 06:07:08 --> Loader Class Initialized
INFO - 2022-07-18 06:07:08 --> Helper loaded: url_helper
INFO - 2022-07-18 06:07:08 --> Helper loaded: file_helper
INFO - 2022-07-18 06:07:08 --> Database Driver Class Initialized
INFO - 2022-07-18 06:07:08 --> Email Class Initialized
DEBUG - 2022-07-18 06:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:07:08 --> Controller Class Initialized
INFO - 2022-07-18 06:07:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:07:08 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:07:08 --> Final output sent to browser
DEBUG - 2022-07-18 06:07:08 --> Total execution time: 0.0163
INFO - 2022-07-18 06:07:10 --> Config Class Initialized
INFO - 2022-07-18 06:07:10 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:07:10 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:07:10 --> Utf8 Class Initialized
INFO - 2022-07-18 06:07:10 --> URI Class Initialized
INFO - 2022-07-18 06:07:10 --> Router Class Initialized
INFO - 2022-07-18 06:07:10 --> Output Class Initialized
INFO - 2022-07-18 06:07:10 --> Security Class Initialized
DEBUG - 2022-07-18 06:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:07:10 --> Input Class Initialized
INFO - 2022-07-18 06:07:10 --> Language Class Initialized
INFO - 2022-07-18 06:07:10 --> Loader Class Initialized
INFO - 2022-07-18 06:07:10 --> Helper loaded: url_helper
INFO - 2022-07-18 06:07:10 --> Helper loaded: file_helper
INFO - 2022-07-18 06:07:10 --> Database Driver Class Initialized
INFO - 2022-07-18 06:07:10 --> Email Class Initialized
DEBUG - 2022-07-18 06:07:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:07:10 --> Controller Class Initialized
INFO - 2022-07-18 06:07:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:07:10 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:37:10 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:37:10 --> Final output sent to browser
DEBUG - 2022-07-18 11:37:10 --> Total execution time: 0.0202
INFO - 2022-07-18 06:07:13 --> Config Class Initialized
INFO - 2022-07-18 06:07:13 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:07:13 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:07:13 --> Utf8 Class Initialized
INFO - 2022-07-18 06:07:13 --> URI Class Initialized
INFO - 2022-07-18 06:07:13 --> Router Class Initialized
INFO - 2022-07-18 06:07:13 --> Output Class Initialized
INFO - 2022-07-18 06:07:13 --> Security Class Initialized
DEBUG - 2022-07-18 06:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:07:13 --> Input Class Initialized
INFO - 2022-07-18 06:07:13 --> Language Class Initialized
INFO - 2022-07-18 06:07:13 --> Loader Class Initialized
INFO - 2022-07-18 06:07:13 --> Helper loaded: url_helper
INFO - 2022-07-18 06:07:13 --> Helper loaded: file_helper
INFO - 2022-07-18 06:07:13 --> Database Driver Class Initialized
INFO - 2022-07-18 06:07:13 --> Email Class Initialized
DEBUG - 2022-07-18 06:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:07:13 --> Controller Class Initialized
INFO - 2022-07-18 06:07:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:07:13 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:37:13 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:37:13 --> Final output sent to browser
DEBUG - 2022-07-18 11:37:13 --> Total execution time: 0.1672
INFO - 2022-07-18 06:10:22 --> Config Class Initialized
INFO - 2022-07-18 06:10:22 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:10:22 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:10:22 --> Utf8 Class Initialized
INFO - 2022-07-18 06:10:22 --> URI Class Initialized
INFO - 2022-07-18 06:10:22 --> Router Class Initialized
INFO - 2022-07-18 06:10:22 --> Output Class Initialized
INFO - 2022-07-18 06:10:22 --> Security Class Initialized
DEBUG - 2022-07-18 06:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:10:22 --> Input Class Initialized
INFO - 2022-07-18 06:10:22 --> Language Class Initialized
INFO - 2022-07-18 06:10:22 --> Loader Class Initialized
INFO - 2022-07-18 06:10:22 --> Helper loaded: url_helper
INFO - 2022-07-18 06:10:22 --> Helper loaded: file_helper
INFO - 2022-07-18 06:10:22 --> Database Driver Class Initialized
INFO - 2022-07-18 06:10:22 --> Email Class Initialized
DEBUG - 2022-07-18 06:10:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:10:22 --> Controller Class Initialized
INFO - 2022-07-18 06:10:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:10:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:10:22 --> Final output sent to browser
DEBUG - 2022-07-18 06:10:22 --> Total execution time: 0.0245
INFO - 2022-07-18 06:10:22 --> Config Class Initialized
INFO - 2022-07-18 06:10:22 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:10:22 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:10:22 --> Utf8 Class Initialized
INFO - 2022-07-18 06:10:22 --> URI Class Initialized
INFO - 2022-07-18 06:10:22 --> Router Class Initialized
INFO - 2022-07-18 06:10:22 --> Output Class Initialized
INFO - 2022-07-18 06:10:22 --> Security Class Initialized
DEBUG - 2022-07-18 06:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:10:22 --> Input Class Initialized
INFO - 2022-07-18 06:10:22 --> Language Class Initialized
INFO - 2022-07-18 06:10:22 --> Loader Class Initialized
INFO - 2022-07-18 06:10:22 --> Helper loaded: url_helper
INFO - 2022-07-18 06:10:22 --> Helper loaded: file_helper
INFO - 2022-07-18 06:10:22 --> Database Driver Class Initialized
INFO - 2022-07-18 06:10:22 --> Email Class Initialized
DEBUG - 2022-07-18 06:10:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:10:22 --> Controller Class Initialized
INFO - 2022-07-18 06:10:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:10:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:10:22 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-18 06:10:22 --> Final output sent to browser
DEBUG - 2022-07-18 06:10:22 --> Total execution time: 0.1178
INFO - 2022-07-18 06:10:24 --> Config Class Initialized
INFO - 2022-07-18 06:10:24 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:10:24 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:10:24 --> Utf8 Class Initialized
INFO - 2022-07-18 06:10:24 --> URI Class Initialized
INFO - 2022-07-18 06:10:24 --> Router Class Initialized
INFO - 2022-07-18 06:10:24 --> Output Class Initialized
INFO - 2022-07-18 06:10:24 --> Security Class Initialized
DEBUG - 2022-07-18 06:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:10:24 --> Input Class Initialized
INFO - 2022-07-18 06:10:24 --> Language Class Initialized
INFO - 2022-07-18 06:10:24 --> Loader Class Initialized
INFO - 2022-07-18 06:10:24 --> Helper loaded: url_helper
INFO - 2022-07-18 06:10:24 --> Helper loaded: file_helper
INFO - 2022-07-18 06:10:24 --> Database Driver Class Initialized
INFO - 2022-07-18 06:10:24 --> Email Class Initialized
DEBUG - 2022-07-18 06:10:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:10:24 --> Controller Class Initialized
INFO - 2022-07-18 06:10:24 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:10:24 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:10:24 --> Final output sent to browser
DEBUG - 2022-07-18 06:10:24 --> Total execution time: 0.0164
INFO - 2022-07-18 06:10:27 --> Config Class Initialized
INFO - 2022-07-18 06:10:27 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:10:27 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:10:27 --> Utf8 Class Initialized
INFO - 2022-07-18 06:10:27 --> URI Class Initialized
INFO - 2022-07-18 06:10:27 --> Router Class Initialized
INFO - 2022-07-18 06:10:27 --> Output Class Initialized
INFO - 2022-07-18 06:10:27 --> Security Class Initialized
DEBUG - 2022-07-18 06:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:10:27 --> Input Class Initialized
INFO - 2022-07-18 06:10:27 --> Language Class Initialized
INFO - 2022-07-18 06:10:27 --> Loader Class Initialized
INFO - 2022-07-18 06:10:27 --> Helper loaded: url_helper
INFO - 2022-07-18 06:10:27 --> Helper loaded: file_helper
INFO - 2022-07-18 06:10:27 --> Database Driver Class Initialized
INFO - 2022-07-18 06:10:27 --> Email Class Initialized
DEBUG - 2022-07-18 06:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:10:27 --> Controller Class Initialized
INFO - 2022-07-18 06:10:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:10:27 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:40:28 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:40:28 --> Final output sent to browser
DEBUG - 2022-07-18 11:40:28 --> Total execution time: 0.2940
INFO - 2022-07-18 06:11:57 --> Config Class Initialized
INFO - 2022-07-18 06:11:57 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:11:57 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:11:57 --> Utf8 Class Initialized
INFO - 2022-07-18 06:11:57 --> URI Class Initialized
INFO - 2022-07-18 06:11:57 --> Router Class Initialized
INFO - 2022-07-18 06:11:57 --> Output Class Initialized
INFO - 2022-07-18 06:11:57 --> Security Class Initialized
DEBUG - 2022-07-18 06:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:11:57 --> Input Class Initialized
INFO - 2022-07-18 06:11:57 --> Language Class Initialized
INFO - 2022-07-18 06:11:57 --> Loader Class Initialized
INFO - 2022-07-18 06:11:57 --> Helper loaded: url_helper
INFO - 2022-07-18 06:11:57 --> Helper loaded: file_helper
INFO - 2022-07-18 06:11:57 --> Database Driver Class Initialized
INFO - 2022-07-18 06:11:57 --> Email Class Initialized
DEBUG - 2022-07-18 06:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:11:57 --> Controller Class Initialized
INFO - 2022-07-18 06:11:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:11:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:41:57 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:41:57 --> Final output sent to browser
DEBUG - 2022-07-18 11:41:57 --> Total execution time: 0.0210
INFO - 2022-07-18 06:12:41 --> Config Class Initialized
INFO - 2022-07-18 06:12:41 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:12:41 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:12:41 --> Utf8 Class Initialized
INFO - 2022-07-18 06:12:41 --> URI Class Initialized
INFO - 2022-07-18 06:12:41 --> Router Class Initialized
INFO - 2022-07-18 06:12:41 --> Output Class Initialized
INFO - 2022-07-18 06:12:41 --> Security Class Initialized
DEBUG - 2022-07-18 06:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:12:41 --> Input Class Initialized
INFO - 2022-07-18 06:12:41 --> Language Class Initialized
INFO - 2022-07-18 06:12:41 --> Loader Class Initialized
INFO - 2022-07-18 06:12:41 --> Helper loaded: url_helper
INFO - 2022-07-18 06:12:41 --> Helper loaded: file_helper
INFO - 2022-07-18 06:12:41 --> Database Driver Class Initialized
INFO - 2022-07-18 06:12:41 --> Email Class Initialized
DEBUG - 2022-07-18 06:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:12:41 --> Controller Class Initialized
INFO - 2022-07-18 06:12:41 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:12:41 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:42:42 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:42:42 --> Final output sent to browser
DEBUG - 2022-07-18 11:42:42 --> Total execution time: 0.1005
INFO - 2022-07-18 06:14:04 --> Config Class Initialized
INFO - 2022-07-18 06:14:04 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:14:04 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:14:04 --> Utf8 Class Initialized
INFO - 2022-07-18 06:14:04 --> URI Class Initialized
INFO - 2022-07-18 06:14:04 --> Router Class Initialized
INFO - 2022-07-18 06:14:04 --> Output Class Initialized
INFO - 2022-07-18 06:14:04 --> Security Class Initialized
DEBUG - 2022-07-18 06:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:14:04 --> Input Class Initialized
INFO - 2022-07-18 06:14:04 --> Language Class Initialized
INFO - 2022-07-18 06:14:04 --> Loader Class Initialized
INFO - 2022-07-18 06:14:04 --> Helper loaded: url_helper
INFO - 2022-07-18 06:14:04 --> Helper loaded: file_helper
INFO - 2022-07-18 06:14:04 --> Database Driver Class Initialized
INFO - 2022-07-18 06:14:04 --> Email Class Initialized
DEBUG - 2022-07-18 06:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:14:04 --> Controller Class Initialized
INFO - 2022-07-18 06:14:04 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:14:04 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:14:04 --> Final output sent to browser
DEBUG - 2022-07-18 06:14:04 --> Total execution time: 0.0281
INFO - 2022-07-18 06:14:04 --> Config Class Initialized
INFO - 2022-07-18 06:14:04 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:14:04 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:14:04 --> Utf8 Class Initialized
INFO - 2022-07-18 06:14:04 --> URI Class Initialized
INFO - 2022-07-18 06:14:04 --> Router Class Initialized
INFO - 2022-07-18 06:14:04 --> Output Class Initialized
INFO - 2022-07-18 06:14:04 --> Security Class Initialized
DEBUG - 2022-07-18 06:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:14:04 --> Input Class Initialized
INFO - 2022-07-18 06:14:04 --> Language Class Initialized
INFO - 2022-07-18 06:14:04 --> Loader Class Initialized
INFO - 2022-07-18 06:14:04 --> Helper loaded: url_helper
INFO - 2022-07-18 06:14:04 --> Helper loaded: file_helper
INFO - 2022-07-18 06:14:04 --> Database Driver Class Initialized
INFO - 2022-07-18 06:14:04 --> Email Class Initialized
DEBUG - 2022-07-18 06:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:14:04 --> Controller Class Initialized
INFO - 2022-07-18 06:14:04 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:14:04 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:14:04 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-18 06:14:04 --> Final output sent to browser
DEBUG - 2022-07-18 06:14:04 --> Total execution time: 0.0165
INFO - 2022-07-18 06:14:06 --> Config Class Initialized
INFO - 2022-07-18 06:14:06 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:14:06 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:14:06 --> Utf8 Class Initialized
INFO - 2022-07-18 06:14:06 --> URI Class Initialized
INFO - 2022-07-18 06:14:06 --> Router Class Initialized
INFO - 2022-07-18 06:14:06 --> Output Class Initialized
INFO - 2022-07-18 06:14:06 --> Security Class Initialized
DEBUG - 2022-07-18 06:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:14:06 --> Input Class Initialized
INFO - 2022-07-18 06:14:06 --> Language Class Initialized
INFO - 2022-07-18 06:14:06 --> Loader Class Initialized
INFO - 2022-07-18 06:14:06 --> Helper loaded: url_helper
INFO - 2022-07-18 06:14:06 --> Helper loaded: file_helper
INFO - 2022-07-18 06:14:06 --> Database Driver Class Initialized
INFO - 2022-07-18 06:14:06 --> Email Class Initialized
DEBUG - 2022-07-18 06:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:14:06 --> Controller Class Initialized
INFO - 2022-07-18 06:14:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:14:06 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:14:06 --> Final output sent to browser
DEBUG - 2022-07-18 06:14:06 --> Total execution time: 0.0259
INFO - 2022-07-18 06:14:09 --> Config Class Initialized
INFO - 2022-07-18 06:14:09 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:14:09 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:14:09 --> Utf8 Class Initialized
INFO - 2022-07-18 06:14:09 --> URI Class Initialized
INFO - 2022-07-18 06:14:09 --> Router Class Initialized
INFO - 2022-07-18 06:14:09 --> Output Class Initialized
INFO - 2022-07-18 06:14:09 --> Security Class Initialized
DEBUG - 2022-07-18 06:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:14:09 --> Input Class Initialized
INFO - 2022-07-18 06:14:09 --> Language Class Initialized
INFO - 2022-07-18 06:14:09 --> Loader Class Initialized
INFO - 2022-07-18 06:14:09 --> Helper loaded: url_helper
INFO - 2022-07-18 06:14:09 --> Helper loaded: file_helper
INFO - 2022-07-18 06:14:09 --> Database Driver Class Initialized
INFO - 2022-07-18 06:14:09 --> Email Class Initialized
DEBUG - 2022-07-18 06:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:14:09 --> Controller Class Initialized
INFO - 2022-07-18 06:14:09 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:14:09 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:44:09 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:44:09 --> Final output sent to browser
DEBUG - 2022-07-18 11:44:09 --> Total execution time: 0.1331
INFO - 2022-07-18 06:14:12 --> Config Class Initialized
INFO - 2022-07-18 06:14:12 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:14:12 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:14:12 --> Utf8 Class Initialized
INFO - 2022-07-18 06:14:12 --> URI Class Initialized
INFO - 2022-07-18 06:14:12 --> Router Class Initialized
INFO - 2022-07-18 06:14:12 --> Output Class Initialized
INFO - 2022-07-18 06:14:12 --> Security Class Initialized
DEBUG - 2022-07-18 06:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:14:12 --> Input Class Initialized
INFO - 2022-07-18 06:14:12 --> Language Class Initialized
INFO - 2022-07-18 06:14:12 --> Loader Class Initialized
INFO - 2022-07-18 06:14:12 --> Helper loaded: url_helper
INFO - 2022-07-18 06:14:12 --> Helper loaded: file_helper
INFO - 2022-07-18 06:14:12 --> Database Driver Class Initialized
INFO - 2022-07-18 06:14:12 --> Email Class Initialized
DEBUG - 2022-07-18 06:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:14:12 --> Controller Class Initialized
INFO - 2022-07-18 06:14:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:14:12 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:44:12 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:44:12 --> Final output sent to browser
DEBUG - 2022-07-18 11:44:12 --> Total execution time: 0.0303
INFO - 2022-07-18 06:14:18 --> Config Class Initialized
INFO - 2022-07-18 06:14:18 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:14:18 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:14:18 --> Utf8 Class Initialized
INFO - 2022-07-18 06:14:18 --> URI Class Initialized
INFO - 2022-07-18 06:14:18 --> Router Class Initialized
INFO - 2022-07-18 06:14:18 --> Output Class Initialized
INFO - 2022-07-18 06:14:18 --> Security Class Initialized
DEBUG - 2022-07-18 06:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:14:18 --> Input Class Initialized
INFO - 2022-07-18 06:14:18 --> Language Class Initialized
INFO - 2022-07-18 06:14:18 --> Loader Class Initialized
INFO - 2022-07-18 06:14:18 --> Helper loaded: url_helper
INFO - 2022-07-18 06:14:18 --> Helper loaded: file_helper
INFO - 2022-07-18 06:14:18 --> Database Driver Class Initialized
INFO - 2022-07-18 06:14:18 --> Email Class Initialized
DEBUG - 2022-07-18 06:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:14:18 --> Controller Class Initialized
INFO - 2022-07-18 06:14:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:14:18 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:44:18 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:44:18 --> Final output sent to browser
DEBUG - 2022-07-18 11:44:18 --> Total execution time: 0.0191
INFO - 2022-07-18 06:14:29 --> Config Class Initialized
INFO - 2022-07-18 06:14:29 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:14:29 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:14:29 --> Utf8 Class Initialized
INFO - 2022-07-18 06:14:29 --> URI Class Initialized
INFO - 2022-07-18 06:14:29 --> Router Class Initialized
INFO - 2022-07-18 06:14:29 --> Output Class Initialized
INFO - 2022-07-18 06:14:29 --> Security Class Initialized
DEBUG - 2022-07-18 06:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:14:29 --> Input Class Initialized
INFO - 2022-07-18 06:14:29 --> Language Class Initialized
INFO - 2022-07-18 06:14:29 --> Loader Class Initialized
INFO - 2022-07-18 06:14:29 --> Helper loaded: url_helper
INFO - 2022-07-18 06:14:29 --> Helper loaded: file_helper
INFO - 2022-07-18 06:14:29 --> Database Driver Class Initialized
INFO - 2022-07-18 06:14:29 --> Email Class Initialized
DEBUG - 2022-07-18 06:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:14:29 --> Controller Class Initialized
INFO - 2022-07-18 06:14:29 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:14:29 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:44:29 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:44:29 --> Final output sent to browser
DEBUG - 2022-07-18 11:44:29 --> Total execution time: 0.0211
INFO - 2022-07-18 06:14:32 --> Config Class Initialized
INFO - 2022-07-18 06:14:32 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:14:32 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:14:32 --> Utf8 Class Initialized
INFO - 2022-07-18 06:14:32 --> URI Class Initialized
INFO - 2022-07-18 06:14:32 --> Router Class Initialized
INFO - 2022-07-18 06:14:32 --> Output Class Initialized
INFO - 2022-07-18 06:14:32 --> Security Class Initialized
DEBUG - 2022-07-18 06:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:14:32 --> Input Class Initialized
INFO - 2022-07-18 06:14:32 --> Language Class Initialized
INFO - 2022-07-18 06:14:32 --> Loader Class Initialized
INFO - 2022-07-18 06:14:32 --> Helper loaded: url_helper
INFO - 2022-07-18 06:14:32 --> Helper loaded: file_helper
INFO - 2022-07-18 06:14:32 --> Database Driver Class Initialized
INFO - 2022-07-18 06:14:32 --> Email Class Initialized
DEBUG - 2022-07-18 06:14:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:14:32 --> Controller Class Initialized
INFO - 2022-07-18 06:14:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:14:32 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:14:32 --> Final output sent to browser
DEBUG - 2022-07-18 06:14:32 --> Total execution time: 0.0180
INFO - 2022-07-18 06:14:32 --> Config Class Initialized
INFO - 2022-07-18 06:14:32 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:14:32 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:14:32 --> Utf8 Class Initialized
INFO - 2022-07-18 06:14:32 --> URI Class Initialized
INFO - 2022-07-18 06:14:32 --> Router Class Initialized
INFO - 2022-07-18 06:14:32 --> Output Class Initialized
INFO - 2022-07-18 06:14:32 --> Security Class Initialized
DEBUG - 2022-07-18 06:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:14:32 --> Input Class Initialized
INFO - 2022-07-18 06:14:32 --> Language Class Initialized
INFO - 2022-07-18 06:14:32 --> Loader Class Initialized
INFO - 2022-07-18 06:14:32 --> Helper loaded: url_helper
INFO - 2022-07-18 06:14:32 --> Helper loaded: file_helper
INFO - 2022-07-18 06:14:32 --> Database Driver Class Initialized
INFO - 2022-07-18 06:14:33 --> Email Class Initialized
DEBUG - 2022-07-18 06:14:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:14:33 --> Controller Class Initialized
INFO - 2022-07-18 06:14:33 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:14:33 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:14:33 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-18 06:14:33 --> Final output sent to browser
DEBUG - 2022-07-18 06:14:33 --> Total execution time: 0.0153
INFO - 2022-07-18 06:14:34 --> Config Class Initialized
INFO - 2022-07-18 06:14:34 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:14:34 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:14:34 --> Utf8 Class Initialized
INFO - 2022-07-18 06:14:34 --> URI Class Initialized
INFO - 2022-07-18 06:14:34 --> Router Class Initialized
INFO - 2022-07-18 06:14:34 --> Output Class Initialized
INFO - 2022-07-18 06:14:34 --> Security Class Initialized
DEBUG - 2022-07-18 06:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:14:34 --> Input Class Initialized
INFO - 2022-07-18 06:14:34 --> Language Class Initialized
INFO - 2022-07-18 06:14:34 --> Loader Class Initialized
INFO - 2022-07-18 06:14:34 --> Helper loaded: url_helper
INFO - 2022-07-18 06:14:34 --> Helper loaded: file_helper
INFO - 2022-07-18 06:14:34 --> Database Driver Class Initialized
INFO - 2022-07-18 06:14:34 --> Email Class Initialized
DEBUG - 2022-07-18 06:14:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:14:34 --> Controller Class Initialized
INFO - 2022-07-18 06:14:34 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:14:34 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:14:34 --> Final output sent to browser
DEBUG - 2022-07-18 06:14:34 --> Total execution time: 0.0156
INFO - 2022-07-18 06:14:37 --> Config Class Initialized
INFO - 2022-07-18 06:14:37 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:14:37 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:14:37 --> Utf8 Class Initialized
INFO - 2022-07-18 06:14:37 --> URI Class Initialized
INFO - 2022-07-18 06:14:37 --> Router Class Initialized
INFO - 2022-07-18 06:14:37 --> Output Class Initialized
INFO - 2022-07-18 06:14:37 --> Security Class Initialized
DEBUG - 2022-07-18 06:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:14:37 --> Input Class Initialized
INFO - 2022-07-18 06:14:37 --> Language Class Initialized
INFO - 2022-07-18 06:14:37 --> Loader Class Initialized
INFO - 2022-07-18 06:14:37 --> Helper loaded: url_helper
INFO - 2022-07-18 06:14:37 --> Helper loaded: file_helper
INFO - 2022-07-18 06:14:37 --> Database Driver Class Initialized
INFO - 2022-07-18 06:14:37 --> Email Class Initialized
DEBUG - 2022-07-18 06:14:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:14:37 --> Controller Class Initialized
INFO - 2022-07-18 06:14:37 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:14:37 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:44:37 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:44:37 --> Final output sent to browser
DEBUG - 2022-07-18 11:44:37 --> Total execution time: 0.0202
INFO - 2022-07-18 06:14:38 --> Config Class Initialized
INFO - 2022-07-18 06:14:38 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:14:38 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:14:38 --> Utf8 Class Initialized
INFO - 2022-07-18 06:14:38 --> URI Class Initialized
INFO - 2022-07-18 06:14:38 --> Router Class Initialized
INFO - 2022-07-18 06:14:38 --> Output Class Initialized
INFO - 2022-07-18 06:14:38 --> Security Class Initialized
DEBUG - 2022-07-18 06:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:14:38 --> Input Class Initialized
INFO - 2022-07-18 06:14:38 --> Language Class Initialized
INFO - 2022-07-18 06:14:38 --> Loader Class Initialized
INFO - 2022-07-18 06:14:38 --> Helper loaded: url_helper
INFO - 2022-07-18 06:14:38 --> Helper loaded: file_helper
INFO - 2022-07-18 06:14:38 --> Database Driver Class Initialized
INFO - 2022-07-18 06:14:38 --> Email Class Initialized
DEBUG - 2022-07-18 06:14:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:14:38 --> Controller Class Initialized
INFO - 2022-07-18 06:14:38 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:14:38 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:44:38 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:44:38 --> Final output sent to browser
DEBUG - 2022-07-18 11:44:38 --> Total execution time: 0.0239
INFO - 2022-07-18 06:14:42 --> Config Class Initialized
INFO - 2022-07-18 06:14:42 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:14:42 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:14:42 --> Utf8 Class Initialized
INFO - 2022-07-18 06:14:42 --> URI Class Initialized
INFO - 2022-07-18 06:14:42 --> Router Class Initialized
INFO - 2022-07-18 06:14:42 --> Output Class Initialized
INFO - 2022-07-18 06:14:42 --> Security Class Initialized
DEBUG - 2022-07-18 06:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:14:42 --> Input Class Initialized
INFO - 2022-07-18 06:14:42 --> Language Class Initialized
INFO - 2022-07-18 06:14:42 --> Loader Class Initialized
INFO - 2022-07-18 06:14:42 --> Helper loaded: url_helper
INFO - 2022-07-18 06:14:42 --> Helper loaded: file_helper
INFO - 2022-07-18 06:14:42 --> Database Driver Class Initialized
INFO - 2022-07-18 06:14:42 --> Email Class Initialized
DEBUG - 2022-07-18 06:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:14:42 --> Controller Class Initialized
INFO - 2022-07-18 06:14:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:14:42 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:44:42 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:44:42 --> Final output sent to browser
DEBUG - 2022-07-18 11:44:42 --> Total execution time: 0.0194
INFO - 2022-07-18 06:16:21 --> Config Class Initialized
INFO - 2022-07-18 06:16:21 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:16:21 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:16:21 --> Utf8 Class Initialized
INFO - 2022-07-18 06:16:21 --> URI Class Initialized
INFO - 2022-07-18 06:16:21 --> Router Class Initialized
INFO - 2022-07-18 06:16:21 --> Output Class Initialized
INFO - 2022-07-18 06:16:21 --> Security Class Initialized
DEBUG - 2022-07-18 06:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:16:21 --> Input Class Initialized
INFO - 2022-07-18 06:16:21 --> Language Class Initialized
INFO - 2022-07-18 06:16:21 --> Loader Class Initialized
INFO - 2022-07-18 06:16:21 --> Helper loaded: url_helper
INFO - 2022-07-18 06:16:21 --> Helper loaded: file_helper
INFO - 2022-07-18 06:16:21 --> Database Driver Class Initialized
INFO - 2022-07-18 06:16:21 --> Email Class Initialized
DEBUG - 2022-07-18 06:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:16:21 --> Controller Class Initialized
INFO - 2022-07-18 06:16:21 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:16:21 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:46:21 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:46:21 --> Final output sent to browser
DEBUG - 2022-07-18 11:46:21 --> Total execution time: 0.0525
INFO - 2022-07-18 06:16:24 --> Config Class Initialized
INFO - 2022-07-18 06:16:24 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:16:24 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:16:24 --> Utf8 Class Initialized
INFO - 2022-07-18 06:16:24 --> URI Class Initialized
INFO - 2022-07-18 06:16:24 --> Router Class Initialized
INFO - 2022-07-18 06:16:24 --> Output Class Initialized
INFO - 2022-07-18 06:16:24 --> Security Class Initialized
DEBUG - 2022-07-18 06:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:16:24 --> Input Class Initialized
INFO - 2022-07-18 06:16:24 --> Language Class Initialized
INFO - 2022-07-18 06:16:24 --> Loader Class Initialized
INFO - 2022-07-18 06:16:24 --> Helper loaded: url_helper
INFO - 2022-07-18 06:16:24 --> Helper loaded: file_helper
INFO - 2022-07-18 06:16:24 --> Database Driver Class Initialized
INFO - 2022-07-18 06:16:24 --> Email Class Initialized
DEBUG - 2022-07-18 06:16:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:16:24 --> Controller Class Initialized
INFO - 2022-07-18 06:16:24 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:16:24 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:16:24 --> Final output sent to browser
DEBUG - 2022-07-18 06:16:24 --> Total execution time: 0.0172
INFO - 2022-07-18 06:16:24 --> Config Class Initialized
INFO - 2022-07-18 06:16:24 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:16:24 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:16:24 --> Utf8 Class Initialized
INFO - 2022-07-18 06:16:24 --> URI Class Initialized
INFO - 2022-07-18 06:16:24 --> Router Class Initialized
INFO - 2022-07-18 06:16:24 --> Output Class Initialized
INFO - 2022-07-18 06:16:24 --> Security Class Initialized
DEBUG - 2022-07-18 06:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:16:24 --> Input Class Initialized
INFO - 2022-07-18 06:16:24 --> Language Class Initialized
INFO - 2022-07-18 06:16:24 --> Loader Class Initialized
INFO - 2022-07-18 06:16:24 --> Helper loaded: url_helper
INFO - 2022-07-18 06:16:24 --> Helper loaded: file_helper
INFO - 2022-07-18 06:16:24 --> Database Driver Class Initialized
INFO - 2022-07-18 06:16:24 --> Email Class Initialized
DEBUG - 2022-07-18 06:16:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:16:24 --> Controller Class Initialized
INFO - 2022-07-18 06:16:24 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:16:24 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:16:24 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-18 06:16:24 --> Final output sent to browser
DEBUG - 2022-07-18 06:16:24 --> Total execution time: 0.0172
INFO - 2022-07-18 06:16:26 --> Config Class Initialized
INFO - 2022-07-18 06:16:26 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:16:26 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:16:26 --> Utf8 Class Initialized
INFO - 2022-07-18 06:16:26 --> URI Class Initialized
INFO - 2022-07-18 06:16:26 --> Router Class Initialized
INFO - 2022-07-18 06:16:26 --> Output Class Initialized
INFO - 2022-07-18 06:16:26 --> Security Class Initialized
DEBUG - 2022-07-18 06:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:16:26 --> Input Class Initialized
INFO - 2022-07-18 06:16:26 --> Language Class Initialized
INFO - 2022-07-18 06:16:26 --> Loader Class Initialized
INFO - 2022-07-18 06:16:26 --> Helper loaded: url_helper
INFO - 2022-07-18 06:16:26 --> Helper loaded: file_helper
INFO - 2022-07-18 06:16:26 --> Database Driver Class Initialized
INFO - 2022-07-18 06:16:26 --> Email Class Initialized
DEBUG - 2022-07-18 06:16:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:16:26 --> Controller Class Initialized
INFO - 2022-07-18 06:16:26 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:16:26 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:16:26 --> Final output sent to browser
DEBUG - 2022-07-18 06:16:26 --> Total execution time: 0.0164
INFO - 2022-07-18 06:16:28 --> Config Class Initialized
INFO - 2022-07-18 06:16:28 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:16:28 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:16:28 --> Utf8 Class Initialized
INFO - 2022-07-18 06:16:28 --> URI Class Initialized
INFO - 2022-07-18 06:16:28 --> Router Class Initialized
INFO - 2022-07-18 06:16:28 --> Output Class Initialized
INFO - 2022-07-18 06:16:28 --> Security Class Initialized
DEBUG - 2022-07-18 06:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:16:28 --> Input Class Initialized
INFO - 2022-07-18 06:16:28 --> Language Class Initialized
INFO - 2022-07-18 06:16:28 --> Loader Class Initialized
INFO - 2022-07-18 06:16:28 --> Helper loaded: url_helper
INFO - 2022-07-18 06:16:28 --> Helper loaded: file_helper
INFO - 2022-07-18 06:16:28 --> Database Driver Class Initialized
INFO - 2022-07-18 06:16:28 --> Email Class Initialized
DEBUG - 2022-07-18 06:16:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:16:28 --> Controller Class Initialized
INFO - 2022-07-18 06:16:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:16:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:46:28 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:46:28 --> Final output sent to browser
DEBUG - 2022-07-18 11:46:28 --> Total execution time: 0.0185
INFO - 2022-07-18 06:16:30 --> Config Class Initialized
INFO - 2022-07-18 06:16:30 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:16:30 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:16:30 --> Utf8 Class Initialized
INFO - 2022-07-18 06:16:30 --> URI Class Initialized
INFO - 2022-07-18 06:16:30 --> Router Class Initialized
INFO - 2022-07-18 06:16:30 --> Output Class Initialized
INFO - 2022-07-18 06:16:30 --> Security Class Initialized
DEBUG - 2022-07-18 06:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:16:30 --> Input Class Initialized
INFO - 2022-07-18 06:16:30 --> Language Class Initialized
INFO - 2022-07-18 06:16:30 --> Loader Class Initialized
INFO - 2022-07-18 06:16:30 --> Helper loaded: url_helper
INFO - 2022-07-18 06:16:30 --> Helper loaded: file_helper
INFO - 2022-07-18 06:16:30 --> Database Driver Class Initialized
INFO - 2022-07-18 06:16:30 --> Email Class Initialized
DEBUG - 2022-07-18 06:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:16:30 --> Controller Class Initialized
INFO - 2022-07-18 06:16:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:16:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:46:30 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:46:30 --> Final output sent to browser
DEBUG - 2022-07-18 11:46:30 --> Total execution time: 0.0180
INFO - 2022-07-18 06:16:33 --> Config Class Initialized
INFO - 2022-07-18 06:16:33 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:16:33 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:16:33 --> Utf8 Class Initialized
INFO - 2022-07-18 06:16:33 --> URI Class Initialized
INFO - 2022-07-18 06:16:33 --> Router Class Initialized
INFO - 2022-07-18 06:16:33 --> Output Class Initialized
INFO - 2022-07-18 06:16:33 --> Security Class Initialized
DEBUG - 2022-07-18 06:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:16:33 --> Input Class Initialized
INFO - 2022-07-18 06:16:33 --> Language Class Initialized
INFO - 2022-07-18 06:16:33 --> Loader Class Initialized
INFO - 2022-07-18 06:16:33 --> Helper loaded: url_helper
INFO - 2022-07-18 06:16:33 --> Helper loaded: file_helper
INFO - 2022-07-18 06:16:33 --> Database Driver Class Initialized
INFO - 2022-07-18 06:16:33 --> Email Class Initialized
DEBUG - 2022-07-18 06:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:16:33 --> Controller Class Initialized
INFO - 2022-07-18 06:16:33 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:16:33 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:46:33 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:46:33 --> Final output sent to browser
DEBUG - 2022-07-18 11:46:33 --> Total execution time: 0.0204
INFO - 2022-07-18 06:16:35 --> Config Class Initialized
INFO - 2022-07-18 06:16:35 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:16:35 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:16:35 --> Utf8 Class Initialized
INFO - 2022-07-18 06:16:35 --> URI Class Initialized
INFO - 2022-07-18 06:16:35 --> Router Class Initialized
INFO - 2022-07-18 06:16:35 --> Output Class Initialized
INFO - 2022-07-18 06:16:35 --> Security Class Initialized
DEBUG - 2022-07-18 06:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:16:35 --> Input Class Initialized
INFO - 2022-07-18 06:16:35 --> Language Class Initialized
INFO - 2022-07-18 06:16:35 --> Loader Class Initialized
INFO - 2022-07-18 06:16:35 --> Helper loaded: url_helper
INFO - 2022-07-18 06:16:35 --> Helper loaded: file_helper
INFO - 2022-07-18 06:16:35 --> Database Driver Class Initialized
INFO - 2022-07-18 06:16:35 --> Email Class Initialized
DEBUG - 2022-07-18 06:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:16:35 --> Controller Class Initialized
INFO - 2022-07-18 06:16:35 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:16:35 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:46:35 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:46:35 --> Final output sent to browser
DEBUG - 2022-07-18 11:46:35 --> Total execution time: 0.0172
INFO - 2022-07-18 06:19:02 --> Config Class Initialized
INFO - 2022-07-18 06:19:02 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:19:02 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:19:02 --> Utf8 Class Initialized
INFO - 2022-07-18 06:19:02 --> URI Class Initialized
INFO - 2022-07-18 06:19:02 --> Router Class Initialized
INFO - 2022-07-18 06:19:02 --> Output Class Initialized
INFO - 2022-07-18 06:19:02 --> Security Class Initialized
DEBUG - 2022-07-18 06:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:19:02 --> Input Class Initialized
INFO - 2022-07-18 06:19:02 --> Language Class Initialized
INFO - 2022-07-18 06:19:02 --> Loader Class Initialized
INFO - 2022-07-18 06:19:02 --> Helper loaded: url_helper
INFO - 2022-07-18 06:19:02 --> Helper loaded: file_helper
INFO - 2022-07-18 06:19:02 --> Database Driver Class Initialized
INFO - 2022-07-18 06:19:02 --> Email Class Initialized
DEBUG - 2022-07-18 06:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:19:02 --> Controller Class Initialized
INFO - 2022-07-18 06:19:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:19:02 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:19:02 --> Final output sent to browser
DEBUG - 2022-07-18 06:19:02 --> Total execution time: 0.0239
INFO - 2022-07-18 06:19:02 --> Config Class Initialized
INFO - 2022-07-18 06:19:02 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:19:02 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:19:02 --> Utf8 Class Initialized
INFO - 2022-07-18 06:19:02 --> URI Class Initialized
INFO - 2022-07-18 06:19:02 --> Router Class Initialized
INFO - 2022-07-18 06:19:02 --> Output Class Initialized
INFO - 2022-07-18 06:19:02 --> Security Class Initialized
DEBUG - 2022-07-18 06:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:19:02 --> Input Class Initialized
INFO - 2022-07-18 06:19:02 --> Language Class Initialized
INFO - 2022-07-18 06:19:02 --> Loader Class Initialized
INFO - 2022-07-18 06:19:02 --> Helper loaded: url_helper
INFO - 2022-07-18 06:19:02 --> Helper loaded: file_helper
INFO - 2022-07-18 06:19:02 --> Database Driver Class Initialized
INFO - 2022-07-18 06:19:02 --> Email Class Initialized
DEBUG - 2022-07-18 06:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:19:02 --> Controller Class Initialized
INFO - 2022-07-18 06:19:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:19:02 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:19:02 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-18 06:19:02 --> Final output sent to browser
DEBUG - 2022-07-18 06:19:02 --> Total execution time: 0.0161
INFO - 2022-07-18 06:19:04 --> Config Class Initialized
INFO - 2022-07-18 06:19:04 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:19:04 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:19:04 --> Utf8 Class Initialized
INFO - 2022-07-18 06:19:04 --> URI Class Initialized
INFO - 2022-07-18 06:19:04 --> Router Class Initialized
INFO - 2022-07-18 06:19:04 --> Output Class Initialized
INFO - 2022-07-18 06:19:04 --> Security Class Initialized
DEBUG - 2022-07-18 06:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:19:04 --> Input Class Initialized
INFO - 2022-07-18 06:19:04 --> Language Class Initialized
INFO - 2022-07-18 06:19:04 --> Loader Class Initialized
INFO - 2022-07-18 06:19:04 --> Helper loaded: url_helper
INFO - 2022-07-18 06:19:04 --> Helper loaded: file_helper
INFO - 2022-07-18 06:19:04 --> Database Driver Class Initialized
INFO - 2022-07-18 06:19:04 --> Email Class Initialized
DEBUG - 2022-07-18 06:19:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:19:04 --> Controller Class Initialized
INFO - 2022-07-18 06:19:04 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:19:04 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:19:04 --> Final output sent to browser
DEBUG - 2022-07-18 06:19:04 --> Total execution time: 0.0166
INFO - 2022-07-18 06:19:06 --> Config Class Initialized
INFO - 2022-07-18 06:19:06 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:19:06 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:19:06 --> Utf8 Class Initialized
INFO - 2022-07-18 06:19:06 --> URI Class Initialized
INFO - 2022-07-18 06:19:06 --> Router Class Initialized
INFO - 2022-07-18 06:19:06 --> Output Class Initialized
INFO - 2022-07-18 06:19:06 --> Security Class Initialized
DEBUG - 2022-07-18 06:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:19:06 --> Input Class Initialized
INFO - 2022-07-18 06:19:06 --> Language Class Initialized
INFO - 2022-07-18 06:19:06 --> Loader Class Initialized
INFO - 2022-07-18 06:19:06 --> Helper loaded: url_helper
INFO - 2022-07-18 06:19:06 --> Helper loaded: file_helper
INFO - 2022-07-18 06:19:06 --> Database Driver Class Initialized
INFO - 2022-07-18 06:19:06 --> Email Class Initialized
DEBUG - 2022-07-18 06:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:19:06 --> Controller Class Initialized
INFO - 2022-07-18 06:19:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:19:06 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:49:06 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:49:06 --> Final output sent to browser
DEBUG - 2022-07-18 11:49:06 --> Total execution time: 0.0203
INFO - 2022-07-18 06:19:08 --> Config Class Initialized
INFO - 2022-07-18 06:19:08 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:19:08 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:19:08 --> Utf8 Class Initialized
INFO - 2022-07-18 06:19:08 --> URI Class Initialized
INFO - 2022-07-18 06:19:08 --> Router Class Initialized
INFO - 2022-07-18 06:19:08 --> Output Class Initialized
INFO - 2022-07-18 06:19:08 --> Security Class Initialized
DEBUG - 2022-07-18 06:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:19:08 --> Input Class Initialized
INFO - 2022-07-18 06:19:08 --> Language Class Initialized
INFO - 2022-07-18 06:19:08 --> Loader Class Initialized
INFO - 2022-07-18 06:19:08 --> Helper loaded: url_helper
INFO - 2022-07-18 06:19:08 --> Helper loaded: file_helper
INFO - 2022-07-18 06:19:08 --> Database Driver Class Initialized
INFO - 2022-07-18 06:19:08 --> Email Class Initialized
DEBUG - 2022-07-18 06:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:19:08 --> Controller Class Initialized
INFO - 2022-07-18 06:19:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:19:08 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:49:08 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:49:08 --> Final output sent to browser
DEBUG - 2022-07-18 11:49:08 --> Total execution time: 0.0188
INFO - 2022-07-18 06:19:09 --> Config Class Initialized
INFO - 2022-07-18 06:19:09 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:19:09 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:19:09 --> Utf8 Class Initialized
INFO - 2022-07-18 06:19:09 --> URI Class Initialized
INFO - 2022-07-18 06:19:09 --> Router Class Initialized
INFO - 2022-07-18 06:19:09 --> Output Class Initialized
INFO - 2022-07-18 06:19:09 --> Security Class Initialized
DEBUG - 2022-07-18 06:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:19:09 --> Input Class Initialized
INFO - 2022-07-18 06:19:09 --> Language Class Initialized
INFO - 2022-07-18 06:19:09 --> Loader Class Initialized
INFO - 2022-07-18 06:19:09 --> Helper loaded: url_helper
INFO - 2022-07-18 06:19:09 --> Helper loaded: file_helper
INFO - 2022-07-18 06:19:09 --> Database Driver Class Initialized
INFO - 2022-07-18 06:19:09 --> Email Class Initialized
DEBUG - 2022-07-18 06:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:19:09 --> Controller Class Initialized
INFO - 2022-07-18 06:19:09 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:19:09 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:49:09 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:49:09 --> Final output sent to browser
DEBUG - 2022-07-18 11:49:09 --> Total execution time: 0.0187
INFO - 2022-07-18 06:19:10 --> Config Class Initialized
INFO - 2022-07-18 06:19:10 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:19:10 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:19:10 --> Utf8 Class Initialized
INFO - 2022-07-18 06:19:10 --> URI Class Initialized
INFO - 2022-07-18 06:19:10 --> Router Class Initialized
INFO - 2022-07-18 06:19:10 --> Output Class Initialized
INFO - 2022-07-18 06:19:10 --> Security Class Initialized
DEBUG - 2022-07-18 06:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:19:10 --> Input Class Initialized
INFO - 2022-07-18 06:19:10 --> Language Class Initialized
INFO - 2022-07-18 06:19:10 --> Loader Class Initialized
INFO - 2022-07-18 06:19:10 --> Helper loaded: url_helper
INFO - 2022-07-18 06:19:10 --> Helper loaded: file_helper
INFO - 2022-07-18 06:19:10 --> Database Driver Class Initialized
INFO - 2022-07-18 06:19:10 --> Email Class Initialized
DEBUG - 2022-07-18 06:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:19:10 --> Controller Class Initialized
INFO - 2022-07-18 06:19:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:19:10 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:49:10 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:49:10 --> Final output sent to browser
DEBUG - 2022-07-18 11:49:10 --> Total execution time: 0.1202
INFO - 2022-07-18 06:19:10 --> Config Class Initialized
INFO - 2022-07-18 06:19:10 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:19:10 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:19:10 --> Utf8 Class Initialized
INFO - 2022-07-18 06:19:10 --> URI Class Initialized
INFO - 2022-07-18 06:19:10 --> Router Class Initialized
INFO - 2022-07-18 06:19:10 --> Output Class Initialized
INFO - 2022-07-18 06:19:10 --> Security Class Initialized
DEBUG - 2022-07-18 06:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:19:10 --> Input Class Initialized
INFO - 2022-07-18 06:19:10 --> Language Class Initialized
INFO - 2022-07-18 06:19:10 --> Loader Class Initialized
INFO - 2022-07-18 06:19:10 --> Helper loaded: url_helper
INFO - 2022-07-18 06:19:10 --> Helper loaded: file_helper
INFO - 2022-07-18 06:19:10 --> Database Driver Class Initialized
INFO - 2022-07-18 06:19:10 --> Email Class Initialized
DEBUG - 2022-07-18 06:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:19:10 --> Controller Class Initialized
INFO - 2022-07-18 06:19:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:19:10 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:49:10 --> Final output sent to browser
DEBUG - 2022-07-18 11:49:10 --> Total execution time: 0.0163
INFO - 2022-07-18 06:21:13 --> Config Class Initialized
INFO - 2022-07-18 06:21:13 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:21:13 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:21:13 --> Utf8 Class Initialized
INFO - 2022-07-18 06:21:13 --> URI Class Initialized
INFO - 2022-07-18 06:21:13 --> Router Class Initialized
INFO - 2022-07-18 06:21:13 --> Output Class Initialized
INFO - 2022-07-18 06:21:13 --> Security Class Initialized
DEBUG - 2022-07-18 06:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:21:13 --> Input Class Initialized
INFO - 2022-07-18 06:21:13 --> Language Class Initialized
INFO - 2022-07-18 06:21:13 --> Loader Class Initialized
INFO - 2022-07-18 06:21:13 --> Helper loaded: url_helper
INFO - 2022-07-18 06:21:13 --> Helper loaded: file_helper
INFO - 2022-07-18 06:21:13 --> Database Driver Class Initialized
INFO - 2022-07-18 06:21:13 --> Email Class Initialized
DEBUG - 2022-07-18 06:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:21:13 --> Controller Class Initialized
INFO - 2022-07-18 06:21:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:21:13 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:51:13 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:51:13 --> Final output sent to browser
DEBUG - 2022-07-18 11:51:13 --> Total execution time: 0.1747
INFO - 2022-07-18 06:21:16 --> Config Class Initialized
INFO - 2022-07-18 06:21:16 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:21:16 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:21:16 --> Utf8 Class Initialized
INFO - 2022-07-18 06:21:16 --> URI Class Initialized
INFO - 2022-07-18 06:21:16 --> Router Class Initialized
INFO - 2022-07-18 06:21:16 --> Output Class Initialized
INFO - 2022-07-18 06:21:16 --> Security Class Initialized
DEBUG - 2022-07-18 06:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:21:16 --> Input Class Initialized
INFO - 2022-07-18 06:21:16 --> Language Class Initialized
INFO - 2022-07-18 06:21:16 --> Loader Class Initialized
INFO - 2022-07-18 06:21:16 --> Helper loaded: url_helper
INFO - 2022-07-18 06:21:16 --> Helper loaded: file_helper
INFO - 2022-07-18 06:21:16 --> Database Driver Class Initialized
INFO - 2022-07-18 06:21:16 --> Email Class Initialized
DEBUG - 2022-07-18 06:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:21:16 --> Controller Class Initialized
INFO - 2022-07-18 06:21:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:21:16 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:21:16 --> Final output sent to browser
DEBUG - 2022-07-18 06:21:16 --> Total execution time: 0.0170
INFO - 2022-07-18 06:21:16 --> Config Class Initialized
INFO - 2022-07-18 06:21:16 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:21:16 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:21:16 --> Utf8 Class Initialized
INFO - 2022-07-18 06:21:16 --> URI Class Initialized
INFO - 2022-07-18 06:21:16 --> Router Class Initialized
INFO - 2022-07-18 06:21:16 --> Output Class Initialized
INFO - 2022-07-18 06:21:16 --> Security Class Initialized
DEBUG - 2022-07-18 06:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:21:16 --> Input Class Initialized
INFO - 2022-07-18 06:21:16 --> Language Class Initialized
INFO - 2022-07-18 06:21:16 --> Loader Class Initialized
INFO - 2022-07-18 06:21:16 --> Helper loaded: url_helper
INFO - 2022-07-18 06:21:16 --> Helper loaded: file_helper
INFO - 2022-07-18 06:21:16 --> Database Driver Class Initialized
INFO - 2022-07-18 06:21:16 --> Email Class Initialized
DEBUG - 2022-07-18 06:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:21:16 --> Controller Class Initialized
INFO - 2022-07-18 06:21:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:21:16 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:21:16 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-18 06:21:16 --> Final output sent to browser
DEBUG - 2022-07-18 06:21:16 --> Total execution time: 0.0164
INFO - 2022-07-18 06:21:18 --> Config Class Initialized
INFO - 2022-07-18 06:21:18 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:21:18 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:21:18 --> Utf8 Class Initialized
INFO - 2022-07-18 06:21:18 --> URI Class Initialized
INFO - 2022-07-18 06:21:18 --> Router Class Initialized
INFO - 2022-07-18 06:21:18 --> Output Class Initialized
INFO - 2022-07-18 06:21:18 --> Security Class Initialized
DEBUG - 2022-07-18 06:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:21:18 --> Input Class Initialized
INFO - 2022-07-18 06:21:18 --> Language Class Initialized
INFO - 2022-07-18 06:21:18 --> Loader Class Initialized
INFO - 2022-07-18 06:21:18 --> Helper loaded: url_helper
INFO - 2022-07-18 06:21:18 --> Helper loaded: file_helper
INFO - 2022-07-18 06:21:18 --> Database Driver Class Initialized
INFO - 2022-07-18 06:21:18 --> Email Class Initialized
DEBUG - 2022-07-18 06:21:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:21:18 --> Controller Class Initialized
INFO - 2022-07-18 06:21:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:21:18 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:21:18 --> Final output sent to browser
DEBUG - 2022-07-18 06:21:18 --> Total execution time: 0.0181
INFO - 2022-07-18 06:21:20 --> Config Class Initialized
INFO - 2022-07-18 06:21:20 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:21:20 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:21:20 --> Utf8 Class Initialized
INFO - 2022-07-18 06:21:20 --> URI Class Initialized
INFO - 2022-07-18 06:21:20 --> Router Class Initialized
INFO - 2022-07-18 06:21:20 --> Output Class Initialized
INFO - 2022-07-18 06:21:20 --> Security Class Initialized
DEBUG - 2022-07-18 06:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:21:20 --> Input Class Initialized
INFO - 2022-07-18 06:21:20 --> Language Class Initialized
INFO - 2022-07-18 06:21:20 --> Loader Class Initialized
INFO - 2022-07-18 06:21:20 --> Helper loaded: url_helper
INFO - 2022-07-18 06:21:20 --> Helper loaded: file_helper
INFO - 2022-07-18 06:21:20 --> Database Driver Class Initialized
INFO - 2022-07-18 06:21:20 --> Email Class Initialized
DEBUG - 2022-07-18 06:21:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:21:20 --> Controller Class Initialized
INFO - 2022-07-18 06:21:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:21:20 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:51:20 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:51:20 --> Final output sent to browser
DEBUG - 2022-07-18 11:51:20 --> Total execution time: 0.0220
INFO - 2022-07-18 06:21:23 --> Config Class Initialized
INFO - 2022-07-18 06:21:23 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:21:23 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:21:23 --> Utf8 Class Initialized
INFO - 2022-07-18 06:21:23 --> URI Class Initialized
INFO - 2022-07-18 06:21:23 --> Router Class Initialized
INFO - 2022-07-18 06:21:23 --> Output Class Initialized
INFO - 2022-07-18 06:21:23 --> Security Class Initialized
DEBUG - 2022-07-18 06:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:21:23 --> Input Class Initialized
INFO - 2022-07-18 06:21:23 --> Language Class Initialized
INFO - 2022-07-18 06:21:23 --> Loader Class Initialized
INFO - 2022-07-18 06:21:23 --> Helper loaded: url_helper
INFO - 2022-07-18 06:21:23 --> Helper loaded: file_helper
INFO - 2022-07-18 06:21:23 --> Database Driver Class Initialized
INFO - 2022-07-18 06:21:23 --> Email Class Initialized
DEBUG - 2022-07-18 06:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:21:23 --> Controller Class Initialized
INFO - 2022-07-18 06:21:23 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:21:23 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:51:23 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:51:23 --> Final output sent to browser
DEBUG - 2022-07-18 11:51:23 --> Total execution time: 0.0456
INFO - 2022-07-18 06:21:24 --> Config Class Initialized
INFO - 2022-07-18 06:21:24 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:21:24 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:21:24 --> Utf8 Class Initialized
INFO - 2022-07-18 06:21:24 --> URI Class Initialized
INFO - 2022-07-18 06:21:24 --> Router Class Initialized
INFO - 2022-07-18 06:21:24 --> Output Class Initialized
INFO - 2022-07-18 06:21:24 --> Security Class Initialized
DEBUG - 2022-07-18 06:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:21:24 --> Input Class Initialized
INFO - 2022-07-18 06:21:24 --> Language Class Initialized
INFO - 2022-07-18 06:21:24 --> Loader Class Initialized
INFO - 2022-07-18 06:21:24 --> Helper loaded: url_helper
INFO - 2022-07-18 06:21:24 --> Helper loaded: file_helper
INFO - 2022-07-18 06:21:24 --> Database Driver Class Initialized
INFO - 2022-07-18 06:21:24 --> Email Class Initialized
DEBUG - 2022-07-18 06:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:21:24 --> Controller Class Initialized
INFO - 2022-07-18 06:21:24 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:21:24 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:51:24 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:51:24 --> Final output sent to browser
DEBUG - 2022-07-18 11:51:24 --> Total execution time: 0.1415
INFO - 2022-07-18 06:21:25 --> Config Class Initialized
INFO - 2022-07-18 06:21:25 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:21:25 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:21:25 --> Utf8 Class Initialized
INFO - 2022-07-18 06:21:25 --> URI Class Initialized
INFO - 2022-07-18 06:21:25 --> Router Class Initialized
INFO - 2022-07-18 06:21:25 --> Output Class Initialized
INFO - 2022-07-18 06:21:25 --> Security Class Initialized
DEBUG - 2022-07-18 06:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:21:25 --> Input Class Initialized
INFO - 2022-07-18 06:21:25 --> Language Class Initialized
INFO - 2022-07-18 06:21:25 --> Loader Class Initialized
INFO - 2022-07-18 06:21:25 --> Helper loaded: url_helper
INFO - 2022-07-18 06:21:25 --> Helper loaded: file_helper
INFO - 2022-07-18 06:21:25 --> Database Driver Class Initialized
INFO - 2022-07-18 06:21:25 --> Email Class Initialized
DEBUG - 2022-07-18 06:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:21:25 --> Controller Class Initialized
INFO - 2022-07-18 06:21:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:21:25 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:51:25 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:51:25 --> Final output sent to browser
DEBUG - 2022-07-18 11:51:25 --> Total execution time: 0.0173
INFO - 2022-07-18 06:21:25 --> Config Class Initialized
INFO - 2022-07-18 06:21:25 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:21:25 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:21:25 --> Utf8 Class Initialized
INFO - 2022-07-18 06:21:25 --> URI Class Initialized
INFO - 2022-07-18 06:21:25 --> Router Class Initialized
INFO - 2022-07-18 06:21:25 --> Output Class Initialized
INFO - 2022-07-18 06:21:25 --> Security Class Initialized
DEBUG - 2022-07-18 06:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:21:25 --> Input Class Initialized
INFO - 2022-07-18 06:21:25 --> Language Class Initialized
INFO - 2022-07-18 06:21:25 --> Loader Class Initialized
INFO - 2022-07-18 06:21:25 --> Helper loaded: url_helper
INFO - 2022-07-18 06:21:26 --> Helper loaded: file_helper
INFO - 2022-07-18 06:21:26 --> Database Driver Class Initialized
INFO - 2022-07-18 06:21:26 --> Email Class Initialized
DEBUG - 2022-07-18 06:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:21:26 --> Controller Class Initialized
INFO - 2022-07-18 06:21:26 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:21:26 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:51:26 --> Final output sent to browser
DEBUG - 2022-07-18 11:51:26 --> Total execution time: 0.1263
INFO - 2022-07-18 06:24:44 --> Config Class Initialized
INFO - 2022-07-18 06:24:44 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:24:44 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:24:44 --> Utf8 Class Initialized
INFO - 2022-07-18 06:24:44 --> URI Class Initialized
INFO - 2022-07-18 06:24:44 --> Router Class Initialized
INFO - 2022-07-18 06:24:44 --> Output Class Initialized
INFO - 2022-07-18 06:24:44 --> Security Class Initialized
DEBUG - 2022-07-18 06:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:24:44 --> Input Class Initialized
INFO - 2022-07-18 06:24:44 --> Language Class Initialized
INFO - 2022-07-18 06:24:44 --> Loader Class Initialized
INFO - 2022-07-18 06:24:44 --> Helper loaded: url_helper
INFO - 2022-07-18 06:24:44 --> Helper loaded: file_helper
INFO - 2022-07-18 06:24:44 --> Database Driver Class Initialized
INFO - 2022-07-18 06:24:44 --> Email Class Initialized
DEBUG - 2022-07-18 06:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:24:44 --> Controller Class Initialized
INFO - 2022-07-18 06:24:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:24:44 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:24:44 --> Final output sent to browser
DEBUG - 2022-07-18 06:24:44 --> Total execution time: 0.0236
INFO - 2022-07-18 06:24:44 --> Config Class Initialized
INFO - 2022-07-18 06:24:44 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:24:44 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:24:44 --> Utf8 Class Initialized
INFO - 2022-07-18 06:24:44 --> URI Class Initialized
INFO - 2022-07-18 06:24:44 --> Router Class Initialized
INFO - 2022-07-18 06:24:44 --> Output Class Initialized
INFO - 2022-07-18 06:24:44 --> Security Class Initialized
DEBUG - 2022-07-18 06:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:24:44 --> Input Class Initialized
INFO - 2022-07-18 06:24:44 --> Language Class Initialized
INFO - 2022-07-18 06:24:44 --> Loader Class Initialized
INFO - 2022-07-18 06:24:44 --> Helper loaded: url_helper
INFO - 2022-07-18 06:24:44 --> Helper loaded: file_helper
INFO - 2022-07-18 06:24:44 --> Database Driver Class Initialized
INFO - 2022-07-18 06:24:44 --> Email Class Initialized
DEBUG - 2022-07-18 06:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:24:44 --> Controller Class Initialized
INFO - 2022-07-18 06:24:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:24:44 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:24:44 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-18 06:24:44 --> Final output sent to browser
DEBUG - 2022-07-18 06:24:44 --> Total execution time: 0.0163
INFO - 2022-07-18 06:24:46 --> Config Class Initialized
INFO - 2022-07-18 06:24:46 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:24:46 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:24:46 --> Utf8 Class Initialized
INFO - 2022-07-18 06:24:46 --> URI Class Initialized
INFO - 2022-07-18 06:24:46 --> Router Class Initialized
INFO - 2022-07-18 06:24:46 --> Output Class Initialized
INFO - 2022-07-18 06:24:46 --> Security Class Initialized
DEBUG - 2022-07-18 06:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:24:46 --> Input Class Initialized
INFO - 2022-07-18 06:24:46 --> Language Class Initialized
INFO - 2022-07-18 06:24:46 --> Loader Class Initialized
INFO - 2022-07-18 06:24:46 --> Helper loaded: url_helper
INFO - 2022-07-18 06:24:46 --> Helper loaded: file_helper
INFO - 2022-07-18 06:24:46 --> Database Driver Class Initialized
INFO - 2022-07-18 06:24:46 --> Email Class Initialized
DEBUG - 2022-07-18 06:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:24:46 --> Controller Class Initialized
INFO - 2022-07-18 06:24:46 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:24:46 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:24:46 --> Final output sent to browser
DEBUG - 2022-07-18 06:24:46 --> Total execution time: 0.0164
INFO - 2022-07-18 06:24:49 --> Config Class Initialized
INFO - 2022-07-18 06:24:49 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:24:49 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:24:49 --> Utf8 Class Initialized
INFO - 2022-07-18 06:24:49 --> URI Class Initialized
INFO - 2022-07-18 06:24:49 --> Router Class Initialized
INFO - 2022-07-18 06:24:49 --> Output Class Initialized
INFO - 2022-07-18 06:24:49 --> Security Class Initialized
DEBUG - 2022-07-18 06:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:24:49 --> Input Class Initialized
INFO - 2022-07-18 06:24:49 --> Language Class Initialized
INFO - 2022-07-18 06:24:49 --> Loader Class Initialized
INFO - 2022-07-18 06:24:49 --> Helper loaded: url_helper
INFO - 2022-07-18 06:24:49 --> Helper loaded: file_helper
INFO - 2022-07-18 06:24:49 --> Database Driver Class Initialized
INFO - 2022-07-18 06:24:49 --> Email Class Initialized
DEBUG - 2022-07-18 06:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:24:49 --> Controller Class Initialized
INFO - 2022-07-18 06:24:49 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:24:49 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:54:49 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:54:49 --> Final output sent to browser
DEBUG - 2022-07-18 11:54:49 --> Total execution time: 0.0399
INFO - 2022-07-18 06:24:53 --> Config Class Initialized
INFO - 2022-07-18 06:24:53 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:24:53 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:24:53 --> Utf8 Class Initialized
INFO - 2022-07-18 06:24:53 --> URI Class Initialized
INFO - 2022-07-18 06:24:53 --> Router Class Initialized
INFO - 2022-07-18 06:24:53 --> Output Class Initialized
INFO - 2022-07-18 06:24:53 --> Security Class Initialized
DEBUG - 2022-07-18 06:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:24:53 --> Input Class Initialized
INFO - 2022-07-18 06:24:53 --> Language Class Initialized
INFO - 2022-07-18 06:24:53 --> Loader Class Initialized
INFO - 2022-07-18 06:24:53 --> Helper loaded: url_helper
INFO - 2022-07-18 06:24:53 --> Helper loaded: file_helper
INFO - 2022-07-18 06:24:53 --> Database Driver Class Initialized
INFO - 2022-07-18 06:24:53 --> Email Class Initialized
DEBUG - 2022-07-18 06:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:24:53 --> Controller Class Initialized
INFO - 2022-07-18 06:24:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:24:53 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:54:53 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:54:53 --> Final output sent to browser
DEBUG - 2022-07-18 11:54:53 --> Total execution time: 0.0205
INFO - 2022-07-18 06:24:57 --> Config Class Initialized
INFO - 2022-07-18 06:24:57 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:24:57 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:24:57 --> Utf8 Class Initialized
INFO - 2022-07-18 06:24:57 --> URI Class Initialized
INFO - 2022-07-18 06:24:57 --> Router Class Initialized
INFO - 2022-07-18 06:24:57 --> Output Class Initialized
INFO - 2022-07-18 06:24:57 --> Security Class Initialized
DEBUG - 2022-07-18 06:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:24:57 --> Input Class Initialized
INFO - 2022-07-18 06:24:57 --> Language Class Initialized
INFO - 2022-07-18 06:24:57 --> Loader Class Initialized
INFO - 2022-07-18 06:24:57 --> Helper loaded: url_helper
INFO - 2022-07-18 06:24:57 --> Helper loaded: file_helper
INFO - 2022-07-18 06:24:57 --> Database Driver Class Initialized
INFO - 2022-07-18 06:24:57 --> Email Class Initialized
DEBUG - 2022-07-18 06:24:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:24:57 --> Controller Class Initialized
INFO - 2022-07-18 06:24:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:24:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:54:57 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:54:57 --> Final output sent to browser
DEBUG - 2022-07-18 11:54:57 --> Total execution time: 0.1171
INFO - 2022-07-18 06:24:58 --> Config Class Initialized
INFO - 2022-07-18 06:24:58 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:24:58 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:24:58 --> Utf8 Class Initialized
INFO - 2022-07-18 06:24:58 --> URI Class Initialized
INFO - 2022-07-18 06:24:58 --> Router Class Initialized
INFO - 2022-07-18 06:24:58 --> Output Class Initialized
INFO - 2022-07-18 06:24:58 --> Security Class Initialized
DEBUG - 2022-07-18 06:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:24:58 --> Input Class Initialized
INFO - 2022-07-18 06:24:58 --> Language Class Initialized
INFO - 2022-07-18 06:24:58 --> Loader Class Initialized
INFO - 2022-07-18 06:24:58 --> Helper loaded: url_helper
INFO - 2022-07-18 06:24:58 --> Helper loaded: file_helper
INFO - 2022-07-18 06:24:58 --> Database Driver Class Initialized
INFO - 2022-07-18 06:24:58 --> Email Class Initialized
DEBUG - 2022-07-18 06:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:24:58 --> Controller Class Initialized
INFO - 2022-07-18 06:24:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:24:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:54:58 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:54:58 --> Final output sent to browser
DEBUG - 2022-07-18 11:54:58 --> Total execution time: 0.0179
INFO - 2022-07-18 06:25:06 --> Config Class Initialized
INFO - 2022-07-18 06:25:06 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:25:06 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:25:06 --> Utf8 Class Initialized
INFO - 2022-07-18 06:25:06 --> URI Class Initialized
INFO - 2022-07-18 06:25:06 --> Router Class Initialized
INFO - 2022-07-18 06:25:06 --> Output Class Initialized
INFO - 2022-07-18 06:25:06 --> Security Class Initialized
DEBUG - 2022-07-18 06:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:25:06 --> Input Class Initialized
INFO - 2022-07-18 06:25:06 --> Language Class Initialized
INFO - 2022-07-18 06:25:06 --> Loader Class Initialized
INFO - 2022-07-18 06:25:06 --> Helper loaded: url_helper
INFO - 2022-07-18 06:25:06 --> Helper loaded: file_helper
INFO - 2022-07-18 06:25:06 --> Database Driver Class Initialized
INFO - 2022-07-18 06:25:06 --> Email Class Initialized
DEBUG - 2022-07-18 06:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:25:06 --> Controller Class Initialized
INFO - 2022-07-18 06:25:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:25:06 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:25:06 --> Final output sent to browser
DEBUG - 2022-07-18 06:25:06 --> Total execution time: 0.0154
INFO - 2022-07-18 06:25:06 --> Config Class Initialized
INFO - 2022-07-18 06:25:06 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:25:06 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:25:06 --> Utf8 Class Initialized
INFO - 2022-07-18 06:25:06 --> URI Class Initialized
INFO - 2022-07-18 06:25:06 --> Router Class Initialized
INFO - 2022-07-18 06:25:06 --> Output Class Initialized
INFO - 2022-07-18 06:25:06 --> Security Class Initialized
DEBUG - 2022-07-18 06:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:25:06 --> Input Class Initialized
INFO - 2022-07-18 06:25:06 --> Language Class Initialized
INFO - 2022-07-18 06:25:06 --> Loader Class Initialized
INFO - 2022-07-18 06:25:06 --> Helper loaded: url_helper
INFO - 2022-07-18 06:25:06 --> Helper loaded: file_helper
INFO - 2022-07-18 06:25:06 --> Database Driver Class Initialized
INFO - 2022-07-18 06:25:06 --> Email Class Initialized
DEBUG - 2022-07-18 06:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:25:06 --> Controller Class Initialized
INFO - 2022-07-18 06:25:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:25:06 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:25:06 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-18 06:25:06 --> Final output sent to browser
DEBUG - 2022-07-18 06:25:06 --> Total execution time: 0.0156
INFO - 2022-07-18 06:25:09 --> Config Class Initialized
INFO - 2022-07-18 06:25:09 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:25:09 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:25:09 --> Utf8 Class Initialized
INFO - 2022-07-18 06:25:09 --> URI Class Initialized
INFO - 2022-07-18 06:25:09 --> Router Class Initialized
INFO - 2022-07-18 06:25:09 --> Output Class Initialized
INFO - 2022-07-18 06:25:09 --> Security Class Initialized
DEBUG - 2022-07-18 06:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:25:09 --> Input Class Initialized
INFO - 2022-07-18 06:25:09 --> Language Class Initialized
INFO - 2022-07-18 06:25:09 --> Loader Class Initialized
INFO - 2022-07-18 06:25:09 --> Helper loaded: url_helper
INFO - 2022-07-18 06:25:09 --> Helper loaded: file_helper
INFO - 2022-07-18 06:25:09 --> Database Driver Class Initialized
INFO - 2022-07-18 06:25:09 --> Email Class Initialized
DEBUG - 2022-07-18 06:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:25:09 --> Controller Class Initialized
INFO - 2022-07-18 06:25:09 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:25:09 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:25:09 --> Final output sent to browser
DEBUG - 2022-07-18 06:25:09 --> Total execution time: 0.0165
INFO - 2022-07-18 06:25:12 --> Config Class Initialized
INFO - 2022-07-18 06:25:12 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:25:12 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:25:12 --> Utf8 Class Initialized
INFO - 2022-07-18 06:25:12 --> URI Class Initialized
INFO - 2022-07-18 06:25:12 --> Router Class Initialized
INFO - 2022-07-18 06:25:12 --> Output Class Initialized
INFO - 2022-07-18 06:25:12 --> Security Class Initialized
DEBUG - 2022-07-18 06:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:25:12 --> Input Class Initialized
INFO - 2022-07-18 06:25:12 --> Language Class Initialized
INFO - 2022-07-18 06:25:12 --> Loader Class Initialized
INFO - 2022-07-18 06:25:12 --> Helper loaded: url_helper
INFO - 2022-07-18 06:25:12 --> Helper loaded: file_helper
INFO - 2022-07-18 06:25:12 --> Database Driver Class Initialized
INFO - 2022-07-18 06:25:12 --> Email Class Initialized
DEBUG - 2022-07-18 06:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:25:12 --> Controller Class Initialized
INFO - 2022-07-18 06:25:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:25:12 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 11:55:12 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 11:55:12 --> Final output sent to browser
DEBUG - 2022-07-18 11:55:12 --> Total execution time: 0.0188
INFO - 2022-07-18 06:53:56 --> Config Class Initialized
INFO - 2022-07-18 06:53:56 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:53:56 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:53:56 --> Utf8 Class Initialized
INFO - 2022-07-18 06:53:56 --> URI Class Initialized
INFO - 2022-07-18 06:53:56 --> Router Class Initialized
INFO - 2022-07-18 06:53:56 --> Output Class Initialized
INFO - 2022-07-18 06:53:56 --> Security Class Initialized
DEBUG - 2022-07-18 06:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:53:56 --> Input Class Initialized
INFO - 2022-07-18 06:53:56 --> Language Class Initialized
INFO - 2022-07-18 06:53:56 --> Loader Class Initialized
INFO - 2022-07-18 06:53:56 --> Helper loaded: url_helper
INFO - 2022-07-18 06:53:56 --> Helper loaded: file_helper
INFO - 2022-07-18 06:53:56 --> Database Driver Class Initialized
INFO - 2022-07-18 06:53:56 --> Email Class Initialized
DEBUG - 2022-07-18 06:53:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:53:56 --> Controller Class Initialized
INFO - 2022-07-18 06:53:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:53:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:53:56 --> Final output sent to browser
DEBUG - 2022-07-18 06:53:56 --> Total execution time: 0.2404
INFO - 2022-07-18 06:53:56 --> Config Class Initialized
INFO - 2022-07-18 06:53:56 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:53:56 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:53:56 --> Utf8 Class Initialized
INFO - 2022-07-18 06:53:56 --> URI Class Initialized
INFO - 2022-07-18 06:53:56 --> Router Class Initialized
INFO - 2022-07-18 06:53:56 --> Output Class Initialized
INFO - 2022-07-18 06:53:56 --> Security Class Initialized
DEBUG - 2022-07-18 06:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:53:56 --> Input Class Initialized
INFO - 2022-07-18 06:53:56 --> Language Class Initialized
INFO - 2022-07-18 06:53:56 --> Loader Class Initialized
INFO - 2022-07-18 06:53:56 --> Helper loaded: url_helper
INFO - 2022-07-18 06:53:56 --> Helper loaded: file_helper
INFO - 2022-07-18 06:53:56 --> Database Driver Class Initialized
INFO - 2022-07-18 06:53:56 --> Email Class Initialized
DEBUG - 2022-07-18 06:53:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:53:56 --> Controller Class Initialized
INFO - 2022-07-18 06:53:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:53:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:53:56 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-18 06:53:56 --> Final output sent to browser
DEBUG - 2022-07-18 06:53:56 --> Total execution time: 0.0210
INFO - 2022-07-18 06:53:58 --> Config Class Initialized
INFO - 2022-07-18 06:53:58 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:53:58 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:53:58 --> Utf8 Class Initialized
INFO - 2022-07-18 06:53:58 --> URI Class Initialized
INFO - 2022-07-18 06:53:58 --> Router Class Initialized
INFO - 2022-07-18 06:53:58 --> Output Class Initialized
INFO - 2022-07-18 06:53:58 --> Security Class Initialized
DEBUG - 2022-07-18 06:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:53:58 --> Input Class Initialized
INFO - 2022-07-18 06:53:58 --> Language Class Initialized
INFO - 2022-07-18 06:53:58 --> Loader Class Initialized
INFO - 2022-07-18 06:53:58 --> Helper loaded: url_helper
INFO - 2022-07-18 06:53:58 --> Helper loaded: file_helper
INFO - 2022-07-18 06:53:58 --> Database Driver Class Initialized
INFO - 2022-07-18 06:53:58 --> Email Class Initialized
DEBUG - 2022-07-18 06:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:53:58 --> Controller Class Initialized
INFO - 2022-07-18 06:53:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:53:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:53:58 --> Final output sent to browser
DEBUG - 2022-07-18 06:53:58 --> Total execution time: 0.0758
INFO - 2022-07-18 06:54:05 --> Config Class Initialized
INFO - 2022-07-18 06:54:05 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:54:05 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:54:05 --> Utf8 Class Initialized
INFO - 2022-07-18 06:54:05 --> URI Class Initialized
INFO - 2022-07-18 06:54:05 --> Router Class Initialized
INFO - 2022-07-18 06:54:05 --> Output Class Initialized
INFO - 2022-07-18 06:54:05 --> Security Class Initialized
DEBUG - 2022-07-18 06:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:54:05 --> Input Class Initialized
INFO - 2022-07-18 06:54:05 --> Language Class Initialized
INFO - 2022-07-18 06:54:05 --> Loader Class Initialized
INFO - 2022-07-18 06:54:05 --> Helper loaded: url_helper
INFO - 2022-07-18 06:54:05 --> Helper loaded: file_helper
INFO - 2022-07-18 06:54:05 --> Database Driver Class Initialized
INFO - 2022-07-18 06:54:05 --> Email Class Initialized
DEBUG - 2022-07-18 06:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:54:05 --> Controller Class Initialized
INFO - 2022-07-18 06:54:05 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:54:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-07-18 06:54:05 --> insertedINSERT INTO `tokendetails` (`td_tk`, `td_cs`, `td_visited_date`) VALUES (5, 0, '2022-07-18')
ERROR - 2022-07-18 06:54:05 --> Severity: Notice --> Undefined variable: time_est C:\wamp64\www\qr\application\controllers\Tokenctrl.php 517
ERROR - 2022-07-18 06:54:05 --> Severity: Notice --> Undefined variable: time_est C:\wamp64\www\qr\application\controllers\Tokenctrl.php 521
INFO - 2022-07-18 06:54:05 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-18 06:54:05 --> Final output sent to browser
DEBUG - 2022-07-18 06:54:05 --> Total execution time: 0.3138
INFO - 2022-07-18 06:54:07 --> Config Class Initialized
INFO - 2022-07-18 06:54:07 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:54:07 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:54:07 --> Utf8 Class Initialized
INFO - 2022-07-18 06:54:07 --> URI Class Initialized
INFO - 2022-07-18 06:54:07 --> Router Class Initialized
INFO - 2022-07-18 06:54:07 --> Output Class Initialized
INFO - 2022-07-18 06:54:07 --> Security Class Initialized
DEBUG - 2022-07-18 06:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:54:07 --> Input Class Initialized
INFO - 2022-07-18 06:54:07 --> Language Class Initialized
INFO - 2022-07-18 06:54:07 --> Loader Class Initialized
INFO - 2022-07-18 06:54:07 --> Helper loaded: url_helper
INFO - 2022-07-18 06:54:07 --> Helper loaded: file_helper
INFO - 2022-07-18 06:54:07 --> Database Driver Class Initialized
INFO - 2022-07-18 06:54:07 --> Email Class Initialized
DEBUG - 2022-07-18 06:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:54:07 --> Controller Class Initialized
INFO - 2022-07-18 06:54:07 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:54:07 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:54:07 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-18 06:54:07 --> Final output sent to browser
DEBUG - 2022-07-18 06:54:07 --> Total execution time: 0.0599
INFO - 2022-07-18 06:54:22 --> Config Class Initialized
INFO - 2022-07-18 06:54:22 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:54:22 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:54:22 --> Utf8 Class Initialized
INFO - 2022-07-18 06:54:22 --> URI Class Initialized
INFO - 2022-07-18 06:54:22 --> Router Class Initialized
INFO - 2022-07-18 06:54:22 --> Output Class Initialized
INFO - 2022-07-18 06:54:22 --> Security Class Initialized
DEBUG - 2022-07-18 06:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:54:22 --> Input Class Initialized
INFO - 2022-07-18 06:54:22 --> Language Class Initialized
INFO - 2022-07-18 06:54:22 --> Loader Class Initialized
INFO - 2022-07-18 06:54:22 --> Helper loaded: url_helper
INFO - 2022-07-18 06:54:22 --> Helper loaded: file_helper
INFO - 2022-07-18 06:54:22 --> Database Driver Class Initialized
INFO - 2022-07-18 06:54:22 --> Email Class Initialized
DEBUG - 2022-07-18 06:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:54:22 --> Controller Class Initialized
INFO - 2022-07-18 06:54:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:54:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:54:22 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-18 06:54:22 --> Final output sent to browser
DEBUG - 2022-07-18 06:54:22 --> Total execution time: 0.0587
INFO - 2022-07-18 06:54:23 --> Config Class Initialized
INFO - 2022-07-18 06:54:23 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:54:23 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:54:23 --> Utf8 Class Initialized
INFO - 2022-07-18 06:54:23 --> URI Class Initialized
INFO - 2022-07-18 06:54:23 --> Router Class Initialized
INFO - 2022-07-18 06:54:23 --> Output Class Initialized
INFO - 2022-07-18 06:54:23 --> Security Class Initialized
DEBUG - 2022-07-18 06:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:54:23 --> Input Class Initialized
INFO - 2022-07-18 06:54:23 --> Language Class Initialized
INFO - 2022-07-18 06:54:23 --> Loader Class Initialized
INFO - 2022-07-18 06:54:23 --> Helper loaded: url_helper
INFO - 2022-07-18 06:54:23 --> Helper loaded: file_helper
INFO - 2022-07-18 06:54:23 --> Database Driver Class Initialized
INFO - 2022-07-18 06:54:23 --> Email Class Initialized
DEBUG - 2022-07-18 06:54:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:54:23 --> Controller Class Initialized
INFO - 2022-07-18 06:54:23 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:54:23 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:54:23 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-18 06:54:23 --> Final output sent to browser
DEBUG - 2022-07-18 06:54:23 --> Total execution time: 0.0578
INFO - 2022-07-18 06:56:08 --> Config Class Initialized
INFO - 2022-07-18 06:56:08 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:56:08 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:56:08 --> Utf8 Class Initialized
INFO - 2022-07-18 06:56:08 --> URI Class Initialized
INFO - 2022-07-18 06:56:08 --> Router Class Initialized
INFO - 2022-07-18 06:56:08 --> Output Class Initialized
INFO - 2022-07-18 06:56:08 --> Security Class Initialized
DEBUG - 2022-07-18 06:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:56:08 --> Input Class Initialized
INFO - 2022-07-18 06:56:08 --> Language Class Initialized
INFO - 2022-07-18 06:56:08 --> Loader Class Initialized
INFO - 2022-07-18 06:56:08 --> Helper loaded: url_helper
INFO - 2022-07-18 06:56:08 --> Helper loaded: file_helper
INFO - 2022-07-18 06:56:08 --> Database Driver Class Initialized
INFO - 2022-07-18 06:56:08 --> Email Class Initialized
DEBUG - 2022-07-18 06:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:56:08 --> Controller Class Initialized
INFO - 2022-07-18 06:56:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:56:08 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:56:08 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-18 06:56:08 --> Final output sent to browser
DEBUG - 2022-07-18 06:56:08 --> Total execution time: 0.0557
INFO - 2022-07-18 06:56:11 --> Config Class Initialized
INFO - 2022-07-18 06:56:11 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:56:11 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:56:11 --> Utf8 Class Initialized
INFO - 2022-07-18 06:56:11 --> URI Class Initialized
INFO - 2022-07-18 06:56:11 --> Router Class Initialized
INFO - 2022-07-18 06:56:11 --> Output Class Initialized
INFO - 2022-07-18 06:56:11 --> Security Class Initialized
DEBUG - 2022-07-18 06:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:56:11 --> Input Class Initialized
INFO - 2022-07-18 06:56:11 --> Language Class Initialized
INFO - 2022-07-18 06:56:11 --> Loader Class Initialized
INFO - 2022-07-18 06:56:11 --> Helper loaded: url_helper
INFO - 2022-07-18 06:56:11 --> Helper loaded: file_helper
INFO - 2022-07-18 06:56:11 --> Database Driver Class Initialized
INFO - 2022-07-18 06:56:11 --> Email Class Initialized
DEBUG - 2022-07-18 06:56:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:56:11 --> Controller Class Initialized
INFO - 2022-07-18 06:56:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:56:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:56:11 --> Final output sent to browser
DEBUG - 2022-07-18 06:56:11 --> Total execution time: 0.0484
INFO - 2022-07-18 06:58:42 --> Config Class Initialized
INFO - 2022-07-18 06:58:42 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:58:42 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:58:42 --> Utf8 Class Initialized
INFO - 2022-07-18 06:58:42 --> URI Class Initialized
INFO - 2022-07-18 06:58:42 --> Router Class Initialized
INFO - 2022-07-18 06:58:42 --> Output Class Initialized
INFO - 2022-07-18 06:58:42 --> Security Class Initialized
DEBUG - 2022-07-18 06:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:58:42 --> Input Class Initialized
INFO - 2022-07-18 06:58:42 --> Language Class Initialized
ERROR - 2022-07-18 06:58:42 --> Severity: error --> Exception: syntax error, unexpected '1' (T_LNUMBER), expecting variable (T_VARIABLE) or '{' or '$' C:\wamp64\www\qr\application\controllers\Tokenctrl.php 114
INFO - 2022-07-18 06:58:59 --> Config Class Initialized
INFO - 2022-07-18 06:58:59 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:58:59 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:58:59 --> Utf8 Class Initialized
INFO - 2022-07-18 06:58:59 --> URI Class Initialized
INFO - 2022-07-18 06:58:59 --> Router Class Initialized
INFO - 2022-07-18 06:58:59 --> Output Class Initialized
INFO - 2022-07-18 06:58:59 --> Security Class Initialized
DEBUG - 2022-07-18 06:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:58:59 --> Input Class Initialized
INFO - 2022-07-18 06:58:59 --> Language Class Initialized
ERROR - 2022-07-18 06:58:59 --> Severity: error --> Exception: syntax error, unexpected '1' (T_LNUMBER), expecting variable (T_VARIABLE) or '{' or '$' C:\wamp64\www\qr\application\controllers\Tokenctrl.php 114
INFO - 2022-07-18 06:59:04 --> Config Class Initialized
INFO - 2022-07-18 06:59:04 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:59:04 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:59:04 --> Utf8 Class Initialized
INFO - 2022-07-18 06:59:04 --> URI Class Initialized
INFO - 2022-07-18 06:59:04 --> Router Class Initialized
INFO - 2022-07-18 06:59:04 --> Output Class Initialized
INFO - 2022-07-18 06:59:04 --> Security Class Initialized
DEBUG - 2022-07-18 06:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:59:04 --> Input Class Initialized
INFO - 2022-07-18 06:59:04 --> Language Class Initialized
ERROR - 2022-07-18 06:59:04 --> Severity: error --> Exception: syntax error, unexpected '1' (T_LNUMBER), expecting variable (T_VARIABLE) or '{' or '$' C:\wamp64\www\qr\application\controllers\Tokenctrl.php 114
INFO - 2022-07-18 06:59:25 --> Config Class Initialized
INFO - 2022-07-18 06:59:25 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:59:25 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:59:25 --> Utf8 Class Initialized
INFO - 2022-07-18 06:59:25 --> URI Class Initialized
INFO - 2022-07-18 06:59:25 --> Router Class Initialized
INFO - 2022-07-18 06:59:25 --> Output Class Initialized
INFO - 2022-07-18 06:59:25 --> Security Class Initialized
DEBUG - 2022-07-18 06:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:59:25 --> Input Class Initialized
INFO - 2022-07-18 06:59:25 --> Language Class Initialized
INFO - 2022-07-18 06:59:25 --> Loader Class Initialized
INFO - 2022-07-18 06:59:25 --> Helper loaded: url_helper
INFO - 2022-07-18 06:59:25 --> Helper loaded: file_helper
INFO - 2022-07-18 06:59:25 --> Database Driver Class Initialized
INFO - 2022-07-18 06:59:25 --> Email Class Initialized
DEBUG - 2022-07-18 06:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:59:25 --> Controller Class Initialized
INFO - 2022-07-18 06:59:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:59:25 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:59:25 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-18 06:59:25 --> Final output sent to browser
DEBUG - 2022-07-18 06:59:25 --> Total execution time: 0.0827
INFO - 2022-07-18 06:59:28 --> Config Class Initialized
INFO - 2022-07-18 06:59:28 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:59:28 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:59:28 --> Utf8 Class Initialized
INFO - 2022-07-18 06:59:28 --> URI Class Initialized
INFO - 2022-07-18 06:59:28 --> Router Class Initialized
INFO - 2022-07-18 06:59:28 --> Output Class Initialized
INFO - 2022-07-18 06:59:28 --> Security Class Initialized
DEBUG - 2022-07-18 06:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:59:28 --> Input Class Initialized
INFO - 2022-07-18 06:59:28 --> Language Class Initialized
INFO - 2022-07-18 06:59:28 --> Loader Class Initialized
INFO - 2022-07-18 06:59:28 --> Helper loaded: url_helper
INFO - 2022-07-18 06:59:28 --> Helper loaded: file_helper
INFO - 2022-07-18 06:59:28 --> Database Driver Class Initialized
INFO - 2022-07-18 06:59:28 --> Email Class Initialized
DEBUG - 2022-07-18 06:59:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:59:28 --> Controller Class Initialized
INFO - 2022-07-18 06:59:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:59:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 06:59:28 --> Severity: Notice --> Undefined variable: tk C:\wamp64\www\qr\application\controllers\Tokenctrl.php 115
ERROR - 2022-07-18 06:59:28 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::insesrt() C:\wamp64\www\qr\application\models\Tokenmodel.php 31
INFO - 2022-07-18 06:59:47 --> Config Class Initialized
INFO - 2022-07-18 06:59:47 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:59:47 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:59:47 --> Utf8 Class Initialized
INFO - 2022-07-18 06:59:47 --> URI Class Initialized
INFO - 2022-07-18 06:59:47 --> Router Class Initialized
INFO - 2022-07-18 06:59:47 --> Output Class Initialized
INFO - 2022-07-18 06:59:47 --> Security Class Initialized
DEBUG - 2022-07-18 06:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:59:47 --> Input Class Initialized
INFO - 2022-07-18 06:59:47 --> Language Class Initialized
INFO - 2022-07-18 06:59:47 --> Loader Class Initialized
INFO - 2022-07-18 06:59:47 --> Helper loaded: url_helper
INFO - 2022-07-18 06:59:47 --> Helper loaded: file_helper
INFO - 2022-07-18 06:59:47 --> Database Driver Class Initialized
INFO - 2022-07-18 06:59:47 --> Email Class Initialized
DEBUG - 2022-07-18 06:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:59:47 --> Controller Class Initialized
INFO - 2022-07-18 06:59:47 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:59:47 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:59:47 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-18 06:59:47 --> Final output sent to browser
DEBUG - 2022-07-18 06:59:47 --> Total execution time: 0.0623
INFO - 2022-07-18 06:59:49 --> Config Class Initialized
INFO - 2022-07-18 06:59:49 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:59:49 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:59:49 --> Utf8 Class Initialized
INFO - 2022-07-18 06:59:49 --> URI Class Initialized
INFO - 2022-07-18 06:59:49 --> Router Class Initialized
INFO - 2022-07-18 06:59:49 --> Output Class Initialized
INFO - 2022-07-18 06:59:49 --> Security Class Initialized
DEBUG - 2022-07-18 06:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:59:49 --> Input Class Initialized
INFO - 2022-07-18 06:59:49 --> Language Class Initialized
INFO - 2022-07-18 06:59:49 --> Loader Class Initialized
INFO - 2022-07-18 06:59:49 --> Helper loaded: url_helper
INFO - 2022-07-18 06:59:49 --> Helper loaded: file_helper
INFO - 2022-07-18 06:59:49 --> Database Driver Class Initialized
INFO - 2022-07-18 06:59:49 --> Email Class Initialized
DEBUG - 2022-07-18 06:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:59:49 --> Controller Class Initialized
INFO - 2022-07-18 06:59:49 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:59:49 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 06:59:49 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-18 06:59:49 --> Final output sent to browser
DEBUG - 2022-07-18 06:59:49 --> Total execution time: 0.0594
INFO - 2022-07-18 06:59:51 --> Config Class Initialized
INFO - 2022-07-18 06:59:51 --> Hooks Class Initialized
DEBUG - 2022-07-18 06:59:51 --> UTF-8 Support Enabled
INFO - 2022-07-18 06:59:51 --> Utf8 Class Initialized
INFO - 2022-07-18 06:59:51 --> URI Class Initialized
INFO - 2022-07-18 06:59:51 --> Router Class Initialized
INFO - 2022-07-18 06:59:51 --> Output Class Initialized
INFO - 2022-07-18 06:59:51 --> Security Class Initialized
DEBUG - 2022-07-18 06:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 06:59:51 --> Input Class Initialized
INFO - 2022-07-18 06:59:51 --> Language Class Initialized
INFO - 2022-07-18 06:59:51 --> Loader Class Initialized
INFO - 2022-07-18 06:59:51 --> Helper loaded: url_helper
INFO - 2022-07-18 06:59:51 --> Helper loaded: file_helper
INFO - 2022-07-18 06:59:51 --> Database Driver Class Initialized
INFO - 2022-07-18 06:59:51 --> Email Class Initialized
DEBUG - 2022-07-18 06:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 06:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 06:59:51 --> Controller Class Initialized
INFO - 2022-07-18 06:59:51 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 06:59:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 06:59:51 --> Severity: Notice --> Undefined variable: tk C:\wamp64\www\qr\application\controllers\Tokenctrl.php 115
ERROR - 2022-07-18 06:59:51 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::insesrt() C:\wamp64\www\qr\application\models\Tokenmodel.php 31
INFO - 2022-07-18 07:03:05 --> Config Class Initialized
INFO - 2022-07-18 07:03:05 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:03:05 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:03:05 --> Utf8 Class Initialized
INFO - 2022-07-18 07:03:05 --> URI Class Initialized
INFO - 2022-07-18 07:03:05 --> Router Class Initialized
INFO - 2022-07-18 07:03:05 --> Output Class Initialized
INFO - 2022-07-18 07:03:05 --> Security Class Initialized
DEBUG - 2022-07-18 07:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:03:05 --> Input Class Initialized
INFO - 2022-07-18 07:03:05 --> Language Class Initialized
INFO - 2022-07-18 07:03:05 --> Loader Class Initialized
INFO - 2022-07-18 07:03:05 --> Helper loaded: url_helper
INFO - 2022-07-18 07:03:05 --> Helper loaded: file_helper
INFO - 2022-07-18 07:03:05 --> Database Driver Class Initialized
INFO - 2022-07-18 07:03:05 --> Email Class Initialized
DEBUG - 2022-07-18 07:03:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:03:05 --> Controller Class Initialized
INFO - 2022-07-18 07:03:05 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:03:05 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:03:05 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-18 07:03:05 --> Final output sent to browser
DEBUG - 2022-07-18 07:03:05 --> Total execution time: 0.0432
INFO - 2022-07-18 07:03:07 --> Config Class Initialized
INFO - 2022-07-18 07:03:07 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:03:07 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:03:07 --> Utf8 Class Initialized
INFO - 2022-07-18 07:03:07 --> URI Class Initialized
INFO - 2022-07-18 07:03:07 --> Router Class Initialized
INFO - 2022-07-18 07:03:07 --> Output Class Initialized
INFO - 2022-07-18 07:03:07 --> Security Class Initialized
DEBUG - 2022-07-18 07:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:03:07 --> Input Class Initialized
INFO - 2022-07-18 07:03:07 --> Language Class Initialized
INFO - 2022-07-18 07:03:07 --> Loader Class Initialized
INFO - 2022-07-18 07:03:07 --> Helper loaded: url_helper
INFO - 2022-07-18 07:03:07 --> Helper loaded: file_helper
INFO - 2022-07-18 07:03:07 --> Database Driver Class Initialized
INFO - 2022-07-18 07:03:07 --> Email Class Initialized
DEBUG - 2022-07-18 07:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:03:07 --> Controller Class Initialized
INFO - 2022-07-18 07:03:07 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:03:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 07:03:07 --> Severity: Notice --> Undefined variable: tk C:\wamp64\www\qr\application\controllers\Tokenctrl.php 115
ERROR - 2022-07-18 07:03:07 --> Query error: Table 'tokensys.tokendetais' doesn't exist - Invalid query: UPDATE `tokendetais` SET `td_request` = 1
WHERE `td_visited_date` = '2022-07-18'
AND `td_tk` IS NULL
INFO - 2022-07-18 07:03:07 --> Language file loaded: language/english/db_lang.php
INFO - 2022-07-18 07:05:19 --> Config Class Initialized
INFO - 2022-07-18 07:05:19 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:05:19 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:05:19 --> Utf8 Class Initialized
INFO - 2022-07-18 07:05:19 --> URI Class Initialized
INFO - 2022-07-18 07:05:19 --> Router Class Initialized
INFO - 2022-07-18 07:05:19 --> Output Class Initialized
INFO - 2022-07-18 07:05:19 --> Security Class Initialized
DEBUG - 2022-07-18 07:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:05:19 --> Input Class Initialized
INFO - 2022-07-18 07:05:19 --> Language Class Initialized
INFO - 2022-07-18 07:05:19 --> Loader Class Initialized
INFO - 2022-07-18 07:05:19 --> Helper loaded: url_helper
INFO - 2022-07-18 07:05:19 --> Helper loaded: file_helper
INFO - 2022-07-18 07:05:19 --> Database Driver Class Initialized
INFO - 2022-07-18 07:05:19 --> Email Class Initialized
DEBUG - 2022-07-18 07:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:05:19 --> Controller Class Initialized
INFO - 2022-07-18 07:05:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:05:19 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:05:19 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-18 07:05:19 --> Final output sent to browser
DEBUG - 2022-07-18 07:05:19 --> Total execution time: 0.0312
INFO - 2022-07-18 07:05:20 --> Config Class Initialized
INFO - 2022-07-18 07:05:20 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:05:20 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:05:20 --> Utf8 Class Initialized
INFO - 2022-07-18 07:05:20 --> URI Class Initialized
INFO - 2022-07-18 07:05:20 --> Router Class Initialized
INFO - 2022-07-18 07:05:20 --> Output Class Initialized
INFO - 2022-07-18 07:05:20 --> Security Class Initialized
DEBUG - 2022-07-18 07:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:05:20 --> Input Class Initialized
INFO - 2022-07-18 07:05:20 --> Language Class Initialized
INFO - 2022-07-18 07:05:20 --> Loader Class Initialized
INFO - 2022-07-18 07:05:20 --> Helper loaded: url_helper
INFO - 2022-07-18 07:05:20 --> Helper loaded: file_helper
INFO - 2022-07-18 07:05:20 --> Database Driver Class Initialized
INFO - 2022-07-18 07:05:20 --> Email Class Initialized
DEBUG - 2022-07-18 07:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:05:20 --> Controller Class Initialized
INFO - 2022-07-18 07:05:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:05:20 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:05:20 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-18 07:05:20 --> Final output sent to browser
DEBUG - 2022-07-18 07:05:20 --> Total execution time: 0.1568
INFO - 2022-07-18 07:05:24 --> Config Class Initialized
INFO - 2022-07-18 07:05:24 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:05:24 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:05:24 --> Utf8 Class Initialized
INFO - 2022-07-18 07:05:24 --> URI Class Initialized
INFO - 2022-07-18 07:05:24 --> Router Class Initialized
INFO - 2022-07-18 07:05:24 --> Output Class Initialized
INFO - 2022-07-18 07:05:24 --> Security Class Initialized
DEBUG - 2022-07-18 07:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:05:24 --> Input Class Initialized
INFO - 2022-07-18 07:05:24 --> Language Class Initialized
INFO - 2022-07-18 07:05:24 --> Loader Class Initialized
INFO - 2022-07-18 07:05:24 --> Helper loaded: url_helper
INFO - 2022-07-18 07:05:24 --> Helper loaded: file_helper
INFO - 2022-07-18 07:05:24 --> Database Driver Class Initialized
INFO - 2022-07-18 07:05:24 --> Email Class Initialized
DEBUG - 2022-07-18 07:05:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:05:24 --> Controller Class Initialized
INFO - 2022-07-18 07:05:24 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:05:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 07:05:24 --> Severity: Notice --> Undefined variable: tk C:\wamp64\www\qr\application\controllers\Tokenctrl.php 115
ERROR - 2022-07-18 07:05:24 --> Query error: Table 'tokensys.tokendetais' doesn't exist - Invalid query: UPDATE `tokendetais` SET `td_request` = 1
WHERE `td_visited_date` = '2022-07-18'
AND `td_tk` IS NULL
INFO - 2022-07-18 07:05:24 --> Language file loaded: language/english/db_lang.php
INFO - 2022-07-18 07:05:58 --> Config Class Initialized
INFO - 2022-07-18 07:05:58 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:05:58 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:05:58 --> Utf8 Class Initialized
INFO - 2022-07-18 07:05:58 --> URI Class Initialized
INFO - 2022-07-18 07:05:58 --> Router Class Initialized
INFO - 2022-07-18 07:05:58 --> Output Class Initialized
INFO - 2022-07-18 07:05:58 --> Security Class Initialized
DEBUG - 2022-07-18 07:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:05:58 --> Input Class Initialized
INFO - 2022-07-18 07:05:58 --> Language Class Initialized
INFO - 2022-07-18 07:05:58 --> Loader Class Initialized
INFO - 2022-07-18 07:05:58 --> Helper loaded: url_helper
INFO - 2022-07-18 07:05:58 --> Helper loaded: file_helper
INFO - 2022-07-18 07:05:58 --> Database Driver Class Initialized
INFO - 2022-07-18 07:05:58 --> Email Class Initialized
DEBUG - 2022-07-18 07:05:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:05:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:05:58 --> Controller Class Initialized
INFO - 2022-07-18 07:05:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:05:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:05:58 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-18 07:05:58 --> Final output sent to browser
DEBUG - 2022-07-18 07:05:58 --> Total execution time: 0.0594
INFO - 2022-07-18 07:06:00 --> Config Class Initialized
INFO - 2022-07-18 07:06:00 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:06:00 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:06:00 --> Utf8 Class Initialized
INFO - 2022-07-18 07:06:00 --> URI Class Initialized
INFO - 2022-07-18 07:06:00 --> Router Class Initialized
INFO - 2022-07-18 07:06:00 --> Output Class Initialized
INFO - 2022-07-18 07:06:00 --> Security Class Initialized
DEBUG - 2022-07-18 07:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:06:00 --> Input Class Initialized
INFO - 2022-07-18 07:06:00 --> Language Class Initialized
INFO - 2022-07-18 07:06:00 --> Loader Class Initialized
INFO - 2022-07-18 07:06:00 --> Helper loaded: url_helper
INFO - 2022-07-18 07:06:00 --> Helper loaded: file_helper
INFO - 2022-07-18 07:06:00 --> Database Driver Class Initialized
INFO - 2022-07-18 07:06:00 --> Email Class Initialized
DEBUG - 2022-07-18 07:06:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:06:00 --> Controller Class Initialized
INFO - 2022-07-18 07:06:00 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:06:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 07:06:00 --> Query error: Table 'tokensys.tokendetais' doesn't exist - Invalid query: UPDATE `tokendetais` SET `td_request` = 1
WHERE `td_visited_date` = '2022-07-18'
AND `td_tk` = ' 5'
INFO - 2022-07-18 07:06:00 --> Language file loaded: language/english/db_lang.php
INFO - 2022-07-18 07:06:32 --> Config Class Initialized
INFO - 2022-07-18 07:06:32 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:06:32 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:06:32 --> Utf8 Class Initialized
INFO - 2022-07-18 07:06:32 --> URI Class Initialized
INFO - 2022-07-18 07:06:32 --> Router Class Initialized
INFO - 2022-07-18 07:06:32 --> Output Class Initialized
INFO - 2022-07-18 07:06:32 --> Security Class Initialized
DEBUG - 2022-07-18 07:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:06:32 --> Input Class Initialized
INFO - 2022-07-18 07:06:32 --> Language Class Initialized
INFO - 2022-07-18 07:06:33 --> Loader Class Initialized
INFO - 2022-07-18 07:06:33 --> Helper loaded: url_helper
INFO - 2022-07-18 07:06:33 --> Helper loaded: file_helper
INFO - 2022-07-18 07:06:33 --> Database Driver Class Initialized
INFO - 2022-07-18 07:06:33 --> Email Class Initialized
DEBUG - 2022-07-18 07:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:06:33 --> Controller Class Initialized
INFO - 2022-07-18 07:06:33 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:06:33 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:06:33 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-18 07:06:33 --> Final output sent to browser
DEBUG - 2022-07-18 07:06:33 --> Total execution time: 0.1946
INFO - 2022-07-18 07:06:36 --> Config Class Initialized
INFO - 2022-07-18 07:06:36 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:06:36 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:06:36 --> Utf8 Class Initialized
INFO - 2022-07-18 07:06:36 --> URI Class Initialized
INFO - 2022-07-18 07:06:36 --> Router Class Initialized
INFO - 2022-07-18 07:06:36 --> Output Class Initialized
INFO - 2022-07-18 07:06:36 --> Security Class Initialized
DEBUG - 2022-07-18 07:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:06:36 --> Input Class Initialized
INFO - 2022-07-18 07:06:36 --> Language Class Initialized
INFO - 2022-07-18 07:06:36 --> Loader Class Initialized
INFO - 2022-07-18 07:06:36 --> Helper loaded: url_helper
INFO - 2022-07-18 07:06:36 --> Helper loaded: file_helper
INFO - 2022-07-18 07:06:36 --> Database Driver Class Initialized
INFO - 2022-07-18 07:06:36 --> Email Class Initialized
DEBUG - 2022-07-18 07:06:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:06:36 --> Controller Class Initialized
INFO - 2022-07-18 07:06:36 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:06:36 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:06:36 --> Final output sent to browser
DEBUG - 2022-07-18 07:06:36 --> Total execution time: 0.0278
INFO - 2022-07-18 07:06:53 --> Config Class Initialized
INFO - 2022-07-18 07:06:53 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:06:53 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:06:53 --> Utf8 Class Initialized
INFO - 2022-07-18 07:06:53 --> URI Class Initialized
INFO - 2022-07-18 07:06:53 --> Router Class Initialized
INFO - 2022-07-18 07:06:53 --> Output Class Initialized
INFO - 2022-07-18 07:06:53 --> Security Class Initialized
DEBUG - 2022-07-18 07:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:06:53 --> Input Class Initialized
INFO - 2022-07-18 07:06:53 --> Language Class Initialized
INFO - 2022-07-18 07:06:53 --> Loader Class Initialized
INFO - 2022-07-18 07:06:53 --> Helper loaded: url_helper
INFO - 2022-07-18 07:06:53 --> Helper loaded: file_helper
INFO - 2022-07-18 07:06:53 --> Database Driver Class Initialized
INFO - 2022-07-18 07:06:53 --> Email Class Initialized
DEBUG - 2022-07-18 07:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:06:53 --> Controller Class Initialized
INFO - 2022-07-18 07:06:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:06:53 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:06:53 --> Final output sent to browser
DEBUG - 2022-07-18 07:06:53 --> Total execution time: 0.0431
INFO - 2022-07-18 07:06:56 --> Config Class Initialized
INFO - 2022-07-18 07:06:56 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:06:56 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:06:56 --> Utf8 Class Initialized
INFO - 2022-07-18 07:06:56 --> URI Class Initialized
INFO - 2022-07-18 07:06:56 --> Router Class Initialized
INFO - 2022-07-18 07:06:56 --> Output Class Initialized
INFO - 2022-07-18 07:06:56 --> Security Class Initialized
DEBUG - 2022-07-18 07:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:06:56 --> Input Class Initialized
INFO - 2022-07-18 07:06:56 --> Language Class Initialized
INFO - 2022-07-18 07:06:56 --> Loader Class Initialized
INFO - 2022-07-18 07:06:56 --> Helper loaded: url_helper
INFO - 2022-07-18 07:06:56 --> Helper loaded: file_helper
INFO - 2022-07-18 07:06:56 --> Database Driver Class Initialized
INFO - 2022-07-18 07:06:56 --> Email Class Initialized
DEBUG - 2022-07-18 07:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:06:56 --> Controller Class Initialized
INFO - 2022-07-18 07:06:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:06:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 12:36:56 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 12:36:56 --> Final output sent to browser
DEBUG - 2022-07-18 12:36:56 --> Total execution time: 0.0994
INFO - 2022-07-18 07:07:05 --> Config Class Initialized
INFO - 2022-07-18 07:07:05 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:07:05 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:07:05 --> Utf8 Class Initialized
INFO - 2022-07-18 07:07:05 --> URI Class Initialized
INFO - 2022-07-18 07:07:05 --> Router Class Initialized
INFO - 2022-07-18 07:07:05 --> Output Class Initialized
INFO - 2022-07-18 07:07:05 --> Security Class Initialized
DEBUG - 2022-07-18 07:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:07:05 --> Input Class Initialized
INFO - 2022-07-18 07:07:05 --> Language Class Initialized
INFO - 2022-07-18 07:07:05 --> Loader Class Initialized
INFO - 2022-07-18 07:07:05 --> Helper loaded: url_helper
INFO - 2022-07-18 07:07:05 --> Helper loaded: file_helper
INFO - 2022-07-18 07:07:05 --> Database Driver Class Initialized
INFO - 2022-07-18 07:07:05 --> Email Class Initialized
DEBUG - 2022-07-18 07:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:07:05 --> Controller Class Initialized
INFO - 2022-07-18 07:07:05 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:07:05 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 12:37:05 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 12:37:05 --> Final output sent to browser
DEBUG - 2022-07-18 12:37:05 --> Total execution time: 0.1650
INFO - 2022-07-18 07:19:00 --> Config Class Initialized
INFO - 2022-07-18 07:19:00 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:19:00 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:19:00 --> Utf8 Class Initialized
INFO - 2022-07-18 07:19:00 --> URI Class Initialized
INFO - 2022-07-18 07:19:00 --> Router Class Initialized
INFO - 2022-07-18 07:19:00 --> Output Class Initialized
INFO - 2022-07-18 07:19:00 --> Security Class Initialized
DEBUG - 2022-07-18 07:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:19:00 --> Input Class Initialized
INFO - 2022-07-18 07:19:00 --> Language Class Initialized
INFO - 2022-07-18 07:19:00 --> Loader Class Initialized
INFO - 2022-07-18 07:19:00 --> Helper loaded: url_helper
INFO - 2022-07-18 07:19:00 --> Helper loaded: file_helper
INFO - 2022-07-18 07:19:00 --> Database Driver Class Initialized
INFO - 2022-07-18 07:19:00 --> Email Class Initialized
DEBUG - 2022-07-18 07:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:19:00 --> Controller Class Initialized
INFO - 2022-07-18 07:19:00 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:19:00 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:19:00 --> Final output sent to browser
DEBUG - 2022-07-18 07:19:00 --> Total execution time: 0.1601
INFO - 2022-07-18 07:19:00 --> Config Class Initialized
INFO - 2022-07-18 07:19:00 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:19:00 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:19:00 --> Utf8 Class Initialized
INFO - 2022-07-18 07:19:00 --> URI Class Initialized
INFO - 2022-07-18 07:19:00 --> Router Class Initialized
INFO - 2022-07-18 07:19:00 --> Output Class Initialized
INFO - 2022-07-18 07:19:00 --> Security Class Initialized
DEBUG - 2022-07-18 07:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:19:00 --> Input Class Initialized
INFO - 2022-07-18 07:19:00 --> Language Class Initialized
INFO - 2022-07-18 07:19:00 --> Loader Class Initialized
INFO - 2022-07-18 07:19:00 --> Helper loaded: url_helper
INFO - 2022-07-18 07:19:00 --> Helper loaded: file_helper
INFO - 2022-07-18 07:19:00 --> Database Driver Class Initialized
INFO - 2022-07-18 07:19:00 --> Email Class Initialized
DEBUG - 2022-07-18 07:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:19:00 --> Controller Class Initialized
INFO - 2022-07-18 07:19:00 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:19:00 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:19:00 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-18 07:19:00 --> Final output sent to browser
DEBUG - 2022-07-18 07:19:00 --> Total execution time: 0.0228
INFO - 2022-07-18 07:19:02 --> Config Class Initialized
INFO - 2022-07-18 07:19:02 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:19:02 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:19:02 --> Utf8 Class Initialized
INFO - 2022-07-18 07:19:02 --> URI Class Initialized
INFO - 2022-07-18 07:19:02 --> Router Class Initialized
INFO - 2022-07-18 07:19:02 --> Output Class Initialized
INFO - 2022-07-18 07:19:02 --> Security Class Initialized
DEBUG - 2022-07-18 07:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:19:02 --> Input Class Initialized
INFO - 2022-07-18 07:19:02 --> Language Class Initialized
INFO - 2022-07-18 07:19:02 --> Loader Class Initialized
INFO - 2022-07-18 07:19:02 --> Helper loaded: url_helper
INFO - 2022-07-18 07:19:02 --> Helper loaded: file_helper
INFO - 2022-07-18 07:19:02 --> Database Driver Class Initialized
INFO - 2022-07-18 07:19:02 --> Email Class Initialized
DEBUG - 2022-07-18 07:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:19:02 --> Controller Class Initialized
INFO - 2022-07-18 07:19:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:19:02 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:19:02 --> Final output sent to browser
DEBUG - 2022-07-18 07:19:02 --> Total execution time: 0.0594
INFO - 2022-07-18 07:19:05 --> Config Class Initialized
INFO - 2022-07-18 07:19:05 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:19:05 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:19:05 --> Utf8 Class Initialized
INFO - 2022-07-18 07:19:05 --> URI Class Initialized
INFO - 2022-07-18 07:19:05 --> Router Class Initialized
INFO - 2022-07-18 07:19:05 --> Output Class Initialized
INFO - 2022-07-18 07:19:05 --> Security Class Initialized
DEBUG - 2022-07-18 07:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:19:06 --> Input Class Initialized
INFO - 2022-07-18 07:19:06 --> Language Class Initialized
INFO - 2022-07-18 07:19:06 --> Loader Class Initialized
INFO - 2022-07-18 07:19:06 --> Helper loaded: url_helper
INFO - 2022-07-18 07:19:06 --> Helper loaded: file_helper
INFO - 2022-07-18 07:19:06 --> Database Driver Class Initialized
INFO - 2022-07-18 07:19:06 --> Email Class Initialized
DEBUG - 2022-07-18 07:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:19:06 --> Controller Class Initialized
INFO - 2022-07-18 07:19:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:19:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 12:49:06 --> Severity: Notice --> Undefined variable: requested_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
ERROR - 2022-07-18 12:49:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
INFO - 2022-07-18 12:49:06 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 12:49:06 --> Final output sent to browser
DEBUG - 2022-07-18 12:49:06 --> Total execution time: 0.0693
INFO - 2022-07-18 07:19:14 --> Config Class Initialized
INFO - 2022-07-18 07:19:14 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:19:14 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:19:14 --> Utf8 Class Initialized
INFO - 2022-07-18 07:19:14 --> URI Class Initialized
INFO - 2022-07-18 07:19:14 --> Router Class Initialized
INFO - 2022-07-18 07:19:14 --> Output Class Initialized
INFO - 2022-07-18 07:19:14 --> Security Class Initialized
DEBUG - 2022-07-18 07:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:19:14 --> Input Class Initialized
INFO - 2022-07-18 07:19:14 --> Language Class Initialized
INFO - 2022-07-18 07:19:14 --> Loader Class Initialized
INFO - 2022-07-18 07:19:14 --> Helper loaded: url_helper
INFO - 2022-07-18 07:19:14 --> Helper loaded: file_helper
INFO - 2022-07-18 07:19:14 --> Database Driver Class Initialized
INFO - 2022-07-18 07:19:14 --> Email Class Initialized
DEBUG - 2022-07-18 07:19:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:19:14 --> Controller Class Initialized
INFO - 2022-07-18 07:19:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:19:14 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 12:49:14 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 12:49:14 --> Final output sent to browser
DEBUG - 2022-07-18 12:49:14 --> Total execution time: 0.0400
INFO - 2022-07-18 07:19:31 --> Config Class Initialized
INFO - 2022-07-18 07:19:31 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:19:31 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:19:31 --> Utf8 Class Initialized
INFO - 2022-07-18 07:19:31 --> URI Class Initialized
INFO - 2022-07-18 07:19:31 --> Router Class Initialized
INFO - 2022-07-18 07:19:31 --> Output Class Initialized
INFO - 2022-07-18 07:19:31 --> Security Class Initialized
DEBUG - 2022-07-18 07:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:19:31 --> Input Class Initialized
INFO - 2022-07-18 07:19:31 --> Language Class Initialized
INFO - 2022-07-18 07:19:31 --> Loader Class Initialized
INFO - 2022-07-18 07:19:31 --> Helper loaded: url_helper
INFO - 2022-07-18 07:19:31 --> Helper loaded: file_helper
INFO - 2022-07-18 07:19:31 --> Database Driver Class Initialized
INFO - 2022-07-18 07:19:31 --> Email Class Initialized
DEBUG - 2022-07-18 07:19:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:19:31 --> Controller Class Initialized
INFO - 2022-07-18 07:19:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:19:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 12:49:31 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 12:49:31 --> Final output sent to browser
DEBUG - 2022-07-18 12:49:31 --> Total execution time: 0.4077
INFO - 2022-07-18 07:19:34 --> Config Class Initialized
INFO - 2022-07-18 07:19:34 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:19:34 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:19:34 --> Utf8 Class Initialized
INFO - 2022-07-18 07:19:34 --> URI Class Initialized
INFO - 2022-07-18 07:19:34 --> Router Class Initialized
INFO - 2022-07-18 07:19:34 --> Output Class Initialized
INFO - 2022-07-18 07:19:34 --> Security Class Initialized
DEBUG - 2022-07-18 07:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:19:34 --> Input Class Initialized
INFO - 2022-07-18 07:19:34 --> Language Class Initialized
INFO - 2022-07-18 07:19:34 --> Loader Class Initialized
INFO - 2022-07-18 07:19:34 --> Helper loaded: url_helper
INFO - 2022-07-18 07:19:34 --> Helper loaded: file_helper
INFO - 2022-07-18 07:19:34 --> Database Driver Class Initialized
INFO - 2022-07-18 07:19:34 --> Email Class Initialized
DEBUG - 2022-07-18 07:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:19:34 --> Controller Class Initialized
INFO - 2022-07-18 07:19:34 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:19:34 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 12:49:34 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 12:49:34 --> Final output sent to browser
DEBUG - 2022-07-18 12:49:34 --> Total execution time: 0.0405
INFO - 2022-07-18 07:19:34 --> Config Class Initialized
INFO - 2022-07-18 07:19:34 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:19:34 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:19:34 --> Utf8 Class Initialized
INFO - 2022-07-18 07:19:34 --> URI Class Initialized
INFO - 2022-07-18 07:19:34 --> Router Class Initialized
INFO - 2022-07-18 07:19:34 --> Output Class Initialized
INFO - 2022-07-18 07:19:34 --> Security Class Initialized
DEBUG - 2022-07-18 07:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:19:34 --> Input Class Initialized
INFO - 2022-07-18 07:19:34 --> Language Class Initialized
INFO - 2022-07-18 07:19:34 --> Loader Class Initialized
INFO - 2022-07-18 07:19:34 --> Helper loaded: url_helper
INFO - 2022-07-18 07:19:34 --> Helper loaded: file_helper
INFO - 2022-07-18 07:19:34 --> Database Driver Class Initialized
INFO - 2022-07-18 07:19:34 --> Email Class Initialized
DEBUG - 2022-07-18 07:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:19:34 --> Controller Class Initialized
INFO - 2022-07-18 07:19:34 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:19:34 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 12:49:35 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 12:49:35 --> Final output sent to browser
DEBUG - 2022-07-18 12:49:35 --> Total execution time: 0.1621
INFO - 2022-07-18 07:19:35 --> Config Class Initialized
INFO - 2022-07-18 07:19:35 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:19:35 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:19:35 --> Utf8 Class Initialized
INFO - 2022-07-18 07:19:35 --> URI Class Initialized
INFO - 2022-07-18 07:19:35 --> Router Class Initialized
INFO - 2022-07-18 07:19:35 --> Output Class Initialized
INFO - 2022-07-18 07:19:35 --> Security Class Initialized
DEBUG - 2022-07-18 07:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:19:35 --> Input Class Initialized
INFO - 2022-07-18 07:19:35 --> Language Class Initialized
INFO - 2022-07-18 07:19:35 --> Loader Class Initialized
INFO - 2022-07-18 07:19:35 --> Helper loaded: url_helper
INFO - 2022-07-18 07:19:35 --> Helper loaded: file_helper
INFO - 2022-07-18 07:19:35 --> Database Driver Class Initialized
INFO - 2022-07-18 07:19:35 --> Email Class Initialized
DEBUG - 2022-07-18 07:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:19:35 --> Controller Class Initialized
INFO - 2022-07-18 07:19:35 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:19:35 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 12:49:35 --> Final output sent to browser
DEBUG - 2022-07-18 12:49:35 --> Total execution time: 0.0469
INFO - 2022-07-18 07:19:38 --> Config Class Initialized
INFO - 2022-07-18 07:19:38 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:19:38 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:19:38 --> Utf8 Class Initialized
INFO - 2022-07-18 07:19:38 --> URI Class Initialized
INFO - 2022-07-18 07:19:38 --> Router Class Initialized
INFO - 2022-07-18 07:19:38 --> Output Class Initialized
INFO - 2022-07-18 07:19:38 --> Security Class Initialized
DEBUG - 2022-07-18 07:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:19:38 --> Input Class Initialized
INFO - 2022-07-18 07:19:38 --> Language Class Initialized
INFO - 2022-07-18 07:19:38 --> Loader Class Initialized
INFO - 2022-07-18 07:19:38 --> Helper loaded: url_helper
INFO - 2022-07-18 07:19:38 --> Helper loaded: file_helper
INFO - 2022-07-18 07:19:38 --> Database Driver Class Initialized
INFO - 2022-07-18 07:19:38 --> Email Class Initialized
DEBUG - 2022-07-18 07:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:19:38 --> Controller Class Initialized
INFO - 2022-07-18 07:19:38 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:19:38 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:19:38 --> Final output sent to browser
DEBUG - 2022-07-18 07:19:38 --> Total execution time: 0.0499
INFO - 2022-07-18 07:19:38 --> Config Class Initialized
INFO - 2022-07-18 07:19:38 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:19:38 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:19:38 --> Utf8 Class Initialized
INFO - 2022-07-18 07:19:38 --> URI Class Initialized
INFO - 2022-07-18 07:19:38 --> Router Class Initialized
INFO - 2022-07-18 07:19:38 --> Output Class Initialized
INFO - 2022-07-18 07:19:38 --> Security Class Initialized
DEBUG - 2022-07-18 07:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:19:38 --> Input Class Initialized
INFO - 2022-07-18 07:19:38 --> Language Class Initialized
INFO - 2022-07-18 07:19:38 --> Loader Class Initialized
INFO - 2022-07-18 07:19:38 --> Helper loaded: url_helper
INFO - 2022-07-18 07:19:38 --> Helper loaded: file_helper
INFO - 2022-07-18 07:19:38 --> Database Driver Class Initialized
INFO - 2022-07-18 07:19:38 --> Email Class Initialized
DEBUG - 2022-07-18 07:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:19:38 --> Controller Class Initialized
INFO - 2022-07-18 07:19:38 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:19:38 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:19:38 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-18 07:19:38 --> Final output sent to browser
DEBUG - 2022-07-18 07:19:38 --> Total execution time: 0.0198
INFO - 2022-07-18 07:19:40 --> Config Class Initialized
INFO - 2022-07-18 07:19:40 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:19:40 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:19:40 --> Utf8 Class Initialized
INFO - 2022-07-18 07:19:40 --> URI Class Initialized
INFO - 2022-07-18 07:19:40 --> Router Class Initialized
INFO - 2022-07-18 07:19:40 --> Output Class Initialized
INFO - 2022-07-18 07:19:40 --> Security Class Initialized
DEBUG - 2022-07-18 07:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:19:40 --> Input Class Initialized
INFO - 2022-07-18 07:19:40 --> Language Class Initialized
INFO - 2022-07-18 07:19:40 --> Loader Class Initialized
INFO - 2022-07-18 07:19:40 --> Helper loaded: url_helper
INFO - 2022-07-18 07:19:40 --> Helper loaded: file_helper
INFO - 2022-07-18 07:19:40 --> Database Driver Class Initialized
INFO - 2022-07-18 07:19:40 --> Email Class Initialized
DEBUG - 2022-07-18 07:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:19:40 --> Controller Class Initialized
INFO - 2022-07-18 07:19:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:19:40 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:19:40 --> Final output sent to browser
DEBUG - 2022-07-18 07:19:40 --> Total execution time: 0.0460
INFO - 2022-07-18 07:19:43 --> Config Class Initialized
INFO - 2022-07-18 07:19:43 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:19:43 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:19:43 --> Utf8 Class Initialized
INFO - 2022-07-18 07:19:43 --> URI Class Initialized
INFO - 2022-07-18 07:19:43 --> Router Class Initialized
INFO - 2022-07-18 07:19:43 --> Output Class Initialized
INFO - 2022-07-18 07:19:43 --> Security Class Initialized
DEBUG - 2022-07-18 07:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:19:43 --> Input Class Initialized
INFO - 2022-07-18 07:19:43 --> Language Class Initialized
INFO - 2022-07-18 07:19:43 --> Loader Class Initialized
INFO - 2022-07-18 07:19:43 --> Helper loaded: url_helper
INFO - 2022-07-18 07:19:43 --> Helper loaded: file_helper
INFO - 2022-07-18 07:19:43 --> Database Driver Class Initialized
INFO - 2022-07-18 07:19:43 --> Email Class Initialized
DEBUG - 2022-07-18 07:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:19:43 --> Controller Class Initialized
INFO - 2022-07-18 07:19:43 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:19:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 12:49:43 --> Severity: Notice --> Undefined variable: requested_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
ERROR - 2022-07-18 12:49:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
INFO - 2022-07-18 12:49:43 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 12:49:43 --> Final output sent to browser
DEBUG - 2022-07-18 12:49:43 --> Total execution time: 0.0838
INFO - 2022-07-18 07:19:46 --> Config Class Initialized
INFO - 2022-07-18 07:19:46 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:19:46 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:19:46 --> Utf8 Class Initialized
INFO - 2022-07-18 07:19:46 --> URI Class Initialized
INFO - 2022-07-18 07:19:46 --> Router Class Initialized
INFO - 2022-07-18 07:19:46 --> Output Class Initialized
INFO - 2022-07-18 07:19:46 --> Security Class Initialized
DEBUG - 2022-07-18 07:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:19:46 --> Input Class Initialized
INFO - 2022-07-18 07:19:46 --> Language Class Initialized
INFO - 2022-07-18 07:19:46 --> Loader Class Initialized
INFO - 2022-07-18 07:19:46 --> Helper loaded: url_helper
INFO - 2022-07-18 07:19:46 --> Helper loaded: file_helper
INFO - 2022-07-18 07:19:46 --> Database Driver Class Initialized
INFO - 2022-07-18 07:19:46 --> Email Class Initialized
DEBUG - 2022-07-18 07:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:19:46 --> Controller Class Initialized
INFO - 2022-07-18 07:19:46 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:19:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 12:49:46 --> Severity: Notice --> Undefined variable: requested_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
ERROR - 2022-07-18 12:49:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
INFO - 2022-07-18 12:49:46 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 12:49:46 --> Final output sent to browser
DEBUG - 2022-07-18 12:49:46 --> Total execution time: 0.2035
INFO - 2022-07-18 07:19:47 --> Config Class Initialized
INFO - 2022-07-18 07:19:47 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:19:47 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:19:47 --> Utf8 Class Initialized
INFO - 2022-07-18 07:19:47 --> URI Class Initialized
INFO - 2022-07-18 07:19:47 --> Router Class Initialized
INFO - 2022-07-18 07:19:47 --> Output Class Initialized
INFO - 2022-07-18 07:19:47 --> Security Class Initialized
DEBUG - 2022-07-18 07:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:19:47 --> Input Class Initialized
INFO - 2022-07-18 07:19:47 --> Language Class Initialized
INFO - 2022-07-18 07:19:47 --> Loader Class Initialized
INFO - 2022-07-18 07:19:47 --> Helper loaded: url_helper
INFO - 2022-07-18 07:19:47 --> Helper loaded: file_helper
INFO - 2022-07-18 07:19:47 --> Database Driver Class Initialized
INFO - 2022-07-18 07:19:47 --> Email Class Initialized
DEBUG - 2022-07-18 07:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:19:47 --> Controller Class Initialized
INFO - 2022-07-18 07:19:47 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:19:47 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 12:49:47 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 12:49:47 --> Final output sent to browser
DEBUG - 2022-07-18 12:49:47 --> Total execution time: 0.0306
INFO - 2022-07-18 07:19:53 --> Config Class Initialized
INFO - 2022-07-18 07:19:53 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:19:53 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:19:53 --> Utf8 Class Initialized
INFO - 2022-07-18 07:19:53 --> URI Class Initialized
INFO - 2022-07-18 07:19:53 --> Router Class Initialized
INFO - 2022-07-18 07:19:53 --> Output Class Initialized
INFO - 2022-07-18 07:19:53 --> Security Class Initialized
DEBUG - 2022-07-18 07:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:19:53 --> Input Class Initialized
INFO - 2022-07-18 07:19:53 --> Language Class Initialized
INFO - 2022-07-18 07:19:53 --> Loader Class Initialized
INFO - 2022-07-18 07:19:53 --> Helper loaded: url_helper
INFO - 2022-07-18 07:19:53 --> Helper loaded: file_helper
INFO - 2022-07-18 07:19:53 --> Database Driver Class Initialized
INFO - 2022-07-18 07:19:53 --> Email Class Initialized
DEBUG - 2022-07-18 07:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:19:53 --> Controller Class Initialized
INFO - 2022-07-18 07:19:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:19:53 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 12:49:53 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 12:49:53 --> Final output sent to browser
DEBUG - 2022-07-18 12:49:53 --> Total execution time: 0.1809
INFO - 2022-07-18 07:19:59 --> Config Class Initialized
INFO - 2022-07-18 07:19:59 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:19:59 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:19:59 --> Utf8 Class Initialized
INFO - 2022-07-18 07:19:59 --> URI Class Initialized
INFO - 2022-07-18 07:19:59 --> Router Class Initialized
INFO - 2022-07-18 07:19:59 --> Output Class Initialized
INFO - 2022-07-18 07:19:59 --> Security Class Initialized
DEBUG - 2022-07-18 07:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:19:59 --> Input Class Initialized
INFO - 2022-07-18 07:19:59 --> Language Class Initialized
INFO - 2022-07-18 07:19:59 --> Loader Class Initialized
INFO - 2022-07-18 07:19:59 --> Helper loaded: url_helper
INFO - 2022-07-18 07:19:59 --> Helper loaded: file_helper
INFO - 2022-07-18 07:19:59 --> Database Driver Class Initialized
INFO - 2022-07-18 07:19:59 --> Email Class Initialized
DEBUG - 2022-07-18 07:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:19:59 --> Controller Class Initialized
INFO - 2022-07-18 07:19:59 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:19:59 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 12:49:59 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 12:49:59 --> Final output sent to browser
DEBUG - 2022-07-18 12:49:59 --> Total execution time: 0.0630
INFO - 2022-07-18 07:20:01 --> Config Class Initialized
INFO - 2022-07-18 07:20:01 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:20:01 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:20:01 --> Utf8 Class Initialized
INFO - 2022-07-18 07:20:01 --> URI Class Initialized
INFO - 2022-07-18 07:20:01 --> Router Class Initialized
INFO - 2022-07-18 07:20:01 --> Output Class Initialized
INFO - 2022-07-18 07:20:01 --> Security Class Initialized
DEBUG - 2022-07-18 07:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:20:01 --> Input Class Initialized
INFO - 2022-07-18 07:20:01 --> Language Class Initialized
INFO - 2022-07-18 07:20:01 --> Loader Class Initialized
INFO - 2022-07-18 07:20:01 --> Helper loaded: url_helper
INFO - 2022-07-18 07:20:01 --> Helper loaded: file_helper
INFO - 2022-07-18 07:20:01 --> Database Driver Class Initialized
INFO - 2022-07-18 07:20:01 --> Email Class Initialized
DEBUG - 2022-07-18 07:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:20:01 --> Controller Class Initialized
INFO - 2022-07-18 07:20:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:20:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 12:50:01 --> Final output sent to browser
DEBUG - 2022-07-18 12:50:01 --> Total execution time: 0.1830
INFO - 2022-07-18 07:20:04 --> Config Class Initialized
INFO - 2022-07-18 07:20:04 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:20:04 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:20:04 --> Utf8 Class Initialized
INFO - 2022-07-18 07:20:04 --> URI Class Initialized
INFO - 2022-07-18 07:20:04 --> Router Class Initialized
INFO - 2022-07-18 07:20:04 --> Output Class Initialized
INFO - 2022-07-18 07:20:04 --> Security Class Initialized
DEBUG - 2022-07-18 07:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:20:04 --> Input Class Initialized
INFO - 2022-07-18 07:20:04 --> Language Class Initialized
INFO - 2022-07-18 07:20:04 --> Loader Class Initialized
INFO - 2022-07-18 07:20:04 --> Helper loaded: url_helper
INFO - 2022-07-18 07:20:04 --> Helper loaded: file_helper
INFO - 2022-07-18 07:20:04 --> Database Driver Class Initialized
INFO - 2022-07-18 07:20:04 --> Email Class Initialized
DEBUG - 2022-07-18 07:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:20:04 --> Controller Class Initialized
INFO - 2022-07-18 07:20:04 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:20:04 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:20:04 --> Final output sent to browser
DEBUG - 2022-07-18 07:20:04 --> Total execution time: 0.0454
INFO - 2022-07-18 07:20:04 --> Config Class Initialized
INFO - 2022-07-18 07:20:04 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:20:04 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:20:04 --> Utf8 Class Initialized
INFO - 2022-07-18 07:20:04 --> URI Class Initialized
INFO - 2022-07-18 07:20:04 --> Router Class Initialized
INFO - 2022-07-18 07:20:04 --> Output Class Initialized
INFO - 2022-07-18 07:20:04 --> Security Class Initialized
DEBUG - 2022-07-18 07:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:20:04 --> Input Class Initialized
INFO - 2022-07-18 07:20:04 --> Language Class Initialized
INFO - 2022-07-18 07:20:04 --> Loader Class Initialized
INFO - 2022-07-18 07:20:04 --> Helper loaded: url_helper
INFO - 2022-07-18 07:20:04 --> Helper loaded: file_helper
INFO - 2022-07-18 07:20:04 --> Database Driver Class Initialized
INFO - 2022-07-18 07:20:04 --> Email Class Initialized
DEBUG - 2022-07-18 07:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:20:04 --> Controller Class Initialized
INFO - 2022-07-18 07:20:04 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:20:04 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:20:04 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-18 07:20:04 --> Final output sent to browser
DEBUG - 2022-07-18 07:20:04 --> Total execution time: 0.0415
INFO - 2022-07-18 07:20:06 --> Config Class Initialized
INFO - 2022-07-18 07:20:06 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:20:06 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:20:06 --> Utf8 Class Initialized
INFO - 2022-07-18 07:20:06 --> URI Class Initialized
INFO - 2022-07-18 07:20:06 --> Router Class Initialized
INFO - 2022-07-18 07:20:06 --> Output Class Initialized
INFO - 2022-07-18 07:20:06 --> Security Class Initialized
DEBUG - 2022-07-18 07:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:20:06 --> Input Class Initialized
INFO - 2022-07-18 07:20:06 --> Language Class Initialized
INFO - 2022-07-18 07:20:06 --> Loader Class Initialized
INFO - 2022-07-18 07:20:06 --> Helper loaded: url_helper
INFO - 2022-07-18 07:20:06 --> Helper loaded: file_helper
INFO - 2022-07-18 07:20:06 --> Database Driver Class Initialized
INFO - 2022-07-18 07:20:06 --> Email Class Initialized
DEBUG - 2022-07-18 07:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:20:06 --> Controller Class Initialized
INFO - 2022-07-18 07:20:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:20:06 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:20:06 --> Final output sent to browser
DEBUG - 2022-07-18 07:20:06 --> Total execution time: 0.0597
INFO - 2022-07-18 07:20:09 --> Config Class Initialized
INFO - 2022-07-18 07:20:09 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:20:09 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:20:09 --> Utf8 Class Initialized
INFO - 2022-07-18 07:20:09 --> URI Class Initialized
INFO - 2022-07-18 07:20:09 --> Router Class Initialized
INFO - 2022-07-18 07:20:09 --> Output Class Initialized
INFO - 2022-07-18 07:20:09 --> Security Class Initialized
DEBUG - 2022-07-18 07:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:20:09 --> Input Class Initialized
INFO - 2022-07-18 07:20:09 --> Language Class Initialized
INFO - 2022-07-18 07:20:09 --> Loader Class Initialized
INFO - 2022-07-18 07:20:09 --> Helper loaded: url_helper
INFO - 2022-07-18 07:20:09 --> Helper loaded: file_helper
INFO - 2022-07-18 07:20:09 --> Database Driver Class Initialized
INFO - 2022-07-18 07:20:09 --> Email Class Initialized
DEBUG - 2022-07-18 07:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:20:09 --> Controller Class Initialized
INFO - 2022-07-18 07:20:09 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:20:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 12:50:09 --> Severity: Notice --> Undefined variable: requested_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
ERROR - 2022-07-18 12:50:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
INFO - 2022-07-18 12:50:09 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 12:50:09 --> Final output sent to browser
DEBUG - 2022-07-18 12:50:09 --> Total execution time: 0.0677
INFO - 2022-07-18 07:20:11 --> Config Class Initialized
INFO - 2022-07-18 07:20:11 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:20:11 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:20:11 --> Utf8 Class Initialized
INFO - 2022-07-18 07:20:11 --> URI Class Initialized
INFO - 2022-07-18 07:20:11 --> Router Class Initialized
INFO - 2022-07-18 07:20:11 --> Output Class Initialized
INFO - 2022-07-18 07:20:11 --> Security Class Initialized
DEBUG - 2022-07-18 07:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:20:11 --> Input Class Initialized
INFO - 2022-07-18 07:20:11 --> Language Class Initialized
INFO - 2022-07-18 07:20:11 --> Loader Class Initialized
INFO - 2022-07-18 07:20:11 --> Helper loaded: url_helper
INFO - 2022-07-18 07:20:11 --> Helper loaded: file_helper
INFO - 2022-07-18 07:20:11 --> Database Driver Class Initialized
INFO - 2022-07-18 07:20:11 --> Email Class Initialized
DEBUG - 2022-07-18 07:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:20:11 --> Controller Class Initialized
INFO - 2022-07-18 07:20:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:20:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 12:50:11 --> Severity: Notice --> Undefined variable: requested_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
ERROR - 2022-07-18 12:50:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
INFO - 2022-07-18 12:50:11 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 12:50:11 --> Final output sent to browser
DEBUG - 2022-07-18 12:50:11 --> Total execution time: 0.0279
INFO - 2022-07-18 07:20:18 --> Config Class Initialized
INFO - 2022-07-18 07:20:18 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:20:18 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:20:18 --> Utf8 Class Initialized
INFO - 2022-07-18 07:20:18 --> URI Class Initialized
INFO - 2022-07-18 07:20:18 --> Router Class Initialized
INFO - 2022-07-18 07:20:18 --> Output Class Initialized
INFO - 2022-07-18 07:20:18 --> Security Class Initialized
DEBUG - 2022-07-18 07:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:20:18 --> Input Class Initialized
INFO - 2022-07-18 07:20:18 --> Language Class Initialized
INFO - 2022-07-18 07:20:18 --> Loader Class Initialized
INFO - 2022-07-18 07:20:18 --> Helper loaded: url_helper
INFO - 2022-07-18 07:20:18 --> Helper loaded: file_helper
INFO - 2022-07-18 07:20:18 --> Database Driver Class Initialized
INFO - 2022-07-18 07:20:18 --> Email Class Initialized
DEBUG - 2022-07-18 07:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:20:18 --> Controller Class Initialized
INFO - 2022-07-18 07:20:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:20:18 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 12:50:18 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 12:50:18 --> Final output sent to browser
DEBUG - 2022-07-18 12:50:18 --> Total execution time: 0.0337
INFO - 2022-07-18 07:22:30 --> Config Class Initialized
INFO - 2022-07-18 07:22:30 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:22:30 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:22:30 --> Utf8 Class Initialized
INFO - 2022-07-18 07:22:30 --> URI Class Initialized
INFO - 2022-07-18 07:22:30 --> Router Class Initialized
INFO - 2022-07-18 07:22:30 --> Output Class Initialized
INFO - 2022-07-18 07:22:30 --> Security Class Initialized
DEBUG - 2022-07-18 07:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:22:30 --> Input Class Initialized
INFO - 2022-07-18 07:22:30 --> Language Class Initialized
INFO - 2022-07-18 07:22:30 --> Loader Class Initialized
INFO - 2022-07-18 07:22:30 --> Helper loaded: url_helper
INFO - 2022-07-18 07:22:30 --> Helper loaded: file_helper
INFO - 2022-07-18 07:22:30 --> Database Driver Class Initialized
INFO - 2022-07-18 07:22:30 --> Email Class Initialized
DEBUG - 2022-07-18 07:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:22:30 --> Controller Class Initialized
INFO - 2022-07-18 07:22:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:22:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:22:30 --> Final output sent to browser
DEBUG - 2022-07-18 07:22:30 --> Total execution time: 0.1770
INFO - 2022-07-18 07:22:30 --> Config Class Initialized
INFO - 2022-07-18 07:22:30 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:22:30 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:22:30 --> Utf8 Class Initialized
INFO - 2022-07-18 07:22:30 --> URI Class Initialized
INFO - 2022-07-18 07:22:30 --> Router Class Initialized
INFO - 2022-07-18 07:22:30 --> Output Class Initialized
INFO - 2022-07-18 07:22:30 --> Security Class Initialized
DEBUG - 2022-07-18 07:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:22:30 --> Input Class Initialized
INFO - 2022-07-18 07:22:30 --> Language Class Initialized
INFO - 2022-07-18 07:22:30 --> Loader Class Initialized
INFO - 2022-07-18 07:22:30 --> Helper loaded: url_helper
INFO - 2022-07-18 07:22:30 --> Helper loaded: file_helper
INFO - 2022-07-18 07:22:30 --> Database Driver Class Initialized
INFO - 2022-07-18 07:22:30 --> Email Class Initialized
DEBUG - 2022-07-18 07:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:22:30 --> Controller Class Initialized
INFO - 2022-07-18 07:22:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:22:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:22:30 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-18 07:22:30 --> Final output sent to browser
DEBUG - 2022-07-18 07:22:30 --> Total execution time: 0.0228
INFO - 2022-07-18 07:22:33 --> Config Class Initialized
INFO - 2022-07-18 07:22:33 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:22:33 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:22:33 --> Utf8 Class Initialized
INFO - 2022-07-18 07:22:33 --> URI Class Initialized
INFO - 2022-07-18 07:22:33 --> Router Class Initialized
INFO - 2022-07-18 07:22:33 --> Output Class Initialized
INFO - 2022-07-18 07:22:33 --> Security Class Initialized
DEBUG - 2022-07-18 07:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:22:33 --> Input Class Initialized
INFO - 2022-07-18 07:22:33 --> Language Class Initialized
INFO - 2022-07-18 07:22:33 --> Loader Class Initialized
INFO - 2022-07-18 07:22:33 --> Helper loaded: url_helper
INFO - 2022-07-18 07:22:33 --> Helper loaded: file_helper
INFO - 2022-07-18 07:22:33 --> Database Driver Class Initialized
INFO - 2022-07-18 07:22:33 --> Email Class Initialized
DEBUG - 2022-07-18 07:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:22:33 --> Controller Class Initialized
INFO - 2022-07-18 07:22:33 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:22:33 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:22:33 --> Final output sent to browser
DEBUG - 2022-07-18 07:22:33 --> Total execution time: 0.1817
INFO - 2022-07-18 07:22:45 --> Config Class Initialized
INFO - 2022-07-18 07:22:45 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:22:45 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:22:45 --> Utf8 Class Initialized
INFO - 2022-07-18 07:22:45 --> URI Class Initialized
INFO - 2022-07-18 07:22:45 --> Router Class Initialized
INFO - 2022-07-18 07:22:45 --> Output Class Initialized
INFO - 2022-07-18 07:22:45 --> Security Class Initialized
DEBUG - 2022-07-18 07:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:22:45 --> Input Class Initialized
INFO - 2022-07-18 07:22:45 --> Language Class Initialized
INFO - 2022-07-18 07:22:45 --> Loader Class Initialized
INFO - 2022-07-18 07:22:45 --> Helper loaded: url_helper
INFO - 2022-07-18 07:22:45 --> Helper loaded: file_helper
INFO - 2022-07-18 07:22:45 --> Database Driver Class Initialized
INFO - 2022-07-18 07:22:45 --> Email Class Initialized
DEBUG - 2022-07-18 07:22:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:22:45 --> Controller Class Initialized
INFO - 2022-07-18 07:22:45 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:22:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 12:52:45 --> Severity: Notice --> Undefined variable: requested_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
ERROR - 2022-07-18 12:52:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
INFO - 2022-07-18 12:52:45 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 12:52:45 --> Final output sent to browser
DEBUG - 2022-07-18 12:52:45 --> Total execution time: 0.1182
INFO - 2022-07-18 07:22:59 --> Config Class Initialized
INFO - 2022-07-18 07:22:59 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:22:59 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:22:59 --> Utf8 Class Initialized
INFO - 2022-07-18 07:22:59 --> URI Class Initialized
INFO - 2022-07-18 07:22:59 --> Router Class Initialized
INFO - 2022-07-18 07:22:59 --> Output Class Initialized
INFO - 2022-07-18 07:22:59 --> Security Class Initialized
DEBUG - 2022-07-18 07:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:22:59 --> Input Class Initialized
INFO - 2022-07-18 07:22:59 --> Language Class Initialized
INFO - 2022-07-18 07:22:59 --> Loader Class Initialized
INFO - 2022-07-18 07:22:59 --> Helper loaded: url_helper
INFO - 2022-07-18 07:22:59 --> Helper loaded: file_helper
INFO - 2022-07-18 07:22:59 --> Database Driver Class Initialized
INFO - 2022-07-18 07:23:00 --> Email Class Initialized
DEBUG - 2022-07-18 07:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:23:00 --> Controller Class Initialized
INFO - 2022-07-18 07:23:00 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:23:00 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 12:53:00 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 12:53:00 --> Final output sent to browser
DEBUG - 2022-07-18 12:53:00 --> Total execution time: 0.1725
INFO - 2022-07-18 07:23:10 --> Config Class Initialized
INFO - 2022-07-18 07:23:10 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:23:10 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:23:10 --> Utf8 Class Initialized
INFO - 2022-07-18 07:23:10 --> URI Class Initialized
INFO - 2022-07-18 07:23:10 --> Router Class Initialized
INFO - 2022-07-18 07:23:10 --> Output Class Initialized
INFO - 2022-07-18 07:23:10 --> Security Class Initialized
DEBUG - 2022-07-18 07:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:23:10 --> Input Class Initialized
INFO - 2022-07-18 07:23:10 --> Language Class Initialized
INFO - 2022-07-18 07:23:10 --> Loader Class Initialized
INFO - 2022-07-18 07:23:10 --> Helper loaded: url_helper
INFO - 2022-07-18 07:23:10 --> Helper loaded: file_helper
INFO - 2022-07-18 07:23:10 --> Database Driver Class Initialized
INFO - 2022-07-18 07:23:10 --> Email Class Initialized
DEBUG - 2022-07-18 07:23:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:23:10 --> Controller Class Initialized
INFO - 2022-07-18 07:23:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:23:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 12:53:10 --> Severity: Notice --> Undefined variable: requested_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
ERROR - 2022-07-18 12:53:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
INFO - 2022-07-18 12:53:10 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 12:53:10 --> Final output sent to browser
DEBUG - 2022-07-18 12:53:10 --> Total execution time: 0.0810
INFO - 2022-07-18 07:23:26 --> Config Class Initialized
INFO - 2022-07-18 07:23:26 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:23:26 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:23:26 --> Utf8 Class Initialized
INFO - 2022-07-18 07:23:26 --> URI Class Initialized
INFO - 2022-07-18 07:23:26 --> Router Class Initialized
INFO - 2022-07-18 07:23:26 --> Output Class Initialized
INFO - 2022-07-18 07:23:26 --> Security Class Initialized
DEBUG - 2022-07-18 07:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:23:26 --> Input Class Initialized
INFO - 2022-07-18 07:23:26 --> Language Class Initialized
INFO - 2022-07-18 07:23:26 --> Loader Class Initialized
INFO - 2022-07-18 07:23:26 --> Helper loaded: url_helper
INFO - 2022-07-18 07:23:26 --> Helper loaded: file_helper
INFO - 2022-07-18 07:23:26 --> Database Driver Class Initialized
INFO - 2022-07-18 07:23:26 --> Email Class Initialized
DEBUG - 2022-07-18 07:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:23:26 --> Controller Class Initialized
INFO - 2022-07-18 07:23:26 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:23:26 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 12:53:26 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 12:53:26 --> Final output sent to browser
DEBUG - 2022-07-18 12:53:26 --> Total execution time: 0.0781
INFO - 2022-07-18 07:33:11 --> Config Class Initialized
INFO - 2022-07-18 07:33:11 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:33:11 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:33:11 --> Utf8 Class Initialized
INFO - 2022-07-18 07:33:11 --> URI Class Initialized
INFO - 2022-07-18 07:33:11 --> Router Class Initialized
INFO - 2022-07-18 07:33:11 --> Output Class Initialized
INFO - 2022-07-18 07:33:11 --> Security Class Initialized
DEBUG - 2022-07-18 07:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:33:11 --> Input Class Initialized
INFO - 2022-07-18 07:33:11 --> Language Class Initialized
INFO - 2022-07-18 07:33:11 --> Loader Class Initialized
INFO - 2022-07-18 07:33:11 --> Helper loaded: url_helper
INFO - 2022-07-18 07:33:11 --> Helper loaded: file_helper
INFO - 2022-07-18 07:33:11 --> Database Driver Class Initialized
INFO - 2022-07-18 07:33:11 --> Email Class Initialized
DEBUG - 2022-07-18 07:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:33:11 --> Controller Class Initialized
INFO - 2022-07-18 07:33:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:33:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:33:11 --> Final output sent to browser
DEBUG - 2022-07-18 07:33:11 --> Total execution time: 0.0507
INFO - 2022-07-18 07:33:11 --> Config Class Initialized
INFO - 2022-07-18 07:33:11 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:33:11 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:33:11 --> Utf8 Class Initialized
INFO - 2022-07-18 07:33:11 --> URI Class Initialized
INFO - 2022-07-18 07:33:11 --> Router Class Initialized
INFO - 2022-07-18 07:33:11 --> Output Class Initialized
INFO - 2022-07-18 07:33:11 --> Security Class Initialized
DEBUG - 2022-07-18 07:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:33:11 --> Input Class Initialized
INFO - 2022-07-18 07:33:11 --> Language Class Initialized
INFO - 2022-07-18 07:33:11 --> Loader Class Initialized
INFO - 2022-07-18 07:33:11 --> Helper loaded: url_helper
INFO - 2022-07-18 07:33:11 --> Helper loaded: file_helper
INFO - 2022-07-18 07:33:11 --> Database Driver Class Initialized
INFO - 2022-07-18 07:33:11 --> Email Class Initialized
DEBUG - 2022-07-18 07:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:33:11 --> Controller Class Initialized
INFO - 2022-07-18 07:33:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:33:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:33:11 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-18 07:33:11 --> Final output sent to browser
DEBUG - 2022-07-18 07:33:11 --> Total execution time: 0.1139
INFO - 2022-07-18 07:33:17 --> Config Class Initialized
INFO - 2022-07-18 07:33:17 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:33:17 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:33:17 --> Utf8 Class Initialized
INFO - 2022-07-18 07:33:17 --> URI Class Initialized
INFO - 2022-07-18 07:33:17 --> Router Class Initialized
INFO - 2022-07-18 07:33:17 --> Output Class Initialized
INFO - 2022-07-18 07:33:17 --> Security Class Initialized
DEBUG - 2022-07-18 07:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:33:17 --> Input Class Initialized
INFO - 2022-07-18 07:33:17 --> Language Class Initialized
INFO - 2022-07-18 07:33:17 --> Loader Class Initialized
INFO - 2022-07-18 07:33:17 --> Helper loaded: url_helper
INFO - 2022-07-18 07:33:17 --> Helper loaded: file_helper
INFO - 2022-07-18 07:33:17 --> Database Driver Class Initialized
INFO - 2022-07-18 07:33:17 --> Email Class Initialized
DEBUG - 2022-07-18 07:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:33:17 --> Controller Class Initialized
INFO - 2022-07-18 07:33:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:33:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:33:17 --> Final output sent to browser
DEBUG - 2022-07-18 07:33:17 --> Total execution time: 0.0572
INFO - 2022-07-18 07:33:20 --> Config Class Initialized
INFO - 2022-07-18 07:33:20 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:33:20 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:33:20 --> Utf8 Class Initialized
INFO - 2022-07-18 07:33:20 --> URI Class Initialized
INFO - 2022-07-18 07:33:20 --> Router Class Initialized
INFO - 2022-07-18 07:33:20 --> Output Class Initialized
INFO - 2022-07-18 07:33:20 --> Security Class Initialized
DEBUG - 2022-07-18 07:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:33:20 --> Input Class Initialized
INFO - 2022-07-18 07:33:20 --> Language Class Initialized
INFO - 2022-07-18 07:33:20 --> Loader Class Initialized
INFO - 2022-07-18 07:33:20 --> Helper loaded: url_helper
INFO - 2022-07-18 07:33:20 --> Helper loaded: file_helper
INFO - 2022-07-18 07:33:20 --> Database Driver Class Initialized
INFO - 2022-07-18 07:33:20 --> Email Class Initialized
DEBUG - 2022-07-18 07:33:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:33:20 --> Controller Class Initialized
INFO - 2022-07-18 07:33:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:33:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 13:03:20 --> Severity: Notice --> Undefined variable: requested_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
ERROR - 2022-07-18 13:03:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
INFO - 2022-07-18 13:03:20 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 13:03:20 --> Final output sent to browser
DEBUG - 2022-07-18 13:03:20 --> Total execution time: 0.0654
INFO - 2022-07-18 07:33:25 --> Config Class Initialized
INFO - 2022-07-18 07:33:25 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:33:25 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:33:25 --> Utf8 Class Initialized
INFO - 2022-07-18 07:33:25 --> URI Class Initialized
INFO - 2022-07-18 07:33:25 --> Router Class Initialized
INFO - 2022-07-18 07:33:25 --> Output Class Initialized
INFO - 2022-07-18 07:33:25 --> Security Class Initialized
DEBUG - 2022-07-18 07:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:33:25 --> Input Class Initialized
INFO - 2022-07-18 07:33:25 --> Language Class Initialized
INFO - 2022-07-18 07:33:25 --> Loader Class Initialized
INFO - 2022-07-18 07:33:25 --> Helper loaded: url_helper
INFO - 2022-07-18 07:33:25 --> Helper loaded: file_helper
INFO - 2022-07-18 07:33:25 --> Database Driver Class Initialized
INFO - 2022-07-18 07:33:25 --> Email Class Initialized
DEBUG - 2022-07-18 07:33:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:33:25 --> Controller Class Initialized
INFO - 2022-07-18 07:33:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:33:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 13:03:25 --> Severity: Notice --> Undefined variable: requested_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
ERROR - 2022-07-18 13:03:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
INFO - 2022-07-18 13:03:25 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 13:03:25 --> Final output sent to browser
DEBUG - 2022-07-18 13:03:25 --> Total execution time: 0.0589
INFO - 2022-07-18 07:33:33 --> Config Class Initialized
INFO - 2022-07-18 07:33:33 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:33:33 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:33:33 --> Utf8 Class Initialized
INFO - 2022-07-18 07:33:33 --> URI Class Initialized
INFO - 2022-07-18 07:33:33 --> Router Class Initialized
INFO - 2022-07-18 07:33:33 --> Output Class Initialized
INFO - 2022-07-18 07:33:33 --> Security Class Initialized
DEBUG - 2022-07-18 07:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:33:33 --> Input Class Initialized
INFO - 2022-07-18 07:33:33 --> Language Class Initialized
INFO - 2022-07-18 07:33:33 --> Loader Class Initialized
INFO - 2022-07-18 07:33:33 --> Helper loaded: url_helper
INFO - 2022-07-18 07:33:33 --> Helper loaded: file_helper
INFO - 2022-07-18 07:33:33 --> Database Driver Class Initialized
INFO - 2022-07-18 07:33:33 --> Email Class Initialized
DEBUG - 2022-07-18 07:33:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:33:33 --> Controller Class Initialized
INFO - 2022-07-18 07:33:33 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:33:33 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 13:03:33 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 13:03:33 --> Final output sent to browser
DEBUG - 2022-07-18 13:03:33 --> Total execution time: 0.1712
INFO - 2022-07-18 07:34:16 --> Config Class Initialized
INFO - 2022-07-18 07:34:16 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:34:16 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:34:16 --> Utf8 Class Initialized
INFO - 2022-07-18 07:34:16 --> URI Class Initialized
INFO - 2022-07-18 07:34:16 --> Router Class Initialized
INFO - 2022-07-18 07:34:16 --> Output Class Initialized
INFO - 2022-07-18 07:34:16 --> Security Class Initialized
DEBUG - 2022-07-18 07:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:34:16 --> Input Class Initialized
INFO - 2022-07-18 07:34:16 --> Language Class Initialized
INFO - 2022-07-18 07:34:16 --> Loader Class Initialized
INFO - 2022-07-18 07:34:16 --> Helper loaded: url_helper
INFO - 2022-07-18 07:34:16 --> Helper loaded: file_helper
INFO - 2022-07-18 07:34:16 --> Database Driver Class Initialized
INFO - 2022-07-18 07:34:16 --> Email Class Initialized
DEBUG - 2022-07-18 07:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:34:16 --> Controller Class Initialized
INFO - 2022-07-18 07:34:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:34:16 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:34:16 --> Final output sent to browser
DEBUG - 2022-07-18 07:34:16 --> Total execution time: 0.1627
INFO - 2022-07-18 07:34:40 --> Config Class Initialized
INFO - 2022-07-18 07:34:40 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:34:40 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:34:40 --> Utf8 Class Initialized
INFO - 2022-07-18 07:34:40 --> URI Class Initialized
INFO - 2022-07-18 07:34:40 --> Router Class Initialized
INFO - 2022-07-18 07:34:40 --> Output Class Initialized
INFO - 2022-07-18 07:34:40 --> Security Class Initialized
DEBUG - 2022-07-18 07:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:34:40 --> Input Class Initialized
INFO - 2022-07-18 07:34:40 --> Language Class Initialized
INFO - 2022-07-18 07:34:40 --> Loader Class Initialized
INFO - 2022-07-18 07:34:40 --> Helper loaded: url_helper
INFO - 2022-07-18 07:34:40 --> Helper loaded: file_helper
INFO - 2022-07-18 07:34:40 --> Database Driver Class Initialized
INFO - 2022-07-18 07:34:40 --> Email Class Initialized
DEBUG - 2022-07-18 07:34:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:34:40 --> Controller Class Initialized
INFO - 2022-07-18 07:34:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:34:40 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 13:04:40 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 13:04:40 --> Final output sent to browser
DEBUG - 2022-07-18 13:04:40 --> Total execution time: 0.2380
INFO - 2022-07-18 07:35:01 --> Config Class Initialized
INFO - 2022-07-18 07:35:01 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:35:01 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:35:01 --> Utf8 Class Initialized
INFO - 2022-07-18 07:35:01 --> URI Class Initialized
INFO - 2022-07-18 07:35:01 --> Router Class Initialized
INFO - 2022-07-18 07:35:01 --> Output Class Initialized
INFO - 2022-07-18 07:35:01 --> Security Class Initialized
DEBUG - 2022-07-18 07:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:35:01 --> Input Class Initialized
INFO - 2022-07-18 07:35:01 --> Language Class Initialized
INFO - 2022-07-18 07:35:01 --> Loader Class Initialized
INFO - 2022-07-18 07:35:01 --> Helper loaded: url_helper
INFO - 2022-07-18 07:35:01 --> Helper loaded: file_helper
INFO - 2022-07-18 07:35:01 --> Database Driver Class Initialized
INFO - 2022-07-18 07:35:01 --> Email Class Initialized
DEBUG - 2022-07-18 07:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:35:01 --> Controller Class Initialized
INFO - 2022-07-18 07:35:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:35:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:35:01 --> Final output sent to browser
DEBUG - 2022-07-18 07:35:01 --> Total execution time: 0.0194
INFO - 2022-07-18 07:35:01 --> Config Class Initialized
INFO - 2022-07-18 07:35:01 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:35:01 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:35:01 --> Utf8 Class Initialized
INFO - 2022-07-18 07:35:01 --> URI Class Initialized
INFO - 2022-07-18 07:35:01 --> Router Class Initialized
INFO - 2022-07-18 07:35:01 --> Output Class Initialized
INFO - 2022-07-18 07:35:01 --> Security Class Initialized
DEBUG - 2022-07-18 07:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:35:01 --> Input Class Initialized
INFO - 2022-07-18 07:35:01 --> Language Class Initialized
INFO - 2022-07-18 07:35:01 --> Loader Class Initialized
INFO - 2022-07-18 07:35:01 --> Helper loaded: url_helper
INFO - 2022-07-18 07:35:01 --> Helper loaded: file_helper
INFO - 2022-07-18 07:35:01 --> Database Driver Class Initialized
INFO - 2022-07-18 07:35:01 --> Email Class Initialized
DEBUG - 2022-07-18 07:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:35:01 --> Controller Class Initialized
INFO - 2022-07-18 07:35:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:35:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:35:01 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-18 07:35:01 --> Final output sent to browser
DEBUG - 2022-07-18 07:35:01 --> Total execution time: 0.0499
INFO - 2022-07-18 07:35:04 --> Config Class Initialized
INFO - 2022-07-18 07:35:04 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:35:04 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:35:04 --> Utf8 Class Initialized
INFO - 2022-07-18 07:35:04 --> URI Class Initialized
INFO - 2022-07-18 07:35:04 --> Router Class Initialized
INFO - 2022-07-18 07:35:04 --> Output Class Initialized
INFO - 2022-07-18 07:35:04 --> Security Class Initialized
DEBUG - 2022-07-18 07:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:35:04 --> Input Class Initialized
INFO - 2022-07-18 07:35:04 --> Language Class Initialized
INFO - 2022-07-18 07:35:04 --> Loader Class Initialized
INFO - 2022-07-18 07:35:04 --> Helper loaded: url_helper
INFO - 2022-07-18 07:35:04 --> Helper loaded: file_helper
INFO - 2022-07-18 07:35:04 --> Database Driver Class Initialized
INFO - 2022-07-18 07:35:04 --> Email Class Initialized
DEBUG - 2022-07-18 07:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:35:04 --> Controller Class Initialized
INFO - 2022-07-18 07:35:04 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:35:04 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:35:04 --> Final output sent to browser
DEBUG - 2022-07-18 07:35:04 --> Total execution time: 0.0610
INFO - 2022-07-18 07:35:06 --> Config Class Initialized
INFO - 2022-07-18 07:35:06 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:35:06 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:35:06 --> Utf8 Class Initialized
INFO - 2022-07-18 07:35:06 --> URI Class Initialized
INFO - 2022-07-18 07:35:06 --> Router Class Initialized
INFO - 2022-07-18 07:35:06 --> Output Class Initialized
INFO - 2022-07-18 07:35:06 --> Security Class Initialized
DEBUG - 2022-07-18 07:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:35:06 --> Input Class Initialized
INFO - 2022-07-18 07:35:06 --> Language Class Initialized
INFO - 2022-07-18 07:35:06 --> Loader Class Initialized
INFO - 2022-07-18 07:35:06 --> Helper loaded: url_helper
INFO - 2022-07-18 07:35:06 --> Helper loaded: file_helper
INFO - 2022-07-18 07:35:06 --> Database Driver Class Initialized
INFO - 2022-07-18 07:35:06 --> Email Class Initialized
DEBUG - 2022-07-18 07:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:35:06 --> Controller Class Initialized
INFO - 2022-07-18 07:35:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:35:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 13:05:06 --> Severity: Notice --> Undefined variable: requested_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
ERROR - 2022-07-18 13:05:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
INFO - 2022-07-18 13:05:06 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 13:05:06 --> Final output sent to browser
DEBUG - 2022-07-18 13:05:06 --> Total execution time: 0.0664
INFO - 2022-07-18 07:35:10 --> Config Class Initialized
INFO - 2022-07-18 07:35:10 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:35:10 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:35:10 --> Utf8 Class Initialized
INFO - 2022-07-18 07:35:10 --> URI Class Initialized
INFO - 2022-07-18 07:35:10 --> Router Class Initialized
INFO - 2022-07-18 07:35:10 --> Output Class Initialized
INFO - 2022-07-18 07:35:10 --> Security Class Initialized
DEBUG - 2022-07-18 07:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:35:10 --> Input Class Initialized
INFO - 2022-07-18 07:35:10 --> Language Class Initialized
INFO - 2022-07-18 07:35:10 --> Loader Class Initialized
INFO - 2022-07-18 07:35:10 --> Helper loaded: url_helper
INFO - 2022-07-18 07:35:10 --> Helper loaded: file_helper
INFO - 2022-07-18 07:35:10 --> Database Driver Class Initialized
INFO - 2022-07-18 07:35:10 --> Email Class Initialized
DEBUG - 2022-07-18 07:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:35:10 --> Controller Class Initialized
INFO - 2022-07-18 07:35:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:35:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 13:05:10 --> Severity: Notice --> Undefined variable: requested_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
ERROR - 2022-07-18 13:05:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
INFO - 2022-07-18 13:05:10 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 13:05:10 --> Final output sent to browser
DEBUG - 2022-07-18 13:05:10 --> Total execution time: 0.1736
INFO - 2022-07-18 07:35:14 --> Config Class Initialized
INFO - 2022-07-18 07:35:14 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:35:14 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:35:14 --> Utf8 Class Initialized
INFO - 2022-07-18 07:35:14 --> URI Class Initialized
INFO - 2022-07-18 07:35:14 --> Router Class Initialized
INFO - 2022-07-18 07:35:14 --> Output Class Initialized
INFO - 2022-07-18 07:35:14 --> Security Class Initialized
DEBUG - 2022-07-18 07:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:35:14 --> Input Class Initialized
INFO - 2022-07-18 07:35:14 --> Language Class Initialized
INFO - 2022-07-18 07:35:14 --> Loader Class Initialized
INFO - 2022-07-18 07:35:14 --> Helper loaded: url_helper
INFO - 2022-07-18 07:35:14 --> Helper loaded: file_helper
INFO - 2022-07-18 07:35:14 --> Database Driver Class Initialized
INFO - 2022-07-18 07:35:14 --> Email Class Initialized
DEBUG - 2022-07-18 07:35:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:35:14 --> Controller Class Initialized
INFO - 2022-07-18 07:35:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:35:14 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 13:05:14 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 13:05:14 --> Final output sent to browser
DEBUG - 2022-07-18 13:05:14 --> Total execution time: 0.0587
INFO - 2022-07-18 07:35:31 --> Config Class Initialized
INFO - 2022-07-18 07:35:31 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:35:31 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:35:31 --> Utf8 Class Initialized
INFO - 2022-07-18 07:35:31 --> URI Class Initialized
INFO - 2022-07-18 07:35:31 --> Router Class Initialized
INFO - 2022-07-18 07:35:31 --> Output Class Initialized
INFO - 2022-07-18 07:35:31 --> Security Class Initialized
DEBUG - 2022-07-18 07:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:35:31 --> Input Class Initialized
INFO - 2022-07-18 07:35:31 --> Language Class Initialized
INFO - 2022-07-18 07:35:31 --> Loader Class Initialized
INFO - 2022-07-18 07:35:31 --> Helper loaded: url_helper
INFO - 2022-07-18 07:35:31 --> Helper loaded: file_helper
INFO - 2022-07-18 07:35:31 --> Database Driver Class Initialized
INFO - 2022-07-18 07:35:31 --> Email Class Initialized
DEBUG - 2022-07-18 07:35:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:35:31 --> Controller Class Initialized
INFO - 2022-07-18 07:35:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:35:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 13:05:31 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 13:05:31 --> Final output sent to browser
DEBUG - 2022-07-18 13:05:31 --> Total execution time: 0.0602
INFO - 2022-07-18 07:35:35 --> Config Class Initialized
INFO - 2022-07-18 07:35:35 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:35:36 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:35:36 --> Utf8 Class Initialized
INFO - 2022-07-18 07:35:36 --> URI Class Initialized
INFO - 2022-07-18 07:35:36 --> Router Class Initialized
INFO - 2022-07-18 07:35:36 --> Output Class Initialized
INFO - 2022-07-18 07:35:36 --> Security Class Initialized
DEBUG - 2022-07-18 07:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:35:36 --> Input Class Initialized
INFO - 2022-07-18 07:35:36 --> Language Class Initialized
INFO - 2022-07-18 07:35:36 --> Loader Class Initialized
INFO - 2022-07-18 07:35:36 --> Helper loaded: url_helper
INFO - 2022-07-18 07:35:36 --> Helper loaded: file_helper
INFO - 2022-07-18 07:35:36 --> Database Driver Class Initialized
INFO - 2022-07-18 07:35:36 --> Email Class Initialized
DEBUG - 2022-07-18 07:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:35:36 --> Controller Class Initialized
INFO - 2022-07-18 07:35:36 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:35:36 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:35:36 --> Final output sent to browser
DEBUG - 2022-07-18 07:35:36 --> Total execution time: 0.1041
INFO - 2022-07-18 07:35:36 --> Config Class Initialized
INFO - 2022-07-18 07:35:36 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:35:36 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:35:36 --> Utf8 Class Initialized
INFO - 2022-07-18 07:35:36 --> URI Class Initialized
INFO - 2022-07-18 07:35:36 --> Router Class Initialized
INFO - 2022-07-18 07:35:36 --> Output Class Initialized
INFO - 2022-07-18 07:35:36 --> Security Class Initialized
DEBUG - 2022-07-18 07:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:35:36 --> Input Class Initialized
INFO - 2022-07-18 07:35:36 --> Language Class Initialized
INFO - 2022-07-18 07:35:36 --> Loader Class Initialized
INFO - 2022-07-18 07:35:36 --> Helper loaded: url_helper
INFO - 2022-07-18 07:35:36 --> Helper loaded: file_helper
INFO - 2022-07-18 07:35:36 --> Database Driver Class Initialized
INFO - 2022-07-18 07:35:36 --> Email Class Initialized
DEBUG - 2022-07-18 07:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:35:36 --> Controller Class Initialized
INFO - 2022-07-18 07:35:36 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:35:36 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:35:36 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-18 07:35:36 --> Final output sent to browser
DEBUG - 2022-07-18 07:35:36 --> Total execution time: 0.1073
INFO - 2022-07-18 07:35:38 --> Config Class Initialized
INFO - 2022-07-18 07:35:38 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:35:38 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:35:38 --> Utf8 Class Initialized
INFO - 2022-07-18 07:35:38 --> URI Class Initialized
INFO - 2022-07-18 07:35:38 --> Router Class Initialized
INFO - 2022-07-18 07:35:38 --> Output Class Initialized
INFO - 2022-07-18 07:35:38 --> Security Class Initialized
DEBUG - 2022-07-18 07:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:35:38 --> Input Class Initialized
INFO - 2022-07-18 07:35:38 --> Language Class Initialized
INFO - 2022-07-18 07:35:38 --> Loader Class Initialized
INFO - 2022-07-18 07:35:38 --> Helper loaded: url_helper
INFO - 2022-07-18 07:35:38 --> Helper loaded: file_helper
INFO - 2022-07-18 07:35:38 --> Database Driver Class Initialized
INFO - 2022-07-18 07:35:38 --> Email Class Initialized
DEBUG - 2022-07-18 07:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:35:38 --> Controller Class Initialized
INFO - 2022-07-18 07:35:38 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:35:38 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:35:38 --> Final output sent to browser
DEBUG - 2022-07-18 07:35:38 --> Total execution time: 0.0862
INFO - 2022-07-18 07:35:51 --> Config Class Initialized
INFO - 2022-07-18 07:35:51 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:35:51 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:35:51 --> Utf8 Class Initialized
INFO - 2022-07-18 07:35:51 --> URI Class Initialized
INFO - 2022-07-18 07:35:51 --> Router Class Initialized
INFO - 2022-07-18 07:35:51 --> Output Class Initialized
INFO - 2022-07-18 07:35:51 --> Security Class Initialized
DEBUG - 2022-07-18 07:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:35:51 --> Input Class Initialized
INFO - 2022-07-18 07:35:51 --> Language Class Initialized
INFO - 2022-07-18 07:35:51 --> Loader Class Initialized
INFO - 2022-07-18 07:35:51 --> Helper loaded: url_helper
INFO - 2022-07-18 07:35:51 --> Helper loaded: file_helper
INFO - 2022-07-18 07:35:51 --> Database Driver Class Initialized
INFO - 2022-07-18 07:35:52 --> Email Class Initialized
DEBUG - 2022-07-18 07:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:35:52 --> Controller Class Initialized
INFO - 2022-07-18 07:35:52 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:35:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-07-18 07:35:52 --> insertedINSERT INTO `tokendetails` (`td_tk`, `td_cs`, `td_visited_date`) VALUES (6, 0, '2022-07-18')
ERROR - 2022-07-18 07:35:52 --> Severity: Notice --> Undefined variable: time_est C:\wamp64\www\qr\application\controllers\Tokenctrl.php 522
ERROR - 2022-07-18 07:35:52 --> Severity: Notice --> Undefined variable: time_est C:\wamp64\www\qr\application\controllers\Tokenctrl.php 526
INFO - 2022-07-18 07:35:52 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-18 07:35:52 --> Final output sent to browser
DEBUG - 2022-07-18 07:35:52 --> Total execution time: 0.0737
INFO - 2022-07-18 07:36:27 --> Config Class Initialized
INFO - 2022-07-18 07:36:27 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:36:27 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:36:27 --> Utf8 Class Initialized
INFO - 2022-07-18 07:36:27 --> URI Class Initialized
INFO - 2022-07-18 07:36:27 --> Router Class Initialized
INFO - 2022-07-18 07:36:27 --> Output Class Initialized
INFO - 2022-07-18 07:36:27 --> Security Class Initialized
DEBUG - 2022-07-18 07:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:36:27 --> Input Class Initialized
INFO - 2022-07-18 07:36:27 --> Language Class Initialized
INFO - 2022-07-18 07:36:27 --> Loader Class Initialized
INFO - 2022-07-18 07:36:27 --> Helper loaded: url_helper
INFO - 2022-07-18 07:36:27 --> Helper loaded: file_helper
INFO - 2022-07-18 07:36:27 --> Database Driver Class Initialized
INFO - 2022-07-18 07:36:27 --> Email Class Initialized
DEBUG - 2022-07-18 07:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:36:27 --> Controller Class Initialized
INFO - 2022-07-18 07:36:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:36:27 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:36:27 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-18 07:36:27 --> Final output sent to browser
DEBUG - 2022-07-18 07:36:27 --> Total execution time: 0.0268
INFO - 2022-07-18 07:36:29 --> Config Class Initialized
INFO - 2022-07-18 07:36:29 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:36:29 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:36:29 --> Utf8 Class Initialized
INFO - 2022-07-18 07:36:29 --> URI Class Initialized
INFO - 2022-07-18 07:36:29 --> Router Class Initialized
INFO - 2022-07-18 07:36:29 --> Output Class Initialized
INFO - 2022-07-18 07:36:29 --> Security Class Initialized
DEBUG - 2022-07-18 07:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:36:29 --> Input Class Initialized
INFO - 2022-07-18 07:36:29 --> Language Class Initialized
INFO - 2022-07-18 07:36:29 --> Loader Class Initialized
INFO - 2022-07-18 07:36:29 --> Helper loaded: url_helper
INFO - 2022-07-18 07:36:29 --> Helper loaded: file_helper
INFO - 2022-07-18 07:36:29 --> Database Driver Class Initialized
INFO - 2022-07-18 07:36:29 --> Email Class Initialized
DEBUG - 2022-07-18 07:36:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:36:29 --> Controller Class Initialized
INFO - 2022-07-18 07:36:29 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:36:29 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:36:29 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-18 07:36:29 --> Final output sent to browser
DEBUG - 2022-07-18 07:36:29 --> Total execution time: 0.1538
INFO - 2022-07-18 07:36:38 --> Config Class Initialized
INFO - 2022-07-18 07:36:38 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:36:38 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:36:38 --> Utf8 Class Initialized
INFO - 2022-07-18 07:36:38 --> URI Class Initialized
INFO - 2022-07-18 07:36:38 --> Router Class Initialized
INFO - 2022-07-18 07:36:38 --> Output Class Initialized
INFO - 2022-07-18 07:36:38 --> Security Class Initialized
DEBUG - 2022-07-18 07:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:36:38 --> Input Class Initialized
INFO - 2022-07-18 07:36:38 --> Language Class Initialized
INFO - 2022-07-18 07:36:38 --> Loader Class Initialized
INFO - 2022-07-18 07:36:38 --> Helper loaded: url_helper
INFO - 2022-07-18 07:36:38 --> Helper loaded: file_helper
INFO - 2022-07-18 07:36:38 --> Database Driver Class Initialized
INFO - 2022-07-18 07:36:38 --> Email Class Initialized
DEBUG - 2022-07-18 07:36:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:36:38 --> Controller Class Initialized
INFO - 2022-07-18 07:36:38 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:36:38 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:36:38 --> Final output sent to browser
DEBUG - 2022-07-18 07:36:38 --> Total execution time: 0.0305
INFO - 2022-07-18 07:36:48 --> Config Class Initialized
INFO - 2022-07-18 07:36:48 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:36:48 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:36:48 --> Utf8 Class Initialized
INFO - 2022-07-18 07:36:48 --> URI Class Initialized
INFO - 2022-07-18 07:36:48 --> Router Class Initialized
INFO - 2022-07-18 07:36:48 --> Output Class Initialized
INFO - 2022-07-18 07:36:48 --> Security Class Initialized
DEBUG - 2022-07-18 07:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:36:48 --> Input Class Initialized
INFO - 2022-07-18 07:36:48 --> Language Class Initialized
INFO - 2022-07-18 07:36:48 --> Loader Class Initialized
INFO - 2022-07-18 07:36:48 --> Helper loaded: url_helper
INFO - 2022-07-18 07:36:48 --> Helper loaded: file_helper
INFO - 2022-07-18 07:36:48 --> Database Driver Class Initialized
INFO - 2022-07-18 07:36:48 --> Email Class Initialized
DEBUG - 2022-07-18 07:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:36:48 --> Controller Class Initialized
INFO - 2022-07-18 07:36:48 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:36:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 13:06:48 --> Severity: Notice --> Undefined variable: requested_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
ERROR - 2022-07-18 13:06:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
INFO - 2022-07-18 13:06:48 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 13:06:48 --> Final output sent to browser
DEBUG - 2022-07-18 13:06:48 --> Total execution time: 0.0321
INFO - 2022-07-18 07:36:53 --> Config Class Initialized
INFO - 2022-07-18 07:36:53 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:36:53 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:36:53 --> Utf8 Class Initialized
INFO - 2022-07-18 07:36:53 --> URI Class Initialized
INFO - 2022-07-18 07:36:53 --> Router Class Initialized
INFO - 2022-07-18 07:36:53 --> Output Class Initialized
INFO - 2022-07-18 07:36:53 --> Security Class Initialized
DEBUG - 2022-07-18 07:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:36:53 --> Input Class Initialized
INFO - 2022-07-18 07:36:53 --> Language Class Initialized
INFO - 2022-07-18 07:36:53 --> Loader Class Initialized
INFO - 2022-07-18 07:36:53 --> Helper loaded: url_helper
INFO - 2022-07-18 07:36:53 --> Helper loaded: file_helper
INFO - 2022-07-18 07:36:53 --> Database Driver Class Initialized
INFO - 2022-07-18 07:36:53 --> Email Class Initialized
DEBUG - 2022-07-18 07:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:36:53 --> Controller Class Initialized
INFO - 2022-07-18 07:36:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:36:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 13:06:53 --> Severity: Notice --> Undefined variable: requested_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
ERROR - 2022-07-18 13:06:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
INFO - 2022-07-18 13:06:53 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 13:06:53 --> Final output sent to browser
DEBUG - 2022-07-18 13:06:53 --> Total execution time: 0.1324
INFO - 2022-07-18 07:36:58 --> Config Class Initialized
INFO - 2022-07-18 07:36:58 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:36:58 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:36:58 --> Utf8 Class Initialized
INFO - 2022-07-18 07:36:58 --> URI Class Initialized
INFO - 2022-07-18 07:36:58 --> Router Class Initialized
INFO - 2022-07-18 07:36:58 --> Output Class Initialized
INFO - 2022-07-18 07:36:58 --> Security Class Initialized
DEBUG - 2022-07-18 07:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:36:58 --> Input Class Initialized
INFO - 2022-07-18 07:36:58 --> Language Class Initialized
INFO - 2022-07-18 07:36:58 --> Loader Class Initialized
INFO - 2022-07-18 07:36:58 --> Helper loaded: url_helper
INFO - 2022-07-18 07:36:58 --> Helper loaded: file_helper
INFO - 2022-07-18 07:36:58 --> Database Driver Class Initialized
INFO - 2022-07-18 07:36:58 --> Email Class Initialized
DEBUG - 2022-07-18 07:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:36:58 --> Controller Class Initialized
INFO - 2022-07-18 07:36:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:36:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 13:06:58 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 13:06:58 --> Final output sent to browser
DEBUG - 2022-07-18 13:06:58 --> Total execution time: 0.0770
INFO - 2022-07-18 07:37:02 --> Config Class Initialized
INFO - 2022-07-18 07:37:02 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:37:02 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:37:02 --> Utf8 Class Initialized
INFO - 2022-07-18 07:37:02 --> URI Class Initialized
INFO - 2022-07-18 07:37:02 --> Router Class Initialized
INFO - 2022-07-18 07:37:02 --> Output Class Initialized
INFO - 2022-07-18 07:37:02 --> Security Class Initialized
DEBUG - 2022-07-18 07:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:37:02 --> Input Class Initialized
INFO - 2022-07-18 07:37:02 --> Language Class Initialized
INFO - 2022-07-18 07:37:02 --> Loader Class Initialized
INFO - 2022-07-18 07:37:02 --> Helper loaded: url_helper
INFO - 2022-07-18 07:37:02 --> Helper loaded: file_helper
INFO - 2022-07-18 07:37:02 --> Database Driver Class Initialized
INFO - 2022-07-18 07:37:02 --> Email Class Initialized
DEBUG - 2022-07-18 07:37:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:37:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:37:02 --> Controller Class Initialized
INFO - 2022-07-18 07:37:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:37:02 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 13:07:03 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 13:07:03 --> Final output sent to browser
DEBUG - 2022-07-18 13:07:03 --> Total execution time: 0.2344
INFO - 2022-07-18 07:47:54 --> Config Class Initialized
INFO - 2022-07-18 07:47:54 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:47:54 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:47:54 --> Utf8 Class Initialized
INFO - 2022-07-18 07:47:54 --> URI Class Initialized
INFO - 2022-07-18 07:47:54 --> Router Class Initialized
INFO - 2022-07-18 07:47:54 --> Output Class Initialized
INFO - 2022-07-18 07:47:54 --> Security Class Initialized
DEBUG - 2022-07-18 07:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:47:54 --> Input Class Initialized
INFO - 2022-07-18 07:47:54 --> Language Class Initialized
INFO - 2022-07-18 07:47:54 --> Loader Class Initialized
INFO - 2022-07-18 07:47:54 --> Helper loaded: url_helper
INFO - 2022-07-18 07:47:54 --> Helper loaded: file_helper
INFO - 2022-07-18 07:47:54 --> Database Driver Class Initialized
INFO - 2022-07-18 07:47:54 --> Email Class Initialized
DEBUG - 2022-07-18 07:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:47:54 --> Controller Class Initialized
INFO - 2022-07-18 07:47:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:47:54 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:47:54 --> Final output sent to browser
DEBUG - 2022-07-18 07:47:54 --> Total execution time: 0.4686
INFO - 2022-07-18 07:47:55 --> Config Class Initialized
INFO - 2022-07-18 07:47:55 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:47:55 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:47:55 --> Utf8 Class Initialized
INFO - 2022-07-18 07:47:55 --> URI Class Initialized
INFO - 2022-07-18 07:47:55 --> Router Class Initialized
INFO - 2022-07-18 07:47:55 --> Output Class Initialized
INFO - 2022-07-18 07:47:55 --> Security Class Initialized
DEBUG - 2022-07-18 07:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:47:55 --> Input Class Initialized
INFO - 2022-07-18 07:47:55 --> Language Class Initialized
INFO - 2022-07-18 07:47:55 --> Loader Class Initialized
INFO - 2022-07-18 07:47:55 --> Helper loaded: url_helper
INFO - 2022-07-18 07:47:55 --> Helper loaded: file_helper
INFO - 2022-07-18 07:47:55 --> Database Driver Class Initialized
INFO - 2022-07-18 07:47:55 --> Email Class Initialized
DEBUG - 2022-07-18 07:47:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:47:55 --> Controller Class Initialized
INFO - 2022-07-18 07:47:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:47:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:47:55 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-18 07:47:55 --> Final output sent to browser
DEBUG - 2022-07-18 07:47:55 --> Total execution time: 0.0559
INFO - 2022-07-18 07:47:57 --> Config Class Initialized
INFO - 2022-07-18 07:47:57 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:47:57 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:47:57 --> Utf8 Class Initialized
INFO - 2022-07-18 07:47:57 --> URI Class Initialized
INFO - 2022-07-18 07:47:57 --> Router Class Initialized
INFO - 2022-07-18 07:47:57 --> Output Class Initialized
INFO - 2022-07-18 07:47:57 --> Security Class Initialized
DEBUG - 2022-07-18 07:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:47:57 --> Input Class Initialized
INFO - 2022-07-18 07:47:57 --> Language Class Initialized
INFO - 2022-07-18 07:47:57 --> Loader Class Initialized
INFO - 2022-07-18 07:47:57 --> Helper loaded: url_helper
INFO - 2022-07-18 07:47:57 --> Helper loaded: file_helper
INFO - 2022-07-18 07:47:57 --> Database Driver Class Initialized
INFO - 2022-07-18 07:47:57 --> Email Class Initialized
DEBUG - 2022-07-18 07:47:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:47:57 --> Controller Class Initialized
INFO - 2022-07-18 07:47:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:47:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:47:57 --> Final output sent to browser
DEBUG - 2022-07-18 07:47:57 --> Total execution time: 0.0470
INFO - 2022-07-18 07:48:51 --> Config Class Initialized
INFO - 2022-07-18 07:48:51 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:48:51 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:48:51 --> Utf8 Class Initialized
INFO - 2022-07-18 07:48:51 --> URI Class Initialized
INFO - 2022-07-18 07:48:51 --> Router Class Initialized
INFO - 2022-07-18 07:48:51 --> Output Class Initialized
INFO - 2022-07-18 07:48:51 --> Security Class Initialized
DEBUG - 2022-07-18 07:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:48:51 --> Input Class Initialized
INFO - 2022-07-18 07:48:51 --> Language Class Initialized
INFO - 2022-07-18 07:48:51 --> Loader Class Initialized
INFO - 2022-07-18 07:48:51 --> Helper loaded: url_helper
INFO - 2022-07-18 07:48:51 --> Helper loaded: file_helper
INFO - 2022-07-18 07:48:51 --> Database Driver Class Initialized
INFO - 2022-07-18 07:48:51 --> Email Class Initialized
DEBUG - 2022-07-18 07:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:48:51 --> Controller Class Initialized
INFO - 2022-07-18 07:48:51 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:48:51 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:48:51 --> Final output sent to browser
DEBUG - 2022-07-18 07:48:51 --> Total execution time: 0.0564
INFO - 2022-07-18 07:48:54 --> Config Class Initialized
INFO - 2022-07-18 07:48:54 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:48:54 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:48:54 --> Utf8 Class Initialized
INFO - 2022-07-18 07:48:54 --> URI Class Initialized
INFO - 2022-07-18 07:48:54 --> Router Class Initialized
INFO - 2022-07-18 07:48:54 --> Output Class Initialized
INFO - 2022-07-18 07:48:54 --> Security Class Initialized
DEBUG - 2022-07-18 07:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:48:54 --> Input Class Initialized
INFO - 2022-07-18 07:48:54 --> Language Class Initialized
INFO - 2022-07-18 07:48:54 --> Loader Class Initialized
INFO - 2022-07-18 07:48:54 --> Helper loaded: url_helper
INFO - 2022-07-18 07:48:54 --> Helper loaded: file_helper
INFO - 2022-07-18 07:48:54 --> Database Driver Class Initialized
INFO - 2022-07-18 07:48:54 --> Email Class Initialized
DEBUG - 2022-07-18 07:48:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:48:54 --> Controller Class Initialized
INFO - 2022-07-18 07:48:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:48:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 13:18:54 --> Severity: Notice --> Undefined variable: requested_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
ERROR - 2022-07-18 13:18:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
INFO - 2022-07-18 13:18:54 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 13:18:54 --> Final output sent to browser
DEBUG - 2022-07-18 13:18:54 --> Total execution time: 0.2764
INFO - 2022-07-18 07:48:57 --> Config Class Initialized
INFO - 2022-07-18 07:48:57 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:48:57 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:48:57 --> Utf8 Class Initialized
INFO - 2022-07-18 07:48:57 --> URI Class Initialized
INFO - 2022-07-18 07:48:57 --> Router Class Initialized
INFO - 2022-07-18 07:48:57 --> Output Class Initialized
INFO - 2022-07-18 07:48:57 --> Security Class Initialized
DEBUG - 2022-07-18 07:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:48:57 --> Input Class Initialized
INFO - 2022-07-18 07:48:57 --> Language Class Initialized
INFO - 2022-07-18 07:48:57 --> Loader Class Initialized
INFO - 2022-07-18 07:48:57 --> Helper loaded: url_helper
INFO - 2022-07-18 07:48:57 --> Helper loaded: file_helper
INFO - 2022-07-18 07:48:57 --> Database Driver Class Initialized
INFO - 2022-07-18 07:48:57 --> Email Class Initialized
DEBUG - 2022-07-18 07:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:48:57 --> Controller Class Initialized
INFO - 2022-07-18 07:48:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:48:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 13:18:57 --> Severity: Notice --> Undefined variable: requested_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
ERROR - 2022-07-18 13:18:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
INFO - 2022-07-18 13:18:57 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 13:18:57 --> Final output sent to browser
DEBUG - 2022-07-18 13:18:57 --> Total execution time: 0.1727
INFO - 2022-07-18 07:49:01 --> Config Class Initialized
INFO - 2022-07-18 07:49:01 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:49:01 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:49:01 --> Utf8 Class Initialized
INFO - 2022-07-18 07:49:01 --> URI Class Initialized
INFO - 2022-07-18 07:49:01 --> Router Class Initialized
INFO - 2022-07-18 07:49:01 --> Output Class Initialized
INFO - 2022-07-18 07:49:01 --> Security Class Initialized
DEBUG - 2022-07-18 07:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:49:01 --> Input Class Initialized
INFO - 2022-07-18 07:49:01 --> Language Class Initialized
INFO - 2022-07-18 07:49:01 --> Loader Class Initialized
INFO - 2022-07-18 07:49:01 --> Helper loaded: url_helper
INFO - 2022-07-18 07:49:01 --> Helper loaded: file_helper
INFO - 2022-07-18 07:49:01 --> Database Driver Class Initialized
INFO - 2022-07-18 07:49:01 --> Email Class Initialized
DEBUG - 2022-07-18 07:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:49:01 --> Controller Class Initialized
INFO - 2022-07-18 07:49:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:49:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 13:19:01 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 13:19:01 --> Final output sent to browser
DEBUG - 2022-07-18 13:19:01 --> Total execution time: 0.0788
INFO - 2022-07-18 07:49:05 --> Config Class Initialized
INFO - 2022-07-18 07:49:05 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:49:05 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:49:05 --> Utf8 Class Initialized
INFO - 2022-07-18 07:49:05 --> URI Class Initialized
INFO - 2022-07-18 07:49:05 --> Router Class Initialized
INFO - 2022-07-18 07:49:05 --> Output Class Initialized
INFO - 2022-07-18 07:49:05 --> Security Class Initialized
DEBUG - 2022-07-18 07:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:49:05 --> Input Class Initialized
INFO - 2022-07-18 07:49:05 --> Language Class Initialized
INFO - 2022-07-18 07:49:05 --> Loader Class Initialized
INFO - 2022-07-18 07:49:05 --> Helper loaded: url_helper
INFO - 2022-07-18 07:49:05 --> Helper loaded: file_helper
INFO - 2022-07-18 07:49:05 --> Database Driver Class Initialized
INFO - 2022-07-18 07:49:05 --> Email Class Initialized
DEBUG - 2022-07-18 07:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:49:05 --> Controller Class Initialized
INFO - 2022-07-18 07:49:05 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:49:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 13:19:05 --> Severity: error --> Exception: Too few arguments to function Tokenmodel::skip_update(), 2 passed in C:\wamp64\www\qr\application\controllers\Tokenctrl.php on line 201 and exactly 3 expected C:\wamp64\www\qr\application\models\Tokenmodel.php 106
INFO - 2022-07-18 07:50:10 --> Config Class Initialized
INFO - 2022-07-18 07:50:10 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:50:10 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:50:10 --> Utf8 Class Initialized
INFO - 2022-07-18 07:50:10 --> URI Class Initialized
INFO - 2022-07-18 07:50:10 --> Router Class Initialized
INFO - 2022-07-18 07:50:10 --> Output Class Initialized
INFO - 2022-07-18 07:50:10 --> Security Class Initialized
DEBUG - 2022-07-18 07:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:50:10 --> Input Class Initialized
INFO - 2022-07-18 07:50:10 --> Language Class Initialized
INFO - 2022-07-18 07:50:10 --> Loader Class Initialized
INFO - 2022-07-18 07:50:10 --> Helper loaded: url_helper
INFO - 2022-07-18 07:50:10 --> Helper loaded: file_helper
INFO - 2022-07-18 07:50:10 --> Database Driver Class Initialized
INFO - 2022-07-18 07:50:10 --> Email Class Initialized
DEBUG - 2022-07-18 07:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:50:10 --> Controller Class Initialized
INFO - 2022-07-18 07:50:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:50:10 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:50:10 --> Final output sent to browser
DEBUG - 2022-07-18 07:50:10 --> Total execution time: 0.1542
INFO - 2022-07-18 07:50:10 --> Config Class Initialized
INFO - 2022-07-18 07:50:10 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:50:10 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:50:10 --> Utf8 Class Initialized
INFO - 2022-07-18 07:50:10 --> URI Class Initialized
INFO - 2022-07-18 07:50:10 --> Router Class Initialized
INFO - 2022-07-18 07:50:10 --> Output Class Initialized
INFO - 2022-07-18 07:50:10 --> Security Class Initialized
DEBUG - 2022-07-18 07:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:50:10 --> Input Class Initialized
INFO - 2022-07-18 07:50:10 --> Language Class Initialized
INFO - 2022-07-18 07:50:10 --> Loader Class Initialized
INFO - 2022-07-18 07:50:10 --> Helper loaded: url_helper
INFO - 2022-07-18 07:50:10 --> Helper loaded: file_helper
INFO - 2022-07-18 07:50:10 --> Database Driver Class Initialized
INFO - 2022-07-18 07:50:10 --> Email Class Initialized
DEBUG - 2022-07-18 07:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:50:10 --> Controller Class Initialized
INFO - 2022-07-18 07:50:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:50:10 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:50:10 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-18 07:50:10 --> Final output sent to browser
DEBUG - 2022-07-18 07:50:10 --> Total execution time: 0.0282
INFO - 2022-07-18 07:50:12 --> Config Class Initialized
INFO - 2022-07-18 07:50:12 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:50:12 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:50:12 --> Utf8 Class Initialized
INFO - 2022-07-18 07:50:12 --> URI Class Initialized
INFO - 2022-07-18 07:50:12 --> Router Class Initialized
INFO - 2022-07-18 07:50:12 --> Output Class Initialized
INFO - 2022-07-18 07:50:12 --> Security Class Initialized
DEBUG - 2022-07-18 07:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:50:12 --> Input Class Initialized
INFO - 2022-07-18 07:50:12 --> Language Class Initialized
INFO - 2022-07-18 07:50:12 --> Loader Class Initialized
INFO - 2022-07-18 07:50:12 --> Helper loaded: url_helper
INFO - 2022-07-18 07:50:12 --> Helper loaded: file_helper
INFO - 2022-07-18 07:50:12 --> Database Driver Class Initialized
INFO - 2022-07-18 07:50:12 --> Email Class Initialized
DEBUG - 2022-07-18 07:50:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:50:12 --> Controller Class Initialized
INFO - 2022-07-18 07:50:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:50:12 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:50:12 --> Final output sent to browser
DEBUG - 2022-07-18 07:50:12 --> Total execution time: 0.0259
INFO - 2022-07-18 07:50:15 --> Config Class Initialized
INFO - 2022-07-18 07:50:15 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:50:15 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:50:15 --> Utf8 Class Initialized
INFO - 2022-07-18 07:50:15 --> URI Class Initialized
INFO - 2022-07-18 07:50:15 --> Router Class Initialized
INFO - 2022-07-18 07:50:15 --> Output Class Initialized
INFO - 2022-07-18 07:50:15 --> Security Class Initialized
DEBUG - 2022-07-18 07:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:50:15 --> Input Class Initialized
INFO - 2022-07-18 07:50:15 --> Language Class Initialized
INFO - 2022-07-18 07:50:15 --> Loader Class Initialized
INFO - 2022-07-18 07:50:15 --> Helper loaded: url_helper
INFO - 2022-07-18 07:50:15 --> Helper loaded: file_helper
INFO - 2022-07-18 07:50:15 --> Database Driver Class Initialized
INFO - 2022-07-18 07:50:15 --> Email Class Initialized
DEBUG - 2022-07-18 07:50:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:50:15 --> Controller Class Initialized
INFO - 2022-07-18 07:50:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:50:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 13:20:15 --> Severity: Notice --> Undefined variable: requested_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
ERROR - 2022-07-18 13:20:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
INFO - 2022-07-18 13:20:15 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 13:20:15 --> Final output sent to browser
DEBUG - 2022-07-18 13:20:15 --> Total execution time: 0.0583
INFO - 2022-07-18 07:50:18 --> Config Class Initialized
INFO - 2022-07-18 07:50:18 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:50:18 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:50:18 --> Utf8 Class Initialized
INFO - 2022-07-18 07:50:18 --> URI Class Initialized
INFO - 2022-07-18 07:50:18 --> Router Class Initialized
INFO - 2022-07-18 07:50:18 --> Output Class Initialized
INFO - 2022-07-18 07:50:18 --> Security Class Initialized
DEBUG - 2022-07-18 07:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:50:18 --> Input Class Initialized
INFO - 2022-07-18 07:50:18 --> Language Class Initialized
INFO - 2022-07-18 07:50:18 --> Loader Class Initialized
INFO - 2022-07-18 07:50:18 --> Helper loaded: url_helper
INFO - 2022-07-18 07:50:18 --> Helper loaded: file_helper
INFO - 2022-07-18 07:50:18 --> Database Driver Class Initialized
INFO - 2022-07-18 07:50:18 --> Email Class Initialized
DEBUG - 2022-07-18 07:50:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:50:18 --> Controller Class Initialized
INFO - 2022-07-18 07:50:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:50:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 13:20:18 --> Severity: Notice --> Undefined variable: requested_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
ERROR - 2022-07-18 13:20:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
INFO - 2022-07-18 13:20:18 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 13:20:18 --> Final output sent to browser
DEBUG - 2022-07-18 13:20:18 --> Total execution time: 0.0704
INFO - 2022-07-18 07:50:19 --> Config Class Initialized
INFO - 2022-07-18 07:50:19 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:50:19 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:50:19 --> Utf8 Class Initialized
INFO - 2022-07-18 07:50:19 --> URI Class Initialized
INFO - 2022-07-18 07:50:19 --> Router Class Initialized
INFO - 2022-07-18 07:50:19 --> Output Class Initialized
INFO - 2022-07-18 07:50:19 --> Security Class Initialized
DEBUG - 2022-07-18 07:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:50:19 --> Input Class Initialized
INFO - 2022-07-18 07:50:19 --> Language Class Initialized
INFO - 2022-07-18 07:50:19 --> Loader Class Initialized
INFO - 2022-07-18 07:50:19 --> Helper loaded: url_helper
INFO - 2022-07-18 07:50:19 --> Helper loaded: file_helper
INFO - 2022-07-18 07:50:19 --> Database Driver Class Initialized
INFO - 2022-07-18 07:50:19 --> Email Class Initialized
DEBUG - 2022-07-18 07:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:50:19 --> Controller Class Initialized
INFO - 2022-07-18 07:50:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:50:19 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 13:20:19 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 13:20:19 --> Final output sent to browser
DEBUG - 2022-07-18 13:20:19 --> Total execution time: 0.1604
INFO - 2022-07-18 07:50:23 --> Config Class Initialized
INFO - 2022-07-18 07:50:23 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:50:23 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:50:23 --> Utf8 Class Initialized
INFO - 2022-07-18 07:50:23 --> URI Class Initialized
INFO - 2022-07-18 07:50:23 --> Router Class Initialized
INFO - 2022-07-18 07:50:23 --> Output Class Initialized
INFO - 2022-07-18 07:50:23 --> Security Class Initialized
DEBUG - 2022-07-18 07:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:50:23 --> Input Class Initialized
INFO - 2022-07-18 07:50:23 --> Language Class Initialized
INFO - 2022-07-18 07:50:23 --> Loader Class Initialized
INFO - 2022-07-18 07:50:23 --> Helper loaded: url_helper
INFO - 2022-07-18 07:50:23 --> Helper loaded: file_helper
INFO - 2022-07-18 07:50:23 --> Database Driver Class Initialized
INFO - 2022-07-18 07:50:23 --> Email Class Initialized
DEBUG - 2022-07-18 07:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:50:23 --> Controller Class Initialized
INFO - 2022-07-18 07:50:23 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:50:23 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 13:20:23 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 13:20:23 --> Final output sent to browser
DEBUG - 2022-07-18 13:20:23 --> Total execution time: 0.0589
INFO - 2022-07-18 07:52:51 --> Config Class Initialized
INFO - 2022-07-18 07:52:51 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:52:51 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:52:51 --> Utf8 Class Initialized
INFO - 2022-07-18 07:52:51 --> URI Class Initialized
INFO - 2022-07-18 07:52:51 --> Router Class Initialized
INFO - 2022-07-18 07:52:51 --> Output Class Initialized
INFO - 2022-07-18 07:52:51 --> Security Class Initialized
DEBUG - 2022-07-18 07:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:52:51 --> Input Class Initialized
INFO - 2022-07-18 07:52:51 --> Language Class Initialized
INFO - 2022-07-18 07:52:51 --> Loader Class Initialized
INFO - 2022-07-18 07:52:51 --> Helper loaded: url_helper
INFO - 2022-07-18 07:52:51 --> Helper loaded: file_helper
INFO - 2022-07-18 07:52:51 --> Database Driver Class Initialized
INFO - 2022-07-18 07:52:51 --> Email Class Initialized
DEBUG - 2022-07-18 07:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:52:51 --> Controller Class Initialized
INFO - 2022-07-18 07:52:51 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:52:51 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 13:22:51 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 13:22:51 --> Final output sent to browser
DEBUG - 2022-07-18 13:22:51 --> Total execution time: 0.3966
INFO - 2022-07-18 07:52:53 --> Config Class Initialized
INFO - 2022-07-18 07:52:53 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:52:53 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:52:53 --> Utf8 Class Initialized
INFO - 2022-07-18 07:52:53 --> URI Class Initialized
INFO - 2022-07-18 07:52:53 --> Router Class Initialized
INFO - 2022-07-18 07:52:53 --> Output Class Initialized
INFO - 2022-07-18 07:52:53 --> Security Class Initialized
DEBUG - 2022-07-18 07:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:52:53 --> Input Class Initialized
INFO - 2022-07-18 07:52:53 --> Language Class Initialized
INFO - 2022-07-18 07:52:53 --> Loader Class Initialized
INFO - 2022-07-18 07:52:53 --> Helper loaded: url_helper
INFO - 2022-07-18 07:52:53 --> Helper loaded: file_helper
INFO - 2022-07-18 07:52:53 --> Database Driver Class Initialized
INFO - 2022-07-18 07:52:53 --> Email Class Initialized
DEBUG - 2022-07-18 07:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:52:53 --> Controller Class Initialized
INFO - 2022-07-18 07:52:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:52:53 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:52:53 --> Final output sent to browser
DEBUG - 2022-07-18 07:52:53 --> Total execution time: 0.0279
INFO - 2022-07-18 07:52:53 --> Config Class Initialized
INFO - 2022-07-18 07:52:53 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:52:53 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:52:53 --> Utf8 Class Initialized
INFO - 2022-07-18 07:52:53 --> URI Class Initialized
INFO - 2022-07-18 07:52:53 --> Router Class Initialized
INFO - 2022-07-18 07:52:53 --> Output Class Initialized
INFO - 2022-07-18 07:52:53 --> Security Class Initialized
DEBUG - 2022-07-18 07:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:52:53 --> Input Class Initialized
INFO - 2022-07-18 07:52:53 --> Language Class Initialized
INFO - 2022-07-18 07:52:53 --> Loader Class Initialized
INFO - 2022-07-18 07:52:53 --> Helper loaded: url_helper
INFO - 2022-07-18 07:52:53 --> Helper loaded: file_helper
INFO - 2022-07-18 07:52:53 --> Database Driver Class Initialized
INFO - 2022-07-18 07:52:53 --> Email Class Initialized
DEBUG - 2022-07-18 07:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:52:53 --> Controller Class Initialized
INFO - 2022-07-18 07:52:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:52:53 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:52:53 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-18 07:52:53 --> Final output sent to browser
DEBUG - 2022-07-18 07:52:53 --> Total execution time: 0.0215
INFO - 2022-07-18 07:52:56 --> Config Class Initialized
INFO - 2022-07-18 07:52:56 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:52:56 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:52:56 --> Utf8 Class Initialized
INFO - 2022-07-18 07:52:56 --> URI Class Initialized
INFO - 2022-07-18 07:52:56 --> Router Class Initialized
INFO - 2022-07-18 07:52:56 --> Output Class Initialized
INFO - 2022-07-18 07:52:56 --> Security Class Initialized
DEBUG - 2022-07-18 07:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:52:56 --> Input Class Initialized
INFO - 2022-07-18 07:52:56 --> Language Class Initialized
INFO - 2022-07-18 07:52:56 --> Loader Class Initialized
INFO - 2022-07-18 07:52:56 --> Helper loaded: url_helper
INFO - 2022-07-18 07:52:56 --> Helper loaded: file_helper
INFO - 2022-07-18 07:52:56 --> Database Driver Class Initialized
INFO - 2022-07-18 07:52:57 --> Email Class Initialized
DEBUG - 2022-07-18 07:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:52:57 --> Controller Class Initialized
INFO - 2022-07-18 07:52:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:52:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:52:57 --> Final output sent to browser
DEBUG - 2022-07-18 07:52:57 --> Total execution time: 0.0737
INFO - 2022-07-18 07:52:59 --> Config Class Initialized
INFO - 2022-07-18 07:52:59 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:52:59 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:52:59 --> Utf8 Class Initialized
INFO - 2022-07-18 07:52:59 --> URI Class Initialized
INFO - 2022-07-18 07:52:59 --> Router Class Initialized
INFO - 2022-07-18 07:52:59 --> Output Class Initialized
INFO - 2022-07-18 07:52:59 --> Security Class Initialized
DEBUG - 2022-07-18 07:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:52:59 --> Input Class Initialized
INFO - 2022-07-18 07:52:59 --> Language Class Initialized
INFO - 2022-07-18 07:52:59 --> Loader Class Initialized
INFO - 2022-07-18 07:52:59 --> Helper loaded: url_helper
INFO - 2022-07-18 07:52:59 --> Helper loaded: file_helper
INFO - 2022-07-18 07:52:59 --> Database Driver Class Initialized
INFO - 2022-07-18 07:52:59 --> Email Class Initialized
DEBUG - 2022-07-18 07:52:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:52:59 --> Controller Class Initialized
INFO - 2022-07-18 07:52:59 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:52:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 13:22:59 --> Severity: Notice --> Undefined variable: requested_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
ERROR - 2022-07-18 13:22:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
INFO - 2022-07-18 13:22:59 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 13:22:59 --> Final output sent to browser
DEBUG - 2022-07-18 13:22:59 --> Total execution time: 0.0578
INFO - 2022-07-18 07:53:02 --> Config Class Initialized
INFO - 2022-07-18 07:53:02 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:53:02 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:53:02 --> Utf8 Class Initialized
INFO - 2022-07-18 07:53:02 --> URI Class Initialized
INFO - 2022-07-18 07:53:02 --> Router Class Initialized
INFO - 2022-07-18 07:53:02 --> Output Class Initialized
INFO - 2022-07-18 07:53:02 --> Security Class Initialized
DEBUG - 2022-07-18 07:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:53:02 --> Input Class Initialized
INFO - 2022-07-18 07:53:02 --> Language Class Initialized
INFO - 2022-07-18 07:53:02 --> Loader Class Initialized
INFO - 2022-07-18 07:53:02 --> Helper loaded: url_helper
INFO - 2022-07-18 07:53:02 --> Helper loaded: file_helper
INFO - 2022-07-18 07:53:02 --> Database Driver Class Initialized
INFO - 2022-07-18 07:53:02 --> Email Class Initialized
DEBUG - 2022-07-18 07:53:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:53:02 --> Controller Class Initialized
INFO - 2022-07-18 07:53:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:53:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 13:23:02 --> Severity: Notice --> Undefined variable: requested_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
ERROR - 2022-07-18 13:23:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
INFO - 2022-07-18 13:23:02 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 13:23:02 --> Final output sent to browser
DEBUG - 2022-07-18 13:23:02 --> Total execution time: 0.0287
INFO - 2022-07-18 07:53:06 --> Config Class Initialized
INFO - 2022-07-18 07:53:06 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:53:06 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:53:06 --> Utf8 Class Initialized
INFO - 2022-07-18 07:53:06 --> URI Class Initialized
INFO - 2022-07-18 07:53:06 --> Router Class Initialized
INFO - 2022-07-18 07:53:06 --> Output Class Initialized
INFO - 2022-07-18 07:53:06 --> Security Class Initialized
DEBUG - 2022-07-18 07:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:53:06 --> Input Class Initialized
INFO - 2022-07-18 07:53:06 --> Language Class Initialized
INFO - 2022-07-18 07:53:06 --> Loader Class Initialized
INFO - 2022-07-18 07:53:06 --> Helper loaded: url_helper
INFO - 2022-07-18 07:53:06 --> Helper loaded: file_helper
INFO - 2022-07-18 07:53:06 --> Database Driver Class Initialized
INFO - 2022-07-18 07:53:07 --> Email Class Initialized
DEBUG - 2022-07-18 07:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:53:07 --> Controller Class Initialized
INFO - 2022-07-18 07:53:07 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:53:07 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 13:23:07 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 13:23:07 --> Final output sent to browser
DEBUG - 2022-07-18 13:23:07 --> Total execution time: 0.0614
INFO - 2022-07-18 07:56:56 --> Config Class Initialized
INFO - 2022-07-18 07:56:56 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:56:56 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:56:56 --> Utf8 Class Initialized
INFO - 2022-07-18 07:56:56 --> URI Class Initialized
INFO - 2022-07-18 07:56:56 --> Router Class Initialized
INFO - 2022-07-18 07:56:56 --> Output Class Initialized
INFO - 2022-07-18 07:56:56 --> Security Class Initialized
DEBUG - 2022-07-18 07:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:56:56 --> Input Class Initialized
INFO - 2022-07-18 07:56:56 --> Language Class Initialized
INFO - 2022-07-18 07:56:56 --> Loader Class Initialized
INFO - 2022-07-18 07:56:56 --> Helper loaded: url_helper
INFO - 2022-07-18 07:56:56 --> Helper loaded: file_helper
INFO - 2022-07-18 07:56:56 --> Database Driver Class Initialized
INFO - 2022-07-18 07:56:56 --> Email Class Initialized
DEBUG - 2022-07-18 07:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:56:56 --> Controller Class Initialized
INFO - 2022-07-18 07:56:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:56:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:56:56 --> Final output sent to browser
DEBUG - 2022-07-18 07:56:56 --> Total execution time: 0.0416
INFO - 2022-07-18 07:56:56 --> Config Class Initialized
INFO - 2022-07-18 07:56:56 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:56:56 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:56:56 --> Utf8 Class Initialized
INFO - 2022-07-18 07:56:56 --> URI Class Initialized
INFO - 2022-07-18 07:56:56 --> Router Class Initialized
INFO - 2022-07-18 07:56:56 --> Output Class Initialized
INFO - 2022-07-18 07:56:56 --> Security Class Initialized
DEBUG - 2022-07-18 07:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:56:56 --> Input Class Initialized
INFO - 2022-07-18 07:56:56 --> Language Class Initialized
INFO - 2022-07-18 07:56:56 --> Loader Class Initialized
INFO - 2022-07-18 07:56:56 --> Helper loaded: url_helper
INFO - 2022-07-18 07:56:56 --> Helper loaded: file_helper
INFO - 2022-07-18 07:56:56 --> Database Driver Class Initialized
INFO - 2022-07-18 07:56:56 --> Email Class Initialized
DEBUG - 2022-07-18 07:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:56:56 --> Controller Class Initialized
INFO - 2022-07-18 07:56:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:56:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:56:56 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-18 07:56:56 --> Final output sent to browser
DEBUG - 2022-07-18 07:56:56 --> Total execution time: 0.0206
INFO - 2022-07-18 07:56:59 --> Config Class Initialized
INFO - 2022-07-18 07:56:59 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:56:59 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:56:59 --> Utf8 Class Initialized
INFO - 2022-07-18 07:56:59 --> URI Class Initialized
INFO - 2022-07-18 07:56:59 --> Router Class Initialized
INFO - 2022-07-18 07:56:59 --> Output Class Initialized
INFO - 2022-07-18 07:56:59 --> Security Class Initialized
DEBUG - 2022-07-18 07:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:56:59 --> Input Class Initialized
INFO - 2022-07-18 07:56:59 --> Language Class Initialized
INFO - 2022-07-18 07:56:59 --> Loader Class Initialized
INFO - 2022-07-18 07:56:59 --> Helper loaded: url_helper
INFO - 2022-07-18 07:56:59 --> Helper loaded: file_helper
INFO - 2022-07-18 07:56:59 --> Database Driver Class Initialized
INFO - 2022-07-18 07:56:59 --> Email Class Initialized
DEBUG - 2022-07-18 07:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:56:59 --> Controller Class Initialized
INFO - 2022-07-18 07:56:59 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:56:59 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:56:59 --> Final output sent to browser
DEBUG - 2022-07-18 07:56:59 --> Total execution time: 0.0307
INFO - 2022-07-18 07:57:01 --> Config Class Initialized
INFO - 2022-07-18 07:57:01 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:57:01 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:57:01 --> Utf8 Class Initialized
INFO - 2022-07-18 07:57:01 --> URI Class Initialized
INFO - 2022-07-18 07:57:01 --> Router Class Initialized
INFO - 2022-07-18 07:57:01 --> Output Class Initialized
INFO - 2022-07-18 07:57:01 --> Security Class Initialized
DEBUG - 2022-07-18 07:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:57:01 --> Input Class Initialized
INFO - 2022-07-18 07:57:01 --> Language Class Initialized
INFO - 2022-07-18 07:57:01 --> Loader Class Initialized
INFO - 2022-07-18 07:57:01 --> Helper loaded: url_helper
INFO - 2022-07-18 07:57:01 --> Helper loaded: file_helper
INFO - 2022-07-18 07:57:01 --> Database Driver Class Initialized
INFO - 2022-07-18 07:57:01 --> Email Class Initialized
DEBUG - 2022-07-18 07:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:57:01 --> Controller Class Initialized
INFO - 2022-07-18 07:57:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:57:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 13:27:01 --> Severity: Notice --> Undefined variable: requested_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
ERROR - 2022-07-18 13:27:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
INFO - 2022-07-18 13:27:01 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 13:27:01 --> Final output sent to browser
DEBUG - 2022-07-18 13:27:01 --> Total execution time: 0.1953
INFO - 2022-07-18 07:57:27 --> Config Class Initialized
INFO - 2022-07-18 07:57:27 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:57:27 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:57:27 --> Utf8 Class Initialized
INFO - 2022-07-18 07:57:27 --> URI Class Initialized
INFO - 2022-07-18 07:57:27 --> Router Class Initialized
INFO - 2022-07-18 07:57:27 --> Output Class Initialized
INFO - 2022-07-18 07:57:27 --> Security Class Initialized
DEBUG - 2022-07-18 07:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:57:27 --> Input Class Initialized
INFO - 2022-07-18 07:57:27 --> Language Class Initialized
INFO - 2022-07-18 07:57:27 --> Loader Class Initialized
INFO - 2022-07-18 07:57:27 --> Helper loaded: url_helper
INFO - 2022-07-18 07:57:27 --> Helper loaded: file_helper
INFO - 2022-07-18 07:57:27 --> Database Driver Class Initialized
INFO - 2022-07-18 07:57:27 --> Email Class Initialized
DEBUG - 2022-07-18 07:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:57:27 --> Controller Class Initialized
INFO - 2022-07-18 07:57:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:57:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 13:27:27 --> Severity: Notice --> Undefined variable: requested_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
ERROR - 2022-07-18 13:27:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
INFO - 2022-07-18 13:27:27 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 13:27:27 --> Final output sent to browser
DEBUG - 2022-07-18 13:27:27 --> Total execution time: 0.0606
INFO - 2022-07-18 07:57:31 --> Config Class Initialized
INFO - 2022-07-18 07:57:31 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:57:31 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:57:31 --> Utf8 Class Initialized
INFO - 2022-07-18 07:57:31 --> URI Class Initialized
INFO - 2022-07-18 07:57:31 --> Router Class Initialized
INFO - 2022-07-18 07:57:31 --> Output Class Initialized
INFO - 2022-07-18 07:57:31 --> Security Class Initialized
DEBUG - 2022-07-18 07:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:57:31 --> Input Class Initialized
INFO - 2022-07-18 07:57:31 --> Language Class Initialized
INFO - 2022-07-18 07:57:31 --> Loader Class Initialized
INFO - 2022-07-18 07:57:31 --> Helper loaded: url_helper
INFO - 2022-07-18 07:57:31 --> Helper loaded: file_helper
INFO - 2022-07-18 07:57:31 --> Database Driver Class Initialized
INFO - 2022-07-18 07:57:31 --> Email Class Initialized
DEBUG - 2022-07-18 07:57:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:57:32 --> Controller Class Initialized
INFO - 2022-07-18 07:57:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:57:32 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 13:27:32 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 13:27:32 --> Final output sent to browser
DEBUG - 2022-07-18 13:27:32 --> Total execution time: 0.3893
INFO - 2022-07-18 07:57:56 --> Config Class Initialized
INFO - 2022-07-18 07:57:56 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:57:56 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:57:56 --> Utf8 Class Initialized
INFO - 2022-07-18 07:57:56 --> URI Class Initialized
INFO - 2022-07-18 07:57:56 --> Router Class Initialized
INFO - 2022-07-18 07:57:56 --> Output Class Initialized
INFO - 2022-07-18 07:57:56 --> Security Class Initialized
DEBUG - 2022-07-18 07:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:57:56 --> Input Class Initialized
INFO - 2022-07-18 07:57:56 --> Language Class Initialized
INFO - 2022-07-18 07:57:56 --> Loader Class Initialized
INFO - 2022-07-18 07:57:56 --> Helper loaded: url_helper
INFO - 2022-07-18 07:57:56 --> Helper loaded: file_helper
INFO - 2022-07-18 07:57:56 --> Database Driver Class Initialized
INFO - 2022-07-18 07:57:56 --> Email Class Initialized
DEBUG - 2022-07-18 07:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:57:56 --> Controller Class Initialized
INFO - 2022-07-18 07:57:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:57:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-07-18 07:57:56 --> insertedINSERT INTO `tokendetails` (`td_tk`, `td_cs`, `td_visited_date`) VALUES (7, 0, '2022-07-18')
INFO - 2022-07-18 07:57:56 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-18 07:57:56 --> Final output sent to browser
DEBUG - 2022-07-18 07:57:56 --> Total execution time: 0.0359
INFO - 2022-07-18 07:58:00 --> Config Class Initialized
INFO - 2022-07-18 07:58:00 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:58:00 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:58:00 --> Utf8 Class Initialized
INFO - 2022-07-18 07:58:00 --> URI Class Initialized
INFO - 2022-07-18 07:58:00 --> Router Class Initialized
INFO - 2022-07-18 07:58:00 --> Output Class Initialized
INFO - 2022-07-18 07:58:00 --> Security Class Initialized
DEBUG - 2022-07-18 07:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:58:00 --> Input Class Initialized
INFO - 2022-07-18 07:58:00 --> Language Class Initialized
INFO - 2022-07-18 07:58:00 --> Loader Class Initialized
INFO - 2022-07-18 07:58:00 --> Helper loaded: url_helper
INFO - 2022-07-18 07:58:00 --> Helper loaded: file_helper
INFO - 2022-07-18 07:58:00 --> Database Driver Class Initialized
INFO - 2022-07-18 07:58:00 --> Email Class Initialized
DEBUG - 2022-07-18 07:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:58:00 --> Controller Class Initialized
INFO - 2022-07-18 07:58:00 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:58:00 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:58:00 --> Final output sent to browser
DEBUG - 2022-07-18 07:58:00 --> Total execution time: 0.1519
INFO - 2022-07-18 07:58:11 --> Config Class Initialized
INFO - 2022-07-18 07:58:11 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:58:11 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:58:11 --> Utf8 Class Initialized
INFO - 2022-07-18 07:58:11 --> URI Class Initialized
INFO - 2022-07-18 07:58:11 --> Router Class Initialized
INFO - 2022-07-18 07:58:11 --> Output Class Initialized
INFO - 2022-07-18 07:58:11 --> Security Class Initialized
DEBUG - 2022-07-18 07:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:58:11 --> Input Class Initialized
INFO - 2022-07-18 07:58:11 --> Language Class Initialized
INFO - 2022-07-18 07:58:11 --> Loader Class Initialized
INFO - 2022-07-18 07:58:11 --> Helper loaded: url_helper
INFO - 2022-07-18 07:58:11 --> Helper loaded: file_helper
INFO - 2022-07-18 07:58:11 --> Database Driver Class Initialized
INFO - 2022-07-18 07:58:11 --> Email Class Initialized
DEBUG - 2022-07-18 07:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:58:11 --> Controller Class Initialized
INFO - 2022-07-18 07:58:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:58:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 13:28:11 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 13:28:11 --> Final output sent to browser
DEBUG - 2022-07-18 13:28:11 --> Total execution time: 0.0312
INFO - 2022-07-18 07:58:15 --> Config Class Initialized
INFO - 2022-07-18 07:58:15 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:58:15 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:58:15 --> Utf8 Class Initialized
INFO - 2022-07-18 07:58:15 --> URI Class Initialized
INFO - 2022-07-18 07:58:15 --> Router Class Initialized
INFO - 2022-07-18 07:58:15 --> Output Class Initialized
INFO - 2022-07-18 07:58:15 --> Security Class Initialized
DEBUG - 2022-07-18 07:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:58:15 --> Input Class Initialized
INFO - 2022-07-18 07:58:15 --> Language Class Initialized
INFO - 2022-07-18 07:58:15 --> Loader Class Initialized
INFO - 2022-07-18 07:58:15 --> Helper loaded: url_helper
INFO - 2022-07-18 07:58:15 --> Helper loaded: file_helper
INFO - 2022-07-18 07:58:15 --> Database Driver Class Initialized
INFO - 2022-07-18 07:58:15 --> Email Class Initialized
DEBUG - 2022-07-18 07:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:58:15 --> Controller Class Initialized
INFO - 2022-07-18 07:58:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:58:15 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 13:28:15 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 13:28:15 --> Final output sent to browser
DEBUG - 2022-07-18 13:28:15 --> Total execution time: 0.0545
INFO - 2022-07-18 07:58:18 --> Config Class Initialized
INFO - 2022-07-18 07:58:18 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:58:18 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:58:18 --> Utf8 Class Initialized
INFO - 2022-07-18 07:58:18 --> URI Class Initialized
INFO - 2022-07-18 07:58:18 --> Router Class Initialized
INFO - 2022-07-18 07:58:18 --> Output Class Initialized
INFO - 2022-07-18 07:58:18 --> Security Class Initialized
DEBUG - 2022-07-18 07:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:58:18 --> Input Class Initialized
INFO - 2022-07-18 07:58:18 --> Language Class Initialized
INFO - 2022-07-18 07:58:18 --> Loader Class Initialized
INFO - 2022-07-18 07:58:18 --> Helper loaded: url_helper
INFO - 2022-07-18 07:58:18 --> Helper loaded: file_helper
INFO - 2022-07-18 07:58:18 --> Database Driver Class Initialized
INFO - 2022-07-18 07:58:18 --> Email Class Initialized
DEBUG - 2022-07-18 07:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:58:18 --> Controller Class Initialized
INFO - 2022-07-18 07:58:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:58:18 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 13:28:18 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 13:28:18 --> Final output sent to browser
DEBUG - 2022-07-18 13:28:18 --> Total execution time: 0.1743
INFO - 2022-07-18 07:58:19 --> Config Class Initialized
INFO - 2022-07-18 07:58:19 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:58:19 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:58:19 --> Utf8 Class Initialized
INFO - 2022-07-18 07:58:19 --> URI Class Initialized
INFO - 2022-07-18 07:58:19 --> Router Class Initialized
INFO - 2022-07-18 07:58:19 --> Output Class Initialized
INFO - 2022-07-18 07:58:19 --> Security Class Initialized
DEBUG - 2022-07-18 07:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:58:19 --> Input Class Initialized
INFO - 2022-07-18 07:58:19 --> Language Class Initialized
INFO - 2022-07-18 07:58:19 --> Loader Class Initialized
INFO - 2022-07-18 07:58:19 --> Helper loaded: url_helper
INFO - 2022-07-18 07:58:19 --> Helper loaded: file_helper
INFO - 2022-07-18 07:58:19 --> Database Driver Class Initialized
INFO - 2022-07-18 07:58:19 --> Email Class Initialized
DEBUG - 2022-07-18 07:58:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:58:19 --> Controller Class Initialized
INFO - 2022-07-18 07:58:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:58:19 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 13:28:19 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 13:28:19 --> Final output sent to browser
DEBUG - 2022-07-18 13:28:19 --> Total execution time: 0.1265
INFO - 2022-07-18 07:58:20 --> Config Class Initialized
INFO - 2022-07-18 07:58:20 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:58:20 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:58:20 --> Utf8 Class Initialized
INFO - 2022-07-18 07:58:20 --> URI Class Initialized
INFO - 2022-07-18 07:58:20 --> Router Class Initialized
INFO - 2022-07-18 07:58:20 --> Output Class Initialized
INFO - 2022-07-18 07:58:20 --> Security Class Initialized
DEBUG - 2022-07-18 07:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:58:20 --> Input Class Initialized
INFO - 2022-07-18 07:58:20 --> Language Class Initialized
INFO - 2022-07-18 07:58:20 --> Loader Class Initialized
INFO - 2022-07-18 07:58:20 --> Helper loaded: url_helper
INFO - 2022-07-18 07:58:20 --> Helper loaded: file_helper
INFO - 2022-07-18 07:58:20 --> Database Driver Class Initialized
INFO - 2022-07-18 07:58:20 --> Email Class Initialized
DEBUG - 2022-07-18 07:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:58:20 --> Controller Class Initialized
INFO - 2022-07-18 07:58:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:58:20 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 13:28:20 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 13:28:20 --> Final output sent to browser
DEBUG - 2022-07-18 13:28:20 --> Total execution time: 0.0584
INFO - 2022-07-18 07:58:20 --> Config Class Initialized
INFO - 2022-07-18 07:58:20 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:58:20 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:58:20 --> Utf8 Class Initialized
INFO - 2022-07-18 07:58:20 --> URI Class Initialized
INFO - 2022-07-18 07:58:20 --> Router Class Initialized
INFO - 2022-07-18 07:58:20 --> Output Class Initialized
INFO - 2022-07-18 07:58:20 --> Security Class Initialized
DEBUG - 2022-07-18 07:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:58:20 --> Input Class Initialized
INFO - 2022-07-18 07:58:20 --> Language Class Initialized
INFO - 2022-07-18 07:58:20 --> Loader Class Initialized
INFO - 2022-07-18 07:58:20 --> Helper loaded: url_helper
INFO - 2022-07-18 07:58:20 --> Helper loaded: file_helper
INFO - 2022-07-18 07:58:20 --> Database Driver Class Initialized
INFO - 2022-07-18 07:58:20 --> Email Class Initialized
DEBUG - 2022-07-18 07:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:58:20 --> Controller Class Initialized
INFO - 2022-07-18 07:58:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:58:20 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 13:28:20 --> Final output sent to browser
DEBUG - 2022-07-18 13:28:20 --> Total execution time: 0.0193
INFO - 2022-07-18 07:58:21 --> Config Class Initialized
INFO - 2022-07-18 07:58:21 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:58:21 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:58:21 --> Utf8 Class Initialized
INFO - 2022-07-18 07:58:21 --> URI Class Initialized
INFO - 2022-07-18 07:58:21 --> Router Class Initialized
INFO - 2022-07-18 07:58:21 --> Output Class Initialized
INFO - 2022-07-18 07:58:21 --> Security Class Initialized
DEBUG - 2022-07-18 07:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:58:21 --> Input Class Initialized
INFO - 2022-07-18 07:58:21 --> Language Class Initialized
INFO - 2022-07-18 07:58:21 --> Loader Class Initialized
INFO - 2022-07-18 07:58:21 --> Helper loaded: url_helper
INFO - 2022-07-18 07:58:21 --> Helper loaded: file_helper
INFO - 2022-07-18 07:58:21 --> Database Driver Class Initialized
INFO - 2022-07-18 07:58:21 --> Email Class Initialized
DEBUG - 2022-07-18 07:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:58:21 --> Controller Class Initialized
INFO - 2022-07-18 07:58:21 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:58:21 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 13:28:21 --> Final output sent to browser
DEBUG - 2022-07-18 13:28:21 --> Total execution time: 0.0571
INFO - 2022-07-18 07:59:27 --> Config Class Initialized
INFO - 2022-07-18 07:59:27 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:59:27 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:59:27 --> Utf8 Class Initialized
INFO - 2022-07-18 07:59:27 --> URI Class Initialized
INFO - 2022-07-18 07:59:27 --> Router Class Initialized
INFO - 2022-07-18 07:59:27 --> Output Class Initialized
INFO - 2022-07-18 07:59:27 --> Security Class Initialized
DEBUG - 2022-07-18 07:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:59:27 --> Input Class Initialized
INFO - 2022-07-18 07:59:27 --> Language Class Initialized
INFO - 2022-07-18 07:59:27 --> Loader Class Initialized
INFO - 2022-07-18 07:59:27 --> Helper loaded: url_helper
INFO - 2022-07-18 07:59:27 --> Helper loaded: file_helper
INFO - 2022-07-18 07:59:27 --> Database Driver Class Initialized
INFO - 2022-07-18 07:59:27 --> Email Class Initialized
DEBUG - 2022-07-18 07:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:59:27 --> Controller Class Initialized
INFO - 2022-07-18 07:59:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:59:27 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 13:29:27 --> Final output sent to browser
DEBUG - 2022-07-18 13:29:27 --> Total execution time: 0.0431
INFO - 2022-07-18 07:59:29 --> Config Class Initialized
INFO - 2022-07-18 07:59:29 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:59:29 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:59:29 --> Utf8 Class Initialized
INFO - 2022-07-18 07:59:29 --> URI Class Initialized
INFO - 2022-07-18 07:59:29 --> Router Class Initialized
INFO - 2022-07-18 07:59:29 --> Output Class Initialized
INFO - 2022-07-18 07:59:29 --> Security Class Initialized
DEBUG - 2022-07-18 07:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:59:29 --> Input Class Initialized
INFO - 2022-07-18 07:59:29 --> Language Class Initialized
INFO - 2022-07-18 07:59:29 --> Loader Class Initialized
INFO - 2022-07-18 07:59:29 --> Helper loaded: url_helper
INFO - 2022-07-18 07:59:29 --> Helper loaded: file_helper
INFO - 2022-07-18 07:59:29 --> Database Driver Class Initialized
INFO - 2022-07-18 07:59:29 --> Email Class Initialized
DEBUG - 2022-07-18 07:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:59:29 --> Controller Class Initialized
INFO - 2022-07-18 07:59:29 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:59:29 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:59:29 --> Final output sent to browser
DEBUG - 2022-07-18 07:59:29 --> Total execution time: 0.0280
INFO - 2022-07-18 07:59:30 --> Config Class Initialized
INFO - 2022-07-18 07:59:30 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:59:30 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:59:30 --> Utf8 Class Initialized
INFO - 2022-07-18 07:59:30 --> URI Class Initialized
INFO - 2022-07-18 07:59:30 --> Router Class Initialized
INFO - 2022-07-18 07:59:30 --> Output Class Initialized
INFO - 2022-07-18 07:59:30 --> Security Class Initialized
DEBUG - 2022-07-18 07:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:59:30 --> Input Class Initialized
INFO - 2022-07-18 07:59:30 --> Language Class Initialized
INFO - 2022-07-18 07:59:30 --> Loader Class Initialized
INFO - 2022-07-18 07:59:30 --> Helper loaded: url_helper
INFO - 2022-07-18 07:59:30 --> Helper loaded: file_helper
INFO - 2022-07-18 07:59:30 --> Database Driver Class Initialized
INFO - 2022-07-18 07:59:30 --> Email Class Initialized
DEBUG - 2022-07-18 07:59:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:59:30 --> Controller Class Initialized
INFO - 2022-07-18 07:59:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:59:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 13:29:30 --> Final output sent to browser
DEBUG - 2022-07-18 13:29:30 --> Total execution time: 0.0298
INFO - 2022-07-18 07:59:33 --> Config Class Initialized
INFO - 2022-07-18 07:59:33 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:59:33 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:59:33 --> Utf8 Class Initialized
INFO - 2022-07-18 07:59:33 --> URI Class Initialized
INFO - 2022-07-18 07:59:33 --> Router Class Initialized
INFO - 2022-07-18 07:59:33 --> Output Class Initialized
INFO - 2022-07-18 07:59:33 --> Security Class Initialized
DEBUG - 2022-07-18 07:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:59:33 --> Input Class Initialized
INFO - 2022-07-18 07:59:33 --> Language Class Initialized
INFO - 2022-07-18 07:59:33 --> Loader Class Initialized
INFO - 2022-07-18 07:59:33 --> Helper loaded: url_helper
INFO - 2022-07-18 07:59:33 --> Helper loaded: file_helper
INFO - 2022-07-18 07:59:33 --> Database Driver Class Initialized
INFO - 2022-07-18 07:59:33 --> Email Class Initialized
DEBUG - 2022-07-18 07:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:59:33 --> Controller Class Initialized
INFO - 2022-07-18 07:59:33 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:59:33 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:59:33 --> Final output sent to browser
DEBUG - 2022-07-18 07:59:33 --> Total execution time: 0.0302
INFO - 2022-07-18 07:59:33 --> Config Class Initialized
INFO - 2022-07-18 07:59:33 --> Hooks Class Initialized
DEBUG - 2022-07-18 07:59:33 --> UTF-8 Support Enabled
INFO - 2022-07-18 07:59:33 --> Utf8 Class Initialized
INFO - 2022-07-18 07:59:33 --> URI Class Initialized
INFO - 2022-07-18 07:59:33 --> Router Class Initialized
INFO - 2022-07-18 07:59:33 --> Output Class Initialized
INFO - 2022-07-18 07:59:33 --> Security Class Initialized
DEBUG - 2022-07-18 07:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 07:59:33 --> Input Class Initialized
INFO - 2022-07-18 07:59:33 --> Language Class Initialized
INFO - 2022-07-18 07:59:33 --> Loader Class Initialized
INFO - 2022-07-18 07:59:33 --> Helper loaded: url_helper
INFO - 2022-07-18 07:59:33 --> Helper loaded: file_helper
INFO - 2022-07-18 07:59:33 --> Database Driver Class Initialized
INFO - 2022-07-18 07:59:33 --> Email Class Initialized
DEBUG - 2022-07-18 07:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 07:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 07:59:33 --> Controller Class Initialized
INFO - 2022-07-18 07:59:33 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 07:59:33 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 07:59:33 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-18 07:59:33 --> Final output sent to browser
DEBUG - 2022-07-18 07:59:33 --> Total execution time: 0.0208
INFO - 2022-07-18 08:02:38 --> Config Class Initialized
INFO - 2022-07-18 08:02:38 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:02:38 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:02:38 --> Utf8 Class Initialized
INFO - 2022-07-18 08:02:38 --> URI Class Initialized
INFO - 2022-07-18 08:02:38 --> Router Class Initialized
INFO - 2022-07-18 08:02:38 --> Output Class Initialized
INFO - 2022-07-18 08:02:38 --> Security Class Initialized
DEBUG - 2022-07-18 08:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:02:38 --> Input Class Initialized
INFO - 2022-07-18 08:02:38 --> Language Class Initialized
INFO - 2022-07-18 08:02:38 --> Loader Class Initialized
INFO - 2022-07-18 08:02:38 --> Helper loaded: url_helper
INFO - 2022-07-18 08:02:38 --> Helper loaded: file_helper
INFO - 2022-07-18 08:02:38 --> Database Driver Class Initialized
INFO - 2022-07-18 08:02:38 --> Email Class Initialized
DEBUG - 2022-07-18 08:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:02:38 --> Controller Class Initialized
INFO - 2022-07-18 08:02:38 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:02:38 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:02:38 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/login_1.php
INFO - 2022-07-18 08:02:38 --> Final output sent to browser
DEBUG - 2022-07-18 08:02:38 --> Total execution time: 0.0698
INFO - 2022-07-18 08:08:41 --> Config Class Initialized
INFO - 2022-07-18 08:08:41 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:08:41 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:08:41 --> Utf8 Class Initialized
INFO - 2022-07-18 08:08:41 --> URI Class Initialized
INFO - 2022-07-18 08:08:41 --> Router Class Initialized
INFO - 2022-07-18 08:08:41 --> Output Class Initialized
INFO - 2022-07-18 08:08:41 --> Security Class Initialized
DEBUG - 2022-07-18 08:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:08:41 --> Input Class Initialized
INFO - 2022-07-18 08:08:41 --> Language Class Initialized
INFO - 2022-07-18 08:08:41 --> Loader Class Initialized
INFO - 2022-07-18 08:08:41 --> Helper loaded: url_helper
INFO - 2022-07-18 08:08:41 --> Helper loaded: file_helper
INFO - 2022-07-18 08:08:41 --> Database Driver Class Initialized
INFO - 2022-07-18 08:08:41 --> Email Class Initialized
DEBUG - 2022-07-18 08:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:08:41 --> Controller Class Initialized
INFO - 2022-07-18 08:08:41 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:08:41 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:08:41 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/login_1.php
INFO - 2022-07-18 08:08:41 --> Final output sent to browser
DEBUG - 2022-07-18 08:08:41 --> Total execution time: 0.1356
INFO - 2022-07-18 08:08:41 --> Config Class Initialized
INFO - 2022-07-18 08:08:41 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:08:41 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:08:41 --> Utf8 Class Initialized
INFO - 2022-07-18 08:08:41 --> URI Class Initialized
INFO - 2022-07-18 08:08:41 --> Router Class Initialized
INFO - 2022-07-18 08:08:41 --> Output Class Initialized
INFO - 2022-07-18 08:08:41 --> Security Class Initialized
DEBUG - 2022-07-18 08:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:08:41 --> Input Class Initialized
INFO - 2022-07-18 08:08:41 --> Language Class Initialized
ERROR - 2022-07-18 08:08:41 --> 404 Page Not Found: Tokenctrl/pic2.png
INFO - 2022-07-18 08:08:41 --> Config Class Initialized
INFO - 2022-07-18 08:08:41 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:08:41 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:08:41 --> Utf8 Class Initialized
INFO - 2022-07-18 08:08:41 --> URI Class Initialized
INFO - 2022-07-18 08:08:41 --> Router Class Initialized
INFO - 2022-07-18 08:08:41 --> Output Class Initialized
INFO - 2022-07-18 08:08:41 --> Security Class Initialized
DEBUG - 2022-07-18 08:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:08:41 --> Input Class Initialized
INFO - 2022-07-18 08:08:41 --> Language Class Initialized
ERROR - 2022-07-18 08:08:41 --> 404 Page Not Found: Tokenctrl/ya.jpg
INFO - 2022-07-18 08:08:58 --> Config Class Initialized
INFO - 2022-07-18 08:08:58 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:08:58 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:08:58 --> Utf8 Class Initialized
INFO - 2022-07-18 08:08:58 --> URI Class Initialized
INFO - 2022-07-18 08:08:58 --> Router Class Initialized
INFO - 2022-07-18 08:08:58 --> Output Class Initialized
INFO - 2022-07-18 08:08:58 --> Security Class Initialized
DEBUG - 2022-07-18 08:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:08:58 --> Input Class Initialized
INFO - 2022-07-18 08:08:58 --> Language Class Initialized
INFO - 2022-07-18 08:08:58 --> Loader Class Initialized
INFO - 2022-07-18 08:08:58 --> Helper loaded: url_helper
INFO - 2022-07-18 08:08:58 --> Helper loaded: file_helper
INFO - 2022-07-18 08:08:58 --> Database Driver Class Initialized
INFO - 2022-07-18 08:08:58 --> Email Class Initialized
DEBUG - 2022-07-18 08:08:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:08:58 --> Controller Class Initialized
INFO - 2022-07-18 08:08:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:08:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:08:58 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/login_1.php
INFO - 2022-07-18 08:08:58 --> Final output sent to browser
DEBUG - 2022-07-18 08:08:58 --> Total execution time: 0.1368
INFO - 2022-07-18 08:08:59 --> Config Class Initialized
INFO - 2022-07-18 08:08:59 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:08:59 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:08:59 --> Utf8 Class Initialized
INFO - 2022-07-18 08:08:59 --> URI Class Initialized
INFO - 2022-07-18 08:08:59 --> Router Class Initialized
INFO - 2022-07-18 08:08:59 --> Output Class Initialized
INFO - 2022-07-18 08:08:59 --> Security Class Initialized
DEBUG - 2022-07-18 08:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:08:59 --> Input Class Initialized
INFO - 2022-07-18 08:08:59 --> Language Class Initialized
ERROR - 2022-07-18 08:08:59 --> 404 Page Not Found: Tokenctrl/ya.jpg
INFO - 2022-07-18 08:10:00 --> Config Class Initialized
INFO - 2022-07-18 08:10:00 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:10:00 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:10:00 --> Utf8 Class Initialized
INFO - 2022-07-18 08:10:00 --> URI Class Initialized
INFO - 2022-07-18 08:10:00 --> Router Class Initialized
INFO - 2022-07-18 08:10:00 --> Output Class Initialized
INFO - 2022-07-18 08:10:00 --> Security Class Initialized
DEBUG - 2022-07-18 08:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:10:00 --> Input Class Initialized
INFO - 2022-07-18 08:10:00 --> Language Class Initialized
INFO - 2022-07-18 08:10:00 --> Loader Class Initialized
INFO - 2022-07-18 08:10:00 --> Helper loaded: url_helper
INFO - 2022-07-18 08:10:00 --> Helper loaded: file_helper
INFO - 2022-07-18 08:10:00 --> Database Driver Class Initialized
INFO - 2022-07-18 08:10:00 --> Email Class Initialized
DEBUG - 2022-07-18 08:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:10:00 --> Controller Class Initialized
INFO - 2022-07-18 08:10:00 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:10:00 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:10:00 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/login_1.php
INFO - 2022-07-18 08:10:00 --> Final output sent to browser
DEBUG - 2022-07-18 08:10:00 --> Total execution time: 0.0265
INFO - 2022-07-18 08:10:00 --> Config Class Initialized
INFO - 2022-07-18 08:10:00 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:10:00 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:10:00 --> Utf8 Class Initialized
INFO - 2022-07-18 08:10:00 --> URI Class Initialized
INFO - 2022-07-18 08:10:00 --> Router Class Initialized
INFO - 2022-07-18 08:10:00 --> Output Class Initialized
INFO - 2022-07-18 08:10:00 --> Security Class Initialized
DEBUG - 2022-07-18 08:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:10:00 --> Input Class Initialized
INFO - 2022-07-18 08:10:00 --> Language Class Initialized
ERROR - 2022-07-18 08:10:00 --> 404 Page Not Found: Tokenctrl/ya.jpg
INFO - 2022-07-18 08:10:48 --> Config Class Initialized
INFO - 2022-07-18 08:10:48 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:10:48 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:10:48 --> Utf8 Class Initialized
INFO - 2022-07-18 08:10:48 --> URI Class Initialized
INFO - 2022-07-18 08:10:48 --> Router Class Initialized
INFO - 2022-07-18 08:10:48 --> Output Class Initialized
INFO - 2022-07-18 08:10:48 --> Security Class Initialized
DEBUG - 2022-07-18 08:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:10:48 --> Input Class Initialized
INFO - 2022-07-18 08:10:48 --> Language Class Initialized
INFO - 2022-07-18 08:10:48 --> Loader Class Initialized
INFO - 2022-07-18 08:10:48 --> Helper loaded: url_helper
INFO - 2022-07-18 08:10:48 --> Helper loaded: file_helper
INFO - 2022-07-18 08:10:48 --> Database Driver Class Initialized
INFO - 2022-07-18 08:10:48 --> Email Class Initialized
DEBUG - 2022-07-18 08:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:10:48 --> Controller Class Initialized
INFO - 2022-07-18 08:10:48 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:10:48 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:10:48 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/login_1.php
INFO - 2022-07-18 08:10:48 --> Final output sent to browser
DEBUG - 2022-07-18 08:10:48 --> Total execution time: 0.1261
INFO - 2022-07-18 08:10:48 --> Config Class Initialized
INFO - 2022-07-18 08:10:48 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:10:48 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:10:48 --> Utf8 Class Initialized
INFO - 2022-07-18 08:10:48 --> URI Class Initialized
INFO - 2022-07-18 08:10:48 --> Router Class Initialized
INFO - 2022-07-18 08:10:48 --> Output Class Initialized
INFO - 2022-07-18 08:10:48 --> Security Class Initialized
DEBUG - 2022-07-18 08:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:10:48 --> Input Class Initialized
INFO - 2022-07-18 08:10:48 --> Language Class Initialized
ERROR - 2022-07-18 08:10:48 --> 404 Page Not Found: Tokenctrl/ya.jpg
INFO - 2022-07-18 08:10:56 --> Config Class Initialized
INFO - 2022-07-18 08:10:56 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:10:56 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:10:56 --> Utf8 Class Initialized
INFO - 2022-07-18 08:10:56 --> URI Class Initialized
INFO - 2022-07-18 08:10:56 --> Router Class Initialized
INFO - 2022-07-18 08:10:56 --> Output Class Initialized
INFO - 2022-07-18 08:10:56 --> Security Class Initialized
DEBUG - 2022-07-18 08:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:10:56 --> Input Class Initialized
INFO - 2022-07-18 08:10:56 --> Language Class Initialized
INFO - 2022-07-18 08:10:56 --> Loader Class Initialized
INFO - 2022-07-18 08:10:56 --> Helper loaded: url_helper
INFO - 2022-07-18 08:10:56 --> Helper loaded: file_helper
INFO - 2022-07-18 08:10:56 --> Database Driver Class Initialized
INFO - 2022-07-18 08:10:56 --> Email Class Initialized
DEBUG - 2022-07-18 08:10:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:10:56 --> Controller Class Initialized
INFO - 2022-07-18 08:10:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:10:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:10:56 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/login_1.php
INFO - 2022-07-18 08:10:56 --> Final output sent to browser
DEBUG - 2022-07-18 08:10:56 --> Total execution time: 0.2356
INFO - 2022-07-18 08:10:56 --> Config Class Initialized
INFO - 2022-07-18 08:10:56 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:10:56 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:10:56 --> Utf8 Class Initialized
INFO - 2022-07-18 08:10:56 --> URI Class Initialized
INFO - 2022-07-18 08:10:56 --> Router Class Initialized
INFO - 2022-07-18 08:10:56 --> Output Class Initialized
INFO - 2022-07-18 08:10:56 --> Security Class Initialized
DEBUG - 2022-07-18 08:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:10:56 --> Input Class Initialized
INFO - 2022-07-18 08:10:56 --> Language Class Initialized
ERROR - 2022-07-18 08:10:56 --> 404 Page Not Found: Tokenctrl/ya.jpg
INFO - 2022-07-18 08:11:12 --> Config Class Initialized
INFO - 2022-07-18 08:11:12 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:11:12 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:11:12 --> Utf8 Class Initialized
INFO - 2022-07-18 08:11:12 --> URI Class Initialized
INFO - 2022-07-18 08:11:12 --> Router Class Initialized
INFO - 2022-07-18 08:11:12 --> Output Class Initialized
INFO - 2022-07-18 08:11:12 --> Security Class Initialized
DEBUG - 2022-07-18 08:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:11:12 --> Input Class Initialized
INFO - 2022-07-18 08:11:12 --> Language Class Initialized
INFO - 2022-07-18 08:11:12 --> Loader Class Initialized
INFO - 2022-07-18 08:11:12 --> Helper loaded: url_helper
INFO - 2022-07-18 08:11:12 --> Helper loaded: file_helper
INFO - 2022-07-18 08:11:12 --> Database Driver Class Initialized
INFO - 2022-07-18 08:11:12 --> Email Class Initialized
DEBUG - 2022-07-18 08:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:11:12 --> Controller Class Initialized
INFO - 2022-07-18 08:11:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:11:12 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:11:12 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/login_1.php
INFO - 2022-07-18 08:11:12 --> Final output sent to browser
DEBUG - 2022-07-18 08:11:12 --> Total execution time: 0.0977
INFO - 2022-07-18 08:11:13 --> Config Class Initialized
INFO - 2022-07-18 08:11:13 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:11:13 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:11:13 --> Utf8 Class Initialized
INFO - 2022-07-18 08:11:13 --> URI Class Initialized
INFO - 2022-07-18 08:11:13 --> Router Class Initialized
INFO - 2022-07-18 08:11:13 --> Output Class Initialized
INFO - 2022-07-18 08:11:13 --> Security Class Initialized
DEBUG - 2022-07-18 08:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:11:13 --> Input Class Initialized
INFO - 2022-07-18 08:11:13 --> Language Class Initialized
ERROR - 2022-07-18 08:11:13 --> 404 Page Not Found: Tokenctrl/ya.jpg
INFO - 2022-07-18 08:32:05 --> Config Class Initialized
INFO - 2022-07-18 08:32:05 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:32:05 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:32:05 --> Utf8 Class Initialized
INFO - 2022-07-18 08:32:05 --> URI Class Initialized
INFO - 2022-07-18 08:32:05 --> Router Class Initialized
INFO - 2022-07-18 08:32:05 --> Output Class Initialized
INFO - 2022-07-18 08:32:05 --> Security Class Initialized
DEBUG - 2022-07-18 08:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:32:05 --> Input Class Initialized
INFO - 2022-07-18 08:32:05 --> Language Class Initialized
INFO - 2022-07-18 08:32:05 --> Loader Class Initialized
INFO - 2022-07-18 08:32:05 --> Helper loaded: url_helper
INFO - 2022-07-18 08:32:05 --> Helper loaded: file_helper
INFO - 2022-07-18 08:32:05 --> Database Driver Class Initialized
INFO - 2022-07-18 08:32:05 --> Email Class Initialized
DEBUG - 2022-07-18 08:32:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:32:05 --> Controller Class Initialized
INFO - 2022-07-18 08:32:05 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:32:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 08:32:05 --> Severity: Notice --> Undefined variable: password C:\wamp64\www\qr\application\models\Tokenmodel.php 299
INFO - 2022-07-18 08:32:05 --> Final output sent to browser
DEBUG - 2022-07-18 08:32:05 --> Total execution time: 0.0816
INFO - 2022-07-18 08:32:41 --> Config Class Initialized
INFO - 2022-07-18 08:32:41 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:32:41 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:32:41 --> Utf8 Class Initialized
INFO - 2022-07-18 08:32:41 --> URI Class Initialized
INFO - 2022-07-18 08:32:41 --> Router Class Initialized
INFO - 2022-07-18 08:32:41 --> Output Class Initialized
INFO - 2022-07-18 08:32:41 --> Security Class Initialized
DEBUG - 2022-07-18 08:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:32:41 --> Input Class Initialized
INFO - 2022-07-18 08:32:41 --> Language Class Initialized
INFO - 2022-07-18 08:32:41 --> Loader Class Initialized
INFO - 2022-07-18 08:32:41 --> Helper loaded: url_helper
INFO - 2022-07-18 08:32:41 --> Helper loaded: file_helper
INFO - 2022-07-18 08:32:41 --> Database Driver Class Initialized
INFO - 2022-07-18 08:32:41 --> Email Class Initialized
DEBUG - 2022-07-18 08:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:32:41 --> Controller Class Initialized
INFO - 2022-07-18 08:32:41 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:32:41 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:32:41 --> Final output sent to browser
DEBUG - 2022-07-18 08:32:41 --> Total execution time: 0.1382
INFO - 2022-07-18 08:39:53 --> Config Class Initialized
INFO - 2022-07-18 08:39:53 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:39:53 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:39:53 --> Utf8 Class Initialized
INFO - 2022-07-18 08:39:53 --> URI Class Initialized
INFO - 2022-07-18 08:39:53 --> Router Class Initialized
INFO - 2022-07-18 08:39:53 --> Output Class Initialized
INFO - 2022-07-18 08:39:53 --> Security Class Initialized
DEBUG - 2022-07-18 08:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:39:53 --> Input Class Initialized
INFO - 2022-07-18 08:39:53 --> Language Class Initialized
INFO - 2022-07-18 08:39:53 --> Loader Class Initialized
INFO - 2022-07-18 08:39:53 --> Helper loaded: url_helper
INFO - 2022-07-18 08:39:53 --> Helper loaded: file_helper
INFO - 2022-07-18 08:39:53 --> Database Driver Class Initialized
INFO - 2022-07-18 08:39:53 --> Email Class Initialized
DEBUG - 2022-07-18 08:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:39:53 --> Controller Class Initialized
INFO - 2022-07-18 08:39:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:39:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 08:39:53 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\wamp64\www\qr\application\controllers\Tokenctrl.php 567
INFO - 2022-07-18 08:39:55 --> Config Class Initialized
INFO - 2022-07-18 08:39:55 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:39:55 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:39:55 --> Utf8 Class Initialized
INFO - 2022-07-18 08:39:55 --> URI Class Initialized
INFO - 2022-07-18 08:39:55 --> Router Class Initialized
INFO - 2022-07-18 08:39:55 --> Output Class Initialized
INFO - 2022-07-18 08:39:55 --> Security Class Initialized
DEBUG - 2022-07-18 08:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:39:55 --> Input Class Initialized
INFO - 2022-07-18 08:39:55 --> Language Class Initialized
INFO - 2022-07-18 08:39:55 --> Loader Class Initialized
INFO - 2022-07-18 08:39:55 --> Helper loaded: url_helper
INFO - 2022-07-18 08:39:55 --> Helper loaded: file_helper
INFO - 2022-07-18 08:39:55 --> Database Driver Class Initialized
INFO - 2022-07-18 08:39:55 --> Email Class Initialized
DEBUG - 2022-07-18 08:39:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:39:55 --> Controller Class Initialized
INFO - 2022-07-18 08:39:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:39:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 08:39:55 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\wamp64\www\qr\application\controllers\Tokenctrl.php 567
INFO - 2022-07-18 08:40:49 --> Config Class Initialized
INFO - 2022-07-18 08:40:49 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:40:49 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:40:49 --> Utf8 Class Initialized
INFO - 2022-07-18 08:40:49 --> URI Class Initialized
INFO - 2022-07-18 08:40:49 --> Router Class Initialized
INFO - 2022-07-18 08:40:49 --> Output Class Initialized
INFO - 2022-07-18 08:40:49 --> Security Class Initialized
DEBUG - 2022-07-18 08:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:40:49 --> Input Class Initialized
INFO - 2022-07-18 08:40:49 --> Language Class Initialized
INFO - 2022-07-18 08:40:49 --> Loader Class Initialized
INFO - 2022-07-18 08:40:49 --> Helper loaded: url_helper
INFO - 2022-07-18 08:40:49 --> Helper loaded: file_helper
INFO - 2022-07-18 08:40:49 --> Database Driver Class Initialized
INFO - 2022-07-18 08:40:49 --> Email Class Initialized
DEBUG - 2022-07-18 08:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:40:49 --> Controller Class Initialized
INFO - 2022-07-18 08:40:49 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:40:49 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:40:49 --> Final output sent to browser
DEBUG - 2022-07-18 08:40:49 --> Total execution time: 0.0442
INFO - 2022-07-18 08:40:50 --> Config Class Initialized
INFO - 2022-07-18 08:40:50 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:40:50 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:40:50 --> Utf8 Class Initialized
INFO - 2022-07-18 08:40:50 --> URI Class Initialized
INFO - 2022-07-18 08:40:50 --> Router Class Initialized
INFO - 2022-07-18 08:40:50 --> Output Class Initialized
INFO - 2022-07-18 08:40:50 --> Security Class Initialized
DEBUG - 2022-07-18 08:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:40:50 --> Input Class Initialized
INFO - 2022-07-18 08:40:50 --> Language Class Initialized
INFO - 2022-07-18 08:40:50 --> Loader Class Initialized
INFO - 2022-07-18 08:40:50 --> Helper loaded: url_helper
INFO - 2022-07-18 08:40:50 --> Helper loaded: file_helper
INFO - 2022-07-18 08:40:50 --> Database Driver Class Initialized
INFO - 2022-07-18 08:40:50 --> Email Class Initialized
DEBUG - 2022-07-18 08:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:40:50 --> Controller Class Initialized
INFO - 2022-07-18 08:40:50 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:40:50 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:40:50 --> Final output sent to browser
DEBUG - 2022-07-18 08:40:50 --> Total execution time: 0.0173
INFO - 2022-07-18 08:41:11 --> Config Class Initialized
INFO - 2022-07-18 08:41:11 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:11 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:11 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:11 --> URI Class Initialized
INFO - 2022-07-18 08:41:11 --> Router Class Initialized
INFO - 2022-07-18 08:41:11 --> Output Class Initialized
INFO - 2022-07-18 08:41:11 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:11 --> Input Class Initialized
INFO - 2022-07-18 08:41:11 --> Language Class Initialized
INFO - 2022-07-18 08:41:11 --> Loader Class Initialized
INFO - 2022-07-18 08:41:11 --> Helper loaded: url_helper
INFO - 2022-07-18 08:41:11 --> Helper loaded: file_helper
INFO - 2022-07-18 08:41:11 --> Database Driver Class Initialized
INFO - 2022-07-18 08:41:11 --> Email Class Initialized
DEBUG - 2022-07-18 08:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:41:11 --> Controller Class Initialized
INFO - 2022-07-18 08:41:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:41:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:41:11 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/login_1.php
INFO - 2022-07-18 08:41:11 --> Final output sent to browser
DEBUG - 2022-07-18 08:41:11 --> Total execution time: 0.0508
INFO - 2022-07-18 08:41:11 --> Config Class Initialized
INFO - 2022-07-18 08:41:11 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:11 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:11 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:11 --> URI Class Initialized
INFO - 2022-07-18 08:41:11 --> Router Class Initialized
INFO - 2022-07-18 08:41:11 --> Output Class Initialized
INFO - 2022-07-18 08:41:11 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:11 --> Input Class Initialized
INFO - 2022-07-18 08:41:11 --> Language Class Initialized
ERROR - 2022-07-18 08:41:11 --> 404 Page Not Found: Tokenctrl/ya.jpg
INFO - 2022-07-18 08:41:12 --> Config Class Initialized
INFO - 2022-07-18 08:41:12 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:12 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:12 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:12 --> URI Class Initialized
INFO - 2022-07-18 08:41:12 --> Router Class Initialized
INFO - 2022-07-18 08:41:12 --> Output Class Initialized
INFO - 2022-07-18 08:41:12 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:12 --> Input Class Initialized
INFO - 2022-07-18 08:41:12 --> Language Class Initialized
INFO - 2022-07-18 08:41:12 --> Loader Class Initialized
INFO - 2022-07-18 08:41:12 --> Helper loaded: url_helper
INFO - 2022-07-18 08:41:12 --> Helper loaded: file_helper
INFO - 2022-07-18 08:41:12 --> Database Driver Class Initialized
INFO - 2022-07-18 08:41:12 --> Email Class Initialized
DEBUG - 2022-07-18 08:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:41:12 --> Controller Class Initialized
INFO - 2022-07-18 08:41:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:41:12 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:41:12 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/login_1.php
INFO - 2022-07-18 08:41:12 --> Final output sent to browser
DEBUG - 2022-07-18 08:41:12 --> Total execution time: 0.0362
INFO - 2022-07-18 08:41:12 --> Config Class Initialized
INFO - 2022-07-18 08:41:12 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:12 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:12 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:12 --> URI Class Initialized
INFO - 2022-07-18 08:41:12 --> Router Class Initialized
INFO - 2022-07-18 08:41:12 --> Output Class Initialized
INFO - 2022-07-18 08:41:12 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:12 --> Input Class Initialized
INFO - 2022-07-18 08:41:12 --> Language Class Initialized
ERROR - 2022-07-18 08:41:12 --> 404 Page Not Found: Tokenctrl/ya.jpg
INFO - 2022-07-18 08:41:13 --> Config Class Initialized
INFO - 2022-07-18 08:41:13 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:13 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:13 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:13 --> URI Class Initialized
INFO - 2022-07-18 08:41:13 --> Router Class Initialized
INFO - 2022-07-18 08:41:13 --> Output Class Initialized
INFO - 2022-07-18 08:41:13 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:13 --> Input Class Initialized
INFO - 2022-07-18 08:41:13 --> Language Class Initialized
INFO - 2022-07-18 08:41:13 --> Loader Class Initialized
INFO - 2022-07-18 08:41:13 --> Helper loaded: url_helper
INFO - 2022-07-18 08:41:13 --> Helper loaded: file_helper
INFO - 2022-07-18 08:41:13 --> Database Driver Class Initialized
INFO - 2022-07-18 08:41:13 --> Email Class Initialized
DEBUG - 2022-07-18 08:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:41:13 --> Controller Class Initialized
INFO - 2022-07-18 08:41:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:41:13 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:41:13 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/login_1.php
INFO - 2022-07-18 08:41:13 --> Final output sent to browser
DEBUG - 2022-07-18 08:41:13 --> Total execution time: 0.0179
INFO - 2022-07-18 08:41:13 --> Config Class Initialized
INFO - 2022-07-18 08:41:13 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:13 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:13 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:13 --> URI Class Initialized
INFO - 2022-07-18 08:41:13 --> Router Class Initialized
INFO - 2022-07-18 08:41:13 --> Output Class Initialized
INFO - 2022-07-18 08:41:13 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:13 --> Input Class Initialized
INFO - 2022-07-18 08:41:13 --> Language Class Initialized
ERROR - 2022-07-18 08:41:13 --> 404 Page Not Found: Tokenctrl/ya.jpg
INFO - 2022-07-18 08:41:13 --> Config Class Initialized
INFO - 2022-07-18 08:41:13 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:13 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:13 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:13 --> URI Class Initialized
INFO - 2022-07-18 08:41:13 --> Router Class Initialized
INFO - 2022-07-18 08:41:13 --> Output Class Initialized
INFO - 2022-07-18 08:41:13 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:13 --> Input Class Initialized
INFO - 2022-07-18 08:41:13 --> Language Class Initialized
INFO - 2022-07-18 08:41:13 --> Loader Class Initialized
INFO - 2022-07-18 08:41:13 --> Helper loaded: url_helper
INFO - 2022-07-18 08:41:13 --> Helper loaded: file_helper
INFO - 2022-07-18 08:41:13 --> Database Driver Class Initialized
INFO - 2022-07-18 08:41:13 --> Email Class Initialized
DEBUG - 2022-07-18 08:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:41:13 --> Controller Class Initialized
INFO - 2022-07-18 08:41:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:41:13 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:41:13 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/login_1.php
INFO - 2022-07-18 08:41:13 --> Final output sent to browser
DEBUG - 2022-07-18 08:41:13 --> Total execution time: 0.0169
INFO - 2022-07-18 08:41:14 --> Config Class Initialized
INFO - 2022-07-18 08:41:14 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:14 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:14 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:14 --> URI Class Initialized
INFO - 2022-07-18 08:41:14 --> Router Class Initialized
INFO - 2022-07-18 08:41:14 --> Output Class Initialized
INFO - 2022-07-18 08:41:14 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:14 --> Input Class Initialized
INFO - 2022-07-18 08:41:14 --> Language Class Initialized
ERROR - 2022-07-18 08:41:14 --> 404 Page Not Found: Tokenctrl/ya.jpg
INFO - 2022-07-18 08:41:14 --> Config Class Initialized
INFO - 2022-07-18 08:41:14 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:14 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:14 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:14 --> URI Class Initialized
INFO - 2022-07-18 08:41:14 --> Router Class Initialized
INFO - 2022-07-18 08:41:14 --> Output Class Initialized
INFO - 2022-07-18 08:41:14 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:14 --> Input Class Initialized
INFO - 2022-07-18 08:41:14 --> Language Class Initialized
INFO - 2022-07-18 08:41:14 --> Loader Class Initialized
INFO - 2022-07-18 08:41:14 --> Helper loaded: url_helper
INFO - 2022-07-18 08:41:14 --> Helper loaded: file_helper
INFO - 2022-07-18 08:41:14 --> Database Driver Class Initialized
INFO - 2022-07-18 08:41:14 --> Email Class Initialized
DEBUG - 2022-07-18 08:41:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:41:14 --> Controller Class Initialized
INFO - 2022-07-18 08:41:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:41:14 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:41:14 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/login_1.php
INFO - 2022-07-18 08:41:14 --> Final output sent to browser
DEBUG - 2022-07-18 08:41:14 --> Total execution time: 0.0389
INFO - 2022-07-18 08:41:14 --> Config Class Initialized
INFO - 2022-07-18 08:41:14 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:14 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:14 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:14 --> URI Class Initialized
INFO - 2022-07-18 08:41:14 --> Router Class Initialized
INFO - 2022-07-18 08:41:14 --> Output Class Initialized
INFO - 2022-07-18 08:41:14 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:14 --> Input Class Initialized
INFO - 2022-07-18 08:41:14 --> Language Class Initialized
INFO - 2022-07-18 08:41:14 --> Loader Class Initialized
INFO - 2022-07-18 08:41:14 --> Helper loaded: url_helper
INFO - 2022-07-18 08:41:14 --> Helper loaded: file_helper
INFO - 2022-07-18 08:41:14 --> Database Driver Class Initialized
INFO - 2022-07-18 08:41:14 --> Email Class Initialized
DEBUG - 2022-07-18 08:41:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:41:14 --> Controller Class Initialized
INFO - 2022-07-18 08:41:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:41:14 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:41:14 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/login_1.php
INFO - 2022-07-18 08:41:14 --> Final output sent to browser
DEBUG - 2022-07-18 08:41:14 --> Total execution time: 0.0192
INFO - 2022-07-18 08:41:14 --> Config Class Initialized
INFO - 2022-07-18 08:41:14 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:14 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:14 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:14 --> URI Class Initialized
INFO - 2022-07-18 08:41:14 --> Router Class Initialized
INFO - 2022-07-18 08:41:14 --> Output Class Initialized
INFO - 2022-07-18 08:41:14 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:14 --> Input Class Initialized
INFO - 2022-07-18 08:41:14 --> Language Class Initialized
ERROR - 2022-07-18 08:41:14 --> 404 Page Not Found: Tokenctrl/ya.jpg
INFO - 2022-07-18 08:41:14 --> Config Class Initialized
INFO - 2022-07-18 08:41:14 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:14 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:14 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:14 --> URI Class Initialized
INFO - 2022-07-18 08:41:14 --> Router Class Initialized
INFO - 2022-07-18 08:41:14 --> Output Class Initialized
INFO - 2022-07-18 08:41:14 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:14 --> Input Class Initialized
INFO - 2022-07-18 08:41:14 --> Language Class Initialized
INFO - 2022-07-18 08:41:14 --> Loader Class Initialized
INFO - 2022-07-18 08:41:14 --> Helper loaded: url_helper
INFO - 2022-07-18 08:41:14 --> Helper loaded: file_helper
INFO - 2022-07-18 08:41:14 --> Database Driver Class Initialized
INFO - 2022-07-18 08:41:14 --> Email Class Initialized
DEBUG - 2022-07-18 08:41:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:41:14 --> Controller Class Initialized
INFO - 2022-07-18 08:41:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:41:14 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:41:14 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/login_1.php
INFO - 2022-07-18 08:41:14 --> Final output sent to browser
DEBUG - 2022-07-18 08:41:14 --> Total execution time: 0.0261
INFO - 2022-07-18 08:41:14 --> Config Class Initialized
INFO - 2022-07-18 08:41:14 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:14 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:14 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:14 --> URI Class Initialized
INFO - 2022-07-18 08:41:14 --> Router Class Initialized
INFO - 2022-07-18 08:41:14 --> Output Class Initialized
INFO - 2022-07-18 08:41:14 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:14 --> Input Class Initialized
INFO - 2022-07-18 08:41:14 --> Language Class Initialized
ERROR - 2022-07-18 08:41:14 --> 404 Page Not Found: Tokenctrl/ya.jpg
INFO - 2022-07-18 08:41:14 --> Config Class Initialized
INFO - 2022-07-18 08:41:14 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:14 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:14 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:14 --> URI Class Initialized
INFO - 2022-07-18 08:41:14 --> Router Class Initialized
INFO - 2022-07-18 08:41:14 --> Output Class Initialized
INFO - 2022-07-18 08:41:14 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:14 --> Input Class Initialized
INFO - 2022-07-18 08:41:14 --> Language Class Initialized
INFO - 2022-07-18 08:41:14 --> Loader Class Initialized
INFO - 2022-07-18 08:41:14 --> Helper loaded: url_helper
INFO - 2022-07-18 08:41:14 --> Helper loaded: file_helper
INFO - 2022-07-18 08:41:14 --> Database Driver Class Initialized
INFO - 2022-07-18 08:41:15 --> Config Class Initialized
INFO - 2022-07-18 08:41:15 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:15 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:15 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:15 --> URI Class Initialized
INFO - 2022-07-18 08:41:15 --> Router Class Initialized
INFO - 2022-07-18 08:41:15 --> Output Class Initialized
INFO - 2022-07-18 08:41:15 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:15 --> Input Class Initialized
INFO - 2022-07-18 08:41:15 --> Language Class Initialized
INFO - 2022-07-18 08:41:15 --> Loader Class Initialized
INFO - 2022-07-18 08:41:15 --> Helper loaded: url_helper
INFO - 2022-07-18 08:41:15 --> Helper loaded: file_helper
INFO - 2022-07-18 08:41:15 --> Database Driver Class Initialized
INFO - 2022-07-18 08:41:15 --> Config Class Initialized
INFO - 2022-07-18 08:41:15 --> Hooks Class Initialized
INFO - 2022-07-18 08:41:15 --> Email Class Initialized
DEBUG - 2022-07-18 08:41:15 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:15 --> Utf8 Class Initialized
DEBUG - 2022-07-18 08:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:41:15 --> Controller Class Initialized
INFO - 2022-07-18 08:41:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:41:15 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:41:15 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/login_1.php
INFO - 2022-07-18 08:41:15 --> Final output sent to browser
DEBUG - 2022-07-18 08:41:15 --> Total execution time: 0.0314
INFO - 2022-07-18 08:41:15 --> URI Class Initialized
INFO - 2022-07-18 08:41:15 --> Router Class Initialized
INFO - 2022-07-18 08:41:15 --> Output Class Initialized
INFO - 2022-07-18 08:41:15 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:15 --> Input Class Initialized
INFO - 2022-07-18 08:41:15 --> Language Class Initialized
INFO - 2022-07-18 08:41:15 --> Config Class Initialized
INFO - 2022-07-18 08:41:15 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:15 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:15 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:15 --> URI Class Initialized
INFO - 2022-07-18 08:41:15 --> Router Class Initialized
INFO - 2022-07-18 08:41:15 --> Output Class Initialized
INFO - 2022-07-18 08:41:15 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:15 --> Input Class Initialized
INFO - 2022-07-18 08:41:15 --> Language Class Initialized
INFO - 2022-07-18 08:41:15 --> Loader Class Initialized
INFO - 2022-07-18 08:41:15 --> Helper loaded: url_helper
INFO - 2022-07-18 08:41:15 --> Helper loaded: file_helper
INFO - 2022-07-18 08:41:15 --> Database Driver Class Initialized
INFO - 2022-07-18 08:41:15 --> Email Class Initialized
INFO - 2022-07-18 08:41:15 --> Email Class Initialized
DEBUG - 2022-07-18 08:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 08:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:41:15 --> Controller Class Initialized
INFO - 2022-07-18 08:41:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:41:15 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:41:15 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/login_1.php
INFO - 2022-07-18 08:41:15 --> Final output sent to browser
DEBUG - 2022-07-18 08:41:15 --> Total execution time: 0.0196
INFO - 2022-07-18 08:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:41:15 --> Controller Class Initialized
INFO - 2022-07-18 08:41:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:41:15 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:41:15 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/login_1.php
INFO - 2022-07-18 08:41:15 --> Final output sent to browser
DEBUG - 2022-07-18 08:41:15 --> Total execution time: 0.1672
INFO - 2022-07-18 08:41:15 --> Loader Class Initialized
INFO - 2022-07-18 08:41:15 --> Helper loaded: url_helper
INFO - 2022-07-18 08:41:15 --> Helper loaded: file_helper
INFO - 2022-07-18 08:41:15 --> Database Driver Class Initialized
INFO - 2022-07-18 08:41:15 --> Email Class Initialized
DEBUG - 2022-07-18 08:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:41:15 --> Controller Class Initialized
INFO - 2022-07-18 08:41:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:41:15 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:41:15 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/login_1.php
INFO - 2022-07-18 08:41:15 --> Final output sent to browser
DEBUG - 2022-07-18 08:41:15 --> Total execution time: 0.2370
INFO - 2022-07-18 08:41:15 --> Config Class Initialized
INFO - 2022-07-18 08:41:15 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:15 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:15 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:15 --> URI Class Initialized
INFO - 2022-07-18 08:41:15 --> Router Class Initialized
INFO - 2022-07-18 08:41:15 --> Output Class Initialized
INFO - 2022-07-18 08:41:15 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:15 --> Input Class Initialized
INFO - 2022-07-18 08:41:15 --> Language Class Initialized
ERROR - 2022-07-18 08:41:15 --> 404 Page Not Found: Tokenctrl/ya.jpg
INFO - 2022-07-18 08:41:15 --> Config Class Initialized
INFO - 2022-07-18 08:41:15 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:15 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:15 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:15 --> URI Class Initialized
INFO - 2022-07-18 08:41:15 --> Router Class Initialized
INFO - 2022-07-18 08:41:15 --> Output Class Initialized
INFO - 2022-07-18 08:41:15 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:15 --> Input Class Initialized
INFO - 2022-07-18 08:41:15 --> Language Class Initialized
INFO - 2022-07-18 08:41:15 --> Loader Class Initialized
INFO - 2022-07-18 08:41:15 --> Helper loaded: url_helper
INFO - 2022-07-18 08:41:15 --> Helper loaded: file_helper
INFO - 2022-07-18 08:41:15 --> Database Driver Class Initialized
INFO - 2022-07-18 08:41:15 --> Email Class Initialized
DEBUG - 2022-07-18 08:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:41:15 --> Controller Class Initialized
INFO - 2022-07-18 08:41:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:41:15 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:41:15 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/login_1.php
INFO - 2022-07-18 08:41:15 --> Final output sent to browser
DEBUG - 2022-07-18 08:41:15 --> Total execution time: 0.0171
INFO - 2022-07-18 08:41:15 --> Config Class Initialized
INFO - 2022-07-18 08:41:15 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:15 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:15 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:15 --> URI Class Initialized
INFO - 2022-07-18 08:41:15 --> Router Class Initialized
INFO - 2022-07-18 08:41:15 --> Output Class Initialized
INFO - 2022-07-18 08:41:15 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:15 --> Input Class Initialized
INFO - 2022-07-18 08:41:15 --> Language Class Initialized
ERROR - 2022-07-18 08:41:15 --> 404 Page Not Found: Tokenctrl/ya.jpg
INFO - 2022-07-18 08:41:15 --> Config Class Initialized
INFO - 2022-07-18 08:41:15 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:15 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:15 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:15 --> URI Class Initialized
INFO - 2022-07-18 08:41:15 --> Router Class Initialized
INFO - 2022-07-18 08:41:15 --> Output Class Initialized
INFO - 2022-07-18 08:41:15 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:15 --> Input Class Initialized
INFO - 2022-07-18 08:41:15 --> Language Class Initialized
INFO - 2022-07-18 08:41:15 --> Loader Class Initialized
INFO - 2022-07-18 08:41:15 --> Helper loaded: url_helper
INFO - 2022-07-18 08:41:15 --> Helper loaded: file_helper
INFO - 2022-07-18 08:41:15 --> Database Driver Class Initialized
INFO - 2022-07-18 08:41:15 --> Email Class Initialized
DEBUG - 2022-07-18 08:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:41:15 --> Controller Class Initialized
INFO - 2022-07-18 08:41:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:41:15 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:41:15 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/login_1.php
INFO - 2022-07-18 08:41:15 --> Final output sent to browser
DEBUG - 2022-07-18 08:41:15 --> Total execution time: 0.0878
INFO - 2022-07-18 08:41:15 --> Config Class Initialized
INFO - 2022-07-18 08:41:15 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:15 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:15 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:15 --> URI Class Initialized
INFO - 2022-07-18 08:41:15 --> Router Class Initialized
INFO - 2022-07-18 08:41:15 --> Output Class Initialized
INFO - 2022-07-18 08:41:15 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:15 --> Input Class Initialized
INFO - 2022-07-18 08:41:15 --> Language Class Initialized
INFO - 2022-07-18 08:41:15 --> Loader Class Initialized
INFO - 2022-07-18 08:41:15 --> Helper loaded: url_helper
INFO - 2022-07-18 08:41:15 --> Helper loaded: file_helper
INFO - 2022-07-18 08:41:15 --> Database Driver Class Initialized
INFO - 2022-07-18 08:41:15 --> Email Class Initialized
DEBUG - 2022-07-18 08:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:41:15 --> Controller Class Initialized
INFO - 2022-07-18 08:41:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:41:15 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:41:15 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/login_1.php
INFO - 2022-07-18 08:41:15 --> Final output sent to browser
DEBUG - 2022-07-18 08:41:15 --> Total execution time: 0.0253
INFO - 2022-07-18 08:41:15 --> Config Class Initialized
INFO - 2022-07-18 08:41:15 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:15 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:15 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:15 --> URI Class Initialized
INFO - 2022-07-18 08:41:15 --> Router Class Initialized
INFO - 2022-07-18 08:41:15 --> Output Class Initialized
INFO - 2022-07-18 08:41:15 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:15 --> Input Class Initialized
INFO - 2022-07-18 08:41:15 --> Language Class Initialized
ERROR - 2022-07-18 08:41:15 --> 404 Page Not Found: Tokenctrl/ya.jpg
INFO - 2022-07-18 08:41:16 --> Config Class Initialized
INFO - 2022-07-18 08:41:16 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:16 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:16 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:16 --> URI Class Initialized
INFO - 2022-07-18 08:41:16 --> Router Class Initialized
INFO - 2022-07-18 08:41:16 --> Output Class Initialized
INFO - 2022-07-18 08:41:16 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:16 --> Input Class Initialized
INFO - 2022-07-18 08:41:16 --> Language Class Initialized
INFO - 2022-07-18 08:41:16 --> Loader Class Initialized
INFO - 2022-07-18 08:41:16 --> Helper loaded: url_helper
INFO - 2022-07-18 08:41:16 --> Helper loaded: file_helper
INFO - 2022-07-18 08:41:16 --> Database Driver Class Initialized
INFO - 2022-07-18 08:41:16 --> Email Class Initialized
DEBUG - 2022-07-18 08:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:41:16 --> Controller Class Initialized
INFO - 2022-07-18 08:41:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:41:16 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:41:16 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/login_1.php
INFO - 2022-07-18 08:41:16 --> Final output sent to browser
DEBUG - 2022-07-18 08:41:16 --> Total execution time: 0.0375
INFO - 2022-07-18 08:41:16 --> Config Class Initialized
INFO - 2022-07-18 08:41:16 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:16 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:16 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:16 --> URI Class Initialized
INFO - 2022-07-18 08:41:16 --> Router Class Initialized
INFO - 2022-07-18 08:41:16 --> Output Class Initialized
INFO - 2022-07-18 08:41:16 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:16 --> Input Class Initialized
INFO - 2022-07-18 08:41:16 --> Language Class Initialized
ERROR - 2022-07-18 08:41:16 --> 404 Page Not Found: Tokenctrl/ya.jpg
INFO - 2022-07-18 08:41:16 --> Config Class Initialized
INFO - 2022-07-18 08:41:16 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:16 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:16 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:16 --> URI Class Initialized
INFO - 2022-07-18 08:41:16 --> Router Class Initialized
INFO - 2022-07-18 08:41:16 --> Output Class Initialized
INFO - 2022-07-18 08:41:16 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:16 --> Input Class Initialized
INFO - 2022-07-18 08:41:16 --> Language Class Initialized
INFO - 2022-07-18 08:41:16 --> Loader Class Initialized
INFO - 2022-07-18 08:41:16 --> Helper loaded: url_helper
INFO - 2022-07-18 08:41:16 --> Helper loaded: file_helper
INFO - 2022-07-18 08:41:16 --> Database Driver Class Initialized
INFO - 2022-07-18 08:41:16 --> Email Class Initialized
DEBUG - 2022-07-18 08:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:41:16 --> Controller Class Initialized
INFO - 2022-07-18 08:41:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:41:16 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:41:16 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/login_1.php
INFO - 2022-07-18 08:41:16 --> Final output sent to browser
DEBUG - 2022-07-18 08:41:16 --> Total execution time: 0.0434
INFO - 2022-07-18 08:41:16 --> Config Class Initialized
INFO - 2022-07-18 08:41:16 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:16 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:16 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:16 --> URI Class Initialized
INFO - 2022-07-18 08:41:16 --> Router Class Initialized
INFO - 2022-07-18 08:41:16 --> Output Class Initialized
INFO - 2022-07-18 08:41:16 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:16 --> Input Class Initialized
INFO - 2022-07-18 08:41:16 --> Language Class Initialized
ERROR - 2022-07-18 08:41:16 --> 404 Page Not Found: Tokenctrl/ya.jpg
INFO - 2022-07-18 08:41:16 --> Config Class Initialized
INFO - 2022-07-18 08:41:16 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:16 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:16 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:16 --> URI Class Initialized
INFO - 2022-07-18 08:41:16 --> Router Class Initialized
INFO - 2022-07-18 08:41:16 --> Output Class Initialized
INFO - 2022-07-18 08:41:16 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:16 --> Input Class Initialized
INFO - 2022-07-18 08:41:16 --> Language Class Initialized
INFO - 2022-07-18 08:41:16 --> Loader Class Initialized
INFO - 2022-07-18 08:41:16 --> Helper loaded: url_helper
INFO - 2022-07-18 08:41:16 --> Helper loaded: file_helper
INFO - 2022-07-18 08:41:16 --> Database Driver Class Initialized
INFO - 2022-07-18 08:41:16 --> Email Class Initialized
DEBUG - 2022-07-18 08:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:41:16 --> Controller Class Initialized
INFO - 2022-07-18 08:41:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:41:16 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:41:16 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/login_1.php
INFO - 2022-07-18 08:41:16 --> Final output sent to browser
DEBUG - 2022-07-18 08:41:16 --> Total execution time: 0.0382
INFO - 2022-07-18 08:41:16 --> Config Class Initialized
INFO - 2022-07-18 08:41:16 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:16 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:16 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:16 --> URI Class Initialized
INFO - 2022-07-18 08:41:16 --> Router Class Initialized
INFO - 2022-07-18 08:41:16 --> Output Class Initialized
INFO - 2022-07-18 08:41:16 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:16 --> Input Class Initialized
INFO - 2022-07-18 08:41:16 --> Language Class Initialized
ERROR - 2022-07-18 08:41:16 --> 404 Page Not Found: Tokenctrl/ya.jpg
INFO - 2022-07-18 08:41:16 --> Config Class Initialized
INFO - 2022-07-18 08:41:16 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:16 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:16 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:16 --> URI Class Initialized
INFO - 2022-07-18 08:41:16 --> Router Class Initialized
INFO - 2022-07-18 08:41:16 --> Output Class Initialized
INFO - 2022-07-18 08:41:16 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:16 --> Input Class Initialized
INFO - 2022-07-18 08:41:16 --> Language Class Initialized
INFO - 2022-07-18 08:41:16 --> Loader Class Initialized
INFO - 2022-07-18 08:41:16 --> Helper loaded: url_helper
INFO - 2022-07-18 08:41:16 --> Helper loaded: file_helper
INFO - 2022-07-18 08:41:16 --> Database Driver Class Initialized
INFO - 2022-07-18 08:41:16 --> Email Class Initialized
DEBUG - 2022-07-18 08:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:41:16 --> Controller Class Initialized
INFO - 2022-07-18 08:41:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:41:16 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:41:16 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/login_1.php
INFO - 2022-07-18 08:41:16 --> Final output sent to browser
DEBUG - 2022-07-18 08:41:16 --> Total execution time: 0.0174
INFO - 2022-07-18 08:41:17 --> Config Class Initialized
INFO - 2022-07-18 08:41:17 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:17 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:17 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:17 --> URI Class Initialized
INFO - 2022-07-18 08:41:17 --> Router Class Initialized
INFO - 2022-07-18 08:41:17 --> Output Class Initialized
INFO - 2022-07-18 08:41:17 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:17 --> Input Class Initialized
INFO - 2022-07-18 08:41:17 --> Language Class Initialized
ERROR - 2022-07-18 08:41:17 --> 404 Page Not Found: Tokenctrl/ya.jpg
INFO - 2022-07-18 08:41:17 --> Config Class Initialized
INFO - 2022-07-18 08:41:17 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:17 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:17 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:17 --> URI Class Initialized
INFO - 2022-07-18 08:41:17 --> Router Class Initialized
INFO - 2022-07-18 08:41:17 --> Output Class Initialized
INFO - 2022-07-18 08:41:17 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:17 --> Input Class Initialized
INFO - 2022-07-18 08:41:17 --> Language Class Initialized
INFO - 2022-07-18 08:41:17 --> Loader Class Initialized
INFO - 2022-07-18 08:41:17 --> Helper loaded: url_helper
INFO - 2022-07-18 08:41:17 --> Helper loaded: file_helper
INFO - 2022-07-18 08:41:17 --> Database Driver Class Initialized
INFO - 2022-07-18 08:41:17 --> Email Class Initialized
DEBUG - 2022-07-18 08:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:41:17 --> Controller Class Initialized
INFO - 2022-07-18 08:41:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:41:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:41:17 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/login_1.php
INFO - 2022-07-18 08:41:17 --> Final output sent to browser
DEBUG - 2022-07-18 08:41:17 --> Total execution time: 0.0347
INFO - 2022-07-18 08:41:17 --> Config Class Initialized
INFO - 2022-07-18 08:41:17 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:17 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:17 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:17 --> URI Class Initialized
INFO - 2022-07-18 08:41:17 --> Router Class Initialized
INFO - 2022-07-18 08:41:17 --> Output Class Initialized
INFO - 2022-07-18 08:41:17 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:17 --> Input Class Initialized
INFO - 2022-07-18 08:41:17 --> Language Class Initialized
ERROR - 2022-07-18 08:41:17 --> 404 Page Not Found: Tokenctrl/ya.jpg
INFO - 2022-07-18 08:41:17 --> Config Class Initialized
INFO - 2022-07-18 08:41:17 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:17 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:17 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:17 --> URI Class Initialized
INFO - 2022-07-18 08:41:17 --> Router Class Initialized
INFO - 2022-07-18 08:41:17 --> Output Class Initialized
INFO - 2022-07-18 08:41:17 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:17 --> Input Class Initialized
INFO - 2022-07-18 08:41:17 --> Language Class Initialized
INFO - 2022-07-18 08:41:17 --> Loader Class Initialized
INFO - 2022-07-18 08:41:17 --> Helper loaded: url_helper
INFO - 2022-07-18 08:41:17 --> Helper loaded: file_helper
INFO - 2022-07-18 08:41:17 --> Database Driver Class Initialized
INFO - 2022-07-18 08:41:17 --> Email Class Initialized
DEBUG - 2022-07-18 08:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:41:17 --> Controller Class Initialized
INFO - 2022-07-18 08:41:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:41:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:41:17 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/login_1.php
INFO - 2022-07-18 08:41:17 --> Final output sent to browser
DEBUG - 2022-07-18 08:41:17 --> Total execution time: 0.0175
INFO - 2022-07-18 08:41:17 --> Config Class Initialized
INFO - 2022-07-18 08:41:17 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:17 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:17 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:17 --> URI Class Initialized
INFO - 2022-07-18 08:41:17 --> Router Class Initialized
INFO - 2022-07-18 08:41:17 --> Output Class Initialized
INFO - 2022-07-18 08:41:17 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:17 --> Input Class Initialized
INFO - 2022-07-18 08:41:17 --> Language Class Initialized
ERROR - 2022-07-18 08:41:17 --> 404 Page Not Found: Tokenctrl/ya.jpg
INFO - 2022-07-18 08:41:17 --> Config Class Initialized
INFO - 2022-07-18 08:41:17 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:17 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:17 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:17 --> URI Class Initialized
INFO - 2022-07-18 08:41:17 --> Router Class Initialized
INFO - 2022-07-18 08:41:17 --> Output Class Initialized
INFO - 2022-07-18 08:41:17 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:17 --> Input Class Initialized
INFO - 2022-07-18 08:41:17 --> Language Class Initialized
INFO - 2022-07-18 08:41:17 --> Loader Class Initialized
INFO - 2022-07-18 08:41:17 --> Helper loaded: url_helper
INFO - 2022-07-18 08:41:17 --> Helper loaded: file_helper
INFO - 2022-07-18 08:41:17 --> Database Driver Class Initialized
INFO - 2022-07-18 08:41:17 --> Email Class Initialized
DEBUG - 2022-07-18 08:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:41:17 --> Controller Class Initialized
INFO - 2022-07-18 08:41:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:41:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:41:17 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/login_1.php
INFO - 2022-07-18 08:41:17 --> Final output sent to browser
DEBUG - 2022-07-18 08:41:17 --> Total execution time: 0.0787
INFO - 2022-07-18 08:41:17 --> Config Class Initialized
INFO - 2022-07-18 08:41:17 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:17 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:17 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:17 --> URI Class Initialized
INFO - 2022-07-18 08:41:17 --> Router Class Initialized
INFO - 2022-07-18 08:41:17 --> Output Class Initialized
INFO - 2022-07-18 08:41:17 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:17 --> Input Class Initialized
INFO - 2022-07-18 08:41:17 --> Language Class Initialized
INFO - 2022-07-18 08:41:17 --> Loader Class Initialized
INFO - 2022-07-18 08:41:17 --> Helper loaded: url_helper
INFO - 2022-07-18 08:41:17 --> Helper loaded: file_helper
INFO - 2022-07-18 08:41:17 --> Database Driver Class Initialized
INFO - 2022-07-18 08:41:17 --> Email Class Initialized
DEBUG - 2022-07-18 08:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:41:17 --> Controller Class Initialized
INFO - 2022-07-18 08:41:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:41:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:41:17 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/login_1.php
INFO - 2022-07-18 08:41:17 --> Final output sent to browser
DEBUG - 2022-07-18 08:41:17 --> Total execution time: 0.0208
INFO - 2022-07-18 08:41:18 --> Config Class Initialized
INFO - 2022-07-18 08:41:18 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:18 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:18 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:18 --> URI Class Initialized
INFO - 2022-07-18 08:41:18 --> Router Class Initialized
INFO - 2022-07-18 08:41:18 --> Output Class Initialized
INFO - 2022-07-18 08:41:18 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:18 --> Input Class Initialized
INFO - 2022-07-18 08:41:18 --> Language Class Initialized
ERROR - 2022-07-18 08:41:18 --> 404 Page Not Found: Tokenctrl/ya.jpg
INFO - 2022-07-18 08:41:18 --> Config Class Initialized
INFO - 2022-07-18 08:41:18 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:18 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:18 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:18 --> URI Class Initialized
INFO - 2022-07-18 08:41:18 --> Router Class Initialized
INFO - 2022-07-18 08:41:18 --> Output Class Initialized
INFO - 2022-07-18 08:41:18 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:18 --> Input Class Initialized
INFO - 2022-07-18 08:41:18 --> Language Class Initialized
INFO - 2022-07-18 08:41:18 --> Loader Class Initialized
INFO - 2022-07-18 08:41:18 --> Helper loaded: url_helper
INFO - 2022-07-18 08:41:18 --> Helper loaded: file_helper
INFO - 2022-07-18 08:41:18 --> Database Driver Class Initialized
INFO - 2022-07-18 08:41:18 --> Email Class Initialized
DEBUG - 2022-07-18 08:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:41:18 --> Controller Class Initialized
INFO - 2022-07-18 08:41:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:41:18 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:41:18 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/login_1.php
INFO - 2022-07-18 08:41:18 --> Final output sent to browser
DEBUG - 2022-07-18 08:41:18 --> Total execution time: 0.0280
INFO - 2022-07-18 08:41:18 --> Config Class Initialized
INFO - 2022-07-18 08:41:18 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:18 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:18 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:18 --> URI Class Initialized
INFO - 2022-07-18 08:41:18 --> Router Class Initialized
INFO - 2022-07-18 08:41:18 --> Output Class Initialized
INFO - 2022-07-18 08:41:18 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:18 --> Input Class Initialized
INFO - 2022-07-18 08:41:18 --> Language Class Initialized
ERROR - 2022-07-18 08:41:18 --> 404 Page Not Found: Tokenctrl/ya.jpg
INFO - 2022-07-18 08:41:18 --> Config Class Initialized
INFO - 2022-07-18 08:41:18 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:18 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:18 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:18 --> URI Class Initialized
INFO - 2022-07-18 08:41:18 --> Router Class Initialized
INFO - 2022-07-18 08:41:18 --> Output Class Initialized
INFO - 2022-07-18 08:41:18 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:18 --> Input Class Initialized
INFO - 2022-07-18 08:41:18 --> Language Class Initialized
INFO - 2022-07-18 08:41:18 --> Loader Class Initialized
INFO - 2022-07-18 08:41:18 --> Helper loaded: url_helper
INFO - 2022-07-18 08:41:18 --> Helper loaded: file_helper
INFO - 2022-07-18 08:41:18 --> Database Driver Class Initialized
INFO - 2022-07-18 08:41:18 --> Email Class Initialized
DEBUG - 2022-07-18 08:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:41:18 --> Controller Class Initialized
INFO - 2022-07-18 08:41:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:41:18 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:41:18 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/login_1.php
INFO - 2022-07-18 08:41:18 --> Final output sent to browser
DEBUG - 2022-07-18 08:41:18 --> Total execution time: 0.0327
INFO - 2022-07-18 08:41:18 --> Config Class Initialized
INFO - 2022-07-18 08:41:18 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:18 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:18 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:18 --> URI Class Initialized
INFO - 2022-07-18 08:41:18 --> Router Class Initialized
INFO - 2022-07-18 08:41:18 --> Output Class Initialized
INFO - 2022-07-18 08:41:18 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:18 --> Input Class Initialized
INFO - 2022-07-18 08:41:18 --> Language Class Initialized
ERROR - 2022-07-18 08:41:18 --> 404 Page Not Found: Tokenctrl/ya.jpg
INFO - 2022-07-18 08:41:19 --> Config Class Initialized
INFO - 2022-07-18 08:41:19 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:19 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:19 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:19 --> URI Class Initialized
INFO - 2022-07-18 08:41:19 --> Router Class Initialized
INFO - 2022-07-18 08:41:19 --> Output Class Initialized
INFO - 2022-07-18 08:41:19 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:19 --> Input Class Initialized
INFO - 2022-07-18 08:41:19 --> Language Class Initialized
INFO - 2022-07-18 08:41:19 --> Loader Class Initialized
INFO - 2022-07-18 08:41:19 --> Helper loaded: url_helper
INFO - 2022-07-18 08:41:19 --> Helper loaded: file_helper
INFO - 2022-07-18 08:41:19 --> Database Driver Class Initialized
INFO - 2022-07-18 08:41:19 --> Email Class Initialized
DEBUG - 2022-07-18 08:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:41:19 --> Controller Class Initialized
INFO - 2022-07-18 08:41:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:41:19 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:41:19 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/login_1.php
INFO - 2022-07-18 08:41:19 --> Final output sent to browser
DEBUG - 2022-07-18 08:41:19 --> Total execution time: 0.0392
INFO - 2022-07-18 08:41:19 --> Config Class Initialized
INFO - 2022-07-18 08:41:19 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:19 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:19 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:19 --> URI Class Initialized
INFO - 2022-07-18 08:41:19 --> Router Class Initialized
INFO - 2022-07-18 08:41:19 --> Output Class Initialized
INFO - 2022-07-18 08:41:19 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:19 --> Input Class Initialized
INFO - 2022-07-18 08:41:19 --> Language Class Initialized
ERROR - 2022-07-18 08:41:19 --> 404 Page Not Found: Tokenctrl/ya.jpg
INFO - 2022-07-18 08:41:19 --> Config Class Initialized
INFO - 2022-07-18 08:41:19 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:19 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:19 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:19 --> URI Class Initialized
INFO - 2022-07-18 08:41:19 --> Router Class Initialized
INFO - 2022-07-18 08:41:19 --> Output Class Initialized
INFO - 2022-07-18 08:41:19 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:19 --> Input Class Initialized
INFO - 2022-07-18 08:41:19 --> Language Class Initialized
INFO - 2022-07-18 08:41:19 --> Loader Class Initialized
INFO - 2022-07-18 08:41:19 --> Helper loaded: url_helper
INFO - 2022-07-18 08:41:19 --> Helper loaded: file_helper
INFO - 2022-07-18 08:41:19 --> Database Driver Class Initialized
INFO - 2022-07-18 08:41:19 --> Email Class Initialized
DEBUG - 2022-07-18 08:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:41:19 --> Controller Class Initialized
INFO - 2022-07-18 08:41:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:41:19 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:41:19 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/login_1.php
INFO - 2022-07-18 08:41:19 --> Final output sent to browser
DEBUG - 2022-07-18 08:41:19 --> Total execution time: 0.0340
INFO - 2022-07-18 08:41:19 --> Config Class Initialized
INFO - 2022-07-18 08:41:19 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:19 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:19 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:19 --> URI Class Initialized
INFO - 2022-07-18 08:41:19 --> Router Class Initialized
INFO - 2022-07-18 08:41:19 --> Output Class Initialized
INFO - 2022-07-18 08:41:19 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:19 --> Input Class Initialized
INFO - 2022-07-18 08:41:19 --> Language Class Initialized
ERROR - 2022-07-18 08:41:19 --> 404 Page Not Found: Tokenctrl/ya.jpg
INFO - 2022-07-18 08:41:19 --> Config Class Initialized
INFO - 2022-07-18 08:41:19 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:19 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:19 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:19 --> URI Class Initialized
INFO - 2022-07-18 08:41:19 --> Router Class Initialized
INFO - 2022-07-18 08:41:19 --> Output Class Initialized
INFO - 2022-07-18 08:41:19 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:19 --> Input Class Initialized
INFO - 2022-07-18 08:41:19 --> Language Class Initialized
INFO - 2022-07-18 08:41:19 --> Loader Class Initialized
INFO - 2022-07-18 08:41:19 --> Helper loaded: url_helper
INFO - 2022-07-18 08:41:19 --> Helper loaded: file_helper
INFO - 2022-07-18 08:41:19 --> Database Driver Class Initialized
INFO - 2022-07-18 08:41:19 --> Email Class Initialized
DEBUG - 2022-07-18 08:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:41:19 --> Controller Class Initialized
INFO - 2022-07-18 08:41:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:41:19 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:41:19 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/login_1.php
INFO - 2022-07-18 08:41:19 --> Final output sent to browser
DEBUG - 2022-07-18 08:41:19 --> Total execution time: 0.0226
INFO - 2022-07-18 08:41:20 --> Config Class Initialized
INFO - 2022-07-18 08:41:20 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:41:20 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:41:20 --> Utf8 Class Initialized
INFO - 2022-07-18 08:41:20 --> URI Class Initialized
INFO - 2022-07-18 08:41:20 --> Router Class Initialized
INFO - 2022-07-18 08:41:20 --> Output Class Initialized
INFO - 2022-07-18 08:41:20 --> Security Class Initialized
DEBUG - 2022-07-18 08:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:41:20 --> Input Class Initialized
INFO - 2022-07-18 08:41:20 --> Language Class Initialized
ERROR - 2022-07-18 08:41:20 --> 404 Page Not Found: Tokenctrl/ya.jpg
INFO - 2022-07-18 08:46:08 --> Config Class Initialized
INFO - 2022-07-18 08:46:08 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:46:08 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:46:08 --> Utf8 Class Initialized
INFO - 2022-07-18 08:46:08 --> URI Class Initialized
INFO - 2022-07-18 08:46:08 --> Router Class Initialized
INFO - 2022-07-18 08:46:08 --> Output Class Initialized
INFO - 2022-07-18 08:46:08 --> Security Class Initialized
DEBUG - 2022-07-18 08:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:46:08 --> Input Class Initialized
INFO - 2022-07-18 08:46:08 --> Language Class Initialized
INFO - 2022-07-18 08:46:08 --> Loader Class Initialized
INFO - 2022-07-18 08:46:08 --> Helper loaded: url_helper
INFO - 2022-07-18 08:46:08 --> Helper loaded: file_helper
INFO - 2022-07-18 08:46:08 --> Database Driver Class Initialized
INFO - 2022-07-18 08:46:09 --> Email Class Initialized
DEBUG - 2022-07-18 08:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:46:09 --> Controller Class Initialized
INFO - 2022-07-18 08:46:09 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:46:09 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:46:09 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/login_1.php
INFO - 2022-07-18 08:46:09 --> Final output sent to browser
DEBUG - 2022-07-18 08:46:09 --> Total execution time: 0.0406
INFO - 2022-07-18 08:46:09 --> Config Class Initialized
INFO - 2022-07-18 08:46:09 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:46:09 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:46:09 --> Utf8 Class Initialized
INFO - 2022-07-18 08:46:09 --> URI Class Initialized
INFO - 2022-07-18 08:46:09 --> Router Class Initialized
INFO - 2022-07-18 08:46:09 --> Output Class Initialized
INFO - 2022-07-18 08:46:09 --> Security Class Initialized
DEBUG - 2022-07-18 08:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:46:09 --> Input Class Initialized
INFO - 2022-07-18 08:46:09 --> Language Class Initialized
ERROR - 2022-07-18 08:46:09 --> 404 Page Not Found: Tokenctrl/ya.jpg
INFO - 2022-07-18 08:46:17 --> Config Class Initialized
INFO - 2022-07-18 08:46:17 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:46:17 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:46:17 --> Utf8 Class Initialized
INFO - 2022-07-18 08:46:17 --> URI Class Initialized
INFO - 2022-07-18 08:46:17 --> Router Class Initialized
INFO - 2022-07-18 08:46:17 --> Output Class Initialized
INFO - 2022-07-18 08:46:17 --> Security Class Initialized
DEBUG - 2022-07-18 08:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:46:17 --> Input Class Initialized
INFO - 2022-07-18 08:46:17 --> Language Class Initialized
INFO - 2022-07-18 08:46:17 --> Loader Class Initialized
INFO - 2022-07-18 08:46:17 --> Helper loaded: url_helper
INFO - 2022-07-18 08:46:17 --> Helper loaded: file_helper
INFO - 2022-07-18 08:46:17 --> Database Driver Class Initialized
INFO - 2022-07-18 08:46:17 --> Email Class Initialized
DEBUG - 2022-07-18 08:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:46:17 --> Controller Class Initialized
INFO - 2022-07-18 08:46:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:46:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:46:17 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-18 08:46:17 --> Final output sent to browser
DEBUG - 2022-07-18 08:46:17 --> Total execution time: 0.0191
INFO - 2022-07-18 08:48:15 --> Config Class Initialized
INFO - 2022-07-18 08:48:15 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:48:15 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:48:15 --> Utf8 Class Initialized
INFO - 2022-07-18 08:48:15 --> URI Class Initialized
INFO - 2022-07-18 08:48:15 --> Router Class Initialized
INFO - 2022-07-18 08:48:15 --> Output Class Initialized
INFO - 2022-07-18 08:48:15 --> Security Class Initialized
DEBUG - 2022-07-18 08:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:48:15 --> Input Class Initialized
INFO - 2022-07-18 08:48:15 --> Language Class Initialized
INFO - 2022-07-18 08:48:15 --> Loader Class Initialized
INFO - 2022-07-18 08:48:15 --> Helper loaded: url_helper
INFO - 2022-07-18 08:48:15 --> Helper loaded: file_helper
INFO - 2022-07-18 08:48:15 --> Database Driver Class Initialized
INFO - 2022-07-18 08:48:16 --> Email Class Initialized
DEBUG - 2022-07-18 08:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:48:16 --> Controller Class Initialized
INFO - 2022-07-18 08:48:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:48:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 14:18:16 --> Severity: Notice --> Undefined variable: requested_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
ERROR - 2022-07-18 14:18:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
INFO - 2022-07-18 14:18:16 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 14:18:16 --> Final output sent to browser
DEBUG - 2022-07-18 14:18:16 --> Total execution time: 0.2081
INFO - 2022-07-18 08:48:32 --> Config Class Initialized
INFO - 2022-07-18 08:48:32 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:48:32 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:48:32 --> Utf8 Class Initialized
INFO - 2022-07-18 08:48:32 --> URI Class Initialized
INFO - 2022-07-18 08:48:32 --> Router Class Initialized
INFO - 2022-07-18 08:48:32 --> Output Class Initialized
INFO - 2022-07-18 08:48:32 --> Security Class Initialized
DEBUG - 2022-07-18 08:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:48:32 --> Input Class Initialized
INFO - 2022-07-18 08:48:32 --> Language Class Initialized
ERROR - 2022-07-18 08:48:32 --> 404 Page Not Found: Tokenctrl/ya.jpg
INFO - 2022-07-18 08:48:55 --> Config Class Initialized
INFO - 2022-07-18 08:48:55 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:48:55 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:48:55 --> Utf8 Class Initialized
INFO - 2022-07-18 08:48:55 --> URI Class Initialized
INFO - 2022-07-18 08:48:55 --> Router Class Initialized
INFO - 2022-07-18 08:48:55 --> Output Class Initialized
INFO - 2022-07-18 08:48:55 --> Security Class Initialized
DEBUG - 2022-07-18 08:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:48:55 --> Input Class Initialized
INFO - 2022-07-18 08:48:55 --> Language Class Initialized
INFO - 2022-07-18 08:48:55 --> Loader Class Initialized
INFO - 2022-07-18 08:48:55 --> Helper loaded: url_helper
INFO - 2022-07-18 08:48:55 --> Helper loaded: file_helper
INFO - 2022-07-18 08:48:55 --> Database Driver Class Initialized
INFO - 2022-07-18 08:48:55 --> Email Class Initialized
DEBUG - 2022-07-18 08:48:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:48:55 --> Controller Class Initialized
INFO - 2022-07-18 08:48:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:48:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:48:55 --> Final output sent to browser
DEBUG - 2022-07-18 08:48:55 --> Total execution time: 0.0267
INFO - 2022-07-18 08:48:55 --> Config Class Initialized
INFO - 2022-07-18 08:48:55 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:48:55 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:48:55 --> Utf8 Class Initialized
INFO - 2022-07-18 08:48:55 --> URI Class Initialized
INFO - 2022-07-18 08:48:55 --> Router Class Initialized
INFO - 2022-07-18 08:48:55 --> Output Class Initialized
INFO - 2022-07-18 08:48:55 --> Security Class Initialized
DEBUG - 2022-07-18 08:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:48:55 --> Input Class Initialized
INFO - 2022-07-18 08:48:55 --> Language Class Initialized
INFO - 2022-07-18 08:48:55 --> Loader Class Initialized
INFO - 2022-07-18 08:48:55 --> Helper loaded: url_helper
INFO - 2022-07-18 08:48:55 --> Helper loaded: file_helper
INFO - 2022-07-18 08:48:55 --> Database Driver Class Initialized
INFO - 2022-07-18 08:48:55 --> Email Class Initialized
DEBUG - 2022-07-18 08:48:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:48:55 --> Controller Class Initialized
INFO - 2022-07-18 08:48:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:48:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:48:55 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-18 08:48:55 --> Final output sent to browser
DEBUG - 2022-07-18 08:48:55 --> Total execution time: 0.1313
INFO - 2022-07-18 08:48:57 --> Config Class Initialized
INFO - 2022-07-18 08:48:57 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:48:57 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:48:57 --> Utf8 Class Initialized
INFO - 2022-07-18 08:48:57 --> URI Class Initialized
INFO - 2022-07-18 08:48:57 --> Router Class Initialized
INFO - 2022-07-18 08:48:57 --> Output Class Initialized
INFO - 2022-07-18 08:48:57 --> Security Class Initialized
DEBUG - 2022-07-18 08:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:48:57 --> Input Class Initialized
INFO - 2022-07-18 08:48:57 --> Language Class Initialized
INFO - 2022-07-18 08:48:57 --> Loader Class Initialized
INFO - 2022-07-18 08:48:57 --> Helper loaded: url_helper
INFO - 2022-07-18 08:48:57 --> Helper loaded: file_helper
INFO - 2022-07-18 08:48:57 --> Database Driver Class Initialized
INFO - 2022-07-18 08:48:57 --> Email Class Initialized
DEBUG - 2022-07-18 08:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:48:57 --> Controller Class Initialized
INFO - 2022-07-18 08:48:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:48:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:48:57 --> Final output sent to browser
DEBUG - 2022-07-18 08:48:57 --> Total execution time: 0.0270
INFO - 2022-07-18 08:49:00 --> Config Class Initialized
INFO - 2022-07-18 08:49:00 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:49:00 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:49:00 --> Utf8 Class Initialized
INFO - 2022-07-18 08:49:00 --> URI Class Initialized
INFO - 2022-07-18 08:49:00 --> Router Class Initialized
INFO - 2022-07-18 08:49:00 --> Output Class Initialized
INFO - 2022-07-18 08:49:00 --> Security Class Initialized
DEBUG - 2022-07-18 08:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:49:00 --> Input Class Initialized
INFO - 2022-07-18 08:49:00 --> Language Class Initialized
INFO - 2022-07-18 08:49:00 --> Loader Class Initialized
INFO - 2022-07-18 08:49:00 --> Helper loaded: url_helper
INFO - 2022-07-18 08:49:00 --> Helper loaded: file_helper
INFO - 2022-07-18 08:49:00 --> Database Driver Class Initialized
INFO - 2022-07-18 08:49:00 --> Email Class Initialized
DEBUG - 2022-07-18 08:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:49:00 --> Controller Class Initialized
INFO - 2022-07-18 08:49:00 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:49:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 14:19:00 --> Severity: Notice --> Undefined variable: requested_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
ERROR - 2022-07-18 14:19:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
INFO - 2022-07-18 14:19:00 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 14:19:00 --> Final output sent to browser
DEBUG - 2022-07-18 14:19:00 --> Total execution time: 0.1838
INFO - 2022-07-18 08:49:01 --> Config Class Initialized
INFO - 2022-07-18 08:49:01 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:49:01 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:49:01 --> Utf8 Class Initialized
INFO - 2022-07-18 08:49:01 --> URI Class Initialized
INFO - 2022-07-18 08:49:01 --> Router Class Initialized
INFO - 2022-07-18 08:49:01 --> Output Class Initialized
INFO - 2022-07-18 08:49:01 --> Security Class Initialized
DEBUG - 2022-07-18 08:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:49:01 --> Input Class Initialized
INFO - 2022-07-18 08:49:01 --> Language Class Initialized
INFO - 2022-07-18 08:49:01 --> Loader Class Initialized
INFO - 2022-07-18 08:49:01 --> Helper loaded: url_helper
INFO - 2022-07-18 08:49:01 --> Helper loaded: file_helper
INFO - 2022-07-18 08:49:01 --> Database Driver Class Initialized
INFO - 2022-07-18 08:49:01 --> Email Class Initialized
DEBUG - 2022-07-18 08:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:49:01 --> Controller Class Initialized
INFO - 2022-07-18 08:49:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:49:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 14:19:01 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 14:19:01 --> Final output sent to browser
DEBUG - 2022-07-18 14:19:01 --> Total execution time: 0.0456
INFO - 2022-07-18 08:49:04 --> Config Class Initialized
INFO - 2022-07-18 08:49:04 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:49:04 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:49:04 --> Utf8 Class Initialized
INFO - 2022-07-18 08:49:04 --> URI Class Initialized
INFO - 2022-07-18 08:49:04 --> Router Class Initialized
INFO - 2022-07-18 08:49:04 --> Output Class Initialized
INFO - 2022-07-18 08:49:04 --> Security Class Initialized
DEBUG - 2022-07-18 08:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:49:04 --> Input Class Initialized
INFO - 2022-07-18 08:49:04 --> Language Class Initialized
INFO - 2022-07-18 08:49:04 --> Loader Class Initialized
INFO - 2022-07-18 08:49:04 --> Helper loaded: url_helper
INFO - 2022-07-18 08:49:04 --> Helper loaded: file_helper
INFO - 2022-07-18 08:49:04 --> Database Driver Class Initialized
INFO - 2022-07-18 08:49:04 --> Email Class Initialized
DEBUG - 2022-07-18 08:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:49:04 --> Controller Class Initialized
INFO - 2022-07-18 08:49:04 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:49:04 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 14:19:04 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 14:19:04 --> Final output sent to browser
DEBUG - 2022-07-18 14:19:04 --> Total execution time: 0.1570
INFO - 2022-07-18 08:49:06 --> Config Class Initialized
INFO - 2022-07-18 08:49:06 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:49:06 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:49:06 --> Utf8 Class Initialized
INFO - 2022-07-18 08:49:06 --> URI Class Initialized
INFO - 2022-07-18 08:49:06 --> Router Class Initialized
INFO - 2022-07-18 08:49:06 --> Output Class Initialized
INFO - 2022-07-18 08:49:06 --> Security Class Initialized
DEBUG - 2022-07-18 08:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:49:06 --> Input Class Initialized
INFO - 2022-07-18 08:49:06 --> Language Class Initialized
INFO - 2022-07-18 08:49:06 --> Loader Class Initialized
INFO - 2022-07-18 08:49:06 --> Helper loaded: url_helper
INFO - 2022-07-18 08:49:06 --> Helper loaded: file_helper
INFO - 2022-07-18 08:49:06 --> Database Driver Class Initialized
INFO - 2022-07-18 08:49:06 --> Email Class Initialized
DEBUG - 2022-07-18 08:49:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:49:06 --> Controller Class Initialized
INFO - 2022-07-18 08:49:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:49:06 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:49:06 --> Final output sent to browser
DEBUG - 2022-07-18 08:49:06 --> Total execution time: 0.0265
INFO - 2022-07-18 08:49:06 --> Config Class Initialized
INFO - 2022-07-18 08:49:06 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:49:06 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:49:06 --> Utf8 Class Initialized
INFO - 2022-07-18 08:49:06 --> URI Class Initialized
INFO - 2022-07-18 08:49:06 --> Router Class Initialized
INFO - 2022-07-18 08:49:06 --> Output Class Initialized
INFO - 2022-07-18 08:49:06 --> Security Class Initialized
DEBUG - 2022-07-18 08:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:49:06 --> Input Class Initialized
INFO - 2022-07-18 08:49:06 --> Language Class Initialized
INFO - 2022-07-18 08:49:06 --> Loader Class Initialized
INFO - 2022-07-18 08:49:06 --> Helper loaded: url_helper
INFO - 2022-07-18 08:49:06 --> Helper loaded: file_helper
INFO - 2022-07-18 08:49:06 --> Database Driver Class Initialized
INFO - 2022-07-18 08:49:06 --> Email Class Initialized
DEBUG - 2022-07-18 08:49:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:49:06 --> Controller Class Initialized
INFO - 2022-07-18 08:49:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:49:06 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:49:06 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-18 08:49:06 --> Final output sent to browser
DEBUG - 2022-07-18 08:49:06 --> Total execution time: 0.0291
INFO - 2022-07-18 08:49:08 --> Config Class Initialized
INFO - 2022-07-18 08:49:08 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:49:08 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:49:08 --> Utf8 Class Initialized
INFO - 2022-07-18 08:49:08 --> URI Class Initialized
INFO - 2022-07-18 08:49:08 --> Router Class Initialized
INFO - 2022-07-18 08:49:08 --> Output Class Initialized
INFO - 2022-07-18 08:49:08 --> Security Class Initialized
DEBUG - 2022-07-18 08:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:49:08 --> Input Class Initialized
INFO - 2022-07-18 08:49:08 --> Language Class Initialized
INFO - 2022-07-18 08:49:08 --> Loader Class Initialized
INFO - 2022-07-18 08:49:08 --> Helper loaded: url_helper
INFO - 2022-07-18 08:49:08 --> Helper loaded: file_helper
INFO - 2022-07-18 08:49:08 --> Database Driver Class Initialized
INFO - 2022-07-18 08:49:08 --> Email Class Initialized
DEBUG - 2022-07-18 08:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:49:08 --> Controller Class Initialized
INFO - 2022-07-18 08:49:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:49:08 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:49:08 --> Final output sent to browser
DEBUG - 2022-07-18 08:49:08 --> Total execution time: 0.0180
INFO - 2022-07-18 08:49:11 --> Config Class Initialized
INFO - 2022-07-18 08:49:11 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:49:11 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:49:11 --> Utf8 Class Initialized
INFO - 2022-07-18 08:49:11 --> URI Class Initialized
INFO - 2022-07-18 08:49:11 --> Router Class Initialized
INFO - 2022-07-18 08:49:11 --> Output Class Initialized
INFO - 2022-07-18 08:49:11 --> Security Class Initialized
DEBUG - 2022-07-18 08:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:49:11 --> Input Class Initialized
INFO - 2022-07-18 08:49:11 --> Language Class Initialized
INFO - 2022-07-18 08:49:11 --> Loader Class Initialized
INFO - 2022-07-18 08:49:11 --> Helper loaded: url_helper
INFO - 2022-07-18 08:49:11 --> Helper loaded: file_helper
INFO - 2022-07-18 08:49:11 --> Database Driver Class Initialized
INFO - 2022-07-18 08:49:11 --> Email Class Initialized
DEBUG - 2022-07-18 08:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:49:11 --> Controller Class Initialized
INFO - 2022-07-18 08:49:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:49:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 14:19:11 --> Severity: Notice --> Undefined variable: requested_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
ERROR - 2022-07-18 14:19:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
INFO - 2022-07-18 14:19:11 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 14:19:11 --> Final output sent to browser
DEBUG - 2022-07-18 14:19:11 --> Total execution time: 0.0216
INFO - 2022-07-18 08:49:14 --> Config Class Initialized
INFO - 2022-07-18 08:49:14 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:49:14 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:49:14 --> Utf8 Class Initialized
INFO - 2022-07-18 08:49:14 --> URI Class Initialized
INFO - 2022-07-18 08:49:14 --> Router Class Initialized
INFO - 2022-07-18 08:49:14 --> Output Class Initialized
INFO - 2022-07-18 08:49:14 --> Security Class Initialized
DEBUG - 2022-07-18 08:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:49:14 --> Input Class Initialized
INFO - 2022-07-18 08:49:14 --> Language Class Initialized
INFO - 2022-07-18 08:49:14 --> Loader Class Initialized
INFO - 2022-07-18 08:49:14 --> Helper loaded: url_helper
INFO - 2022-07-18 08:49:14 --> Helper loaded: file_helper
INFO - 2022-07-18 08:49:14 --> Database Driver Class Initialized
INFO - 2022-07-18 08:49:14 --> Email Class Initialized
DEBUG - 2022-07-18 08:49:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:49:14 --> Controller Class Initialized
INFO - 2022-07-18 08:49:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:49:14 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 14:19:14 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 14:19:14 --> Final output sent to browser
DEBUG - 2022-07-18 14:19:14 --> Total execution time: 0.0203
INFO - 2022-07-18 08:49:19 --> Config Class Initialized
INFO - 2022-07-18 08:49:19 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:49:19 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:49:19 --> Utf8 Class Initialized
INFO - 2022-07-18 08:49:19 --> URI Class Initialized
INFO - 2022-07-18 08:49:19 --> Router Class Initialized
INFO - 2022-07-18 08:49:19 --> Output Class Initialized
INFO - 2022-07-18 08:49:19 --> Security Class Initialized
DEBUG - 2022-07-18 08:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:49:19 --> Input Class Initialized
INFO - 2022-07-18 08:49:19 --> Language Class Initialized
INFO - 2022-07-18 08:49:19 --> Loader Class Initialized
INFO - 2022-07-18 08:49:19 --> Helper loaded: url_helper
INFO - 2022-07-18 08:49:19 --> Helper loaded: file_helper
INFO - 2022-07-18 08:49:19 --> Database Driver Class Initialized
INFO - 2022-07-18 08:49:19 --> Email Class Initialized
DEBUG - 2022-07-18 08:49:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:49:19 --> Controller Class Initialized
INFO - 2022-07-18 08:49:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:49:19 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 14:19:19 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 14:19:19 --> Final output sent to browser
DEBUG - 2022-07-18 14:19:19 --> Total execution time: 0.0200
INFO - 2022-07-18 08:49:20 --> Config Class Initialized
INFO - 2022-07-18 08:49:20 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:49:20 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:49:20 --> Utf8 Class Initialized
INFO - 2022-07-18 08:49:20 --> URI Class Initialized
INFO - 2022-07-18 08:49:20 --> Router Class Initialized
INFO - 2022-07-18 08:49:20 --> Output Class Initialized
INFO - 2022-07-18 08:49:20 --> Security Class Initialized
DEBUG - 2022-07-18 08:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:49:20 --> Input Class Initialized
INFO - 2022-07-18 08:49:20 --> Language Class Initialized
INFO - 2022-07-18 08:49:20 --> Loader Class Initialized
INFO - 2022-07-18 08:49:20 --> Helper loaded: url_helper
INFO - 2022-07-18 08:49:20 --> Helper loaded: file_helper
INFO - 2022-07-18 08:49:20 --> Database Driver Class Initialized
INFO - 2022-07-18 08:49:20 --> Email Class Initialized
DEBUG - 2022-07-18 08:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:49:20 --> Controller Class Initialized
INFO - 2022-07-18 08:49:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:49:20 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 14:19:20 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 14:19:20 --> Final output sent to browser
DEBUG - 2022-07-18 14:19:20 --> Total execution time: 0.0187
INFO - 2022-07-18 08:49:20 --> Config Class Initialized
INFO - 2022-07-18 08:49:20 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:49:20 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:49:20 --> Utf8 Class Initialized
INFO - 2022-07-18 08:49:20 --> URI Class Initialized
INFO - 2022-07-18 08:49:20 --> Router Class Initialized
INFO - 2022-07-18 08:49:20 --> Output Class Initialized
INFO - 2022-07-18 08:49:20 --> Security Class Initialized
DEBUG - 2022-07-18 08:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:49:20 --> Input Class Initialized
INFO - 2022-07-18 08:49:20 --> Language Class Initialized
INFO - 2022-07-18 08:49:20 --> Loader Class Initialized
INFO - 2022-07-18 08:49:20 --> Helper loaded: url_helper
INFO - 2022-07-18 08:49:20 --> Helper loaded: file_helper
INFO - 2022-07-18 08:49:20 --> Database Driver Class Initialized
INFO - 2022-07-18 08:49:20 --> Email Class Initialized
DEBUG - 2022-07-18 08:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:49:20 --> Controller Class Initialized
INFO - 2022-07-18 08:49:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:49:20 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 14:19:20 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 14:19:20 --> Final output sent to browser
DEBUG - 2022-07-18 14:19:20 --> Total execution time: 0.0462
INFO - 2022-07-18 08:49:21 --> Config Class Initialized
INFO - 2022-07-18 08:49:21 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:49:21 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:49:21 --> Utf8 Class Initialized
INFO - 2022-07-18 08:49:21 --> URI Class Initialized
INFO - 2022-07-18 08:49:21 --> Router Class Initialized
INFO - 2022-07-18 08:49:21 --> Output Class Initialized
INFO - 2022-07-18 08:49:21 --> Security Class Initialized
DEBUG - 2022-07-18 08:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:49:21 --> Input Class Initialized
INFO - 2022-07-18 08:49:21 --> Language Class Initialized
INFO - 2022-07-18 08:49:21 --> Loader Class Initialized
INFO - 2022-07-18 08:49:21 --> Helper loaded: url_helper
INFO - 2022-07-18 08:49:21 --> Helper loaded: file_helper
INFO - 2022-07-18 08:49:21 --> Database Driver Class Initialized
INFO - 2022-07-18 08:49:21 --> Email Class Initialized
DEBUG - 2022-07-18 08:49:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:49:21 --> Controller Class Initialized
INFO - 2022-07-18 08:49:21 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:49:21 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 14:19:21 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 14:19:21 --> Final output sent to browser
DEBUG - 2022-07-18 14:19:21 --> Total execution time: 0.0187
INFO - 2022-07-18 08:49:22 --> Config Class Initialized
INFO - 2022-07-18 08:49:22 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:49:22 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:49:22 --> Utf8 Class Initialized
INFO - 2022-07-18 08:49:22 --> URI Class Initialized
INFO - 2022-07-18 08:49:22 --> Router Class Initialized
INFO - 2022-07-18 08:49:22 --> Output Class Initialized
INFO - 2022-07-18 08:49:22 --> Security Class Initialized
DEBUG - 2022-07-18 08:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:49:22 --> Input Class Initialized
INFO - 2022-07-18 08:49:22 --> Language Class Initialized
INFO - 2022-07-18 08:49:22 --> Loader Class Initialized
INFO - 2022-07-18 08:49:22 --> Helper loaded: url_helper
INFO - 2022-07-18 08:49:22 --> Helper loaded: file_helper
INFO - 2022-07-18 08:49:22 --> Database Driver Class Initialized
INFO - 2022-07-18 08:49:22 --> Email Class Initialized
DEBUG - 2022-07-18 08:49:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:49:22 --> Controller Class Initialized
INFO - 2022-07-18 08:49:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:49:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 14:19:22 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 14:19:22 --> Final output sent to browser
DEBUG - 2022-07-18 14:19:22 --> Total execution time: 0.0462
INFO - 2022-07-18 08:49:23 --> Config Class Initialized
INFO - 2022-07-18 08:49:23 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:49:23 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:49:23 --> Utf8 Class Initialized
INFO - 2022-07-18 08:49:23 --> URI Class Initialized
INFO - 2022-07-18 08:49:23 --> Router Class Initialized
INFO - 2022-07-18 08:49:23 --> Output Class Initialized
INFO - 2022-07-18 08:49:23 --> Security Class Initialized
DEBUG - 2022-07-18 08:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:49:23 --> Input Class Initialized
INFO - 2022-07-18 08:49:23 --> Language Class Initialized
INFO - 2022-07-18 08:49:23 --> Loader Class Initialized
INFO - 2022-07-18 08:49:23 --> Helper loaded: url_helper
INFO - 2022-07-18 08:49:23 --> Helper loaded: file_helper
INFO - 2022-07-18 08:49:23 --> Database Driver Class Initialized
INFO - 2022-07-18 08:49:23 --> Email Class Initialized
DEBUG - 2022-07-18 08:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:49:23 --> Controller Class Initialized
INFO - 2022-07-18 08:49:23 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:49:23 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 14:19:23 --> Final output sent to browser
DEBUG - 2022-07-18 14:19:23 --> Total execution time: 0.1394
INFO - 2022-07-18 08:49:23 --> Config Class Initialized
INFO - 2022-07-18 08:49:23 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:49:23 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:49:23 --> Utf8 Class Initialized
INFO - 2022-07-18 08:49:23 --> URI Class Initialized
INFO - 2022-07-18 08:49:23 --> Router Class Initialized
INFO - 2022-07-18 08:49:23 --> Output Class Initialized
INFO - 2022-07-18 08:49:23 --> Security Class Initialized
DEBUG - 2022-07-18 08:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:49:23 --> Input Class Initialized
INFO - 2022-07-18 08:49:23 --> Language Class Initialized
INFO - 2022-07-18 08:49:23 --> Loader Class Initialized
INFO - 2022-07-18 08:49:23 --> Helper loaded: url_helper
INFO - 2022-07-18 08:49:23 --> Helper loaded: file_helper
INFO - 2022-07-18 08:49:23 --> Database Driver Class Initialized
INFO - 2022-07-18 08:49:23 --> Email Class Initialized
DEBUG - 2022-07-18 08:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:49:23 --> Controller Class Initialized
INFO - 2022-07-18 08:49:23 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:49:23 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 14:19:23 --> Final output sent to browser
DEBUG - 2022-07-18 14:19:23 --> Total execution time: 0.0168
INFO - 2022-07-18 08:49:25 --> Config Class Initialized
INFO - 2022-07-18 08:49:25 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:49:25 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:49:25 --> Utf8 Class Initialized
INFO - 2022-07-18 08:49:25 --> URI Class Initialized
INFO - 2022-07-18 08:49:25 --> Router Class Initialized
INFO - 2022-07-18 08:49:25 --> Output Class Initialized
INFO - 2022-07-18 08:49:25 --> Security Class Initialized
DEBUG - 2022-07-18 08:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:49:25 --> Input Class Initialized
INFO - 2022-07-18 08:49:25 --> Language Class Initialized
INFO - 2022-07-18 08:49:25 --> Loader Class Initialized
INFO - 2022-07-18 08:49:25 --> Helper loaded: url_helper
INFO - 2022-07-18 08:49:25 --> Helper loaded: file_helper
INFO - 2022-07-18 08:49:25 --> Database Driver Class Initialized
INFO - 2022-07-18 08:49:25 --> Email Class Initialized
DEBUG - 2022-07-18 08:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:49:25 --> Controller Class Initialized
INFO - 2022-07-18 08:49:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:49:25 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:49:25 --> Final output sent to browser
DEBUG - 2022-07-18 08:49:25 --> Total execution time: 0.0166
INFO - 2022-07-18 08:49:25 --> Config Class Initialized
INFO - 2022-07-18 08:49:25 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:49:25 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:49:25 --> Utf8 Class Initialized
INFO - 2022-07-18 08:49:25 --> URI Class Initialized
INFO - 2022-07-18 08:49:25 --> Router Class Initialized
INFO - 2022-07-18 08:49:25 --> Output Class Initialized
INFO - 2022-07-18 08:49:25 --> Security Class Initialized
DEBUG - 2022-07-18 08:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:49:25 --> Input Class Initialized
INFO - 2022-07-18 08:49:25 --> Language Class Initialized
INFO - 2022-07-18 08:49:25 --> Loader Class Initialized
INFO - 2022-07-18 08:49:25 --> Helper loaded: url_helper
INFO - 2022-07-18 08:49:25 --> Helper loaded: file_helper
INFO - 2022-07-18 08:49:25 --> Database Driver Class Initialized
INFO - 2022-07-18 08:49:25 --> Email Class Initialized
DEBUG - 2022-07-18 08:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:49:25 --> Controller Class Initialized
INFO - 2022-07-18 08:49:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:49:25 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:49:25 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-18 08:49:25 --> Final output sent to browser
DEBUG - 2022-07-18 08:49:25 --> Total execution time: 0.0251
INFO - 2022-07-18 08:49:27 --> Config Class Initialized
INFO - 2022-07-18 08:49:27 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:49:27 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:49:27 --> Utf8 Class Initialized
INFO - 2022-07-18 08:49:27 --> URI Class Initialized
INFO - 2022-07-18 08:49:27 --> Router Class Initialized
INFO - 2022-07-18 08:49:27 --> Output Class Initialized
INFO - 2022-07-18 08:49:27 --> Security Class Initialized
DEBUG - 2022-07-18 08:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:49:27 --> Input Class Initialized
INFO - 2022-07-18 08:49:27 --> Language Class Initialized
INFO - 2022-07-18 08:49:27 --> Loader Class Initialized
INFO - 2022-07-18 08:49:27 --> Helper loaded: url_helper
INFO - 2022-07-18 08:49:27 --> Helper loaded: file_helper
INFO - 2022-07-18 08:49:27 --> Database Driver Class Initialized
INFO - 2022-07-18 08:49:27 --> Email Class Initialized
DEBUG - 2022-07-18 08:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 08:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 08:49:27 --> Controller Class Initialized
INFO - 2022-07-18 08:49:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 08:49:27 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 08:49:27 --> Final output sent to browser
DEBUG - 2022-07-18 08:49:27 --> Total execution time: 0.0419
INFO - 2022-07-18 08:49:30 --> Config Class Initialized
INFO - 2022-07-18 08:49:30 --> Hooks Class Initialized
DEBUG - 2022-07-18 08:49:30 --> UTF-8 Support Enabled
INFO - 2022-07-18 08:49:30 --> Utf8 Class Initialized
INFO - 2022-07-18 08:49:30 --> URI Class Initialized
INFO - 2022-07-18 08:49:30 --> Router Class Initialized
INFO - 2022-07-18 08:49:30 --> Output Class Initialized
INFO - 2022-07-18 08:49:30 --> Security Class Initialized
DEBUG - 2022-07-18 08:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 08:49:30 --> Input Class Initialized
INFO - 2022-07-18 08:49:30 --> Language Class Initialized
ERROR - 2022-07-18 08:49:30 --> 404 Page Not Found: Tokenctrl/ya.jpg
INFO - 2022-07-18 09:08:02 --> Config Class Initialized
INFO - 2022-07-18 09:08:02 --> Hooks Class Initialized
DEBUG - 2022-07-18 09:08:02 --> UTF-8 Support Enabled
INFO - 2022-07-18 09:08:02 --> Utf8 Class Initialized
INFO - 2022-07-18 09:08:02 --> URI Class Initialized
INFO - 2022-07-18 09:08:02 --> Router Class Initialized
INFO - 2022-07-18 09:08:02 --> Output Class Initialized
INFO - 2022-07-18 09:08:02 --> Security Class Initialized
DEBUG - 2022-07-18 09:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 09:08:02 --> Input Class Initialized
INFO - 2022-07-18 09:08:02 --> Language Class Initialized
INFO - 2022-07-18 09:08:02 --> Loader Class Initialized
INFO - 2022-07-18 09:08:02 --> Helper loaded: url_helper
INFO - 2022-07-18 09:08:02 --> Helper loaded: file_helper
INFO - 2022-07-18 09:08:02 --> Database Driver Class Initialized
INFO - 2022-07-18 09:08:02 --> Email Class Initialized
DEBUG - 2022-07-18 09:08:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 09:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 09:08:02 --> Controller Class Initialized
INFO - 2022-07-18 09:08:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 09:08:02 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 09:08:02 --> Final output sent to browser
DEBUG - 2022-07-18 09:08:02 --> Total execution time: 0.0404
INFO - 2022-07-18 09:08:06 --> Config Class Initialized
INFO - 2022-07-18 09:08:06 --> Hooks Class Initialized
DEBUG - 2022-07-18 09:08:06 --> UTF-8 Support Enabled
INFO - 2022-07-18 09:08:06 --> Utf8 Class Initialized
INFO - 2022-07-18 09:08:06 --> URI Class Initialized
INFO - 2022-07-18 09:08:06 --> Router Class Initialized
INFO - 2022-07-18 09:08:06 --> Output Class Initialized
INFO - 2022-07-18 09:08:06 --> Security Class Initialized
DEBUG - 2022-07-18 09:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 09:08:06 --> Input Class Initialized
INFO - 2022-07-18 09:08:06 --> Language Class Initialized
INFO - 2022-07-18 09:08:06 --> Loader Class Initialized
INFO - 2022-07-18 09:08:06 --> Helper loaded: url_helper
INFO - 2022-07-18 09:08:06 --> Helper loaded: file_helper
INFO - 2022-07-18 09:08:06 --> Database Driver Class Initialized
INFO - 2022-07-18 09:08:06 --> Email Class Initialized
DEBUG - 2022-07-18 09:08:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 09:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 09:08:06 --> Controller Class Initialized
INFO - 2022-07-18 09:08:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 09:08:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-18 14:38:06 --> Severity: Notice --> Undefined variable: requested_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
ERROR - 2022-07-18 14:38:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 623
INFO - 2022-07-18 14:38:06 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 14:38:06 --> Final output sent to browser
DEBUG - 2022-07-18 14:38:06 --> Total execution time: 0.1431
INFO - 2022-07-18 09:08:17 --> Config Class Initialized
INFO - 2022-07-18 09:08:17 --> Hooks Class Initialized
DEBUG - 2022-07-18 09:08:17 --> UTF-8 Support Enabled
INFO - 2022-07-18 09:08:17 --> Utf8 Class Initialized
INFO - 2022-07-18 09:08:17 --> URI Class Initialized
INFO - 2022-07-18 09:08:17 --> Router Class Initialized
INFO - 2022-07-18 09:08:17 --> Output Class Initialized
INFO - 2022-07-18 09:08:17 --> Security Class Initialized
DEBUG - 2022-07-18 09:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-18 09:08:17 --> Input Class Initialized
INFO - 2022-07-18 09:08:17 --> Language Class Initialized
INFO - 2022-07-18 09:08:17 --> Loader Class Initialized
INFO - 2022-07-18 09:08:17 --> Helper loaded: url_helper
INFO - 2022-07-18 09:08:17 --> Helper loaded: file_helper
INFO - 2022-07-18 09:08:17 --> Database Driver Class Initialized
INFO - 2022-07-18 09:08:17 --> Email Class Initialized
DEBUG - 2022-07-18 09:08:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-18 09:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-18 09:08:17 --> Controller Class Initialized
INFO - 2022-07-18 09:08:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-18 09:08:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-18 14:38:17 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-18 14:38:17 --> Final output sent to browser
DEBUG - 2022-07-18 14:38:17 --> Total execution time: 0.0451
