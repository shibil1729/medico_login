<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-06-27 04:07:06 --> Config Class Initialized
INFO - 2022-06-27 04:07:06 --> Hooks Class Initialized
DEBUG - 2022-06-27 04:07:06 --> UTF-8 Support Enabled
INFO - 2022-06-27 04:07:06 --> Utf8 Class Initialized
INFO - 2022-06-27 04:07:06 --> URI Class Initialized
INFO - 2022-06-27 04:07:06 --> Router Class Initialized
INFO - 2022-06-27 04:07:06 --> Output Class Initialized
INFO - 2022-06-27 04:07:06 --> Security Class Initialized
DEBUG - 2022-06-27 04:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 04:07:06 --> Input Class Initialized
INFO - 2022-06-27 04:07:06 --> Language Class Initialized
ERROR - 2022-06-27 04:07:06 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ')' C:\wamp64\www\qr\application\controllers\Tokenctrl.php 77
INFO - 2022-06-27 04:07:32 --> Config Class Initialized
INFO - 2022-06-27 04:07:32 --> Hooks Class Initialized
DEBUG - 2022-06-27 04:07:32 --> UTF-8 Support Enabled
INFO - 2022-06-27 04:07:32 --> Utf8 Class Initialized
INFO - 2022-06-27 04:07:32 --> URI Class Initialized
INFO - 2022-06-27 04:07:32 --> Router Class Initialized
INFO - 2022-06-27 04:07:32 --> Output Class Initialized
INFO - 2022-06-27 04:07:32 --> Security Class Initialized
DEBUG - 2022-06-27 04:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 04:07:32 --> Input Class Initialized
INFO - 2022-06-27 04:07:32 --> Language Class Initialized
INFO - 2022-06-27 04:07:32 --> Loader Class Initialized
INFO - 2022-06-27 04:07:32 --> Helper loaded: url_helper
INFO - 2022-06-27 04:07:32 --> Helper loaded: file_helper
INFO - 2022-06-27 04:07:33 --> Database Driver Class Initialized
INFO - 2022-06-27 04:07:34 --> Email Class Initialized
DEBUG - 2022-06-27 04:07:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 04:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 04:07:34 --> Controller Class Initialized
INFO - 2022-06-27 04:07:34 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 04:07:34 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 04:07:35 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 04:07:35 --> Final output sent to browser
DEBUG - 2022-06-27 04:07:35 --> Total execution time: 2.5996
INFO - 2022-06-27 04:07:35 --> Config Class Initialized
INFO - 2022-06-27 04:07:35 --> Hooks Class Initialized
DEBUG - 2022-06-27 04:07:35 --> UTF-8 Support Enabled
INFO - 2022-06-27 04:07:35 --> Utf8 Class Initialized
INFO - 2022-06-27 04:07:35 --> URI Class Initialized
INFO - 2022-06-27 04:07:35 --> Router Class Initialized
INFO - 2022-06-27 04:07:35 --> Output Class Initialized
INFO - 2022-06-27 04:07:35 --> Security Class Initialized
DEBUG - 2022-06-27 04:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 04:07:35 --> Input Class Initialized
INFO - 2022-06-27 04:07:35 --> Language Class Initialized
ERROR - 2022-06-27 04:07:35 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 04:07:35 --> Config Class Initialized
INFO - 2022-06-27 04:07:35 --> Hooks Class Initialized
DEBUG - 2022-06-27 04:07:35 --> UTF-8 Support Enabled
INFO - 2022-06-27 04:07:35 --> Utf8 Class Initialized
INFO - 2022-06-27 04:07:35 --> URI Class Initialized
INFO - 2022-06-27 04:07:35 --> Router Class Initialized
INFO - 2022-06-27 04:07:35 --> Output Class Initialized
INFO - 2022-06-27 04:07:35 --> Security Class Initialized
DEBUG - 2022-06-27 04:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 04:07:35 --> Input Class Initialized
INFO - 2022-06-27 04:07:35 --> Language Class Initialized
ERROR - 2022-06-27 04:07:35 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 04:10:00 --> Config Class Initialized
INFO - 2022-06-27 04:10:00 --> Hooks Class Initialized
DEBUG - 2022-06-27 04:10:00 --> UTF-8 Support Enabled
INFO - 2022-06-27 04:10:00 --> Utf8 Class Initialized
INFO - 2022-06-27 04:10:00 --> URI Class Initialized
INFO - 2022-06-27 04:10:00 --> Router Class Initialized
INFO - 2022-06-27 04:10:00 --> Output Class Initialized
INFO - 2022-06-27 04:10:00 --> Security Class Initialized
DEBUG - 2022-06-27 04:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 04:10:00 --> Input Class Initialized
INFO - 2022-06-27 04:10:00 --> Language Class Initialized
INFO - 2022-06-27 04:10:00 --> Loader Class Initialized
INFO - 2022-06-27 04:10:00 --> Helper loaded: url_helper
INFO - 2022-06-27 04:10:00 --> Helper loaded: file_helper
INFO - 2022-06-27 04:10:00 --> Database Driver Class Initialized
INFO - 2022-06-27 04:10:00 --> Email Class Initialized
DEBUG - 2022-06-27 04:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 04:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 04:10:00 --> Controller Class Initialized
INFO - 2022-06-27 04:10:00 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 04:10:00 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 04:10:00 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 04:10:00 --> Final output sent to browser
DEBUG - 2022-06-27 04:10:00 --> Total execution time: 0.3050
INFO - 2022-06-27 04:10:00 --> Config Class Initialized
INFO - 2022-06-27 04:10:00 --> Hooks Class Initialized
DEBUG - 2022-06-27 04:10:00 --> UTF-8 Support Enabled
INFO - 2022-06-27 04:10:00 --> Utf8 Class Initialized
INFO - 2022-06-27 04:10:00 --> URI Class Initialized
INFO - 2022-06-27 04:10:00 --> Router Class Initialized
INFO - 2022-06-27 04:10:00 --> Output Class Initialized
INFO - 2022-06-27 04:10:00 --> Security Class Initialized
DEBUG - 2022-06-27 04:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 04:10:00 --> Input Class Initialized
INFO - 2022-06-27 04:10:00 --> Language Class Initialized
ERROR - 2022-06-27 04:10:00 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 04:10:01 --> Config Class Initialized
INFO - 2022-06-27 04:10:01 --> Hooks Class Initialized
DEBUG - 2022-06-27 04:10:01 --> UTF-8 Support Enabled
INFO - 2022-06-27 04:10:01 --> Utf8 Class Initialized
INFO - 2022-06-27 04:10:01 --> URI Class Initialized
INFO - 2022-06-27 04:10:01 --> Router Class Initialized
INFO - 2022-06-27 04:10:01 --> Output Class Initialized
INFO - 2022-06-27 04:10:01 --> Security Class Initialized
DEBUG - 2022-06-27 04:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 04:10:01 --> Input Class Initialized
INFO - 2022-06-27 04:10:01 --> Language Class Initialized
ERROR - 2022-06-27 04:10:01 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 04:15:43 --> Config Class Initialized
INFO - 2022-06-27 04:15:43 --> Hooks Class Initialized
DEBUG - 2022-06-27 04:15:43 --> UTF-8 Support Enabled
INFO - 2022-06-27 04:15:43 --> Utf8 Class Initialized
INFO - 2022-06-27 04:15:43 --> URI Class Initialized
INFO - 2022-06-27 04:15:43 --> Router Class Initialized
INFO - 2022-06-27 04:15:43 --> Output Class Initialized
INFO - 2022-06-27 04:15:43 --> Security Class Initialized
DEBUG - 2022-06-27 04:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 04:15:43 --> Input Class Initialized
INFO - 2022-06-27 04:15:43 --> Language Class Initialized
INFO - 2022-06-27 04:15:44 --> Loader Class Initialized
INFO - 2022-06-27 04:15:44 --> Helper loaded: url_helper
INFO - 2022-06-27 04:15:44 --> Helper loaded: file_helper
INFO - 2022-06-27 04:15:44 --> Database Driver Class Initialized
INFO - 2022-06-27 04:15:44 --> Email Class Initialized
DEBUG - 2022-06-27 04:15:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 04:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 04:15:44 --> Controller Class Initialized
INFO - 2022-06-27 04:15:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 04:15:44 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 04:15:44 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 04:15:44 --> Final output sent to browser
DEBUG - 2022-06-27 04:15:44 --> Total execution time: 0.2195
INFO - 2022-06-27 04:15:44 --> Config Class Initialized
INFO - 2022-06-27 04:15:44 --> Hooks Class Initialized
DEBUG - 2022-06-27 04:15:44 --> UTF-8 Support Enabled
INFO - 2022-06-27 04:15:44 --> Utf8 Class Initialized
INFO - 2022-06-27 04:15:44 --> URI Class Initialized
INFO - 2022-06-27 04:15:44 --> Router Class Initialized
INFO - 2022-06-27 04:15:44 --> Output Class Initialized
INFO - 2022-06-27 04:15:44 --> Security Class Initialized
DEBUG - 2022-06-27 04:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 04:15:44 --> Input Class Initialized
INFO - 2022-06-27 04:15:44 --> Language Class Initialized
ERROR - 2022-06-27 04:15:44 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 04:15:44 --> Config Class Initialized
INFO - 2022-06-27 04:15:44 --> Hooks Class Initialized
DEBUG - 2022-06-27 04:15:44 --> UTF-8 Support Enabled
INFO - 2022-06-27 04:15:44 --> Utf8 Class Initialized
INFO - 2022-06-27 04:15:44 --> URI Class Initialized
INFO - 2022-06-27 04:15:44 --> Router Class Initialized
INFO - 2022-06-27 04:15:44 --> Output Class Initialized
INFO - 2022-06-27 04:15:44 --> Security Class Initialized
DEBUG - 2022-06-27 04:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 04:15:44 --> Input Class Initialized
INFO - 2022-06-27 04:15:44 --> Language Class Initialized
ERROR - 2022-06-27 04:15:44 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 04:15:46 --> Config Class Initialized
INFO - 2022-06-27 04:15:46 --> Hooks Class Initialized
DEBUG - 2022-06-27 04:15:46 --> UTF-8 Support Enabled
INFO - 2022-06-27 04:15:46 --> Utf8 Class Initialized
INFO - 2022-06-27 04:15:46 --> URI Class Initialized
INFO - 2022-06-27 04:15:46 --> Router Class Initialized
INFO - 2022-06-27 04:15:46 --> Output Class Initialized
INFO - 2022-06-27 04:15:46 --> Security Class Initialized
DEBUG - 2022-06-27 04:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 04:15:46 --> Input Class Initialized
INFO - 2022-06-27 04:15:46 --> Language Class Initialized
INFO - 2022-06-27 04:15:46 --> Loader Class Initialized
INFO - 2022-06-27 04:15:46 --> Helper loaded: url_helper
INFO - 2022-06-27 04:15:46 --> Helper loaded: file_helper
INFO - 2022-06-27 04:15:46 --> Database Driver Class Initialized
INFO - 2022-06-27 04:15:47 --> Email Class Initialized
DEBUG - 2022-06-27 04:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 04:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 04:15:47 --> Controller Class Initialized
INFO - 2022-06-27 04:15:47 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 04:15:47 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 04:15:47 --> Final output sent to browser
DEBUG - 2022-06-27 04:15:47 --> Total execution time: 0.7346
INFO - 2022-06-27 04:15:53 --> Config Class Initialized
INFO - 2022-06-27 04:15:53 --> Hooks Class Initialized
DEBUG - 2022-06-27 04:15:53 --> UTF-8 Support Enabled
INFO - 2022-06-27 04:15:53 --> Utf8 Class Initialized
INFO - 2022-06-27 04:15:53 --> URI Class Initialized
INFO - 2022-06-27 04:15:53 --> Router Class Initialized
INFO - 2022-06-27 04:15:53 --> Output Class Initialized
INFO - 2022-06-27 04:15:53 --> Security Class Initialized
DEBUG - 2022-06-27 04:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 04:15:53 --> Input Class Initialized
INFO - 2022-06-27 04:15:53 --> Language Class Initialized
INFO - 2022-06-27 04:15:53 --> Loader Class Initialized
INFO - 2022-06-27 04:15:53 --> Helper loaded: url_helper
INFO - 2022-06-27 04:15:53 --> Helper loaded: file_helper
INFO - 2022-06-27 04:15:53 --> Database Driver Class Initialized
INFO - 2022-06-27 04:15:53 --> Email Class Initialized
DEBUG - 2022-06-27 04:15:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 04:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 04:15:53 --> Controller Class Initialized
INFO - 2022-06-27 04:15:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 04:15:53 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 04:15:53 --> Final output sent to browser
DEBUG - 2022-06-27 04:15:53 --> Total execution time: 0.0716
INFO - 2022-06-27 04:16:37 --> Config Class Initialized
INFO - 2022-06-27 04:16:37 --> Hooks Class Initialized
DEBUG - 2022-06-27 04:16:37 --> UTF-8 Support Enabled
INFO - 2022-06-27 04:16:37 --> Utf8 Class Initialized
INFO - 2022-06-27 04:16:37 --> URI Class Initialized
INFO - 2022-06-27 04:16:37 --> Router Class Initialized
INFO - 2022-06-27 04:16:37 --> Output Class Initialized
INFO - 2022-06-27 04:16:37 --> Security Class Initialized
DEBUG - 2022-06-27 04:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 04:16:37 --> Input Class Initialized
INFO - 2022-06-27 04:16:37 --> Language Class Initialized
INFO - 2022-06-27 04:16:37 --> Loader Class Initialized
INFO - 2022-06-27 04:16:37 --> Helper loaded: url_helper
INFO - 2022-06-27 04:16:37 --> Helper loaded: file_helper
INFO - 2022-06-27 04:16:37 --> Database Driver Class Initialized
INFO - 2022-06-27 04:16:37 --> Email Class Initialized
DEBUG - 2022-06-27 04:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 04:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 04:16:37 --> Controller Class Initialized
INFO - 2022-06-27 04:16:37 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 04:16:37 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 04:16:37 --> Final output sent to browser
DEBUG - 2022-06-27 04:16:37 --> Total execution time: 0.1695
INFO - 2022-06-27 04:16:56 --> Config Class Initialized
INFO - 2022-06-27 04:16:56 --> Hooks Class Initialized
DEBUG - 2022-06-27 04:16:56 --> UTF-8 Support Enabled
INFO - 2022-06-27 04:16:56 --> Utf8 Class Initialized
INFO - 2022-06-27 04:16:56 --> URI Class Initialized
INFO - 2022-06-27 04:16:56 --> Router Class Initialized
INFO - 2022-06-27 04:16:56 --> Output Class Initialized
INFO - 2022-06-27 04:16:56 --> Security Class Initialized
DEBUG - 2022-06-27 04:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 04:16:56 --> Input Class Initialized
INFO - 2022-06-27 04:16:56 --> Language Class Initialized
INFO - 2022-06-27 04:16:56 --> Loader Class Initialized
INFO - 2022-06-27 04:16:56 --> Helper loaded: url_helper
INFO - 2022-06-27 04:16:56 --> Helper loaded: file_helper
INFO - 2022-06-27 04:16:56 --> Database Driver Class Initialized
INFO - 2022-06-27 04:16:56 --> Email Class Initialized
DEBUG - 2022-06-27 04:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 04:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 04:16:56 --> Controller Class Initialized
INFO - 2022-06-27 04:16:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 04:16:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 04:16:56 --> Final output sent to browser
DEBUG - 2022-06-27 04:16:56 --> Total execution time: 0.1777
INFO - 2022-06-27 04:18:03 --> Config Class Initialized
INFO - 2022-06-27 04:18:03 --> Hooks Class Initialized
DEBUG - 2022-06-27 04:18:03 --> UTF-8 Support Enabled
INFO - 2022-06-27 04:18:03 --> Utf8 Class Initialized
INFO - 2022-06-27 04:18:03 --> URI Class Initialized
INFO - 2022-06-27 04:18:03 --> Router Class Initialized
INFO - 2022-06-27 04:18:03 --> Output Class Initialized
INFO - 2022-06-27 04:18:03 --> Security Class Initialized
DEBUG - 2022-06-27 04:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 04:18:03 --> Input Class Initialized
INFO - 2022-06-27 04:18:03 --> Language Class Initialized
INFO - 2022-06-27 04:18:03 --> Loader Class Initialized
INFO - 2022-06-27 04:18:03 --> Helper loaded: url_helper
INFO - 2022-06-27 04:18:03 --> Helper loaded: file_helper
INFO - 2022-06-27 04:18:03 --> Database Driver Class Initialized
INFO - 2022-06-27 04:18:05 --> Email Class Initialized
DEBUG - 2022-06-27 04:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 04:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 04:18:05 --> Controller Class Initialized
INFO - 2022-06-27 04:18:05 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 04:18:05 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 04:18:05 --> Final output sent to browser
DEBUG - 2022-06-27 04:18:05 --> Total execution time: 1.7147
INFO - 2022-06-27 04:26:27 --> Config Class Initialized
INFO - 2022-06-27 04:26:27 --> Hooks Class Initialized
DEBUG - 2022-06-27 04:26:27 --> UTF-8 Support Enabled
INFO - 2022-06-27 04:26:27 --> Utf8 Class Initialized
INFO - 2022-06-27 04:26:27 --> URI Class Initialized
INFO - 2022-06-27 04:26:27 --> Router Class Initialized
INFO - 2022-06-27 04:26:27 --> Output Class Initialized
INFO - 2022-06-27 04:26:27 --> Security Class Initialized
DEBUG - 2022-06-27 04:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 04:26:27 --> Input Class Initialized
INFO - 2022-06-27 04:26:27 --> Language Class Initialized
INFO - 2022-06-27 04:26:27 --> Loader Class Initialized
INFO - 2022-06-27 04:26:27 --> Helper loaded: url_helper
INFO - 2022-06-27 04:26:27 --> Helper loaded: file_helper
INFO - 2022-06-27 04:26:27 --> Database Driver Class Initialized
INFO - 2022-06-27 04:26:27 --> Email Class Initialized
DEBUG - 2022-06-27 04:26:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 04:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 04:26:27 --> Controller Class Initialized
INFO - 2022-06-27 04:26:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 04:26:27 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 04:26:27 --> Final output sent to browser
DEBUG - 2022-06-27 04:26:27 --> Total execution time: 0.1786
INFO - 2022-06-27 04:26:29 --> Config Class Initialized
INFO - 2022-06-27 04:26:29 --> Hooks Class Initialized
DEBUG - 2022-06-27 04:26:29 --> UTF-8 Support Enabled
INFO - 2022-06-27 04:26:29 --> Utf8 Class Initialized
INFO - 2022-06-27 04:26:29 --> URI Class Initialized
INFO - 2022-06-27 04:26:29 --> Router Class Initialized
INFO - 2022-06-27 04:26:29 --> Output Class Initialized
INFO - 2022-06-27 04:26:29 --> Security Class Initialized
DEBUG - 2022-06-27 04:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 04:26:29 --> Input Class Initialized
INFO - 2022-06-27 04:26:29 --> Language Class Initialized
INFO - 2022-06-27 04:26:29 --> Loader Class Initialized
INFO - 2022-06-27 04:26:29 --> Helper loaded: url_helper
INFO - 2022-06-27 04:26:29 --> Helper loaded: file_helper
INFO - 2022-06-27 04:26:29 --> Database Driver Class Initialized
INFO - 2022-06-27 04:26:29 --> Email Class Initialized
DEBUG - 2022-06-27 04:26:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 04:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 04:26:29 --> Controller Class Initialized
INFO - 2022-06-27 04:26:29 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 04:26:29 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 04:26:29 --> Final output sent to browser
DEBUG - 2022-06-27 04:26:29 --> Total execution time: 0.1638
INFO - 2022-06-27 04:48:10 --> Config Class Initialized
INFO - 2022-06-27 04:48:10 --> Hooks Class Initialized
DEBUG - 2022-06-27 04:48:10 --> UTF-8 Support Enabled
INFO - 2022-06-27 04:48:10 --> Utf8 Class Initialized
INFO - 2022-06-27 04:48:10 --> URI Class Initialized
INFO - 2022-06-27 04:48:10 --> Router Class Initialized
INFO - 2022-06-27 04:48:10 --> Output Class Initialized
INFO - 2022-06-27 04:48:10 --> Security Class Initialized
DEBUG - 2022-06-27 04:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 04:48:10 --> Input Class Initialized
INFO - 2022-06-27 04:48:10 --> Language Class Initialized
INFO - 2022-06-27 04:48:10 --> Loader Class Initialized
INFO - 2022-06-27 04:48:10 --> Helper loaded: url_helper
INFO - 2022-06-27 04:48:10 --> Helper loaded: file_helper
INFO - 2022-06-27 04:48:10 --> Database Driver Class Initialized
INFO - 2022-06-27 04:48:10 --> Email Class Initialized
DEBUG - 2022-06-27 04:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 04:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 04:48:10 --> Controller Class Initialized
INFO - 2022-06-27 04:48:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 04:48:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-27 04:48:10 --> Severity: Notice --> Array to string conversion C:\wamp64\www\qr\application\controllers\Tokenctrl.php 76
INFO - 2022-06-27 04:48:11 --> Final output sent to browser
DEBUG - 2022-06-27 04:48:11 --> Total execution time: 0.2930
INFO - 2022-06-27 04:48:36 --> Config Class Initialized
INFO - 2022-06-27 04:48:36 --> Hooks Class Initialized
DEBUG - 2022-06-27 04:48:36 --> UTF-8 Support Enabled
INFO - 2022-06-27 04:48:36 --> Utf8 Class Initialized
INFO - 2022-06-27 04:48:36 --> URI Class Initialized
INFO - 2022-06-27 04:48:36 --> Router Class Initialized
INFO - 2022-06-27 04:48:36 --> Output Class Initialized
INFO - 2022-06-27 04:48:36 --> Security Class Initialized
DEBUG - 2022-06-27 04:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 04:48:36 --> Input Class Initialized
INFO - 2022-06-27 04:48:36 --> Language Class Initialized
INFO - 2022-06-27 04:48:36 --> Loader Class Initialized
INFO - 2022-06-27 04:48:36 --> Helper loaded: url_helper
INFO - 2022-06-27 04:48:36 --> Helper loaded: file_helper
INFO - 2022-06-27 04:48:36 --> Database Driver Class Initialized
INFO - 2022-06-27 04:48:36 --> Email Class Initialized
DEBUG - 2022-06-27 04:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 04:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 04:48:36 --> Controller Class Initialized
INFO - 2022-06-27 04:48:36 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 04:48:36 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 04:48:36 --> Final output sent to browser
DEBUG - 2022-06-27 04:48:36 --> Total execution time: 0.4048
INFO - 2022-06-27 04:48:55 --> Config Class Initialized
INFO - 2022-06-27 04:48:55 --> Hooks Class Initialized
DEBUG - 2022-06-27 04:48:55 --> UTF-8 Support Enabled
INFO - 2022-06-27 04:48:55 --> Utf8 Class Initialized
INFO - 2022-06-27 04:48:55 --> URI Class Initialized
INFO - 2022-06-27 04:48:55 --> Router Class Initialized
INFO - 2022-06-27 04:48:55 --> Output Class Initialized
INFO - 2022-06-27 04:48:55 --> Security Class Initialized
DEBUG - 2022-06-27 04:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 04:48:55 --> Input Class Initialized
INFO - 2022-06-27 04:48:55 --> Language Class Initialized
INFO - 2022-06-27 04:48:55 --> Loader Class Initialized
INFO - 2022-06-27 04:48:55 --> Helper loaded: url_helper
INFO - 2022-06-27 04:48:55 --> Helper loaded: file_helper
INFO - 2022-06-27 04:48:55 --> Database Driver Class Initialized
INFO - 2022-06-27 04:48:55 --> Email Class Initialized
DEBUG - 2022-06-27 04:48:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 04:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 04:48:55 --> Controller Class Initialized
INFO - 2022-06-27 04:48:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 04:48:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-27 04:48:55 --> Severity: Notice --> Uninitialized string offset: 2 C:\wamp64\www\qr\application\controllers\Tokenctrl.php 76
INFO - 2022-06-27 04:48:55 --> Final output sent to browser
DEBUG - 2022-06-27 04:48:55 --> Total execution time: 0.1081
INFO - 2022-06-27 04:49:29 --> Config Class Initialized
INFO - 2022-06-27 04:49:29 --> Hooks Class Initialized
DEBUG - 2022-06-27 04:49:29 --> UTF-8 Support Enabled
INFO - 2022-06-27 04:49:29 --> Utf8 Class Initialized
INFO - 2022-06-27 04:49:29 --> URI Class Initialized
INFO - 2022-06-27 04:49:29 --> Router Class Initialized
INFO - 2022-06-27 04:49:29 --> Output Class Initialized
INFO - 2022-06-27 04:49:29 --> Security Class Initialized
DEBUG - 2022-06-27 04:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 04:49:29 --> Input Class Initialized
INFO - 2022-06-27 04:49:29 --> Language Class Initialized
INFO - 2022-06-27 04:49:29 --> Loader Class Initialized
INFO - 2022-06-27 04:49:29 --> Helper loaded: url_helper
INFO - 2022-06-27 04:49:29 --> Helper loaded: file_helper
INFO - 2022-06-27 04:49:29 --> Database Driver Class Initialized
INFO - 2022-06-27 04:49:29 --> Email Class Initialized
DEBUG - 2022-06-27 04:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 04:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 04:49:29 --> Controller Class Initialized
INFO - 2022-06-27 04:49:29 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 04:49:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-27 04:49:29 --> Severity: Notice --> Uninitialized string offset: 2 C:\wamp64\www\qr\application\controllers\Tokenctrl.php 76
INFO - 2022-06-27 04:49:29 --> Final output sent to browser
DEBUG - 2022-06-27 04:49:29 --> Total execution time: 0.1126
INFO - 2022-06-27 04:49:30 --> Config Class Initialized
INFO - 2022-06-27 04:49:30 --> Hooks Class Initialized
DEBUG - 2022-06-27 04:49:30 --> UTF-8 Support Enabled
INFO - 2022-06-27 04:49:30 --> Utf8 Class Initialized
INFO - 2022-06-27 04:49:30 --> URI Class Initialized
INFO - 2022-06-27 04:49:30 --> Router Class Initialized
INFO - 2022-06-27 04:49:30 --> Output Class Initialized
INFO - 2022-06-27 04:49:30 --> Security Class Initialized
DEBUG - 2022-06-27 04:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 04:49:30 --> Input Class Initialized
INFO - 2022-06-27 04:49:30 --> Language Class Initialized
INFO - 2022-06-27 04:49:30 --> Loader Class Initialized
INFO - 2022-06-27 04:49:30 --> Helper loaded: url_helper
INFO - 2022-06-27 04:49:30 --> Helper loaded: file_helper
INFO - 2022-06-27 04:49:30 --> Database Driver Class Initialized
INFO - 2022-06-27 04:49:30 --> Email Class Initialized
DEBUG - 2022-06-27 04:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 04:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 04:49:30 --> Controller Class Initialized
INFO - 2022-06-27 04:49:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 04:49:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-27 04:49:30 --> Severity: Notice --> Uninitialized string offset: 2 C:\wamp64\www\qr\application\controllers\Tokenctrl.php 76
INFO - 2022-06-27 04:49:30 --> Final output sent to browser
DEBUG - 2022-06-27 04:49:30 --> Total execution time: 0.1196
INFO - 2022-06-27 04:49:32 --> Config Class Initialized
INFO - 2022-06-27 04:49:32 --> Hooks Class Initialized
DEBUG - 2022-06-27 04:49:32 --> UTF-8 Support Enabled
INFO - 2022-06-27 04:49:32 --> Utf8 Class Initialized
INFO - 2022-06-27 04:49:32 --> URI Class Initialized
INFO - 2022-06-27 04:49:32 --> Router Class Initialized
INFO - 2022-06-27 04:49:32 --> Output Class Initialized
INFO - 2022-06-27 04:49:32 --> Security Class Initialized
DEBUG - 2022-06-27 04:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 04:49:32 --> Input Class Initialized
INFO - 2022-06-27 04:49:32 --> Language Class Initialized
INFO - 2022-06-27 04:49:32 --> Loader Class Initialized
INFO - 2022-06-27 04:49:32 --> Helper loaded: url_helper
INFO - 2022-06-27 04:49:32 --> Helper loaded: file_helper
INFO - 2022-06-27 04:49:32 --> Database Driver Class Initialized
INFO - 2022-06-27 04:49:32 --> Email Class Initialized
DEBUG - 2022-06-27 04:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 04:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 04:49:32 --> Controller Class Initialized
INFO - 2022-06-27 04:49:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 04:49:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-27 04:49:32 --> Severity: Notice --> Uninitialized string offset: 2 C:\wamp64\www\qr\application\controllers\Tokenctrl.php 76
INFO - 2022-06-27 04:49:32 --> Final output sent to browser
DEBUG - 2022-06-27 04:49:32 --> Total execution time: 0.1668
INFO - 2022-06-27 04:49:32 --> Config Class Initialized
INFO - 2022-06-27 04:49:32 --> Hooks Class Initialized
DEBUG - 2022-06-27 04:49:32 --> UTF-8 Support Enabled
INFO - 2022-06-27 04:49:32 --> Utf8 Class Initialized
INFO - 2022-06-27 04:49:32 --> URI Class Initialized
INFO - 2022-06-27 04:49:32 --> Router Class Initialized
INFO - 2022-06-27 04:49:32 --> Output Class Initialized
INFO - 2022-06-27 04:49:32 --> Security Class Initialized
DEBUG - 2022-06-27 04:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 04:49:32 --> Input Class Initialized
INFO - 2022-06-27 04:49:32 --> Language Class Initialized
INFO - 2022-06-27 04:49:32 --> Loader Class Initialized
INFO - 2022-06-27 04:49:32 --> Helper loaded: url_helper
INFO - 2022-06-27 04:49:32 --> Helper loaded: file_helper
INFO - 2022-06-27 04:49:32 --> Database Driver Class Initialized
INFO - 2022-06-27 04:49:32 --> Email Class Initialized
DEBUG - 2022-06-27 04:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 04:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 04:49:32 --> Controller Class Initialized
INFO - 2022-06-27 04:49:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 04:49:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-27 04:49:32 --> Severity: Notice --> Uninitialized string offset: 2 C:\wamp64\www\qr\application\controllers\Tokenctrl.php 76
INFO - 2022-06-27 04:49:32 --> Final output sent to browser
DEBUG - 2022-06-27 04:49:32 --> Total execution time: 0.1587
INFO - 2022-06-27 04:49:32 --> Config Class Initialized
INFO - 2022-06-27 04:49:32 --> Hooks Class Initialized
DEBUG - 2022-06-27 04:49:32 --> UTF-8 Support Enabled
INFO - 2022-06-27 04:49:32 --> Utf8 Class Initialized
INFO - 2022-06-27 04:49:32 --> URI Class Initialized
INFO - 2022-06-27 04:49:32 --> Router Class Initialized
INFO - 2022-06-27 04:49:32 --> Output Class Initialized
INFO - 2022-06-27 04:49:32 --> Security Class Initialized
DEBUG - 2022-06-27 04:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 04:49:32 --> Input Class Initialized
INFO - 2022-06-27 04:49:32 --> Language Class Initialized
INFO - 2022-06-27 04:49:32 --> Loader Class Initialized
INFO - 2022-06-27 04:49:32 --> Helper loaded: url_helper
INFO - 2022-06-27 04:49:32 --> Helper loaded: file_helper
INFO - 2022-06-27 04:49:32 --> Database Driver Class Initialized
INFO - 2022-06-27 04:49:32 --> Email Class Initialized
DEBUG - 2022-06-27 04:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 04:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 04:49:32 --> Controller Class Initialized
INFO - 2022-06-27 04:49:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 04:49:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-27 04:49:32 --> Severity: Notice --> Uninitialized string offset: 2 C:\wamp64\www\qr\application\controllers\Tokenctrl.php 76
INFO - 2022-06-27 04:49:32 --> Final output sent to browser
DEBUG - 2022-06-27 04:49:32 --> Total execution time: 0.0368
INFO - 2022-06-27 04:49:32 --> Config Class Initialized
INFO - 2022-06-27 04:49:32 --> Hooks Class Initialized
DEBUG - 2022-06-27 04:49:32 --> UTF-8 Support Enabled
INFO - 2022-06-27 04:49:32 --> Utf8 Class Initialized
INFO - 2022-06-27 04:49:32 --> URI Class Initialized
INFO - 2022-06-27 04:49:32 --> Router Class Initialized
INFO - 2022-06-27 04:49:32 --> Output Class Initialized
INFO - 2022-06-27 04:49:32 --> Security Class Initialized
DEBUG - 2022-06-27 04:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 04:49:32 --> Input Class Initialized
INFO - 2022-06-27 04:49:32 --> Language Class Initialized
INFO - 2022-06-27 04:49:32 --> Loader Class Initialized
INFO - 2022-06-27 04:49:32 --> Helper loaded: url_helper
INFO - 2022-06-27 04:49:32 --> Helper loaded: file_helper
INFO - 2022-06-27 04:49:32 --> Database Driver Class Initialized
INFO - 2022-06-27 04:49:32 --> Email Class Initialized
DEBUG - 2022-06-27 04:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 04:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 04:49:32 --> Controller Class Initialized
INFO - 2022-06-27 04:49:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 04:49:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-27 04:49:32 --> Severity: Notice --> Uninitialized string offset: 2 C:\wamp64\www\qr\application\controllers\Tokenctrl.php 76
INFO - 2022-06-27 04:49:32 --> Final output sent to browser
DEBUG - 2022-06-27 04:49:32 --> Total execution time: 0.0651
INFO - 2022-06-27 04:50:06 --> Config Class Initialized
INFO - 2022-06-27 04:50:06 --> Hooks Class Initialized
DEBUG - 2022-06-27 04:50:06 --> UTF-8 Support Enabled
INFO - 2022-06-27 04:50:06 --> Utf8 Class Initialized
INFO - 2022-06-27 04:50:06 --> URI Class Initialized
INFO - 2022-06-27 04:50:06 --> Router Class Initialized
INFO - 2022-06-27 04:50:06 --> Output Class Initialized
INFO - 2022-06-27 04:50:06 --> Security Class Initialized
DEBUG - 2022-06-27 04:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 04:50:06 --> Input Class Initialized
INFO - 2022-06-27 04:50:06 --> Language Class Initialized
INFO - 2022-06-27 04:50:06 --> Loader Class Initialized
INFO - 2022-06-27 04:50:06 --> Helper loaded: url_helper
INFO - 2022-06-27 04:50:06 --> Helper loaded: file_helper
INFO - 2022-06-27 04:50:06 --> Database Driver Class Initialized
INFO - 2022-06-27 04:50:06 --> Email Class Initialized
DEBUG - 2022-06-27 04:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 04:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 04:50:06 --> Controller Class Initialized
INFO - 2022-06-27 04:50:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 04:50:06 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 04:50:06 --> Final output sent to browser
DEBUG - 2022-06-27 04:50:06 --> Total execution time: 0.1587
INFO - 2022-06-27 04:50:35 --> Config Class Initialized
INFO - 2022-06-27 04:50:35 --> Hooks Class Initialized
DEBUG - 2022-06-27 04:50:35 --> UTF-8 Support Enabled
INFO - 2022-06-27 04:50:35 --> Utf8 Class Initialized
INFO - 2022-06-27 04:50:35 --> URI Class Initialized
INFO - 2022-06-27 04:50:35 --> Router Class Initialized
INFO - 2022-06-27 04:50:35 --> Output Class Initialized
INFO - 2022-06-27 04:50:35 --> Security Class Initialized
DEBUG - 2022-06-27 04:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 04:50:35 --> Input Class Initialized
INFO - 2022-06-27 04:50:35 --> Language Class Initialized
INFO - 2022-06-27 04:50:35 --> Loader Class Initialized
INFO - 2022-06-27 04:50:35 --> Helper loaded: url_helper
INFO - 2022-06-27 04:50:35 --> Helper loaded: file_helper
INFO - 2022-06-27 04:50:35 --> Database Driver Class Initialized
INFO - 2022-06-27 04:50:35 --> Email Class Initialized
DEBUG - 2022-06-27 04:50:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 04:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 04:50:35 --> Controller Class Initialized
INFO - 2022-06-27 04:50:35 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 04:50:35 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 04:50:35 --> Final output sent to browser
DEBUG - 2022-06-27 04:50:35 --> Total execution time: 0.3541
INFO - 2022-06-27 04:50:39 --> Config Class Initialized
INFO - 2022-06-27 04:50:39 --> Hooks Class Initialized
DEBUG - 2022-06-27 04:50:39 --> UTF-8 Support Enabled
INFO - 2022-06-27 04:50:39 --> Utf8 Class Initialized
INFO - 2022-06-27 04:50:39 --> URI Class Initialized
INFO - 2022-06-27 04:50:39 --> Router Class Initialized
INFO - 2022-06-27 04:50:39 --> Output Class Initialized
INFO - 2022-06-27 04:50:39 --> Security Class Initialized
DEBUG - 2022-06-27 04:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 04:50:39 --> Input Class Initialized
INFO - 2022-06-27 04:50:39 --> Language Class Initialized
INFO - 2022-06-27 04:50:39 --> Loader Class Initialized
INFO - 2022-06-27 04:50:39 --> Helper loaded: url_helper
INFO - 2022-06-27 04:50:39 --> Helper loaded: file_helper
INFO - 2022-06-27 04:50:39 --> Database Driver Class Initialized
INFO - 2022-06-27 04:50:39 --> Email Class Initialized
DEBUG - 2022-06-27 04:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 04:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 04:50:39 --> Controller Class Initialized
INFO - 2022-06-27 04:50:39 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 04:50:39 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 04:50:39 --> Final output sent to browser
DEBUG - 2022-06-27 04:50:39 --> Total execution time: 0.1587
INFO - 2022-06-27 04:51:28 --> Config Class Initialized
INFO - 2022-06-27 04:51:28 --> Hooks Class Initialized
DEBUG - 2022-06-27 04:51:28 --> UTF-8 Support Enabled
INFO - 2022-06-27 04:51:28 --> Utf8 Class Initialized
INFO - 2022-06-27 04:51:28 --> URI Class Initialized
INFO - 2022-06-27 04:51:28 --> Router Class Initialized
INFO - 2022-06-27 04:51:28 --> Output Class Initialized
INFO - 2022-06-27 04:51:28 --> Security Class Initialized
DEBUG - 2022-06-27 04:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 04:51:28 --> Input Class Initialized
INFO - 2022-06-27 04:51:28 --> Language Class Initialized
INFO - 2022-06-27 04:51:28 --> Loader Class Initialized
INFO - 2022-06-27 04:51:28 --> Helper loaded: url_helper
INFO - 2022-06-27 04:51:28 --> Helper loaded: file_helper
INFO - 2022-06-27 04:51:28 --> Database Driver Class Initialized
INFO - 2022-06-27 04:51:28 --> Email Class Initialized
DEBUG - 2022-06-27 04:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 04:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 04:51:28 --> Controller Class Initialized
INFO - 2022-06-27 04:51:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 04:51:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-27 04:51:28 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\wamp64\www\qr\application\controllers\Tokenctrl.php 76
INFO - 2022-06-27 04:51:55 --> Config Class Initialized
INFO - 2022-06-27 04:51:55 --> Hooks Class Initialized
DEBUG - 2022-06-27 04:51:55 --> UTF-8 Support Enabled
INFO - 2022-06-27 04:51:55 --> Utf8 Class Initialized
INFO - 2022-06-27 04:51:55 --> URI Class Initialized
INFO - 2022-06-27 04:51:55 --> Router Class Initialized
INFO - 2022-06-27 04:51:55 --> Output Class Initialized
INFO - 2022-06-27 04:51:55 --> Security Class Initialized
DEBUG - 2022-06-27 04:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 04:51:55 --> Input Class Initialized
INFO - 2022-06-27 04:51:55 --> Language Class Initialized
INFO - 2022-06-27 04:51:55 --> Loader Class Initialized
INFO - 2022-06-27 04:51:55 --> Helper loaded: url_helper
INFO - 2022-06-27 04:51:55 --> Helper loaded: file_helper
INFO - 2022-06-27 04:51:55 --> Database Driver Class Initialized
INFO - 2022-06-27 04:51:55 --> Email Class Initialized
DEBUG - 2022-06-27 04:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 04:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 04:51:55 --> Controller Class Initialized
INFO - 2022-06-27 04:51:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 04:51:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 04:51:55 --> Final output sent to browser
DEBUG - 2022-06-27 04:51:55 --> Total execution time: 0.1392
INFO - 2022-06-27 04:51:56 --> Config Class Initialized
INFO - 2022-06-27 04:51:56 --> Hooks Class Initialized
DEBUG - 2022-06-27 04:51:56 --> UTF-8 Support Enabled
INFO - 2022-06-27 04:51:56 --> Utf8 Class Initialized
INFO - 2022-06-27 04:51:56 --> URI Class Initialized
INFO - 2022-06-27 04:51:56 --> Router Class Initialized
INFO - 2022-06-27 04:51:56 --> Output Class Initialized
INFO - 2022-06-27 04:51:56 --> Security Class Initialized
DEBUG - 2022-06-27 04:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 04:51:56 --> Input Class Initialized
INFO - 2022-06-27 04:51:56 --> Language Class Initialized
INFO - 2022-06-27 04:51:56 --> Loader Class Initialized
INFO - 2022-06-27 04:51:56 --> Helper loaded: url_helper
INFO - 2022-06-27 04:51:56 --> Helper loaded: file_helper
INFO - 2022-06-27 04:51:56 --> Database Driver Class Initialized
INFO - 2022-06-27 04:51:57 --> Email Class Initialized
DEBUG - 2022-06-27 04:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 04:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 04:51:57 --> Controller Class Initialized
INFO - 2022-06-27 04:51:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 04:51:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 04:51:57 --> Final output sent to browser
DEBUG - 2022-06-27 04:51:57 --> Total execution time: 0.1394
INFO - 2022-06-27 04:52:23 --> Config Class Initialized
INFO - 2022-06-27 04:52:23 --> Hooks Class Initialized
DEBUG - 2022-06-27 04:52:23 --> UTF-8 Support Enabled
INFO - 2022-06-27 04:52:23 --> Utf8 Class Initialized
INFO - 2022-06-27 04:52:23 --> URI Class Initialized
INFO - 2022-06-27 04:52:23 --> Router Class Initialized
INFO - 2022-06-27 04:52:23 --> Output Class Initialized
INFO - 2022-06-27 04:52:23 --> Security Class Initialized
DEBUG - 2022-06-27 04:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 04:52:23 --> Input Class Initialized
INFO - 2022-06-27 04:52:23 --> Language Class Initialized
INFO - 2022-06-27 04:52:23 --> Loader Class Initialized
INFO - 2022-06-27 04:52:23 --> Helper loaded: url_helper
INFO - 2022-06-27 04:52:23 --> Helper loaded: file_helper
INFO - 2022-06-27 04:52:23 --> Database Driver Class Initialized
INFO - 2022-06-27 04:52:24 --> Email Class Initialized
DEBUG - 2022-06-27 04:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 04:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 04:52:24 --> Controller Class Initialized
INFO - 2022-06-27 04:52:24 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 04:52:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-27 04:52:24 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::num_row() C:\wamp64\www\qr\application\models\Tokenmodel.php 28
INFO - 2022-06-27 04:52:45 --> Config Class Initialized
INFO - 2022-06-27 04:52:45 --> Hooks Class Initialized
DEBUG - 2022-06-27 04:52:45 --> UTF-8 Support Enabled
INFO - 2022-06-27 04:52:45 --> Utf8 Class Initialized
INFO - 2022-06-27 04:52:45 --> URI Class Initialized
INFO - 2022-06-27 04:52:45 --> Router Class Initialized
INFO - 2022-06-27 04:52:45 --> Output Class Initialized
INFO - 2022-06-27 04:52:45 --> Security Class Initialized
DEBUG - 2022-06-27 04:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 04:52:45 --> Input Class Initialized
INFO - 2022-06-27 04:52:45 --> Language Class Initialized
INFO - 2022-06-27 04:52:45 --> Loader Class Initialized
INFO - 2022-06-27 04:52:45 --> Helper loaded: url_helper
INFO - 2022-06-27 04:52:45 --> Helper loaded: file_helper
INFO - 2022-06-27 04:52:45 --> Database Driver Class Initialized
INFO - 2022-06-27 04:52:45 --> Email Class Initialized
DEBUG - 2022-06-27 04:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 04:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 04:52:45 --> Controller Class Initialized
INFO - 2022-06-27 04:52:45 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 04:52:45 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 04:52:45 --> Final output sent to browser
DEBUG - 2022-06-27 04:52:45 --> Total execution time: 0.1847
INFO - 2022-06-27 04:53:19 --> Config Class Initialized
INFO - 2022-06-27 04:53:19 --> Hooks Class Initialized
DEBUG - 2022-06-27 04:53:19 --> UTF-8 Support Enabled
INFO - 2022-06-27 04:53:19 --> Utf8 Class Initialized
INFO - 2022-06-27 04:53:19 --> URI Class Initialized
INFO - 2022-06-27 04:53:19 --> Router Class Initialized
INFO - 2022-06-27 04:53:19 --> Output Class Initialized
INFO - 2022-06-27 04:53:19 --> Security Class Initialized
DEBUG - 2022-06-27 04:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 04:53:19 --> Input Class Initialized
INFO - 2022-06-27 04:53:19 --> Language Class Initialized
INFO - 2022-06-27 04:53:19 --> Loader Class Initialized
INFO - 2022-06-27 04:53:19 --> Helper loaded: url_helper
INFO - 2022-06-27 04:53:19 --> Helper loaded: file_helper
INFO - 2022-06-27 04:53:19 --> Database Driver Class Initialized
INFO - 2022-06-27 04:53:20 --> Email Class Initialized
DEBUG - 2022-06-27 04:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 04:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 04:53:20 --> Controller Class Initialized
INFO - 2022-06-27 04:53:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 04:53:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-27 04:53:20 --> Severity: Notice --> Undefined index: td_cs C:\wamp64\www\qr\application\controllers\Tokenctrl.php 76
INFO - 2022-06-27 04:53:20 --> Final output sent to browser
DEBUG - 2022-06-27 04:53:20 --> Total execution time: 0.1623
INFO - 2022-06-27 04:54:15 --> Config Class Initialized
INFO - 2022-06-27 04:54:15 --> Hooks Class Initialized
DEBUG - 2022-06-27 04:54:15 --> UTF-8 Support Enabled
INFO - 2022-06-27 04:54:15 --> Utf8 Class Initialized
INFO - 2022-06-27 04:54:15 --> URI Class Initialized
INFO - 2022-06-27 04:54:15 --> Router Class Initialized
INFO - 2022-06-27 04:54:15 --> Output Class Initialized
INFO - 2022-06-27 04:54:15 --> Security Class Initialized
DEBUG - 2022-06-27 04:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 04:54:15 --> Input Class Initialized
INFO - 2022-06-27 04:54:15 --> Language Class Initialized
INFO - 2022-06-27 04:54:15 --> Loader Class Initialized
INFO - 2022-06-27 04:54:15 --> Helper loaded: url_helper
INFO - 2022-06-27 04:54:15 --> Helper loaded: file_helper
INFO - 2022-06-27 04:54:15 --> Database Driver Class Initialized
INFO - 2022-06-27 04:54:15 --> Email Class Initialized
DEBUG - 2022-06-27 04:54:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 04:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 04:54:15 --> Controller Class Initialized
INFO - 2022-06-27 04:54:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 04:54:15 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 04:54:15 --> Final output sent to browser
DEBUG - 2022-06-27 04:54:15 --> Total execution time: 0.0182
INFO - 2022-06-27 05:15:14 --> Config Class Initialized
INFO - 2022-06-27 05:15:14 --> Hooks Class Initialized
DEBUG - 2022-06-27 05:15:14 --> UTF-8 Support Enabled
INFO - 2022-06-27 05:15:14 --> Utf8 Class Initialized
INFO - 2022-06-27 05:15:14 --> URI Class Initialized
INFO - 2022-06-27 05:15:14 --> Router Class Initialized
INFO - 2022-06-27 05:15:14 --> Output Class Initialized
INFO - 2022-06-27 05:15:14 --> Security Class Initialized
DEBUG - 2022-06-27 05:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 05:15:14 --> Input Class Initialized
INFO - 2022-06-27 05:15:14 --> Language Class Initialized
INFO - 2022-06-27 05:15:14 --> Loader Class Initialized
INFO - 2022-06-27 05:15:14 --> Helper loaded: url_helper
INFO - 2022-06-27 05:15:14 --> Helper loaded: file_helper
INFO - 2022-06-27 05:15:14 --> Database Driver Class Initialized
INFO - 2022-06-27 05:15:14 --> Email Class Initialized
DEBUG - 2022-06-27 05:15:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 05:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 05:15:14 --> Controller Class Initialized
INFO - 2022-06-27 05:15:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 05:15:14 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 05:15:14 --> Final output sent to browser
DEBUG - 2022-06-27 05:15:14 --> Total execution time: 0.2968
INFO - 2022-06-27 05:15:16 --> Config Class Initialized
INFO - 2022-06-27 05:15:16 --> Hooks Class Initialized
DEBUG - 2022-06-27 05:15:16 --> UTF-8 Support Enabled
INFO - 2022-06-27 05:15:16 --> Utf8 Class Initialized
INFO - 2022-06-27 05:15:16 --> URI Class Initialized
INFO - 2022-06-27 05:15:16 --> Router Class Initialized
INFO - 2022-06-27 05:15:16 --> Output Class Initialized
INFO - 2022-06-27 05:15:16 --> Security Class Initialized
DEBUG - 2022-06-27 05:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 05:15:16 --> Input Class Initialized
INFO - 2022-06-27 05:15:16 --> Language Class Initialized
INFO - 2022-06-27 05:15:16 --> Loader Class Initialized
INFO - 2022-06-27 05:15:16 --> Helper loaded: url_helper
INFO - 2022-06-27 05:15:16 --> Helper loaded: file_helper
INFO - 2022-06-27 05:15:16 --> Database Driver Class Initialized
INFO - 2022-06-27 05:15:16 --> Email Class Initialized
DEBUG - 2022-06-27 05:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 05:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 05:15:16 --> Controller Class Initialized
INFO - 2022-06-27 05:15:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 05:15:16 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 05:15:16 --> Final output sent to browser
DEBUG - 2022-06-27 05:15:16 --> Total execution time: 0.1161
INFO - 2022-06-27 05:15:17 --> Config Class Initialized
INFO - 2022-06-27 05:15:17 --> Hooks Class Initialized
DEBUG - 2022-06-27 05:15:17 --> UTF-8 Support Enabled
INFO - 2022-06-27 05:15:17 --> Utf8 Class Initialized
INFO - 2022-06-27 05:15:17 --> URI Class Initialized
INFO - 2022-06-27 05:15:17 --> Router Class Initialized
INFO - 2022-06-27 05:15:17 --> Output Class Initialized
INFO - 2022-06-27 05:15:17 --> Security Class Initialized
DEBUG - 2022-06-27 05:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 05:15:17 --> Input Class Initialized
INFO - 2022-06-27 05:15:17 --> Language Class Initialized
INFO - 2022-06-27 05:15:17 --> Loader Class Initialized
INFO - 2022-06-27 05:15:17 --> Helper loaded: url_helper
INFO - 2022-06-27 05:15:17 --> Helper loaded: file_helper
INFO - 2022-06-27 05:15:17 --> Database Driver Class Initialized
INFO - 2022-06-27 05:15:17 --> Email Class Initialized
DEBUG - 2022-06-27 05:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 05:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 05:15:17 --> Controller Class Initialized
INFO - 2022-06-27 05:15:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 05:15:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 05:15:17 --> Final output sent to browser
DEBUG - 2022-06-27 05:15:17 --> Total execution time: 0.0176
INFO - 2022-06-27 05:15:17 --> Config Class Initialized
INFO - 2022-06-27 05:15:17 --> Hooks Class Initialized
DEBUG - 2022-06-27 05:15:17 --> UTF-8 Support Enabled
INFO - 2022-06-27 05:15:17 --> Utf8 Class Initialized
INFO - 2022-06-27 05:15:17 --> URI Class Initialized
INFO - 2022-06-27 05:15:17 --> Router Class Initialized
INFO - 2022-06-27 05:15:17 --> Output Class Initialized
INFO - 2022-06-27 05:15:17 --> Security Class Initialized
DEBUG - 2022-06-27 05:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 05:15:17 --> Input Class Initialized
INFO - 2022-06-27 05:15:17 --> Language Class Initialized
INFO - 2022-06-27 05:15:17 --> Loader Class Initialized
INFO - 2022-06-27 05:15:17 --> Helper loaded: url_helper
INFO - 2022-06-27 05:15:17 --> Helper loaded: file_helper
INFO - 2022-06-27 05:15:17 --> Database Driver Class Initialized
INFO - 2022-06-27 05:15:17 --> Email Class Initialized
DEBUG - 2022-06-27 05:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 05:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 05:15:17 --> Controller Class Initialized
INFO - 2022-06-27 05:15:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 05:15:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 05:15:17 --> Final output sent to browser
DEBUG - 2022-06-27 05:15:17 --> Total execution time: 0.1625
INFO - 2022-06-27 05:15:17 --> Config Class Initialized
INFO - 2022-06-27 05:15:17 --> Hooks Class Initialized
DEBUG - 2022-06-27 05:15:17 --> UTF-8 Support Enabled
INFO - 2022-06-27 05:15:17 --> Utf8 Class Initialized
INFO - 2022-06-27 05:15:17 --> URI Class Initialized
INFO - 2022-06-27 05:15:17 --> Router Class Initialized
INFO - 2022-06-27 05:15:17 --> Output Class Initialized
INFO - 2022-06-27 05:15:17 --> Security Class Initialized
DEBUG - 2022-06-27 05:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 05:15:17 --> Input Class Initialized
INFO - 2022-06-27 05:15:17 --> Language Class Initialized
INFO - 2022-06-27 05:15:17 --> Loader Class Initialized
INFO - 2022-06-27 05:15:17 --> Helper loaded: url_helper
INFO - 2022-06-27 05:15:17 --> Helper loaded: file_helper
INFO - 2022-06-27 05:15:17 --> Database Driver Class Initialized
INFO - 2022-06-27 05:15:17 --> Email Class Initialized
DEBUG - 2022-06-27 05:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 05:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 05:15:17 --> Controller Class Initialized
INFO - 2022-06-27 05:15:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 05:15:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 05:15:17 --> Final output sent to browser
DEBUG - 2022-06-27 05:15:17 --> Total execution time: 0.0717
INFO - 2022-06-27 05:15:17 --> Config Class Initialized
INFO - 2022-06-27 05:15:17 --> Hooks Class Initialized
DEBUG - 2022-06-27 05:15:17 --> UTF-8 Support Enabled
INFO - 2022-06-27 05:15:17 --> Utf8 Class Initialized
INFO - 2022-06-27 05:15:17 --> URI Class Initialized
INFO - 2022-06-27 05:15:17 --> Router Class Initialized
INFO - 2022-06-27 05:15:17 --> Output Class Initialized
INFO - 2022-06-27 05:15:17 --> Security Class Initialized
DEBUG - 2022-06-27 05:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 05:15:17 --> Input Class Initialized
INFO - 2022-06-27 05:15:17 --> Language Class Initialized
INFO - 2022-06-27 05:15:17 --> Loader Class Initialized
INFO - 2022-06-27 05:15:17 --> Helper loaded: url_helper
INFO - 2022-06-27 05:15:17 --> Helper loaded: file_helper
INFO - 2022-06-27 05:15:17 --> Database Driver Class Initialized
INFO - 2022-06-27 05:15:17 --> Email Class Initialized
DEBUG - 2022-06-27 05:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 05:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 05:15:17 --> Controller Class Initialized
INFO - 2022-06-27 05:15:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 05:15:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 05:15:18 --> Final output sent to browser
DEBUG - 2022-06-27 05:15:18 --> Total execution time: 0.0655
INFO - 2022-06-27 05:15:18 --> Config Class Initialized
INFO - 2022-06-27 05:15:18 --> Hooks Class Initialized
DEBUG - 2022-06-27 05:15:18 --> UTF-8 Support Enabled
INFO - 2022-06-27 05:15:18 --> Utf8 Class Initialized
INFO - 2022-06-27 05:15:18 --> URI Class Initialized
INFO - 2022-06-27 05:15:18 --> Router Class Initialized
INFO - 2022-06-27 05:15:18 --> Output Class Initialized
INFO - 2022-06-27 05:15:18 --> Security Class Initialized
DEBUG - 2022-06-27 05:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 05:15:18 --> Input Class Initialized
INFO - 2022-06-27 05:15:18 --> Language Class Initialized
INFO - 2022-06-27 05:15:18 --> Loader Class Initialized
INFO - 2022-06-27 05:15:18 --> Helper loaded: url_helper
INFO - 2022-06-27 05:15:18 --> Helper loaded: file_helper
INFO - 2022-06-27 05:15:18 --> Database Driver Class Initialized
INFO - 2022-06-27 05:15:18 --> Email Class Initialized
DEBUG - 2022-06-27 05:15:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 05:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 05:15:18 --> Controller Class Initialized
INFO - 2022-06-27 05:15:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 05:15:18 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 05:15:18 --> Final output sent to browser
DEBUG - 2022-06-27 05:15:18 --> Total execution time: 0.0668
INFO - 2022-06-27 05:15:18 --> Config Class Initialized
INFO - 2022-06-27 05:15:18 --> Hooks Class Initialized
DEBUG - 2022-06-27 05:15:18 --> UTF-8 Support Enabled
INFO - 2022-06-27 05:15:18 --> Utf8 Class Initialized
INFO - 2022-06-27 05:15:18 --> URI Class Initialized
INFO - 2022-06-27 05:15:18 --> Router Class Initialized
INFO - 2022-06-27 05:15:18 --> Output Class Initialized
INFO - 2022-06-27 05:15:18 --> Security Class Initialized
DEBUG - 2022-06-27 05:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 05:15:18 --> Input Class Initialized
INFO - 2022-06-27 05:15:18 --> Language Class Initialized
INFO - 2022-06-27 05:15:18 --> Loader Class Initialized
INFO - 2022-06-27 05:15:18 --> Helper loaded: url_helper
INFO - 2022-06-27 05:15:18 --> Helper loaded: file_helper
INFO - 2022-06-27 05:15:18 --> Database Driver Class Initialized
INFO - 2022-06-27 05:15:19 --> Email Class Initialized
DEBUG - 2022-06-27 05:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 05:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 05:15:19 --> Controller Class Initialized
INFO - 2022-06-27 05:15:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 05:15:19 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 05:15:19 --> Final output sent to browser
DEBUG - 2022-06-27 05:15:19 --> Total execution time: 0.1377
INFO - 2022-06-27 05:15:19 --> Config Class Initialized
INFO - 2022-06-27 05:15:19 --> Hooks Class Initialized
DEBUG - 2022-06-27 05:15:19 --> UTF-8 Support Enabled
INFO - 2022-06-27 05:15:19 --> Utf8 Class Initialized
INFO - 2022-06-27 05:15:19 --> URI Class Initialized
INFO - 2022-06-27 05:15:19 --> Router Class Initialized
INFO - 2022-06-27 05:15:19 --> Output Class Initialized
INFO - 2022-06-27 05:15:19 --> Security Class Initialized
DEBUG - 2022-06-27 05:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 05:15:19 --> Input Class Initialized
INFO - 2022-06-27 05:15:19 --> Language Class Initialized
INFO - 2022-06-27 05:15:19 --> Loader Class Initialized
INFO - 2022-06-27 05:15:19 --> Helper loaded: url_helper
INFO - 2022-06-27 05:15:19 --> Helper loaded: file_helper
INFO - 2022-06-27 05:15:19 --> Database Driver Class Initialized
INFO - 2022-06-27 05:15:19 --> Email Class Initialized
DEBUG - 2022-06-27 05:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 05:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 05:15:19 --> Controller Class Initialized
INFO - 2022-06-27 05:15:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 05:15:19 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 05:15:19 --> Final output sent to browser
DEBUG - 2022-06-27 05:15:19 --> Total execution time: 0.1323
INFO - 2022-06-27 05:15:32 --> Config Class Initialized
INFO - 2022-06-27 05:15:32 --> Hooks Class Initialized
DEBUG - 2022-06-27 05:15:32 --> UTF-8 Support Enabled
INFO - 2022-06-27 05:15:32 --> Utf8 Class Initialized
INFO - 2022-06-27 05:15:32 --> URI Class Initialized
INFO - 2022-06-27 05:15:32 --> Router Class Initialized
INFO - 2022-06-27 05:15:32 --> Output Class Initialized
INFO - 2022-06-27 05:15:32 --> Security Class Initialized
DEBUG - 2022-06-27 05:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 05:15:32 --> Input Class Initialized
INFO - 2022-06-27 05:15:32 --> Language Class Initialized
INFO - 2022-06-27 05:15:32 --> Loader Class Initialized
INFO - 2022-06-27 05:15:32 --> Helper loaded: url_helper
INFO - 2022-06-27 05:15:32 --> Helper loaded: file_helper
INFO - 2022-06-27 05:15:32 --> Database Driver Class Initialized
INFO - 2022-06-27 05:15:32 --> Email Class Initialized
DEBUG - 2022-06-27 05:15:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 05:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 05:15:32 --> Controller Class Initialized
INFO - 2022-06-27 05:15:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 05:15:32 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 05:15:32 --> Final output sent to browser
DEBUG - 2022-06-27 05:15:32 --> Total execution time: 0.3688
INFO - 2022-06-27 05:17:55 --> Config Class Initialized
INFO - 2022-06-27 05:17:55 --> Hooks Class Initialized
DEBUG - 2022-06-27 05:17:55 --> UTF-8 Support Enabled
INFO - 2022-06-27 05:17:55 --> Utf8 Class Initialized
INFO - 2022-06-27 05:17:55 --> URI Class Initialized
INFO - 2022-06-27 05:17:55 --> Router Class Initialized
INFO - 2022-06-27 05:17:55 --> Output Class Initialized
INFO - 2022-06-27 05:17:55 --> Security Class Initialized
DEBUG - 2022-06-27 05:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 05:17:55 --> Input Class Initialized
INFO - 2022-06-27 05:17:55 --> Language Class Initialized
INFO - 2022-06-27 05:17:55 --> Loader Class Initialized
INFO - 2022-06-27 05:17:55 --> Helper loaded: url_helper
INFO - 2022-06-27 05:17:55 --> Helper loaded: file_helper
INFO - 2022-06-27 05:17:55 --> Database Driver Class Initialized
INFO - 2022-06-27 05:17:55 --> Email Class Initialized
DEBUG - 2022-06-27 05:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 05:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 05:17:55 --> Controller Class Initialized
INFO - 2022-06-27 05:17:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 05:17:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-27 05:17:55 --> Severity: Notice --> Undefined variable: n C:\wamp64\www\qr\application\controllers\Tokenctrl.php 77
INFO - 2022-06-27 05:17:55 --> Final output sent to browser
DEBUG - 2022-06-27 05:17:55 --> Total execution time: 0.1874
INFO - 2022-06-27 05:18:46 --> Config Class Initialized
INFO - 2022-06-27 05:18:46 --> Hooks Class Initialized
DEBUG - 2022-06-27 05:18:46 --> UTF-8 Support Enabled
INFO - 2022-06-27 05:18:46 --> Utf8 Class Initialized
INFO - 2022-06-27 05:18:46 --> URI Class Initialized
INFO - 2022-06-27 05:18:46 --> Router Class Initialized
INFO - 2022-06-27 05:18:46 --> Output Class Initialized
INFO - 2022-06-27 05:18:46 --> Security Class Initialized
DEBUG - 2022-06-27 05:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 05:18:46 --> Input Class Initialized
INFO - 2022-06-27 05:18:46 --> Language Class Initialized
INFO - 2022-06-27 05:18:46 --> Loader Class Initialized
INFO - 2022-06-27 05:18:46 --> Helper loaded: url_helper
INFO - 2022-06-27 05:18:46 --> Helper loaded: file_helper
INFO - 2022-06-27 05:18:46 --> Database Driver Class Initialized
INFO - 2022-06-27 05:18:46 --> Email Class Initialized
DEBUG - 2022-06-27 05:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 05:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 05:18:46 --> Controller Class Initialized
INFO - 2022-06-27 05:18:46 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 05:18:46 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 05:18:46 --> Final output sent to browser
DEBUG - 2022-06-27 05:18:46 --> Total execution time: 0.1367
INFO - 2022-06-27 06:18:08 --> Config Class Initialized
INFO - 2022-06-27 06:18:08 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:18:08 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:18:08 --> Utf8 Class Initialized
INFO - 2022-06-27 06:18:08 --> URI Class Initialized
INFO - 2022-06-27 06:18:08 --> Router Class Initialized
INFO - 2022-06-27 06:18:08 --> Output Class Initialized
INFO - 2022-06-27 06:18:08 --> Security Class Initialized
DEBUG - 2022-06-27 06:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:18:08 --> Input Class Initialized
INFO - 2022-06-27 06:18:08 --> Language Class Initialized
INFO - 2022-06-27 06:18:08 --> Loader Class Initialized
INFO - 2022-06-27 06:18:08 --> Helper loaded: url_helper
INFO - 2022-06-27 06:18:08 --> Helper loaded: file_helper
INFO - 2022-06-27 06:18:08 --> Database Driver Class Initialized
INFO - 2022-06-27 06:18:08 --> Email Class Initialized
DEBUG - 2022-06-27 06:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 06:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 06:18:08 --> Controller Class Initialized
INFO - 2022-06-27 06:18:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 06:18:08 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 06:18:08 --> Final output sent to browser
DEBUG - 2022-06-27 06:18:08 --> Total execution time: 0.2921
INFO - 2022-06-27 06:18:16 --> Config Class Initialized
INFO - 2022-06-27 06:18:16 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:18:16 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:18:16 --> Utf8 Class Initialized
INFO - 2022-06-27 06:18:16 --> URI Class Initialized
INFO - 2022-06-27 06:18:16 --> Router Class Initialized
INFO - 2022-06-27 06:18:16 --> Output Class Initialized
INFO - 2022-06-27 06:18:16 --> Security Class Initialized
DEBUG - 2022-06-27 06:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:18:16 --> Input Class Initialized
INFO - 2022-06-27 06:18:16 --> Language Class Initialized
INFO - 2022-06-27 06:18:16 --> Loader Class Initialized
INFO - 2022-06-27 06:18:16 --> Helper loaded: url_helper
INFO - 2022-06-27 06:18:16 --> Helper loaded: file_helper
INFO - 2022-06-27 06:18:16 --> Database Driver Class Initialized
INFO - 2022-06-27 06:18:16 --> Email Class Initialized
DEBUG - 2022-06-27 06:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 06:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 06:18:16 --> Controller Class Initialized
INFO - 2022-06-27 06:18:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 06:18:16 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 06:18:16 --> Final output sent to browser
DEBUG - 2022-06-27 06:18:16 --> Total execution time: 0.1985
INFO - 2022-06-27 06:23:50 --> Config Class Initialized
INFO - 2022-06-27 06:23:50 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:23:50 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:23:50 --> Utf8 Class Initialized
INFO - 2022-06-27 06:23:50 --> URI Class Initialized
INFO - 2022-06-27 06:23:50 --> Router Class Initialized
INFO - 2022-06-27 06:23:50 --> Output Class Initialized
INFO - 2022-06-27 06:23:50 --> Security Class Initialized
DEBUG - 2022-06-27 06:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:23:50 --> Input Class Initialized
INFO - 2022-06-27 06:23:50 --> Language Class Initialized
INFO - 2022-06-27 06:23:50 --> Loader Class Initialized
INFO - 2022-06-27 06:23:50 --> Helper loaded: url_helper
INFO - 2022-06-27 06:23:50 --> Helper loaded: file_helper
INFO - 2022-06-27 06:23:50 --> Database Driver Class Initialized
INFO - 2022-06-27 06:23:50 --> Email Class Initialized
DEBUG - 2022-06-27 06:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 06:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 06:23:50 --> Controller Class Initialized
INFO - 2022-06-27 06:23:50 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 06:23:50 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 06:23:50 --> Final output sent to browser
DEBUG - 2022-06-27 06:23:50 --> Total execution time: 0.2090
INFO - 2022-06-27 06:27:22 --> Config Class Initialized
INFO - 2022-06-27 06:27:22 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:27:22 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:27:22 --> Utf8 Class Initialized
INFO - 2022-06-27 06:27:22 --> URI Class Initialized
INFO - 2022-06-27 06:27:22 --> Router Class Initialized
INFO - 2022-06-27 06:27:22 --> Output Class Initialized
INFO - 2022-06-27 06:27:22 --> Security Class Initialized
DEBUG - 2022-06-27 06:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:27:22 --> Input Class Initialized
INFO - 2022-06-27 06:27:22 --> Language Class Initialized
INFO - 2022-06-27 06:27:22 --> Loader Class Initialized
INFO - 2022-06-27 06:27:22 --> Helper loaded: url_helper
INFO - 2022-06-27 06:27:22 --> Helper loaded: file_helper
INFO - 2022-06-27 06:27:22 --> Database Driver Class Initialized
INFO - 2022-06-27 06:27:22 --> Email Class Initialized
DEBUG - 2022-06-27 06:27:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 06:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 06:27:22 --> Controller Class Initialized
INFO - 2022-06-27 06:27:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 06:27:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-27 06:27:22 --> Severity: Notice --> Undefined variable: tk C:\wamp64\www\qr\application\views\doc_screen\doctor.php 323
ERROR - 2022-06-27 06:27:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\wamp64\www\qr\application\views\doc_screen\doctor.php 323
ERROR - 2022-06-27 06:27:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\wamp64\www\qr\application\views\doc_screen\doctor.php 323
INFO - 2022-06-27 06:27:22 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 06:27:22 --> Final output sent to browser
DEBUG - 2022-06-27 06:27:22 --> Total execution time: 0.1862
INFO - 2022-06-27 06:27:23 --> Config Class Initialized
INFO - 2022-06-27 06:27:23 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:27:23 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:27:23 --> Utf8 Class Initialized
INFO - 2022-06-27 06:27:23 --> URI Class Initialized
INFO - 2022-06-27 06:27:23 --> Router Class Initialized
INFO - 2022-06-27 06:27:23 --> Output Class Initialized
INFO - 2022-06-27 06:27:23 --> Security Class Initialized
DEBUG - 2022-06-27 06:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:27:23 --> Input Class Initialized
INFO - 2022-06-27 06:27:23 --> Language Class Initialized
ERROR - 2022-06-27 06:27:23 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 06:27:23 --> Config Class Initialized
INFO - 2022-06-27 06:27:23 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:27:23 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:27:23 --> Utf8 Class Initialized
INFO - 2022-06-27 06:27:23 --> URI Class Initialized
INFO - 2022-06-27 06:27:23 --> Router Class Initialized
INFO - 2022-06-27 06:27:23 --> Output Class Initialized
INFO - 2022-06-27 06:27:23 --> Security Class Initialized
DEBUG - 2022-06-27 06:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:27:23 --> Input Class Initialized
INFO - 2022-06-27 06:27:23 --> Language Class Initialized
ERROR - 2022-06-27 06:27:23 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 06:28:07 --> Config Class Initialized
INFO - 2022-06-27 06:28:07 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:28:07 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:28:07 --> Utf8 Class Initialized
INFO - 2022-06-27 06:28:07 --> URI Class Initialized
INFO - 2022-06-27 06:28:07 --> Router Class Initialized
INFO - 2022-06-27 06:28:07 --> Output Class Initialized
INFO - 2022-06-27 06:28:07 --> Security Class Initialized
DEBUG - 2022-06-27 06:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:28:07 --> Input Class Initialized
INFO - 2022-06-27 06:28:07 --> Language Class Initialized
INFO - 2022-06-27 06:28:07 --> Loader Class Initialized
INFO - 2022-06-27 06:28:07 --> Helper loaded: url_helper
INFO - 2022-06-27 06:28:07 --> Helper loaded: file_helper
INFO - 2022-06-27 06:28:07 --> Database Driver Class Initialized
INFO - 2022-06-27 06:28:07 --> Email Class Initialized
DEBUG - 2022-06-27 06:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 06:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 06:28:07 --> Controller Class Initialized
INFO - 2022-06-27 06:28:07 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 06:28:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-27 06:28:07 --> Severity: Notice --> Undefined variable: tk C:\wamp64\www\qr\application\views\doc_screen\doctor.php 323
ERROR - 2022-06-27 06:28:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\wamp64\www\qr\application\views\doc_screen\doctor.php 323
ERROR - 2022-06-27 06:28:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\wamp64\www\qr\application\views\doc_screen\doctor.php 323
INFO - 2022-06-27 06:28:07 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 06:28:07 --> Final output sent to browser
DEBUG - 2022-06-27 06:28:07 --> Total execution time: 0.1603
INFO - 2022-06-27 06:28:08 --> Config Class Initialized
INFO - 2022-06-27 06:28:08 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:28:08 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:28:08 --> Utf8 Class Initialized
INFO - 2022-06-27 06:28:08 --> URI Class Initialized
INFO - 2022-06-27 06:28:08 --> Router Class Initialized
INFO - 2022-06-27 06:28:08 --> Output Class Initialized
INFO - 2022-06-27 06:28:08 --> Security Class Initialized
DEBUG - 2022-06-27 06:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:28:08 --> Input Class Initialized
INFO - 2022-06-27 06:28:08 --> Language Class Initialized
ERROR - 2022-06-27 06:28:08 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 06:28:08 --> Config Class Initialized
INFO - 2022-06-27 06:28:08 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:28:08 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:28:08 --> Utf8 Class Initialized
INFO - 2022-06-27 06:28:08 --> URI Class Initialized
INFO - 2022-06-27 06:28:08 --> Router Class Initialized
INFO - 2022-06-27 06:28:08 --> Output Class Initialized
INFO - 2022-06-27 06:28:08 --> Security Class Initialized
DEBUG - 2022-06-27 06:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:28:08 --> Input Class Initialized
INFO - 2022-06-27 06:28:08 --> Language Class Initialized
ERROR - 2022-06-27 06:28:08 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 06:28:18 --> Config Class Initialized
INFO - 2022-06-27 06:28:18 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:28:18 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:28:18 --> Utf8 Class Initialized
INFO - 2022-06-27 06:28:18 --> URI Class Initialized
INFO - 2022-06-27 06:28:18 --> Router Class Initialized
INFO - 2022-06-27 06:28:18 --> Output Class Initialized
INFO - 2022-06-27 06:28:18 --> Security Class Initialized
DEBUG - 2022-06-27 06:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:28:18 --> Input Class Initialized
INFO - 2022-06-27 06:28:18 --> Language Class Initialized
INFO - 2022-06-27 06:28:18 --> Loader Class Initialized
INFO - 2022-06-27 06:28:18 --> Helper loaded: url_helper
INFO - 2022-06-27 06:28:18 --> Helper loaded: file_helper
INFO - 2022-06-27 06:28:18 --> Database Driver Class Initialized
INFO - 2022-06-27 06:28:18 --> Email Class Initialized
DEBUG - 2022-06-27 06:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 06:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 06:28:18 --> Controller Class Initialized
INFO - 2022-06-27 06:28:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 06:28:18 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 06:28:18 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 06:28:18 --> Final output sent to browser
DEBUG - 2022-06-27 06:28:18 --> Total execution time: 0.2483
INFO - 2022-06-27 06:28:18 --> Config Class Initialized
INFO - 2022-06-27 06:28:18 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:28:18 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:28:18 --> Utf8 Class Initialized
INFO - 2022-06-27 06:28:18 --> URI Class Initialized
INFO - 2022-06-27 06:28:18 --> Router Class Initialized
INFO - 2022-06-27 06:28:18 --> Output Class Initialized
INFO - 2022-06-27 06:28:18 --> Security Class Initialized
DEBUG - 2022-06-27 06:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:28:18 --> Input Class Initialized
INFO - 2022-06-27 06:28:18 --> Language Class Initialized
ERROR - 2022-06-27 06:28:18 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 06:28:18 --> Config Class Initialized
INFO - 2022-06-27 06:28:18 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:28:18 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:28:18 --> Utf8 Class Initialized
INFO - 2022-06-27 06:28:18 --> URI Class Initialized
INFO - 2022-06-27 06:28:18 --> Router Class Initialized
INFO - 2022-06-27 06:28:18 --> Output Class Initialized
INFO - 2022-06-27 06:28:18 --> Security Class Initialized
DEBUG - 2022-06-27 06:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:28:18 --> Input Class Initialized
INFO - 2022-06-27 06:28:18 --> Language Class Initialized
ERROR - 2022-06-27 06:28:18 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 06:30:03 --> Config Class Initialized
INFO - 2022-06-27 06:30:03 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:30:03 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:30:03 --> Utf8 Class Initialized
INFO - 2022-06-27 06:30:03 --> URI Class Initialized
INFO - 2022-06-27 06:30:03 --> Router Class Initialized
INFO - 2022-06-27 06:30:03 --> Output Class Initialized
INFO - 2022-06-27 06:30:03 --> Security Class Initialized
DEBUG - 2022-06-27 06:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:30:03 --> Input Class Initialized
INFO - 2022-06-27 06:30:03 --> Language Class Initialized
INFO - 2022-06-27 06:30:03 --> Loader Class Initialized
INFO - 2022-06-27 06:30:03 --> Helper loaded: url_helper
INFO - 2022-06-27 06:30:03 --> Helper loaded: file_helper
INFO - 2022-06-27 06:30:03 --> Database Driver Class Initialized
INFO - 2022-06-27 06:30:03 --> Email Class Initialized
DEBUG - 2022-06-27 06:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 06:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 06:30:03 --> Controller Class Initialized
INFO - 2022-06-27 06:30:03 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 06:30:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-27 06:30:04 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\qr\application\views\doc_screen\doctor.php 323
INFO - 2022-06-27 06:30:04 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 06:30:04 --> Final output sent to browser
DEBUG - 2022-06-27 06:30:04 --> Total execution time: 0.2876
INFO - 2022-06-27 06:30:04 --> Config Class Initialized
INFO - 2022-06-27 06:30:04 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:30:04 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:30:04 --> Utf8 Class Initialized
INFO - 2022-06-27 06:30:04 --> URI Class Initialized
INFO - 2022-06-27 06:30:04 --> Router Class Initialized
INFO - 2022-06-27 06:30:04 --> Output Class Initialized
INFO - 2022-06-27 06:30:04 --> Security Class Initialized
DEBUG - 2022-06-27 06:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:30:04 --> Input Class Initialized
INFO - 2022-06-27 06:30:04 --> Language Class Initialized
ERROR - 2022-06-27 06:30:04 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 06:30:04 --> Config Class Initialized
INFO - 2022-06-27 06:30:04 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:30:04 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:30:04 --> Utf8 Class Initialized
INFO - 2022-06-27 06:30:04 --> URI Class Initialized
INFO - 2022-06-27 06:30:04 --> Router Class Initialized
INFO - 2022-06-27 06:30:04 --> Output Class Initialized
INFO - 2022-06-27 06:30:04 --> Security Class Initialized
DEBUG - 2022-06-27 06:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:30:04 --> Input Class Initialized
INFO - 2022-06-27 06:30:04 --> Language Class Initialized
ERROR - 2022-06-27 06:30:04 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 06:30:22 --> Config Class Initialized
INFO - 2022-06-27 06:30:22 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:30:22 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:30:22 --> Utf8 Class Initialized
INFO - 2022-06-27 06:30:23 --> URI Class Initialized
INFO - 2022-06-27 06:30:23 --> Router Class Initialized
INFO - 2022-06-27 06:30:23 --> Output Class Initialized
INFO - 2022-06-27 06:30:23 --> Security Class Initialized
DEBUG - 2022-06-27 06:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:30:23 --> Input Class Initialized
INFO - 2022-06-27 06:30:23 --> Language Class Initialized
INFO - 2022-06-27 06:30:23 --> Loader Class Initialized
INFO - 2022-06-27 06:30:23 --> Helper loaded: url_helper
INFO - 2022-06-27 06:30:23 --> Helper loaded: file_helper
INFO - 2022-06-27 06:30:23 --> Database Driver Class Initialized
INFO - 2022-06-27 06:30:23 --> Email Class Initialized
DEBUG - 2022-06-27 06:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 06:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 06:30:23 --> Controller Class Initialized
INFO - 2022-06-27 06:30:23 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 06:30:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-27 06:30:23 --> Severity: Warning --> Use of undefined constant i - assumed 'i' (this will throw an Error in a future version of PHP) C:\wamp64\www\qr\application\controllers\Tokenctrl.php 83
ERROR - 2022-06-27 06:30:23 --> Severity: Notice --> Undefined index: i C:\wamp64\www\qr\application\controllers\Tokenctrl.php 83
ERROR - 2022-06-27 06:30:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\wamp64\www\qr\application\controllers\Tokenctrl.php 83
INFO - 2022-06-27 06:30:23 --> Final output sent to browser
DEBUG - 2022-06-27 06:30:23 --> Total execution time: 0.3849
INFO - 2022-06-27 06:31:33 --> Config Class Initialized
INFO - 2022-06-27 06:31:33 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:31:33 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:31:33 --> Utf8 Class Initialized
INFO - 2022-06-27 06:31:33 --> URI Class Initialized
INFO - 2022-06-27 06:31:33 --> Router Class Initialized
INFO - 2022-06-27 06:31:33 --> Output Class Initialized
INFO - 2022-06-27 06:31:33 --> Security Class Initialized
DEBUG - 2022-06-27 06:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:31:33 --> Input Class Initialized
INFO - 2022-06-27 06:31:33 --> Language Class Initialized
INFO - 2022-06-27 06:31:33 --> Loader Class Initialized
INFO - 2022-06-27 06:31:33 --> Helper loaded: url_helper
INFO - 2022-06-27 06:31:33 --> Helper loaded: file_helper
INFO - 2022-06-27 06:31:33 --> Database Driver Class Initialized
INFO - 2022-06-27 06:31:33 --> Email Class Initialized
DEBUG - 2022-06-27 06:31:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 06:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 06:31:33 --> Controller Class Initialized
INFO - 2022-06-27 06:31:33 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 06:31:33 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 06:31:33 --> Final output sent to browser
DEBUG - 2022-06-27 06:31:33 --> Total execution time: 0.1208
INFO - 2022-06-27 06:31:38 --> Config Class Initialized
INFO - 2022-06-27 06:31:38 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:31:38 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:31:38 --> Utf8 Class Initialized
INFO - 2022-06-27 06:31:38 --> URI Class Initialized
INFO - 2022-06-27 06:31:38 --> Router Class Initialized
INFO - 2022-06-27 06:31:38 --> Output Class Initialized
INFO - 2022-06-27 06:31:38 --> Security Class Initialized
DEBUG - 2022-06-27 06:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:31:38 --> Input Class Initialized
INFO - 2022-06-27 06:31:38 --> Language Class Initialized
INFO - 2022-06-27 06:31:38 --> Loader Class Initialized
INFO - 2022-06-27 06:31:38 --> Helper loaded: url_helper
INFO - 2022-06-27 06:31:38 --> Helper loaded: file_helper
INFO - 2022-06-27 06:31:38 --> Database Driver Class Initialized
INFO - 2022-06-27 06:31:38 --> Email Class Initialized
DEBUG - 2022-06-27 06:31:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 06:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 06:31:38 --> Controller Class Initialized
INFO - 2022-06-27 06:31:38 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 06:31:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-27 06:31:38 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\qr\application\views\doc_screen\doctor.php 323
INFO - 2022-06-27 06:31:38 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 06:31:38 --> Final output sent to browser
DEBUG - 2022-06-27 06:31:38 --> Total execution time: 0.1665
INFO - 2022-06-27 06:31:38 --> Config Class Initialized
INFO - 2022-06-27 06:31:38 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:31:38 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:31:38 --> Utf8 Class Initialized
INFO - 2022-06-27 06:31:38 --> URI Class Initialized
INFO - 2022-06-27 06:31:38 --> Router Class Initialized
INFO - 2022-06-27 06:31:38 --> Output Class Initialized
INFO - 2022-06-27 06:31:38 --> Security Class Initialized
DEBUG - 2022-06-27 06:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:31:38 --> Input Class Initialized
INFO - 2022-06-27 06:31:38 --> Language Class Initialized
ERROR - 2022-06-27 06:31:38 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 06:31:38 --> Config Class Initialized
INFO - 2022-06-27 06:31:38 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:31:38 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:31:38 --> Utf8 Class Initialized
INFO - 2022-06-27 06:31:38 --> URI Class Initialized
INFO - 2022-06-27 06:31:38 --> Router Class Initialized
INFO - 2022-06-27 06:31:38 --> Output Class Initialized
INFO - 2022-06-27 06:31:38 --> Security Class Initialized
DEBUG - 2022-06-27 06:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:31:38 --> Input Class Initialized
INFO - 2022-06-27 06:31:38 --> Language Class Initialized
ERROR - 2022-06-27 06:31:38 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 06:32:50 --> Config Class Initialized
INFO - 2022-06-27 06:32:50 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:32:50 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:32:50 --> Utf8 Class Initialized
INFO - 2022-06-27 06:32:50 --> URI Class Initialized
INFO - 2022-06-27 06:32:50 --> Router Class Initialized
INFO - 2022-06-27 06:32:50 --> Output Class Initialized
INFO - 2022-06-27 06:32:50 --> Security Class Initialized
DEBUG - 2022-06-27 06:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:32:50 --> Input Class Initialized
INFO - 2022-06-27 06:32:50 --> Language Class Initialized
INFO - 2022-06-27 06:32:50 --> Loader Class Initialized
INFO - 2022-06-27 06:32:50 --> Helper loaded: url_helper
INFO - 2022-06-27 06:32:50 --> Helper loaded: file_helper
INFO - 2022-06-27 06:32:50 --> Database Driver Class Initialized
INFO - 2022-06-27 06:32:50 --> Email Class Initialized
DEBUG - 2022-06-27 06:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 06:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 06:32:50 --> Controller Class Initialized
INFO - 2022-06-27 06:32:50 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 06:32:50 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 06:32:50 --> Final output sent to browser
DEBUG - 2022-06-27 06:32:50 --> Total execution time: 0.0367
INFO - 2022-06-27 06:32:52 --> Config Class Initialized
INFO - 2022-06-27 06:32:52 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:32:52 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:32:52 --> Utf8 Class Initialized
INFO - 2022-06-27 06:32:52 --> URI Class Initialized
INFO - 2022-06-27 06:32:52 --> Router Class Initialized
INFO - 2022-06-27 06:32:52 --> Output Class Initialized
INFO - 2022-06-27 06:32:52 --> Security Class Initialized
DEBUG - 2022-06-27 06:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:32:52 --> Input Class Initialized
INFO - 2022-06-27 06:32:52 --> Language Class Initialized
INFO - 2022-06-27 06:32:52 --> Loader Class Initialized
INFO - 2022-06-27 06:32:52 --> Helper loaded: url_helper
INFO - 2022-06-27 06:32:52 --> Helper loaded: file_helper
INFO - 2022-06-27 06:32:52 --> Database Driver Class Initialized
INFO - 2022-06-27 06:32:52 --> Email Class Initialized
DEBUG - 2022-06-27 06:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 06:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 06:32:52 --> Controller Class Initialized
INFO - 2022-06-27 06:32:52 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 06:32:52 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 06:32:52 --> Final output sent to browser
DEBUG - 2022-06-27 06:32:52 --> Total execution time: 0.1183
INFO - 2022-06-27 06:32:53 --> Config Class Initialized
INFO - 2022-06-27 06:32:53 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:32:53 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:32:53 --> Utf8 Class Initialized
INFO - 2022-06-27 06:32:53 --> URI Class Initialized
INFO - 2022-06-27 06:32:53 --> Router Class Initialized
INFO - 2022-06-27 06:32:53 --> Output Class Initialized
INFO - 2022-06-27 06:32:53 --> Security Class Initialized
DEBUG - 2022-06-27 06:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:32:53 --> Input Class Initialized
INFO - 2022-06-27 06:32:53 --> Language Class Initialized
INFO - 2022-06-27 06:32:53 --> Loader Class Initialized
INFO - 2022-06-27 06:32:53 --> Helper loaded: url_helper
INFO - 2022-06-27 06:32:53 --> Helper loaded: file_helper
INFO - 2022-06-27 06:32:53 --> Database Driver Class Initialized
INFO - 2022-06-27 06:32:53 --> Email Class Initialized
DEBUG - 2022-06-27 06:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 06:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 06:32:53 --> Controller Class Initialized
INFO - 2022-06-27 06:32:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 06:32:53 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 06:32:53 --> Final output sent to browser
DEBUG - 2022-06-27 06:32:53 --> Total execution time: 0.2414
INFO - 2022-06-27 06:32:53 --> Config Class Initialized
INFO - 2022-06-27 06:32:53 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:32:53 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:32:53 --> Utf8 Class Initialized
INFO - 2022-06-27 06:32:53 --> URI Class Initialized
INFO - 2022-06-27 06:32:53 --> Router Class Initialized
INFO - 2022-06-27 06:32:53 --> Output Class Initialized
INFO - 2022-06-27 06:32:53 --> Security Class Initialized
DEBUG - 2022-06-27 06:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:32:53 --> Input Class Initialized
INFO - 2022-06-27 06:32:53 --> Language Class Initialized
INFO - 2022-06-27 06:32:53 --> Loader Class Initialized
INFO - 2022-06-27 06:32:53 --> Helper loaded: url_helper
INFO - 2022-06-27 06:32:53 --> Helper loaded: file_helper
INFO - 2022-06-27 06:32:53 --> Database Driver Class Initialized
INFO - 2022-06-27 06:32:53 --> Email Class Initialized
DEBUG - 2022-06-27 06:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 06:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 06:32:53 --> Controller Class Initialized
INFO - 2022-06-27 06:32:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 06:32:53 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 06:32:53 --> Final output sent to browser
DEBUG - 2022-06-27 06:32:53 --> Total execution time: 0.0596
INFO - 2022-06-27 06:32:53 --> Config Class Initialized
INFO - 2022-06-27 06:32:53 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:32:53 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:32:53 --> Utf8 Class Initialized
INFO - 2022-06-27 06:32:53 --> URI Class Initialized
INFO - 2022-06-27 06:32:53 --> Router Class Initialized
INFO - 2022-06-27 06:32:53 --> Output Class Initialized
INFO - 2022-06-27 06:32:53 --> Security Class Initialized
DEBUG - 2022-06-27 06:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:32:53 --> Input Class Initialized
INFO - 2022-06-27 06:32:53 --> Language Class Initialized
INFO - 2022-06-27 06:32:53 --> Loader Class Initialized
INFO - 2022-06-27 06:32:53 --> Helper loaded: url_helper
INFO - 2022-06-27 06:32:53 --> Helper loaded: file_helper
INFO - 2022-06-27 06:32:53 --> Database Driver Class Initialized
INFO - 2022-06-27 06:32:53 --> Email Class Initialized
DEBUG - 2022-06-27 06:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 06:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 06:32:53 --> Controller Class Initialized
INFO - 2022-06-27 06:32:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 06:32:53 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 06:32:53 --> Final output sent to browser
DEBUG - 2022-06-27 06:32:53 --> Total execution time: 0.0504
INFO - 2022-06-27 06:32:53 --> Config Class Initialized
INFO - 2022-06-27 06:32:53 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:32:53 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:32:53 --> Utf8 Class Initialized
INFO - 2022-06-27 06:32:53 --> URI Class Initialized
INFO - 2022-06-27 06:32:53 --> Router Class Initialized
INFO - 2022-06-27 06:32:53 --> Output Class Initialized
INFO - 2022-06-27 06:32:53 --> Security Class Initialized
DEBUG - 2022-06-27 06:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:32:53 --> Input Class Initialized
INFO - 2022-06-27 06:32:53 --> Language Class Initialized
INFO - 2022-06-27 06:32:53 --> Loader Class Initialized
INFO - 2022-06-27 06:32:53 --> Helper loaded: url_helper
INFO - 2022-06-27 06:32:53 --> Helper loaded: file_helper
INFO - 2022-06-27 06:32:53 --> Database Driver Class Initialized
INFO - 2022-06-27 06:32:53 --> Email Class Initialized
DEBUG - 2022-06-27 06:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 06:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 06:32:53 --> Controller Class Initialized
INFO - 2022-06-27 06:32:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 06:32:53 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 06:32:53 --> Final output sent to browser
DEBUG - 2022-06-27 06:32:53 --> Total execution time: 0.0404
INFO - 2022-06-27 06:32:54 --> Config Class Initialized
INFO - 2022-06-27 06:32:54 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:32:54 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:32:54 --> Utf8 Class Initialized
INFO - 2022-06-27 06:32:54 --> URI Class Initialized
INFO - 2022-06-27 06:32:54 --> Router Class Initialized
INFO - 2022-06-27 06:32:54 --> Output Class Initialized
INFO - 2022-06-27 06:32:54 --> Security Class Initialized
DEBUG - 2022-06-27 06:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:32:54 --> Input Class Initialized
INFO - 2022-06-27 06:32:54 --> Language Class Initialized
INFO - 2022-06-27 06:32:54 --> Loader Class Initialized
INFO - 2022-06-27 06:32:54 --> Helper loaded: url_helper
INFO - 2022-06-27 06:32:54 --> Helper loaded: file_helper
INFO - 2022-06-27 06:32:54 --> Database Driver Class Initialized
INFO - 2022-06-27 06:32:54 --> Email Class Initialized
DEBUG - 2022-06-27 06:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 06:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 06:32:54 --> Controller Class Initialized
INFO - 2022-06-27 06:32:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 06:32:54 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 06:32:54 --> Final output sent to browser
DEBUG - 2022-06-27 06:32:54 --> Total execution time: 0.0392
INFO - 2022-06-27 06:32:54 --> Config Class Initialized
INFO - 2022-06-27 06:32:54 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:32:54 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:32:54 --> Utf8 Class Initialized
INFO - 2022-06-27 06:32:54 --> URI Class Initialized
INFO - 2022-06-27 06:32:54 --> Router Class Initialized
INFO - 2022-06-27 06:32:54 --> Output Class Initialized
INFO - 2022-06-27 06:32:54 --> Security Class Initialized
DEBUG - 2022-06-27 06:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:32:54 --> Input Class Initialized
INFO - 2022-06-27 06:32:54 --> Language Class Initialized
INFO - 2022-06-27 06:32:54 --> Loader Class Initialized
INFO - 2022-06-27 06:32:54 --> Helper loaded: url_helper
INFO - 2022-06-27 06:32:54 --> Helper loaded: file_helper
INFO - 2022-06-27 06:32:54 --> Database Driver Class Initialized
INFO - 2022-06-27 06:32:54 --> Email Class Initialized
DEBUG - 2022-06-27 06:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 06:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 06:32:54 --> Controller Class Initialized
INFO - 2022-06-27 06:32:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 06:32:54 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 06:32:54 --> Final output sent to browser
DEBUG - 2022-06-27 06:32:54 --> Total execution time: 0.0484
INFO - 2022-06-27 06:32:54 --> Config Class Initialized
INFO - 2022-06-27 06:32:54 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:32:54 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:32:54 --> Utf8 Class Initialized
INFO - 2022-06-27 06:32:54 --> URI Class Initialized
INFO - 2022-06-27 06:32:54 --> Router Class Initialized
INFO - 2022-06-27 06:32:54 --> Output Class Initialized
INFO - 2022-06-27 06:32:54 --> Security Class Initialized
DEBUG - 2022-06-27 06:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:32:54 --> Input Class Initialized
INFO - 2022-06-27 06:32:54 --> Language Class Initialized
INFO - 2022-06-27 06:32:54 --> Loader Class Initialized
INFO - 2022-06-27 06:32:54 --> Helper loaded: url_helper
INFO - 2022-06-27 06:32:54 --> Helper loaded: file_helper
INFO - 2022-06-27 06:32:54 --> Database Driver Class Initialized
INFO - 2022-06-27 06:32:54 --> Email Class Initialized
DEBUG - 2022-06-27 06:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 06:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 06:32:54 --> Controller Class Initialized
INFO - 2022-06-27 06:32:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 06:32:54 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 06:32:54 --> Final output sent to browser
DEBUG - 2022-06-27 06:32:54 --> Total execution time: 0.0385
INFO - 2022-06-27 06:32:54 --> Config Class Initialized
INFO - 2022-06-27 06:32:54 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:32:54 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:32:54 --> Utf8 Class Initialized
INFO - 2022-06-27 06:32:54 --> URI Class Initialized
INFO - 2022-06-27 06:32:54 --> Router Class Initialized
INFO - 2022-06-27 06:32:54 --> Output Class Initialized
INFO - 2022-06-27 06:32:54 --> Security Class Initialized
DEBUG - 2022-06-27 06:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:32:54 --> Input Class Initialized
INFO - 2022-06-27 06:32:54 --> Language Class Initialized
INFO - 2022-06-27 06:32:54 --> Loader Class Initialized
INFO - 2022-06-27 06:32:54 --> Helper loaded: url_helper
INFO - 2022-06-27 06:32:54 --> Helper loaded: file_helper
INFO - 2022-06-27 06:32:54 --> Database Driver Class Initialized
INFO - 2022-06-27 06:32:54 --> Email Class Initialized
DEBUG - 2022-06-27 06:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 06:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 06:32:54 --> Controller Class Initialized
INFO - 2022-06-27 06:32:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 06:32:54 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 06:32:54 --> Final output sent to browser
DEBUG - 2022-06-27 06:32:54 --> Total execution time: 0.0637
INFO - 2022-06-27 06:32:54 --> Config Class Initialized
INFO - 2022-06-27 06:32:54 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:32:54 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:32:54 --> Utf8 Class Initialized
INFO - 2022-06-27 06:32:54 --> URI Class Initialized
INFO - 2022-06-27 06:32:54 --> Router Class Initialized
INFO - 2022-06-27 06:32:54 --> Output Class Initialized
INFO - 2022-06-27 06:32:54 --> Security Class Initialized
DEBUG - 2022-06-27 06:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:32:54 --> Input Class Initialized
INFO - 2022-06-27 06:32:54 --> Language Class Initialized
INFO - 2022-06-27 06:32:54 --> Loader Class Initialized
INFO - 2022-06-27 06:32:54 --> Helper loaded: url_helper
INFO - 2022-06-27 06:32:54 --> Helper loaded: file_helper
INFO - 2022-06-27 06:32:54 --> Database Driver Class Initialized
INFO - 2022-06-27 06:32:54 --> Email Class Initialized
DEBUG - 2022-06-27 06:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 06:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 06:32:54 --> Controller Class Initialized
INFO - 2022-06-27 06:32:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 06:32:54 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 06:32:54 --> Final output sent to browser
DEBUG - 2022-06-27 06:32:54 --> Total execution time: 0.0273
INFO - 2022-06-27 06:32:55 --> Config Class Initialized
INFO - 2022-06-27 06:32:55 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:32:55 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:32:55 --> Utf8 Class Initialized
INFO - 2022-06-27 06:32:55 --> URI Class Initialized
INFO - 2022-06-27 06:32:55 --> Router Class Initialized
INFO - 2022-06-27 06:32:55 --> Output Class Initialized
INFO - 2022-06-27 06:32:55 --> Security Class Initialized
DEBUG - 2022-06-27 06:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:32:55 --> Input Class Initialized
INFO - 2022-06-27 06:32:55 --> Language Class Initialized
INFO - 2022-06-27 06:32:55 --> Loader Class Initialized
INFO - 2022-06-27 06:32:55 --> Helper loaded: url_helper
INFO - 2022-06-27 06:32:55 --> Helper loaded: file_helper
INFO - 2022-06-27 06:32:55 --> Database Driver Class Initialized
INFO - 2022-06-27 06:32:55 --> Email Class Initialized
DEBUG - 2022-06-27 06:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 06:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 06:32:55 --> Controller Class Initialized
INFO - 2022-06-27 06:32:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 06:32:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 06:32:55 --> Final output sent to browser
DEBUG - 2022-06-27 06:32:55 --> Total execution time: 0.1035
INFO - 2022-06-27 06:32:55 --> Config Class Initialized
INFO - 2022-06-27 06:32:55 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:32:55 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:32:55 --> Utf8 Class Initialized
INFO - 2022-06-27 06:32:55 --> URI Class Initialized
INFO - 2022-06-27 06:32:55 --> Router Class Initialized
INFO - 2022-06-27 06:32:55 --> Output Class Initialized
INFO - 2022-06-27 06:32:55 --> Security Class Initialized
DEBUG - 2022-06-27 06:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:32:55 --> Input Class Initialized
INFO - 2022-06-27 06:32:55 --> Language Class Initialized
INFO - 2022-06-27 06:32:55 --> Loader Class Initialized
INFO - 2022-06-27 06:32:55 --> Helper loaded: url_helper
INFO - 2022-06-27 06:32:55 --> Helper loaded: file_helper
INFO - 2022-06-27 06:32:55 --> Database Driver Class Initialized
INFO - 2022-06-27 06:32:55 --> Email Class Initialized
DEBUG - 2022-06-27 06:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 06:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 06:32:55 --> Controller Class Initialized
INFO - 2022-06-27 06:32:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 06:32:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 06:32:55 --> Final output sent to browser
DEBUG - 2022-06-27 06:32:55 --> Total execution time: 0.0174
INFO - 2022-06-27 06:32:55 --> Config Class Initialized
INFO - 2022-06-27 06:32:55 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:32:55 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:32:55 --> Utf8 Class Initialized
INFO - 2022-06-27 06:32:55 --> URI Class Initialized
INFO - 2022-06-27 06:32:55 --> Router Class Initialized
INFO - 2022-06-27 06:32:55 --> Output Class Initialized
INFO - 2022-06-27 06:32:55 --> Security Class Initialized
DEBUG - 2022-06-27 06:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:32:55 --> Input Class Initialized
INFO - 2022-06-27 06:32:55 --> Language Class Initialized
INFO - 2022-06-27 06:32:55 --> Loader Class Initialized
INFO - 2022-06-27 06:32:55 --> Helper loaded: url_helper
INFO - 2022-06-27 06:32:55 --> Helper loaded: file_helper
INFO - 2022-06-27 06:32:55 --> Database Driver Class Initialized
INFO - 2022-06-27 06:32:55 --> Email Class Initialized
DEBUG - 2022-06-27 06:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 06:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 06:32:55 --> Controller Class Initialized
INFO - 2022-06-27 06:32:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 06:32:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 06:32:55 --> Final output sent to browser
DEBUG - 2022-06-27 06:32:55 --> Total execution time: 0.0304
INFO - 2022-06-27 06:32:55 --> Config Class Initialized
INFO - 2022-06-27 06:32:55 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:32:55 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:32:55 --> Utf8 Class Initialized
INFO - 2022-06-27 06:32:55 --> URI Class Initialized
INFO - 2022-06-27 06:32:55 --> Router Class Initialized
INFO - 2022-06-27 06:32:55 --> Output Class Initialized
INFO - 2022-06-27 06:32:55 --> Security Class Initialized
DEBUG - 2022-06-27 06:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:32:55 --> Input Class Initialized
INFO - 2022-06-27 06:32:55 --> Language Class Initialized
INFO - 2022-06-27 06:32:55 --> Loader Class Initialized
INFO - 2022-06-27 06:32:55 --> Helper loaded: url_helper
INFO - 2022-06-27 06:32:55 --> Helper loaded: file_helper
INFO - 2022-06-27 06:32:55 --> Database Driver Class Initialized
INFO - 2022-06-27 06:32:55 --> Email Class Initialized
DEBUG - 2022-06-27 06:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 06:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 06:32:55 --> Controller Class Initialized
INFO - 2022-06-27 06:32:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 06:32:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 06:32:55 --> Final output sent to browser
DEBUG - 2022-06-27 06:32:55 --> Total execution time: 0.0411
INFO - 2022-06-27 06:32:55 --> Config Class Initialized
INFO - 2022-06-27 06:32:55 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:32:55 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:32:55 --> Utf8 Class Initialized
INFO - 2022-06-27 06:32:55 --> URI Class Initialized
INFO - 2022-06-27 06:32:55 --> Router Class Initialized
INFO - 2022-06-27 06:32:55 --> Output Class Initialized
INFO - 2022-06-27 06:32:55 --> Security Class Initialized
DEBUG - 2022-06-27 06:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:32:55 --> Input Class Initialized
INFO - 2022-06-27 06:32:55 --> Language Class Initialized
INFO - 2022-06-27 06:32:55 --> Loader Class Initialized
INFO - 2022-06-27 06:32:55 --> Helper loaded: url_helper
INFO - 2022-06-27 06:32:55 --> Helper loaded: file_helper
INFO - 2022-06-27 06:32:55 --> Database Driver Class Initialized
INFO - 2022-06-27 06:32:55 --> Email Class Initialized
DEBUG - 2022-06-27 06:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 06:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 06:32:55 --> Controller Class Initialized
INFO - 2022-06-27 06:32:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 06:32:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 06:32:55 --> Final output sent to browser
DEBUG - 2022-06-27 06:32:55 --> Total execution time: 0.0558
INFO - 2022-06-27 06:32:56 --> Config Class Initialized
INFO - 2022-06-27 06:32:56 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:32:56 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:32:56 --> Utf8 Class Initialized
INFO - 2022-06-27 06:32:56 --> URI Class Initialized
INFO - 2022-06-27 06:32:56 --> Router Class Initialized
INFO - 2022-06-27 06:32:56 --> Output Class Initialized
INFO - 2022-06-27 06:32:56 --> Security Class Initialized
DEBUG - 2022-06-27 06:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:32:56 --> Input Class Initialized
INFO - 2022-06-27 06:32:56 --> Language Class Initialized
INFO - 2022-06-27 06:32:56 --> Loader Class Initialized
INFO - 2022-06-27 06:32:56 --> Helper loaded: url_helper
INFO - 2022-06-27 06:32:56 --> Helper loaded: file_helper
INFO - 2022-06-27 06:32:56 --> Database Driver Class Initialized
INFO - 2022-06-27 06:32:56 --> Email Class Initialized
DEBUG - 2022-06-27 06:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 06:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 06:32:56 --> Controller Class Initialized
INFO - 2022-06-27 06:32:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 06:32:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 06:32:56 --> Final output sent to browser
DEBUG - 2022-06-27 06:32:56 --> Total execution time: 0.0481
INFO - 2022-06-27 06:32:56 --> Config Class Initialized
INFO - 2022-06-27 06:32:56 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:32:56 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:32:56 --> Utf8 Class Initialized
INFO - 2022-06-27 06:32:56 --> URI Class Initialized
INFO - 2022-06-27 06:32:56 --> Router Class Initialized
INFO - 2022-06-27 06:32:56 --> Output Class Initialized
INFO - 2022-06-27 06:32:56 --> Security Class Initialized
DEBUG - 2022-06-27 06:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:32:56 --> Input Class Initialized
INFO - 2022-06-27 06:32:56 --> Language Class Initialized
INFO - 2022-06-27 06:32:56 --> Loader Class Initialized
INFO - 2022-06-27 06:32:56 --> Helper loaded: url_helper
INFO - 2022-06-27 06:32:56 --> Helper loaded: file_helper
INFO - 2022-06-27 06:32:56 --> Database Driver Class Initialized
INFO - 2022-06-27 06:32:56 --> Email Class Initialized
DEBUG - 2022-06-27 06:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 06:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 06:32:56 --> Controller Class Initialized
INFO - 2022-06-27 06:32:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 06:32:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 06:32:56 --> Final output sent to browser
DEBUG - 2022-06-27 06:32:56 --> Total execution time: 0.0417
INFO - 2022-06-27 06:32:56 --> Config Class Initialized
INFO - 2022-06-27 06:32:56 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:32:56 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:32:56 --> Utf8 Class Initialized
INFO - 2022-06-27 06:32:56 --> URI Class Initialized
INFO - 2022-06-27 06:32:56 --> Router Class Initialized
INFO - 2022-06-27 06:32:56 --> Output Class Initialized
INFO - 2022-06-27 06:32:56 --> Security Class Initialized
DEBUG - 2022-06-27 06:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:32:56 --> Input Class Initialized
INFO - 2022-06-27 06:32:56 --> Language Class Initialized
INFO - 2022-06-27 06:32:56 --> Loader Class Initialized
INFO - 2022-06-27 06:32:56 --> Helper loaded: url_helper
INFO - 2022-06-27 06:32:56 --> Helper loaded: file_helper
INFO - 2022-06-27 06:32:56 --> Database Driver Class Initialized
INFO - 2022-06-27 06:32:56 --> Email Class Initialized
DEBUG - 2022-06-27 06:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 06:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 06:32:56 --> Controller Class Initialized
INFO - 2022-06-27 06:32:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 06:32:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 06:32:56 --> Final output sent to browser
DEBUG - 2022-06-27 06:32:56 --> Total execution time: 0.0641
INFO - 2022-06-27 06:32:56 --> Config Class Initialized
INFO - 2022-06-27 06:32:56 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:32:56 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:32:56 --> Utf8 Class Initialized
INFO - 2022-06-27 06:32:56 --> URI Class Initialized
INFO - 2022-06-27 06:32:56 --> Router Class Initialized
INFO - 2022-06-27 06:32:56 --> Output Class Initialized
INFO - 2022-06-27 06:32:56 --> Security Class Initialized
DEBUG - 2022-06-27 06:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:32:56 --> Input Class Initialized
INFO - 2022-06-27 06:32:56 --> Language Class Initialized
INFO - 2022-06-27 06:32:56 --> Loader Class Initialized
INFO - 2022-06-27 06:32:56 --> Helper loaded: url_helper
INFO - 2022-06-27 06:32:56 --> Helper loaded: file_helper
INFO - 2022-06-27 06:32:56 --> Database Driver Class Initialized
INFO - 2022-06-27 06:32:56 --> Email Class Initialized
DEBUG - 2022-06-27 06:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 06:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 06:32:56 --> Controller Class Initialized
INFO - 2022-06-27 06:32:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 06:32:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 06:32:56 --> Final output sent to browser
DEBUG - 2022-06-27 06:32:56 --> Total execution time: 0.0326
INFO - 2022-06-27 06:32:56 --> Config Class Initialized
INFO - 2022-06-27 06:32:56 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:32:56 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:32:56 --> Utf8 Class Initialized
INFO - 2022-06-27 06:32:56 --> URI Class Initialized
INFO - 2022-06-27 06:32:56 --> Router Class Initialized
INFO - 2022-06-27 06:32:56 --> Output Class Initialized
INFO - 2022-06-27 06:32:56 --> Security Class Initialized
DEBUG - 2022-06-27 06:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:32:56 --> Input Class Initialized
INFO - 2022-06-27 06:32:56 --> Language Class Initialized
INFO - 2022-06-27 06:32:56 --> Loader Class Initialized
INFO - 2022-06-27 06:32:56 --> Helper loaded: url_helper
INFO - 2022-06-27 06:32:56 --> Helper loaded: file_helper
INFO - 2022-06-27 06:32:56 --> Database Driver Class Initialized
INFO - 2022-06-27 06:32:56 --> Email Class Initialized
DEBUG - 2022-06-27 06:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 06:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 06:32:56 --> Controller Class Initialized
INFO - 2022-06-27 06:32:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 06:32:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 06:32:56 --> Final output sent to browser
DEBUG - 2022-06-27 06:32:56 --> Total execution time: 0.0315
INFO - 2022-06-27 06:34:17 --> Config Class Initialized
INFO - 2022-06-27 06:34:17 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:34:17 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:34:17 --> Utf8 Class Initialized
INFO - 2022-06-27 06:34:17 --> URI Class Initialized
INFO - 2022-06-27 06:34:17 --> Router Class Initialized
INFO - 2022-06-27 06:34:17 --> Output Class Initialized
INFO - 2022-06-27 06:34:17 --> Security Class Initialized
DEBUG - 2022-06-27 06:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:34:17 --> Input Class Initialized
INFO - 2022-06-27 06:34:17 --> Language Class Initialized
INFO - 2022-06-27 06:34:17 --> Loader Class Initialized
INFO - 2022-06-27 06:34:17 --> Helper loaded: url_helper
INFO - 2022-06-27 06:34:17 --> Helper loaded: file_helper
INFO - 2022-06-27 06:34:17 --> Database Driver Class Initialized
INFO - 2022-06-27 06:34:17 --> Email Class Initialized
DEBUG - 2022-06-27 06:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 06:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 06:34:17 --> Controller Class Initialized
INFO - 2022-06-27 06:34:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 06:34:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-27 06:34:17 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\qr\application\views\doc_screen\doctor.php 323
INFO - 2022-06-27 06:34:17 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 06:34:17 --> Final output sent to browser
DEBUG - 2022-06-27 06:34:17 --> Total execution time: 0.1122
INFO - 2022-06-27 06:34:17 --> Config Class Initialized
INFO - 2022-06-27 06:34:17 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:34:17 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:34:17 --> Utf8 Class Initialized
INFO - 2022-06-27 06:34:17 --> URI Class Initialized
INFO - 2022-06-27 06:34:17 --> Router Class Initialized
INFO - 2022-06-27 06:34:17 --> Output Class Initialized
INFO - 2022-06-27 06:34:17 --> Security Class Initialized
DEBUG - 2022-06-27 06:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:34:17 --> Input Class Initialized
INFO - 2022-06-27 06:34:17 --> Language Class Initialized
ERROR - 2022-06-27 06:34:17 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 06:34:17 --> Config Class Initialized
INFO - 2022-06-27 06:34:17 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:34:17 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:34:17 --> Utf8 Class Initialized
INFO - 2022-06-27 06:34:17 --> URI Class Initialized
INFO - 2022-06-27 06:34:17 --> Router Class Initialized
INFO - 2022-06-27 06:34:17 --> Output Class Initialized
INFO - 2022-06-27 06:34:17 --> Security Class Initialized
DEBUG - 2022-06-27 06:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:34:17 --> Input Class Initialized
INFO - 2022-06-27 06:34:17 --> Language Class Initialized
ERROR - 2022-06-27 06:34:17 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 06:34:42 --> Config Class Initialized
INFO - 2022-06-27 06:34:42 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:34:42 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:34:42 --> Utf8 Class Initialized
INFO - 2022-06-27 06:34:42 --> URI Class Initialized
INFO - 2022-06-27 06:34:42 --> Router Class Initialized
INFO - 2022-06-27 06:34:42 --> Output Class Initialized
INFO - 2022-06-27 06:34:42 --> Security Class Initialized
DEBUG - 2022-06-27 06:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:34:42 --> Input Class Initialized
INFO - 2022-06-27 06:34:42 --> Language Class Initialized
INFO - 2022-06-27 06:34:42 --> Loader Class Initialized
INFO - 2022-06-27 06:34:42 --> Helper loaded: url_helper
INFO - 2022-06-27 06:34:42 --> Helper loaded: file_helper
INFO - 2022-06-27 06:34:42 --> Database Driver Class Initialized
INFO - 2022-06-27 06:34:42 --> Email Class Initialized
DEBUG - 2022-06-27 06:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 06:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 06:34:42 --> Controller Class Initialized
INFO - 2022-06-27 06:34:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 06:34:42 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 06:34:42 --> Final output sent to browser
DEBUG - 2022-06-27 06:34:42 --> Total execution time: 0.1375
INFO - 2022-06-27 06:57:11 --> Config Class Initialized
INFO - 2022-06-27 06:57:11 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:57:11 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:57:11 --> Utf8 Class Initialized
INFO - 2022-06-27 06:57:11 --> URI Class Initialized
INFO - 2022-06-27 06:57:11 --> Router Class Initialized
INFO - 2022-06-27 06:57:11 --> Output Class Initialized
INFO - 2022-06-27 06:57:11 --> Security Class Initialized
DEBUG - 2022-06-27 06:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:57:11 --> Input Class Initialized
INFO - 2022-06-27 06:57:11 --> Language Class Initialized
INFO - 2022-06-27 06:57:11 --> Loader Class Initialized
INFO - 2022-06-27 06:57:11 --> Helper loaded: url_helper
INFO - 2022-06-27 06:57:11 --> Helper loaded: file_helper
INFO - 2022-06-27 06:57:11 --> Database Driver Class Initialized
INFO - 2022-06-27 06:57:11 --> Email Class Initialized
DEBUG - 2022-06-27 06:57:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 06:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 06:57:11 --> Controller Class Initialized
INFO - 2022-06-27 06:57:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 06:57:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-27 06:57:11 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\qr\application\views\doc_screen\doctor.php 323
INFO - 2022-06-27 06:57:11 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 06:57:11 --> Final output sent to browser
DEBUG - 2022-06-27 06:57:11 --> Total execution time: 0.0988
INFO - 2022-06-27 06:57:11 --> Config Class Initialized
INFO - 2022-06-27 06:57:11 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:57:11 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:57:11 --> Utf8 Class Initialized
INFO - 2022-06-27 06:57:11 --> URI Class Initialized
INFO - 2022-06-27 06:57:11 --> Router Class Initialized
INFO - 2022-06-27 06:57:11 --> Output Class Initialized
INFO - 2022-06-27 06:57:11 --> Security Class Initialized
DEBUG - 2022-06-27 06:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:57:11 --> Input Class Initialized
INFO - 2022-06-27 06:57:11 --> Language Class Initialized
ERROR - 2022-06-27 06:57:11 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 06:57:12 --> Config Class Initialized
INFO - 2022-06-27 06:57:12 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:57:12 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:57:12 --> Utf8 Class Initialized
INFO - 2022-06-27 06:57:12 --> URI Class Initialized
INFO - 2022-06-27 06:57:12 --> Router Class Initialized
INFO - 2022-06-27 06:57:12 --> Output Class Initialized
INFO - 2022-06-27 06:57:12 --> Security Class Initialized
DEBUG - 2022-06-27 06:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:57:12 --> Input Class Initialized
INFO - 2022-06-27 06:57:12 --> Language Class Initialized
ERROR - 2022-06-27 06:57:12 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 06:57:14 --> Config Class Initialized
INFO - 2022-06-27 06:57:14 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:57:14 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:57:14 --> Utf8 Class Initialized
INFO - 2022-06-27 06:57:14 --> URI Class Initialized
INFO - 2022-06-27 06:57:14 --> Router Class Initialized
INFO - 2022-06-27 06:57:14 --> Output Class Initialized
INFO - 2022-06-27 06:57:14 --> Security Class Initialized
DEBUG - 2022-06-27 06:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:57:14 --> Input Class Initialized
INFO - 2022-06-27 06:57:14 --> Language Class Initialized
INFO - 2022-06-27 06:57:14 --> Loader Class Initialized
INFO - 2022-06-27 06:57:14 --> Helper loaded: url_helper
INFO - 2022-06-27 06:57:14 --> Helper loaded: file_helper
INFO - 2022-06-27 06:57:14 --> Database Driver Class Initialized
INFO - 2022-06-27 06:57:14 --> Email Class Initialized
DEBUG - 2022-06-27 06:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 06:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 06:57:14 --> Controller Class Initialized
INFO - 2022-06-27 06:57:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 06:57:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-27 06:57:14 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\qr\application\views\doc_screen\doctor.php 323
INFO - 2022-06-27 06:57:14 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 06:57:14 --> Final output sent to browser
DEBUG - 2022-06-27 06:57:14 --> Total execution time: 0.0473
INFO - 2022-06-27 06:57:14 --> Config Class Initialized
INFO - 2022-06-27 06:57:14 --> Hooks Class Initialized
INFO - 2022-06-27 06:57:14 --> Config Class Initialized
DEBUG - 2022-06-27 06:57:14 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:57:14 --> Utf8 Class Initialized
INFO - 2022-06-27 06:57:14 --> Hooks Class Initialized
INFO - 2022-06-27 06:57:14 --> URI Class Initialized
DEBUG - 2022-06-27 06:57:14 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:57:14 --> Utf8 Class Initialized
INFO - 2022-06-27 06:57:14 --> Router Class Initialized
INFO - 2022-06-27 06:57:14 --> URI Class Initialized
INFO - 2022-06-27 06:57:14 --> Output Class Initialized
INFO - 2022-06-27 06:57:14 --> Router Class Initialized
INFO - 2022-06-27 06:57:14 --> Security Class Initialized
DEBUG - 2022-06-27 06:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:57:14 --> Input Class Initialized
INFO - 2022-06-27 06:57:14 --> Output Class Initialized
INFO - 2022-06-27 06:57:14 --> Language Class Initialized
INFO - 2022-06-27 06:57:14 --> Security Class Initialized
ERROR - 2022-06-27 06:57:14 --> 404 Page Not Found: Tokenctrl/localhost
DEBUG - 2022-06-27 06:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:57:14 --> Input Class Initialized
INFO - 2022-06-27 06:57:14 --> Language Class Initialized
ERROR - 2022-06-27 06:57:14 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 06:57:28 --> Config Class Initialized
INFO - 2022-06-27 06:57:28 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:57:28 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:57:28 --> Utf8 Class Initialized
INFO - 2022-06-27 06:57:28 --> URI Class Initialized
INFO - 2022-06-27 06:57:28 --> Router Class Initialized
INFO - 2022-06-27 06:57:28 --> Output Class Initialized
INFO - 2022-06-27 06:57:28 --> Security Class Initialized
DEBUG - 2022-06-27 06:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:57:28 --> Input Class Initialized
INFO - 2022-06-27 06:57:28 --> Language Class Initialized
INFO - 2022-06-27 06:57:28 --> Loader Class Initialized
INFO - 2022-06-27 06:57:28 --> Helper loaded: url_helper
INFO - 2022-06-27 06:57:28 --> Helper loaded: file_helper
INFO - 2022-06-27 06:57:28 --> Database Driver Class Initialized
INFO - 2022-06-27 06:57:28 --> Email Class Initialized
DEBUG - 2022-06-27 06:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 06:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 06:57:28 --> Controller Class Initialized
INFO - 2022-06-27 06:57:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 06:57:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-27 06:57:28 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\qr\application\views\doc_screen\doctor.php 323
INFO - 2022-06-27 06:57:28 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 06:57:28 --> Final output sent to browser
DEBUG - 2022-06-27 06:57:28 --> Total execution time: 0.2096
INFO - 2022-06-27 06:57:29 --> Config Class Initialized
INFO - 2022-06-27 06:57:29 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:57:29 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:57:29 --> Utf8 Class Initialized
INFO - 2022-06-27 06:57:29 --> URI Class Initialized
INFO - 2022-06-27 06:57:29 --> Router Class Initialized
INFO - 2022-06-27 06:57:29 --> Output Class Initialized
INFO - 2022-06-27 06:57:29 --> Security Class Initialized
DEBUG - 2022-06-27 06:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:57:29 --> Input Class Initialized
INFO - 2022-06-27 06:57:29 --> Language Class Initialized
ERROR - 2022-06-27 06:57:29 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 06:57:29 --> Config Class Initialized
INFO - 2022-06-27 06:57:29 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:57:29 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:57:29 --> Utf8 Class Initialized
INFO - 2022-06-27 06:57:29 --> URI Class Initialized
INFO - 2022-06-27 06:57:29 --> Router Class Initialized
INFO - 2022-06-27 06:57:29 --> Output Class Initialized
INFO - 2022-06-27 06:57:29 --> Security Class Initialized
DEBUG - 2022-06-27 06:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:57:29 --> Input Class Initialized
INFO - 2022-06-27 06:57:29 --> Language Class Initialized
ERROR - 2022-06-27 06:57:29 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 06:58:17 --> Config Class Initialized
INFO - 2022-06-27 06:58:17 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:58:17 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:58:17 --> Utf8 Class Initialized
INFO - 2022-06-27 06:58:17 --> URI Class Initialized
INFO - 2022-06-27 06:58:17 --> Router Class Initialized
INFO - 2022-06-27 06:58:17 --> Output Class Initialized
INFO - 2022-06-27 06:58:17 --> Security Class Initialized
DEBUG - 2022-06-27 06:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:58:17 --> Input Class Initialized
INFO - 2022-06-27 06:58:17 --> Language Class Initialized
INFO - 2022-06-27 06:58:17 --> Loader Class Initialized
INFO - 2022-06-27 06:58:17 --> Helper loaded: url_helper
INFO - 2022-06-27 06:58:17 --> Helper loaded: file_helper
INFO - 2022-06-27 06:58:17 --> Database Driver Class Initialized
INFO - 2022-06-27 06:58:17 --> Email Class Initialized
DEBUG - 2022-06-27 06:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 06:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 06:58:17 --> Controller Class Initialized
INFO - 2022-06-27 06:58:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 06:58:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-27 06:58:17 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\qr\application\views\doc_screen\doctor.php 323
INFO - 2022-06-27 06:58:17 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 06:58:17 --> Final output sent to browser
DEBUG - 2022-06-27 06:58:17 --> Total execution time: 0.1247
INFO - 2022-06-27 06:58:17 --> Config Class Initialized
INFO - 2022-06-27 06:58:17 --> Config Class Initialized
INFO - 2022-06-27 06:58:17 --> Hooks Class Initialized
INFO - 2022-06-27 06:58:17 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 06:58:17 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:58:17 --> Utf8 Class Initialized
INFO - 2022-06-27 06:58:17 --> Utf8 Class Initialized
INFO - 2022-06-27 06:58:17 --> URI Class Initialized
INFO - 2022-06-27 06:58:17 --> URI Class Initialized
INFO - 2022-06-27 06:58:17 --> Router Class Initialized
INFO - 2022-06-27 06:58:17 --> Router Class Initialized
INFO - 2022-06-27 06:58:17 --> Output Class Initialized
INFO - 2022-06-27 06:58:17 --> Output Class Initialized
INFO - 2022-06-27 06:58:17 --> Security Class Initialized
DEBUG - 2022-06-27 06:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:58:17 --> Security Class Initialized
INFO - 2022-06-27 06:58:17 --> Input Class Initialized
DEBUG - 2022-06-27 06:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:58:17 --> Input Class Initialized
INFO - 2022-06-27 06:58:17 --> Language Class Initialized
INFO - 2022-06-27 06:58:17 --> Language Class Initialized
ERROR - 2022-06-27 06:58:17 --> 404 Page Not Found: Tokenctrl/localhost
ERROR - 2022-06-27 06:58:17 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 06:58:21 --> Config Class Initialized
INFO - 2022-06-27 06:58:21 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:58:21 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:58:21 --> Utf8 Class Initialized
INFO - 2022-06-27 06:58:21 --> URI Class Initialized
INFO - 2022-06-27 06:58:21 --> Router Class Initialized
INFO - 2022-06-27 06:58:21 --> Output Class Initialized
INFO - 2022-06-27 06:58:21 --> Security Class Initialized
DEBUG - 2022-06-27 06:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:58:21 --> Input Class Initialized
INFO - 2022-06-27 06:58:21 --> Language Class Initialized
INFO - 2022-06-27 06:58:21 --> Loader Class Initialized
INFO - 2022-06-27 06:58:21 --> Helper loaded: url_helper
INFO - 2022-06-27 06:58:21 --> Helper loaded: file_helper
INFO - 2022-06-27 06:58:21 --> Database Driver Class Initialized
INFO - 2022-06-27 06:58:21 --> Email Class Initialized
DEBUG - 2022-06-27 06:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 06:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 06:58:21 --> Controller Class Initialized
INFO - 2022-06-27 06:58:21 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 06:58:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-27 06:58:21 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\qr\application\views\doc_screen\doctor.php 323
INFO - 2022-06-27 06:58:21 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 06:58:21 --> Final output sent to browser
DEBUG - 2022-06-27 06:58:21 --> Total execution time: 0.1189
INFO - 2022-06-27 06:58:21 --> Config Class Initialized
INFO - 2022-06-27 06:58:21 --> Hooks Class Initialized
DEBUG - 2022-06-27 06:58:21 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:58:21 --> Utf8 Class Initialized
INFO - 2022-06-27 06:58:21 --> URI Class Initialized
INFO - 2022-06-27 06:58:21 --> Router Class Initialized
INFO - 2022-06-27 06:58:21 --> Output Class Initialized
INFO - 2022-06-27 06:58:21 --> Security Class Initialized
INFO - 2022-06-27 06:58:21 --> Config Class Initialized
DEBUG - 2022-06-27 06:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:58:21 --> Hooks Class Initialized
INFO - 2022-06-27 06:58:21 --> Input Class Initialized
INFO - 2022-06-27 06:58:21 --> Language Class Initialized
DEBUG - 2022-06-27 06:58:21 --> UTF-8 Support Enabled
INFO - 2022-06-27 06:58:21 --> Utf8 Class Initialized
ERROR - 2022-06-27 06:58:21 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 06:58:21 --> URI Class Initialized
INFO - 2022-06-27 06:58:21 --> Router Class Initialized
INFO - 2022-06-27 06:58:21 --> Output Class Initialized
INFO - 2022-06-27 06:58:21 --> Security Class Initialized
DEBUG - 2022-06-27 06:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 06:58:21 --> Input Class Initialized
INFO - 2022-06-27 06:58:21 --> Language Class Initialized
ERROR - 2022-06-27 06:58:21 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 08:31:43 --> Config Class Initialized
INFO - 2022-06-27 08:31:43 --> Hooks Class Initialized
DEBUG - 2022-06-27 08:31:43 --> UTF-8 Support Enabled
INFO - 2022-06-27 08:31:43 --> Utf8 Class Initialized
INFO - 2022-06-27 08:31:43 --> URI Class Initialized
INFO - 2022-06-27 08:31:43 --> Router Class Initialized
INFO - 2022-06-27 08:31:43 --> Output Class Initialized
INFO - 2022-06-27 08:31:43 --> Security Class Initialized
DEBUG - 2022-06-27 08:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 08:31:43 --> Input Class Initialized
INFO - 2022-06-27 08:31:43 --> Language Class Initialized
INFO - 2022-06-27 08:31:43 --> Loader Class Initialized
INFO - 2022-06-27 08:31:43 --> Helper loaded: url_helper
INFO - 2022-06-27 08:31:43 --> Helper loaded: file_helper
INFO - 2022-06-27 08:31:43 --> Database Driver Class Initialized
INFO - 2022-06-27 08:31:43 --> Email Class Initialized
DEBUG - 2022-06-27 08:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 08:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 08:31:43 --> Controller Class Initialized
INFO - 2022-06-27 08:31:43 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 08:31:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-27 08:31:43 --> Severity: error --> Exception: Call to undefined method Tokenmodel::update() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 95
INFO - 2022-06-27 08:31:50 --> Config Class Initialized
INFO - 2022-06-27 08:31:50 --> Hooks Class Initialized
DEBUG - 2022-06-27 08:31:50 --> UTF-8 Support Enabled
INFO - 2022-06-27 08:31:50 --> Utf8 Class Initialized
INFO - 2022-06-27 08:31:50 --> URI Class Initialized
INFO - 2022-06-27 08:31:50 --> Router Class Initialized
INFO - 2022-06-27 08:31:50 --> Output Class Initialized
INFO - 2022-06-27 08:31:50 --> Security Class Initialized
DEBUG - 2022-06-27 08:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 08:31:50 --> Input Class Initialized
INFO - 2022-06-27 08:31:50 --> Language Class Initialized
INFO - 2022-06-27 08:31:50 --> Loader Class Initialized
INFO - 2022-06-27 08:31:50 --> Helper loaded: url_helper
INFO - 2022-06-27 08:31:50 --> Helper loaded: file_helper
INFO - 2022-06-27 08:31:50 --> Database Driver Class Initialized
INFO - 2022-06-27 08:31:51 --> Email Class Initialized
DEBUG - 2022-06-27 08:31:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 08:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 08:31:51 --> Controller Class Initialized
INFO - 2022-06-27 08:31:51 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 08:31:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-27 08:31:51 --> Severity: error --> Exception: Call to undefined method Tokenmodel::update() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 95
INFO - 2022-06-27 08:50:12 --> Config Class Initialized
INFO - 2022-06-27 08:50:12 --> Hooks Class Initialized
DEBUG - 2022-06-27 08:50:12 --> UTF-8 Support Enabled
INFO - 2022-06-27 08:50:12 --> Utf8 Class Initialized
INFO - 2022-06-27 08:50:12 --> URI Class Initialized
INFO - 2022-06-27 08:50:12 --> Router Class Initialized
INFO - 2022-06-27 08:50:12 --> Output Class Initialized
INFO - 2022-06-27 08:50:12 --> Security Class Initialized
DEBUG - 2022-06-27 08:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 08:50:12 --> Input Class Initialized
INFO - 2022-06-27 08:50:12 --> Language Class Initialized
INFO - 2022-06-27 08:50:12 --> Loader Class Initialized
INFO - 2022-06-27 08:50:12 --> Helper loaded: url_helper
INFO - 2022-06-27 08:50:12 --> Helper loaded: file_helper
INFO - 2022-06-27 08:50:12 --> Database Driver Class Initialized
INFO - 2022-06-27 08:50:13 --> Email Class Initialized
DEBUG - 2022-06-27 08:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 08:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 08:50:13 --> Controller Class Initialized
INFO - 2022-06-27 08:50:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 08:50:13 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 08:50:13 --> Final output sent to browser
DEBUG - 2022-06-27 08:50:13 --> Total execution time: 0.1494
INFO - 2022-06-27 09:31:07 --> Config Class Initialized
INFO - 2022-06-27 09:31:07 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:31:07 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:31:07 --> Utf8 Class Initialized
INFO - 2022-06-27 09:31:07 --> URI Class Initialized
INFO - 2022-06-27 09:31:07 --> Router Class Initialized
INFO - 2022-06-27 09:31:07 --> Output Class Initialized
INFO - 2022-06-27 09:31:07 --> Security Class Initialized
DEBUG - 2022-06-27 09:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:31:07 --> Input Class Initialized
INFO - 2022-06-27 09:31:07 --> Language Class Initialized
INFO - 2022-06-27 09:31:07 --> Loader Class Initialized
INFO - 2022-06-27 09:31:07 --> Helper loaded: url_helper
INFO - 2022-06-27 09:31:07 --> Helper loaded: file_helper
INFO - 2022-06-27 09:31:07 --> Database Driver Class Initialized
INFO - 2022-06-27 09:31:08 --> Email Class Initialized
DEBUG - 2022-06-27 09:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 09:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 09:31:08 --> Controller Class Initialized
INFO - 2022-06-27 09:31:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 09:31:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-27 09:31:08 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\qr\application\views\doc_screen\doctor.php 323
INFO - 2022-06-27 09:31:08 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 09:31:08 --> Final output sent to browser
DEBUG - 2022-06-27 09:31:08 --> Total execution time: 0.3432
INFO - 2022-06-27 09:31:08 --> Config Class Initialized
INFO - 2022-06-27 09:31:08 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:31:08 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:31:08 --> Utf8 Class Initialized
INFO - 2022-06-27 09:31:08 --> URI Class Initialized
INFO - 2022-06-27 09:31:08 --> Router Class Initialized
INFO - 2022-06-27 09:31:08 --> Output Class Initialized
INFO - 2022-06-27 09:31:08 --> Security Class Initialized
DEBUG - 2022-06-27 09:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:31:08 --> Input Class Initialized
INFO - 2022-06-27 09:31:08 --> Language Class Initialized
ERROR - 2022-06-27 09:31:08 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 09:31:08 --> Config Class Initialized
INFO - 2022-06-27 09:31:08 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:31:08 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:31:08 --> Utf8 Class Initialized
INFO - 2022-06-27 09:31:08 --> URI Class Initialized
INFO - 2022-06-27 09:31:08 --> Router Class Initialized
INFO - 2022-06-27 09:31:08 --> Output Class Initialized
INFO - 2022-06-27 09:31:08 --> Security Class Initialized
DEBUG - 2022-06-27 09:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:31:08 --> Input Class Initialized
INFO - 2022-06-27 09:31:08 --> Language Class Initialized
ERROR - 2022-06-27 09:31:08 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 09:31:18 --> Config Class Initialized
INFO - 2022-06-27 09:31:18 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:31:18 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:31:18 --> Utf8 Class Initialized
INFO - 2022-06-27 09:31:18 --> URI Class Initialized
INFO - 2022-06-27 09:31:18 --> Router Class Initialized
INFO - 2022-06-27 09:31:18 --> Output Class Initialized
INFO - 2022-06-27 09:31:18 --> Security Class Initialized
DEBUG - 2022-06-27 09:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:31:18 --> Input Class Initialized
INFO - 2022-06-27 09:31:18 --> Language Class Initialized
INFO - 2022-06-27 09:31:18 --> Loader Class Initialized
INFO - 2022-06-27 09:31:18 --> Helper loaded: url_helper
INFO - 2022-06-27 09:31:18 --> Helper loaded: file_helper
INFO - 2022-06-27 09:31:18 --> Database Driver Class Initialized
INFO - 2022-06-27 09:31:18 --> Email Class Initialized
DEBUG - 2022-06-27 09:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 09:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 09:31:18 --> Controller Class Initialized
INFO - 2022-06-27 09:31:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 09:31:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-27 09:31:18 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\qr\application\views\doc_screen\doctor.php 323
INFO - 2022-06-27 09:31:18 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 09:31:18 --> Final output sent to browser
DEBUG - 2022-06-27 09:31:18 --> Total execution time: 0.1743
INFO - 2022-06-27 09:31:18 --> Config Class Initialized
INFO - 2022-06-27 09:31:18 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:31:18 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:31:18 --> Utf8 Class Initialized
INFO - 2022-06-27 09:31:18 --> URI Class Initialized
INFO - 2022-06-27 09:31:18 --> Router Class Initialized
INFO - 2022-06-27 09:31:18 --> Output Class Initialized
INFO - 2022-06-27 09:31:18 --> Security Class Initialized
DEBUG - 2022-06-27 09:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:31:18 --> Input Class Initialized
INFO - 2022-06-27 09:31:18 --> Language Class Initialized
ERROR - 2022-06-27 09:31:18 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 09:31:18 --> Config Class Initialized
INFO - 2022-06-27 09:31:18 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:31:18 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:31:18 --> Utf8 Class Initialized
INFO - 2022-06-27 09:31:18 --> URI Class Initialized
INFO - 2022-06-27 09:31:18 --> Router Class Initialized
INFO - 2022-06-27 09:31:18 --> Output Class Initialized
INFO - 2022-06-27 09:31:18 --> Security Class Initialized
DEBUG - 2022-06-27 09:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:31:18 --> Input Class Initialized
INFO - 2022-06-27 09:31:18 --> Language Class Initialized
ERROR - 2022-06-27 09:31:18 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 09:31:58 --> Config Class Initialized
INFO - 2022-06-27 09:31:58 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:31:58 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:31:58 --> Utf8 Class Initialized
INFO - 2022-06-27 09:31:58 --> URI Class Initialized
INFO - 2022-06-27 09:31:58 --> Router Class Initialized
INFO - 2022-06-27 09:31:58 --> Output Class Initialized
INFO - 2022-06-27 09:31:58 --> Security Class Initialized
DEBUG - 2022-06-27 09:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:31:58 --> Input Class Initialized
INFO - 2022-06-27 09:31:58 --> Language Class Initialized
INFO - 2022-06-27 09:31:58 --> Loader Class Initialized
INFO - 2022-06-27 09:31:58 --> Helper loaded: url_helper
INFO - 2022-06-27 09:31:58 --> Helper loaded: file_helper
INFO - 2022-06-27 09:31:58 --> Database Driver Class Initialized
INFO - 2022-06-27 09:31:58 --> Email Class Initialized
DEBUG - 2022-06-27 09:31:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 09:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 09:31:58 --> Controller Class Initialized
INFO - 2022-06-27 09:31:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 09:31:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 09:31:58 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 09:31:58 --> Final output sent to browser
DEBUG - 2022-06-27 09:31:58 --> Total execution time: 0.0329
INFO - 2022-06-27 09:31:58 --> Config Class Initialized
INFO - 2022-06-27 09:31:58 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:31:58 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:31:58 --> Utf8 Class Initialized
INFO - 2022-06-27 09:31:58 --> URI Class Initialized
INFO - 2022-06-27 09:31:58 --> Router Class Initialized
INFO - 2022-06-27 09:31:58 --> Output Class Initialized
INFO - 2022-06-27 09:31:58 --> Security Class Initialized
DEBUG - 2022-06-27 09:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:31:58 --> Input Class Initialized
INFO - 2022-06-27 09:31:58 --> Language Class Initialized
ERROR - 2022-06-27 09:31:58 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 09:31:58 --> Config Class Initialized
INFO - 2022-06-27 09:31:58 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:31:58 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:31:58 --> Utf8 Class Initialized
INFO - 2022-06-27 09:31:58 --> URI Class Initialized
INFO - 2022-06-27 09:31:58 --> Router Class Initialized
INFO - 2022-06-27 09:31:58 --> Output Class Initialized
INFO - 2022-06-27 09:31:58 --> Security Class Initialized
DEBUG - 2022-06-27 09:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:31:58 --> Input Class Initialized
INFO - 2022-06-27 09:31:58 --> Language Class Initialized
ERROR - 2022-06-27 09:31:58 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 09:32:04 --> Config Class Initialized
INFO - 2022-06-27 09:32:04 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:32:04 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:32:04 --> Utf8 Class Initialized
INFO - 2022-06-27 09:32:04 --> URI Class Initialized
INFO - 2022-06-27 09:32:04 --> Router Class Initialized
INFO - 2022-06-27 09:32:04 --> Output Class Initialized
INFO - 2022-06-27 09:32:04 --> Security Class Initialized
DEBUG - 2022-06-27 09:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:32:04 --> Input Class Initialized
INFO - 2022-06-27 09:32:04 --> Language Class Initialized
INFO - 2022-06-27 09:32:04 --> Loader Class Initialized
INFO - 2022-06-27 09:32:04 --> Helper loaded: url_helper
INFO - 2022-06-27 09:32:04 --> Helper loaded: file_helper
INFO - 2022-06-27 09:32:04 --> Database Driver Class Initialized
INFO - 2022-06-27 09:32:04 --> Email Class Initialized
DEBUG - 2022-06-27 09:32:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 09:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 09:32:04 --> Controller Class Initialized
INFO - 2022-06-27 09:32:04 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 09:32:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-27 09:32:04 --> Severity: error --> Exception: Call to undefined method Tokenmodel::update2_0() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 114
INFO - 2022-06-27 09:32:06 --> Config Class Initialized
INFO - 2022-06-27 09:32:06 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:32:06 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:32:06 --> Utf8 Class Initialized
INFO - 2022-06-27 09:32:06 --> URI Class Initialized
INFO - 2022-06-27 09:32:06 --> Router Class Initialized
INFO - 2022-06-27 09:32:06 --> Output Class Initialized
INFO - 2022-06-27 09:32:06 --> Security Class Initialized
DEBUG - 2022-06-27 09:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:32:06 --> Input Class Initialized
INFO - 2022-06-27 09:32:06 --> Language Class Initialized
INFO - 2022-06-27 09:32:06 --> Loader Class Initialized
INFO - 2022-06-27 09:32:06 --> Helper loaded: url_helper
INFO - 2022-06-27 09:32:06 --> Helper loaded: file_helper
INFO - 2022-06-27 09:32:06 --> Database Driver Class Initialized
INFO - 2022-06-27 09:32:06 --> Email Class Initialized
DEBUG - 2022-06-27 09:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 09:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 09:32:06 --> Controller Class Initialized
INFO - 2022-06-27 09:32:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 09:32:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-27 09:32:06 --> Severity: error --> Exception: Call to undefined method Tokenmodel::update2_0() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 114
INFO - 2022-06-27 09:32:54 --> Config Class Initialized
INFO - 2022-06-27 09:32:54 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:32:54 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:32:54 --> Utf8 Class Initialized
INFO - 2022-06-27 09:32:54 --> URI Class Initialized
INFO - 2022-06-27 09:32:54 --> Router Class Initialized
INFO - 2022-06-27 09:32:54 --> Output Class Initialized
INFO - 2022-06-27 09:32:54 --> Security Class Initialized
DEBUG - 2022-06-27 09:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:32:54 --> Input Class Initialized
INFO - 2022-06-27 09:32:54 --> Language Class Initialized
INFO - 2022-06-27 09:32:54 --> Loader Class Initialized
INFO - 2022-06-27 09:32:54 --> Helper loaded: url_helper
INFO - 2022-06-27 09:32:54 --> Helper loaded: file_helper
INFO - 2022-06-27 09:32:54 --> Database Driver Class Initialized
INFO - 2022-06-27 09:32:54 --> Email Class Initialized
DEBUG - 2022-06-27 09:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 09:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 09:32:54 --> Controller Class Initialized
INFO - 2022-06-27 09:32:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 09:32:54 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 09:32:54 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 09:32:54 --> Final output sent to browser
DEBUG - 2022-06-27 09:32:54 --> Total execution time: 0.1374
INFO - 2022-06-27 09:32:54 --> Config Class Initialized
INFO - 2022-06-27 09:32:54 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:32:54 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:32:54 --> Utf8 Class Initialized
INFO - 2022-06-27 09:32:54 --> URI Class Initialized
INFO - 2022-06-27 09:32:54 --> Router Class Initialized
INFO - 2022-06-27 09:32:54 --> Output Class Initialized
INFO - 2022-06-27 09:32:54 --> Security Class Initialized
DEBUG - 2022-06-27 09:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:32:54 --> Input Class Initialized
INFO - 2022-06-27 09:32:54 --> Language Class Initialized
ERROR - 2022-06-27 09:32:54 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 09:32:54 --> Config Class Initialized
INFO - 2022-06-27 09:32:54 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:32:54 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:32:54 --> Utf8 Class Initialized
INFO - 2022-06-27 09:32:54 --> URI Class Initialized
INFO - 2022-06-27 09:32:54 --> Router Class Initialized
INFO - 2022-06-27 09:32:54 --> Output Class Initialized
INFO - 2022-06-27 09:32:54 --> Security Class Initialized
DEBUG - 2022-06-27 09:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:32:54 --> Input Class Initialized
INFO - 2022-06-27 09:32:54 --> Language Class Initialized
ERROR - 2022-06-27 09:32:54 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 09:33:07 --> Config Class Initialized
INFO - 2022-06-27 09:33:07 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:33:07 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:33:07 --> Utf8 Class Initialized
INFO - 2022-06-27 09:33:07 --> URI Class Initialized
INFO - 2022-06-27 09:33:07 --> Router Class Initialized
INFO - 2022-06-27 09:33:07 --> Output Class Initialized
INFO - 2022-06-27 09:33:07 --> Security Class Initialized
DEBUG - 2022-06-27 09:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:33:07 --> Input Class Initialized
INFO - 2022-06-27 09:33:07 --> Language Class Initialized
INFO - 2022-06-27 09:33:07 --> Loader Class Initialized
INFO - 2022-06-27 09:33:07 --> Helper loaded: url_helper
INFO - 2022-06-27 09:33:07 --> Helper loaded: file_helper
INFO - 2022-06-27 09:33:07 --> Database Driver Class Initialized
INFO - 2022-06-27 09:33:07 --> Email Class Initialized
DEBUG - 2022-06-27 09:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 09:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 09:33:07 --> Controller Class Initialized
INFO - 2022-06-27 09:33:07 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 09:33:07 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 09:33:07 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 09:33:07 --> Final output sent to browser
DEBUG - 2022-06-27 09:33:07 --> Total execution time: 0.1372
INFO - 2022-06-27 09:33:09 --> Config Class Initialized
INFO - 2022-06-27 09:33:09 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:33:09 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:33:09 --> Utf8 Class Initialized
INFO - 2022-06-27 09:33:09 --> URI Class Initialized
INFO - 2022-06-27 09:33:09 --> Router Class Initialized
INFO - 2022-06-27 09:33:09 --> Output Class Initialized
INFO - 2022-06-27 09:33:09 --> Security Class Initialized
DEBUG - 2022-06-27 09:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:33:09 --> Input Class Initialized
INFO - 2022-06-27 09:33:09 --> Language Class Initialized
INFO - 2022-06-27 09:33:09 --> Loader Class Initialized
INFO - 2022-06-27 09:33:09 --> Helper loaded: url_helper
INFO - 2022-06-27 09:33:09 --> Helper loaded: file_helper
INFO - 2022-06-27 09:33:09 --> Database Driver Class Initialized
INFO - 2022-06-27 09:33:09 --> Email Class Initialized
DEBUG - 2022-06-27 09:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 09:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 09:33:09 --> Controller Class Initialized
INFO - 2022-06-27 09:33:09 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 09:33:09 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 09:33:09 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 09:33:09 --> Final output sent to browser
DEBUG - 2022-06-27 09:33:09 --> Total execution time: 0.0468
INFO - 2022-06-27 09:33:09 --> Config Class Initialized
INFO - 2022-06-27 09:33:09 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:33:09 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:33:09 --> Utf8 Class Initialized
INFO - 2022-06-27 09:33:09 --> URI Class Initialized
INFO - 2022-06-27 09:33:09 --> Router Class Initialized
INFO - 2022-06-27 09:33:09 --> Output Class Initialized
INFO - 2022-06-27 09:33:09 --> Security Class Initialized
DEBUG - 2022-06-27 09:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:33:09 --> Input Class Initialized
INFO - 2022-06-27 09:33:09 --> Language Class Initialized
ERROR - 2022-06-27 09:33:09 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 09:33:09 --> Config Class Initialized
INFO - 2022-06-27 09:33:09 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:33:09 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:33:09 --> Utf8 Class Initialized
INFO - 2022-06-27 09:33:09 --> URI Class Initialized
INFO - 2022-06-27 09:33:09 --> Router Class Initialized
INFO - 2022-06-27 09:33:09 --> Output Class Initialized
INFO - 2022-06-27 09:33:09 --> Security Class Initialized
DEBUG - 2022-06-27 09:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:33:09 --> Input Class Initialized
INFO - 2022-06-27 09:33:09 --> Language Class Initialized
ERROR - 2022-06-27 09:33:09 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 09:33:32 --> Config Class Initialized
INFO - 2022-06-27 09:33:32 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:33:32 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:33:32 --> Utf8 Class Initialized
INFO - 2022-06-27 09:33:32 --> URI Class Initialized
INFO - 2022-06-27 09:33:32 --> Router Class Initialized
INFO - 2022-06-27 09:33:32 --> Output Class Initialized
INFO - 2022-06-27 09:33:32 --> Security Class Initialized
DEBUG - 2022-06-27 09:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:33:32 --> Input Class Initialized
INFO - 2022-06-27 09:33:32 --> Language Class Initialized
INFO - 2022-06-27 09:33:32 --> Loader Class Initialized
INFO - 2022-06-27 09:33:32 --> Helper loaded: url_helper
INFO - 2022-06-27 09:33:32 --> Helper loaded: file_helper
INFO - 2022-06-27 09:33:32 --> Database Driver Class Initialized
INFO - 2022-06-27 09:33:32 --> Email Class Initialized
DEBUG - 2022-06-27 09:33:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 09:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 09:33:32 --> Controller Class Initialized
INFO - 2022-06-27 09:33:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 09:33:32 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 09:33:32 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 09:33:32 --> Final output sent to browser
DEBUG - 2022-06-27 09:33:32 --> Total execution time: 0.1394
INFO - 2022-06-27 09:33:32 --> Config Class Initialized
INFO - 2022-06-27 09:33:32 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:33:32 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:33:32 --> Utf8 Class Initialized
INFO - 2022-06-27 09:33:32 --> URI Class Initialized
INFO - 2022-06-27 09:33:32 --> Router Class Initialized
INFO - 2022-06-27 09:33:32 --> Output Class Initialized
INFO - 2022-06-27 09:33:32 --> Security Class Initialized
DEBUG - 2022-06-27 09:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:33:32 --> Input Class Initialized
INFO - 2022-06-27 09:33:32 --> Language Class Initialized
ERROR - 2022-06-27 09:33:32 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 09:33:32 --> Config Class Initialized
INFO - 2022-06-27 09:33:32 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:33:32 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:33:32 --> Utf8 Class Initialized
INFO - 2022-06-27 09:33:32 --> URI Class Initialized
INFO - 2022-06-27 09:33:32 --> Router Class Initialized
INFO - 2022-06-27 09:33:32 --> Output Class Initialized
INFO - 2022-06-27 09:33:32 --> Security Class Initialized
DEBUG - 2022-06-27 09:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:33:32 --> Input Class Initialized
INFO - 2022-06-27 09:33:32 --> Language Class Initialized
ERROR - 2022-06-27 09:33:32 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 09:33:41 --> Config Class Initialized
INFO - 2022-06-27 09:33:41 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:33:41 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:33:41 --> Utf8 Class Initialized
INFO - 2022-06-27 09:33:41 --> URI Class Initialized
INFO - 2022-06-27 09:33:41 --> Router Class Initialized
INFO - 2022-06-27 09:33:41 --> Output Class Initialized
INFO - 2022-06-27 09:33:41 --> Security Class Initialized
DEBUG - 2022-06-27 09:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:33:41 --> Input Class Initialized
INFO - 2022-06-27 09:33:41 --> Language Class Initialized
INFO - 2022-06-27 09:33:41 --> Loader Class Initialized
INFO - 2022-06-27 09:33:41 --> Helper loaded: url_helper
INFO - 2022-06-27 09:33:41 --> Helper loaded: file_helper
INFO - 2022-06-27 09:33:41 --> Database Driver Class Initialized
INFO - 2022-06-27 09:33:41 --> Email Class Initialized
DEBUG - 2022-06-27 09:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 09:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 09:33:41 --> Controller Class Initialized
INFO - 2022-06-27 09:33:41 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 09:33:41 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 09:33:41 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 09:33:41 --> Final output sent to browser
DEBUG - 2022-06-27 09:33:41 --> Total execution time: 0.1493
INFO - 2022-06-27 09:33:44 --> Config Class Initialized
INFO - 2022-06-27 09:33:44 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:33:44 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:33:44 --> Utf8 Class Initialized
INFO - 2022-06-27 09:33:44 --> URI Class Initialized
INFO - 2022-06-27 09:33:44 --> Router Class Initialized
INFO - 2022-06-27 09:33:44 --> Output Class Initialized
INFO - 2022-06-27 09:33:44 --> Security Class Initialized
DEBUG - 2022-06-27 09:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:33:44 --> Input Class Initialized
INFO - 2022-06-27 09:33:44 --> Language Class Initialized
INFO - 2022-06-27 09:33:44 --> Loader Class Initialized
INFO - 2022-06-27 09:33:44 --> Helper loaded: url_helper
INFO - 2022-06-27 09:33:44 --> Helper loaded: file_helper
INFO - 2022-06-27 09:33:44 --> Database Driver Class Initialized
INFO - 2022-06-27 09:33:44 --> Email Class Initialized
DEBUG - 2022-06-27 09:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 09:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 09:33:44 --> Controller Class Initialized
INFO - 2022-06-27 09:33:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 09:33:44 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 09:33:44 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 09:33:44 --> Final output sent to browser
DEBUG - 2022-06-27 09:33:44 --> Total execution time: 0.0511
INFO - 2022-06-27 09:33:44 --> Config Class Initialized
INFO - 2022-06-27 09:33:44 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:33:44 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:33:44 --> Utf8 Class Initialized
INFO - 2022-06-27 09:33:44 --> URI Class Initialized
INFO - 2022-06-27 09:33:44 --> Router Class Initialized
INFO - 2022-06-27 09:33:44 --> Output Class Initialized
INFO - 2022-06-27 09:33:44 --> Security Class Initialized
DEBUG - 2022-06-27 09:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:33:44 --> Input Class Initialized
INFO - 2022-06-27 09:33:44 --> Language Class Initialized
ERROR - 2022-06-27 09:33:44 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 09:33:44 --> Config Class Initialized
INFO - 2022-06-27 09:33:44 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:33:44 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:33:44 --> Utf8 Class Initialized
INFO - 2022-06-27 09:33:44 --> URI Class Initialized
INFO - 2022-06-27 09:33:44 --> Router Class Initialized
INFO - 2022-06-27 09:33:44 --> Output Class Initialized
INFO - 2022-06-27 09:33:44 --> Security Class Initialized
DEBUG - 2022-06-27 09:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:33:44 --> Input Class Initialized
INFO - 2022-06-27 09:33:44 --> Language Class Initialized
ERROR - 2022-06-27 09:33:44 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 09:34:10 --> Config Class Initialized
INFO - 2022-06-27 09:34:10 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:34:10 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:34:10 --> Utf8 Class Initialized
INFO - 2022-06-27 09:34:10 --> URI Class Initialized
INFO - 2022-06-27 09:34:10 --> Router Class Initialized
INFO - 2022-06-27 09:34:10 --> Output Class Initialized
INFO - 2022-06-27 09:34:10 --> Security Class Initialized
DEBUG - 2022-06-27 09:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:34:10 --> Input Class Initialized
INFO - 2022-06-27 09:34:10 --> Language Class Initialized
INFO - 2022-06-27 09:34:10 --> Loader Class Initialized
INFO - 2022-06-27 09:34:10 --> Helper loaded: url_helper
INFO - 2022-06-27 09:34:10 --> Helper loaded: file_helper
INFO - 2022-06-27 09:34:10 --> Database Driver Class Initialized
INFO - 2022-06-27 09:34:10 --> Email Class Initialized
DEBUG - 2022-06-27 09:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 09:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 09:34:10 --> Controller Class Initialized
INFO - 2022-06-27 09:34:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 09:34:10 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 09:34:10 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 09:34:10 --> Final output sent to browser
DEBUG - 2022-06-27 09:34:10 --> Total execution time: 0.0422
INFO - 2022-06-27 09:34:37 --> Config Class Initialized
INFO - 2022-06-27 09:34:37 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:34:37 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:34:37 --> Utf8 Class Initialized
INFO - 2022-06-27 09:34:37 --> URI Class Initialized
INFO - 2022-06-27 09:34:37 --> Router Class Initialized
INFO - 2022-06-27 09:34:37 --> Output Class Initialized
INFO - 2022-06-27 09:34:37 --> Security Class Initialized
DEBUG - 2022-06-27 09:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:34:37 --> Input Class Initialized
INFO - 2022-06-27 09:34:37 --> Language Class Initialized
INFO - 2022-06-27 09:34:37 --> Loader Class Initialized
INFO - 2022-06-27 09:34:37 --> Helper loaded: url_helper
INFO - 2022-06-27 09:34:37 --> Helper loaded: file_helper
INFO - 2022-06-27 09:34:37 --> Database Driver Class Initialized
INFO - 2022-06-27 09:34:37 --> Email Class Initialized
DEBUG - 2022-06-27 09:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 09:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 09:34:37 --> Controller Class Initialized
INFO - 2022-06-27 09:34:37 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 09:34:37 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 09:34:37 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 09:34:37 --> Final output sent to browser
DEBUG - 2022-06-27 09:34:37 --> Total execution time: 0.0259
INFO - 2022-06-27 09:34:39 --> Config Class Initialized
INFO - 2022-06-27 09:34:39 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:34:39 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:34:39 --> Utf8 Class Initialized
INFO - 2022-06-27 09:34:39 --> URI Class Initialized
INFO - 2022-06-27 09:34:39 --> Router Class Initialized
INFO - 2022-06-27 09:34:39 --> Output Class Initialized
INFO - 2022-06-27 09:34:39 --> Security Class Initialized
DEBUG - 2022-06-27 09:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:34:39 --> Input Class Initialized
INFO - 2022-06-27 09:34:39 --> Language Class Initialized
INFO - 2022-06-27 09:34:39 --> Loader Class Initialized
INFO - 2022-06-27 09:34:39 --> Helper loaded: url_helper
INFO - 2022-06-27 09:34:39 --> Helper loaded: file_helper
INFO - 2022-06-27 09:34:39 --> Database Driver Class Initialized
INFO - 2022-06-27 09:34:39 --> Email Class Initialized
DEBUG - 2022-06-27 09:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 09:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 09:34:39 --> Controller Class Initialized
INFO - 2022-06-27 09:34:39 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 09:34:39 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 09:34:39 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 09:34:39 --> Final output sent to browser
DEBUG - 2022-06-27 09:34:39 --> Total execution time: 0.0439
INFO - 2022-06-27 09:34:52 --> Config Class Initialized
INFO - 2022-06-27 09:34:52 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:34:52 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:34:52 --> Utf8 Class Initialized
INFO - 2022-06-27 09:34:52 --> URI Class Initialized
INFO - 2022-06-27 09:34:52 --> Router Class Initialized
INFO - 2022-06-27 09:34:52 --> Output Class Initialized
INFO - 2022-06-27 09:34:52 --> Security Class Initialized
DEBUG - 2022-06-27 09:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:34:52 --> Input Class Initialized
INFO - 2022-06-27 09:34:52 --> Language Class Initialized
INFO - 2022-06-27 09:34:52 --> Loader Class Initialized
INFO - 2022-06-27 09:34:52 --> Helper loaded: url_helper
INFO - 2022-06-27 09:34:52 --> Helper loaded: file_helper
INFO - 2022-06-27 09:34:52 --> Database Driver Class Initialized
INFO - 2022-06-27 09:34:52 --> Email Class Initialized
DEBUG - 2022-06-27 09:34:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 09:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 09:34:52 --> Controller Class Initialized
INFO - 2022-06-27 09:34:52 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 09:34:52 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 09:34:52 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 09:34:52 --> Final output sent to browser
DEBUG - 2022-06-27 09:34:52 --> Total execution time: 0.0232
INFO - 2022-06-27 09:34:52 --> Config Class Initialized
INFO - 2022-06-27 09:34:52 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:34:52 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:34:52 --> Utf8 Class Initialized
INFO - 2022-06-27 09:34:52 --> URI Class Initialized
INFO - 2022-06-27 09:34:52 --> Router Class Initialized
INFO - 2022-06-27 09:34:52 --> Output Class Initialized
INFO - 2022-06-27 09:34:52 --> Security Class Initialized
DEBUG - 2022-06-27 09:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:34:52 --> Input Class Initialized
INFO - 2022-06-27 09:34:52 --> Language Class Initialized
ERROR - 2022-06-27 09:34:52 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 09:34:53 --> Config Class Initialized
INFO - 2022-06-27 09:34:53 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:34:53 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:34:53 --> Utf8 Class Initialized
INFO - 2022-06-27 09:34:53 --> URI Class Initialized
INFO - 2022-06-27 09:34:53 --> Router Class Initialized
INFO - 2022-06-27 09:34:53 --> Output Class Initialized
INFO - 2022-06-27 09:34:53 --> Security Class Initialized
DEBUG - 2022-06-27 09:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:34:53 --> Input Class Initialized
INFO - 2022-06-27 09:34:53 --> Language Class Initialized
ERROR - 2022-06-27 09:34:53 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 09:35:42 --> Config Class Initialized
INFO - 2022-06-27 09:35:42 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:35:42 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:35:42 --> Utf8 Class Initialized
INFO - 2022-06-27 09:35:42 --> URI Class Initialized
INFO - 2022-06-27 09:35:42 --> Router Class Initialized
INFO - 2022-06-27 09:35:42 --> Output Class Initialized
INFO - 2022-06-27 09:35:42 --> Security Class Initialized
DEBUG - 2022-06-27 09:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:35:42 --> Input Class Initialized
INFO - 2022-06-27 09:35:42 --> Language Class Initialized
INFO - 2022-06-27 09:35:42 --> Loader Class Initialized
INFO - 2022-06-27 09:35:42 --> Helper loaded: url_helper
INFO - 2022-06-27 09:35:42 --> Helper loaded: file_helper
INFO - 2022-06-27 09:35:42 --> Database Driver Class Initialized
INFO - 2022-06-27 09:35:42 --> Email Class Initialized
DEBUG - 2022-06-27 09:35:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 09:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 09:35:42 --> Controller Class Initialized
INFO - 2022-06-27 09:35:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 09:35:42 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 09:35:42 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 09:35:42 --> Final output sent to browser
DEBUG - 2022-06-27 09:35:42 --> Total execution time: 0.0402
INFO - 2022-06-27 09:35:42 --> Config Class Initialized
INFO - 2022-06-27 09:35:42 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:35:42 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:35:42 --> Utf8 Class Initialized
INFO - 2022-06-27 09:35:42 --> URI Class Initialized
INFO - 2022-06-27 09:35:42 --> Router Class Initialized
INFO - 2022-06-27 09:35:42 --> Output Class Initialized
INFO - 2022-06-27 09:35:42 --> Security Class Initialized
DEBUG - 2022-06-27 09:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:35:42 --> Input Class Initialized
INFO - 2022-06-27 09:35:42 --> Language Class Initialized
ERROR - 2022-06-27 09:35:42 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 09:35:42 --> Config Class Initialized
INFO - 2022-06-27 09:35:42 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:35:42 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:35:42 --> Utf8 Class Initialized
INFO - 2022-06-27 09:35:42 --> URI Class Initialized
INFO - 2022-06-27 09:35:42 --> Router Class Initialized
INFO - 2022-06-27 09:35:42 --> Output Class Initialized
INFO - 2022-06-27 09:35:42 --> Security Class Initialized
DEBUG - 2022-06-27 09:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:35:42 --> Input Class Initialized
INFO - 2022-06-27 09:35:42 --> Language Class Initialized
ERROR - 2022-06-27 09:35:42 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 09:35:54 --> Config Class Initialized
INFO - 2022-06-27 09:35:54 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:35:54 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:35:54 --> Utf8 Class Initialized
INFO - 2022-06-27 09:35:54 --> URI Class Initialized
INFO - 2022-06-27 09:35:54 --> Router Class Initialized
INFO - 2022-06-27 09:35:54 --> Output Class Initialized
INFO - 2022-06-27 09:35:54 --> Security Class Initialized
DEBUG - 2022-06-27 09:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:35:54 --> Input Class Initialized
INFO - 2022-06-27 09:35:54 --> Language Class Initialized
INFO - 2022-06-27 09:35:54 --> Loader Class Initialized
INFO - 2022-06-27 09:35:54 --> Helper loaded: url_helper
INFO - 2022-06-27 09:35:54 --> Helper loaded: file_helper
INFO - 2022-06-27 09:35:54 --> Database Driver Class Initialized
INFO - 2022-06-27 09:35:54 --> Email Class Initialized
DEBUG - 2022-06-27 09:35:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 09:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 09:35:54 --> Controller Class Initialized
INFO - 2022-06-27 09:35:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 09:35:54 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 09:35:54 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 09:35:54 --> Final output sent to browser
DEBUG - 2022-06-27 09:35:54 --> Total execution time: 0.0248
INFO - 2022-06-27 09:36:10 --> Config Class Initialized
INFO - 2022-06-27 09:36:10 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:36:10 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:36:10 --> Utf8 Class Initialized
INFO - 2022-06-27 09:36:10 --> URI Class Initialized
INFO - 2022-06-27 09:36:10 --> Router Class Initialized
INFO - 2022-06-27 09:36:10 --> Output Class Initialized
INFO - 2022-06-27 09:36:10 --> Security Class Initialized
DEBUG - 2022-06-27 09:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:36:10 --> Input Class Initialized
INFO - 2022-06-27 09:36:10 --> Language Class Initialized
INFO - 2022-06-27 09:36:10 --> Loader Class Initialized
INFO - 2022-06-27 09:36:10 --> Helper loaded: url_helper
INFO - 2022-06-27 09:36:10 --> Helper loaded: file_helper
INFO - 2022-06-27 09:36:10 --> Database Driver Class Initialized
INFO - 2022-06-27 09:36:10 --> Email Class Initialized
DEBUG - 2022-06-27 09:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 09:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 09:36:10 --> Controller Class Initialized
INFO - 2022-06-27 09:36:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 09:36:10 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 09:36:10 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 09:36:10 --> Final output sent to browser
DEBUG - 2022-06-27 09:36:10 --> Total execution time: 0.0351
INFO - 2022-06-27 09:36:10 --> Config Class Initialized
INFO - 2022-06-27 09:36:10 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:36:10 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:36:10 --> Utf8 Class Initialized
INFO - 2022-06-27 09:36:10 --> URI Class Initialized
INFO - 2022-06-27 09:36:10 --> Router Class Initialized
INFO - 2022-06-27 09:36:10 --> Output Class Initialized
INFO - 2022-06-27 09:36:10 --> Security Class Initialized
DEBUG - 2022-06-27 09:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:36:10 --> Input Class Initialized
INFO - 2022-06-27 09:36:10 --> Language Class Initialized
ERROR - 2022-06-27 09:36:10 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 09:36:10 --> Config Class Initialized
INFO - 2022-06-27 09:36:10 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:36:10 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:36:10 --> Utf8 Class Initialized
INFO - 2022-06-27 09:36:10 --> URI Class Initialized
INFO - 2022-06-27 09:36:10 --> Router Class Initialized
INFO - 2022-06-27 09:36:10 --> Output Class Initialized
INFO - 2022-06-27 09:36:10 --> Security Class Initialized
DEBUG - 2022-06-27 09:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:36:10 --> Input Class Initialized
INFO - 2022-06-27 09:36:10 --> Language Class Initialized
ERROR - 2022-06-27 09:36:10 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 09:36:31 --> Config Class Initialized
INFO - 2022-06-27 09:36:31 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:36:31 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:36:31 --> Utf8 Class Initialized
INFO - 2022-06-27 09:36:31 --> URI Class Initialized
INFO - 2022-06-27 09:36:31 --> Router Class Initialized
INFO - 2022-06-27 09:36:31 --> Output Class Initialized
INFO - 2022-06-27 09:36:31 --> Security Class Initialized
DEBUG - 2022-06-27 09:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:36:31 --> Input Class Initialized
INFO - 2022-06-27 09:36:31 --> Language Class Initialized
INFO - 2022-06-27 09:36:31 --> Loader Class Initialized
INFO - 2022-06-27 09:36:31 --> Helper loaded: url_helper
INFO - 2022-06-27 09:36:31 --> Helper loaded: file_helper
INFO - 2022-06-27 09:36:31 --> Database Driver Class Initialized
INFO - 2022-06-27 09:36:31 --> Email Class Initialized
DEBUG - 2022-06-27 09:36:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 09:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 09:36:31 --> Controller Class Initialized
INFO - 2022-06-27 09:36:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 09:36:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 09:36:31 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 09:36:31 --> Final output sent to browser
DEBUG - 2022-06-27 09:36:31 --> Total execution time: 0.1240
INFO - 2022-06-27 09:36:41 --> Config Class Initialized
INFO - 2022-06-27 09:36:41 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:36:41 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:36:41 --> Utf8 Class Initialized
INFO - 2022-06-27 09:36:41 --> URI Class Initialized
INFO - 2022-06-27 09:36:41 --> Router Class Initialized
INFO - 2022-06-27 09:36:41 --> Output Class Initialized
INFO - 2022-06-27 09:36:41 --> Security Class Initialized
DEBUG - 2022-06-27 09:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:36:41 --> Input Class Initialized
INFO - 2022-06-27 09:36:41 --> Language Class Initialized
INFO - 2022-06-27 09:36:41 --> Loader Class Initialized
INFO - 2022-06-27 09:36:41 --> Helper loaded: url_helper
INFO - 2022-06-27 09:36:41 --> Helper loaded: file_helper
INFO - 2022-06-27 09:36:41 --> Database Driver Class Initialized
INFO - 2022-06-27 09:36:41 --> Email Class Initialized
DEBUG - 2022-06-27 09:36:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 09:36:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 09:36:41 --> Controller Class Initialized
INFO - 2022-06-27 09:36:41 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 09:36:41 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 09:36:41 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 09:36:41 --> Final output sent to browser
DEBUG - 2022-06-27 09:36:41 --> Total execution time: 0.0437
INFO - 2022-06-27 09:36:58 --> Config Class Initialized
INFO - 2022-06-27 09:36:58 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:36:58 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:36:58 --> Utf8 Class Initialized
INFO - 2022-06-27 09:36:58 --> URI Class Initialized
INFO - 2022-06-27 09:36:58 --> Router Class Initialized
INFO - 2022-06-27 09:36:58 --> Output Class Initialized
INFO - 2022-06-27 09:36:58 --> Security Class Initialized
DEBUG - 2022-06-27 09:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:36:58 --> Input Class Initialized
INFO - 2022-06-27 09:36:58 --> Language Class Initialized
INFO - 2022-06-27 09:36:58 --> Loader Class Initialized
INFO - 2022-06-27 09:36:58 --> Helper loaded: url_helper
INFO - 2022-06-27 09:36:58 --> Helper loaded: file_helper
INFO - 2022-06-27 09:36:58 --> Database Driver Class Initialized
INFO - 2022-06-27 09:36:58 --> Email Class Initialized
DEBUG - 2022-06-27 09:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 09:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 09:36:58 --> Controller Class Initialized
INFO - 2022-06-27 09:36:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 09:36:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 09:36:58 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 09:36:58 --> Final output sent to browser
DEBUG - 2022-06-27 09:36:58 --> Total execution time: 0.0261
INFO - 2022-06-27 09:37:08 --> Config Class Initialized
INFO - 2022-06-27 09:37:08 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:37:08 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:37:08 --> Utf8 Class Initialized
INFO - 2022-06-27 09:37:08 --> URI Class Initialized
INFO - 2022-06-27 09:37:08 --> Router Class Initialized
INFO - 2022-06-27 09:37:08 --> Output Class Initialized
INFO - 2022-06-27 09:37:08 --> Security Class Initialized
DEBUG - 2022-06-27 09:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:37:08 --> Input Class Initialized
INFO - 2022-06-27 09:37:08 --> Language Class Initialized
INFO - 2022-06-27 09:37:08 --> Loader Class Initialized
INFO - 2022-06-27 09:37:08 --> Helper loaded: url_helper
INFO - 2022-06-27 09:37:08 --> Helper loaded: file_helper
INFO - 2022-06-27 09:37:08 --> Database Driver Class Initialized
INFO - 2022-06-27 09:37:08 --> Email Class Initialized
DEBUG - 2022-06-27 09:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 09:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 09:37:08 --> Controller Class Initialized
INFO - 2022-06-27 09:37:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 09:37:08 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 09:37:08 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 09:37:08 --> Final output sent to browser
DEBUG - 2022-06-27 09:37:08 --> Total execution time: 0.0271
INFO - 2022-06-27 09:37:17 --> Config Class Initialized
INFO - 2022-06-27 09:37:17 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:37:17 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:37:17 --> Utf8 Class Initialized
INFO - 2022-06-27 09:37:17 --> URI Class Initialized
INFO - 2022-06-27 09:37:17 --> Router Class Initialized
INFO - 2022-06-27 09:37:17 --> Output Class Initialized
INFO - 2022-06-27 09:37:17 --> Security Class Initialized
DEBUG - 2022-06-27 09:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:37:17 --> Input Class Initialized
INFO - 2022-06-27 09:37:17 --> Language Class Initialized
INFO - 2022-06-27 09:37:17 --> Loader Class Initialized
INFO - 2022-06-27 09:37:17 --> Helper loaded: url_helper
INFO - 2022-06-27 09:37:17 --> Helper loaded: file_helper
INFO - 2022-06-27 09:37:17 --> Database Driver Class Initialized
INFO - 2022-06-27 09:37:17 --> Email Class Initialized
DEBUG - 2022-06-27 09:37:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 09:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 09:37:17 --> Controller Class Initialized
INFO - 2022-06-27 09:37:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 09:37:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 09:37:17 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 09:37:17 --> Final output sent to browser
DEBUG - 2022-06-27 09:37:17 --> Total execution time: 0.0278
INFO - 2022-06-27 09:39:55 --> Config Class Initialized
INFO - 2022-06-27 09:39:55 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:39:55 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:39:55 --> Utf8 Class Initialized
INFO - 2022-06-27 09:39:55 --> URI Class Initialized
INFO - 2022-06-27 09:39:55 --> Router Class Initialized
INFO - 2022-06-27 09:39:55 --> Output Class Initialized
INFO - 2022-06-27 09:39:55 --> Security Class Initialized
DEBUG - 2022-06-27 09:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:39:55 --> Input Class Initialized
INFO - 2022-06-27 09:39:55 --> Language Class Initialized
INFO - 2022-06-27 09:39:55 --> Loader Class Initialized
INFO - 2022-06-27 09:39:55 --> Helper loaded: url_helper
INFO - 2022-06-27 09:39:55 --> Helper loaded: file_helper
INFO - 2022-06-27 09:39:55 --> Database Driver Class Initialized
INFO - 2022-06-27 09:39:55 --> Email Class Initialized
DEBUG - 2022-06-27 09:39:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 09:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 09:39:55 --> Controller Class Initialized
INFO - 2022-06-27 09:39:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 09:39:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 09:39:55 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 09:39:55 --> Final output sent to browser
DEBUG - 2022-06-27 09:39:55 --> Total execution time: 0.0527
INFO - 2022-06-27 09:40:23 --> Config Class Initialized
INFO - 2022-06-27 09:40:23 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:40:23 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:40:23 --> Utf8 Class Initialized
INFO - 2022-06-27 09:40:23 --> URI Class Initialized
INFO - 2022-06-27 09:40:23 --> Router Class Initialized
INFO - 2022-06-27 09:40:23 --> Output Class Initialized
INFO - 2022-06-27 09:40:23 --> Security Class Initialized
DEBUG - 2022-06-27 09:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:40:23 --> Input Class Initialized
INFO - 2022-06-27 09:40:23 --> Language Class Initialized
INFO - 2022-06-27 09:40:23 --> Loader Class Initialized
INFO - 2022-06-27 09:40:23 --> Helper loaded: url_helper
INFO - 2022-06-27 09:40:23 --> Helper loaded: file_helper
INFO - 2022-06-27 09:40:23 --> Database Driver Class Initialized
INFO - 2022-06-27 09:40:23 --> Email Class Initialized
DEBUG - 2022-06-27 09:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 09:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 09:40:23 --> Controller Class Initialized
INFO - 2022-06-27 09:40:23 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 09:40:23 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 09:40:23 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 09:40:23 --> Final output sent to browser
DEBUG - 2022-06-27 09:40:23 --> Total execution time: 0.0410
INFO - 2022-06-27 09:40:31 --> Config Class Initialized
INFO - 2022-06-27 09:40:31 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:40:31 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:40:31 --> Utf8 Class Initialized
INFO - 2022-06-27 09:40:31 --> URI Class Initialized
INFO - 2022-06-27 09:40:31 --> Router Class Initialized
INFO - 2022-06-27 09:40:31 --> Output Class Initialized
INFO - 2022-06-27 09:40:31 --> Security Class Initialized
DEBUG - 2022-06-27 09:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:40:31 --> Input Class Initialized
INFO - 2022-06-27 09:40:31 --> Language Class Initialized
INFO - 2022-06-27 09:40:31 --> Loader Class Initialized
INFO - 2022-06-27 09:40:31 --> Helper loaded: url_helper
INFO - 2022-06-27 09:40:31 --> Helper loaded: file_helper
INFO - 2022-06-27 09:40:31 --> Database Driver Class Initialized
INFO - 2022-06-27 09:40:31 --> Email Class Initialized
DEBUG - 2022-06-27 09:40:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 09:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 09:40:31 --> Controller Class Initialized
INFO - 2022-06-27 09:40:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 09:40:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 09:40:31 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 09:40:31 --> Final output sent to browser
DEBUG - 2022-06-27 09:40:31 --> Total execution time: 0.0446
INFO - 2022-06-27 09:40:45 --> Config Class Initialized
INFO - 2022-06-27 09:40:45 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:40:45 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:40:45 --> Utf8 Class Initialized
INFO - 2022-06-27 09:40:45 --> URI Class Initialized
INFO - 2022-06-27 09:40:45 --> Router Class Initialized
INFO - 2022-06-27 09:40:45 --> Output Class Initialized
INFO - 2022-06-27 09:40:45 --> Security Class Initialized
DEBUG - 2022-06-27 09:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:40:45 --> Input Class Initialized
INFO - 2022-06-27 09:40:45 --> Language Class Initialized
INFO - 2022-06-27 09:40:45 --> Loader Class Initialized
INFO - 2022-06-27 09:40:45 --> Helper loaded: url_helper
INFO - 2022-06-27 09:40:45 --> Helper loaded: file_helper
INFO - 2022-06-27 09:40:45 --> Database Driver Class Initialized
INFO - 2022-06-27 09:40:45 --> Email Class Initialized
DEBUG - 2022-06-27 09:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 09:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 09:40:45 --> Controller Class Initialized
INFO - 2022-06-27 09:40:45 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 09:40:45 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 09:40:45 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 09:40:45 --> Final output sent to browser
DEBUG - 2022-06-27 09:40:45 --> Total execution time: 0.0261
INFO - 2022-06-27 09:40:53 --> Config Class Initialized
INFO - 2022-06-27 09:40:53 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:40:53 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:40:53 --> Utf8 Class Initialized
INFO - 2022-06-27 09:40:53 --> URI Class Initialized
INFO - 2022-06-27 09:40:53 --> Router Class Initialized
INFO - 2022-06-27 09:40:53 --> Output Class Initialized
INFO - 2022-06-27 09:40:53 --> Security Class Initialized
DEBUG - 2022-06-27 09:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:40:53 --> Input Class Initialized
INFO - 2022-06-27 09:40:53 --> Language Class Initialized
INFO - 2022-06-27 09:40:53 --> Loader Class Initialized
INFO - 2022-06-27 09:40:53 --> Helper loaded: url_helper
INFO - 2022-06-27 09:40:53 --> Helper loaded: file_helper
INFO - 2022-06-27 09:40:53 --> Database Driver Class Initialized
INFO - 2022-06-27 09:40:53 --> Email Class Initialized
DEBUG - 2022-06-27 09:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 09:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 09:40:53 --> Controller Class Initialized
INFO - 2022-06-27 09:40:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 09:40:53 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 09:40:53 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 09:40:53 --> Final output sent to browser
DEBUG - 2022-06-27 09:40:53 --> Total execution time: 0.0243
INFO - 2022-06-27 09:47:48 --> Config Class Initialized
INFO - 2022-06-27 09:47:48 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:47:48 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:47:48 --> Utf8 Class Initialized
INFO - 2022-06-27 09:47:48 --> URI Class Initialized
INFO - 2022-06-27 09:47:48 --> Router Class Initialized
INFO - 2022-06-27 09:47:48 --> Output Class Initialized
INFO - 2022-06-27 09:47:48 --> Security Class Initialized
DEBUG - 2022-06-27 09:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:47:48 --> Input Class Initialized
INFO - 2022-06-27 09:47:48 --> Language Class Initialized
INFO - 2022-06-27 09:47:48 --> Loader Class Initialized
INFO - 2022-06-27 09:47:48 --> Helper loaded: url_helper
INFO - 2022-06-27 09:47:48 --> Helper loaded: file_helper
INFO - 2022-06-27 09:47:48 --> Database Driver Class Initialized
INFO - 2022-06-27 09:47:48 --> Config Class Initialized
INFO - 2022-06-27 09:47:48 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:47:48 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:47:48 --> Utf8 Class Initialized
INFO - 2022-06-27 09:47:48 --> URI Class Initialized
INFO - 2022-06-27 09:47:48 --> Router Class Initialized
INFO - 2022-06-27 09:47:48 --> Output Class Initialized
INFO - 2022-06-27 09:47:48 --> Security Class Initialized
DEBUG - 2022-06-27 09:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:47:48 --> Input Class Initialized
INFO - 2022-06-27 09:47:48 --> Language Class Initialized
INFO - 2022-06-27 09:47:48 --> Loader Class Initialized
INFO - 2022-06-27 09:47:48 --> Helper loaded: url_helper
INFO - 2022-06-27 09:47:48 --> Helper loaded: file_helper
INFO - 2022-06-27 09:47:48 --> Database Driver Class Initialized
INFO - 2022-06-27 09:47:48 --> Email Class Initialized
DEBUG - 2022-06-27 09:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 09:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 09:47:48 --> Controller Class Initialized
INFO - 2022-06-27 09:47:48 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 09:47:48 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 09:47:48 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 09:47:48 --> Final output sent to browser
DEBUG - 2022-06-27 09:47:48 --> Total execution time: 0.0271
INFO - 2022-06-27 09:47:48 --> Email Class Initialized
DEBUG - 2022-06-27 09:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 09:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 09:47:48 --> Controller Class Initialized
INFO - 2022-06-27 09:47:48 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 09:47:48 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 09:47:48 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 09:47:48 --> Final output sent to browser
DEBUG - 2022-06-27 09:47:48 --> Total execution time: 0.3968
INFO - 2022-06-27 09:47:49 --> Config Class Initialized
INFO - 2022-06-27 09:47:49 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:47:49 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:47:49 --> Utf8 Class Initialized
INFO - 2022-06-27 09:47:49 --> URI Class Initialized
INFO - 2022-06-27 09:47:49 --> Router Class Initialized
INFO - 2022-06-27 09:47:49 --> Output Class Initialized
INFO - 2022-06-27 09:47:49 --> Security Class Initialized
DEBUG - 2022-06-27 09:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:47:49 --> Input Class Initialized
INFO - 2022-06-27 09:47:49 --> Language Class Initialized
INFO - 2022-06-27 09:47:49 --> Loader Class Initialized
INFO - 2022-06-27 09:47:49 --> Helper loaded: url_helper
INFO - 2022-06-27 09:47:49 --> Helper loaded: file_helper
INFO - 2022-06-27 09:47:49 --> Database Driver Class Initialized
INFO - 2022-06-27 09:47:49 --> Email Class Initialized
DEBUG - 2022-06-27 09:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 09:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 09:47:49 --> Controller Class Initialized
INFO - 2022-06-27 09:47:49 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 09:47:49 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 09:47:49 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 09:47:49 --> Final output sent to browser
DEBUG - 2022-06-27 09:47:49 --> Total execution time: 0.0802
INFO - 2022-06-27 09:54:02 --> Config Class Initialized
INFO - 2022-06-27 09:54:02 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:54:02 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:54:02 --> Utf8 Class Initialized
INFO - 2022-06-27 09:54:02 --> URI Class Initialized
INFO - 2022-06-27 09:54:02 --> Router Class Initialized
INFO - 2022-06-27 09:54:02 --> Output Class Initialized
INFO - 2022-06-27 09:54:02 --> Security Class Initialized
DEBUG - 2022-06-27 09:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:54:02 --> Input Class Initialized
INFO - 2022-06-27 09:54:02 --> Language Class Initialized
ERROR - 2022-06-27 09:54:02 --> Severity: error --> Exception: syntax error, unexpected '=' C:\wamp64\www\qr\application\controllers\Tokenctrl.php 81
INFO - 2022-06-27 09:54:38 --> Config Class Initialized
INFO - 2022-06-27 09:54:38 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:54:38 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:54:38 --> Utf8 Class Initialized
INFO - 2022-06-27 09:54:38 --> URI Class Initialized
INFO - 2022-06-27 09:54:38 --> Router Class Initialized
INFO - 2022-06-27 09:54:38 --> Output Class Initialized
INFO - 2022-06-27 09:54:38 --> Security Class Initialized
DEBUG - 2022-06-27 09:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:54:38 --> Input Class Initialized
INFO - 2022-06-27 09:54:38 --> Language Class Initialized
INFO - 2022-06-27 09:54:38 --> Loader Class Initialized
INFO - 2022-06-27 09:54:38 --> Helper loaded: url_helper
INFO - 2022-06-27 09:54:38 --> Helper loaded: file_helper
INFO - 2022-06-27 09:54:38 --> Database Driver Class Initialized
INFO - 2022-06-27 09:54:38 --> Email Class Initialized
DEBUG - 2022-06-27 09:54:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 09:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 09:54:38 --> Controller Class Initialized
INFO - 2022-06-27 09:54:38 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 09:54:38 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 09:54:38 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 09:54:38 --> Final output sent to browser
DEBUG - 2022-06-27 09:54:38 --> Total execution time: 0.0299
INFO - 2022-06-27 09:54:38 --> Config Class Initialized
INFO - 2022-06-27 09:54:38 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:54:38 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:54:38 --> Utf8 Class Initialized
INFO - 2022-06-27 09:54:38 --> URI Class Initialized
INFO - 2022-06-27 09:54:38 --> Router Class Initialized
INFO - 2022-06-27 09:54:38 --> Output Class Initialized
INFO - 2022-06-27 09:54:38 --> Security Class Initialized
DEBUG - 2022-06-27 09:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:54:38 --> Input Class Initialized
INFO - 2022-06-27 09:54:38 --> Language Class Initialized
ERROR - 2022-06-27 09:54:38 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 09:54:38 --> Config Class Initialized
INFO - 2022-06-27 09:54:38 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:54:38 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:54:38 --> Utf8 Class Initialized
INFO - 2022-06-27 09:54:38 --> URI Class Initialized
INFO - 2022-06-27 09:54:38 --> Router Class Initialized
INFO - 2022-06-27 09:54:38 --> Output Class Initialized
INFO - 2022-06-27 09:54:38 --> Security Class Initialized
DEBUG - 2022-06-27 09:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:54:38 --> Input Class Initialized
INFO - 2022-06-27 09:54:38 --> Language Class Initialized
ERROR - 2022-06-27 09:54:38 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 09:54:41 --> Config Class Initialized
INFO - 2022-06-27 09:54:41 --> Hooks Class Initialized
DEBUG - 2022-06-27 09:54:41 --> UTF-8 Support Enabled
INFO - 2022-06-27 09:54:41 --> Utf8 Class Initialized
INFO - 2022-06-27 09:54:41 --> URI Class Initialized
INFO - 2022-06-27 09:54:41 --> Router Class Initialized
INFO - 2022-06-27 09:54:41 --> Output Class Initialized
INFO - 2022-06-27 09:54:41 --> Security Class Initialized
DEBUG - 2022-06-27 09:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 09:54:41 --> Input Class Initialized
INFO - 2022-06-27 09:54:41 --> Language Class Initialized
INFO - 2022-06-27 09:54:41 --> Loader Class Initialized
INFO - 2022-06-27 09:54:41 --> Helper loaded: url_helper
INFO - 2022-06-27 09:54:41 --> Helper loaded: file_helper
INFO - 2022-06-27 09:54:41 --> Database Driver Class Initialized
INFO - 2022-06-27 09:54:41 --> Email Class Initialized
DEBUG - 2022-06-27 09:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 09:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 09:54:41 --> Controller Class Initialized
INFO - 2022-06-27 09:54:41 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 09:54:41 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 09:54:41 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 09:54:41 --> Final output sent to browser
DEBUG - 2022-06-27 09:54:41 --> Total execution time: 0.0334
INFO - 2022-06-27 10:05:49 --> Config Class Initialized
INFO - 2022-06-27 10:05:49 --> Hooks Class Initialized
DEBUG - 2022-06-27 10:05:49 --> UTF-8 Support Enabled
INFO - 2022-06-27 10:05:49 --> Utf8 Class Initialized
INFO - 2022-06-27 10:05:49 --> URI Class Initialized
INFO - 2022-06-27 10:05:49 --> Router Class Initialized
INFO - 2022-06-27 10:05:49 --> Output Class Initialized
INFO - 2022-06-27 10:05:49 --> Security Class Initialized
DEBUG - 2022-06-27 10:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 10:05:49 --> Input Class Initialized
INFO - 2022-06-27 10:05:49 --> Language Class Initialized
INFO - 2022-06-27 10:05:49 --> Loader Class Initialized
INFO - 2022-06-27 10:05:49 --> Helper loaded: url_helper
INFO - 2022-06-27 10:05:49 --> Helper loaded: file_helper
INFO - 2022-06-27 10:05:49 --> Database Driver Class Initialized
INFO - 2022-06-27 10:05:49 --> Email Class Initialized
DEBUG - 2022-06-27 10:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 10:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 10:05:49 --> Controller Class Initialized
INFO - 2022-06-27 10:05:49 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 10:05:49 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 10:05:49 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 10:05:49 --> Final output sent to browser
DEBUG - 2022-06-27 10:05:49 --> Total execution time: 0.0287
INFO - 2022-06-27 10:06:08 --> Config Class Initialized
INFO - 2022-06-27 10:06:08 --> Hooks Class Initialized
DEBUG - 2022-06-27 10:06:08 --> UTF-8 Support Enabled
INFO - 2022-06-27 10:06:08 --> Utf8 Class Initialized
INFO - 2022-06-27 10:06:08 --> URI Class Initialized
INFO - 2022-06-27 10:06:08 --> Router Class Initialized
INFO - 2022-06-27 10:06:08 --> Output Class Initialized
INFO - 2022-06-27 10:06:08 --> Security Class Initialized
DEBUG - 2022-06-27 10:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 10:06:08 --> Input Class Initialized
INFO - 2022-06-27 10:06:08 --> Language Class Initialized
INFO - 2022-06-27 10:06:08 --> Loader Class Initialized
INFO - 2022-06-27 10:06:08 --> Helper loaded: url_helper
INFO - 2022-06-27 10:06:08 --> Helper loaded: file_helper
INFO - 2022-06-27 10:06:08 --> Database Driver Class Initialized
INFO - 2022-06-27 10:06:08 --> Email Class Initialized
DEBUG - 2022-06-27 10:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 10:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 10:06:08 --> Controller Class Initialized
INFO - 2022-06-27 10:06:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 10:06:08 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 10:06:08 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 10:06:08 --> Final output sent to browser
DEBUG - 2022-06-27 10:06:08 --> Total execution time: 0.0251
INFO - 2022-06-27 10:29:56 --> Config Class Initialized
INFO - 2022-06-27 10:29:56 --> Hooks Class Initialized
DEBUG - 2022-06-27 10:29:56 --> UTF-8 Support Enabled
INFO - 2022-06-27 10:29:56 --> Utf8 Class Initialized
INFO - 2022-06-27 10:29:56 --> URI Class Initialized
INFO - 2022-06-27 10:29:56 --> Router Class Initialized
INFO - 2022-06-27 10:29:56 --> Output Class Initialized
INFO - 2022-06-27 10:29:56 --> Security Class Initialized
DEBUG - 2022-06-27 10:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 10:29:56 --> Input Class Initialized
INFO - 2022-06-27 10:29:56 --> Language Class Initialized
INFO - 2022-06-27 10:29:56 --> Loader Class Initialized
INFO - 2022-06-27 10:29:56 --> Helper loaded: url_helper
INFO - 2022-06-27 10:29:56 --> Helper loaded: file_helper
INFO - 2022-06-27 10:29:56 --> Database Driver Class Initialized
INFO - 2022-06-27 10:29:56 --> Email Class Initialized
DEBUG - 2022-06-27 10:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 10:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 10:29:56 --> Controller Class Initialized
INFO - 2022-06-27 10:29:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 10:29:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 10:30:01 --> Config Class Initialized
INFO - 2022-06-27 10:30:01 --> Hooks Class Initialized
DEBUG - 2022-06-27 10:30:01 --> UTF-8 Support Enabled
INFO - 2022-06-27 10:30:01 --> Utf8 Class Initialized
INFO - 2022-06-27 10:30:01 --> URI Class Initialized
INFO - 2022-06-27 10:30:01 --> Router Class Initialized
INFO - 2022-06-27 10:30:01 --> Output Class Initialized
INFO - 2022-06-27 10:30:01 --> Security Class Initialized
DEBUG - 2022-06-27 10:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 10:30:01 --> Input Class Initialized
INFO - 2022-06-27 10:30:01 --> Language Class Initialized
INFO - 2022-06-27 10:30:01 --> Loader Class Initialized
INFO - 2022-06-27 10:30:01 --> Helper loaded: url_helper
INFO - 2022-06-27 10:30:01 --> Helper loaded: file_helper
INFO - 2022-06-27 10:30:01 --> Database Driver Class Initialized
INFO - 2022-06-27 10:30:01 --> Email Class Initialized
DEBUG - 2022-06-27 10:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 10:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 10:30:01 --> Controller Class Initialized
INFO - 2022-06-27 10:30:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 10:30:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 10:32:06 --> Config Class Initialized
INFO - 2022-06-27 10:32:06 --> Hooks Class Initialized
DEBUG - 2022-06-27 10:32:06 --> UTF-8 Support Enabled
INFO - 2022-06-27 10:32:06 --> Utf8 Class Initialized
INFO - 2022-06-27 10:32:06 --> URI Class Initialized
INFO - 2022-06-27 10:32:06 --> Router Class Initialized
INFO - 2022-06-27 10:32:06 --> Output Class Initialized
INFO - 2022-06-27 10:32:06 --> Security Class Initialized
DEBUG - 2022-06-27 10:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 10:32:06 --> Input Class Initialized
INFO - 2022-06-27 10:32:06 --> Language Class Initialized
INFO - 2022-06-27 10:32:06 --> Loader Class Initialized
INFO - 2022-06-27 10:32:06 --> Helper loaded: url_helper
INFO - 2022-06-27 10:32:06 --> Helper loaded: file_helper
INFO - 2022-06-27 10:32:06 --> Database Driver Class Initialized
INFO - 2022-06-27 10:32:06 --> Email Class Initialized
DEBUG - 2022-06-27 10:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 10:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 10:32:06 --> Controller Class Initialized
INFO - 2022-06-27 10:32:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 10:32:06 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 10:34:13 --> Config Class Initialized
INFO - 2022-06-27 10:34:13 --> Hooks Class Initialized
DEBUG - 2022-06-27 10:34:13 --> UTF-8 Support Enabled
INFO - 2022-06-27 10:34:13 --> Utf8 Class Initialized
INFO - 2022-06-27 10:34:13 --> URI Class Initialized
INFO - 2022-06-27 10:34:13 --> Router Class Initialized
INFO - 2022-06-27 10:34:13 --> Output Class Initialized
INFO - 2022-06-27 10:34:13 --> Security Class Initialized
DEBUG - 2022-06-27 10:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 10:34:13 --> Input Class Initialized
INFO - 2022-06-27 10:34:13 --> Language Class Initialized
INFO - 2022-06-27 10:34:13 --> Loader Class Initialized
INFO - 2022-06-27 10:34:13 --> Helper loaded: url_helper
INFO - 2022-06-27 10:34:13 --> Helper loaded: file_helper
INFO - 2022-06-27 10:34:13 --> Database Driver Class Initialized
INFO - 2022-06-27 10:34:13 --> Email Class Initialized
DEBUG - 2022-06-27 10:34:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 10:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 10:34:13 --> Controller Class Initialized
INFO - 2022-06-27 10:34:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 10:34:13 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 10:34:57 --> Config Class Initialized
INFO - 2022-06-27 10:34:57 --> Hooks Class Initialized
DEBUG - 2022-06-27 10:34:57 --> UTF-8 Support Enabled
INFO - 2022-06-27 10:34:57 --> Utf8 Class Initialized
INFO - 2022-06-27 10:34:57 --> URI Class Initialized
INFO - 2022-06-27 10:34:57 --> Router Class Initialized
INFO - 2022-06-27 10:34:57 --> Output Class Initialized
INFO - 2022-06-27 10:34:57 --> Security Class Initialized
DEBUG - 2022-06-27 10:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 10:34:57 --> Input Class Initialized
INFO - 2022-06-27 10:34:57 --> Language Class Initialized
INFO - 2022-06-27 10:34:57 --> Loader Class Initialized
INFO - 2022-06-27 10:34:57 --> Helper loaded: url_helper
INFO - 2022-06-27 10:34:57 --> Helper loaded: file_helper
INFO - 2022-06-27 10:34:57 --> Database Driver Class Initialized
INFO - 2022-06-27 10:34:57 --> Email Class Initialized
DEBUG - 2022-06-27 10:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 10:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 10:34:57 --> Controller Class Initialized
INFO - 2022-06-27 10:34:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 10:34:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 10:36:13 --> Config Class Initialized
INFO - 2022-06-27 10:36:13 --> Hooks Class Initialized
DEBUG - 2022-06-27 10:36:13 --> UTF-8 Support Enabled
INFO - 2022-06-27 10:36:13 --> Utf8 Class Initialized
INFO - 2022-06-27 10:36:13 --> URI Class Initialized
INFO - 2022-06-27 10:36:13 --> Router Class Initialized
INFO - 2022-06-27 10:36:13 --> Output Class Initialized
INFO - 2022-06-27 10:36:13 --> Security Class Initialized
DEBUG - 2022-06-27 10:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 10:36:13 --> Input Class Initialized
INFO - 2022-06-27 10:36:13 --> Language Class Initialized
INFO - 2022-06-27 10:36:13 --> Loader Class Initialized
INFO - 2022-06-27 10:36:13 --> Helper loaded: url_helper
INFO - 2022-06-27 10:36:13 --> Helper loaded: file_helper
INFO - 2022-06-27 10:36:13 --> Database Driver Class Initialized
INFO - 2022-06-27 10:36:13 --> Email Class Initialized
DEBUG - 2022-06-27 10:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 10:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 10:36:13 --> Controller Class Initialized
INFO - 2022-06-27 10:36:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 10:36:13 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 10:43:38 --> Config Class Initialized
INFO - 2022-06-27 10:43:38 --> Hooks Class Initialized
DEBUG - 2022-06-27 10:43:38 --> UTF-8 Support Enabled
INFO - 2022-06-27 10:43:38 --> Utf8 Class Initialized
INFO - 2022-06-27 10:43:38 --> URI Class Initialized
INFO - 2022-06-27 10:43:38 --> Router Class Initialized
INFO - 2022-06-27 10:43:38 --> Output Class Initialized
INFO - 2022-06-27 10:43:38 --> Security Class Initialized
DEBUG - 2022-06-27 10:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 10:43:38 --> Input Class Initialized
INFO - 2022-06-27 10:43:38 --> Language Class Initialized
INFO - 2022-06-27 10:43:38 --> Loader Class Initialized
INFO - 2022-06-27 10:43:38 --> Helper loaded: url_helper
INFO - 2022-06-27 10:43:38 --> Helper loaded: file_helper
INFO - 2022-06-27 10:43:38 --> Database Driver Class Initialized
INFO - 2022-06-27 10:43:39 --> Email Class Initialized
DEBUG - 2022-06-27 10:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 10:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 10:43:39 --> Controller Class Initialized
INFO - 2022-06-27 10:43:39 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 10:43:39 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 10:46:57 --> Config Class Initialized
INFO - 2022-06-27 10:46:57 --> Hooks Class Initialized
DEBUG - 2022-06-27 10:46:57 --> UTF-8 Support Enabled
INFO - 2022-06-27 10:46:57 --> Utf8 Class Initialized
INFO - 2022-06-27 10:46:57 --> URI Class Initialized
INFO - 2022-06-27 10:46:57 --> Router Class Initialized
INFO - 2022-06-27 10:46:57 --> Output Class Initialized
INFO - 2022-06-27 10:46:57 --> Security Class Initialized
DEBUG - 2022-06-27 10:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 10:46:57 --> Input Class Initialized
INFO - 2022-06-27 10:46:57 --> Language Class Initialized
INFO - 2022-06-27 10:46:57 --> Loader Class Initialized
INFO - 2022-06-27 10:46:57 --> Helper loaded: url_helper
INFO - 2022-06-27 10:46:57 --> Helper loaded: file_helper
INFO - 2022-06-27 10:46:57 --> Database Driver Class Initialized
INFO - 2022-06-27 10:46:57 --> Email Class Initialized
DEBUG - 2022-06-27 10:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 10:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 10:46:57 --> Controller Class Initialized
INFO - 2022-06-27 10:46:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 10:46:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-27 10:46:57 --> Severity: Notice --> Undefined variable: user_details C:\wamp64\www\qr\application\views\doc_screen\doctor.php 323
INFO - 2022-06-27 10:46:57 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 10:46:57 --> Final output sent to browser
DEBUG - 2022-06-27 10:46:57 --> Total execution time: 0.0357
INFO - 2022-06-27 10:46:57 --> Config Class Initialized
INFO - 2022-06-27 10:46:57 --> Hooks Class Initialized
DEBUG - 2022-06-27 10:46:57 --> UTF-8 Support Enabled
INFO - 2022-06-27 10:46:57 --> Utf8 Class Initialized
INFO - 2022-06-27 10:46:57 --> URI Class Initialized
INFO - 2022-06-27 10:46:57 --> Router Class Initialized
INFO - 2022-06-27 10:46:57 --> Output Class Initialized
INFO - 2022-06-27 10:46:57 --> Security Class Initialized
DEBUG - 2022-06-27 10:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 10:46:57 --> Input Class Initialized
INFO - 2022-06-27 10:46:57 --> Language Class Initialized
ERROR - 2022-06-27 10:46:57 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 10:46:57 --> Config Class Initialized
INFO - 2022-06-27 10:46:57 --> Hooks Class Initialized
DEBUG - 2022-06-27 10:46:57 --> UTF-8 Support Enabled
INFO - 2022-06-27 10:46:57 --> Utf8 Class Initialized
INFO - 2022-06-27 10:46:57 --> URI Class Initialized
INFO - 2022-06-27 10:46:57 --> Router Class Initialized
INFO - 2022-06-27 10:46:57 --> Output Class Initialized
INFO - 2022-06-27 10:46:57 --> Security Class Initialized
DEBUG - 2022-06-27 10:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 10:46:57 --> Input Class Initialized
INFO - 2022-06-27 10:46:57 --> Language Class Initialized
ERROR - 2022-06-27 10:46:57 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 10:48:37 --> Config Class Initialized
INFO - 2022-06-27 10:48:37 --> Hooks Class Initialized
DEBUG - 2022-06-27 10:48:37 --> UTF-8 Support Enabled
INFO - 2022-06-27 10:48:37 --> Utf8 Class Initialized
INFO - 2022-06-27 10:48:37 --> URI Class Initialized
INFO - 2022-06-27 10:48:37 --> Router Class Initialized
INFO - 2022-06-27 10:48:37 --> Output Class Initialized
INFO - 2022-06-27 10:48:37 --> Security Class Initialized
DEBUG - 2022-06-27 10:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 10:48:37 --> Input Class Initialized
INFO - 2022-06-27 10:48:37 --> Language Class Initialized
INFO - 2022-06-27 10:48:37 --> Loader Class Initialized
INFO - 2022-06-27 10:48:37 --> Helper loaded: url_helper
INFO - 2022-06-27 10:48:37 --> Helper loaded: file_helper
INFO - 2022-06-27 10:48:37 --> Database Driver Class Initialized
INFO - 2022-06-27 10:48:37 --> Email Class Initialized
DEBUG - 2022-06-27 10:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 10:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 10:48:37 --> Controller Class Initialized
INFO - 2022-06-27 10:48:37 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 10:48:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-27 10:48:37 --> Severity: Notice --> Undefined variable: user_details C:\wamp64\www\qr\application\views\doc_screen\doctor.php 323
INFO - 2022-06-27 10:48:37 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 10:48:37 --> Final output sent to browser
DEBUG - 2022-06-27 10:48:37 --> Total execution time: 0.0383
INFO - 2022-06-27 10:48:37 --> Config Class Initialized
INFO - 2022-06-27 10:48:37 --> Hooks Class Initialized
DEBUG - 2022-06-27 10:48:37 --> UTF-8 Support Enabled
INFO - 2022-06-27 10:48:37 --> Utf8 Class Initialized
INFO - 2022-06-27 10:48:37 --> URI Class Initialized
INFO - 2022-06-27 10:48:37 --> Router Class Initialized
INFO - 2022-06-27 10:48:37 --> Output Class Initialized
INFO - 2022-06-27 10:48:37 --> Security Class Initialized
DEBUG - 2022-06-27 10:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 10:48:37 --> Input Class Initialized
INFO - 2022-06-27 10:48:37 --> Language Class Initialized
ERROR - 2022-06-27 10:48:37 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 10:48:37 --> Config Class Initialized
INFO - 2022-06-27 10:48:37 --> Hooks Class Initialized
DEBUG - 2022-06-27 10:48:37 --> UTF-8 Support Enabled
INFO - 2022-06-27 10:48:37 --> Utf8 Class Initialized
INFO - 2022-06-27 10:48:37 --> URI Class Initialized
INFO - 2022-06-27 10:48:37 --> Router Class Initialized
INFO - 2022-06-27 10:48:37 --> Output Class Initialized
INFO - 2022-06-27 10:48:37 --> Security Class Initialized
DEBUG - 2022-06-27 10:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 10:48:37 --> Input Class Initialized
INFO - 2022-06-27 10:48:37 --> Language Class Initialized
ERROR - 2022-06-27 10:48:37 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 10:48:40 --> Config Class Initialized
INFO - 2022-06-27 10:48:40 --> Hooks Class Initialized
DEBUG - 2022-06-27 10:48:40 --> UTF-8 Support Enabled
INFO - 2022-06-27 10:48:40 --> Utf8 Class Initialized
INFO - 2022-06-27 10:48:40 --> URI Class Initialized
INFO - 2022-06-27 10:48:40 --> Router Class Initialized
INFO - 2022-06-27 10:48:40 --> Output Class Initialized
INFO - 2022-06-27 10:48:40 --> Security Class Initialized
DEBUG - 2022-06-27 10:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 10:48:40 --> Input Class Initialized
INFO - 2022-06-27 10:48:40 --> Language Class Initialized
INFO - 2022-06-27 10:48:40 --> Loader Class Initialized
INFO - 2022-06-27 10:48:40 --> Helper loaded: url_helper
INFO - 2022-06-27 10:48:40 --> Helper loaded: file_helper
INFO - 2022-06-27 10:48:40 --> Database Driver Class Initialized
INFO - 2022-06-27 10:48:40 --> Email Class Initialized
DEBUG - 2022-06-27 10:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 10:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 10:48:40 --> Controller Class Initialized
INFO - 2022-06-27 10:48:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 10:48:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-27 10:48:40 --> Severity: Notice --> Undefined variable: user_details C:\wamp64\www\qr\application\views\doc_screen\doctor.php 323
INFO - 2022-06-27 10:48:40 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 10:48:40 --> Final output sent to browser
DEBUG - 2022-06-27 10:48:40 --> Total execution time: 0.0429
INFO - 2022-06-27 10:48:40 --> Config Class Initialized
INFO - 2022-06-27 10:48:40 --> Config Class Initialized
INFO - 2022-06-27 10:48:40 --> Hooks Class Initialized
INFO - 2022-06-27 10:48:40 --> Hooks Class Initialized
DEBUG - 2022-06-27 10:48:40 --> UTF-8 Support Enabled
INFO - 2022-06-27 10:48:40 --> Utf8 Class Initialized
DEBUG - 2022-06-27 10:48:40 --> UTF-8 Support Enabled
INFO - 2022-06-27 10:48:40 --> Utf8 Class Initialized
INFO - 2022-06-27 10:48:40 --> URI Class Initialized
INFO - 2022-06-27 10:48:40 --> URI Class Initialized
INFO - 2022-06-27 10:48:40 --> Router Class Initialized
INFO - 2022-06-27 10:48:40 --> Router Class Initialized
INFO - 2022-06-27 10:48:40 --> Output Class Initialized
INFO - 2022-06-27 10:48:40 --> Output Class Initialized
INFO - 2022-06-27 10:48:40 --> Security Class Initialized
INFO - 2022-06-27 10:48:40 --> Security Class Initialized
DEBUG - 2022-06-27 10:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 10:48:40 --> Input Class Initialized
INFO - 2022-06-27 10:48:40 --> Input Class Initialized
INFO - 2022-06-27 10:48:40 --> Language Class Initialized
INFO - 2022-06-27 10:48:40 --> Language Class Initialized
ERROR - 2022-06-27 10:48:40 --> 404 Page Not Found: Tokenctrl/localhost
ERROR - 2022-06-27 10:48:40 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 10:49:07 --> Config Class Initialized
INFO - 2022-06-27 10:49:07 --> Hooks Class Initialized
DEBUG - 2022-06-27 10:49:07 --> UTF-8 Support Enabled
INFO - 2022-06-27 10:49:07 --> Utf8 Class Initialized
INFO - 2022-06-27 10:49:07 --> URI Class Initialized
INFO - 2022-06-27 10:49:07 --> Router Class Initialized
INFO - 2022-06-27 10:49:07 --> Output Class Initialized
INFO - 2022-06-27 10:49:07 --> Security Class Initialized
DEBUG - 2022-06-27 10:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 10:49:07 --> Input Class Initialized
INFO - 2022-06-27 10:49:07 --> Language Class Initialized
INFO - 2022-06-27 10:49:07 --> Loader Class Initialized
INFO - 2022-06-27 10:49:07 --> Helper loaded: url_helper
INFO - 2022-06-27 10:49:07 --> Helper loaded: file_helper
INFO - 2022-06-27 10:49:07 --> Database Driver Class Initialized
INFO - 2022-06-27 10:49:07 --> Email Class Initialized
DEBUG - 2022-06-27 10:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 10:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 10:49:07 --> Controller Class Initialized
INFO - 2022-06-27 10:49:07 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 10:49:07 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 10:49:07 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 10:49:07 --> Final output sent to browser
DEBUG - 2022-06-27 10:49:07 --> Total execution time: 0.0344
INFO - 2022-06-27 10:49:12 --> Config Class Initialized
INFO - 2022-06-27 10:49:12 --> Hooks Class Initialized
DEBUG - 2022-06-27 10:49:12 --> UTF-8 Support Enabled
INFO - 2022-06-27 10:49:12 --> Utf8 Class Initialized
INFO - 2022-06-27 10:49:12 --> URI Class Initialized
INFO - 2022-06-27 10:49:12 --> Router Class Initialized
INFO - 2022-06-27 10:49:12 --> Output Class Initialized
INFO - 2022-06-27 10:49:12 --> Security Class Initialized
DEBUG - 2022-06-27 10:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 10:49:12 --> Input Class Initialized
INFO - 2022-06-27 10:49:12 --> Language Class Initialized
INFO - 2022-06-27 10:49:12 --> Loader Class Initialized
INFO - 2022-06-27 10:49:12 --> Helper loaded: url_helper
INFO - 2022-06-27 10:49:12 --> Helper loaded: file_helper
INFO - 2022-06-27 10:49:12 --> Database Driver Class Initialized
INFO - 2022-06-27 10:49:12 --> Email Class Initialized
DEBUG - 2022-06-27 10:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 10:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 10:49:12 --> Controller Class Initialized
INFO - 2022-06-27 10:49:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 10:49:12 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 10:49:12 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 10:49:12 --> Final output sent to browser
DEBUG - 2022-06-27 10:49:12 --> Total execution time: 0.0702
INFO - 2022-06-27 10:52:18 --> Config Class Initialized
INFO - 2022-06-27 10:52:18 --> Hooks Class Initialized
DEBUG - 2022-06-27 10:52:18 --> UTF-8 Support Enabled
INFO - 2022-06-27 10:52:18 --> Utf8 Class Initialized
INFO - 2022-06-27 10:52:18 --> URI Class Initialized
INFO - 2022-06-27 10:52:18 --> Router Class Initialized
INFO - 2022-06-27 10:52:18 --> Output Class Initialized
INFO - 2022-06-27 10:52:18 --> Security Class Initialized
DEBUG - 2022-06-27 10:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 10:52:18 --> Input Class Initialized
INFO - 2022-06-27 10:52:18 --> Language Class Initialized
INFO - 2022-06-27 10:52:18 --> Loader Class Initialized
INFO - 2022-06-27 10:52:18 --> Helper loaded: url_helper
INFO - 2022-06-27 10:52:18 --> Helper loaded: file_helper
INFO - 2022-06-27 10:52:18 --> Database Driver Class Initialized
INFO - 2022-06-27 10:52:18 --> Email Class Initialized
DEBUG - 2022-06-27 10:52:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 10:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 10:52:18 --> Controller Class Initialized
INFO - 2022-06-27 10:52:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 10:52:18 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 10:52:18 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 10:52:18 --> Final output sent to browser
DEBUG - 2022-06-27 10:52:18 --> Total execution time: 0.0389
INFO - 2022-06-27 10:52:20 --> Config Class Initialized
INFO - 2022-06-27 10:52:20 --> Hooks Class Initialized
DEBUG - 2022-06-27 10:52:20 --> UTF-8 Support Enabled
INFO - 2022-06-27 10:52:20 --> Utf8 Class Initialized
INFO - 2022-06-27 10:52:20 --> URI Class Initialized
INFO - 2022-06-27 10:52:20 --> Router Class Initialized
INFO - 2022-06-27 10:52:20 --> Output Class Initialized
INFO - 2022-06-27 10:52:20 --> Security Class Initialized
DEBUG - 2022-06-27 10:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 10:52:20 --> Input Class Initialized
INFO - 2022-06-27 10:52:20 --> Language Class Initialized
ERROR - 2022-06-27 10:52:20 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 10:52:20 --> Config Class Initialized
INFO - 2022-06-27 10:52:20 --> Hooks Class Initialized
DEBUG - 2022-06-27 10:52:20 --> UTF-8 Support Enabled
INFO - 2022-06-27 10:52:20 --> Utf8 Class Initialized
INFO - 2022-06-27 10:52:20 --> URI Class Initialized
INFO - 2022-06-27 10:52:20 --> Router Class Initialized
INFO - 2022-06-27 10:52:20 --> Output Class Initialized
INFO - 2022-06-27 10:52:20 --> Security Class Initialized
DEBUG - 2022-06-27 10:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 10:52:20 --> Input Class Initialized
INFO - 2022-06-27 10:52:20 --> Language Class Initialized
ERROR - 2022-06-27 10:52:20 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 10:52:52 --> Config Class Initialized
INFO - 2022-06-27 10:52:52 --> Hooks Class Initialized
DEBUG - 2022-06-27 10:52:52 --> UTF-8 Support Enabled
INFO - 2022-06-27 10:52:52 --> Utf8 Class Initialized
INFO - 2022-06-27 10:52:52 --> URI Class Initialized
INFO - 2022-06-27 10:52:52 --> Router Class Initialized
INFO - 2022-06-27 10:52:52 --> Output Class Initialized
INFO - 2022-06-27 10:52:52 --> Security Class Initialized
DEBUG - 2022-06-27 10:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 10:52:52 --> Input Class Initialized
INFO - 2022-06-27 10:52:52 --> Language Class Initialized
INFO - 2022-06-27 10:52:52 --> Loader Class Initialized
INFO - 2022-06-27 10:52:52 --> Helper loaded: url_helper
INFO - 2022-06-27 10:52:52 --> Helper loaded: file_helper
INFO - 2022-06-27 10:52:52 --> Database Driver Class Initialized
INFO - 2022-06-27 10:52:52 --> Email Class Initialized
DEBUG - 2022-06-27 10:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 10:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 10:52:52 --> Controller Class Initialized
INFO - 2022-06-27 10:52:52 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 10:52:52 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 10:52:52 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 10:52:52 --> Final output sent to browser
DEBUG - 2022-06-27 10:52:52 --> Total execution time: 0.0440
INFO - 2022-06-27 10:52:52 --> Config Class Initialized
INFO - 2022-06-27 10:52:52 --> Hooks Class Initialized
DEBUG - 2022-06-27 10:52:52 --> UTF-8 Support Enabled
INFO - 2022-06-27 10:52:52 --> Utf8 Class Initialized
INFO - 2022-06-27 10:52:52 --> URI Class Initialized
INFO - 2022-06-27 10:52:52 --> Router Class Initialized
INFO - 2022-06-27 10:52:52 --> Output Class Initialized
INFO - 2022-06-27 10:52:52 --> Security Class Initialized
DEBUG - 2022-06-27 10:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 10:52:52 --> Input Class Initialized
INFO - 2022-06-27 10:52:52 --> Language Class Initialized
INFO - 2022-06-27 10:52:52 --> Config Class Initialized
INFO - 2022-06-27 10:52:52 --> Hooks Class Initialized
ERROR - 2022-06-27 10:52:52 --> 404 Page Not Found: Tokenctrl/localhost
DEBUG - 2022-06-27 10:52:52 --> UTF-8 Support Enabled
INFO - 2022-06-27 10:52:52 --> Utf8 Class Initialized
INFO - 2022-06-27 10:52:52 --> URI Class Initialized
INFO - 2022-06-27 10:52:52 --> Router Class Initialized
INFO - 2022-06-27 10:52:52 --> Output Class Initialized
INFO - 2022-06-27 10:52:52 --> Security Class Initialized
DEBUG - 2022-06-27 10:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 10:52:52 --> Input Class Initialized
INFO - 2022-06-27 10:52:52 --> Language Class Initialized
ERROR - 2022-06-27 10:52:52 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 10:53:57 --> Config Class Initialized
INFO - 2022-06-27 10:53:57 --> Config Class Initialized
INFO - 2022-06-27 10:53:57 --> Hooks Class Initialized
INFO - 2022-06-27 10:53:57 --> Hooks Class Initialized
DEBUG - 2022-06-27 10:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 10:53:57 --> UTF-8 Support Enabled
INFO - 2022-06-27 10:53:57 --> Utf8 Class Initialized
INFO - 2022-06-27 10:53:57 --> Utf8 Class Initialized
INFO - 2022-06-27 10:53:57 --> URI Class Initialized
INFO - 2022-06-27 10:53:57 --> URI Class Initialized
INFO - 2022-06-27 10:53:57 --> Router Class Initialized
INFO - 2022-06-27 10:53:57 --> Router Class Initialized
INFO - 2022-06-27 10:53:57 --> Output Class Initialized
INFO - 2022-06-27 10:53:57 --> Output Class Initialized
INFO - 2022-06-27 10:53:57 --> Security Class Initialized
INFO - 2022-06-27 10:53:57 --> Security Class Initialized
DEBUG - 2022-06-27 10:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 10:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 10:53:57 --> Input Class Initialized
INFO - 2022-06-27 10:53:57 --> Input Class Initialized
INFO - 2022-06-27 10:53:57 --> Language Class Initialized
INFO - 2022-06-27 10:53:57 --> Language Class Initialized
ERROR - 2022-06-27 10:53:57 --> 404 Page Not Found: Tokenctrl/localhost
ERROR - 2022-06-27 10:53:57 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 11:08:17 --> Config Class Initialized
INFO - 2022-06-27 11:08:17 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:08:17 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:08:17 --> Utf8 Class Initialized
INFO - 2022-06-27 11:08:17 --> URI Class Initialized
INFO - 2022-06-27 11:08:17 --> Router Class Initialized
INFO - 2022-06-27 11:08:17 --> Output Class Initialized
INFO - 2022-06-27 11:08:17 --> Security Class Initialized
DEBUG - 2022-06-27 11:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:08:17 --> Input Class Initialized
INFO - 2022-06-27 11:08:17 --> Language Class Initialized
INFO - 2022-06-27 11:08:17 --> Loader Class Initialized
INFO - 2022-06-27 11:08:17 --> Helper loaded: url_helper
INFO - 2022-06-27 11:08:17 --> Helper loaded: file_helper
INFO - 2022-06-27 11:08:17 --> Database Driver Class Initialized
INFO - 2022-06-27 11:08:17 --> Email Class Initialized
DEBUG - 2022-06-27 11:08:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 11:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 11:08:17 --> Controller Class Initialized
INFO - 2022-06-27 11:08:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 11:08:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 11:08:17 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 11:08:17 --> Final output sent to browser
DEBUG - 2022-06-27 11:08:17 --> Total execution time: 0.1448
INFO - 2022-06-27 11:08:17 --> Config Class Initialized
INFO - 2022-06-27 11:08:17 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:08:17 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:08:17 --> Utf8 Class Initialized
INFO - 2022-06-27 11:08:17 --> URI Class Initialized
INFO - 2022-06-27 11:08:17 --> Router Class Initialized
INFO - 2022-06-27 11:08:17 --> Output Class Initialized
INFO - 2022-06-27 11:08:17 --> Security Class Initialized
DEBUG - 2022-06-27 11:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:08:17 --> Input Class Initialized
INFO - 2022-06-27 11:08:17 --> Language Class Initialized
ERROR - 2022-06-27 11:08:17 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 11:08:18 --> Config Class Initialized
INFO - 2022-06-27 11:08:18 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:08:18 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:08:18 --> Utf8 Class Initialized
INFO - 2022-06-27 11:08:18 --> URI Class Initialized
INFO - 2022-06-27 11:08:18 --> Router Class Initialized
INFO - 2022-06-27 11:08:18 --> Output Class Initialized
INFO - 2022-06-27 11:08:18 --> Security Class Initialized
DEBUG - 2022-06-27 11:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:08:18 --> Input Class Initialized
INFO - 2022-06-27 11:08:18 --> Language Class Initialized
ERROR - 2022-06-27 11:08:18 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 11:08:18 --> Config Class Initialized
INFO - 2022-06-27 11:08:18 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:08:18 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:08:18 --> Utf8 Class Initialized
INFO - 2022-06-27 11:08:18 --> URI Class Initialized
INFO - 2022-06-27 11:08:18 --> Router Class Initialized
INFO - 2022-06-27 11:08:18 --> Output Class Initialized
INFO - 2022-06-27 11:08:18 --> Security Class Initialized
DEBUG - 2022-06-27 11:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:08:18 --> Input Class Initialized
INFO - 2022-06-27 11:08:18 --> Language Class Initialized
ERROR - 2022-06-27 11:08:18 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 11:08:18 --> Config Class Initialized
INFO - 2022-06-27 11:08:18 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:08:18 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:08:18 --> Utf8 Class Initialized
INFO - 2022-06-27 11:08:18 --> URI Class Initialized
INFO - 2022-06-27 11:08:18 --> Router Class Initialized
INFO - 2022-06-27 11:08:18 --> Output Class Initialized
INFO - 2022-06-27 11:08:18 --> Security Class Initialized
DEBUG - 2022-06-27 11:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:08:18 --> Input Class Initialized
INFO - 2022-06-27 11:08:18 --> Language Class Initialized
ERROR - 2022-06-27 11:08:18 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 11:08:36 --> Config Class Initialized
INFO - 2022-06-27 11:08:36 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:08:36 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:08:36 --> Utf8 Class Initialized
INFO - 2022-06-27 11:08:36 --> URI Class Initialized
INFO - 2022-06-27 11:08:36 --> Router Class Initialized
INFO - 2022-06-27 11:08:36 --> Output Class Initialized
INFO - 2022-06-27 11:08:36 --> Security Class Initialized
DEBUG - 2022-06-27 11:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:08:36 --> Input Class Initialized
INFO - 2022-06-27 11:08:36 --> Language Class Initialized
INFO - 2022-06-27 11:08:36 --> Loader Class Initialized
INFO - 2022-06-27 11:08:36 --> Helper loaded: url_helper
INFO - 2022-06-27 11:08:36 --> Helper loaded: file_helper
INFO - 2022-06-27 11:08:36 --> Database Driver Class Initialized
INFO - 2022-06-27 11:08:36 --> Email Class Initialized
DEBUG - 2022-06-27 11:08:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 11:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 11:08:36 --> Controller Class Initialized
INFO - 2022-06-27 11:08:36 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 11:08:36 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 11:08:36 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 11:08:36 --> Final output sent to browser
DEBUG - 2022-06-27 11:08:36 --> Total execution time: 0.1239
INFO - 2022-06-27 11:08:45 --> Config Class Initialized
INFO - 2022-06-27 11:08:45 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:08:45 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:08:45 --> Utf8 Class Initialized
INFO - 2022-06-27 11:08:45 --> URI Class Initialized
INFO - 2022-06-27 11:08:45 --> Router Class Initialized
INFO - 2022-06-27 11:08:45 --> Output Class Initialized
INFO - 2022-06-27 11:08:45 --> Security Class Initialized
DEBUG - 2022-06-27 11:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:08:45 --> Input Class Initialized
INFO - 2022-06-27 11:08:45 --> Language Class Initialized
ERROR - 2022-06-27 11:08:45 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 11:09:31 --> Config Class Initialized
INFO - 2022-06-27 11:09:31 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:09:31 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:09:31 --> Utf8 Class Initialized
INFO - 2022-06-27 11:09:31 --> URI Class Initialized
INFO - 2022-06-27 11:09:31 --> Router Class Initialized
INFO - 2022-06-27 11:09:31 --> Output Class Initialized
INFO - 2022-06-27 11:09:31 --> Security Class Initialized
DEBUG - 2022-06-27 11:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:09:31 --> Input Class Initialized
INFO - 2022-06-27 11:09:31 --> Language Class Initialized
INFO - 2022-06-27 11:09:31 --> Loader Class Initialized
INFO - 2022-06-27 11:09:31 --> Helper loaded: url_helper
INFO - 2022-06-27 11:09:31 --> Helper loaded: file_helper
INFO - 2022-06-27 11:09:31 --> Database Driver Class Initialized
INFO - 2022-06-27 11:09:31 --> Email Class Initialized
DEBUG - 2022-06-27 11:09:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 11:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 11:09:31 --> Controller Class Initialized
INFO - 2022-06-27 11:09:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 11:09:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 11:09:31 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 11:09:31 --> Final output sent to browser
DEBUG - 2022-06-27 11:09:31 --> Total execution time: 0.1392
INFO - 2022-06-27 11:09:31 --> Config Class Initialized
INFO - 2022-06-27 11:09:31 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:09:31 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:09:31 --> Utf8 Class Initialized
INFO - 2022-06-27 11:09:31 --> URI Class Initialized
INFO - 2022-06-27 11:09:31 --> Router Class Initialized
INFO - 2022-06-27 11:09:31 --> Output Class Initialized
INFO - 2022-06-27 11:09:31 --> Config Class Initialized
INFO - 2022-06-27 11:09:31 --> Security Class Initialized
INFO - 2022-06-27 11:09:31 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:09:31 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:09:31 --> Input Class Initialized
INFO - 2022-06-27 11:09:31 --> Utf8 Class Initialized
INFO - 2022-06-27 11:09:31 --> Language Class Initialized
INFO - 2022-06-27 11:09:31 --> URI Class Initialized
ERROR - 2022-06-27 11:09:31 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 11:09:31 --> Router Class Initialized
INFO - 2022-06-27 11:09:31 --> Output Class Initialized
INFO - 2022-06-27 11:09:31 --> Security Class Initialized
DEBUG - 2022-06-27 11:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:09:31 --> Input Class Initialized
INFO - 2022-06-27 11:09:31 --> Language Class Initialized
ERROR - 2022-06-27 11:09:31 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 11:09:51 --> Config Class Initialized
INFO - 2022-06-27 11:09:51 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:09:51 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:09:51 --> Utf8 Class Initialized
INFO - 2022-06-27 11:09:51 --> URI Class Initialized
INFO - 2022-06-27 11:09:51 --> Router Class Initialized
INFO - 2022-06-27 11:09:51 --> Output Class Initialized
INFO - 2022-06-27 11:09:51 --> Security Class Initialized
DEBUG - 2022-06-27 11:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:09:51 --> Input Class Initialized
INFO - 2022-06-27 11:09:51 --> Language Class Initialized
INFO - 2022-06-27 11:09:51 --> Loader Class Initialized
INFO - 2022-06-27 11:09:51 --> Helper loaded: url_helper
INFO - 2022-06-27 11:09:51 --> Helper loaded: file_helper
INFO - 2022-06-27 11:09:51 --> Database Driver Class Initialized
INFO - 2022-06-27 11:09:51 --> Email Class Initialized
DEBUG - 2022-06-27 11:09:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 11:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 11:09:51 --> Controller Class Initialized
INFO - 2022-06-27 11:09:51 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 11:09:51 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 11:09:51 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 11:09:51 --> Final output sent to browser
DEBUG - 2022-06-27 11:09:51 --> Total execution time: 0.0436
INFO - 2022-06-27 11:12:24 --> Config Class Initialized
INFO - 2022-06-27 11:12:24 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:12:24 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:12:24 --> Utf8 Class Initialized
INFO - 2022-06-27 11:12:24 --> URI Class Initialized
INFO - 2022-06-27 11:12:24 --> Router Class Initialized
INFO - 2022-06-27 11:12:24 --> Output Class Initialized
INFO - 2022-06-27 11:12:24 --> Security Class Initialized
DEBUG - 2022-06-27 11:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:12:24 --> Input Class Initialized
INFO - 2022-06-27 11:12:24 --> Language Class Initialized
INFO - 2022-06-27 11:12:24 --> Loader Class Initialized
INFO - 2022-06-27 11:12:24 --> Helper loaded: url_helper
INFO - 2022-06-27 11:12:24 --> Helper loaded: file_helper
INFO - 2022-06-27 11:12:24 --> Database Driver Class Initialized
INFO - 2022-06-27 11:12:24 --> Email Class Initialized
DEBUG - 2022-06-27 11:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 11:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 11:12:24 --> Controller Class Initialized
INFO - 2022-06-27 11:12:24 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 11:12:24 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 11:12:24 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 11:12:24 --> Final output sent to browser
DEBUG - 2022-06-27 11:12:24 --> Total execution time: 0.0280
INFO - 2022-06-27 11:12:24 --> Config Class Initialized
INFO - 2022-06-27 11:12:24 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:12:24 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:12:24 --> Utf8 Class Initialized
INFO - 2022-06-27 11:12:24 --> URI Class Initialized
INFO - 2022-06-27 11:12:24 --> Router Class Initialized
INFO - 2022-06-27 11:12:24 --> Output Class Initialized
INFO - 2022-06-27 11:12:24 --> Security Class Initialized
DEBUG - 2022-06-27 11:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:12:24 --> Input Class Initialized
INFO - 2022-06-27 11:12:24 --> Language Class Initialized
ERROR - 2022-06-27 11:12:24 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 11:12:24 --> Config Class Initialized
INFO - 2022-06-27 11:12:24 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:12:24 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:12:24 --> Utf8 Class Initialized
INFO - 2022-06-27 11:12:24 --> URI Class Initialized
INFO - 2022-06-27 11:12:24 --> Router Class Initialized
INFO - 2022-06-27 11:12:24 --> Output Class Initialized
INFO - 2022-06-27 11:12:24 --> Security Class Initialized
DEBUG - 2022-06-27 11:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:12:24 --> Input Class Initialized
INFO - 2022-06-27 11:12:24 --> Language Class Initialized
ERROR - 2022-06-27 11:12:24 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 11:14:10 --> Config Class Initialized
INFO - 2022-06-27 11:14:10 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:14:10 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:14:10 --> Utf8 Class Initialized
INFO - 2022-06-27 11:14:10 --> URI Class Initialized
INFO - 2022-06-27 11:14:10 --> Router Class Initialized
INFO - 2022-06-27 11:14:10 --> Output Class Initialized
INFO - 2022-06-27 11:14:10 --> Security Class Initialized
DEBUG - 2022-06-27 11:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:14:10 --> Input Class Initialized
INFO - 2022-06-27 11:14:10 --> Language Class Initialized
INFO - 2022-06-27 11:14:10 --> Loader Class Initialized
INFO - 2022-06-27 11:14:10 --> Helper loaded: url_helper
INFO - 2022-06-27 11:14:10 --> Helper loaded: file_helper
INFO - 2022-06-27 11:14:10 --> Database Driver Class Initialized
INFO - 2022-06-27 11:14:10 --> Email Class Initialized
DEBUG - 2022-06-27 11:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 11:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 11:14:10 --> Controller Class Initialized
INFO - 2022-06-27 11:14:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 11:14:10 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 11:15:53 --> Config Class Initialized
INFO - 2022-06-27 11:15:53 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:15:53 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:15:53 --> Utf8 Class Initialized
INFO - 2022-06-27 11:15:53 --> URI Class Initialized
INFO - 2022-06-27 11:15:53 --> Router Class Initialized
INFO - 2022-06-27 11:15:53 --> Output Class Initialized
INFO - 2022-06-27 11:15:53 --> Security Class Initialized
DEBUG - 2022-06-27 11:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:15:53 --> Input Class Initialized
INFO - 2022-06-27 11:15:53 --> Language Class Initialized
INFO - 2022-06-27 11:15:53 --> Loader Class Initialized
INFO - 2022-06-27 11:15:53 --> Helper loaded: url_helper
INFO - 2022-06-27 11:15:53 --> Helper loaded: file_helper
INFO - 2022-06-27 11:15:53 --> Database Driver Class Initialized
INFO - 2022-06-27 11:15:53 --> Email Class Initialized
DEBUG - 2022-06-27 11:15:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 11:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 11:15:53 --> Controller Class Initialized
INFO - 2022-06-27 11:15:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 11:15:53 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 11:18:00 --> Config Class Initialized
INFO - 2022-06-27 11:18:00 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:18:00 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:18:00 --> Utf8 Class Initialized
INFO - 2022-06-27 11:18:00 --> URI Class Initialized
INFO - 2022-06-27 11:18:00 --> Router Class Initialized
INFO - 2022-06-27 11:18:00 --> Output Class Initialized
INFO - 2022-06-27 11:18:00 --> Security Class Initialized
DEBUG - 2022-06-27 11:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:18:00 --> Input Class Initialized
INFO - 2022-06-27 11:18:00 --> Language Class Initialized
INFO - 2022-06-27 11:18:00 --> Loader Class Initialized
INFO - 2022-06-27 11:18:00 --> Helper loaded: url_helper
INFO - 2022-06-27 11:18:00 --> Helper loaded: file_helper
INFO - 2022-06-27 11:18:00 --> Database Driver Class Initialized
INFO - 2022-06-27 11:18:00 --> Email Class Initialized
DEBUG - 2022-06-27 11:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 11:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 11:18:00 --> Controller Class Initialized
INFO - 2022-06-27 11:18:00 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 11:18:00 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 11:18:00 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 11:18:00 --> Final output sent to browser
DEBUG - 2022-06-27 11:18:00 --> Total execution time: 0.1488
INFO - 2022-06-27 11:18:00 --> Config Class Initialized
INFO - 2022-06-27 11:18:00 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:18:00 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:18:00 --> Utf8 Class Initialized
INFO - 2022-06-27 11:18:00 --> URI Class Initialized
INFO - 2022-06-27 11:18:00 --> Router Class Initialized
INFO - 2022-06-27 11:18:00 --> Output Class Initialized
INFO - 2022-06-27 11:18:00 --> Security Class Initialized
DEBUG - 2022-06-27 11:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:18:00 --> Input Class Initialized
INFO - 2022-06-27 11:18:00 --> Language Class Initialized
ERROR - 2022-06-27 11:18:00 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 11:18:00 --> Config Class Initialized
INFO - 2022-06-27 11:18:00 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:18:00 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:18:00 --> Utf8 Class Initialized
INFO - 2022-06-27 11:18:00 --> URI Class Initialized
INFO - 2022-06-27 11:18:00 --> Router Class Initialized
INFO - 2022-06-27 11:18:00 --> Output Class Initialized
INFO - 2022-06-27 11:18:00 --> Security Class Initialized
DEBUG - 2022-06-27 11:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:18:00 --> Input Class Initialized
INFO - 2022-06-27 11:18:00 --> Language Class Initialized
ERROR - 2022-06-27 11:18:00 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 11:18:24 --> Config Class Initialized
INFO - 2022-06-27 11:18:24 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:18:24 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:18:24 --> Utf8 Class Initialized
INFO - 2022-06-27 11:18:24 --> URI Class Initialized
INFO - 2022-06-27 11:18:24 --> Router Class Initialized
INFO - 2022-06-27 11:18:24 --> Output Class Initialized
INFO - 2022-06-27 11:18:24 --> Security Class Initialized
DEBUG - 2022-06-27 11:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:18:24 --> Input Class Initialized
INFO - 2022-06-27 11:18:24 --> Language Class Initialized
INFO - 2022-06-27 11:18:24 --> Loader Class Initialized
INFO - 2022-06-27 11:18:24 --> Helper loaded: url_helper
INFO - 2022-06-27 11:18:24 --> Helper loaded: file_helper
INFO - 2022-06-27 11:18:24 --> Database Driver Class Initialized
INFO - 2022-06-27 11:18:24 --> Email Class Initialized
DEBUG - 2022-06-27 11:18:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 11:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 11:18:24 --> Controller Class Initialized
INFO - 2022-06-27 11:18:24 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 11:18:24 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 11:18:24 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 11:18:24 --> Final output sent to browser
DEBUG - 2022-06-27 11:18:24 --> Total execution time: 0.1282
INFO - 2022-06-27 11:24:50 --> Config Class Initialized
INFO - 2022-06-27 11:24:50 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:24:50 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:24:50 --> Utf8 Class Initialized
INFO - 2022-06-27 11:24:50 --> URI Class Initialized
INFO - 2022-06-27 11:24:50 --> Router Class Initialized
INFO - 2022-06-27 11:24:50 --> Output Class Initialized
INFO - 2022-06-27 11:24:50 --> Security Class Initialized
DEBUG - 2022-06-27 11:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:24:50 --> Input Class Initialized
INFO - 2022-06-27 11:24:50 --> Language Class Initialized
INFO - 2022-06-27 11:24:50 --> Loader Class Initialized
INFO - 2022-06-27 11:24:50 --> Helper loaded: url_helper
INFO - 2022-06-27 11:24:50 --> Helper loaded: file_helper
INFO - 2022-06-27 11:24:50 --> Database Driver Class Initialized
INFO - 2022-06-27 11:24:50 --> Email Class Initialized
DEBUG - 2022-06-27 11:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 11:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 11:24:50 --> Controller Class Initialized
INFO - 2022-06-27 11:24:50 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 11:24:50 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 11:24:50 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 11:24:50 --> Final output sent to browser
DEBUG - 2022-06-27 11:24:50 --> Total execution time: 0.0492
INFO - 2022-06-27 11:24:50 --> Config Class Initialized
INFO - 2022-06-27 11:24:50 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:24:50 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:24:50 --> Utf8 Class Initialized
INFO - 2022-06-27 11:24:50 --> URI Class Initialized
INFO - 2022-06-27 11:24:50 --> Router Class Initialized
INFO - 2022-06-27 11:24:50 --> Output Class Initialized
INFO - 2022-06-27 11:24:50 --> Security Class Initialized
DEBUG - 2022-06-27 11:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:24:50 --> Input Class Initialized
INFO - 2022-06-27 11:24:50 --> Language Class Initialized
ERROR - 2022-06-27 11:24:50 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 11:24:50 --> Config Class Initialized
INFO - 2022-06-27 11:24:50 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:24:50 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:24:50 --> Utf8 Class Initialized
INFO - 2022-06-27 11:24:50 --> URI Class Initialized
INFO - 2022-06-27 11:24:50 --> Router Class Initialized
INFO - 2022-06-27 11:24:50 --> Output Class Initialized
INFO - 2022-06-27 11:24:50 --> Security Class Initialized
DEBUG - 2022-06-27 11:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:24:50 --> Input Class Initialized
INFO - 2022-06-27 11:24:50 --> Language Class Initialized
ERROR - 2022-06-27 11:24:50 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 11:25:00 --> Config Class Initialized
INFO - 2022-06-27 11:25:00 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:25:00 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:25:00 --> Utf8 Class Initialized
INFO - 2022-06-27 11:25:00 --> URI Class Initialized
INFO - 2022-06-27 11:25:00 --> Router Class Initialized
INFO - 2022-06-27 11:25:00 --> Output Class Initialized
INFO - 2022-06-27 11:25:00 --> Security Class Initialized
DEBUG - 2022-06-27 11:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:25:00 --> Input Class Initialized
INFO - 2022-06-27 11:25:00 --> Language Class Initialized
INFO - 2022-06-27 11:25:00 --> Loader Class Initialized
INFO - 2022-06-27 11:25:00 --> Helper loaded: url_helper
INFO - 2022-06-27 11:25:00 --> Helper loaded: file_helper
INFO - 2022-06-27 11:25:00 --> Database Driver Class Initialized
INFO - 2022-06-27 11:25:00 --> Email Class Initialized
DEBUG - 2022-06-27 11:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 11:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 11:25:00 --> Controller Class Initialized
INFO - 2022-06-27 11:25:00 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 11:25:00 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 11:25:00 --> Config Class Initialized
INFO - 2022-06-27 11:25:00 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:25:00 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:25:00 --> Utf8 Class Initialized
INFO - 2022-06-27 11:25:00 --> URI Class Initialized
INFO - 2022-06-27 11:25:00 --> Router Class Initialized
INFO - 2022-06-27 11:25:00 --> Output Class Initialized
INFO - 2022-06-27 11:25:00 --> Security Class Initialized
DEBUG - 2022-06-27 11:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:25:00 --> Input Class Initialized
INFO - 2022-06-27 11:25:00 --> Language Class Initialized
ERROR - 2022-06-27 11:25:00 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 11:25:28 --> Config Class Initialized
INFO - 2022-06-27 11:25:28 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:25:28 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:25:28 --> Utf8 Class Initialized
INFO - 2022-06-27 11:25:28 --> URI Class Initialized
INFO - 2022-06-27 11:25:28 --> Router Class Initialized
INFO - 2022-06-27 11:25:28 --> Output Class Initialized
INFO - 2022-06-27 11:25:28 --> Security Class Initialized
DEBUG - 2022-06-27 11:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:25:28 --> Input Class Initialized
INFO - 2022-06-27 11:25:28 --> Language Class Initialized
INFO - 2022-06-27 11:25:28 --> Loader Class Initialized
INFO - 2022-06-27 11:25:28 --> Helper loaded: url_helper
INFO - 2022-06-27 11:25:28 --> Helper loaded: file_helper
INFO - 2022-06-27 11:25:28 --> Database Driver Class Initialized
INFO - 2022-06-27 11:25:28 --> Email Class Initialized
DEBUG - 2022-06-27 11:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 11:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 11:25:28 --> Controller Class Initialized
INFO - 2022-06-27 11:25:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 11:25:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 11:25:28 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 11:25:28 --> Final output sent to browser
DEBUG - 2022-06-27 11:25:28 --> Total execution time: 0.0277
INFO - 2022-06-27 11:25:28 --> Config Class Initialized
INFO - 2022-06-27 11:25:28 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:25:28 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:25:28 --> Utf8 Class Initialized
INFO - 2022-06-27 11:25:28 --> URI Class Initialized
INFO - 2022-06-27 11:25:28 --> Router Class Initialized
INFO - 2022-06-27 11:25:28 --> Output Class Initialized
INFO - 2022-06-27 11:25:28 --> Security Class Initialized
DEBUG - 2022-06-27 11:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:25:28 --> Input Class Initialized
INFO - 2022-06-27 11:25:28 --> Language Class Initialized
ERROR - 2022-06-27 11:25:28 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 11:25:28 --> Config Class Initialized
INFO - 2022-06-27 11:25:28 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:25:28 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:25:28 --> Utf8 Class Initialized
INFO - 2022-06-27 11:25:28 --> URI Class Initialized
INFO - 2022-06-27 11:25:28 --> Router Class Initialized
INFO - 2022-06-27 11:25:28 --> Output Class Initialized
INFO - 2022-06-27 11:25:28 --> Security Class Initialized
DEBUG - 2022-06-27 11:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:25:28 --> Input Class Initialized
INFO - 2022-06-27 11:25:28 --> Language Class Initialized
ERROR - 2022-06-27 11:25:28 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 11:25:40 --> Config Class Initialized
INFO - 2022-06-27 11:25:40 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:25:40 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:25:40 --> Utf8 Class Initialized
INFO - 2022-06-27 11:25:40 --> URI Class Initialized
INFO - 2022-06-27 11:25:40 --> Router Class Initialized
INFO - 2022-06-27 11:25:40 --> Output Class Initialized
INFO - 2022-06-27 11:25:40 --> Security Class Initialized
DEBUG - 2022-06-27 11:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:25:40 --> Input Class Initialized
INFO - 2022-06-27 11:25:40 --> Language Class Initialized
INFO - 2022-06-27 11:25:40 --> Loader Class Initialized
INFO - 2022-06-27 11:25:40 --> Helper loaded: url_helper
INFO - 2022-06-27 11:25:40 --> Helper loaded: file_helper
INFO - 2022-06-27 11:25:40 --> Database Driver Class Initialized
INFO - 2022-06-27 11:25:40 --> Email Class Initialized
DEBUG - 2022-06-27 11:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 11:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 11:25:40 --> Controller Class Initialized
INFO - 2022-06-27 11:25:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 11:25:40 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 11:25:40 --> Config Class Initialized
INFO - 2022-06-27 11:25:40 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:25:40 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:25:40 --> Utf8 Class Initialized
INFO - 2022-06-27 11:25:40 --> URI Class Initialized
INFO - 2022-06-27 11:25:40 --> Router Class Initialized
INFO - 2022-06-27 11:25:40 --> Output Class Initialized
INFO - 2022-06-27 11:25:40 --> Security Class Initialized
DEBUG - 2022-06-27 11:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:25:40 --> Input Class Initialized
INFO - 2022-06-27 11:25:40 --> Language Class Initialized
ERROR - 2022-06-27 11:25:40 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 11:36:16 --> Config Class Initialized
INFO - 2022-06-27 11:36:16 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:36:16 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:36:16 --> Utf8 Class Initialized
INFO - 2022-06-27 11:36:16 --> URI Class Initialized
INFO - 2022-06-27 11:36:16 --> Router Class Initialized
INFO - 2022-06-27 11:36:16 --> Output Class Initialized
INFO - 2022-06-27 11:36:16 --> Security Class Initialized
DEBUG - 2022-06-27 11:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:36:16 --> Input Class Initialized
INFO - 2022-06-27 11:36:16 --> Language Class Initialized
INFO - 2022-06-27 11:36:16 --> Loader Class Initialized
INFO - 2022-06-27 11:36:16 --> Helper loaded: url_helper
INFO - 2022-06-27 11:36:16 --> Helper loaded: file_helper
INFO - 2022-06-27 11:36:16 --> Database Driver Class Initialized
INFO - 2022-06-27 11:36:16 --> Email Class Initialized
DEBUG - 2022-06-27 11:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 11:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 11:36:16 --> Controller Class Initialized
INFO - 2022-06-27 11:36:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 11:36:16 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 11:36:16 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 11:36:16 --> Final output sent to browser
DEBUG - 2022-06-27 11:36:16 --> Total execution time: 0.1947
INFO - 2022-06-27 11:36:16 --> Config Class Initialized
INFO - 2022-06-27 11:36:16 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:36:16 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:36:16 --> Utf8 Class Initialized
INFO - 2022-06-27 11:36:16 --> URI Class Initialized
INFO - 2022-06-27 11:36:16 --> Router Class Initialized
INFO - 2022-06-27 11:36:16 --> Output Class Initialized
INFO - 2022-06-27 11:36:16 --> Security Class Initialized
DEBUG - 2022-06-27 11:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:36:16 --> Input Class Initialized
INFO - 2022-06-27 11:36:16 --> Language Class Initialized
ERROR - 2022-06-27 11:36:16 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 11:36:16 --> Config Class Initialized
INFO - 2022-06-27 11:36:16 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:36:16 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:36:16 --> Utf8 Class Initialized
INFO - 2022-06-27 11:36:16 --> URI Class Initialized
INFO - 2022-06-27 11:36:16 --> Router Class Initialized
INFO - 2022-06-27 11:36:16 --> Output Class Initialized
INFO - 2022-06-27 11:36:16 --> Security Class Initialized
DEBUG - 2022-06-27 11:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:36:16 --> Input Class Initialized
INFO - 2022-06-27 11:36:16 --> Language Class Initialized
ERROR - 2022-06-27 11:36:16 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 11:36:33 --> Config Class Initialized
INFO - 2022-06-27 11:36:33 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:36:33 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:36:33 --> Utf8 Class Initialized
INFO - 2022-06-27 11:36:33 --> URI Class Initialized
INFO - 2022-06-27 11:36:33 --> Router Class Initialized
INFO - 2022-06-27 11:36:33 --> Output Class Initialized
INFO - 2022-06-27 11:36:33 --> Security Class Initialized
DEBUG - 2022-06-27 11:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:36:33 --> Input Class Initialized
INFO - 2022-06-27 11:36:33 --> Language Class Initialized
INFO - 2022-06-27 11:36:33 --> Loader Class Initialized
INFO - 2022-06-27 11:36:33 --> Helper loaded: url_helper
INFO - 2022-06-27 11:36:33 --> Helper loaded: file_helper
INFO - 2022-06-27 11:36:33 --> Database Driver Class Initialized
INFO - 2022-06-27 11:36:33 --> Email Class Initialized
DEBUG - 2022-06-27 11:36:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 11:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 11:36:33 --> Controller Class Initialized
INFO - 2022-06-27 11:36:33 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 11:36:33 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 11:36:33 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 11:36:33 --> Final output sent to browser
DEBUG - 2022-06-27 11:36:33 --> Total execution time: 0.0244
INFO - 2022-06-27 11:36:34 --> Config Class Initialized
INFO - 2022-06-27 11:36:34 --> Hooks Class Initialized
INFO - 2022-06-27 11:36:34 --> Config Class Initialized
INFO - 2022-06-27 11:36:34 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:36:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:36:34 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:36:34 --> Utf8 Class Initialized
INFO - 2022-06-27 11:36:34 --> Utf8 Class Initialized
INFO - 2022-06-27 11:36:34 --> URI Class Initialized
INFO - 2022-06-27 11:36:34 --> URI Class Initialized
INFO - 2022-06-27 11:36:34 --> Router Class Initialized
INFO - 2022-06-27 11:36:34 --> Router Class Initialized
INFO - 2022-06-27 11:36:34 --> Output Class Initialized
INFO - 2022-06-27 11:36:34 --> Output Class Initialized
INFO - 2022-06-27 11:36:34 --> Security Class Initialized
INFO - 2022-06-27 11:36:34 --> Security Class Initialized
DEBUG - 2022-06-27 11:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:36:34 --> Input Class Initialized
DEBUG - 2022-06-27 11:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:36:34 --> Input Class Initialized
INFO - 2022-06-27 11:36:34 --> Language Class Initialized
INFO - 2022-06-27 11:36:34 --> Language Class Initialized
ERROR - 2022-06-27 11:36:34 --> 404 Page Not Found: Tokenctrl/localhost
ERROR - 2022-06-27 11:36:34 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 11:40:49 --> Config Class Initialized
INFO - 2022-06-27 11:40:49 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:40:49 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:40:49 --> Utf8 Class Initialized
INFO - 2022-06-27 11:40:49 --> URI Class Initialized
INFO - 2022-06-27 11:40:49 --> Router Class Initialized
INFO - 2022-06-27 11:40:49 --> Output Class Initialized
INFO - 2022-06-27 11:40:49 --> Security Class Initialized
DEBUG - 2022-06-27 11:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:40:49 --> Input Class Initialized
INFO - 2022-06-27 11:40:49 --> Language Class Initialized
INFO - 2022-06-27 11:40:49 --> Loader Class Initialized
INFO - 2022-06-27 11:40:49 --> Helper loaded: url_helper
INFO - 2022-06-27 11:40:49 --> Helper loaded: file_helper
INFO - 2022-06-27 11:40:49 --> Database Driver Class Initialized
INFO - 2022-06-27 11:40:49 --> Email Class Initialized
DEBUG - 2022-06-27 11:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 11:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 11:40:49 --> Controller Class Initialized
INFO - 2022-06-27 11:40:49 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 11:40:49 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 11:40:49 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 11:40:49 --> Final output sent to browser
DEBUG - 2022-06-27 11:40:49 --> Total execution time: 0.0434
INFO - 2022-06-27 11:40:49 --> Config Class Initialized
INFO - 2022-06-27 11:40:49 --> Config Class Initialized
INFO - 2022-06-27 11:40:49 --> Hooks Class Initialized
INFO - 2022-06-27 11:40:49 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:40:49 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:40:49 --> Utf8 Class Initialized
INFO - 2022-06-27 11:40:49 --> Utf8 Class Initialized
INFO - 2022-06-27 11:40:49 --> URI Class Initialized
INFO - 2022-06-27 11:40:49 --> URI Class Initialized
INFO - 2022-06-27 11:40:49 --> Router Class Initialized
INFO - 2022-06-27 11:40:49 --> Router Class Initialized
INFO - 2022-06-27 11:40:49 --> Output Class Initialized
INFO - 2022-06-27 11:40:49 --> Output Class Initialized
INFO - 2022-06-27 11:40:49 --> Security Class Initialized
DEBUG - 2022-06-27 11:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:40:49 --> Security Class Initialized
INFO - 2022-06-27 11:40:49 --> Input Class Initialized
DEBUG - 2022-06-27 11:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:40:49 --> Language Class Initialized
INFO - 2022-06-27 11:40:49 --> Input Class Initialized
ERROR - 2022-06-27 11:40:49 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 11:40:49 --> Language Class Initialized
ERROR - 2022-06-27 11:40:49 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 11:41:43 --> Config Class Initialized
INFO - 2022-06-27 11:41:43 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:41:43 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:41:43 --> Utf8 Class Initialized
INFO - 2022-06-27 11:41:43 --> URI Class Initialized
INFO - 2022-06-27 11:41:43 --> Router Class Initialized
INFO - 2022-06-27 11:41:43 --> Output Class Initialized
INFO - 2022-06-27 11:41:43 --> Security Class Initialized
DEBUG - 2022-06-27 11:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:41:43 --> Input Class Initialized
INFO - 2022-06-27 11:41:43 --> Language Class Initialized
INFO - 2022-06-27 11:41:43 --> Loader Class Initialized
INFO - 2022-06-27 11:41:43 --> Helper loaded: url_helper
INFO - 2022-06-27 11:41:43 --> Helper loaded: file_helper
INFO - 2022-06-27 11:41:43 --> Database Driver Class Initialized
INFO - 2022-06-27 11:41:43 --> Email Class Initialized
DEBUG - 2022-06-27 11:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 11:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 11:41:43 --> Controller Class Initialized
INFO - 2022-06-27 11:41:43 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 11:41:43 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 11:41:43 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 11:41:43 --> Final output sent to browser
DEBUG - 2022-06-27 11:41:43 --> Total execution time: 0.0440
INFO - 2022-06-27 11:41:43 --> Config Class Initialized
INFO - 2022-06-27 11:41:43 --> Hooks Class Initialized
INFO - 2022-06-27 11:41:43 --> Config Class Initialized
INFO - 2022-06-27 11:41:43 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:41:43 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:41:43 --> Utf8 Class Initialized
DEBUG - 2022-06-27 11:41:43 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:41:43 --> Utf8 Class Initialized
INFO - 2022-06-27 11:41:43 --> URI Class Initialized
INFO - 2022-06-27 11:41:43 --> URI Class Initialized
INFO - 2022-06-27 11:41:43 --> Router Class Initialized
INFO - 2022-06-27 11:41:43 --> Router Class Initialized
INFO - 2022-06-27 11:41:43 --> Output Class Initialized
INFO - 2022-06-27 11:41:43 --> Output Class Initialized
INFO - 2022-06-27 11:41:43 --> Security Class Initialized
INFO - 2022-06-27 11:41:43 --> Security Class Initialized
DEBUG - 2022-06-27 11:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:41:43 --> Input Class Initialized
DEBUG - 2022-06-27 11:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:41:43 --> Input Class Initialized
INFO - 2022-06-27 11:41:43 --> Language Class Initialized
INFO - 2022-06-27 11:41:43 --> Language Class Initialized
ERROR - 2022-06-27 11:41:43 --> 404 Page Not Found: Tokenctrl/localhost
ERROR - 2022-06-27 11:41:43 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 11:42:11 --> Config Class Initialized
INFO - 2022-06-27 11:42:11 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:42:11 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:42:11 --> Utf8 Class Initialized
INFO - 2022-06-27 11:42:11 --> URI Class Initialized
INFO - 2022-06-27 11:42:11 --> Router Class Initialized
INFO - 2022-06-27 11:42:11 --> Output Class Initialized
INFO - 2022-06-27 11:42:11 --> Security Class Initialized
DEBUG - 2022-06-27 11:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:42:11 --> Input Class Initialized
INFO - 2022-06-27 11:42:11 --> Language Class Initialized
INFO - 2022-06-27 11:42:11 --> Loader Class Initialized
INFO - 2022-06-27 11:42:11 --> Helper loaded: url_helper
INFO - 2022-06-27 11:42:11 --> Helper loaded: file_helper
INFO - 2022-06-27 11:42:11 --> Database Driver Class Initialized
INFO - 2022-06-27 11:42:11 --> Email Class Initialized
DEBUG - 2022-06-27 11:42:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 11:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 11:42:11 --> Controller Class Initialized
INFO - 2022-06-27 11:42:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 11:42:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 11:42:11 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 11:42:11 --> Final output sent to browser
DEBUG - 2022-06-27 11:42:11 --> Total execution time: 0.0292
INFO - 2022-06-27 11:42:11 --> Config Class Initialized
INFO - 2022-06-27 11:42:11 --> Config Class Initialized
INFO - 2022-06-27 11:42:11 --> Hooks Class Initialized
INFO - 2022-06-27 11:42:11 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:42:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:42:11 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:42:11 --> Utf8 Class Initialized
INFO - 2022-06-27 11:42:11 --> Utf8 Class Initialized
INFO - 2022-06-27 11:42:11 --> URI Class Initialized
INFO - 2022-06-27 11:42:11 --> URI Class Initialized
INFO - 2022-06-27 11:42:11 --> Router Class Initialized
INFO - 2022-06-27 11:42:11 --> Router Class Initialized
INFO - 2022-06-27 11:42:11 --> Output Class Initialized
INFO - 2022-06-27 11:42:11 --> Output Class Initialized
INFO - 2022-06-27 11:42:11 --> Security Class Initialized
INFO - 2022-06-27 11:42:11 --> Security Class Initialized
DEBUG - 2022-06-27 11:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:42:11 --> Input Class Initialized
DEBUG - 2022-06-27 11:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:42:11 --> Input Class Initialized
INFO - 2022-06-27 11:42:11 --> Language Class Initialized
INFO - 2022-06-27 11:42:11 --> Language Class Initialized
ERROR - 2022-06-27 11:42:11 --> 404 Page Not Found: Tokenctrl/localhost
ERROR - 2022-06-27 11:42:11 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 11:42:13 --> Config Class Initialized
INFO - 2022-06-27 11:42:13 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:42:13 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:42:13 --> Utf8 Class Initialized
INFO - 2022-06-27 11:42:13 --> URI Class Initialized
INFO - 2022-06-27 11:42:13 --> Router Class Initialized
INFO - 2022-06-27 11:42:13 --> Output Class Initialized
INFO - 2022-06-27 11:42:13 --> Security Class Initialized
DEBUG - 2022-06-27 11:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:42:13 --> Input Class Initialized
INFO - 2022-06-27 11:42:13 --> Language Class Initialized
INFO - 2022-06-27 11:42:13 --> Loader Class Initialized
INFO - 2022-06-27 11:42:13 --> Helper loaded: url_helper
INFO - 2022-06-27 11:42:13 --> Helper loaded: file_helper
INFO - 2022-06-27 11:42:13 --> Database Driver Class Initialized
INFO - 2022-06-27 11:42:13 --> Email Class Initialized
DEBUG - 2022-06-27 11:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 11:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 11:42:13 --> Controller Class Initialized
INFO - 2022-06-27 11:42:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 11:42:13 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 11:42:13 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 11:42:13 --> Final output sent to browser
DEBUG - 2022-06-27 11:42:13 --> Total execution time: 0.0332
INFO - 2022-06-27 11:42:13 --> Config Class Initialized
INFO - 2022-06-27 11:42:13 --> Config Class Initialized
INFO - 2022-06-27 11:42:13 --> Hooks Class Initialized
INFO - 2022-06-27 11:42:13 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:42:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:42:13 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:42:13 --> Utf8 Class Initialized
INFO - 2022-06-27 11:42:13 --> Utf8 Class Initialized
INFO - 2022-06-27 11:42:13 --> URI Class Initialized
INFO - 2022-06-27 11:42:13 --> URI Class Initialized
INFO - 2022-06-27 11:42:13 --> Router Class Initialized
INFO - 2022-06-27 11:42:13 --> Router Class Initialized
INFO - 2022-06-27 11:42:13 --> Output Class Initialized
INFO - 2022-06-27 11:42:13 --> Output Class Initialized
INFO - 2022-06-27 11:42:13 --> Security Class Initialized
INFO - 2022-06-27 11:42:13 --> Security Class Initialized
DEBUG - 2022-06-27 11:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:42:13 --> Input Class Initialized
INFO - 2022-06-27 11:42:13 --> Input Class Initialized
INFO - 2022-06-27 11:42:13 --> Language Class Initialized
INFO - 2022-06-27 11:42:13 --> Language Class Initialized
ERROR - 2022-06-27 11:42:13 --> 404 Page Not Found: Tokenctrl/localhost
ERROR - 2022-06-27 11:42:13 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 11:42:28 --> Config Class Initialized
INFO - 2022-06-27 11:42:28 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:42:28 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:42:28 --> Utf8 Class Initialized
INFO - 2022-06-27 11:42:28 --> URI Class Initialized
INFO - 2022-06-27 11:42:28 --> Router Class Initialized
INFO - 2022-06-27 11:42:28 --> Output Class Initialized
INFO - 2022-06-27 11:42:28 --> Security Class Initialized
DEBUG - 2022-06-27 11:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:42:28 --> Input Class Initialized
INFO - 2022-06-27 11:42:28 --> Language Class Initialized
INFO - 2022-06-27 11:42:28 --> Loader Class Initialized
INFO - 2022-06-27 11:42:28 --> Helper loaded: url_helper
INFO - 2022-06-27 11:42:28 --> Helper loaded: file_helper
INFO - 2022-06-27 11:42:28 --> Database Driver Class Initialized
INFO - 2022-06-27 11:42:28 --> Email Class Initialized
DEBUG - 2022-06-27 11:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 11:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 11:42:28 --> Controller Class Initialized
INFO - 2022-06-27 11:42:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 11:42:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-27 11:42:28 --> Severity: Notice --> Trying to get property 'ud_token' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 333
ERROR - 2022-06-27 11:42:28 --> Severity: Notice --> Trying to get property 'ud_token' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 344
ERROR - 2022-06-27 11:42:28 --> Severity: Notice --> Trying to get property 'ud_name' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 346
ERROR - 2022-06-27 11:42:28 --> Severity: Notice --> Trying to get property 'ud_age' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 347
ERROR - 2022-06-27 11:42:28 --> Severity: Notice --> Trying to get property 'ud_gender' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 348
INFO - 2022-06-27 11:42:28 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 11:42:28 --> Final output sent to browser
DEBUG - 2022-06-27 11:42:28 --> Total execution time: 0.0276
INFO - 2022-06-27 11:42:28 --> Config Class Initialized
INFO - 2022-06-27 11:42:28 --> Config Class Initialized
INFO - 2022-06-27 11:42:28 --> Hooks Class Initialized
INFO - 2022-06-27 11:42:28 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:42:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:42:28 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:42:28 --> Utf8 Class Initialized
INFO - 2022-06-27 11:42:28 --> Utf8 Class Initialized
INFO - 2022-06-27 11:42:28 --> URI Class Initialized
INFO - 2022-06-27 11:42:28 --> URI Class Initialized
INFO - 2022-06-27 11:42:28 --> Router Class Initialized
INFO - 2022-06-27 11:42:28 --> Router Class Initialized
INFO - 2022-06-27 11:42:28 --> Output Class Initialized
INFO - 2022-06-27 11:42:28 --> Output Class Initialized
INFO - 2022-06-27 11:42:28 --> Security Class Initialized
INFO - 2022-06-27 11:42:28 --> Security Class Initialized
DEBUG - 2022-06-27 11:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:42:28 --> Input Class Initialized
INFO - 2022-06-27 11:42:28 --> Input Class Initialized
INFO - 2022-06-27 11:42:28 --> Language Class Initialized
INFO - 2022-06-27 11:42:28 --> Language Class Initialized
ERROR - 2022-06-27 11:42:28 --> 404 Page Not Found: Tokenctrl/localhost
ERROR - 2022-06-27 11:42:28 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 11:47:02 --> Config Class Initialized
INFO - 2022-06-27 11:47:02 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:47:02 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:47:02 --> Utf8 Class Initialized
INFO - 2022-06-27 11:47:02 --> URI Class Initialized
INFO - 2022-06-27 11:47:02 --> Router Class Initialized
INFO - 2022-06-27 11:47:02 --> Output Class Initialized
INFO - 2022-06-27 11:47:02 --> Security Class Initialized
DEBUG - 2022-06-27 11:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:47:02 --> Input Class Initialized
INFO - 2022-06-27 11:47:02 --> Language Class Initialized
INFO - 2022-06-27 11:47:02 --> Loader Class Initialized
INFO - 2022-06-27 11:47:02 --> Helper loaded: url_helper
INFO - 2022-06-27 11:47:02 --> Helper loaded: file_helper
INFO - 2022-06-27 11:47:02 --> Database Driver Class Initialized
INFO - 2022-06-27 11:47:02 --> Email Class Initialized
DEBUG - 2022-06-27 11:47:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 11:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 11:47:02 --> Controller Class Initialized
INFO - 2022-06-27 11:47:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 11:47:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-27 11:47:02 --> Severity: Notice --> Trying to get property 'ud_token' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 333
ERROR - 2022-06-27 11:47:02 --> Severity: Notice --> Trying to get property 'ud_token' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 344
ERROR - 2022-06-27 11:47:02 --> Severity: Notice --> Trying to get property 'ud_age' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 347
ERROR - 2022-06-27 11:47:02 --> Severity: Notice --> Trying to get property 'ud_gender' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 348
INFO - 2022-06-27 11:47:02 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 11:47:02 --> Final output sent to browser
DEBUG - 2022-06-27 11:47:02 --> Total execution time: 0.0436
INFO - 2022-06-27 11:47:03 --> Config Class Initialized
INFO - 2022-06-27 11:47:03 --> Hooks Class Initialized
INFO - 2022-06-27 11:47:03 --> Config Class Initialized
INFO - 2022-06-27 11:47:03 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:47:03 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:47:03 --> Utf8 Class Initialized
INFO - 2022-06-27 11:47:03 --> Utf8 Class Initialized
INFO - 2022-06-27 11:47:03 --> URI Class Initialized
INFO - 2022-06-27 11:47:03 --> URI Class Initialized
INFO - 2022-06-27 11:47:03 --> Router Class Initialized
INFO - 2022-06-27 11:47:03 --> Router Class Initialized
INFO - 2022-06-27 11:47:03 --> Output Class Initialized
INFO - 2022-06-27 11:47:03 --> Output Class Initialized
INFO - 2022-06-27 11:47:03 --> Security Class Initialized
INFO - 2022-06-27 11:47:03 --> Security Class Initialized
DEBUG - 2022-06-27 11:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:47:03 --> Input Class Initialized
INFO - 2022-06-27 11:47:03 --> Input Class Initialized
INFO - 2022-06-27 11:47:03 --> Language Class Initialized
INFO - 2022-06-27 11:47:03 --> Language Class Initialized
ERROR - 2022-06-27 11:47:03 --> 404 Page Not Found: Tokenctrl/localhost
ERROR - 2022-06-27 11:47:03 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 11:47:31 --> Config Class Initialized
INFO - 2022-06-27 11:47:31 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:47:31 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:47:31 --> Utf8 Class Initialized
INFO - 2022-06-27 11:47:31 --> URI Class Initialized
INFO - 2022-06-27 11:47:31 --> Router Class Initialized
INFO - 2022-06-27 11:47:31 --> Output Class Initialized
INFO - 2022-06-27 11:47:31 --> Security Class Initialized
DEBUG - 2022-06-27 11:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:47:31 --> Input Class Initialized
INFO - 2022-06-27 11:47:31 --> Language Class Initialized
INFO - 2022-06-27 11:47:31 --> Loader Class Initialized
INFO - 2022-06-27 11:47:31 --> Helper loaded: url_helper
INFO - 2022-06-27 11:47:31 --> Helper loaded: file_helper
INFO - 2022-06-27 11:47:31 --> Database Driver Class Initialized
INFO - 2022-06-27 11:47:31 --> Email Class Initialized
DEBUG - 2022-06-27 11:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 11:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 11:47:31 --> Controller Class Initialized
INFO - 2022-06-27 11:47:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 11:47:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 11:47:31 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 11:47:31 --> Final output sent to browser
DEBUG - 2022-06-27 11:47:31 --> Total execution time: 0.0272
INFO - 2022-06-27 11:47:31 --> Config Class Initialized
INFO - 2022-06-27 11:47:31 --> Hooks Class Initialized
INFO - 2022-06-27 11:47:31 --> Config Class Initialized
INFO - 2022-06-27 11:47:31 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:47:31 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:47:31 --> Utf8 Class Initialized
DEBUG - 2022-06-27 11:47:31 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:47:31 --> URI Class Initialized
INFO - 2022-06-27 11:47:31 --> Utf8 Class Initialized
INFO - 2022-06-27 11:47:31 --> URI Class Initialized
INFO - 2022-06-27 11:47:31 --> Router Class Initialized
INFO - 2022-06-27 11:47:31 --> Output Class Initialized
INFO - 2022-06-27 11:47:31 --> Router Class Initialized
INFO - 2022-06-27 11:47:31 --> Security Class Initialized
INFO - 2022-06-27 11:47:31 --> Output Class Initialized
DEBUG - 2022-06-27 11:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:47:31 --> Security Class Initialized
INFO - 2022-06-27 11:47:31 --> Input Class Initialized
DEBUG - 2022-06-27 11:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:47:31 --> Language Class Initialized
INFO - 2022-06-27 11:47:31 --> Input Class Initialized
ERROR - 2022-06-27 11:47:31 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 11:47:31 --> Language Class Initialized
ERROR - 2022-06-27 11:47:31 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 11:50:36 --> Config Class Initialized
INFO - 2022-06-27 11:50:36 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:50:36 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:50:36 --> Utf8 Class Initialized
INFO - 2022-06-27 11:50:36 --> URI Class Initialized
INFO - 2022-06-27 11:50:36 --> Router Class Initialized
INFO - 2022-06-27 11:50:36 --> Output Class Initialized
INFO - 2022-06-27 11:50:36 --> Security Class Initialized
DEBUG - 2022-06-27 11:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:50:36 --> Input Class Initialized
INFO - 2022-06-27 11:50:36 --> Language Class Initialized
INFO - 2022-06-27 11:50:36 --> Loader Class Initialized
INFO - 2022-06-27 11:50:36 --> Helper loaded: url_helper
INFO - 2022-06-27 11:50:36 --> Helper loaded: file_helper
INFO - 2022-06-27 11:50:36 --> Database Driver Class Initialized
INFO - 2022-06-27 11:50:36 --> Email Class Initialized
DEBUG - 2022-06-27 11:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 11:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 11:50:36 --> Controller Class Initialized
INFO - 2022-06-27 11:50:36 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 11:50:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-27 11:50:36 --> Severity: Notice --> Trying to get property 'ud_token' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 333
INFO - 2022-06-27 11:50:36 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 11:50:36 --> Final output sent to browser
DEBUG - 2022-06-27 11:50:36 --> Total execution time: 0.0240
INFO - 2022-06-27 11:50:36 --> Config Class Initialized
INFO - 2022-06-27 11:50:36 --> Hooks Class Initialized
INFO - 2022-06-27 11:50:36 --> Config Class Initialized
INFO - 2022-06-27 11:50:36 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:50:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-27 11:50:36 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:50:36 --> Utf8 Class Initialized
INFO - 2022-06-27 11:50:36 --> Utf8 Class Initialized
INFO - 2022-06-27 11:50:36 --> URI Class Initialized
INFO - 2022-06-27 11:50:36 --> URI Class Initialized
INFO - 2022-06-27 11:50:36 --> Router Class Initialized
INFO - 2022-06-27 11:50:36 --> Router Class Initialized
INFO - 2022-06-27 11:50:36 --> Output Class Initialized
INFO - 2022-06-27 11:50:36 --> Output Class Initialized
INFO - 2022-06-27 11:50:36 --> Security Class Initialized
INFO - 2022-06-27 11:50:36 --> Security Class Initialized
DEBUG - 2022-06-27 11:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-27 11:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:50:36 --> Input Class Initialized
INFO - 2022-06-27 11:50:36 --> Input Class Initialized
INFO - 2022-06-27 11:50:36 --> Language Class Initialized
INFO - 2022-06-27 11:50:36 --> Language Class Initialized
ERROR - 2022-06-27 11:50:36 --> 404 Page Not Found: Tokenctrl/localhost
ERROR - 2022-06-27 11:50:36 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 11:52:28 --> Config Class Initialized
INFO - 2022-06-27 11:52:28 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:52:28 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:52:28 --> Utf8 Class Initialized
INFO - 2022-06-27 11:52:28 --> URI Class Initialized
INFO - 2022-06-27 11:52:28 --> Router Class Initialized
INFO - 2022-06-27 11:52:28 --> Output Class Initialized
INFO - 2022-06-27 11:52:28 --> Security Class Initialized
DEBUG - 2022-06-27 11:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:52:28 --> Input Class Initialized
INFO - 2022-06-27 11:52:28 --> Language Class Initialized
INFO - 2022-06-27 11:52:28 --> Loader Class Initialized
INFO - 2022-06-27 11:52:28 --> Helper loaded: url_helper
INFO - 2022-06-27 11:52:28 --> Helper loaded: file_helper
INFO - 2022-06-27 11:52:28 --> Database Driver Class Initialized
INFO - 2022-06-27 11:52:28 --> Email Class Initialized
DEBUG - 2022-06-27 11:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 11:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 11:52:28 --> Controller Class Initialized
INFO - 2022-06-27 11:52:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 11:52:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 11:57:25 --> Config Class Initialized
INFO - 2022-06-27 11:57:25 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:57:25 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:57:25 --> Utf8 Class Initialized
INFO - 2022-06-27 11:57:25 --> URI Class Initialized
INFO - 2022-06-27 11:57:25 --> Router Class Initialized
INFO - 2022-06-27 11:57:25 --> Output Class Initialized
INFO - 2022-06-27 11:57:25 --> Security Class Initialized
DEBUG - 2022-06-27 11:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:57:25 --> Input Class Initialized
INFO - 2022-06-27 11:57:25 --> Language Class Initialized
INFO - 2022-06-27 11:57:25 --> Loader Class Initialized
INFO - 2022-06-27 11:57:25 --> Helper loaded: url_helper
INFO - 2022-06-27 11:57:25 --> Helper loaded: file_helper
INFO - 2022-06-27 11:57:25 --> Database Driver Class Initialized
INFO - 2022-06-27 11:57:25 --> Email Class Initialized
DEBUG - 2022-06-27 11:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 11:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 11:57:25 --> Controller Class Initialized
INFO - 2022-06-27 11:57:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 11:57:25 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 11:57:25 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 11:57:25 --> Final output sent to browser
DEBUG - 2022-06-27 11:57:25 --> Total execution time: 0.0413
INFO - 2022-06-27 11:57:25 --> Config Class Initialized
INFO - 2022-06-27 11:57:25 --> Hooks Class Initialized
INFO - 2022-06-27 11:57:25 --> Config Class Initialized
INFO - 2022-06-27 11:57:25 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:57:25 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:57:25 --> Utf8 Class Initialized
DEBUG - 2022-06-27 11:57:25 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:57:25 --> URI Class Initialized
INFO - 2022-06-27 11:57:25 --> Utf8 Class Initialized
INFO - 2022-06-27 11:57:25 --> URI Class Initialized
INFO - 2022-06-27 11:57:25 --> Router Class Initialized
INFO - 2022-06-27 11:57:25 --> Output Class Initialized
INFO - 2022-06-27 11:57:25 --> Router Class Initialized
INFO - 2022-06-27 11:57:25 --> Security Class Initialized
INFO - 2022-06-27 11:57:25 --> Output Class Initialized
DEBUG - 2022-06-27 11:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:57:25 --> Security Class Initialized
INFO - 2022-06-27 11:57:25 --> Input Class Initialized
DEBUG - 2022-06-27 11:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:57:25 --> Language Class Initialized
INFO - 2022-06-27 11:57:25 --> Input Class Initialized
INFO - 2022-06-27 11:57:25 --> Language Class Initialized
ERROR - 2022-06-27 11:57:25 --> 404 Page Not Found: Tokenctrl/localhost
ERROR - 2022-06-27 11:57:25 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 11:58:24 --> Config Class Initialized
INFO - 2022-06-27 11:58:24 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:58:24 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:58:24 --> Utf8 Class Initialized
INFO - 2022-06-27 11:58:24 --> URI Class Initialized
INFO - 2022-06-27 11:58:24 --> Router Class Initialized
INFO - 2022-06-27 11:58:24 --> Output Class Initialized
INFO - 2022-06-27 11:58:24 --> Security Class Initialized
DEBUG - 2022-06-27 11:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:58:24 --> Input Class Initialized
INFO - 2022-06-27 11:58:24 --> Language Class Initialized
INFO - 2022-06-27 11:58:24 --> Loader Class Initialized
INFO - 2022-06-27 11:58:24 --> Helper loaded: url_helper
INFO - 2022-06-27 11:58:24 --> Helper loaded: file_helper
INFO - 2022-06-27 11:58:24 --> Database Driver Class Initialized
INFO - 2022-06-27 11:58:24 --> Email Class Initialized
DEBUG - 2022-06-27 11:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 11:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 11:58:24 --> Controller Class Initialized
INFO - 2022-06-27 11:58:24 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 11:58:24 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 11:58:25 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 11:58:25 --> Final output sent to browser
DEBUG - 2022-06-27 11:58:25 --> Total execution time: 0.3287
INFO - 2022-06-27 11:58:25 --> Config Class Initialized
INFO - 2022-06-27 11:58:25 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:58:25 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:58:25 --> Utf8 Class Initialized
INFO - 2022-06-27 11:58:25 --> URI Class Initialized
INFO - 2022-06-27 11:58:25 --> Router Class Initialized
INFO - 2022-06-27 11:58:25 --> Output Class Initialized
INFO - 2022-06-27 11:58:25 --> Security Class Initialized
DEBUG - 2022-06-27 11:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:58:25 --> Input Class Initialized
INFO - 2022-06-27 11:58:25 --> Language Class Initialized
ERROR - 2022-06-27 11:58:25 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 11:58:25 --> Config Class Initialized
INFO - 2022-06-27 11:58:25 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:58:25 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:58:25 --> Utf8 Class Initialized
INFO - 2022-06-27 11:58:25 --> URI Class Initialized
INFO - 2022-06-27 11:58:25 --> Router Class Initialized
INFO - 2022-06-27 11:58:25 --> Output Class Initialized
INFO - 2022-06-27 11:58:25 --> Security Class Initialized
DEBUG - 2022-06-27 11:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:58:25 --> Input Class Initialized
INFO - 2022-06-27 11:58:25 --> Language Class Initialized
ERROR - 2022-06-27 11:58:25 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 11:59:18 --> Config Class Initialized
INFO - 2022-06-27 11:59:18 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:59:18 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:59:18 --> Utf8 Class Initialized
INFO - 2022-06-27 11:59:18 --> URI Class Initialized
INFO - 2022-06-27 11:59:18 --> Router Class Initialized
INFO - 2022-06-27 11:59:18 --> Output Class Initialized
INFO - 2022-06-27 11:59:18 --> Security Class Initialized
DEBUG - 2022-06-27 11:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:59:18 --> Input Class Initialized
INFO - 2022-06-27 11:59:18 --> Language Class Initialized
INFO - 2022-06-27 11:59:18 --> Loader Class Initialized
INFO - 2022-06-27 11:59:18 --> Helper loaded: url_helper
INFO - 2022-06-27 11:59:18 --> Helper loaded: file_helper
INFO - 2022-06-27 11:59:18 --> Database Driver Class Initialized
INFO - 2022-06-27 11:59:18 --> Email Class Initialized
DEBUG - 2022-06-27 11:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 11:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 11:59:18 --> Controller Class Initialized
INFO - 2022-06-27 11:59:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 11:59:18 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 11:59:18 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-27 11:59:18 --> Final output sent to browser
DEBUG - 2022-06-27 11:59:18 --> Total execution time: 0.0230
INFO - 2022-06-27 11:59:19 --> Config Class Initialized
INFO - 2022-06-27 11:59:19 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:59:19 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:59:19 --> Utf8 Class Initialized
INFO - 2022-06-27 11:59:19 --> URI Class Initialized
INFO - 2022-06-27 11:59:19 --> Router Class Initialized
INFO - 2022-06-27 11:59:19 --> Output Class Initialized
INFO - 2022-06-27 11:59:19 --> Security Class Initialized
DEBUG - 2022-06-27 11:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:59:19 --> Input Class Initialized
INFO - 2022-06-27 11:59:19 --> Config Class Initialized
INFO - 2022-06-27 11:59:19 --> Language Class Initialized
INFO - 2022-06-27 11:59:19 --> Hooks Class Initialized
ERROR - 2022-06-27 11:59:19 --> 404 Page Not Found: Tokenctrl/localhost
DEBUG - 2022-06-27 11:59:19 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:59:19 --> Utf8 Class Initialized
INFO - 2022-06-27 11:59:19 --> URI Class Initialized
INFO - 2022-06-27 11:59:19 --> Router Class Initialized
INFO - 2022-06-27 11:59:19 --> Output Class Initialized
INFO - 2022-06-27 11:59:19 --> Security Class Initialized
DEBUG - 2022-06-27 11:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:59:19 --> Input Class Initialized
INFO - 2022-06-27 11:59:19 --> Language Class Initialized
ERROR - 2022-06-27 11:59:19 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-27 11:59:32 --> Config Class Initialized
INFO - 2022-06-27 11:59:32 --> Hooks Class Initialized
DEBUG - 2022-06-27 11:59:32 --> UTF-8 Support Enabled
INFO - 2022-06-27 11:59:32 --> Utf8 Class Initialized
INFO - 2022-06-27 11:59:32 --> URI Class Initialized
INFO - 2022-06-27 11:59:32 --> Router Class Initialized
INFO - 2022-06-27 11:59:32 --> Output Class Initialized
INFO - 2022-06-27 11:59:32 --> Security Class Initialized
DEBUG - 2022-06-27 11:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 11:59:32 --> Input Class Initialized
INFO - 2022-06-27 11:59:32 --> Language Class Initialized
INFO - 2022-06-27 11:59:32 --> Loader Class Initialized
INFO - 2022-06-27 11:59:32 --> Helper loaded: url_helper
INFO - 2022-06-27 11:59:32 --> Helper loaded: file_helper
INFO - 2022-06-27 11:59:32 --> Database Driver Class Initialized
INFO - 2022-06-27 11:59:32 --> Email Class Initialized
DEBUG - 2022-06-27 11:59:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 11:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 11:59:32 --> Controller Class Initialized
INFO - 2022-06-27 11:59:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 11:59:32 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 12:00:00 --> Config Class Initialized
INFO - 2022-06-27 12:00:00 --> Hooks Class Initialized
DEBUG - 2022-06-27 12:00:00 --> UTF-8 Support Enabled
INFO - 2022-06-27 12:00:00 --> Utf8 Class Initialized
INFO - 2022-06-27 12:00:00 --> URI Class Initialized
INFO - 2022-06-27 12:00:00 --> Router Class Initialized
INFO - 2022-06-27 12:00:00 --> Output Class Initialized
INFO - 2022-06-27 12:00:00 --> Security Class Initialized
DEBUG - 2022-06-27 12:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 12:00:00 --> Input Class Initialized
INFO - 2022-06-27 12:00:00 --> Language Class Initialized
INFO - 2022-06-27 12:00:00 --> Loader Class Initialized
INFO - 2022-06-27 12:00:00 --> Helper loaded: url_helper
INFO - 2022-06-27 12:00:00 --> Helper loaded: file_helper
INFO - 2022-06-27 12:00:00 --> Database Driver Class Initialized
INFO - 2022-06-27 12:00:00 --> Email Class Initialized
DEBUG - 2022-06-27 12:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 12:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 12:00:00 --> Controller Class Initialized
INFO - 2022-06-27 12:00:00 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 12:00:00 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 12:00:00 --> Final output sent to browser
DEBUG - 2022-06-27 12:00:00 --> Total execution time: 0.0211
INFO - 2022-06-27 12:00:12 --> Config Class Initialized
INFO - 2022-06-27 12:00:12 --> Hooks Class Initialized
DEBUG - 2022-06-27 12:00:12 --> UTF-8 Support Enabled
INFO - 2022-06-27 12:00:12 --> Utf8 Class Initialized
INFO - 2022-06-27 12:00:12 --> URI Class Initialized
INFO - 2022-06-27 12:00:12 --> Router Class Initialized
INFO - 2022-06-27 12:00:12 --> Output Class Initialized
INFO - 2022-06-27 12:00:12 --> Security Class Initialized
DEBUG - 2022-06-27 12:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 12:00:12 --> Input Class Initialized
INFO - 2022-06-27 12:00:12 --> Language Class Initialized
INFO - 2022-06-27 12:00:12 --> Loader Class Initialized
INFO - 2022-06-27 12:00:12 --> Helper loaded: url_helper
INFO - 2022-06-27 12:00:12 --> Helper loaded: file_helper
INFO - 2022-06-27 12:00:12 --> Database Driver Class Initialized
INFO - 2022-06-27 12:00:12 --> Email Class Initialized
DEBUG - 2022-06-27 12:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 12:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 12:00:12 --> Controller Class Initialized
INFO - 2022-06-27 12:00:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 12:00:12 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 12:00:12 --> Final output sent to browser
DEBUG - 2022-06-27 12:00:12 --> Total execution time: 0.0511
INFO - 2022-06-27 12:29:25 --> Config Class Initialized
INFO - 2022-06-27 12:29:25 --> Hooks Class Initialized
DEBUG - 2022-06-27 12:29:25 --> UTF-8 Support Enabled
INFO - 2022-06-27 12:29:25 --> Utf8 Class Initialized
INFO - 2022-06-27 12:29:25 --> URI Class Initialized
INFO - 2022-06-27 12:29:25 --> Router Class Initialized
INFO - 2022-06-27 12:29:25 --> Output Class Initialized
INFO - 2022-06-27 12:29:25 --> Security Class Initialized
DEBUG - 2022-06-27 12:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 12:29:25 --> Input Class Initialized
INFO - 2022-06-27 12:29:25 --> Language Class Initialized
INFO - 2022-06-27 12:29:25 --> Loader Class Initialized
INFO - 2022-06-27 12:29:25 --> Helper loaded: url_helper
INFO - 2022-06-27 12:29:25 --> Helper loaded: file_helper
INFO - 2022-06-27 12:29:25 --> Database Driver Class Initialized
INFO - 2022-06-27 12:29:25 --> Email Class Initialized
DEBUG - 2022-06-27 12:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 12:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 12:29:25 --> Controller Class Initialized
INFO - 2022-06-27 12:29:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 12:29:25 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 12:29:25 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-27 12:29:25 --> Final output sent to browser
DEBUG - 2022-06-27 12:29:25 --> Total execution time: 0.0378
INFO - 2022-06-27 12:45:17 --> Config Class Initialized
INFO - 2022-06-27 12:45:17 --> Hooks Class Initialized
DEBUG - 2022-06-27 12:45:17 --> UTF-8 Support Enabled
INFO - 2022-06-27 12:45:17 --> Utf8 Class Initialized
INFO - 2022-06-27 12:45:17 --> URI Class Initialized
INFO - 2022-06-27 12:45:17 --> Router Class Initialized
INFO - 2022-06-27 12:45:17 --> Output Class Initialized
INFO - 2022-06-27 12:45:17 --> Security Class Initialized
DEBUG - 2022-06-27 12:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 12:45:17 --> Input Class Initialized
INFO - 2022-06-27 12:45:17 --> Language Class Initialized
INFO - 2022-06-27 12:45:17 --> Loader Class Initialized
INFO - 2022-06-27 12:45:17 --> Helper loaded: url_helper
INFO - 2022-06-27 12:45:17 --> Helper loaded: file_helper
INFO - 2022-06-27 12:45:17 --> Database Driver Class Initialized
INFO - 2022-06-27 12:45:17 --> Email Class Initialized
DEBUG - 2022-06-27 12:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 12:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 12:45:17 --> Controller Class Initialized
INFO - 2022-06-27 12:45:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 12:45:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 12:45:17 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-27 12:45:17 --> Final output sent to browser
DEBUG - 2022-06-27 12:45:17 --> Total execution time: 0.0939
INFO - 2022-06-27 12:46:42 --> Config Class Initialized
INFO - 2022-06-27 12:46:42 --> Hooks Class Initialized
DEBUG - 2022-06-27 12:46:42 --> UTF-8 Support Enabled
INFO - 2022-06-27 12:46:42 --> Utf8 Class Initialized
INFO - 2022-06-27 12:46:42 --> URI Class Initialized
INFO - 2022-06-27 12:46:42 --> Router Class Initialized
INFO - 2022-06-27 12:46:42 --> Output Class Initialized
INFO - 2022-06-27 12:46:42 --> Security Class Initialized
DEBUG - 2022-06-27 12:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 12:46:42 --> Input Class Initialized
INFO - 2022-06-27 12:46:42 --> Language Class Initialized
INFO - 2022-06-27 12:46:42 --> Loader Class Initialized
INFO - 2022-06-27 12:46:42 --> Helper loaded: url_helper
INFO - 2022-06-27 12:46:42 --> Helper loaded: file_helper
INFO - 2022-06-27 12:46:42 --> Database Driver Class Initialized
INFO - 2022-06-27 12:46:42 --> Email Class Initialized
DEBUG - 2022-06-27 12:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 12:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 12:46:42 --> Controller Class Initialized
INFO - 2022-06-27 12:46:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 12:46:42 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 12:46:42 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-27 12:46:42 --> Final output sent to browser
DEBUG - 2022-06-27 12:46:42 --> Total execution time: 0.0379
INFO - 2022-06-27 12:48:27 --> Config Class Initialized
INFO - 2022-06-27 12:48:27 --> Hooks Class Initialized
DEBUG - 2022-06-27 12:48:27 --> UTF-8 Support Enabled
INFO - 2022-06-27 12:48:27 --> Utf8 Class Initialized
INFO - 2022-06-27 12:48:27 --> URI Class Initialized
INFO - 2022-06-27 12:48:27 --> Router Class Initialized
INFO - 2022-06-27 12:48:27 --> Output Class Initialized
INFO - 2022-06-27 12:48:27 --> Security Class Initialized
DEBUG - 2022-06-27 12:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 12:48:27 --> Input Class Initialized
INFO - 2022-06-27 12:48:27 --> Language Class Initialized
INFO - 2022-06-27 12:48:27 --> Loader Class Initialized
INFO - 2022-06-27 12:48:27 --> Helper loaded: url_helper
INFO - 2022-06-27 12:48:27 --> Helper loaded: file_helper
INFO - 2022-06-27 12:48:27 --> Database Driver Class Initialized
INFO - 2022-06-27 12:48:27 --> Email Class Initialized
DEBUG - 2022-06-27 12:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 12:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 12:48:27 --> Controller Class Initialized
INFO - 2022-06-27 12:48:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 12:48:27 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 12:48:27 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-27 12:48:27 --> Final output sent to browser
DEBUG - 2022-06-27 12:48:27 --> Total execution time: 0.1336
INFO - 2022-06-27 12:49:11 --> Config Class Initialized
INFO - 2022-06-27 12:49:11 --> Hooks Class Initialized
DEBUG - 2022-06-27 12:49:11 --> UTF-8 Support Enabled
INFO - 2022-06-27 12:49:11 --> Utf8 Class Initialized
INFO - 2022-06-27 12:49:11 --> URI Class Initialized
INFO - 2022-06-27 12:49:11 --> Router Class Initialized
INFO - 2022-06-27 12:49:11 --> Output Class Initialized
INFO - 2022-06-27 12:49:11 --> Security Class Initialized
DEBUG - 2022-06-27 12:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-27 12:49:11 --> Input Class Initialized
INFO - 2022-06-27 12:49:11 --> Language Class Initialized
INFO - 2022-06-27 12:49:11 --> Loader Class Initialized
INFO - 2022-06-27 12:49:11 --> Helper loaded: url_helper
INFO - 2022-06-27 12:49:11 --> Helper loaded: file_helper
INFO - 2022-06-27 12:49:11 --> Database Driver Class Initialized
INFO - 2022-06-27 12:49:11 --> Email Class Initialized
DEBUG - 2022-06-27 12:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-27 12:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-27 12:49:11 --> Controller Class Initialized
INFO - 2022-06-27 12:49:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-27 12:49:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-27 12:49:11 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-27 12:49:11 --> Final output sent to browser
DEBUG - 2022-06-27 12:49:11 --> Total execution time: 0.0320
