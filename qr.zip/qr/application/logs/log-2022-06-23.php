<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-06-23 04:41:32 --> Config Class Initialized
INFO - 2022-06-23 04:41:32 --> Hooks Class Initialized
DEBUG - 2022-06-23 04:41:32 --> UTF-8 Support Enabled
INFO - 2022-06-23 04:41:32 --> Utf8 Class Initialized
INFO - 2022-06-23 04:41:32 --> URI Class Initialized
INFO - 2022-06-23 04:41:32 --> Router Class Initialized
INFO - 2022-06-23 04:41:32 --> Output Class Initialized
INFO - 2022-06-23 04:41:32 --> Security Class Initialized
DEBUG - 2022-06-23 04:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 04:41:32 --> Input Class Initialized
INFO - 2022-06-23 04:41:32 --> Language Class Initialized
INFO - 2022-06-23 04:41:32 --> Loader Class Initialized
INFO - 2022-06-23 04:41:32 --> Helper loaded: url_helper
INFO - 2022-06-23 04:41:32 --> Helper loaded: file_helper
INFO - 2022-06-23 04:41:32 --> Database Driver Class Initialized
INFO - 2022-06-23 04:41:32 --> Email Class Initialized
DEBUG - 2022-06-23 04:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 04:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 04:41:32 --> Controller Class Initialized
INFO - 2022-06-23 04:41:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 04:41:32 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 04:41:32 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 04:41:32 --> Final output sent to browser
DEBUG - 2022-06-23 04:41:32 --> Total execution time: 0.2957
INFO - 2022-06-23 04:55:24 --> Config Class Initialized
INFO - 2022-06-23 04:55:24 --> Hooks Class Initialized
DEBUG - 2022-06-23 04:55:24 --> UTF-8 Support Enabled
INFO - 2022-06-23 04:55:24 --> Utf8 Class Initialized
INFO - 2022-06-23 04:55:24 --> URI Class Initialized
INFO - 2022-06-23 04:55:24 --> Router Class Initialized
INFO - 2022-06-23 04:55:24 --> Output Class Initialized
INFO - 2022-06-23 04:55:24 --> Security Class Initialized
DEBUG - 2022-06-23 04:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 04:55:24 --> Input Class Initialized
INFO - 2022-06-23 04:55:24 --> Language Class Initialized
INFO - 2022-06-23 04:55:24 --> Loader Class Initialized
INFO - 2022-06-23 04:55:24 --> Helper loaded: url_helper
INFO - 2022-06-23 04:55:24 --> Helper loaded: file_helper
INFO - 2022-06-23 04:55:24 --> Database Driver Class Initialized
INFO - 2022-06-23 04:55:24 --> Email Class Initialized
DEBUG - 2022-06-23 04:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 04:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 04:55:24 --> Controller Class Initialized
INFO - 2022-06-23 04:55:24 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 04:55:24 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 04:55:24 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 04:55:24 --> Final output sent to browser
DEBUG - 2022-06-23 04:55:24 --> Total execution time: 0.1055
INFO - 2022-06-23 04:55:35 --> Config Class Initialized
INFO - 2022-06-23 04:55:35 --> Hooks Class Initialized
DEBUG - 2022-06-23 04:55:35 --> UTF-8 Support Enabled
INFO - 2022-06-23 04:55:35 --> Utf8 Class Initialized
INFO - 2022-06-23 04:55:35 --> URI Class Initialized
INFO - 2022-06-23 04:55:35 --> Router Class Initialized
INFO - 2022-06-23 04:55:35 --> Output Class Initialized
INFO - 2022-06-23 04:55:35 --> Security Class Initialized
DEBUG - 2022-06-23 04:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 04:55:35 --> Input Class Initialized
INFO - 2022-06-23 04:55:35 --> Language Class Initialized
INFO - 2022-06-23 04:55:35 --> Loader Class Initialized
INFO - 2022-06-23 04:55:35 --> Helper loaded: url_helper
INFO - 2022-06-23 04:55:35 --> Helper loaded: file_helper
INFO - 2022-06-23 04:55:35 --> Database Driver Class Initialized
INFO - 2022-06-23 04:55:35 --> Email Class Initialized
DEBUG - 2022-06-23 04:55:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 04:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 04:55:35 --> Controller Class Initialized
INFO - 2022-06-23 04:55:35 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 04:55:35 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 04:55:35 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 04:55:35 --> Final output sent to browser
DEBUG - 2022-06-23 04:55:35 --> Total execution time: 0.0788
INFO - 2022-06-23 04:55:44 --> Config Class Initialized
INFO - 2022-06-23 04:55:44 --> Hooks Class Initialized
DEBUG - 2022-06-23 04:55:44 --> UTF-8 Support Enabled
INFO - 2022-06-23 04:55:44 --> Utf8 Class Initialized
INFO - 2022-06-23 04:55:44 --> URI Class Initialized
INFO - 2022-06-23 04:55:44 --> Router Class Initialized
INFO - 2022-06-23 04:55:44 --> Output Class Initialized
INFO - 2022-06-23 04:55:44 --> Security Class Initialized
DEBUG - 2022-06-23 04:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 04:55:44 --> Input Class Initialized
INFO - 2022-06-23 04:55:44 --> Language Class Initialized
INFO - 2022-06-23 04:55:44 --> Loader Class Initialized
INFO - 2022-06-23 04:55:44 --> Helper loaded: url_helper
INFO - 2022-06-23 04:55:44 --> Helper loaded: file_helper
INFO - 2022-06-23 04:55:44 --> Database Driver Class Initialized
INFO - 2022-06-23 04:55:44 --> Email Class Initialized
DEBUG - 2022-06-23 04:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 04:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 04:55:44 --> Controller Class Initialized
INFO - 2022-06-23 04:55:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 04:55:44 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 04:55:44 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 04:55:44 --> Final output sent to browser
DEBUG - 2022-06-23 04:55:44 --> Total execution time: 0.2111
INFO - 2022-06-23 04:56:07 --> Config Class Initialized
INFO - 2022-06-23 04:56:07 --> Hooks Class Initialized
DEBUG - 2022-06-23 04:56:07 --> UTF-8 Support Enabled
INFO - 2022-06-23 04:56:07 --> Utf8 Class Initialized
INFO - 2022-06-23 04:56:07 --> URI Class Initialized
INFO - 2022-06-23 04:56:07 --> Router Class Initialized
INFO - 2022-06-23 04:56:07 --> Output Class Initialized
INFO - 2022-06-23 04:56:07 --> Security Class Initialized
DEBUG - 2022-06-23 04:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 04:56:07 --> Input Class Initialized
INFO - 2022-06-23 04:56:07 --> Language Class Initialized
INFO - 2022-06-23 04:56:07 --> Loader Class Initialized
INFO - 2022-06-23 04:56:07 --> Helper loaded: url_helper
INFO - 2022-06-23 04:56:07 --> Helper loaded: file_helper
INFO - 2022-06-23 04:56:07 --> Database Driver Class Initialized
INFO - 2022-06-23 04:56:07 --> Email Class Initialized
DEBUG - 2022-06-23 04:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 04:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 04:56:07 --> Controller Class Initialized
INFO - 2022-06-23 04:56:07 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 04:56:07 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 04:56:07 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 04:56:07 --> Final output sent to browser
DEBUG - 2022-06-23 04:56:07 --> Total execution time: 0.1395
INFO - 2022-06-23 04:56:26 --> Config Class Initialized
INFO - 2022-06-23 04:56:26 --> Hooks Class Initialized
DEBUG - 2022-06-23 04:56:26 --> UTF-8 Support Enabled
INFO - 2022-06-23 04:56:26 --> Utf8 Class Initialized
INFO - 2022-06-23 04:56:26 --> URI Class Initialized
INFO - 2022-06-23 04:56:26 --> Router Class Initialized
INFO - 2022-06-23 04:56:26 --> Output Class Initialized
INFO - 2022-06-23 04:56:26 --> Security Class Initialized
DEBUG - 2022-06-23 04:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 04:56:26 --> Input Class Initialized
INFO - 2022-06-23 04:56:26 --> Language Class Initialized
INFO - 2022-06-23 04:56:26 --> Loader Class Initialized
INFO - 2022-06-23 04:56:26 --> Helper loaded: url_helper
INFO - 2022-06-23 04:56:26 --> Helper loaded: file_helper
INFO - 2022-06-23 04:56:26 --> Database Driver Class Initialized
INFO - 2022-06-23 04:56:26 --> Email Class Initialized
DEBUG - 2022-06-23 04:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 04:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 04:56:26 --> Controller Class Initialized
INFO - 2022-06-23 04:56:26 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 04:56:26 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 04:56:26 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 04:56:26 --> Final output sent to browser
DEBUG - 2022-06-23 04:56:26 --> Total execution time: 0.2276
INFO - 2022-06-23 04:56:31 --> Config Class Initialized
INFO - 2022-06-23 04:56:31 --> Hooks Class Initialized
DEBUG - 2022-06-23 04:56:31 --> UTF-8 Support Enabled
INFO - 2022-06-23 04:56:31 --> Utf8 Class Initialized
INFO - 2022-06-23 04:56:31 --> URI Class Initialized
INFO - 2022-06-23 04:56:31 --> Router Class Initialized
INFO - 2022-06-23 04:56:31 --> Output Class Initialized
INFO - 2022-06-23 04:56:31 --> Security Class Initialized
DEBUG - 2022-06-23 04:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 04:56:31 --> Input Class Initialized
INFO - 2022-06-23 04:56:31 --> Language Class Initialized
INFO - 2022-06-23 04:56:31 --> Loader Class Initialized
INFO - 2022-06-23 04:56:31 --> Helper loaded: url_helper
INFO - 2022-06-23 04:56:31 --> Helper loaded: file_helper
INFO - 2022-06-23 04:56:31 --> Database Driver Class Initialized
INFO - 2022-06-23 04:56:31 --> Email Class Initialized
DEBUG - 2022-06-23 04:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 04:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 04:56:31 --> Controller Class Initialized
INFO - 2022-06-23 04:56:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 04:56:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 04:56:31 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 04:56:31 --> Final output sent to browser
DEBUG - 2022-06-23 04:56:31 --> Total execution time: 0.1811
INFO - 2022-06-23 04:57:24 --> Config Class Initialized
INFO - 2022-06-23 04:57:24 --> Hooks Class Initialized
DEBUG - 2022-06-23 04:57:24 --> UTF-8 Support Enabled
INFO - 2022-06-23 04:57:24 --> Utf8 Class Initialized
INFO - 2022-06-23 04:57:24 --> URI Class Initialized
INFO - 2022-06-23 04:57:24 --> Router Class Initialized
INFO - 2022-06-23 04:57:24 --> Output Class Initialized
INFO - 2022-06-23 04:57:24 --> Security Class Initialized
DEBUG - 2022-06-23 04:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 04:57:24 --> Input Class Initialized
INFO - 2022-06-23 04:57:24 --> Language Class Initialized
INFO - 2022-06-23 04:57:24 --> Loader Class Initialized
INFO - 2022-06-23 04:57:24 --> Helper loaded: url_helper
INFO - 2022-06-23 04:57:24 --> Helper loaded: file_helper
INFO - 2022-06-23 04:57:24 --> Database Driver Class Initialized
INFO - 2022-06-23 04:57:24 --> Email Class Initialized
DEBUG - 2022-06-23 04:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 04:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 04:57:24 --> Controller Class Initialized
INFO - 2022-06-23 04:57:24 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 04:57:24 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 04:57:24 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 04:57:24 --> Final output sent to browser
DEBUG - 2022-06-23 04:57:24 --> Total execution time: 0.1534
INFO - 2022-06-23 04:57:29 --> Config Class Initialized
INFO - 2022-06-23 04:57:29 --> Hooks Class Initialized
DEBUG - 2022-06-23 04:57:29 --> UTF-8 Support Enabled
INFO - 2022-06-23 04:57:29 --> Utf8 Class Initialized
INFO - 2022-06-23 04:57:29 --> URI Class Initialized
INFO - 2022-06-23 04:57:29 --> Router Class Initialized
INFO - 2022-06-23 04:57:29 --> Output Class Initialized
INFO - 2022-06-23 04:57:29 --> Security Class Initialized
DEBUG - 2022-06-23 04:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 04:57:29 --> Input Class Initialized
INFO - 2022-06-23 04:57:29 --> Language Class Initialized
INFO - 2022-06-23 04:57:30 --> Loader Class Initialized
INFO - 2022-06-23 04:57:30 --> Helper loaded: url_helper
INFO - 2022-06-23 04:57:30 --> Helper loaded: file_helper
INFO - 2022-06-23 04:57:30 --> Database Driver Class Initialized
INFO - 2022-06-23 04:57:30 --> Email Class Initialized
DEBUG - 2022-06-23 04:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 04:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 04:57:30 --> Controller Class Initialized
INFO - 2022-06-23 04:57:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 04:57:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 04:57:30 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 04:57:30 --> Final output sent to browser
DEBUG - 2022-06-23 04:57:30 --> Total execution time: 0.1775
INFO - 2022-06-23 04:57:32 --> Config Class Initialized
INFO - 2022-06-23 04:57:32 --> Hooks Class Initialized
DEBUG - 2022-06-23 04:57:32 --> UTF-8 Support Enabled
INFO - 2022-06-23 04:57:32 --> Utf8 Class Initialized
INFO - 2022-06-23 04:57:32 --> URI Class Initialized
INFO - 2022-06-23 04:57:32 --> Router Class Initialized
INFO - 2022-06-23 04:57:32 --> Output Class Initialized
INFO - 2022-06-23 04:57:32 --> Security Class Initialized
DEBUG - 2022-06-23 04:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 04:57:32 --> Input Class Initialized
INFO - 2022-06-23 04:57:32 --> Language Class Initialized
INFO - 2022-06-23 04:57:32 --> Loader Class Initialized
INFO - 2022-06-23 04:57:32 --> Helper loaded: url_helper
INFO - 2022-06-23 04:57:32 --> Helper loaded: file_helper
INFO - 2022-06-23 04:57:32 --> Database Driver Class Initialized
INFO - 2022-06-23 04:57:32 --> Email Class Initialized
DEBUG - 2022-06-23 04:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 04:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 04:57:32 --> Controller Class Initialized
INFO - 2022-06-23 04:57:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 04:57:32 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 04:57:32 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 04:57:32 --> Final output sent to browser
DEBUG - 2022-06-23 04:57:32 --> Total execution time: 0.2452
INFO - 2022-06-23 04:57:46 --> Config Class Initialized
INFO - 2022-06-23 04:57:46 --> Hooks Class Initialized
DEBUG - 2022-06-23 04:57:46 --> UTF-8 Support Enabled
INFO - 2022-06-23 04:57:46 --> Utf8 Class Initialized
INFO - 2022-06-23 04:57:46 --> URI Class Initialized
INFO - 2022-06-23 04:57:46 --> Router Class Initialized
INFO - 2022-06-23 04:57:46 --> Output Class Initialized
INFO - 2022-06-23 04:57:46 --> Security Class Initialized
DEBUG - 2022-06-23 04:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 04:57:46 --> Input Class Initialized
INFO - 2022-06-23 04:57:46 --> Language Class Initialized
INFO - 2022-06-23 04:57:46 --> Loader Class Initialized
INFO - 2022-06-23 04:57:46 --> Helper loaded: url_helper
INFO - 2022-06-23 04:57:46 --> Helper loaded: file_helper
INFO - 2022-06-23 04:57:46 --> Database Driver Class Initialized
INFO - 2022-06-23 04:57:46 --> Email Class Initialized
DEBUG - 2022-06-23 04:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 04:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 04:57:46 --> Controller Class Initialized
INFO - 2022-06-23 04:57:46 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 04:57:46 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 04:57:46 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 04:57:46 --> Final output sent to browser
DEBUG - 2022-06-23 04:57:46 --> Total execution time: 0.0404
INFO - 2022-06-23 04:58:34 --> Config Class Initialized
INFO - 2022-06-23 04:58:34 --> Hooks Class Initialized
DEBUG - 2022-06-23 04:58:34 --> UTF-8 Support Enabled
INFO - 2022-06-23 04:58:34 --> Utf8 Class Initialized
INFO - 2022-06-23 04:58:34 --> URI Class Initialized
INFO - 2022-06-23 04:58:34 --> Router Class Initialized
INFO - 2022-06-23 04:58:34 --> Output Class Initialized
INFO - 2022-06-23 04:58:34 --> Security Class Initialized
DEBUG - 2022-06-23 04:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 04:58:34 --> Input Class Initialized
INFO - 2022-06-23 04:58:34 --> Language Class Initialized
INFO - 2022-06-23 04:58:34 --> Loader Class Initialized
INFO - 2022-06-23 04:58:34 --> Helper loaded: url_helper
INFO - 2022-06-23 04:58:34 --> Helper loaded: file_helper
INFO - 2022-06-23 04:58:34 --> Database Driver Class Initialized
INFO - 2022-06-23 04:58:34 --> Email Class Initialized
DEBUG - 2022-06-23 04:58:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 04:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 04:58:34 --> Controller Class Initialized
INFO - 2022-06-23 04:58:34 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 04:58:34 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 04:58:34 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 04:58:34 --> Final output sent to browser
DEBUG - 2022-06-23 04:58:34 --> Total execution time: 0.1540
INFO - 2022-06-23 04:58:47 --> Config Class Initialized
INFO - 2022-06-23 04:58:47 --> Hooks Class Initialized
DEBUG - 2022-06-23 04:58:47 --> UTF-8 Support Enabled
INFO - 2022-06-23 04:58:47 --> Utf8 Class Initialized
INFO - 2022-06-23 04:58:47 --> URI Class Initialized
INFO - 2022-06-23 04:58:47 --> Router Class Initialized
INFO - 2022-06-23 04:58:47 --> Output Class Initialized
INFO - 2022-06-23 04:58:47 --> Security Class Initialized
DEBUG - 2022-06-23 04:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 04:58:47 --> Input Class Initialized
INFO - 2022-06-23 04:58:47 --> Language Class Initialized
INFO - 2022-06-23 04:58:47 --> Loader Class Initialized
INFO - 2022-06-23 04:58:47 --> Helper loaded: url_helper
INFO - 2022-06-23 04:58:47 --> Helper loaded: file_helper
INFO - 2022-06-23 04:58:47 --> Database Driver Class Initialized
INFO - 2022-06-23 04:58:47 --> Email Class Initialized
DEBUG - 2022-06-23 04:58:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 04:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 04:58:47 --> Controller Class Initialized
INFO - 2022-06-23 04:58:47 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 04:58:47 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 04:58:47 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 04:58:47 --> Final output sent to browser
DEBUG - 2022-06-23 04:58:47 --> Total execution time: 0.1527
INFO - 2022-06-23 04:59:55 --> Config Class Initialized
INFO - 2022-06-23 04:59:55 --> Hooks Class Initialized
DEBUG - 2022-06-23 04:59:55 --> UTF-8 Support Enabled
INFO - 2022-06-23 04:59:55 --> Utf8 Class Initialized
INFO - 2022-06-23 04:59:55 --> URI Class Initialized
INFO - 2022-06-23 04:59:55 --> Router Class Initialized
INFO - 2022-06-23 04:59:55 --> Output Class Initialized
INFO - 2022-06-23 04:59:55 --> Security Class Initialized
DEBUG - 2022-06-23 04:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 04:59:55 --> Input Class Initialized
INFO - 2022-06-23 04:59:55 --> Language Class Initialized
INFO - 2022-06-23 04:59:55 --> Loader Class Initialized
INFO - 2022-06-23 04:59:55 --> Helper loaded: url_helper
INFO - 2022-06-23 04:59:55 --> Helper loaded: file_helper
INFO - 2022-06-23 04:59:55 --> Database Driver Class Initialized
INFO - 2022-06-23 04:59:55 --> Email Class Initialized
DEBUG - 2022-06-23 04:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 04:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 04:59:55 --> Controller Class Initialized
INFO - 2022-06-23 04:59:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 04:59:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 04:59:55 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 04:59:55 --> Final output sent to browser
DEBUG - 2022-06-23 04:59:55 --> Total execution time: 0.1107
INFO - 2022-06-23 05:00:08 --> Config Class Initialized
INFO - 2022-06-23 05:00:08 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:00:08 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:00:08 --> Utf8 Class Initialized
INFO - 2022-06-23 05:00:08 --> URI Class Initialized
INFO - 2022-06-23 05:00:08 --> Router Class Initialized
INFO - 2022-06-23 05:00:08 --> Output Class Initialized
INFO - 2022-06-23 05:00:08 --> Security Class Initialized
DEBUG - 2022-06-23 05:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:00:08 --> Input Class Initialized
INFO - 2022-06-23 05:00:08 --> Language Class Initialized
INFO - 2022-06-23 05:00:08 --> Loader Class Initialized
INFO - 2022-06-23 05:00:08 --> Helper loaded: url_helper
INFO - 2022-06-23 05:00:08 --> Helper loaded: file_helper
INFO - 2022-06-23 05:00:08 --> Database Driver Class Initialized
INFO - 2022-06-23 05:00:08 --> Email Class Initialized
DEBUG - 2022-06-23 05:00:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:00:08 --> Controller Class Initialized
INFO - 2022-06-23 05:00:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:00:08 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:00:08 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:00:08 --> Final output sent to browser
DEBUG - 2022-06-23 05:00:08 --> Total execution time: 0.0218
INFO - 2022-06-23 05:05:54 --> Config Class Initialized
INFO - 2022-06-23 05:05:54 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:05:54 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:05:54 --> Utf8 Class Initialized
INFO - 2022-06-23 05:05:54 --> URI Class Initialized
INFO - 2022-06-23 05:05:54 --> Router Class Initialized
INFO - 2022-06-23 05:05:54 --> Output Class Initialized
INFO - 2022-06-23 05:05:54 --> Security Class Initialized
DEBUG - 2022-06-23 05:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:05:54 --> Input Class Initialized
INFO - 2022-06-23 05:05:54 --> Language Class Initialized
INFO - 2022-06-23 05:05:54 --> Loader Class Initialized
INFO - 2022-06-23 05:05:54 --> Helper loaded: url_helper
INFO - 2022-06-23 05:05:54 --> Helper loaded: file_helper
INFO - 2022-06-23 05:05:54 --> Database Driver Class Initialized
INFO - 2022-06-23 05:05:54 --> Email Class Initialized
DEBUG - 2022-06-23 05:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:05:54 --> Controller Class Initialized
INFO - 2022-06-23 05:05:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:05:54 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:05:54 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:05:54 --> Final output sent to browser
DEBUG - 2022-06-23 05:05:54 --> Total execution time: 0.1524
INFO - 2022-06-23 05:06:27 --> Config Class Initialized
INFO - 2022-06-23 05:06:27 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:06:27 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:06:27 --> Utf8 Class Initialized
INFO - 2022-06-23 05:06:27 --> URI Class Initialized
INFO - 2022-06-23 05:06:27 --> Router Class Initialized
INFO - 2022-06-23 05:06:27 --> Output Class Initialized
INFO - 2022-06-23 05:06:27 --> Security Class Initialized
DEBUG - 2022-06-23 05:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:06:27 --> Input Class Initialized
INFO - 2022-06-23 05:06:27 --> Language Class Initialized
INFO - 2022-06-23 05:06:27 --> Loader Class Initialized
INFO - 2022-06-23 05:06:27 --> Helper loaded: url_helper
INFO - 2022-06-23 05:06:27 --> Helper loaded: file_helper
INFO - 2022-06-23 05:06:27 --> Database Driver Class Initialized
INFO - 2022-06-23 05:06:27 --> Email Class Initialized
DEBUG - 2022-06-23 05:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:06:27 --> Controller Class Initialized
INFO - 2022-06-23 05:06:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:06:27 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:06:27 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:06:27 --> Final output sent to browser
DEBUG - 2022-06-23 05:06:27 --> Total execution time: 0.3354
INFO - 2022-06-23 05:08:26 --> Config Class Initialized
INFO - 2022-06-23 05:08:26 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:08:26 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:08:26 --> Utf8 Class Initialized
INFO - 2022-06-23 05:08:26 --> URI Class Initialized
INFO - 2022-06-23 05:08:26 --> Router Class Initialized
INFO - 2022-06-23 05:08:26 --> Output Class Initialized
INFO - 2022-06-23 05:08:26 --> Security Class Initialized
DEBUG - 2022-06-23 05:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:08:26 --> Input Class Initialized
INFO - 2022-06-23 05:08:26 --> Language Class Initialized
INFO - 2022-06-23 05:08:26 --> Loader Class Initialized
INFO - 2022-06-23 05:08:26 --> Helper loaded: url_helper
INFO - 2022-06-23 05:08:26 --> Helper loaded: file_helper
INFO - 2022-06-23 05:08:26 --> Database Driver Class Initialized
INFO - 2022-06-23 05:08:26 --> Email Class Initialized
DEBUG - 2022-06-23 05:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:08:26 --> Controller Class Initialized
INFO - 2022-06-23 05:08:26 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:08:26 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:08:26 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:08:26 --> Final output sent to browser
DEBUG - 2022-06-23 05:08:26 --> Total execution time: 0.0444
INFO - 2022-06-23 05:10:01 --> Config Class Initialized
INFO - 2022-06-23 05:10:01 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:10:01 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:10:01 --> Utf8 Class Initialized
INFO - 2022-06-23 05:10:01 --> URI Class Initialized
INFO - 2022-06-23 05:10:01 --> Router Class Initialized
INFO - 2022-06-23 05:10:01 --> Output Class Initialized
INFO - 2022-06-23 05:10:01 --> Security Class Initialized
DEBUG - 2022-06-23 05:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:10:01 --> Input Class Initialized
INFO - 2022-06-23 05:10:01 --> Language Class Initialized
INFO - 2022-06-23 05:10:01 --> Loader Class Initialized
INFO - 2022-06-23 05:10:01 --> Helper loaded: url_helper
INFO - 2022-06-23 05:10:01 --> Helper loaded: file_helper
INFO - 2022-06-23 05:10:01 --> Database Driver Class Initialized
INFO - 2022-06-23 05:10:01 --> Email Class Initialized
DEBUG - 2022-06-23 05:10:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:10:01 --> Controller Class Initialized
INFO - 2022-06-23 05:10:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:10:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:10:01 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:10:01 --> Final output sent to browser
DEBUG - 2022-06-23 05:10:01 --> Total execution time: 0.2001
INFO - 2022-06-23 05:10:05 --> Config Class Initialized
INFO - 2022-06-23 05:10:05 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:10:05 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:10:05 --> Utf8 Class Initialized
INFO - 2022-06-23 05:10:05 --> URI Class Initialized
INFO - 2022-06-23 05:10:05 --> Router Class Initialized
INFO - 2022-06-23 05:10:05 --> Output Class Initialized
INFO - 2022-06-23 05:10:05 --> Security Class Initialized
DEBUG - 2022-06-23 05:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:10:05 --> Input Class Initialized
INFO - 2022-06-23 05:10:05 --> Language Class Initialized
INFO - 2022-06-23 05:10:05 --> Loader Class Initialized
INFO - 2022-06-23 05:10:05 --> Helper loaded: url_helper
INFO - 2022-06-23 05:10:05 --> Helper loaded: file_helper
INFO - 2022-06-23 05:10:05 --> Database Driver Class Initialized
INFO - 2022-06-23 05:10:05 --> Email Class Initialized
DEBUG - 2022-06-23 05:10:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:10:05 --> Controller Class Initialized
INFO - 2022-06-23 05:10:05 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:10:05 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:10:05 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:10:05 --> Final output sent to browser
DEBUG - 2022-06-23 05:10:05 --> Total execution time: 0.0844
INFO - 2022-06-23 05:10:21 --> Config Class Initialized
INFO - 2022-06-23 05:10:21 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:10:21 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:10:21 --> Utf8 Class Initialized
INFO - 2022-06-23 05:10:21 --> URI Class Initialized
INFO - 2022-06-23 05:10:21 --> Router Class Initialized
INFO - 2022-06-23 05:10:21 --> Output Class Initialized
INFO - 2022-06-23 05:10:21 --> Security Class Initialized
DEBUG - 2022-06-23 05:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:10:21 --> Input Class Initialized
INFO - 2022-06-23 05:10:21 --> Language Class Initialized
INFO - 2022-06-23 05:10:21 --> Loader Class Initialized
INFO - 2022-06-23 05:10:21 --> Helper loaded: url_helper
INFO - 2022-06-23 05:10:21 --> Helper loaded: file_helper
INFO - 2022-06-23 05:10:21 --> Database Driver Class Initialized
INFO - 2022-06-23 05:10:21 --> Email Class Initialized
DEBUG - 2022-06-23 05:10:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:10:21 --> Controller Class Initialized
INFO - 2022-06-23 05:10:21 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:10:21 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:10:21 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:10:21 --> Final output sent to browser
DEBUG - 2022-06-23 05:10:21 --> Total execution time: 0.1764
INFO - 2022-06-23 05:14:22 --> Config Class Initialized
INFO - 2022-06-23 05:14:22 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:14:22 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:14:22 --> Utf8 Class Initialized
INFO - 2022-06-23 05:14:22 --> URI Class Initialized
INFO - 2022-06-23 05:14:22 --> Router Class Initialized
INFO - 2022-06-23 05:14:22 --> Output Class Initialized
INFO - 2022-06-23 05:14:22 --> Security Class Initialized
DEBUG - 2022-06-23 05:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:14:22 --> Input Class Initialized
INFO - 2022-06-23 05:14:22 --> Language Class Initialized
INFO - 2022-06-23 05:14:23 --> Loader Class Initialized
INFO - 2022-06-23 05:14:23 --> Helper loaded: url_helper
INFO - 2022-06-23 05:14:23 --> Helper loaded: file_helper
INFO - 2022-06-23 05:14:23 --> Database Driver Class Initialized
INFO - 2022-06-23 05:14:23 --> Email Class Initialized
DEBUG - 2022-06-23 05:14:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:14:23 --> Controller Class Initialized
INFO - 2022-06-23 05:14:23 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:14:23 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:14:23 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:14:23 --> Final output sent to browser
DEBUG - 2022-06-23 05:14:23 --> Total execution time: 0.1277
INFO - 2022-06-23 05:14:29 --> Config Class Initialized
INFO - 2022-06-23 05:14:29 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:14:29 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:14:29 --> Utf8 Class Initialized
INFO - 2022-06-23 05:14:29 --> URI Class Initialized
INFO - 2022-06-23 05:14:29 --> Router Class Initialized
INFO - 2022-06-23 05:14:29 --> Output Class Initialized
INFO - 2022-06-23 05:14:29 --> Security Class Initialized
DEBUG - 2022-06-23 05:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:14:29 --> Input Class Initialized
INFO - 2022-06-23 05:14:29 --> Language Class Initialized
INFO - 2022-06-23 05:14:29 --> Loader Class Initialized
INFO - 2022-06-23 05:14:29 --> Helper loaded: url_helper
INFO - 2022-06-23 05:14:29 --> Helper loaded: file_helper
INFO - 2022-06-23 05:14:29 --> Database Driver Class Initialized
INFO - 2022-06-23 05:14:29 --> Email Class Initialized
DEBUG - 2022-06-23 05:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:14:29 --> Controller Class Initialized
INFO - 2022-06-23 05:14:29 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:14:29 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:14:29 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:14:29 --> Final output sent to browser
DEBUG - 2022-06-23 05:14:29 --> Total execution time: 0.0501
INFO - 2022-06-23 05:14:41 --> Config Class Initialized
INFO - 2022-06-23 05:14:41 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:14:41 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:14:41 --> Utf8 Class Initialized
INFO - 2022-06-23 05:14:41 --> URI Class Initialized
INFO - 2022-06-23 05:14:41 --> Router Class Initialized
INFO - 2022-06-23 05:14:41 --> Output Class Initialized
INFO - 2022-06-23 05:14:41 --> Security Class Initialized
DEBUG - 2022-06-23 05:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:14:41 --> Input Class Initialized
INFO - 2022-06-23 05:14:41 --> Language Class Initialized
INFO - 2022-06-23 05:14:41 --> Loader Class Initialized
INFO - 2022-06-23 05:14:41 --> Helper loaded: url_helper
INFO - 2022-06-23 05:14:41 --> Helper loaded: file_helper
INFO - 2022-06-23 05:14:41 --> Database Driver Class Initialized
INFO - 2022-06-23 05:14:41 --> Email Class Initialized
DEBUG - 2022-06-23 05:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:14:41 --> Controller Class Initialized
INFO - 2022-06-23 05:14:41 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:14:41 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:14:41 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:14:41 --> Final output sent to browser
DEBUG - 2022-06-23 05:14:41 --> Total execution time: 0.0293
INFO - 2022-06-23 05:15:44 --> Config Class Initialized
INFO - 2022-06-23 05:15:44 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:15:44 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:15:44 --> Utf8 Class Initialized
INFO - 2022-06-23 05:15:44 --> URI Class Initialized
INFO - 2022-06-23 05:15:44 --> Router Class Initialized
INFO - 2022-06-23 05:15:44 --> Output Class Initialized
INFO - 2022-06-23 05:15:44 --> Security Class Initialized
DEBUG - 2022-06-23 05:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:15:44 --> Input Class Initialized
INFO - 2022-06-23 05:15:44 --> Language Class Initialized
INFO - 2022-06-23 05:15:44 --> Loader Class Initialized
INFO - 2022-06-23 05:15:44 --> Helper loaded: url_helper
INFO - 2022-06-23 05:15:44 --> Helper loaded: file_helper
INFO - 2022-06-23 05:15:44 --> Database Driver Class Initialized
INFO - 2022-06-23 05:15:44 --> Email Class Initialized
DEBUG - 2022-06-23 05:15:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:15:44 --> Controller Class Initialized
INFO - 2022-06-23 05:15:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:15:44 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:15:44 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:15:44 --> Final output sent to browser
DEBUG - 2022-06-23 05:15:44 --> Total execution time: 0.2924
INFO - 2022-06-23 05:15:57 --> Config Class Initialized
INFO - 2022-06-23 05:15:57 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:15:57 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:15:57 --> Utf8 Class Initialized
INFO - 2022-06-23 05:15:57 --> URI Class Initialized
INFO - 2022-06-23 05:15:57 --> Router Class Initialized
INFO - 2022-06-23 05:15:57 --> Output Class Initialized
INFO - 2022-06-23 05:15:57 --> Security Class Initialized
DEBUG - 2022-06-23 05:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:15:57 --> Input Class Initialized
INFO - 2022-06-23 05:15:57 --> Language Class Initialized
INFO - 2022-06-23 05:15:57 --> Loader Class Initialized
INFO - 2022-06-23 05:15:57 --> Helper loaded: url_helper
INFO - 2022-06-23 05:15:57 --> Helper loaded: file_helper
INFO - 2022-06-23 05:15:57 --> Database Driver Class Initialized
INFO - 2022-06-23 05:15:57 --> Email Class Initialized
DEBUG - 2022-06-23 05:15:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:15:57 --> Controller Class Initialized
INFO - 2022-06-23 05:15:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:15:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:15:57 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:15:57 --> Final output sent to browser
DEBUG - 2022-06-23 05:15:57 --> Total execution time: 0.0392
INFO - 2022-06-23 05:15:57 --> Config Class Initialized
INFO - 2022-06-23 05:15:57 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:15:57 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:15:57 --> Utf8 Class Initialized
INFO - 2022-06-23 05:15:57 --> URI Class Initialized
INFO - 2022-06-23 05:15:57 --> Router Class Initialized
INFO - 2022-06-23 05:15:57 --> Output Class Initialized
INFO - 2022-06-23 05:15:57 --> Security Class Initialized
DEBUG - 2022-06-23 05:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:15:57 --> Input Class Initialized
INFO - 2022-06-23 05:15:57 --> Language Class Initialized
INFO - 2022-06-23 05:15:57 --> Loader Class Initialized
INFO - 2022-06-23 05:15:57 --> Helper loaded: url_helper
INFO - 2022-06-23 05:15:57 --> Helper loaded: file_helper
INFO - 2022-06-23 05:15:57 --> Database Driver Class Initialized
INFO - 2022-06-23 05:15:57 --> Email Class Initialized
DEBUG - 2022-06-23 05:15:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:15:57 --> Controller Class Initialized
INFO - 2022-06-23 05:15:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:15:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:15:58 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:15:58 --> Final output sent to browser
DEBUG - 2022-06-23 05:15:58 --> Total execution time: 0.1829
INFO - 2022-06-23 05:17:14 --> Config Class Initialized
INFO - 2022-06-23 05:17:14 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:17:14 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:17:14 --> Utf8 Class Initialized
INFO - 2022-06-23 05:17:14 --> URI Class Initialized
INFO - 2022-06-23 05:17:14 --> Router Class Initialized
INFO - 2022-06-23 05:17:14 --> Output Class Initialized
INFO - 2022-06-23 05:17:14 --> Security Class Initialized
DEBUG - 2022-06-23 05:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:17:14 --> Input Class Initialized
INFO - 2022-06-23 05:17:14 --> Language Class Initialized
INFO - 2022-06-23 05:17:14 --> Loader Class Initialized
INFO - 2022-06-23 05:17:14 --> Helper loaded: url_helper
INFO - 2022-06-23 05:17:14 --> Helper loaded: file_helper
INFO - 2022-06-23 05:17:14 --> Database Driver Class Initialized
INFO - 2022-06-23 05:17:14 --> Email Class Initialized
DEBUG - 2022-06-23 05:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:17:14 --> Controller Class Initialized
INFO - 2022-06-23 05:17:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:17:14 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:17:15 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:17:15 --> Final output sent to browser
DEBUG - 2022-06-23 05:17:15 --> Total execution time: 0.5351
INFO - 2022-06-23 05:17:28 --> Config Class Initialized
INFO - 2022-06-23 05:17:28 --> Config Class Initialized
INFO - 2022-06-23 05:17:28 --> Hooks Class Initialized
INFO - 2022-06-23 05:17:28 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:17:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:17:28 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:17:28 --> Utf8 Class Initialized
INFO - 2022-06-23 05:17:28 --> Utf8 Class Initialized
INFO - 2022-06-23 05:17:28 --> URI Class Initialized
INFO - 2022-06-23 05:17:28 --> URI Class Initialized
INFO - 2022-06-23 05:17:28 --> Router Class Initialized
INFO - 2022-06-23 05:17:28 --> Router Class Initialized
INFO - 2022-06-23 05:17:28 --> Output Class Initialized
INFO - 2022-06-23 05:17:28 --> Output Class Initialized
INFO - 2022-06-23 05:17:28 --> Security Class Initialized
INFO - 2022-06-23 05:17:28 --> Security Class Initialized
DEBUG - 2022-06-23 05:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:17:28 --> Input Class Initialized
INFO - 2022-06-23 05:17:28 --> Input Class Initialized
INFO - 2022-06-23 05:17:28 --> Language Class Initialized
INFO - 2022-06-23 05:17:28 --> Language Class Initialized
INFO - 2022-06-23 05:17:28 --> Loader Class Initialized
INFO - 2022-06-23 05:17:28 --> Loader Class Initialized
INFO - 2022-06-23 05:17:28 --> Helper loaded: url_helper
INFO - 2022-06-23 05:17:28 --> Helper loaded: url_helper
INFO - 2022-06-23 05:17:28 --> Helper loaded: file_helper
INFO - 2022-06-23 05:17:28 --> Helper loaded: file_helper
INFO - 2022-06-23 05:17:28 --> Database Driver Class Initialized
INFO - 2022-06-23 05:17:28 --> Database Driver Class Initialized
INFO - 2022-06-23 05:17:28 --> Email Class Initialized
DEBUG - 2022-06-23 05:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:17:28 --> Controller Class Initialized
INFO - 2022-06-23 05:17:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:17:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:17:28 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:17:28 --> Final output sent to browser
DEBUG - 2022-06-23 05:17:28 --> Total execution time: 0.3671
INFO - 2022-06-23 05:17:28 --> Email Class Initialized
DEBUG - 2022-06-23 05:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:17:28 --> Controller Class Initialized
INFO - 2022-06-23 05:17:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:17:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:17:28 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:17:28 --> Final output sent to browser
DEBUG - 2022-06-23 05:17:28 --> Total execution time: 0.4385
INFO - 2022-06-23 05:17:43 --> Config Class Initialized
INFO - 2022-06-23 05:17:43 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:17:44 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:17:44 --> Utf8 Class Initialized
INFO - 2022-06-23 05:17:44 --> URI Class Initialized
INFO - 2022-06-23 05:17:44 --> Router Class Initialized
INFO - 2022-06-23 05:17:44 --> Output Class Initialized
INFO - 2022-06-23 05:17:44 --> Security Class Initialized
DEBUG - 2022-06-23 05:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:17:44 --> Input Class Initialized
INFO - 2022-06-23 05:17:44 --> Language Class Initialized
INFO - 2022-06-23 05:17:44 --> Loader Class Initialized
INFO - 2022-06-23 05:17:44 --> Helper loaded: url_helper
INFO - 2022-06-23 05:17:44 --> Helper loaded: file_helper
INFO - 2022-06-23 05:17:44 --> Database Driver Class Initialized
INFO - 2022-06-23 05:17:44 --> Email Class Initialized
DEBUG - 2022-06-23 05:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:17:44 --> Controller Class Initialized
INFO - 2022-06-23 05:17:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:17:44 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:17:44 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:17:44 --> Final output sent to browser
DEBUG - 2022-06-23 05:17:44 --> Total execution time: 0.0500
INFO - 2022-06-23 05:18:28 --> Config Class Initialized
INFO - 2022-06-23 05:18:28 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:18:28 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:18:28 --> Utf8 Class Initialized
INFO - 2022-06-23 05:18:28 --> URI Class Initialized
INFO - 2022-06-23 05:18:29 --> Router Class Initialized
INFO - 2022-06-23 05:18:29 --> Output Class Initialized
INFO - 2022-06-23 05:18:29 --> Security Class Initialized
DEBUG - 2022-06-23 05:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:18:29 --> Input Class Initialized
INFO - 2022-06-23 05:18:29 --> Language Class Initialized
INFO - 2022-06-23 05:18:29 --> Loader Class Initialized
INFO - 2022-06-23 05:18:29 --> Helper loaded: url_helper
INFO - 2022-06-23 05:18:29 --> Helper loaded: file_helper
INFO - 2022-06-23 05:18:29 --> Database Driver Class Initialized
INFO - 2022-06-23 05:18:29 --> Email Class Initialized
DEBUG - 2022-06-23 05:18:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:18:29 --> Controller Class Initialized
INFO - 2022-06-23 05:18:29 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:18:29 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:18:29 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
ERROR - 2022-06-23 05:18:29 --> Severity: Warning --> Use of undefined constant ud_eotp - assumed 'ud_eotp' (this will throw an Error in a future version of PHP) C:\wamp64\www\qr\application\controllers\Tokenctrl.php 38
ERROR - 2022-06-23 05:18:29 --> Severity: Warning --> Use of undefined constant ud_otp - assumed 'ud_otp' (this will throw an Error in a future version of PHP) C:\wamp64\www\qr\application\controllers\Tokenctrl.php 38
ERROR - 2022-06-23 05:18:29 --> Severity: error --> Exception: Call to undefined function alert() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 44
INFO - 2022-06-23 05:18:33 --> Config Class Initialized
INFO - 2022-06-23 05:18:33 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:18:33 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:18:33 --> Utf8 Class Initialized
INFO - 2022-06-23 05:18:33 --> URI Class Initialized
INFO - 2022-06-23 05:18:33 --> Router Class Initialized
INFO - 2022-06-23 05:18:33 --> Output Class Initialized
INFO - 2022-06-23 05:18:33 --> Security Class Initialized
DEBUG - 2022-06-23 05:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:18:33 --> Input Class Initialized
INFO - 2022-06-23 05:18:33 --> Language Class Initialized
INFO - 2022-06-23 05:18:33 --> Loader Class Initialized
INFO - 2022-06-23 05:18:33 --> Helper loaded: url_helper
INFO - 2022-06-23 05:18:33 --> Helper loaded: file_helper
INFO - 2022-06-23 05:18:33 --> Database Driver Class Initialized
INFO - 2022-06-23 05:18:33 --> Email Class Initialized
DEBUG - 2022-06-23 05:18:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:18:33 --> Controller Class Initialized
INFO - 2022-06-23 05:18:33 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:18:33 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:18:33 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
ERROR - 2022-06-23 05:18:33 --> Severity: Warning --> Use of undefined constant ud_eotp - assumed 'ud_eotp' (this will throw an Error in a future version of PHP) C:\wamp64\www\qr\application\controllers\Tokenctrl.php 38
ERROR - 2022-06-23 05:18:33 --> Severity: Warning --> Use of undefined constant ud_otp - assumed 'ud_otp' (this will throw an Error in a future version of PHP) C:\wamp64\www\qr\application\controllers\Tokenctrl.php 38
ERROR - 2022-06-23 05:18:33 --> Severity: error --> Exception: Call to undefined function alert() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 44
INFO - 2022-06-23 05:19:17 --> Config Class Initialized
INFO - 2022-06-23 05:19:17 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:19:17 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:19:17 --> Utf8 Class Initialized
INFO - 2022-06-23 05:19:17 --> URI Class Initialized
INFO - 2022-06-23 05:19:17 --> Router Class Initialized
INFO - 2022-06-23 05:19:17 --> Output Class Initialized
INFO - 2022-06-23 05:19:17 --> Security Class Initialized
DEBUG - 2022-06-23 05:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:19:17 --> Input Class Initialized
INFO - 2022-06-23 05:19:17 --> Language Class Initialized
INFO - 2022-06-23 05:19:17 --> Loader Class Initialized
INFO - 2022-06-23 05:19:17 --> Helper loaded: url_helper
INFO - 2022-06-23 05:19:17 --> Helper loaded: file_helper
INFO - 2022-06-23 05:19:17 --> Database Driver Class Initialized
INFO - 2022-06-23 05:19:17 --> Email Class Initialized
DEBUG - 2022-06-23 05:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:19:17 --> Controller Class Initialized
INFO - 2022-06-23 05:19:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:19:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:19:17 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
ERROR - 2022-06-23 05:19:17 --> Severity: Notice --> Undefined variable: ud_eotp C:\wamp64\www\qr\application\controllers\Tokenctrl.php 38
ERROR - 2022-06-23 05:19:17 --> Severity: Notice --> Undefined variable: ud_otp C:\wamp64\www\qr\application\controllers\Tokenctrl.php 38
ERROR - 2022-06-23 05:19:17 --> Severity: error --> Exception: Call to undefined function alert() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 40
INFO - 2022-06-23 05:20:24 --> Config Class Initialized
INFO - 2022-06-23 05:20:24 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:20:24 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:20:24 --> Utf8 Class Initialized
INFO - 2022-06-23 05:20:24 --> URI Class Initialized
INFO - 2022-06-23 05:20:24 --> Router Class Initialized
INFO - 2022-06-23 05:20:24 --> Output Class Initialized
INFO - 2022-06-23 05:20:24 --> Security Class Initialized
DEBUG - 2022-06-23 05:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:20:24 --> Input Class Initialized
INFO - 2022-06-23 05:20:24 --> Language Class Initialized
INFO - 2022-06-23 05:20:24 --> Loader Class Initialized
INFO - 2022-06-23 05:20:24 --> Helper loaded: url_helper
INFO - 2022-06-23 05:20:24 --> Helper loaded: file_helper
INFO - 2022-06-23 05:20:24 --> Database Driver Class Initialized
INFO - 2022-06-23 05:20:24 --> Email Class Initialized
DEBUG - 2022-06-23 05:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:20:24 --> Controller Class Initialized
INFO - 2022-06-23 05:20:24 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:20:24 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:20:24 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
ERROR - 2022-06-23 05:20:24 --> Severity: error --> Exception: Call to undefined function alert() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 40
INFO - 2022-06-23 05:20:29 --> Config Class Initialized
INFO - 2022-06-23 05:20:29 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:20:29 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:20:29 --> Utf8 Class Initialized
INFO - 2022-06-23 05:20:29 --> URI Class Initialized
INFO - 2022-06-23 05:20:29 --> Router Class Initialized
INFO - 2022-06-23 05:20:29 --> Output Class Initialized
INFO - 2022-06-23 05:20:29 --> Security Class Initialized
DEBUG - 2022-06-23 05:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:20:29 --> Input Class Initialized
INFO - 2022-06-23 05:20:29 --> Language Class Initialized
INFO - 2022-06-23 05:20:29 --> Loader Class Initialized
INFO - 2022-06-23 05:20:29 --> Helper loaded: url_helper
INFO - 2022-06-23 05:20:29 --> Helper loaded: file_helper
INFO - 2022-06-23 05:20:29 --> Database Driver Class Initialized
INFO - 2022-06-23 05:20:29 --> Email Class Initialized
DEBUG - 2022-06-23 05:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:20:29 --> Controller Class Initialized
INFO - 2022-06-23 05:20:29 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:20:29 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:20:29 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
ERROR - 2022-06-23 05:20:29 --> Severity: error --> Exception: Call to undefined function alert() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 40
INFO - 2022-06-23 05:20:36 --> Config Class Initialized
INFO - 2022-06-23 05:20:36 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:20:36 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:20:36 --> Utf8 Class Initialized
INFO - 2022-06-23 05:20:36 --> URI Class Initialized
INFO - 2022-06-23 05:20:36 --> Router Class Initialized
INFO - 2022-06-23 05:20:36 --> Output Class Initialized
INFO - 2022-06-23 05:20:36 --> Security Class Initialized
DEBUG - 2022-06-23 05:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:20:36 --> Input Class Initialized
INFO - 2022-06-23 05:20:36 --> Language Class Initialized
INFO - 2022-06-23 05:20:36 --> Loader Class Initialized
INFO - 2022-06-23 05:20:36 --> Helper loaded: url_helper
INFO - 2022-06-23 05:20:36 --> Helper loaded: file_helper
INFO - 2022-06-23 05:20:36 --> Database Driver Class Initialized
INFO - 2022-06-23 05:20:36 --> Email Class Initialized
DEBUG - 2022-06-23 05:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:20:36 --> Controller Class Initialized
INFO - 2022-06-23 05:20:36 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:20:36 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:20:36 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
ERROR - 2022-06-23 05:20:36 --> Severity: error --> Exception: Call to undefined function alert() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 40
INFO - 2022-06-23 05:21:32 --> Config Class Initialized
INFO - 2022-06-23 05:21:32 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:21:32 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:21:32 --> Utf8 Class Initialized
INFO - 2022-06-23 05:21:32 --> URI Class Initialized
INFO - 2022-06-23 05:21:32 --> Router Class Initialized
INFO - 2022-06-23 05:21:32 --> Output Class Initialized
INFO - 2022-06-23 05:21:32 --> Security Class Initialized
DEBUG - 2022-06-23 05:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:21:32 --> Input Class Initialized
INFO - 2022-06-23 05:21:32 --> Language Class Initialized
INFO - 2022-06-23 05:21:32 --> Loader Class Initialized
INFO - 2022-06-23 05:21:32 --> Helper loaded: url_helper
INFO - 2022-06-23 05:21:32 --> Helper loaded: file_helper
INFO - 2022-06-23 05:21:32 --> Database Driver Class Initialized
INFO - 2022-06-23 05:21:32 --> Email Class Initialized
DEBUG - 2022-06-23 05:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:21:32 --> Controller Class Initialized
INFO - 2022-06-23 05:21:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:21:32 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:21:32 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:21:32 --> Final output sent to browser
DEBUG - 2022-06-23 05:21:32 --> Total execution time: 0.0304
INFO - 2022-06-23 05:21:39 --> Config Class Initialized
INFO - 2022-06-23 05:21:39 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:21:39 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:21:39 --> Utf8 Class Initialized
INFO - 2022-06-23 05:21:39 --> URI Class Initialized
INFO - 2022-06-23 05:21:39 --> Router Class Initialized
INFO - 2022-06-23 05:21:39 --> Output Class Initialized
INFO - 2022-06-23 05:21:39 --> Security Class Initialized
DEBUG - 2022-06-23 05:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:21:39 --> Input Class Initialized
INFO - 2022-06-23 05:21:39 --> Language Class Initialized
INFO - 2022-06-23 05:21:39 --> Loader Class Initialized
INFO - 2022-06-23 05:21:39 --> Helper loaded: url_helper
INFO - 2022-06-23 05:21:39 --> Helper loaded: file_helper
INFO - 2022-06-23 05:21:39 --> Database Driver Class Initialized
INFO - 2022-06-23 05:21:39 --> Email Class Initialized
DEBUG - 2022-06-23 05:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:21:39 --> Controller Class Initialized
INFO - 2022-06-23 05:21:39 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:21:39 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:21:39 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:21:39 --> Final output sent to browser
DEBUG - 2022-06-23 05:21:39 --> Total execution time: 0.1087
INFO - 2022-06-23 05:21:52 --> Config Class Initialized
INFO - 2022-06-23 05:21:52 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:21:52 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:21:52 --> Utf8 Class Initialized
INFO - 2022-06-23 05:21:52 --> URI Class Initialized
INFO - 2022-06-23 05:21:52 --> Config Class Initialized
INFO - 2022-06-23 05:21:52 --> Hooks Class Initialized
INFO - 2022-06-23 05:21:52 --> Router Class Initialized
DEBUG - 2022-06-23 05:21:52 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:21:52 --> Output Class Initialized
INFO - 2022-06-23 05:21:52 --> Utf8 Class Initialized
INFO - 2022-06-23 05:21:52 --> URI Class Initialized
INFO - 2022-06-23 05:21:52 --> Security Class Initialized
DEBUG - 2022-06-23 05:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:21:52 --> Router Class Initialized
INFO - 2022-06-23 05:21:52 --> Input Class Initialized
INFO - 2022-06-23 05:21:52 --> Language Class Initialized
INFO - 2022-06-23 05:21:52 --> Output Class Initialized
INFO - 2022-06-23 05:21:52 --> Security Class Initialized
INFO - 2022-06-23 05:21:52 --> Loader Class Initialized
DEBUG - 2022-06-23 05:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:21:52 --> Input Class Initialized
INFO - 2022-06-23 05:21:52 --> Helper loaded: url_helper
INFO - 2022-06-23 05:21:52 --> Language Class Initialized
INFO - 2022-06-23 05:21:52 --> Helper loaded: file_helper
INFO - 2022-06-23 05:21:52 --> Loader Class Initialized
INFO - 2022-06-23 05:21:52 --> Database Driver Class Initialized
INFO - 2022-06-23 05:21:52 --> Helper loaded: url_helper
INFO - 2022-06-23 05:21:52 --> Helper loaded: file_helper
INFO - 2022-06-23 05:21:52 --> Email Class Initialized
INFO - 2022-06-23 05:21:52 --> Database Driver Class Initialized
DEBUG - 2022-06-23 05:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:21:52 --> Email Class Initialized
INFO - 2022-06-23 05:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:21:52 --> Controller Class Initialized
INFO - 2022-06-23 05:21:52 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 05:21:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 05:21:52 --> Severity: error --> Exception: Call to undefined function alert() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 40
INFO - 2022-06-23 05:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:21:52 --> Controller Class Initialized
INFO - 2022-06-23 05:21:52 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:21:52 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:21:52 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:21:52 --> Final output sent to browser
DEBUG - 2022-06-23 05:21:52 --> Total execution time: 0.0455
INFO - 2022-06-23 05:22:25 --> Config Class Initialized
INFO - 2022-06-23 05:22:25 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:22:25 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:22:25 --> Utf8 Class Initialized
INFO - 2022-06-23 05:22:25 --> URI Class Initialized
INFO - 2022-06-23 05:22:25 --> Router Class Initialized
INFO - 2022-06-23 05:22:25 --> Output Class Initialized
INFO - 2022-06-23 05:22:25 --> Security Class Initialized
DEBUG - 2022-06-23 05:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:22:25 --> Input Class Initialized
INFO - 2022-06-23 05:22:25 --> Language Class Initialized
INFO - 2022-06-23 05:22:25 --> Loader Class Initialized
INFO - 2022-06-23 05:22:25 --> Helper loaded: url_helper
INFO - 2022-06-23 05:22:25 --> Helper loaded: file_helper
INFO - 2022-06-23 05:22:25 --> Database Driver Class Initialized
INFO - 2022-06-23 05:22:25 --> Email Class Initialized
DEBUG - 2022-06-23 05:22:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:22:25 --> Controller Class Initialized
INFO - 2022-06-23 05:22:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:22:25 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:22:25 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:22:25 --> Final output sent to browser
DEBUG - 2022-06-23 05:22:25 --> Total execution time: 0.0567
INFO - 2022-06-23 05:22:35 --> Config Class Initialized
INFO - 2022-06-23 05:22:35 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:22:35 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:22:35 --> Utf8 Class Initialized
INFO - 2022-06-23 05:22:35 --> Config Class Initialized
INFO - 2022-06-23 05:22:35 --> URI Class Initialized
INFO - 2022-06-23 05:22:35 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:22:35 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:22:35 --> Router Class Initialized
INFO - 2022-06-23 05:22:35 --> Utf8 Class Initialized
INFO - 2022-06-23 05:22:35 --> Output Class Initialized
INFO - 2022-06-23 05:22:35 --> URI Class Initialized
INFO - 2022-06-23 05:22:35 --> Security Class Initialized
INFO - 2022-06-23 05:22:35 --> Router Class Initialized
INFO - 2022-06-23 05:22:35 --> Output Class Initialized
DEBUG - 2022-06-23 05:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:22:35 --> Input Class Initialized
INFO - 2022-06-23 05:22:35 --> Security Class Initialized
INFO - 2022-06-23 05:22:35 --> Language Class Initialized
DEBUG - 2022-06-23 05:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:22:35 --> Input Class Initialized
INFO - 2022-06-23 05:22:35 --> Loader Class Initialized
INFO - 2022-06-23 05:22:35 --> Language Class Initialized
INFO - 2022-06-23 05:22:35 --> Helper loaded: url_helper
INFO - 2022-06-23 05:22:35 --> Loader Class Initialized
INFO - 2022-06-23 05:22:35 --> Helper loaded: file_helper
INFO - 2022-06-23 05:22:35 --> Helper loaded: url_helper
INFO - 2022-06-23 05:22:35 --> Database Driver Class Initialized
INFO - 2022-06-23 05:22:35 --> Helper loaded: file_helper
INFO - 2022-06-23 05:22:35 --> Database Driver Class Initialized
INFO - 2022-06-23 05:22:35 --> Email Class Initialized
DEBUG - 2022-06-23 05:22:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:22:35 --> Controller Class Initialized
INFO - 2022-06-23 05:22:35 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:22:35 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:22:35 --> Final output sent to browser
DEBUG - 2022-06-23 05:22:35 --> Total execution time: 0.4053
INFO - 2022-06-23 05:22:35 --> Email Class Initialized
DEBUG - 2022-06-23 05:22:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:22:35 --> Controller Class Initialized
INFO - 2022-06-23 05:22:35 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:22:35 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:22:35 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:22:35 --> Final output sent to browser
DEBUG - 2022-06-23 05:22:35 --> Total execution time: 0.5399
INFO - 2022-06-23 05:22:48 --> Config Class Initialized
INFO - 2022-06-23 05:22:48 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:22:48 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:22:48 --> Utf8 Class Initialized
INFO - 2022-06-23 05:22:48 --> URI Class Initialized
INFO - 2022-06-23 05:22:48 --> Router Class Initialized
INFO - 2022-06-23 05:22:48 --> Output Class Initialized
INFO - 2022-06-23 05:22:48 --> Security Class Initialized
DEBUG - 2022-06-23 05:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:22:48 --> Input Class Initialized
INFO - 2022-06-23 05:22:48 --> Language Class Initialized
INFO - 2022-06-23 05:22:48 --> Loader Class Initialized
INFO - 2022-06-23 05:22:48 --> Helper loaded: url_helper
INFO - 2022-06-23 05:22:48 --> Helper loaded: file_helper
INFO - 2022-06-23 05:22:48 --> Database Driver Class Initialized
INFO - 2022-06-23 05:22:48 --> Email Class Initialized
DEBUG - 2022-06-23 05:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:22:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:22:48 --> Controller Class Initialized
INFO - 2022-06-23 05:22:48 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:22:48 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:22:48 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:22:48 --> Final output sent to browser
DEBUG - 2022-06-23 05:22:48 --> Total execution time: 0.1650
INFO - 2022-06-23 05:23:16 --> Config Class Initialized
INFO - 2022-06-23 05:23:16 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:23:16 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:23:16 --> Utf8 Class Initialized
INFO - 2022-06-23 05:23:16 --> URI Class Initialized
INFO - 2022-06-23 05:23:16 --> Router Class Initialized
INFO - 2022-06-23 05:23:16 --> Output Class Initialized
INFO - 2022-06-23 05:23:16 --> Security Class Initialized
DEBUG - 2022-06-23 05:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:23:16 --> Input Class Initialized
INFO - 2022-06-23 05:23:16 --> Language Class Initialized
INFO - 2022-06-23 05:23:16 --> Loader Class Initialized
INFO - 2022-06-23 05:23:16 --> Helper loaded: url_helper
INFO - 2022-06-23 05:23:16 --> Helper loaded: file_helper
INFO - 2022-06-23 05:23:16 --> Database Driver Class Initialized
INFO - 2022-06-23 05:23:17 --> Email Class Initialized
DEBUG - 2022-06-23 05:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:23:17 --> Controller Class Initialized
INFO - 2022-06-23 05:23:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:23:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:23:17 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:23:17 --> Final output sent to browser
DEBUG - 2022-06-23 05:23:17 --> Total execution time: 0.4074
INFO - 2022-06-23 05:23:31 --> Config Class Initialized
INFO - 2022-06-23 05:23:31 --> Config Class Initialized
INFO - 2022-06-23 05:23:31 --> Hooks Class Initialized
INFO - 2022-06-23 05:23:31 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:23:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 05:23:31 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:23:31 --> Utf8 Class Initialized
INFO - 2022-06-23 05:23:31 --> Utf8 Class Initialized
INFO - 2022-06-23 05:23:31 --> URI Class Initialized
INFO - 2022-06-23 05:23:31 --> URI Class Initialized
INFO - 2022-06-23 05:23:31 --> Router Class Initialized
INFO - 2022-06-23 05:23:31 --> Router Class Initialized
INFO - 2022-06-23 05:23:31 --> Output Class Initialized
INFO - 2022-06-23 05:23:31 --> Output Class Initialized
INFO - 2022-06-23 05:23:31 --> Security Class Initialized
INFO - 2022-06-23 05:23:31 --> Security Class Initialized
DEBUG - 2022-06-23 05:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:23:31 --> Input Class Initialized
DEBUG - 2022-06-23 05:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:23:31 --> Input Class Initialized
INFO - 2022-06-23 05:23:31 --> Language Class Initialized
INFO - 2022-06-23 05:23:31 --> Language Class Initialized
INFO - 2022-06-23 05:23:31 --> Loader Class Initialized
INFO - 2022-06-23 05:23:31 --> Loader Class Initialized
INFO - 2022-06-23 05:23:31 --> Helper loaded: url_helper
INFO - 2022-06-23 05:23:31 --> Helper loaded: url_helper
INFO - 2022-06-23 05:23:31 --> Helper loaded: file_helper
INFO - 2022-06-23 05:23:31 --> Helper loaded: file_helper
INFO - 2022-06-23 05:23:31 --> Database Driver Class Initialized
INFO - 2022-06-23 05:23:31 --> Database Driver Class Initialized
INFO - 2022-06-23 05:23:31 --> Email Class Initialized
INFO - 2022-06-23 05:23:31 --> Email Class Initialized
DEBUG - 2022-06-23 05:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 05:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:23:31 --> Controller Class Initialized
INFO - 2022-06-23 05:23:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:23:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:23:31 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:23:31 --> Final output sent to browser
DEBUG - 2022-06-23 05:23:31 --> Total execution time: 0.0406
INFO - 2022-06-23 05:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:23:31 --> Controller Class Initialized
INFO - 2022-06-23 05:23:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:23:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:23:31 --> Final output sent to browser
DEBUG - 2022-06-23 05:23:31 --> Total execution time: 0.0461
INFO - 2022-06-23 05:23:43 --> Config Class Initialized
INFO - 2022-06-23 05:23:43 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:23:43 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:23:43 --> Utf8 Class Initialized
INFO - 2022-06-23 05:23:43 --> URI Class Initialized
INFO - 2022-06-23 05:23:43 --> Router Class Initialized
INFO - 2022-06-23 05:23:43 --> Output Class Initialized
INFO - 2022-06-23 05:23:43 --> Security Class Initialized
DEBUG - 2022-06-23 05:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:23:43 --> Input Class Initialized
INFO - 2022-06-23 05:23:43 --> Language Class Initialized
INFO - 2022-06-23 05:23:43 --> Loader Class Initialized
INFO - 2022-06-23 05:23:43 --> Helper loaded: url_helper
INFO - 2022-06-23 05:23:43 --> Helper loaded: file_helper
INFO - 2022-06-23 05:23:43 --> Database Driver Class Initialized
INFO - 2022-06-23 05:23:43 --> Email Class Initialized
DEBUG - 2022-06-23 05:23:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:23:43 --> Controller Class Initialized
INFO - 2022-06-23 05:23:43 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:23:43 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:23:43 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:23:43 --> Final output sent to browser
DEBUG - 2022-06-23 05:23:43 --> Total execution time: 0.1750
INFO - 2022-06-23 05:25:52 --> Config Class Initialized
INFO - 2022-06-23 05:25:52 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:25:52 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:25:52 --> Utf8 Class Initialized
INFO - 2022-06-23 05:25:52 --> URI Class Initialized
INFO - 2022-06-23 05:25:52 --> Router Class Initialized
INFO - 2022-06-23 05:25:52 --> Output Class Initialized
INFO - 2022-06-23 05:25:52 --> Security Class Initialized
DEBUG - 2022-06-23 05:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:25:52 --> Input Class Initialized
INFO - 2022-06-23 05:25:52 --> Language Class Initialized
INFO - 2022-06-23 05:25:52 --> Loader Class Initialized
INFO - 2022-06-23 05:25:52 --> Helper loaded: url_helper
INFO - 2022-06-23 05:25:52 --> Helper loaded: file_helper
INFO - 2022-06-23 05:25:52 --> Database Driver Class Initialized
INFO - 2022-06-23 05:25:52 --> Email Class Initialized
DEBUG - 2022-06-23 05:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:25:52 --> Controller Class Initialized
INFO - 2022-06-23 05:25:52 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:25:52 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:25:52 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:25:52 --> Final output sent to browser
DEBUG - 2022-06-23 05:25:52 --> Total execution time: 0.2284
INFO - 2022-06-23 05:26:01 --> Config Class Initialized
INFO - 2022-06-23 05:26:01 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:26:01 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:26:01 --> Utf8 Class Initialized
INFO - 2022-06-23 05:26:01 --> URI Class Initialized
INFO - 2022-06-23 05:26:01 --> Config Class Initialized
INFO - 2022-06-23 05:26:01 --> Router Class Initialized
INFO - 2022-06-23 05:26:01 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:26:01 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:26:01 --> Output Class Initialized
INFO - 2022-06-23 05:26:01 --> Utf8 Class Initialized
INFO - 2022-06-23 05:26:01 --> Security Class Initialized
INFO - 2022-06-23 05:26:01 --> URI Class Initialized
DEBUG - 2022-06-23 05:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:26:01 --> Router Class Initialized
INFO - 2022-06-23 05:26:01 --> Input Class Initialized
INFO - 2022-06-23 05:26:01 --> Language Class Initialized
INFO - 2022-06-23 05:26:01 --> Output Class Initialized
INFO - 2022-06-23 05:26:01 --> Security Class Initialized
INFO - 2022-06-23 05:26:01 --> Loader Class Initialized
DEBUG - 2022-06-23 05:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:26:01 --> Helper loaded: url_helper
INFO - 2022-06-23 05:26:01 --> Input Class Initialized
INFO - 2022-06-23 05:26:01 --> Helper loaded: file_helper
INFO - 2022-06-23 05:26:01 --> Language Class Initialized
INFO - 2022-06-23 05:26:01 --> Loader Class Initialized
INFO - 2022-06-23 05:26:01 --> Database Driver Class Initialized
INFO - 2022-06-23 05:26:01 --> Helper loaded: url_helper
INFO - 2022-06-23 05:26:01 --> Helper loaded: file_helper
INFO - 2022-06-23 05:26:01 --> Database Driver Class Initialized
INFO - 2022-06-23 05:26:01 --> Email Class Initialized
DEBUG - 2022-06-23 05:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:26:01 --> Controller Class Initialized
INFO - 2022-06-23 05:26:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:26:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:26:01 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:26:01 --> Final output sent to browser
DEBUG - 2022-06-23 05:26:01 --> Total execution time: 0.2333
INFO - 2022-06-23 05:26:01 --> Email Class Initialized
DEBUG - 2022-06-23 05:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:26:01 --> Controller Class Initialized
INFO - 2022-06-23 05:26:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:26:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:26:01 --> Final output sent to browser
DEBUG - 2022-06-23 05:26:01 --> Total execution time: 0.3061
INFO - 2022-06-23 05:26:10 --> Config Class Initialized
INFO - 2022-06-23 05:26:10 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:26:10 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:26:10 --> Utf8 Class Initialized
INFO - 2022-06-23 05:26:10 --> Config Class Initialized
INFO - 2022-06-23 05:26:10 --> Hooks Class Initialized
INFO - 2022-06-23 05:26:10 --> URI Class Initialized
DEBUG - 2022-06-23 05:26:10 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:26:10 --> Router Class Initialized
INFO - 2022-06-23 05:26:10 --> Utf8 Class Initialized
INFO - 2022-06-23 05:26:10 --> URI Class Initialized
INFO - 2022-06-23 05:26:10 --> Output Class Initialized
INFO - 2022-06-23 05:26:10 --> Router Class Initialized
INFO - 2022-06-23 05:26:10 --> Security Class Initialized
DEBUG - 2022-06-23 05:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:26:10 --> Output Class Initialized
INFO - 2022-06-23 05:26:10 --> Input Class Initialized
INFO - 2022-06-23 05:26:10 --> Security Class Initialized
INFO - 2022-06-23 05:26:10 --> Language Class Initialized
DEBUG - 2022-06-23 05:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:26:10 --> Loader Class Initialized
INFO - 2022-06-23 05:26:10 --> Input Class Initialized
INFO - 2022-06-23 05:26:10 --> Helper loaded: url_helper
INFO - 2022-06-23 05:26:10 --> Language Class Initialized
INFO - 2022-06-23 05:26:10 --> Helper loaded: file_helper
INFO - 2022-06-23 05:26:10 --> Loader Class Initialized
INFO - 2022-06-23 05:26:10 --> Helper loaded: url_helper
INFO - 2022-06-23 05:26:10 --> Database Driver Class Initialized
INFO - 2022-06-23 05:26:10 --> Helper loaded: file_helper
INFO - 2022-06-23 05:26:10 --> Database Driver Class Initialized
INFO - 2022-06-23 05:26:10 --> Email Class Initialized
INFO - 2022-06-23 05:26:10 --> Email Class Initialized
DEBUG - 2022-06-23 05:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 05:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:26:10 --> Controller Class Initialized
INFO - 2022-06-23 05:26:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:26:10 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:26:10 --> Final output sent to browser
DEBUG - 2022-06-23 05:26:10 --> Total execution time: 0.6328
INFO - 2022-06-23 05:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:26:10 --> Controller Class Initialized
INFO - 2022-06-23 05:26:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:26:10 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:26:10 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:26:10 --> Final output sent to browser
DEBUG - 2022-06-23 05:26:10 --> Total execution time: 0.6406
INFO - 2022-06-23 05:26:50 --> Config Class Initialized
INFO - 2022-06-23 05:26:50 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:26:50 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:26:50 --> Utf8 Class Initialized
INFO - 2022-06-23 05:26:50 --> URI Class Initialized
INFO - 2022-06-23 05:26:50 --> Router Class Initialized
INFO - 2022-06-23 05:26:50 --> Output Class Initialized
INFO - 2022-06-23 05:26:50 --> Security Class Initialized
DEBUG - 2022-06-23 05:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:26:50 --> Input Class Initialized
INFO - 2022-06-23 05:26:50 --> Language Class Initialized
INFO - 2022-06-23 05:26:50 --> Loader Class Initialized
INFO - 2022-06-23 05:26:50 --> Helper loaded: url_helper
INFO - 2022-06-23 05:26:50 --> Helper loaded: file_helper
INFO - 2022-06-23 05:26:50 --> Database Driver Class Initialized
INFO - 2022-06-23 05:26:50 --> Email Class Initialized
DEBUG - 2022-06-23 05:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:26:50 --> Controller Class Initialized
INFO - 2022-06-23 05:26:50 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:26:50 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:26:50 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:26:50 --> Final output sent to browser
DEBUG - 2022-06-23 05:26:50 --> Total execution time: 0.2719
INFO - 2022-06-23 05:27:07 --> Config Class Initialized
INFO - 2022-06-23 05:27:07 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:27:07 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:27:07 --> Utf8 Class Initialized
INFO - 2022-06-23 05:27:07 --> URI Class Initialized
INFO - 2022-06-23 05:27:07 --> Router Class Initialized
INFO - 2022-06-23 05:27:07 --> Output Class Initialized
INFO - 2022-06-23 05:27:07 --> Security Class Initialized
DEBUG - 2022-06-23 05:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:27:07 --> Input Class Initialized
INFO - 2022-06-23 05:27:07 --> Language Class Initialized
INFO - 2022-06-23 05:27:07 --> Loader Class Initialized
INFO - 2022-06-23 05:27:07 --> Config Class Initialized
INFO - 2022-06-23 05:27:07 --> Hooks Class Initialized
INFO - 2022-06-23 05:27:07 --> Helper loaded: url_helper
DEBUG - 2022-06-23 05:27:07 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:27:07 --> Helper loaded: file_helper
INFO - 2022-06-23 05:27:07 --> Utf8 Class Initialized
INFO - 2022-06-23 05:27:07 --> URI Class Initialized
INFO - 2022-06-23 05:27:07 --> Database Driver Class Initialized
INFO - 2022-06-23 05:27:07 --> Router Class Initialized
INFO - 2022-06-23 05:27:07 --> Output Class Initialized
INFO - 2022-06-23 05:27:07 --> Email Class Initialized
INFO - 2022-06-23 05:27:07 --> Security Class Initialized
DEBUG - 2022-06-23 05:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:27:07 --> Input Class Initialized
INFO - 2022-06-23 05:27:07 --> Language Class Initialized
INFO - 2022-06-23 05:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:27:07 --> Controller Class Initialized
INFO - 2022-06-23 05:27:07 --> Loader Class Initialized
INFO - 2022-06-23 05:27:07 --> Model "Tokenmodel" initialized
INFO - 2022-06-23 05:27:07 --> Helper loaded: url_helper
DEBUG - 2022-06-23 05:27:07 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:27:07 --> Helper loaded: file_helper
ERROR - 2022-06-23 05:27:07 --> Severity: error --> Exception: Call to undefined function alert() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 40
INFO - 2022-06-23 05:27:07 --> Database Driver Class Initialized
INFO - 2022-06-23 05:27:07 --> Email Class Initialized
DEBUG - 2022-06-23 05:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:27:07 --> Controller Class Initialized
INFO - 2022-06-23 05:27:07 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:27:07 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:27:07 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:27:07 --> Final output sent to browser
DEBUG - 2022-06-23 05:27:07 --> Total execution time: 0.0337
INFO - 2022-06-23 05:27:23 --> Config Class Initialized
INFO - 2022-06-23 05:27:23 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:27:23 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:27:23 --> Utf8 Class Initialized
INFO - 2022-06-23 05:27:23 --> URI Class Initialized
INFO - 2022-06-23 05:27:23 --> Router Class Initialized
INFO - 2022-06-23 05:27:23 --> Config Class Initialized
INFO - 2022-06-23 05:27:23 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:27:23 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:27:23 --> Utf8 Class Initialized
INFO - 2022-06-23 05:27:23 --> Output Class Initialized
INFO - 2022-06-23 05:27:23 --> URI Class Initialized
INFO - 2022-06-23 05:27:23 --> Security Class Initialized
DEBUG - 2022-06-23 05:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:27:23 --> Router Class Initialized
INFO - 2022-06-23 05:27:23 --> Input Class Initialized
INFO - 2022-06-23 05:27:23 --> Language Class Initialized
INFO - 2022-06-23 05:27:23 --> Output Class Initialized
INFO - 2022-06-23 05:27:23 --> Security Class Initialized
INFO - 2022-06-23 05:27:23 --> Loader Class Initialized
DEBUG - 2022-06-23 05:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:27:23 --> Helper loaded: url_helper
INFO - 2022-06-23 05:27:23 --> Input Class Initialized
INFO - 2022-06-23 05:27:23 --> Language Class Initialized
INFO - 2022-06-23 05:27:23 --> Helper loaded: file_helper
INFO - 2022-06-23 05:27:23 --> Loader Class Initialized
INFO - 2022-06-23 05:27:23 --> Database Driver Class Initialized
INFO - 2022-06-23 05:27:23 --> Helper loaded: url_helper
INFO - 2022-06-23 05:27:23 --> Helper loaded: file_helper
INFO - 2022-06-23 05:27:23 --> Database Driver Class Initialized
INFO - 2022-06-23 05:27:23 --> Email Class Initialized
INFO - 2022-06-23 05:27:23 --> Email Class Initialized
DEBUG - 2022-06-23 05:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 05:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:27:23 --> Controller Class Initialized
INFO - 2022-06-23 05:27:23 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:27:23 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:27:23 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:27:23 --> Final output sent to browser
DEBUG - 2022-06-23 05:27:23 --> Total execution time: 0.3526
INFO - 2022-06-23 05:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:27:23 --> Controller Class Initialized
INFO - 2022-06-23 05:27:23 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:27:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 05:27:23 --> Severity: error --> Exception: Call to undefined function alert() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 40
INFO - 2022-06-23 05:27:37 --> Config Class Initialized
INFO - 2022-06-23 05:27:37 --> Hooks Class Initialized
INFO - 2022-06-23 05:27:37 --> Config Class Initialized
INFO - 2022-06-23 05:27:37 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:27:37 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:27:37 --> Utf8 Class Initialized
DEBUG - 2022-06-23 05:27:37 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:27:37 --> URI Class Initialized
INFO - 2022-06-23 05:27:37 --> Utf8 Class Initialized
INFO - 2022-06-23 05:27:37 --> URI Class Initialized
INFO - 2022-06-23 05:27:37 --> Router Class Initialized
INFO - 2022-06-23 05:27:37 --> Router Class Initialized
INFO - 2022-06-23 05:27:37 --> Output Class Initialized
INFO - 2022-06-23 05:27:37 --> Security Class Initialized
INFO - 2022-06-23 05:27:37 --> Output Class Initialized
DEBUG - 2022-06-23 05:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:27:37 --> Input Class Initialized
INFO - 2022-06-23 05:27:37 --> Security Class Initialized
INFO - 2022-06-23 05:27:37 --> Language Class Initialized
DEBUG - 2022-06-23 05:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:27:37 --> Input Class Initialized
INFO - 2022-06-23 05:27:37 --> Loader Class Initialized
INFO - 2022-06-23 05:27:37 --> Language Class Initialized
INFO - 2022-06-23 05:27:37 --> Loader Class Initialized
INFO - 2022-06-23 05:27:37 --> Helper loaded: url_helper
INFO - 2022-06-23 05:27:37 --> Helper loaded: file_helper
INFO - 2022-06-23 05:27:37 --> Helper loaded: url_helper
INFO - 2022-06-23 05:27:37 --> Helper loaded: file_helper
INFO - 2022-06-23 05:27:37 --> Database Driver Class Initialized
INFO - 2022-06-23 05:27:37 --> Database Driver Class Initialized
INFO - 2022-06-23 05:27:37 --> Email Class Initialized
INFO - 2022-06-23 05:27:37 --> Email Class Initialized
DEBUG - 2022-06-23 05:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 05:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:27:37 --> Controller Class Initialized
INFO - 2022-06-23 05:27:37 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:27:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 05:27:37 --> Severity: error --> Exception: Call to undefined function alert() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 40
INFO - 2022-06-23 05:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:27:37 --> Controller Class Initialized
INFO - 2022-06-23 05:27:37 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:27:37 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:27:37 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:27:37 --> Final output sent to browser
DEBUG - 2022-06-23 05:27:37 --> Total execution time: 0.0371
INFO - 2022-06-23 05:28:01 --> Config Class Initialized
INFO - 2022-06-23 05:28:01 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:28:01 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:28:01 --> Utf8 Class Initialized
INFO - 2022-06-23 05:28:01 --> URI Class Initialized
INFO - 2022-06-23 05:28:01 --> Router Class Initialized
INFO - 2022-06-23 05:28:01 --> Output Class Initialized
INFO - 2022-06-23 05:28:01 --> Security Class Initialized
DEBUG - 2022-06-23 05:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:28:01 --> Input Class Initialized
INFO - 2022-06-23 05:28:01 --> Language Class Initialized
INFO - 2022-06-23 05:28:01 --> Loader Class Initialized
INFO - 2022-06-23 05:28:01 --> Helper loaded: url_helper
INFO - 2022-06-23 05:28:01 --> Helper loaded: file_helper
INFO - 2022-06-23 05:28:01 --> Database Driver Class Initialized
INFO - 2022-06-23 05:28:01 --> Email Class Initialized
DEBUG - 2022-06-23 05:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:28:01 --> Controller Class Initialized
INFO - 2022-06-23 05:28:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:28:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:28:01 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:28:01 --> Final output sent to browser
DEBUG - 2022-06-23 05:28:01 --> Total execution time: 0.2673
INFO - 2022-06-23 05:28:09 --> Config Class Initialized
INFO - 2022-06-23 05:28:09 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:28:09 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:28:09 --> Utf8 Class Initialized
INFO - 2022-06-23 05:28:09 --> URI Class Initialized
INFO - 2022-06-23 05:28:09 --> Router Class Initialized
INFO - 2022-06-23 05:28:09 --> Output Class Initialized
INFO - 2022-06-23 05:28:09 --> Security Class Initialized
DEBUG - 2022-06-23 05:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:28:09 --> Input Class Initialized
INFO - 2022-06-23 05:28:09 --> Language Class Initialized
INFO - 2022-06-23 05:28:09 --> Loader Class Initialized
INFO - 2022-06-23 05:28:09 --> Helper loaded: url_helper
INFO - 2022-06-23 05:28:09 --> Helper loaded: file_helper
INFO - 2022-06-23 05:28:09 --> Database Driver Class Initialized
INFO - 2022-06-23 05:28:09 --> Email Class Initialized
DEBUG - 2022-06-23 05:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:28:09 --> Controller Class Initialized
INFO - 2022-06-23 05:28:09 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:28:09 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:28:09 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:28:09 --> Final output sent to browser
DEBUG - 2022-06-23 05:28:09 --> Total execution time: 0.2384
INFO - 2022-06-23 05:28:24 --> Config Class Initialized
INFO - 2022-06-23 05:28:24 --> Hooks Class Initialized
INFO - 2022-06-23 05:28:24 --> Config Class Initialized
INFO - 2022-06-23 05:28:24 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:28:24 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:28:24 --> Utf8 Class Initialized
DEBUG - 2022-06-23 05:28:24 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:28:24 --> Utf8 Class Initialized
INFO - 2022-06-23 05:28:24 --> URI Class Initialized
INFO - 2022-06-23 05:28:24 --> URI Class Initialized
INFO - 2022-06-23 05:28:24 --> Router Class Initialized
INFO - 2022-06-23 05:28:24 --> Router Class Initialized
INFO - 2022-06-23 05:28:24 --> Output Class Initialized
INFO - 2022-06-23 05:28:24 --> Output Class Initialized
INFO - 2022-06-23 05:28:24 --> Security Class Initialized
INFO - 2022-06-23 05:28:24 --> Security Class Initialized
DEBUG - 2022-06-23 05:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:28:24 --> Input Class Initialized
DEBUG - 2022-06-23 05:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:28:24 --> Input Class Initialized
INFO - 2022-06-23 05:28:24 --> Language Class Initialized
INFO - 2022-06-23 05:28:24 --> Language Class Initialized
INFO - 2022-06-23 05:28:24 --> Loader Class Initialized
INFO - 2022-06-23 05:28:24 --> Loader Class Initialized
INFO - 2022-06-23 05:28:24 --> Helper loaded: url_helper
INFO - 2022-06-23 05:28:24 --> Helper loaded: url_helper
INFO - 2022-06-23 05:28:24 --> Helper loaded: file_helper
INFO - 2022-06-23 05:28:24 --> Helper loaded: file_helper
INFO - 2022-06-23 05:28:24 --> Database Driver Class Initialized
INFO - 2022-06-23 05:28:24 --> Database Driver Class Initialized
INFO - 2022-06-23 05:28:24 --> Email Class Initialized
DEBUG - 2022-06-23 05:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:28:24 --> Controller Class Initialized
INFO - 2022-06-23 05:28:24 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:28:24 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:28:24 --> Final output sent to browser
DEBUG - 2022-06-23 05:28:24 --> Total execution time: 0.1999
INFO - 2022-06-23 05:28:24 --> Email Class Initialized
DEBUG - 2022-06-23 05:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:28:24 --> Controller Class Initialized
INFO - 2022-06-23 05:28:24 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:28:24 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:28:24 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:28:24 --> Final output sent to browser
DEBUG - 2022-06-23 05:28:24 --> Total execution time: 0.2537
INFO - 2022-06-23 05:28:36 --> Config Class Initialized
INFO - 2022-06-23 05:28:36 --> Hooks Class Initialized
INFO - 2022-06-23 05:28:36 --> Config Class Initialized
INFO - 2022-06-23 05:28:36 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:28:36 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:28:36 --> Utf8 Class Initialized
DEBUG - 2022-06-23 05:28:36 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:28:36 --> URI Class Initialized
INFO - 2022-06-23 05:28:36 --> Utf8 Class Initialized
INFO - 2022-06-23 05:28:36 --> URI Class Initialized
INFO - 2022-06-23 05:28:36 --> Router Class Initialized
INFO - 2022-06-23 05:28:36 --> Router Class Initialized
INFO - 2022-06-23 05:28:36 --> Output Class Initialized
INFO - 2022-06-23 05:28:36 --> Output Class Initialized
INFO - 2022-06-23 05:28:36 --> Security Class Initialized
INFO - 2022-06-23 05:28:36 --> Security Class Initialized
DEBUG - 2022-06-23 05:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:28:36 --> Input Class Initialized
INFO - 2022-06-23 05:28:36 --> Input Class Initialized
INFO - 2022-06-23 05:28:36 --> Language Class Initialized
INFO - 2022-06-23 05:28:36 --> Language Class Initialized
INFO - 2022-06-23 05:28:36 --> Loader Class Initialized
INFO - 2022-06-23 05:28:36 --> Loader Class Initialized
INFO - 2022-06-23 05:28:36 --> Helper loaded: url_helper
INFO - 2022-06-23 05:28:36 --> Helper loaded: url_helper
INFO - 2022-06-23 05:28:36 --> Helper loaded: file_helper
INFO - 2022-06-23 05:28:36 --> Helper loaded: file_helper
INFO - 2022-06-23 05:28:36 --> Database Driver Class Initialized
INFO - 2022-06-23 05:28:36 --> Database Driver Class Initialized
INFO - 2022-06-23 05:28:36 --> Email Class Initialized
DEBUG - 2022-06-23 05:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:28:37 --> Controller Class Initialized
INFO - 2022-06-23 05:28:37 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:28:37 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:28:37 --> Final output sent to browser
DEBUG - 2022-06-23 05:28:37 --> Total execution time: 0.0334
INFO - 2022-06-23 05:28:37 --> Email Class Initialized
DEBUG - 2022-06-23 05:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:28:37 --> Controller Class Initialized
INFO - 2022-06-23 05:28:37 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:28:37 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:28:37 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:28:37 --> Final output sent to browser
DEBUG - 2022-06-23 05:28:37 --> Total execution time: 0.3344
INFO - 2022-06-23 05:29:10 --> Config Class Initialized
INFO - 2022-06-23 05:29:10 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:29:10 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:29:10 --> Utf8 Class Initialized
INFO - 2022-06-23 05:29:10 --> URI Class Initialized
INFO - 2022-06-23 05:29:10 --> Router Class Initialized
INFO - 2022-06-23 05:29:10 --> Output Class Initialized
INFO - 2022-06-23 05:29:10 --> Security Class Initialized
DEBUG - 2022-06-23 05:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:29:10 --> Input Class Initialized
INFO - 2022-06-23 05:29:10 --> Language Class Initialized
INFO - 2022-06-23 05:29:10 --> Loader Class Initialized
INFO - 2022-06-23 05:29:10 --> Helper loaded: url_helper
INFO - 2022-06-23 05:29:10 --> Helper loaded: file_helper
INFO - 2022-06-23 05:29:10 --> Database Driver Class Initialized
INFO - 2022-06-23 05:29:10 --> Email Class Initialized
DEBUG - 2022-06-23 05:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:29:10 --> Controller Class Initialized
INFO - 2022-06-23 05:29:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:29:10 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:29:10 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:29:10 --> Final output sent to browser
DEBUG - 2022-06-23 05:29:10 --> Total execution time: 0.1557
INFO - 2022-06-23 05:29:21 --> Config Class Initialized
INFO - 2022-06-23 05:29:21 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:29:21 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:29:21 --> Config Class Initialized
INFO - 2022-06-23 05:29:21 --> Utf8 Class Initialized
INFO - 2022-06-23 05:29:21 --> Hooks Class Initialized
INFO - 2022-06-23 05:29:21 --> URI Class Initialized
DEBUG - 2022-06-23 05:29:21 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:29:21 --> Utf8 Class Initialized
INFO - 2022-06-23 05:29:21 --> Router Class Initialized
INFO - 2022-06-23 05:29:21 --> URI Class Initialized
INFO - 2022-06-23 05:29:21 --> Output Class Initialized
INFO - 2022-06-23 05:29:21 --> Router Class Initialized
INFO - 2022-06-23 05:29:21 --> Security Class Initialized
INFO - 2022-06-23 05:29:21 --> Output Class Initialized
DEBUG - 2022-06-23 05:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:29:21 --> Input Class Initialized
INFO - 2022-06-23 05:29:21 --> Security Class Initialized
INFO - 2022-06-23 05:29:21 --> Language Class Initialized
DEBUG - 2022-06-23 05:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:29:21 --> Input Class Initialized
INFO - 2022-06-23 05:29:21 --> Language Class Initialized
INFO - 2022-06-23 05:29:21 --> Loader Class Initialized
INFO - 2022-06-23 05:29:21 --> Loader Class Initialized
INFO - 2022-06-23 05:29:21 --> Helper loaded: url_helper
INFO - 2022-06-23 05:29:21 --> Helper loaded: url_helper
INFO - 2022-06-23 05:29:21 --> Helper loaded: file_helper
INFO - 2022-06-23 05:29:21 --> Helper loaded: file_helper
INFO - 2022-06-23 05:29:21 --> Database Driver Class Initialized
INFO - 2022-06-23 05:29:21 --> Database Driver Class Initialized
INFO - 2022-06-23 05:29:21 --> Email Class Initialized
INFO - 2022-06-23 05:29:21 --> Email Class Initialized
DEBUG - 2022-06-23 05:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 05:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:29:21 --> Controller Class Initialized
INFO - 2022-06-23 05:29:21 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:29:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 05:29:21 --> Severity: error --> Exception: Call to undefined function alert() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 40
INFO - 2022-06-23 05:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:29:21 --> Controller Class Initialized
INFO - 2022-06-23 05:29:21 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:29:21 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:29:21 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:29:21 --> Final output sent to browser
DEBUG - 2022-06-23 05:29:21 --> Total execution time: 0.0467
INFO - 2022-06-23 05:41:17 --> Config Class Initialized
INFO - 2022-06-23 05:41:17 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:41:17 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:41:17 --> Utf8 Class Initialized
INFO - 2022-06-23 05:41:17 --> URI Class Initialized
INFO - 2022-06-23 05:41:17 --> Router Class Initialized
INFO - 2022-06-23 05:41:17 --> Output Class Initialized
INFO - 2022-06-23 05:41:17 --> Security Class Initialized
DEBUG - 2022-06-23 05:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:41:17 --> Input Class Initialized
INFO - 2022-06-23 05:41:17 --> Language Class Initialized
INFO - 2022-06-23 05:41:17 --> Loader Class Initialized
INFO - 2022-06-23 05:41:17 --> Helper loaded: url_helper
INFO - 2022-06-23 05:41:17 --> Helper loaded: file_helper
INFO - 2022-06-23 05:41:17 --> Database Driver Class Initialized
INFO - 2022-06-23 05:41:17 --> Email Class Initialized
DEBUG - 2022-06-23 05:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:41:17 --> Controller Class Initialized
INFO - 2022-06-23 05:41:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:41:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:41:17 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:41:17 --> Final output sent to browser
DEBUG - 2022-06-23 05:41:17 --> Total execution time: 0.0866
INFO - 2022-06-23 05:41:30 --> Config Class Initialized
INFO - 2022-06-23 05:41:30 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:41:30 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:41:30 --> Utf8 Class Initialized
INFO - 2022-06-23 05:41:30 --> Config Class Initialized
INFO - 2022-06-23 05:41:30 --> URI Class Initialized
INFO - 2022-06-23 05:41:30 --> Hooks Class Initialized
INFO - 2022-06-23 05:41:30 --> Router Class Initialized
DEBUG - 2022-06-23 05:41:30 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:41:30 --> Utf8 Class Initialized
INFO - 2022-06-23 05:41:30 --> Output Class Initialized
INFO - 2022-06-23 05:41:30 --> URI Class Initialized
INFO - 2022-06-23 05:41:30 --> Security Class Initialized
DEBUG - 2022-06-23 05:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:41:30 --> Router Class Initialized
INFO - 2022-06-23 05:41:30 --> Input Class Initialized
INFO - 2022-06-23 05:41:30 --> Output Class Initialized
INFO - 2022-06-23 05:41:30 --> Language Class Initialized
INFO - 2022-06-23 05:41:30 --> Security Class Initialized
INFO - 2022-06-23 05:41:30 --> Loader Class Initialized
DEBUG - 2022-06-23 05:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:41:30 --> Input Class Initialized
INFO - 2022-06-23 05:41:30 --> Helper loaded: url_helper
INFO - 2022-06-23 05:41:30 --> Language Class Initialized
INFO - 2022-06-23 05:41:30 --> Helper loaded: file_helper
INFO - 2022-06-23 05:41:30 --> Loader Class Initialized
INFO - 2022-06-23 05:41:30 --> Database Driver Class Initialized
INFO - 2022-06-23 05:41:30 --> Helper loaded: url_helper
INFO - 2022-06-23 05:41:30 --> Helper loaded: file_helper
INFO - 2022-06-23 05:41:30 --> Database Driver Class Initialized
INFO - 2022-06-23 05:41:30 --> Email Class Initialized
DEBUG - 2022-06-23 05:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:41:30 --> Controller Class Initialized
INFO - 2022-06-23 05:41:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:41:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:41:30 --> Final output sent to browser
DEBUG - 2022-06-23 05:41:30 --> Total execution time: 0.1329
INFO - 2022-06-23 05:41:30 --> Email Class Initialized
DEBUG - 2022-06-23 05:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:41:30 --> Controller Class Initialized
INFO - 2022-06-23 05:41:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:41:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:41:30 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:41:30 --> Final output sent to browser
DEBUG - 2022-06-23 05:41:30 --> Total execution time: 0.1333
INFO - 2022-06-23 05:41:42 --> Config Class Initialized
INFO - 2022-06-23 05:41:42 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:41:42 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:41:42 --> Utf8 Class Initialized
INFO - 2022-06-23 05:41:42 --> URI Class Initialized
INFO - 2022-06-23 05:41:42 --> Config Class Initialized
INFO - 2022-06-23 05:41:42 --> Hooks Class Initialized
INFO - 2022-06-23 05:41:42 --> Router Class Initialized
DEBUG - 2022-06-23 05:41:42 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:41:42 --> Utf8 Class Initialized
INFO - 2022-06-23 05:41:42 --> Output Class Initialized
INFO - 2022-06-23 05:41:42 --> URI Class Initialized
INFO - 2022-06-23 05:41:42 --> Security Class Initialized
DEBUG - 2022-06-23 05:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:41:42 --> Router Class Initialized
INFO - 2022-06-23 05:41:42 --> Input Class Initialized
INFO - 2022-06-23 05:41:42 --> Output Class Initialized
INFO - 2022-06-23 05:41:42 --> Language Class Initialized
INFO - 2022-06-23 05:41:42 --> Security Class Initialized
INFO - 2022-06-23 05:41:42 --> Loader Class Initialized
DEBUG - 2022-06-23 05:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:41:42 --> Input Class Initialized
INFO - 2022-06-23 05:41:42 --> Helper loaded: url_helper
INFO - 2022-06-23 05:41:42 --> Language Class Initialized
INFO - 2022-06-23 05:41:42 --> Helper loaded: file_helper
INFO - 2022-06-23 05:41:42 --> Loader Class Initialized
INFO - 2022-06-23 05:41:42 --> Database Driver Class Initialized
INFO - 2022-06-23 05:41:42 --> Helper loaded: url_helper
INFO - 2022-06-23 05:41:42 --> Helper loaded: file_helper
INFO - 2022-06-23 05:41:42 --> Database Driver Class Initialized
INFO - 2022-06-23 05:41:42 --> Email Class Initialized
INFO - 2022-06-23 05:41:42 --> Email Class Initialized
DEBUG - 2022-06-23 05:41:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 05:41:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:41:42 --> Controller Class Initialized
INFO - 2022-06-23 05:41:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:41:42 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:41:42 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:41:42 --> Final output sent to browser
DEBUG - 2022-06-23 05:41:42 --> Total execution time: 0.1360
INFO - 2022-06-23 05:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:41:42 --> Controller Class Initialized
INFO - 2022-06-23 05:41:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:41:42 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:41:42 --> Final output sent to browser
DEBUG - 2022-06-23 05:41:42 --> Total execution time: 0.1576
INFO - 2022-06-23 05:41:50 --> Config Class Initialized
INFO - 2022-06-23 05:41:50 --> Hooks Class Initialized
INFO - 2022-06-23 05:41:50 --> Config Class Initialized
INFO - 2022-06-23 05:41:50 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:41:50 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:41:50 --> Utf8 Class Initialized
DEBUG - 2022-06-23 05:41:50 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:41:50 --> URI Class Initialized
INFO - 2022-06-23 05:41:50 --> Utf8 Class Initialized
INFO - 2022-06-23 05:41:50 --> URI Class Initialized
INFO - 2022-06-23 05:41:50 --> Router Class Initialized
INFO - 2022-06-23 05:41:50 --> Router Class Initialized
INFO - 2022-06-23 05:41:50 --> Output Class Initialized
INFO - 2022-06-23 05:41:50 --> Security Class Initialized
INFO - 2022-06-23 05:41:50 --> Output Class Initialized
DEBUG - 2022-06-23 05:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:41:50 --> Security Class Initialized
INFO - 2022-06-23 05:41:50 --> Input Class Initialized
DEBUG - 2022-06-23 05:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:41:50 --> Language Class Initialized
INFO - 2022-06-23 05:41:50 --> Input Class Initialized
INFO - 2022-06-23 05:41:50 --> Language Class Initialized
INFO - 2022-06-23 05:41:50 --> Loader Class Initialized
INFO - 2022-06-23 05:41:50 --> Loader Class Initialized
INFO - 2022-06-23 05:41:50 --> Helper loaded: url_helper
INFO - 2022-06-23 05:41:50 --> Helper loaded: url_helper
INFO - 2022-06-23 05:41:50 --> Helper loaded: file_helper
INFO - 2022-06-23 05:41:50 --> Helper loaded: file_helper
INFO - 2022-06-23 05:41:50 --> Database Driver Class Initialized
INFO - 2022-06-23 05:41:50 --> Database Driver Class Initialized
INFO - 2022-06-23 05:41:50 --> Email Class Initialized
INFO - 2022-06-23 05:41:50 --> Email Class Initialized
DEBUG - 2022-06-23 05:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 05:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:41:50 --> Controller Class Initialized
INFO - 2022-06-23 05:41:50 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:41:51 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:41:51 --> Final output sent to browser
DEBUG - 2022-06-23 05:41:51 --> Total execution time: 0.1640
INFO - 2022-06-23 05:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:41:51 --> Controller Class Initialized
INFO - 2022-06-23 05:41:51 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:41:51 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:41:51 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:41:51 --> Final output sent to browser
DEBUG - 2022-06-23 05:41:51 --> Total execution time: 0.1846
INFO - 2022-06-23 05:41:56 --> Config Class Initialized
INFO - 2022-06-23 05:41:56 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:41:56 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:41:56 --> Utf8 Class Initialized
INFO - 2022-06-23 05:41:57 --> URI Class Initialized
INFO - 2022-06-23 05:41:57 --> Router Class Initialized
INFO - 2022-06-23 05:41:57 --> Output Class Initialized
INFO - 2022-06-23 05:41:57 --> Security Class Initialized
DEBUG - 2022-06-23 05:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:41:57 --> Input Class Initialized
INFO - 2022-06-23 05:41:57 --> Language Class Initialized
INFO - 2022-06-23 05:41:57 --> Loader Class Initialized
INFO - 2022-06-23 05:41:57 --> Helper loaded: url_helper
INFO - 2022-06-23 05:41:57 --> Helper loaded: file_helper
INFO - 2022-06-23 05:41:57 --> Database Driver Class Initialized
INFO - 2022-06-23 05:41:57 --> Email Class Initialized
DEBUG - 2022-06-23 05:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:41:57 --> Controller Class Initialized
INFO - 2022-06-23 05:41:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:41:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:41:57 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:41:57 --> Final output sent to browser
DEBUG - 2022-06-23 05:41:57 --> Total execution time: 0.1557
INFO - 2022-06-23 05:42:09 --> Config Class Initialized
INFO - 2022-06-23 05:42:09 --> Hooks Class Initialized
INFO - 2022-06-23 05:42:09 --> Config Class Initialized
INFO - 2022-06-23 05:42:09 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:42:09 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:42:09 --> Utf8 Class Initialized
DEBUG - 2022-06-23 05:42:09 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:42:09 --> Utf8 Class Initialized
INFO - 2022-06-23 05:42:09 --> URI Class Initialized
INFO - 2022-06-23 05:42:09 --> URI Class Initialized
INFO - 2022-06-23 05:42:09 --> Router Class Initialized
INFO - 2022-06-23 05:42:09 --> Router Class Initialized
INFO - 2022-06-23 05:42:09 --> Output Class Initialized
INFO - 2022-06-23 05:42:09 --> Output Class Initialized
INFO - 2022-06-23 05:42:09 --> Security Class Initialized
INFO - 2022-06-23 05:42:09 --> Security Class Initialized
DEBUG - 2022-06-23 05:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 05:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:42:09 --> Input Class Initialized
INFO - 2022-06-23 05:42:09 --> Input Class Initialized
INFO - 2022-06-23 05:42:09 --> Language Class Initialized
INFO - 2022-06-23 05:42:09 --> Language Class Initialized
INFO - 2022-06-23 05:42:09 --> Loader Class Initialized
INFO - 2022-06-23 05:42:09 --> Loader Class Initialized
INFO - 2022-06-23 05:42:09 --> Helper loaded: url_helper
INFO - 2022-06-23 05:42:09 --> Helper loaded: url_helper
INFO - 2022-06-23 05:42:09 --> Helper loaded: file_helper
INFO - 2022-06-23 05:42:09 --> Helper loaded: file_helper
INFO - 2022-06-23 05:42:09 --> Database Driver Class Initialized
INFO - 2022-06-23 05:42:09 --> Database Driver Class Initialized
INFO - 2022-06-23 05:42:09 --> Email Class Initialized
INFO - 2022-06-23 05:42:09 --> Email Class Initialized
DEBUG - 2022-06-23 05:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 05:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:42:09 --> Controller Class Initialized
INFO - 2022-06-23 05:42:09 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:42:09 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:42:09 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:42:09 --> Final output sent to browser
DEBUG - 2022-06-23 05:42:09 --> Total execution time: 0.0907
INFO - 2022-06-23 05:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:42:09 --> Controller Class Initialized
INFO - 2022-06-23 05:42:09 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:42:09 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:42:09 --> Final output sent to browser
DEBUG - 2022-06-23 05:42:09 --> Total execution time: 0.1091
INFO - 2022-06-23 05:42:41 --> Config Class Initialized
INFO - 2022-06-23 05:42:41 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:42:41 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:42:41 --> Utf8 Class Initialized
INFO - 2022-06-23 05:42:41 --> URI Class Initialized
INFO - 2022-06-23 05:42:41 --> Router Class Initialized
INFO - 2022-06-23 05:42:41 --> Output Class Initialized
INFO - 2022-06-23 05:42:41 --> Security Class Initialized
DEBUG - 2022-06-23 05:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:42:41 --> Input Class Initialized
INFO - 2022-06-23 05:42:41 --> Language Class Initialized
INFO - 2022-06-23 05:42:41 --> Loader Class Initialized
INFO - 2022-06-23 05:42:41 --> Helper loaded: url_helper
INFO - 2022-06-23 05:42:41 --> Helper loaded: file_helper
INFO - 2022-06-23 05:42:41 --> Database Driver Class Initialized
INFO - 2022-06-23 05:42:41 --> Email Class Initialized
DEBUG - 2022-06-23 05:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:42:41 --> Controller Class Initialized
INFO - 2022-06-23 05:42:41 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:42:41 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:42:41 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:42:41 --> Final output sent to browser
DEBUG - 2022-06-23 05:42:41 --> Total execution time: 0.1061
INFO - 2022-06-23 05:42:54 --> Config Class Initialized
INFO - 2022-06-23 05:42:54 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:42:54 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:42:54 --> Utf8 Class Initialized
INFO - 2022-06-23 05:42:54 --> URI Class Initialized
INFO - 2022-06-23 05:42:54 --> Config Class Initialized
INFO - 2022-06-23 05:42:54 --> Hooks Class Initialized
INFO - 2022-06-23 05:42:54 --> Router Class Initialized
DEBUG - 2022-06-23 05:42:54 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:42:54 --> Utf8 Class Initialized
INFO - 2022-06-23 05:42:54 --> Output Class Initialized
INFO - 2022-06-23 05:42:54 --> URI Class Initialized
INFO - 2022-06-23 05:42:54 --> Security Class Initialized
INFO - 2022-06-23 05:42:54 --> Router Class Initialized
DEBUG - 2022-06-23 05:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:42:54 --> Input Class Initialized
INFO - 2022-06-23 05:42:54 --> Output Class Initialized
INFO - 2022-06-23 05:42:54 --> Language Class Initialized
INFO - 2022-06-23 05:42:54 --> Security Class Initialized
DEBUG - 2022-06-23 05:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:42:54 --> Loader Class Initialized
INFO - 2022-06-23 05:42:54 --> Input Class Initialized
INFO - 2022-06-23 05:42:54 --> Language Class Initialized
INFO - 2022-06-23 05:42:54 --> Helper loaded: url_helper
INFO - 2022-06-23 05:42:54 --> Loader Class Initialized
INFO - 2022-06-23 05:42:54 --> Helper loaded: file_helper
INFO - 2022-06-23 05:42:54 --> Helper loaded: url_helper
INFO - 2022-06-23 05:42:54 --> Database Driver Class Initialized
INFO - 2022-06-23 05:42:54 --> Helper loaded: file_helper
INFO - 2022-06-23 05:42:54 --> Database Driver Class Initialized
INFO - 2022-06-23 05:42:54 --> Email Class Initialized
INFO - 2022-06-23 05:42:54 --> Email Class Initialized
DEBUG - 2022-06-23 05:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 05:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:42:54 --> Controller Class Initialized
INFO - 2022-06-23 05:42:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:42:54 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:42:54 --> Final output sent to browser
DEBUG - 2022-06-23 05:42:54 --> Total execution time: 0.1413
INFO - 2022-06-23 05:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:42:54 --> Controller Class Initialized
INFO - 2022-06-23 05:42:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:42:54 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:42:54 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:42:54 --> Final output sent to browser
DEBUG - 2022-06-23 05:42:54 --> Total execution time: 0.0570
INFO - 2022-06-23 05:43:08 --> Config Class Initialized
INFO - 2022-06-23 05:43:08 --> Hooks Class Initialized
DEBUG - 2022-06-23 05:43:08 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:43:08 --> Utf8 Class Initialized
INFO - 2022-06-23 05:43:08 --> URI Class Initialized
INFO - 2022-06-23 05:43:08 --> Router Class Initialized
INFO - 2022-06-23 05:43:08 --> Config Class Initialized
INFO - 2022-06-23 05:43:08 --> Hooks Class Initialized
INFO - 2022-06-23 05:43:08 --> Output Class Initialized
DEBUG - 2022-06-23 05:43:08 --> UTF-8 Support Enabled
INFO - 2022-06-23 05:43:08 --> Security Class Initialized
INFO - 2022-06-23 05:43:08 --> Utf8 Class Initialized
DEBUG - 2022-06-23 05:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:43:08 --> URI Class Initialized
INFO - 2022-06-23 05:43:08 --> Input Class Initialized
INFO - 2022-06-23 05:43:08 --> Router Class Initialized
INFO - 2022-06-23 05:43:08 --> Language Class Initialized
INFO - 2022-06-23 05:43:08 --> Output Class Initialized
INFO - 2022-06-23 05:43:08 --> Loader Class Initialized
INFO - 2022-06-23 05:43:08 --> Security Class Initialized
INFO - 2022-06-23 05:43:08 --> Helper loaded: url_helper
DEBUG - 2022-06-23 05:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 05:43:08 --> Helper loaded: file_helper
INFO - 2022-06-23 05:43:08 --> Input Class Initialized
INFO - 2022-06-23 05:43:08 --> Language Class Initialized
INFO - 2022-06-23 05:43:08 --> Database Driver Class Initialized
INFO - 2022-06-23 05:43:08 --> Loader Class Initialized
INFO - 2022-06-23 05:43:08 --> Helper loaded: url_helper
INFO - 2022-06-23 05:43:08 --> Helper loaded: file_helper
INFO - 2022-06-23 05:43:08 --> Database Driver Class Initialized
INFO - 2022-06-23 05:43:08 --> Email Class Initialized
DEBUG - 2022-06-23 05:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:43:08 --> Controller Class Initialized
INFO - 2022-06-23 05:43:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:43:08 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:43:08 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 05:43:08 --> Final output sent to browser
DEBUG - 2022-06-23 05:43:08 --> Total execution time: 0.1120
INFO - 2022-06-23 05:43:08 --> Email Class Initialized
DEBUG - 2022-06-23 05:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 05:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 05:43:08 --> Controller Class Initialized
INFO - 2022-06-23 05:43:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 05:43:08 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 05:43:08 --> Final output sent to browser
DEBUG - 2022-06-23 05:43:08 --> Total execution time: 0.2714
INFO - 2022-06-23 06:07:04 --> Config Class Initialized
INFO - 2022-06-23 06:07:04 --> Hooks Class Initialized
INFO - 2022-06-23 06:07:04 --> Config Class Initialized
DEBUG - 2022-06-23 06:07:04 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:07:04 --> Hooks Class Initialized
INFO - 2022-06-23 06:07:04 --> Utf8 Class Initialized
DEBUG - 2022-06-23 06:07:04 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:07:04 --> Utf8 Class Initialized
INFO - 2022-06-23 06:07:04 --> URI Class Initialized
INFO - 2022-06-23 06:07:04 --> URI Class Initialized
INFO - 2022-06-23 06:07:04 --> Router Class Initialized
INFO - 2022-06-23 06:07:04 --> Router Class Initialized
INFO - 2022-06-23 06:07:04 --> Output Class Initialized
INFO - 2022-06-23 06:07:04 --> Output Class Initialized
INFO - 2022-06-23 06:07:04 --> Security Class Initialized
INFO - 2022-06-23 06:07:04 --> Security Class Initialized
DEBUG - 2022-06-23 06:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:07:04 --> Input Class Initialized
INFO - 2022-06-23 06:07:04 --> Input Class Initialized
INFO - 2022-06-23 06:07:04 --> Language Class Initialized
INFO - 2022-06-23 06:07:04 --> Language Class Initialized
INFO - 2022-06-23 06:07:04 --> Loader Class Initialized
INFO - 2022-06-23 06:07:04 --> Loader Class Initialized
INFO - 2022-06-23 06:07:04 --> Helper loaded: url_helper
INFO - 2022-06-23 06:07:04 --> Helper loaded: url_helper
INFO - 2022-06-23 06:07:04 --> Helper loaded: file_helper
INFO - 2022-06-23 06:07:04 --> Helper loaded: file_helper
INFO - 2022-06-23 06:07:04 --> Database Driver Class Initialized
INFO - 2022-06-23 06:07:04 --> Database Driver Class Initialized
INFO - 2022-06-23 06:07:04 --> Email Class Initialized
DEBUG - 2022-06-23 06:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:07:04 --> Controller Class Initialized
INFO - 2022-06-23 06:07:04 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:07:04 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:07:04 --> Final output sent to browser
DEBUG - 2022-06-23 06:07:04 --> Total execution time: 0.1165
INFO - 2022-06-23 06:07:04 --> Email Class Initialized
DEBUG - 2022-06-23 06:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:07:04 --> Controller Class Initialized
INFO - 2022-06-23 06:07:04 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:07:04 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:07:04 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:07:04 --> Final output sent to browser
DEBUG - 2022-06-23 06:07:04 --> Total execution time: 0.4738
INFO - 2022-06-23 06:07:21 --> Config Class Initialized
INFO - 2022-06-23 06:07:21 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:07:21 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:07:21 --> Utf8 Class Initialized
INFO - 2022-06-23 06:07:21 --> URI Class Initialized
INFO - 2022-06-23 06:07:21 --> Router Class Initialized
INFO - 2022-06-23 06:07:21 --> Output Class Initialized
INFO - 2022-06-23 06:07:21 --> Security Class Initialized
DEBUG - 2022-06-23 06:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:07:21 --> Input Class Initialized
INFO - 2022-06-23 06:07:21 --> Language Class Initialized
INFO - 2022-06-23 06:07:21 --> Loader Class Initialized
INFO - 2022-06-23 06:07:21 --> Helper loaded: url_helper
INFO - 2022-06-23 06:07:21 --> Helper loaded: file_helper
INFO - 2022-06-23 06:07:21 --> Database Driver Class Initialized
INFO - 2022-06-23 06:07:22 --> Email Class Initialized
DEBUG - 2022-06-23 06:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:07:22 --> Controller Class Initialized
INFO - 2022-06-23 06:07:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:07:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:07:22 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:07:22 --> Final output sent to browser
DEBUG - 2022-06-23 06:07:22 --> Total execution time: 0.4938
INFO - 2022-06-23 06:08:58 --> Config Class Initialized
INFO - 2022-06-23 06:08:58 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:08:58 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:08:58 --> Utf8 Class Initialized
INFO - 2022-06-23 06:08:58 --> URI Class Initialized
INFO - 2022-06-23 06:08:58 --> Router Class Initialized
INFO - 2022-06-23 06:08:58 --> Output Class Initialized
INFO - 2022-06-23 06:08:58 --> Security Class Initialized
DEBUG - 2022-06-23 06:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:08:58 --> Input Class Initialized
INFO - 2022-06-23 06:08:58 --> Language Class Initialized
INFO - 2022-06-23 06:08:58 --> Loader Class Initialized
INFO - 2022-06-23 06:08:58 --> Helper loaded: url_helper
INFO - 2022-06-23 06:08:58 --> Helper loaded: file_helper
INFO - 2022-06-23 06:08:58 --> Database Driver Class Initialized
INFO - 2022-06-23 06:08:58 --> Email Class Initialized
DEBUG - 2022-06-23 06:08:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:08:58 --> Controller Class Initialized
INFO - 2022-06-23 06:08:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:08:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:08:58 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:08:58 --> Final output sent to browser
DEBUG - 2022-06-23 06:08:58 --> Total execution time: 0.1320
INFO - 2022-06-23 06:09:14 --> Config Class Initialized
INFO - 2022-06-23 06:09:14 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:09:14 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:09:14 --> Utf8 Class Initialized
INFO - 2022-06-23 06:09:14 --> URI Class Initialized
INFO - 2022-06-23 06:09:14 --> Router Class Initialized
INFO - 2022-06-23 06:09:14 --> Output Class Initialized
INFO - 2022-06-23 06:09:14 --> Security Class Initialized
DEBUG - 2022-06-23 06:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:09:14 --> Input Class Initialized
INFO - 2022-06-23 06:09:14 --> Language Class Initialized
INFO - 2022-06-23 06:09:14 --> Loader Class Initialized
INFO - 2022-06-23 06:09:14 --> Helper loaded: url_helper
INFO - 2022-06-23 06:09:14 --> Helper loaded: file_helper
INFO - 2022-06-23 06:09:14 --> Database Driver Class Initialized
INFO - 2022-06-23 06:09:14 --> Email Class Initialized
DEBUG - 2022-06-23 06:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:09:14 --> Controller Class Initialized
INFO - 2022-06-23 06:09:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:09:14 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:09:14 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:09:14 --> Final output sent to browser
DEBUG - 2022-06-23 06:09:14 --> Total execution time: 0.1870
INFO - 2022-06-23 06:09:24 --> Config Class Initialized
INFO - 2022-06-23 06:09:24 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:09:24 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:09:24 --> Utf8 Class Initialized
INFO - 2022-06-23 06:09:24 --> URI Class Initialized
INFO - 2022-06-23 06:09:24 --> Config Class Initialized
INFO - 2022-06-23 06:09:24 --> Hooks Class Initialized
INFO - 2022-06-23 06:09:24 --> Router Class Initialized
DEBUG - 2022-06-23 06:09:24 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:09:24 --> Utf8 Class Initialized
INFO - 2022-06-23 06:09:24 --> Output Class Initialized
INFO - 2022-06-23 06:09:24 --> URI Class Initialized
INFO - 2022-06-23 06:09:24 --> Security Class Initialized
DEBUG - 2022-06-23 06:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:09:24 --> Router Class Initialized
INFO - 2022-06-23 06:09:24 --> Input Class Initialized
INFO - 2022-06-23 06:09:24 --> Output Class Initialized
INFO - 2022-06-23 06:09:25 --> Language Class Initialized
INFO - 2022-06-23 06:09:25 --> Security Class Initialized
DEBUG - 2022-06-23 06:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:09:25 --> Loader Class Initialized
INFO - 2022-06-23 06:09:25 --> Input Class Initialized
INFO - 2022-06-23 06:09:25 --> Helper loaded: url_helper
INFO - 2022-06-23 06:09:25 --> Language Class Initialized
INFO - 2022-06-23 06:09:25 --> Helper loaded: file_helper
INFO - 2022-06-23 06:09:25 --> Loader Class Initialized
INFO - 2022-06-23 06:09:25 --> Helper loaded: url_helper
INFO - 2022-06-23 06:09:25 --> Database Driver Class Initialized
INFO - 2022-06-23 06:09:25 --> Helper loaded: file_helper
INFO - 2022-06-23 06:09:25 --> Database Driver Class Initialized
INFO - 2022-06-23 06:09:25 --> Email Class Initialized
INFO - 2022-06-23 06:09:25 --> Email Class Initialized
DEBUG - 2022-06-23 06:09:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 06:09:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:09:25 --> Controller Class Initialized
INFO - 2022-06-23 06:09:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:09:25 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:09:25 --> Final output sent to browser
DEBUG - 2022-06-23 06:09:25 --> Total execution time: 0.2420
INFO - 2022-06-23 06:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:09:25 --> Controller Class Initialized
INFO - 2022-06-23 06:09:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:09:25 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:09:25 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:09:25 --> Final output sent to browser
DEBUG - 2022-06-23 06:09:25 --> Total execution time: 0.2528
INFO - 2022-06-23 06:09:30 --> Config Class Initialized
INFO - 2022-06-23 06:09:30 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:09:30 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:09:30 --> Utf8 Class Initialized
INFO - 2022-06-23 06:09:30 --> URI Class Initialized
INFO - 2022-06-23 06:09:30 --> Router Class Initialized
INFO - 2022-06-23 06:09:30 --> Output Class Initialized
INFO - 2022-06-23 06:09:30 --> Security Class Initialized
DEBUG - 2022-06-23 06:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:09:30 --> Input Class Initialized
INFO - 2022-06-23 06:09:30 --> Language Class Initialized
INFO - 2022-06-23 06:09:30 --> Loader Class Initialized
INFO - 2022-06-23 06:09:30 --> Helper loaded: url_helper
INFO - 2022-06-23 06:09:30 --> Helper loaded: file_helper
INFO - 2022-06-23 06:09:30 --> Database Driver Class Initialized
INFO - 2022-06-23 06:09:30 --> Email Class Initialized
DEBUG - 2022-06-23 06:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:09:30 --> Controller Class Initialized
INFO - 2022-06-23 06:09:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:09:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:09:30 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:09:30 --> Final output sent to browser
DEBUG - 2022-06-23 06:09:30 --> Total execution time: 0.0727
INFO - 2022-06-23 06:19:56 --> Config Class Initialized
INFO - 2022-06-23 06:19:56 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:19:56 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:19:56 --> Utf8 Class Initialized
INFO - 2022-06-23 06:19:56 --> URI Class Initialized
INFO - 2022-06-23 06:19:56 --> Router Class Initialized
INFO - 2022-06-23 06:19:56 --> Output Class Initialized
INFO - 2022-06-23 06:19:56 --> Security Class Initialized
DEBUG - 2022-06-23 06:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:19:56 --> Input Class Initialized
INFO - 2022-06-23 06:19:56 --> Language Class Initialized
INFO - 2022-06-23 06:19:56 --> Loader Class Initialized
INFO - 2022-06-23 06:19:56 --> Helper loaded: url_helper
INFO - 2022-06-23 06:19:56 --> Helper loaded: file_helper
INFO - 2022-06-23 06:19:56 --> Database Driver Class Initialized
INFO - 2022-06-23 06:19:56 --> Email Class Initialized
DEBUG - 2022-06-23 06:19:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:19:56 --> Controller Class Initialized
INFO - 2022-06-23 06:19:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:19:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:19:56 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:19:56 --> Final output sent to browser
DEBUG - 2022-06-23 06:19:56 --> Total execution time: 0.1549
INFO - 2022-06-23 06:20:15 --> Config Class Initialized
INFO - 2022-06-23 06:20:15 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:20:15 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:20:15 --> Utf8 Class Initialized
INFO - 2022-06-23 06:20:15 --> URI Class Initialized
INFO - 2022-06-23 06:20:15 --> Router Class Initialized
INFO - 2022-06-23 06:20:15 --> Output Class Initialized
INFO - 2022-06-23 06:20:15 --> Config Class Initialized
INFO - 2022-06-23 06:20:15 --> Security Class Initialized
INFO - 2022-06-23 06:20:15 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:20:15 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:20:15 --> Input Class Initialized
INFO - 2022-06-23 06:20:15 --> Utf8 Class Initialized
INFO - 2022-06-23 06:20:15 --> Language Class Initialized
INFO - 2022-06-23 06:20:15 --> URI Class Initialized
INFO - 2022-06-23 06:20:15 --> Loader Class Initialized
INFO - 2022-06-23 06:20:15 --> Router Class Initialized
INFO - 2022-06-23 06:20:15 --> Output Class Initialized
INFO - 2022-06-23 06:20:15 --> Helper loaded: url_helper
INFO - 2022-06-23 06:20:15 --> Security Class Initialized
INFO - 2022-06-23 06:20:15 --> Helper loaded: file_helper
DEBUG - 2022-06-23 06:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:20:15 --> Input Class Initialized
INFO - 2022-06-23 06:20:15 --> Database Driver Class Initialized
INFO - 2022-06-23 06:20:15 --> Language Class Initialized
INFO - 2022-06-23 06:20:15 --> Loader Class Initialized
INFO - 2022-06-23 06:20:15 --> Helper loaded: url_helper
INFO - 2022-06-23 06:20:15 --> Helper loaded: file_helper
INFO - 2022-06-23 06:20:15 --> Database Driver Class Initialized
INFO - 2022-06-23 06:20:15 --> Email Class Initialized
DEBUG - 2022-06-23 06:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:20:15 --> Controller Class Initialized
INFO - 2022-06-23 06:20:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:20:15 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:20:15 --> Final output sent to browser
DEBUG - 2022-06-23 06:20:15 --> Total execution time: 0.2276
INFO - 2022-06-23 06:20:15 --> Email Class Initialized
DEBUG - 2022-06-23 06:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:20:15 --> Controller Class Initialized
INFO - 2022-06-23 06:20:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:20:15 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:20:15 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:20:15 --> Final output sent to browser
DEBUG - 2022-06-23 06:20:15 --> Total execution time: 0.2375
INFO - 2022-06-23 06:20:26 --> Config Class Initialized
INFO - 2022-06-23 06:20:26 --> Hooks Class Initialized
INFO - 2022-06-23 06:20:26 --> Config Class Initialized
DEBUG - 2022-06-23 06:20:26 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:20:26 --> Hooks Class Initialized
INFO - 2022-06-23 06:20:26 --> Utf8 Class Initialized
INFO - 2022-06-23 06:20:26 --> URI Class Initialized
DEBUG - 2022-06-23 06:20:26 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:20:26 --> Utf8 Class Initialized
INFO - 2022-06-23 06:20:26 --> Router Class Initialized
INFO - 2022-06-23 06:20:26 --> URI Class Initialized
INFO - 2022-06-23 06:20:26 --> Output Class Initialized
INFO - 2022-06-23 06:20:26 --> Router Class Initialized
INFO - 2022-06-23 06:20:26 --> Security Class Initialized
INFO - 2022-06-23 06:20:26 --> Output Class Initialized
DEBUG - 2022-06-23 06:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:20:26 --> Input Class Initialized
INFO - 2022-06-23 06:20:26 --> Security Class Initialized
INFO - 2022-06-23 06:20:26 --> Language Class Initialized
DEBUG - 2022-06-23 06:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:20:26 --> Input Class Initialized
INFO - 2022-06-23 06:20:26 --> Loader Class Initialized
INFO - 2022-06-23 06:20:26 --> Language Class Initialized
INFO - 2022-06-23 06:20:26 --> Helper loaded: url_helper
INFO - 2022-06-23 06:20:26 --> Loader Class Initialized
INFO - 2022-06-23 06:20:26 --> Helper loaded: file_helper
INFO - 2022-06-23 06:20:26 --> Helper loaded: url_helper
INFO - 2022-06-23 06:20:26 --> Helper loaded: file_helper
INFO - 2022-06-23 06:20:26 --> Database Driver Class Initialized
INFO - 2022-06-23 06:20:26 --> Database Driver Class Initialized
INFO - 2022-06-23 06:20:26 --> Email Class Initialized
DEBUG - 2022-06-23 06:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:20:26 --> Controller Class Initialized
INFO - 2022-06-23 06:20:26 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:20:26 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:20:26 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:20:26 --> Final output sent to browser
DEBUG - 2022-06-23 06:20:26 --> Total execution time: 0.3565
INFO - 2022-06-23 06:20:26 --> Email Class Initialized
DEBUG - 2022-06-23 06:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:20:26 --> Controller Class Initialized
INFO - 2022-06-23 06:20:26 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:20:26 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:20:26 --> Final output sent to browser
DEBUG - 2022-06-23 06:20:26 --> Total execution time: 0.4278
INFO - 2022-06-23 06:23:01 --> Config Class Initialized
INFO - 2022-06-23 06:23:01 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:23:01 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:23:01 --> Utf8 Class Initialized
INFO - 2022-06-23 06:23:01 --> URI Class Initialized
INFO - 2022-06-23 06:23:01 --> Router Class Initialized
INFO - 2022-06-23 06:23:01 --> Output Class Initialized
INFO - 2022-06-23 06:23:01 --> Security Class Initialized
DEBUG - 2022-06-23 06:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:23:01 --> Input Class Initialized
INFO - 2022-06-23 06:23:01 --> Language Class Initialized
INFO - 2022-06-23 06:23:01 --> Loader Class Initialized
INFO - 2022-06-23 06:23:01 --> Helper loaded: url_helper
INFO - 2022-06-23 06:23:01 --> Helper loaded: file_helper
INFO - 2022-06-23 06:23:01 --> Database Driver Class Initialized
INFO - 2022-06-23 06:23:01 --> Email Class Initialized
DEBUG - 2022-06-23 06:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:23:01 --> Controller Class Initialized
INFO - 2022-06-23 06:23:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:23:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 06:23:01 --> Severity: Notice --> Undefined variable: dat C:\wamp64\www\qr\application\views\otp\otp.php 233
INFO - 2022-06-23 06:23:01 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:23:01 --> Final output sent to browser
DEBUG - 2022-06-23 06:23:01 --> Total execution time: 0.0569
INFO - 2022-06-23 06:23:13 --> Config Class Initialized
INFO - 2022-06-23 06:23:13 --> Hooks Class Initialized
INFO - 2022-06-23 06:23:13 --> Config Class Initialized
DEBUG - 2022-06-23 06:23:13 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:23:13 --> Hooks Class Initialized
INFO - 2022-06-23 06:23:13 --> Utf8 Class Initialized
INFO - 2022-06-23 06:23:13 --> URI Class Initialized
DEBUG - 2022-06-23 06:23:13 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:23:13 --> Utf8 Class Initialized
INFO - 2022-06-23 06:23:13 --> Router Class Initialized
INFO - 2022-06-23 06:23:13 --> URI Class Initialized
INFO - 2022-06-23 06:23:13 --> Router Class Initialized
INFO - 2022-06-23 06:23:13 --> Output Class Initialized
INFO - 2022-06-23 06:23:13 --> Output Class Initialized
INFO - 2022-06-23 06:23:13 --> Security Class Initialized
INFO - 2022-06-23 06:23:13 --> Security Class Initialized
DEBUG - 2022-06-23 06:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:23:13 --> Input Class Initialized
DEBUG - 2022-06-23 06:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:23:13 --> Input Class Initialized
INFO - 2022-06-23 06:23:13 --> Language Class Initialized
INFO - 2022-06-23 06:23:13 --> Language Class Initialized
INFO - 2022-06-23 06:23:13 --> Loader Class Initialized
INFO - 2022-06-23 06:23:13 --> Loader Class Initialized
INFO - 2022-06-23 06:23:13 --> Helper loaded: url_helper
INFO - 2022-06-23 06:23:13 --> Helper loaded: url_helper
INFO - 2022-06-23 06:23:13 --> Helper loaded: file_helper
INFO - 2022-06-23 06:23:13 --> Helper loaded: file_helper
INFO - 2022-06-23 06:23:13 --> Database Driver Class Initialized
INFO - 2022-06-23 06:23:13 --> Database Driver Class Initialized
INFO - 2022-06-23 06:23:14 --> Email Class Initialized
DEBUG - 2022-06-23 06:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:23:14 --> Controller Class Initialized
INFO - 2022-06-23 06:23:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:23:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 06:23:14 --> Severity: Notice --> Undefined variable: dat C:\wamp64\www\qr\application\views\otp\otp.php 233
INFO - 2022-06-23 06:23:14 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:23:14 --> Final output sent to browser
DEBUG - 2022-06-23 06:23:14 --> Total execution time: 0.0836
INFO - 2022-06-23 06:23:14 --> Email Class Initialized
DEBUG - 2022-06-23 06:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:23:14 --> Controller Class Initialized
INFO - 2022-06-23 06:23:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:23:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 06:23:14 --> Severity: Notice --> Undefined variable: dat C:\wamp64\www\qr\application\views\otp\otp.php 233
INFO - 2022-06-23 06:23:14 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:23:14 --> Final output sent to browser
DEBUG - 2022-06-23 06:23:14 --> Total execution time: 0.0992
INFO - 2022-06-23 06:23:22 --> Config Class Initialized
INFO - 2022-06-23 06:23:22 --> Hooks Class Initialized
INFO - 2022-06-23 06:23:22 --> Config Class Initialized
DEBUG - 2022-06-23 06:23:22 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:23:22 --> Hooks Class Initialized
INFO - 2022-06-23 06:23:22 --> Utf8 Class Initialized
INFO - 2022-06-23 06:23:22 --> URI Class Initialized
DEBUG - 2022-06-23 06:23:22 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:23:22 --> Utf8 Class Initialized
INFO - 2022-06-23 06:23:22 --> Router Class Initialized
INFO - 2022-06-23 06:23:22 --> URI Class Initialized
INFO - 2022-06-23 06:23:22 --> Output Class Initialized
INFO - 2022-06-23 06:23:22 --> Router Class Initialized
INFO - 2022-06-23 06:23:22 --> Security Class Initialized
INFO - 2022-06-23 06:23:22 --> Output Class Initialized
DEBUG - 2022-06-23 06:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:23:22 --> Security Class Initialized
INFO - 2022-06-23 06:23:22 --> Input Class Initialized
DEBUG - 2022-06-23 06:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:23:22 --> Language Class Initialized
INFO - 2022-06-23 06:23:22 --> Input Class Initialized
INFO - 2022-06-23 06:23:22 --> Language Class Initialized
INFO - 2022-06-23 06:23:22 --> Loader Class Initialized
INFO - 2022-06-23 06:23:22 --> Loader Class Initialized
INFO - 2022-06-23 06:23:22 --> Helper loaded: url_helper
INFO - 2022-06-23 06:23:22 --> Helper loaded: url_helper
INFO - 2022-06-23 06:23:22 --> Helper loaded: file_helper
INFO - 2022-06-23 06:23:22 --> Helper loaded: file_helper
INFO - 2022-06-23 06:23:22 --> Database Driver Class Initialized
INFO - 2022-06-23 06:23:22 --> Database Driver Class Initialized
INFO - 2022-06-23 06:23:22 --> Email Class Initialized
DEBUG - 2022-06-23 06:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:23:22 --> Controller Class Initialized
INFO - 2022-06-23 06:23:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:23:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 06:23:22 --> Severity: Notice --> Undefined variable: dat C:\wamp64\www\qr\application\views\otp\otp.php 233
INFO - 2022-06-23 06:23:22 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:23:22 --> Final output sent to browser
DEBUG - 2022-06-23 06:23:22 --> Total execution time: 0.0268
INFO - 2022-06-23 06:23:22 --> Email Class Initialized
DEBUG - 2022-06-23 06:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:23:22 --> Controller Class Initialized
INFO - 2022-06-23 06:23:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:23:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 06:23:22 --> Severity: Notice --> Undefined variable: dat C:\wamp64\www\qr\application\views\otp\otp.php 233
INFO - 2022-06-23 06:23:22 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:23:22 --> Final output sent to browser
DEBUG - 2022-06-23 06:23:22 --> Total execution time: 0.0497
INFO - 2022-06-23 06:23:55 --> Config Class Initialized
INFO - 2022-06-23 06:23:55 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:23:55 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:23:55 --> Utf8 Class Initialized
INFO - 2022-06-23 06:23:55 --> URI Class Initialized
INFO - 2022-06-23 06:23:55 --> Router Class Initialized
INFO - 2022-06-23 06:23:55 --> Output Class Initialized
INFO - 2022-06-23 06:23:55 --> Security Class Initialized
DEBUG - 2022-06-23 06:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:23:55 --> Input Class Initialized
INFO - 2022-06-23 06:23:55 --> Language Class Initialized
INFO - 2022-06-23 06:23:55 --> Loader Class Initialized
INFO - 2022-06-23 06:23:55 --> Helper loaded: url_helper
INFO - 2022-06-23 06:23:55 --> Helper loaded: file_helper
INFO - 2022-06-23 06:23:55 --> Database Driver Class Initialized
INFO - 2022-06-23 06:23:55 --> Email Class Initialized
DEBUG - 2022-06-23 06:23:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:23:55 --> Controller Class Initialized
INFO - 2022-06-23 06:23:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:23:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:23:55 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:23:55 --> Final output sent to browser
DEBUG - 2022-06-23 06:23:55 --> Total execution time: 0.0260
INFO - 2022-06-23 06:24:08 --> Config Class Initialized
INFO - 2022-06-23 06:24:08 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:24:08 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:24:08 --> Utf8 Class Initialized
INFO - 2022-06-23 06:24:08 --> Config Class Initialized
INFO - 2022-06-23 06:24:08 --> Hooks Class Initialized
INFO - 2022-06-23 06:24:08 --> URI Class Initialized
DEBUG - 2022-06-23 06:24:08 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:24:08 --> Router Class Initialized
INFO - 2022-06-23 06:24:08 --> Utf8 Class Initialized
INFO - 2022-06-23 06:24:08 --> URI Class Initialized
INFO - 2022-06-23 06:24:08 --> Output Class Initialized
INFO - 2022-06-23 06:24:08 --> Security Class Initialized
INFO - 2022-06-23 06:24:08 --> Router Class Initialized
DEBUG - 2022-06-23 06:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:24:08 --> Output Class Initialized
INFO - 2022-06-23 06:24:08 --> Input Class Initialized
INFO - 2022-06-23 06:24:08 --> Security Class Initialized
INFO - 2022-06-23 06:24:08 --> Language Class Initialized
DEBUG - 2022-06-23 06:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:24:08 --> Input Class Initialized
INFO - 2022-06-23 06:24:08 --> Loader Class Initialized
INFO - 2022-06-23 06:24:08 --> Language Class Initialized
INFO - 2022-06-23 06:24:08 --> Helper loaded: url_helper
INFO - 2022-06-23 06:24:08 --> Loader Class Initialized
INFO - 2022-06-23 06:24:08 --> Helper loaded: file_helper
INFO - 2022-06-23 06:24:08 --> Helper loaded: url_helper
INFO - 2022-06-23 06:24:08 --> Helper loaded: file_helper
INFO - 2022-06-23 06:24:08 --> Database Driver Class Initialized
INFO - 2022-06-23 06:24:08 --> Database Driver Class Initialized
INFO - 2022-06-23 06:24:09 --> Email Class Initialized
INFO - 2022-06-23 06:24:09 --> Email Class Initialized
DEBUG - 2022-06-23 06:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 06:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:24:09 --> Controller Class Initialized
INFO - 2022-06-23 06:24:09 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:24:09 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:24:09 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:24:09 --> Final output sent to browser
DEBUG - 2022-06-23 06:24:09 --> Total execution time: 0.3520
INFO - 2022-06-23 06:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:24:09 --> Controller Class Initialized
INFO - 2022-06-23 06:24:09 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:24:09 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:24:09 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:24:09 --> Final output sent to browser
DEBUG - 2022-06-23 06:24:09 --> Total execution time: 0.3593
INFO - 2022-06-23 06:24:20 --> Config Class Initialized
INFO - 2022-06-23 06:24:20 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:24:20 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:24:20 --> Utf8 Class Initialized
INFO - 2022-06-23 06:24:20 --> URI Class Initialized
INFO - 2022-06-23 06:24:20 --> Config Class Initialized
INFO - 2022-06-23 06:24:20 --> Hooks Class Initialized
INFO - 2022-06-23 06:24:20 --> Router Class Initialized
DEBUG - 2022-06-23 06:24:20 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:24:20 --> Output Class Initialized
INFO - 2022-06-23 06:24:20 --> Utf8 Class Initialized
INFO - 2022-06-23 06:24:20 --> URI Class Initialized
INFO - 2022-06-23 06:24:20 --> Security Class Initialized
DEBUG - 2022-06-23 06:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:24:20 --> Router Class Initialized
INFO - 2022-06-23 06:24:20 --> Input Class Initialized
INFO - 2022-06-23 06:24:20 --> Output Class Initialized
INFO - 2022-06-23 06:24:20 --> Language Class Initialized
INFO - 2022-06-23 06:24:20 --> Security Class Initialized
INFO - 2022-06-23 06:24:20 --> Loader Class Initialized
DEBUG - 2022-06-23 06:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:24:20 --> Input Class Initialized
INFO - 2022-06-23 06:24:20 --> Helper loaded: url_helper
INFO - 2022-06-23 06:24:20 --> Language Class Initialized
INFO - 2022-06-23 06:24:20 --> Helper loaded: file_helper
INFO - 2022-06-23 06:24:20 --> Loader Class Initialized
INFO - 2022-06-23 06:24:20 --> Database Driver Class Initialized
INFO - 2022-06-23 06:24:20 --> Helper loaded: url_helper
INFO - 2022-06-23 06:24:20 --> Helper loaded: file_helper
INFO - 2022-06-23 06:24:20 --> Database Driver Class Initialized
INFO - 2022-06-23 06:24:21 --> Email Class Initialized
DEBUG - 2022-06-23 06:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:24:21 --> Controller Class Initialized
INFO - 2022-06-23 06:24:21 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:24:21 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:24:21 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:24:21 --> Final output sent to browser
DEBUG - 2022-06-23 06:24:21 --> Total execution time: 0.1220
INFO - 2022-06-23 06:24:21 --> Email Class Initialized
DEBUG - 2022-06-23 06:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:24:21 --> Controller Class Initialized
INFO - 2022-06-23 06:24:21 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:24:21 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:24:21 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:24:21 --> Final output sent to browser
DEBUG - 2022-06-23 06:24:21 --> Total execution time: 0.1305
INFO - 2022-06-23 06:24:52 --> Config Class Initialized
INFO - 2022-06-23 06:24:52 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:24:52 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:24:52 --> Utf8 Class Initialized
INFO - 2022-06-23 06:24:52 --> URI Class Initialized
INFO - 2022-06-23 06:24:52 --> Router Class Initialized
INFO - 2022-06-23 06:24:52 --> Output Class Initialized
INFO - 2022-06-23 06:24:52 --> Security Class Initialized
DEBUG - 2022-06-23 06:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:24:52 --> Input Class Initialized
INFO - 2022-06-23 06:24:52 --> Language Class Initialized
INFO - 2022-06-23 06:24:52 --> Loader Class Initialized
INFO - 2022-06-23 06:24:52 --> Helper loaded: url_helper
INFO - 2022-06-23 06:24:52 --> Helper loaded: file_helper
INFO - 2022-06-23 06:24:52 --> Database Driver Class Initialized
INFO - 2022-06-23 06:24:52 --> Email Class Initialized
DEBUG - 2022-06-23 06:24:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:24:52 --> Controller Class Initialized
INFO - 2022-06-23 06:24:52 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:24:52 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:24:52 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:24:52 --> Final output sent to browser
DEBUG - 2022-06-23 06:24:52 --> Total execution time: 0.1297
INFO - 2022-06-23 06:25:03 --> Config Class Initialized
INFO - 2022-06-23 06:25:03 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:25:03 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:25:03 --> Utf8 Class Initialized
INFO - 2022-06-23 06:25:03 --> URI Class Initialized
INFO - 2022-06-23 06:25:03 --> Config Class Initialized
INFO - 2022-06-23 06:25:03 --> Router Class Initialized
INFO - 2022-06-23 06:25:03 --> Hooks Class Initialized
INFO - 2022-06-23 06:25:03 --> Output Class Initialized
DEBUG - 2022-06-23 06:25:03 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:25:03 --> Utf8 Class Initialized
INFO - 2022-06-23 06:25:03 --> Security Class Initialized
INFO - 2022-06-23 06:25:03 --> URI Class Initialized
DEBUG - 2022-06-23 06:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:25:03 --> Input Class Initialized
INFO - 2022-06-23 06:25:03 --> Language Class Initialized
INFO - 2022-06-23 06:25:03 --> Router Class Initialized
INFO - 2022-06-23 06:25:03 --> Output Class Initialized
INFO - 2022-06-23 06:25:03 --> Loader Class Initialized
INFO - 2022-06-23 06:25:03 --> Helper loaded: url_helper
INFO - 2022-06-23 06:25:03 --> Security Class Initialized
INFO - 2022-06-23 06:25:03 --> Helper loaded: file_helper
DEBUG - 2022-06-23 06:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:25:03 --> Input Class Initialized
INFO - 2022-06-23 06:25:03 --> Database Driver Class Initialized
INFO - 2022-06-23 06:25:03 --> Language Class Initialized
INFO - 2022-06-23 06:25:03 --> Loader Class Initialized
INFO - 2022-06-23 06:25:03 --> Helper loaded: url_helper
INFO - 2022-06-23 06:25:03 --> Helper loaded: file_helper
INFO - 2022-06-23 06:25:03 --> Email Class Initialized
INFO - 2022-06-23 06:25:03 --> Database Driver Class Initialized
DEBUG - 2022-06-23 06:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:25:03 --> Controller Class Initialized
INFO - 2022-06-23 06:25:03 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:25:03 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:25:03 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
ERROR - 2022-06-23 06:25:03 --> Severity: error --> Exception: Call to undefined function alert() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 42
INFO - 2022-06-23 06:25:03 --> Email Class Initialized
DEBUG - 2022-06-23 06:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:25:03 --> Controller Class Initialized
INFO - 2022-06-23 06:25:03 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:25:03 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:25:03 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:25:03 --> Final output sent to browser
DEBUG - 2022-06-23 06:25:03 --> Total execution time: 0.0476
INFO - 2022-06-23 06:25:15 --> Config Class Initialized
INFO - 2022-06-23 06:25:15 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:25:15 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:25:15 --> Utf8 Class Initialized
INFO - 2022-06-23 06:25:15 --> URI Class Initialized
INFO - 2022-06-23 06:25:15 --> Router Class Initialized
INFO - 2022-06-23 06:25:15 --> Output Class Initialized
INFO - 2022-06-23 06:25:15 --> Security Class Initialized
DEBUG - 2022-06-23 06:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:25:15 --> Input Class Initialized
INFO - 2022-06-23 06:25:15 --> Language Class Initialized
INFO - 2022-06-23 06:25:15 --> Loader Class Initialized
INFO - 2022-06-23 06:25:15 --> Helper loaded: url_helper
INFO - 2022-06-23 06:25:15 --> Helper loaded: file_helper
INFO - 2022-06-23 06:25:15 --> Database Driver Class Initialized
INFO - 2022-06-23 06:25:15 --> Email Class Initialized
DEBUG - 2022-06-23 06:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:25:15 --> Controller Class Initialized
INFO - 2022-06-23 06:25:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:25:15 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:25:15 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:25:15 --> Final output sent to browser
DEBUG - 2022-06-23 06:25:15 --> Total execution time: 0.0211
INFO - 2022-06-23 06:25:25 --> Config Class Initialized
INFO - 2022-06-23 06:25:25 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:25:25 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:25:25 --> Utf8 Class Initialized
INFO - 2022-06-23 06:25:25 --> URI Class Initialized
INFO - 2022-06-23 06:25:25 --> Router Class Initialized
INFO - 2022-06-23 06:25:25 --> Output Class Initialized
INFO - 2022-06-23 06:25:25 --> Security Class Initialized
DEBUG - 2022-06-23 06:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:25:25 --> Input Class Initialized
INFO - 2022-06-23 06:25:25 --> Language Class Initialized
INFO - 2022-06-23 06:25:25 --> Loader Class Initialized
INFO - 2022-06-23 06:25:25 --> Config Class Initialized
INFO - 2022-06-23 06:25:25 --> Hooks Class Initialized
INFO - 2022-06-23 06:25:25 --> Helper loaded: url_helper
DEBUG - 2022-06-23 06:25:25 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:25:25 --> Helper loaded: file_helper
INFO - 2022-06-23 06:25:25 --> Utf8 Class Initialized
INFO - 2022-06-23 06:25:25 --> Database Driver Class Initialized
INFO - 2022-06-23 06:25:25 --> URI Class Initialized
INFO - 2022-06-23 06:25:25 --> Router Class Initialized
INFO - 2022-06-23 06:25:25 --> Output Class Initialized
INFO - 2022-06-23 06:25:25 --> Email Class Initialized
INFO - 2022-06-23 06:25:25 --> Security Class Initialized
DEBUG - 2022-06-23 06:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:25:25 --> Input Class Initialized
DEBUG - 2022-06-23 06:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:25:25 --> Language Class Initialized
INFO - 2022-06-23 06:25:25 --> Loader Class Initialized
INFO - 2022-06-23 06:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:25:25 --> Controller Class Initialized
INFO - 2022-06-23 06:25:25 --> Helper loaded: url_helper
INFO - 2022-06-23 06:25:25 --> Model "Tokenmodel" initialized
INFO - 2022-06-23 06:25:25 --> Helper loaded: file_helper
DEBUG - 2022-06-23 06:25:25 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:25:25 --> Database Driver Class Initialized
INFO - 2022-06-23 06:25:25 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:25:25 --> Final output sent to browser
DEBUG - 2022-06-23 06:25:25 --> Total execution time: 0.0314
INFO - 2022-06-23 06:25:25 --> Email Class Initialized
DEBUG - 2022-06-23 06:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:25:25 --> Controller Class Initialized
INFO - 2022-06-23 06:25:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:25:25 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:25:25 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
ERROR - 2022-06-23 06:25:25 --> Severity: error --> Exception: Call to undefined function alert() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 42
INFO - 2022-06-23 06:25:29 --> Config Class Initialized
INFO - 2022-06-23 06:25:29 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:25:29 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:25:29 --> Utf8 Class Initialized
INFO - 2022-06-23 06:25:29 --> URI Class Initialized
INFO - 2022-06-23 06:25:29 --> Router Class Initialized
INFO - 2022-06-23 06:25:29 --> Output Class Initialized
INFO - 2022-06-23 06:25:29 --> Security Class Initialized
DEBUG - 2022-06-23 06:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:25:29 --> Input Class Initialized
INFO - 2022-06-23 06:25:29 --> Language Class Initialized
INFO - 2022-06-23 06:25:29 --> Loader Class Initialized
INFO - 2022-06-23 06:25:29 --> Helper loaded: url_helper
INFO - 2022-06-23 06:25:29 --> Helper loaded: file_helper
INFO - 2022-06-23 06:25:29 --> Database Driver Class Initialized
INFO - 2022-06-23 06:25:29 --> Email Class Initialized
DEBUG - 2022-06-23 06:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:25:29 --> Controller Class Initialized
INFO - 2022-06-23 06:25:29 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:25:29 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:25:29 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:25:29 --> Final output sent to browser
DEBUG - 2022-06-23 06:25:29 --> Total execution time: 0.0409
INFO - 2022-06-23 06:25:42 --> Config Class Initialized
INFO - 2022-06-23 06:25:42 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:25:42 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:25:42 --> Utf8 Class Initialized
INFO - 2022-06-23 06:25:42 --> Config Class Initialized
INFO - 2022-06-23 06:25:42 --> Hooks Class Initialized
INFO - 2022-06-23 06:25:42 --> URI Class Initialized
DEBUG - 2022-06-23 06:25:42 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:25:42 --> Utf8 Class Initialized
INFO - 2022-06-23 06:25:42 --> Router Class Initialized
INFO - 2022-06-23 06:25:42 --> URI Class Initialized
INFO - 2022-06-23 06:25:42 --> Output Class Initialized
INFO - 2022-06-23 06:25:42 --> Security Class Initialized
DEBUG - 2022-06-23 06:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:25:42 --> Router Class Initialized
INFO - 2022-06-23 06:25:42 --> Input Class Initialized
INFO - 2022-06-23 06:25:42 --> Output Class Initialized
INFO - 2022-06-23 06:25:42 --> Language Class Initialized
INFO - 2022-06-23 06:25:42 --> Security Class Initialized
INFO - 2022-06-23 06:25:42 --> Loader Class Initialized
DEBUG - 2022-06-23 06:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:25:42 --> Input Class Initialized
INFO - 2022-06-23 06:25:42 --> Helper loaded: url_helper
INFO - 2022-06-23 06:25:42 --> Language Class Initialized
INFO - 2022-06-23 06:25:42 --> Helper loaded: file_helper
INFO - 2022-06-23 06:25:42 --> Loader Class Initialized
INFO - 2022-06-23 06:25:42 --> Database Driver Class Initialized
INFO - 2022-06-23 06:25:42 --> Helper loaded: url_helper
INFO - 2022-06-23 06:25:42 --> Helper loaded: file_helper
INFO - 2022-06-23 06:25:42 --> Database Driver Class Initialized
INFO - 2022-06-23 06:25:42 --> Email Class Initialized
DEBUG - 2022-06-23 06:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:25:42 --> Controller Class Initialized
INFO - 2022-06-23 06:25:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:25:42 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:25:42 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:25:42 --> Final output sent to browser
DEBUG - 2022-06-23 06:25:42 --> Total execution time: 0.0301
INFO - 2022-06-23 06:25:42 --> Email Class Initialized
DEBUG - 2022-06-23 06:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:25:42 --> Controller Class Initialized
INFO - 2022-06-23 06:25:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:25:42 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:25:42 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
ERROR - 2022-06-23 06:25:42 --> Severity: error --> Exception: Call to undefined function alert() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 42
INFO - 2022-06-23 06:25:50 --> Config Class Initialized
INFO - 2022-06-23 06:25:50 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:25:50 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:25:50 --> Config Class Initialized
INFO - 2022-06-23 06:25:50 --> Utf8 Class Initialized
INFO - 2022-06-23 06:25:50 --> Hooks Class Initialized
INFO - 2022-06-23 06:25:50 --> URI Class Initialized
DEBUG - 2022-06-23 06:25:50 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:25:50 --> Utf8 Class Initialized
INFO - 2022-06-23 06:25:50 --> Router Class Initialized
INFO - 2022-06-23 06:25:50 --> URI Class Initialized
INFO - 2022-06-23 06:25:50 --> Output Class Initialized
INFO - 2022-06-23 06:25:50 --> Router Class Initialized
INFO - 2022-06-23 06:25:50 --> Security Class Initialized
INFO - 2022-06-23 06:25:50 --> Output Class Initialized
DEBUG - 2022-06-23 06:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:25:50 --> Input Class Initialized
INFO - 2022-06-23 06:25:50 --> Security Class Initialized
INFO - 2022-06-23 06:25:50 --> Language Class Initialized
DEBUG - 2022-06-23 06:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:25:50 --> Input Class Initialized
INFO - 2022-06-23 06:25:50 --> Loader Class Initialized
INFO - 2022-06-23 06:25:50 --> Language Class Initialized
INFO - 2022-06-23 06:25:50 --> Helper loaded: url_helper
INFO - 2022-06-23 06:25:50 --> Loader Class Initialized
INFO - 2022-06-23 06:25:50 --> Helper loaded: file_helper
INFO - 2022-06-23 06:25:50 --> Helper loaded: url_helper
INFO - 2022-06-23 06:25:50 --> Database Driver Class Initialized
INFO - 2022-06-23 06:25:50 --> Helper loaded: file_helper
INFO - 2022-06-23 06:25:50 --> Database Driver Class Initialized
INFO - 2022-06-23 06:25:50 --> Email Class Initialized
DEBUG - 2022-06-23 06:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:25:50 --> Controller Class Initialized
INFO - 2022-06-23 06:25:50 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:25:50 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:25:50 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
ERROR - 2022-06-23 06:25:50 --> Severity: error --> Exception: Call to undefined function alert() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 42
INFO - 2022-06-23 06:25:50 --> Email Class Initialized
DEBUG - 2022-06-23 06:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:25:50 --> Controller Class Initialized
INFO - 2022-06-23 06:25:50 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:25:50 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:25:50 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:25:50 --> Final output sent to browser
DEBUG - 2022-06-23 06:25:50 --> Total execution time: 0.1301
INFO - 2022-06-23 06:26:00 --> Config Class Initialized
INFO - 2022-06-23 06:26:00 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:26:00 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:26:00 --> Utf8 Class Initialized
INFO - 2022-06-23 06:26:00 --> URI Class Initialized
INFO - 2022-06-23 06:26:00 --> Router Class Initialized
INFO - 2022-06-23 06:26:00 --> Output Class Initialized
INFO - 2022-06-23 06:26:00 --> Security Class Initialized
DEBUG - 2022-06-23 06:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:26:00 --> Input Class Initialized
INFO - 2022-06-23 06:26:00 --> Language Class Initialized
INFO - 2022-06-23 06:26:00 --> Loader Class Initialized
INFO - 2022-06-23 06:26:00 --> Helper loaded: url_helper
INFO - 2022-06-23 06:26:00 --> Helper loaded: file_helper
INFO - 2022-06-23 06:26:00 --> Database Driver Class Initialized
INFO - 2022-06-23 06:26:00 --> Email Class Initialized
DEBUG - 2022-06-23 06:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:26:00 --> Controller Class Initialized
INFO - 2022-06-23 06:26:00 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:26:00 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:26:00 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:26:00 --> Final output sent to browser
DEBUG - 2022-06-23 06:26:00 --> Total execution time: 0.0422
INFO - 2022-06-23 06:26:49 --> Config Class Initialized
INFO - 2022-06-23 06:26:49 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:26:49 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:26:49 --> Utf8 Class Initialized
INFO - 2022-06-23 06:26:49 --> URI Class Initialized
INFO - 2022-06-23 06:26:49 --> Config Class Initialized
INFO - 2022-06-23 06:26:49 --> Router Class Initialized
INFO - 2022-06-23 06:26:49 --> Hooks Class Initialized
INFO - 2022-06-23 06:26:49 --> Output Class Initialized
DEBUG - 2022-06-23 06:26:49 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:26:49 --> Utf8 Class Initialized
INFO - 2022-06-23 06:26:49 --> Security Class Initialized
INFO - 2022-06-23 06:26:49 --> URI Class Initialized
DEBUG - 2022-06-23 06:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:26:49 --> Input Class Initialized
INFO - 2022-06-23 06:26:49 --> Router Class Initialized
INFO - 2022-06-23 06:26:49 --> Language Class Initialized
INFO - 2022-06-23 06:26:49 --> Output Class Initialized
INFO - 2022-06-23 06:26:49 --> Loader Class Initialized
INFO - 2022-06-23 06:26:49 --> Security Class Initialized
DEBUG - 2022-06-23 06:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:26:49 --> Helper loaded: url_helper
INFO - 2022-06-23 06:26:49 --> Input Class Initialized
INFO - 2022-06-23 06:26:49 --> Language Class Initialized
INFO - 2022-06-23 06:26:49 --> Helper loaded: file_helper
INFO - 2022-06-23 06:26:49 --> Loader Class Initialized
INFO - 2022-06-23 06:26:49 --> Database Driver Class Initialized
INFO - 2022-06-23 06:26:49 --> Helper loaded: url_helper
INFO - 2022-06-23 06:26:49 --> Helper loaded: file_helper
INFO - 2022-06-23 06:26:49 --> Database Driver Class Initialized
INFO - 2022-06-23 06:26:49 --> Email Class Initialized
DEBUG - 2022-06-23 06:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:26:49 --> Email Class Initialized
INFO - 2022-06-23 06:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:26:49 --> Controller Class Initialized
DEBUG - 2022-06-23 06:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:26:49 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:26:49 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:26:49 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
ERROR - 2022-06-23 06:26:49 --> Severity: error --> Exception: Call to undefined function alert() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 42
INFO - 2022-06-23 06:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:26:49 --> Controller Class Initialized
INFO - 2022-06-23 06:26:49 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:26:49 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:26:49 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:26:49 --> Final output sent to browser
DEBUG - 2022-06-23 06:26:49 --> Total execution time: 0.0315
INFO - 2022-06-23 06:27:22 --> Config Class Initialized
INFO - 2022-06-23 06:27:22 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:27:22 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:27:22 --> Utf8 Class Initialized
INFO - 2022-06-23 06:27:22 --> URI Class Initialized
INFO - 2022-06-23 06:27:22 --> Router Class Initialized
INFO - 2022-06-23 06:27:22 --> Output Class Initialized
INFO - 2022-06-23 06:27:22 --> Security Class Initialized
DEBUG - 2022-06-23 06:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:27:22 --> Input Class Initialized
INFO - 2022-06-23 06:27:22 --> Language Class Initialized
INFO - 2022-06-23 06:27:22 --> Loader Class Initialized
INFO - 2022-06-23 06:27:22 --> Helper loaded: url_helper
INFO - 2022-06-23 06:27:22 --> Helper loaded: file_helper
INFO - 2022-06-23 06:27:22 --> Database Driver Class Initialized
INFO - 2022-06-23 06:27:22 --> Email Class Initialized
DEBUG - 2022-06-23 06:27:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:27:22 --> Controller Class Initialized
INFO - 2022-06-23 06:27:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:27:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:27:22 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:27:22 --> Final output sent to browser
DEBUG - 2022-06-23 06:27:22 --> Total execution time: 0.0275
INFO - 2022-06-23 06:27:32 --> Config Class Initialized
INFO - 2022-06-23 06:27:32 --> Config Class Initialized
INFO - 2022-06-23 06:27:32 --> Hooks Class Initialized
INFO - 2022-06-23 06:27:32 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:27:32 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:27:32 --> Utf8 Class Initialized
INFO - 2022-06-23 06:27:32 --> Utf8 Class Initialized
INFO - 2022-06-23 06:27:32 --> URI Class Initialized
INFO - 2022-06-23 06:27:32 --> URI Class Initialized
INFO - 2022-06-23 06:27:32 --> Router Class Initialized
INFO - 2022-06-23 06:27:32 --> Router Class Initialized
INFO - 2022-06-23 06:27:32 --> Output Class Initialized
INFO - 2022-06-23 06:27:32 --> Output Class Initialized
INFO - 2022-06-23 06:27:32 --> Security Class Initialized
INFO - 2022-06-23 06:27:32 --> Security Class Initialized
DEBUG - 2022-06-23 06:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:27:32 --> Input Class Initialized
INFO - 2022-06-23 06:27:32 --> Input Class Initialized
INFO - 2022-06-23 06:27:32 --> Language Class Initialized
INFO - 2022-06-23 06:27:32 --> Language Class Initialized
INFO - 2022-06-23 06:27:32 --> Loader Class Initialized
INFO - 2022-06-23 06:27:32 --> Loader Class Initialized
INFO - 2022-06-23 06:27:32 --> Helper loaded: url_helper
INFO - 2022-06-23 06:27:32 --> Helper loaded: url_helper
INFO - 2022-06-23 06:27:32 --> Helper loaded: file_helper
INFO - 2022-06-23 06:27:32 --> Helper loaded: file_helper
INFO - 2022-06-23 06:27:32 --> Database Driver Class Initialized
INFO - 2022-06-23 06:27:32 --> Database Driver Class Initialized
INFO - 2022-06-23 06:27:32 --> Email Class Initialized
DEBUG - 2022-06-23 06:27:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:27:32 --> Controller Class Initialized
INFO - 2022-06-23 06:27:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:27:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 06:27:32 --> Severity: error --> Exception: Call to undefined function alert() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 42
INFO - 2022-06-23 06:27:32 --> Email Class Initialized
DEBUG - 2022-06-23 06:27:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:27:32 --> Controller Class Initialized
INFO - 2022-06-23 06:27:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:27:32 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:27:32 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:27:32 --> Final output sent to browser
DEBUG - 2022-06-23 06:27:32 --> Total execution time: 0.0471
INFO - 2022-06-23 06:28:08 --> Config Class Initialized
INFO - 2022-06-23 06:28:08 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:28:08 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:28:08 --> Utf8 Class Initialized
INFO - 2022-06-23 06:28:08 --> URI Class Initialized
INFO - 2022-06-23 06:28:08 --> Router Class Initialized
INFO - 2022-06-23 06:28:08 --> Output Class Initialized
INFO - 2022-06-23 06:28:08 --> Security Class Initialized
DEBUG - 2022-06-23 06:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:28:08 --> Input Class Initialized
INFO - 2022-06-23 06:28:08 --> Language Class Initialized
INFO - 2022-06-23 06:28:08 --> Loader Class Initialized
INFO - 2022-06-23 06:28:08 --> Helper loaded: url_helper
INFO - 2022-06-23 06:28:08 --> Helper loaded: file_helper
INFO - 2022-06-23 06:28:08 --> Database Driver Class Initialized
INFO - 2022-06-23 06:28:08 --> Email Class Initialized
DEBUG - 2022-06-23 06:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:28:08 --> Controller Class Initialized
INFO - 2022-06-23 06:28:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:28:08 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:28:08 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:28:08 --> Final output sent to browser
DEBUG - 2022-06-23 06:28:08 --> Total execution time: 0.1995
INFO - 2022-06-23 06:28:21 --> Config Class Initialized
INFO - 2022-06-23 06:28:21 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:28:21 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:28:21 --> Utf8 Class Initialized
INFO - 2022-06-23 06:28:21 --> Config Class Initialized
INFO - 2022-06-23 06:28:21 --> Hooks Class Initialized
INFO - 2022-06-23 06:28:21 --> URI Class Initialized
DEBUG - 2022-06-23 06:28:21 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:28:21 --> Utf8 Class Initialized
INFO - 2022-06-23 06:28:21 --> Router Class Initialized
INFO - 2022-06-23 06:28:21 --> URI Class Initialized
INFO - 2022-06-23 06:28:21 --> Output Class Initialized
INFO - 2022-06-23 06:28:21 --> Security Class Initialized
INFO - 2022-06-23 06:28:21 --> Router Class Initialized
DEBUG - 2022-06-23 06:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:28:21 --> Input Class Initialized
INFO - 2022-06-23 06:28:21 --> Output Class Initialized
INFO - 2022-06-23 06:28:21 --> Language Class Initialized
INFO - 2022-06-23 06:28:21 --> Security Class Initialized
DEBUG - 2022-06-23 06:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:28:21 --> Loader Class Initialized
INFO - 2022-06-23 06:28:21 --> Input Class Initialized
INFO - 2022-06-23 06:28:21 --> Language Class Initialized
INFO - 2022-06-23 06:28:21 --> Helper loaded: url_helper
INFO - 2022-06-23 06:28:21 --> Helper loaded: file_helper
INFO - 2022-06-23 06:28:21 --> Loader Class Initialized
INFO - 2022-06-23 06:28:21 --> Helper loaded: url_helper
INFO - 2022-06-23 06:28:21 --> Database Driver Class Initialized
INFO - 2022-06-23 06:28:21 --> Helper loaded: file_helper
INFO - 2022-06-23 06:28:21 --> Database Driver Class Initialized
INFO - 2022-06-23 06:28:22 --> Email Class Initialized
DEBUG - 2022-06-23 06:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:28:22 --> Controller Class Initialized
INFO - 2022-06-23 06:28:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:28:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:28:22 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:28:22 --> Final output sent to browser
DEBUG - 2022-06-23 06:28:22 --> Total execution time: 0.3699
INFO - 2022-06-23 06:28:22 --> Email Class Initialized
DEBUG - 2022-06-23 06:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:28:22 --> Controller Class Initialized
INFO - 2022-06-23 06:28:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:28:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:28:22 --> Final output sent to browser
DEBUG - 2022-06-23 06:28:22 --> Total execution time: 0.3933
INFO - 2022-06-23 06:28:29 --> Config Class Initialized
INFO - 2022-06-23 06:28:29 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:28:29 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:28:29 --> Utf8 Class Initialized
INFO - 2022-06-23 06:28:29 --> URI Class Initialized
INFO - 2022-06-23 06:28:29 --> Router Class Initialized
INFO - 2022-06-23 06:28:29 --> Output Class Initialized
INFO - 2022-06-23 06:28:29 --> Security Class Initialized
DEBUG - 2022-06-23 06:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:28:29 --> Input Class Initialized
INFO - 2022-06-23 06:28:29 --> Language Class Initialized
INFO - 2022-06-23 06:28:29 --> Loader Class Initialized
INFO - 2022-06-23 06:28:29 --> Helper loaded: url_helper
INFO - 2022-06-23 06:28:29 --> Helper loaded: file_helper
INFO - 2022-06-23 06:28:29 --> Database Driver Class Initialized
INFO - 2022-06-23 06:28:29 --> Email Class Initialized
DEBUG - 2022-06-23 06:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:28:29 --> Controller Class Initialized
INFO - 2022-06-23 06:28:29 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:28:29 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:28:29 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:28:29 --> Final output sent to browser
DEBUG - 2022-06-23 06:28:29 --> Total execution time: 0.0389
INFO - 2022-06-23 06:28:34 --> Config Class Initialized
INFO - 2022-06-23 06:28:34 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:28:34 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:28:34 --> Utf8 Class Initialized
INFO - 2022-06-23 06:28:34 --> URI Class Initialized
INFO - 2022-06-23 06:28:34 --> Router Class Initialized
INFO - 2022-06-23 06:28:34 --> Output Class Initialized
INFO - 2022-06-23 06:28:34 --> Security Class Initialized
DEBUG - 2022-06-23 06:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:28:34 --> Input Class Initialized
INFO - 2022-06-23 06:28:34 --> Language Class Initialized
INFO - 2022-06-23 06:28:34 --> Loader Class Initialized
INFO - 2022-06-23 06:28:34 --> Helper loaded: url_helper
INFO - 2022-06-23 06:28:34 --> Helper loaded: file_helper
INFO - 2022-06-23 06:28:34 --> Database Driver Class Initialized
INFO - 2022-06-23 06:28:34 --> Email Class Initialized
DEBUG - 2022-06-23 06:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:28:34 --> Controller Class Initialized
INFO - 2022-06-23 06:28:34 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:28:34 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:28:34 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:28:34 --> Final output sent to browser
DEBUG - 2022-06-23 06:28:34 --> Total execution time: 0.0170
INFO - 2022-06-23 06:28:45 --> Config Class Initialized
INFO - 2022-06-23 06:28:45 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:28:45 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:28:45 --> Utf8 Class Initialized
INFO - 2022-06-23 06:28:45 --> URI Class Initialized
INFO - 2022-06-23 06:28:45 --> Router Class Initialized
INFO - 2022-06-23 06:28:45 --> Config Class Initialized
INFO - 2022-06-23 06:28:45 --> Output Class Initialized
INFO - 2022-06-23 06:28:45 --> Hooks Class Initialized
INFO - 2022-06-23 06:28:45 --> Security Class Initialized
DEBUG - 2022-06-23 06:28:45 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:28:45 --> Utf8 Class Initialized
DEBUG - 2022-06-23 06:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:28:45 --> Input Class Initialized
INFO - 2022-06-23 06:28:45 --> URI Class Initialized
INFO - 2022-06-23 06:28:45 --> Language Class Initialized
INFO - 2022-06-23 06:28:45 --> Router Class Initialized
INFO - 2022-06-23 06:28:45 --> Loader Class Initialized
INFO - 2022-06-23 06:28:45 --> Output Class Initialized
INFO - 2022-06-23 06:28:45 --> Helper loaded: url_helper
INFO - 2022-06-23 06:28:45 --> Security Class Initialized
DEBUG - 2022-06-23 06:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:28:45 --> Helper loaded: file_helper
INFO - 2022-06-23 06:28:45 --> Input Class Initialized
INFO - 2022-06-23 06:28:45 --> Language Class Initialized
INFO - 2022-06-23 06:28:45 --> Database Driver Class Initialized
INFO - 2022-06-23 06:28:45 --> Loader Class Initialized
INFO - 2022-06-23 06:28:45 --> Helper loaded: url_helper
INFO - 2022-06-23 06:28:45 --> Email Class Initialized
INFO - 2022-06-23 06:28:45 --> Helper loaded: file_helper
INFO - 2022-06-23 06:28:45 --> Database Driver Class Initialized
DEBUG - 2022-06-23 06:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:28:45 --> Controller Class Initialized
INFO - 2022-06-23 06:28:45 --> Email Class Initialized
INFO - 2022-06-23 06:28:45 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:28:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 06:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:28:45 --> Final output sent to browser
DEBUG - 2022-06-23 06:28:45 --> Total execution time: 0.0321
INFO - 2022-06-23 06:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:28:45 --> Controller Class Initialized
INFO - 2022-06-23 06:28:45 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:28:45 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:28:45 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:28:45 --> Final output sent to browser
DEBUG - 2022-06-23 06:28:45 --> Total execution time: 0.0298
INFO - 2022-06-23 06:29:00 --> Config Class Initialized
INFO - 2022-06-23 06:29:00 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:29:00 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:29:00 --> Utf8 Class Initialized
INFO - 2022-06-23 06:29:00 --> Config Class Initialized
INFO - 2022-06-23 06:29:00 --> Hooks Class Initialized
INFO - 2022-06-23 06:29:00 --> URI Class Initialized
DEBUG - 2022-06-23 06:29:00 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:29:00 --> Utf8 Class Initialized
INFO - 2022-06-23 06:29:00 --> Router Class Initialized
INFO - 2022-06-23 06:29:00 --> URI Class Initialized
INFO - 2022-06-23 06:29:00 --> Output Class Initialized
INFO - 2022-06-23 06:29:00 --> Router Class Initialized
INFO - 2022-06-23 06:29:00 --> Security Class Initialized
INFO - 2022-06-23 06:29:00 --> Output Class Initialized
DEBUG - 2022-06-23 06:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:29:00 --> Input Class Initialized
INFO - 2022-06-23 06:29:00 --> Security Class Initialized
INFO - 2022-06-23 06:29:00 --> Language Class Initialized
DEBUG - 2022-06-23 06:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:29:00 --> Input Class Initialized
INFO - 2022-06-23 06:29:00 --> Loader Class Initialized
INFO - 2022-06-23 06:29:00 --> Language Class Initialized
INFO - 2022-06-23 06:29:00 --> Helper loaded: url_helper
INFO - 2022-06-23 06:29:00 --> Loader Class Initialized
INFO - 2022-06-23 06:29:00 --> Helper loaded: file_helper
INFO - 2022-06-23 06:29:00 --> Helper loaded: url_helper
INFO - 2022-06-23 06:29:00 --> Database Driver Class Initialized
INFO - 2022-06-23 06:29:00 --> Helper loaded: file_helper
INFO - 2022-06-23 06:29:00 --> Database Driver Class Initialized
INFO - 2022-06-23 06:29:01 --> Email Class Initialized
INFO - 2022-06-23 06:29:01 --> Email Class Initialized
DEBUG - 2022-06-23 06:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 06:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:29:01 --> Controller Class Initialized
INFO - 2022-06-23 06:29:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:29:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:29:01 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:29:01 --> Final output sent to browser
DEBUG - 2022-06-23 06:29:01 --> Total execution time: 0.1376
INFO - 2022-06-23 06:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:29:01 --> Controller Class Initialized
INFO - 2022-06-23 06:29:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:29:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:29:01 --> Final output sent to browser
DEBUG - 2022-06-23 06:29:01 --> Total execution time: 0.1438
INFO - 2022-06-23 06:29:25 --> Config Class Initialized
INFO - 2022-06-23 06:29:25 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:29:25 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:29:25 --> Utf8 Class Initialized
INFO - 2022-06-23 06:29:25 --> URI Class Initialized
INFO - 2022-06-23 06:29:25 --> Router Class Initialized
INFO - 2022-06-23 06:29:25 --> Output Class Initialized
INFO - 2022-06-23 06:29:25 --> Security Class Initialized
DEBUG - 2022-06-23 06:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:29:25 --> Input Class Initialized
INFO - 2022-06-23 06:29:25 --> Language Class Initialized
INFO - 2022-06-23 06:29:25 --> Loader Class Initialized
INFO - 2022-06-23 06:29:25 --> Helper loaded: url_helper
INFO - 2022-06-23 06:29:25 --> Helper loaded: file_helper
INFO - 2022-06-23 06:29:25 --> Database Driver Class Initialized
INFO - 2022-06-23 06:29:25 --> Email Class Initialized
DEBUG - 2022-06-23 06:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:29:25 --> Controller Class Initialized
INFO - 2022-06-23 06:29:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:29:25 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:29:25 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:29:25 --> Final output sent to browser
DEBUG - 2022-06-23 06:29:25 --> Total execution time: 0.1183
INFO - 2022-06-23 06:29:35 --> Config Class Initialized
INFO - 2022-06-23 06:29:35 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:29:35 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:29:35 --> Utf8 Class Initialized
INFO - 2022-06-23 06:29:35 --> URI Class Initialized
INFO - 2022-06-23 06:29:35 --> Router Class Initialized
INFO - 2022-06-23 06:29:35 --> Output Class Initialized
INFO - 2022-06-23 06:29:35 --> Security Class Initialized
DEBUG - 2022-06-23 06:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:29:35 --> Input Class Initialized
INFO - 2022-06-23 06:29:35 --> Language Class Initialized
INFO - 2022-06-23 06:29:35 --> Loader Class Initialized
INFO - 2022-06-23 06:29:35 --> Helper loaded: url_helper
INFO - 2022-06-23 06:29:35 --> Helper loaded: file_helper
INFO - 2022-06-23 06:29:35 --> Database Driver Class Initialized
INFO - 2022-06-23 06:29:35 --> Email Class Initialized
DEBUG - 2022-06-23 06:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:29:35 --> Controller Class Initialized
INFO - 2022-06-23 06:29:35 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:29:35 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:29:35 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:29:35 --> Final output sent to browser
DEBUG - 2022-06-23 06:29:35 --> Total execution time: 0.0372
INFO - 2022-06-23 06:29:51 --> Config Class Initialized
INFO - 2022-06-23 06:29:51 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:29:51 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:29:51 --> Config Class Initialized
INFO - 2022-06-23 06:29:51 --> Utf8 Class Initialized
INFO - 2022-06-23 06:29:51 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:29:51 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:29:51 --> URI Class Initialized
INFO - 2022-06-23 06:29:51 --> Utf8 Class Initialized
INFO - 2022-06-23 06:29:51 --> URI Class Initialized
INFO - 2022-06-23 06:29:51 --> Router Class Initialized
INFO - 2022-06-23 06:29:51 --> Router Class Initialized
INFO - 2022-06-23 06:29:51 --> Output Class Initialized
INFO - 2022-06-23 06:29:51 --> Output Class Initialized
INFO - 2022-06-23 06:29:51 --> Security Class Initialized
INFO - 2022-06-23 06:29:51 --> Security Class Initialized
DEBUG - 2022-06-23 06:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:29:51 --> Input Class Initialized
DEBUG - 2022-06-23 06:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:29:51 --> Language Class Initialized
INFO - 2022-06-23 06:29:51 --> Input Class Initialized
INFO - 2022-06-23 06:29:51 --> Language Class Initialized
INFO - 2022-06-23 06:29:51 --> Loader Class Initialized
INFO - 2022-06-23 06:29:51 --> Loader Class Initialized
INFO - 2022-06-23 06:29:51 --> Helper loaded: url_helper
INFO - 2022-06-23 06:29:51 --> Helper loaded: url_helper
INFO - 2022-06-23 06:29:51 --> Helper loaded: file_helper
INFO - 2022-06-23 06:29:51 --> Helper loaded: file_helper
INFO - 2022-06-23 06:29:51 --> Database Driver Class Initialized
INFO - 2022-06-23 06:29:51 --> Database Driver Class Initialized
INFO - 2022-06-23 06:29:51 --> Email Class Initialized
DEBUG - 2022-06-23 06:29:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:29:51 --> Controller Class Initialized
INFO - 2022-06-23 06:29:51 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:29:51 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:29:51 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:29:51 --> Final output sent to browser
DEBUG - 2022-06-23 06:29:51 --> Total execution time: 0.0233
INFO - 2022-06-23 06:29:51 --> Email Class Initialized
DEBUG - 2022-06-23 06:29:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:29:51 --> Controller Class Initialized
INFO - 2022-06-23 06:29:51 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:29:51 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:29:51 --> Final output sent to browser
DEBUG - 2022-06-23 06:29:51 --> Total execution time: 0.0403
INFO - 2022-06-23 06:29:56 --> Config Class Initialized
INFO - 2022-06-23 06:29:56 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:29:56 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:29:56 --> Utf8 Class Initialized
INFO - 2022-06-23 06:29:56 --> URI Class Initialized
INFO - 2022-06-23 06:29:56 --> Router Class Initialized
INFO - 2022-06-23 06:29:56 --> Output Class Initialized
INFO - 2022-06-23 06:29:56 --> Security Class Initialized
DEBUG - 2022-06-23 06:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:29:56 --> Input Class Initialized
INFO - 2022-06-23 06:29:56 --> Language Class Initialized
INFO - 2022-06-23 06:29:56 --> Loader Class Initialized
INFO - 2022-06-23 06:29:56 --> Helper loaded: url_helper
INFO - 2022-06-23 06:29:56 --> Helper loaded: file_helper
INFO - 2022-06-23 06:29:56 --> Database Driver Class Initialized
INFO - 2022-06-23 06:29:56 --> Email Class Initialized
DEBUG - 2022-06-23 06:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:29:56 --> Controller Class Initialized
INFO - 2022-06-23 06:29:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:29:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:29:56 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:29:56 --> Final output sent to browser
DEBUG - 2022-06-23 06:29:56 --> Total execution time: 0.3444
INFO - 2022-06-23 06:30:18 --> Config Class Initialized
INFO - 2022-06-23 06:30:18 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:30:18 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:30:18 --> Config Class Initialized
INFO - 2022-06-23 06:30:18 --> Utf8 Class Initialized
INFO - 2022-06-23 06:30:18 --> Hooks Class Initialized
INFO - 2022-06-23 06:30:18 --> URI Class Initialized
DEBUG - 2022-06-23 06:30:18 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:30:18 --> Utf8 Class Initialized
INFO - 2022-06-23 06:30:18 --> Router Class Initialized
INFO - 2022-06-23 06:30:18 --> URI Class Initialized
INFO - 2022-06-23 06:30:18 --> Output Class Initialized
INFO - 2022-06-23 06:30:18 --> Router Class Initialized
INFO - 2022-06-23 06:30:18 --> Security Class Initialized
INFO - 2022-06-23 06:30:18 --> Output Class Initialized
DEBUG - 2022-06-23 06:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:30:18 --> Security Class Initialized
INFO - 2022-06-23 06:30:18 --> Input Class Initialized
DEBUG - 2022-06-23 06:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:30:18 --> Input Class Initialized
INFO - 2022-06-23 06:30:18 --> Language Class Initialized
INFO - 2022-06-23 06:30:18 --> Language Class Initialized
INFO - 2022-06-23 06:30:18 --> Loader Class Initialized
INFO - 2022-06-23 06:30:18 --> Loader Class Initialized
INFO - 2022-06-23 06:30:18 --> Helper loaded: url_helper
INFO - 2022-06-23 06:30:18 --> Helper loaded: url_helper
INFO - 2022-06-23 06:30:18 --> Helper loaded: file_helper
INFO - 2022-06-23 06:30:18 --> Helper loaded: file_helper
INFO - 2022-06-23 06:30:18 --> Database Driver Class Initialized
INFO - 2022-06-23 06:30:18 --> Database Driver Class Initialized
INFO - 2022-06-23 06:30:18 --> Email Class Initialized
INFO - 2022-06-23 06:30:18 --> Email Class Initialized
DEBUG - 2022-06-23 06:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 06:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:30:18 --> Controller Class Initialized
INFO - 2022-06-23 06:30:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:30:18 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:30:18 --> Final output sent to browser
DEBUG - 2022-06-23 06:30:18 --> Total execution time: 0.0267
INFO - 2022-06-23 06:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:30:18 --> Controller Class Initialized
INFO - 2022-06-23 06:30:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:30:18 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:30:18 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:30:18 --> Final output sent to browser
DEBUG - 2022-06-23 06:30:18 --> Total execution time: 0.0309
INFO - 2022-06-23 06:30:32 --> Config Class Initialized
INFO - 2022-06-23 06:30:32 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:30:32 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:30:32 --> Utf8 Class Initialized
INFO - 2022-06-23 06:30:32 --> Config Class Initialized
INFO - 2022-06-23 06:30:32 --> Hooks Class Initialized
INFO - 2022-06-23 06:30:32 --> URI Class Initialized
DEBUG - 2022-06-23 06:30:32 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:30:32 --> Router Class Initialized
INFO - 2022-06-23 06:30:32 --> Utf8 Class Initialized
INFO - 2022-06-23 06:30:32 --> URI Class Initialized
INFO - 2022-06-23 06:30:32 --> Output Class Initialized
INFO - 2022-06-23 06:30:32 --> Router Class Initialized
INFO - 2022-06-23 06:30:32 --> Security Class Initialized
DEBUG - 2022-06-23 06:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:30:32 --> Output Class Initialized
INFO - 2022-06-23 06:30:32 --> Input Class Initialized
INFO - 2022-06-23 06:30:32 --> Security Class Initialized
INFO - 2022-06-23 06:30:32 --> Language Class Initialized
DEBUG - 2022-06-23 06:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:30:32 --> Input Class Initialized
INFO - 2022-06-23 06:30:32 --> Loader Class Initialized
INFO - 2022-06-23 06:30:32 --> Language Class Initialized
INFO - 2022-06-23 06:30:32 --> Helper loaded: url_helper
INFO - 2022-06-23 06:30:32 --> Loader Class Initialized
INFO - 2022-06-23 06:30:32 --> Helper loaded: file_helper
INFO - 2022-06-23 06:30:32 --> Database Driver Class Initialized
INFO - 2022-06-23 06:30:32 --> Helper loaded: url_helper
INFO - 2022-06-23 06:30:32 --> Helper loaded: file_helper
INFO - 2022-06-23 06:30:32 --> Database Driver Class Initialized
INFO - 2022-06-23 06:30:32 --> Email Class Initialized
INFO - 2022-06-23 06:30:32 --> Email Class Initialized
DEBUG - 2022-06-23 06:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 06:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:30:32 --> Controller Class Initialized
INFO - 2022-06-23 06:30:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:30:32 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:30:32 --> Final output sent to browser
DEBUG - 2022-06-23 06:30:32 --> Total execution time: 0.0246
INFO - 2022-06-23 06:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:30:32 --> Controller Class Initialized
INFO - 2022-06-23 06:30:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:30:32 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:30:32 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:30:32 --> Final output sent to browser
DEBUG - 2022-06-23 06:30:32 --> Total execution time: 0.0299
INFO - 2022-06-23 06:31:20 --> Config Class Initialized
INFO - 2022-06-23 06:31:20 --> Config Class Initialized
INFO - 2022-06-23 06:31:20 --> Hooks Class Initialized
INFO - 2022-06-23 06:31:20 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:31:20 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:31:20 --> Utf8 Class Initialized
INFO - 2022-06-23 06:31:20 --> Utf8 Class Initialized
INFO - 2022-06-23 06:31:20 --> URI Class Initialized
INFO - 2022-06-23 06:31:20 --> URI Class Initialized
INFO - 2022-06-23 06:31:20 --> Router Class Initialized
INFO - 2022-06-23 06:31:20 --> Router Class Initialized
INFO - 2022-06-23 06:31:20 --> Output Class Initialized
INFO - 2022-06-23 06:31:20 --> Output Class Initialized
INFO - 2022-06-23 06:31:20 --> Security Class Initialized
INFO - 2022-06-23 06:31:20 --> Security Class Initialized
DEBUG - 2022-06-23 06:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:31:20 --> Input Class Initialized
INFO - 2022-06-23 06:31:20 --> Input Class Initialized
INFO - 2022-06-23 06:31:20 --> Language Class Initialized
INFO - 2022-06-23 06:31:20 --> Language Class Initialized
INFO - 2022-06-23 06:31:20 --> Loader Class Initialized
INFO - 2022-06-23 06:31:20 --> Loader Class Initialized
INFO - 2022-06-23 06:31:20 --> Helper loaded: url_helper
INFO - 2022-06-23 06:31:20 --> Helper loaded: url_helper
INFO - 2022-06-23 06:31:20 --> Helper loaded: file_helper
INFO - 2022-06-23 06:31:20 --> Helper loaded: file_helper
INFO - 2022-06-23 06:31:20 --> Database Driver Class Initialized
INFO - 2022-06-23 06:31:20 --> Database Driver Class Initialized
INFO - 2022-06-23 06:31:20 --> Email Class Initialized
DEBUG - 2022-06-23 06:31:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:31:20 --> Controller Class Initialized
INFO - 2022-06-23 06:31:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:31:20 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:31:20 --> Final output sent to browser
DEBUG - 2022-06-23 06:31:20 --> Total execution time: 0.0443
INFO - 2022-06-23 06:31:20 --> Email Class Initialized
DEBUG - 2022-06-23 06:31:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:31:20 --> Controller Class Initialized
INFO - 2022-06-23 06:31:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:31:20 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:31:20 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:31:20 --> Final output sent to browser
DEBUG - 2022-06-23 06:31:20 --> Total execution time: 0.3456
INFO - 2022-06-23 06:31:26 --> Config Class Initialized
INFO - 2022-06-23 06:31:26 --> Hooks Class Initialized
INFO - 2022-06-23 06:31:26 --> Config Class Initialized
INFO - 2022-06-23 06:31:26 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:31:26 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:31:26 --> Utf8 Class Initialized
DEBUG - 2022-06-23 06:31:26 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:31:26 --> Utf8 Class Initialized
INFO - 2022-06-23 06:31:26 --> URI Class Initialized
INFO - 2022-06-23 06:31:26 --> URI Class Initialized
INFO - 2022-06-23 06:31:26 --> Router Class Initialized
INFO - 2022-06-23 06:31:26 --> Router Class Initialized
INFO - 2022-06-23 06:31:26 --> Output Class Initialized
INFO - 2022-06-23 06:31:26 --> Output Class Initialized
INFO - 2022-06-23 06:31:26 --> Security Class Initialized
INFO - 2022-06-23 06:31:26 --> Security Class Initialized
DEBUG - 2022-06-23 06:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:31:26 --> Input Class Initialized
INFO - 2022-06-23 06:31:26 --> Input Class Initialized
INFO - 2022-06-23 06:31:26 --> Language Class Initialized
INFO - 2022-06-23 06:31:26 --> Language Class Initialized
INFO - 2022-06-23 06:31:26 --> Loader Class Initialized
INFO - 2022-06-23 06:31:26 --> Loader Class Initialized
INFO - 2022-06-23 06:31:26 --> Helper loaded: url_helper
INFO - 2022-06-23 06:31:26 --> Helper loaded: url_helper
INFO - 2022-06-23 06:31:26 --> Helper loaded: file_helper
INFO - 2022-06-23 06:31:26 --> Helper loaded: file_helper
INFO - 2022-06-23 06:31:26 --> Database Driver Class Initialized
INFO - 2022-06-23 06:31:26 --> Database Driver Class Initialized
INFO - 2022-06-23 06:31:26 --> Email Class Initialized
INFO - 2022-06-23 06:31:26 --> Email Class Initialized
DEBUG - 2022-06-23 06:31:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 06:31:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:31:26 --> Controller Class Initialized
INFO - 2022-06-23 06:31:26 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:31:26 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:31:26 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:31:26 --> Final output sent to browser
DEBUG - 2022-06-23 06:31:26 --> Total execution time: 0.0350
INFO - 2022-06-23 06:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:31:27 --> Controller Class Initialized
INFO - 2022-06-23 06:31:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:31:27 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:31:27 --> Final output sent to browser
DEBUG - 2022-06-23 06:31:27 --> Total execution time: 0.0401
INFO - 2022-06-23 06:31:50 --> Config Class Initialized
INFO - 2022-06-23 06:31:50 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:31:50 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:31:50 --> Utf8 Class Initialized
INFO - 2022-06-23 06:31:50 --> URI Class Initialized
INFO - 2022-06-23 06:31:50 --> Router Class Initialized
INFO - 2022-06-23 06:31:50 --> Output Class Initialized
INFO - 2022-06-23 06:31:50 --> Security Class Initialized
DEBUG - 2022-06-23 06:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:31:50 --> Input Class Initialized
INFO - 2022-06-23 06:31:50 --> Language Class Initialized
INFO - 2022-06-23 06:31:50 --> Loader Class Initialized
INFO - 2022-06-23 06:31:50 --> Helper loaded: url_helper
INFO - 2022-06-23 06:31:50 --> Helper loaded: file_helper
INFO - 2022-06-23 06:31:50 --> Database Driver Class Initialized
INFO - 2022-06-23 06:31:50 --> Email Class Initialized
DEBUG - 2022-06-23 06:31:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:31:50 --> Controller Class Initialized
INFO - 2022-06-23 06:31:50 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:31:50 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:31:50 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:31:50 --> Final output sent to browser
DEBUG - 2022-06-23 06:31:50 --> Total execution time: 0.0193
INFO - 2022-06-23 06:31:55 --> Config Class Initialized
INFO - 2022-06-23 06:31:55 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:31:55 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:31:55 --> Utf8 Class Initialized
INFO - 2022-06-23 06:31:55 --> URI Class Initialized
INFO - 2022-06-23 06:31:55 --> Router Class Initialized
INFO - 2022-06-23 06:31:55 --> Output Class Initialized
INFO - 2022-06-23 06:31:55 --> Security Class Initialized
DEBUG - 2022-06-23 06:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:31:55 --> Input Class Initialized
INFO - 2022-06-23 06:31:55 --> Language Class Initialized
INFO - 2022-06-23 06:31:55 --> Loader Class Initialized
INFO - 2022-06-23 06:31:55 --> Helper loaded: url_helper
INFO - 2022-06-23 06:31:55 --> Helper loaded: file_helper
INFO - 2022-06-23 06:31:55 --> Database Driver Class Initialized
INFO - 2022-06-23 06:31:55 --> Email Class Initialized
DEBUG - 2022-06-23 06:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:31:55 --> Controller Class Initialized
INFO - 2022-06-23 06:31:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:31:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:31:55 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:31:55 --> Final output sent to browser
DEBUG - 2022-06-23 06:31:55 --> Total execution time: 0.0447
INFO - 2022-06-23 06:32:15 --> Config Class Initialized
INFO - 2022-06-23 06:32:15 --> Hooks Class Initialized
INFO - 2022-06-23 06:32:15 --> Config Class Initialized
DEBUG - 2022-06-23 06:32:15 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:32:15 --> Utf8 Class Initialized
INFO - 2022-06-23 06:32:15 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:32:15 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:32:15 --> URI Class Initialized
INFO - 2022-06-23 06:32:15 --> Utf8 Class Initialized
INFO - 2022-06-23 06:32:15 --> URI Class Initialized
INFO - 2022-06-23 06:32:15 --> Router Class Initialized
INFO - 2022-06-23 06:32:15 --> Output Class Initialized
INFO - 2022-06-23 06:32:15 --> Router Class Initialized
INFO - 2022-06-23 06:32:15 --> Security Class Initialized
INFO - 2022-06-23 06:32:15 --> Output Class Initialized
INFO - 2022-06-23 06:32:15 --> Security Class Initialized
DEBUG - 2022-06-23 06:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:32:15 --> Input Class Initialized
DEBUG - 2022-06-23 06:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:32:15 --> Language Class Initialized
INFO - 2022-06-23 06:32:15 --> Input Class Initialized
INFO - 2022-06-23 06:32:15 --> Language Class Initialized
INFO - 2022-06-23 06:32:15 --> Loader Class Initialized
INFO - 2022-06-23 06:32:15 --> Loader Class Initialized
INFO - 2022-06-23 06:32:15 --> Helper loaded: url_helper
INFO - 2022-06-23 06:32:15 --> Helper loaded: url_helper
INFO - 2022-06-23 06:32:15 --> Helper loaded: file_helper
INFO - 2022-06-23 06:32:15 --> Helper loaded: file_helper
INFO - 2022-06-23 06:32:15 --> Database Driver Class Initialized
INFO - 2022-06-23 06:32:15 --> Database Driver Class Initialized
INFO - 2022-06-23 06:32:15 --> Email Class Initialized
INFO - 2022-06-23 06:32:15 --> Email Class Initialized
DEBUG - 2022-06-23 06:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 06:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:32:15 --> Controller Class Initialized
INFO - 2022-06-23 06:32:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:32:15 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:32:15 --> Final output sent to browser
DEBUG - 2022-06-23 06:32:15 --> Total execution time: 0.0287
INFO - 2022-06-23 06:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:32:15 --> Controller Class Initialized
INFO - 2022-06-23 06:32:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:32:15 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:32:15 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:32:15 --> Final output sent to browser
DEBUG - 2022-06-23 06:32:15 --> Total execution time: 0.0308
INFO - 2022-06-23 06:32:28 --> Config Class Initialized
INFO - 2022-06-23 06:32:28 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:32:28 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:32:28 --> Utf8 Class Initialized
INFO - 2022-06-23 06:32:28 --> Config Class Initialized
INFO - 2022-06-23 06:32:28 --> URI Class Initialized
INFO - 2022-06-23 06:32:28 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:32:28 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:32:28 --> Router Class Initialized
INFO - 2022-06-23 06:32:28 --> Utf8 Class Initialized
INFO - 2022-06-23 06:32:28 --> Output Class Initialized
INFO - 2022-06-23 06:32:28 --> URI Class Initialized
INFO - 2022-06-23 06:32:28 --> Security Class Initialized
DEBUG - 2022-06-23 06:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:32:28 --> Router Class Initialized
INFO - 2022-06-23 06:32:28 --> Input Class Initialized
INFO - 2022-06-23 06:32:28 --> Output Class Initialized
INFO - 2022-06-23 06:32:28 --> Language Class Initialized
INFO - 2022-06-23 06:32:28 --> Security Class Initialized
INFO - 2022-06-23 06:32:28 --> Loader Class Initialized
DEBUG - 2022-06-23 06:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:32:28 --> Input Class Initialized
INFO - 2022-06-23 06:32:28 --> Helper loaded: url_helper
INFO - 2022-06-23 06:32:28 --> Language Class Initialized
INFO - 2022-06-23 06:32:28 --> Helper loaded: file_helper
INFO - 2022-06-23 06:32:28 --> Loader Class Initialized
INFO - 2022-06-23 06:32:28 --> Database Driver Class Initialized
INFO - 2022-06-23 06:32:28 --> Helper loaded: url_helper
INFO - 2022-06-23 06:32:28 --> Helper loaded: file_helper
INFO - 2022-06-23 06:32:28 --> Database Driver Class Initialized
INFO - 2022-06-23 06:32:28 --> Email Class Initialized
DEBUG - 2022-06-23 06:32:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:32:28 --> Email Class Initialized
INFO - 2022-06-23 06:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:32:28 --> Controller Class Initialized
DEBUG - 2022-06-23 06:32:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:32:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:32:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:32:28 --> Final output sent to browser
DEBUG - 2022-06-23 06:32:28 --> Total execution time: 0.0228
INFO - 2022-06-23 06:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:32:28 --> Controller Class Initialized
INFO - 2022-06-23 06:32:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:32:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:32:28 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:32:28 --> Final output sent to browser
DEBUG - 2022-06-23 06:32:28 --> Total execution time: 0.0249
INFO - 2022-06-23 06:34:25 --> Config Class Initialized
INFO - 2022-06-23 06:34:25 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:34:25 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:34:25 --> Utf8 Class Initialized
INFO - 2022-06-23 06:34:25 --> URI Class Initialized
INFO - 2022-06-23 06:34:25 --> Router Class Initialized
INFO - 2022-06-23 06:34:25 --> Output Class Initialized
INFO - 2022-06-23 06:34:25 --> Security Class Initialized
DEBUG - 2022-06-23 06:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:34:25 --> Input Class Initialized
INFO - 2022-06-23 06:34:25 --> Language Class Initialized
INFO - 2022-06-23 06:34:25 --> Loader Class Initialized
INFO - 2022-06-23 06:34:25 --> Helper loaded: url_helper
INFO - 2022-06-23 06:34:25 --> Helper loaded: file_helper
INFO - 2022-06-23 06:34:25 --> Database Driver Class Initialized
INFO - 2022-06-23 06:34:26 --> Email Class Initialized
DEBUG - 2022-06-23 06:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:34:26 --> Controller Class Initialized
INFO - 2022-06-23 06:34:26 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:34:26 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:34:26 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:34:26 --> Final output sent to browser
DEBUG - 2022-06-23 06:34:26 --> Total execution time: 0.0333
INFO - 2022-06-23 06:34:39 --> Config Class Initialized
INFO - 2022-06-23 06:34:39 --> Hooks Class Initialized
INFO - 2022-06-23 06:34:39 --> Config Class Initialized
INFO - 2022-06-23 06:34:39 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:34:39 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:34:39 --> Utf8 Class Initialized
DEBUG - 2022-06-23 06:34:39 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:34:39 --> Utf8 Class Initialized
INFO - 2022-06-23 06:34:39 --> URI Class Initialized
INFO - 2022-06-23 06:34:39 --> URI Class Initialized
INFO - 2022-06-23 06:34:39 --> Router Class Initialized
INFO - 2022-06-23 06:34:39 --> Router Class Initialized
INFO - 2022-06-23 06:34:39 --> Output Class Initialized
INFO - 2022-06-23 06:34:39 --> Output Class Initialized
INFO - 2022-06-23 06:34:39 --> Security Class Initialized
INFO - 2022-06-23 06:34:39 --> Security Class Initialized
DEBUG - 2022-06-23 06:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:34:39 --> Input Class Initialized
DEBUG - 2022-06-23 06:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:34:39 --> Input Class Initialized
INFO - 2022-06-23 06:34:39 --> Language Class Initialized
INFO - 2022-06-23 06:34:39 --> Language Class Initialized
INFO - 2022-06-23 06:34:39 --> Loader Class Initialized
INFO - 2022-06-23 06:34:39 --> Loader Class Initialized
INFO - 2022-06-23 06:34:39 --> Helper loaded: url_helper
INFO - 2022-06-23 06:34:39 --> Helper loaded: url_helper
INFO - 2022-06-23 06:34:39 --> Helper loaded: file_helper
INFO - 2022-06-23 06:34:39 --> Helper loaded: file_helper
INFO - 2022-06-23 06:34:39 --> Database Driver Class Initialized
INFO - 2022-06-23 06:34:39 --> Database Driver Class Initialized
INFO - 2022-06-23 06:34:40 --> Email Class Initialized
DEBUG - 2022-06-23 06:34:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:34:40 --> Controller Class Initialized
INFO - 2022-06-23 06:34:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:34:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 06:34:40 --> Severity: error --> Exception: Call to undefined function alert() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 42
INFO - 2022-06-23 06:34:40 --> Email Class Initialized
DEBUG - 2022-06-23 06:34:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:34:40 --> Controller Class Initialized
INFO - 2022-06-23 06:34:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:34:40 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:34:40 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:34:40 --> Final output sent to browser
DEBUG - 2022-06-23 06:34:40 --> Total execution time: 0.3709
INFO - 2022-06-23 06:35:57 --> Config Class Initialized
INFO - 2022-06-23 06:35:57 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:35:57 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:35:57 --> Utf8 Class Initialized
INFO - 2022-06-23 06:35:57 --> URI Class Initialized
INFO - 2022-06-23 06:35:57 --> Router Class Initialized
INFO - 2022-06-23 06:35:57 --> Output Class Initialized
INFO - 2022-06-23 06:35:57 --> Security Class Initialized
DEBUG - 2022-06-23 06:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:35:57 --> Input Class Initialized
INFO - 2022-06-23 06:35:57 --> Language Class Initialized
INFO - 2022-06-23 06:35:57 --> Loader Class Initialized
INFO - 2022-06-23 06:35:57 --> Helper loaded: url_helper
INFO - 2022-06-23 06:35:57 --> Helper loaded: file_helper
INFO - 2022-06-23 06:35:57 --> Database Driver Class Initialized
INFO - 2022-06-23 06:35:57 --> Email Class Initialized
DEBUG - 2022-06-23 06:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:35:57 --> Controller Class Initialized
INFO - 2022-06-23 06:35:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:35:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:35:57 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:35:57 --> Final output sent to browser
DEBUG - 2022-06-23 06:35:57 --> Total execution time: 0.0277
INFO - 2022-06-23 06:36:10 --> Config Class Initialized
INFO - 2022-06-23 06:36:10 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:36:10 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:36:10 --> Utf8 Class Initialized
INFO - 2022-06-23 06:36:10 --> URI Class Initialized
INFO - 2022-06-23 06:36:10 --> Router Class Initialized
INFO - 2022-06-23 06:36:10 --> Output Class Initialized
INFO - 2022-06-23 06:36:10 --> Config Class Initialized
INFO - 2022-06-23 06:36:10 --> Security Class Initialized
INFO - 2022-06-23 06:36:10 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:36:10 --> Input Class Initialized
DEBUG - 2022-06-23 06:36:10 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:36:10 --> Utf8 Class Initialized
INFO - 2022-06-23 06:36:10 --> Language Class Initialized
INFO - 2022-06-23 06:36:10 --> URI Class Initialized
INFO - 2022-06-23 06:36:10 --> Loader Class Initialized
INFO - 2022-06-23 06:36:10 --> Router Class Initialized
INFO - 2022-06-23 06:36:10 --> Helper loaded: url_helper
INFO - 2022-06-23 06:36:10 --> Output Class Initialized
INFO - 2022-06-23 06:36:10 --> Helper loaded: file_helper
INFO - 2022-06-23 06:36:10 --> Security Class Initialized
INFO - 2022-06-23 06:36:10 --> Database Driver Class Initialized
DEBUG - 2022-06-23 06:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:36:10 --> Input Class Initialized
INFO - 2022-06-23 06:36:10 --> Language Class Initialized
INFO - 2022-06-23 06:36:10 --> Loader Class Initialized
INFO - 2022-06-23 06:36:10 --> Email Class Initialized
INFO - 2022-06-23 06:36:10 --> Helper loaded: url_helper
DEBUG - 2022-06-23 06:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:36:10 --> Helper loaded: file_helper
INFO - 2022-06-23 06:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:36:10 --> Database Driver Class Initialized
INFO - 2022-06-23 06:36:10 --> Controller Class Initialized
INFO - 2022-06-23 06:36:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:36:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 06:36:10 --> Severity: error --> Exception: Call to undefined function alert() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 42
INFO - 2022-06-23 06:36:10 --> Email Class Initialized
DEBUG - 2022-06-23 06:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:36:10 --> Controller Class Initialized
INFO - 2022-06-23 06:36:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:36:10 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:36:10 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:36:10 --> Final output sent to browser
DEBUG - 2022-06-23 06:36:10 --> Total execution time: 0.0310
INFO - 2022-06-23 06:36:17 --> Config Class Initialized
INFO - 2022-06-23 06:36:17 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:36:17 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:36:17 --> Utf8 Class Initialized
INFO - 2022-06-23 06:36:17 --> URI Class Initialized
INFO - 2022-06-23 06:36:17 --> Router Class Initialized
INFO - 2022-06-23 06:36:17 --> Output Class Initialized
INFO - 2022-06-23 06:36:17 --> Security Class Initialized
DEBUG - 2022-06-23 06:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:36:17 --> Input Class Initialized
INFO - 2022-06-23 06:36:17 --> Language Class Initialized
INFO - 2022-06-23 06:36:17 --> Loader Class Initialized
INFO - 2022-06-23 06:36:17 --> Helper loaded: url_helper
INFO - 2022-06-23 06:36:17 --> Helper loaded: file_helper
INFO - 2022-06-23 06:36:17 --> Database Driver Class Initialized
INFO - 2022-06-23 06:36:17 --> Email Class Initialized
DEBUG - 2022-06-23 06:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:36:17 --> Controller Class Initialized
INFO - 2022-06-23 06:36:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:36:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:36:17 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:36:17 --> Final output sent to browser
DEBUG - 2022-06-23 06:36:17 --> Total execution time: 0.1352
INFO - 2022-06-23 06:36:19 --> Config Class Initialized
INFO - 2022-06-23 06:36:19 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:36:19 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:36:19 --> Utf8 Class Initialized
INFO - 2022-06-23 06:36:19 --> URI Class Initialized
INFO - 2022-06-23 06:36:19 --> Router Class Initialized
INFO - 2022-06-23 06:36:19 --> Output Class Initialized
INFO - 2022-06-23 06:36:19 --> Security Class Initialized
DEBUG - 2022-06-23 06:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:36:19 --> Input Class Initialized
INFO - 2022-06-23 06:36:19 --> Language Class Initialized
INFO - 2022-06-23 06:36:19 --> Loader Class Initialized
INFO - 2022-06-23 06:36:19 --> Helper loaded: url_helper
INFO - 2022-06-23 06:36:19 --> Helper loaded: file_helper
INFO - 2022-06-23 06:36:19 --> Database Driver Class Initialized
INFO - 2022-06-23 06:36:19 --> Email Class Initialized
DEBUG - 2022-06-23 06:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:36:19 --> Controller Class Initialized
INFO - 2022-06-23 06:36:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:36:19 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:36:19 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:36:19 --> Final output sent to browser
DEBUG - 2022-06-23 06:36:19 --> Total execution time: 0.0200
INFO - 2022-06-23 06:36:38 --> Config Class Initialized
INFO - 2022-06-23 06:36:38 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:36:38 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:36:38 --> Utf8 Class Initialized
INFO - 2022-06-23 06:36:38 --> URI Class Initialized
INFO - 2022-06-23 06:36:38 --> Router Class Initialized
INFO - 2022-06-23 06:36:38 --> Config Class Initialized
INFO - 2022-06-23 06:36:38 --> Output Class Initialized
INFO - 2022-06-23 06:36:38 --> Hooks Class Initialized
INFO - 2022-06-23 06:36:38 --> Security Class Initialized
DEBUG - 2022-06-23 06:36:38 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:36:38 --> Utf8 Class Initialized
DEBUG - 2022-06-23 06:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:36:38 --> URI Class Initialized
INFO - 2022-06-23 06:36:38 --> Input Class Initialized
INFO - 2022-06-23 06:36:38 --> Router Class Initialized
INFO - 2022-06-23 06:36:38 --> Language Class Initialized
INFO - 2022-06-23 06:36:38 --> Output Class Initialized
INFO - 2022-06-23 06:36:38 --> Loader Class Initialized
INFO - 2022-06-23 06:36:38 --> Security Class Initialized
INFO - 2022-06-23 06:36:38 --> Helper loaded: url_helper
DEBUG - 2022-06-23 06:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:36:38 --> Input Class Initialized
INFO - 2022-06-23 06:36:38 --> Helper loaded: file_helper
INFO - 2022-06-23 06:36:38 --> Language Class Initialized
INFO - 2022-06-23 06:36:38 --> Database Driver Class Initialized
INFO - 2022-06-23 06:36:38 --> Loader Class Initialized
INFO - 2022-06-23 06:36:38 --> Helper loaded: url_helper
INFO - 2022-06-23 06:36:38 --> Helper loaded: file_helper
INFO - 2022-06-23 06:36:38 --> Email Class Initialized
INFO - 2022-06-23 06:36:38 --> Database Driver Class Initialized
DEBUG - 2022-06-23 06:36:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:36:38 --> Email Class Initialized
INFO - 2022-06-23 06:36:38 --> Controller Class Initialized
INFO - 2022-06-23 06:36:38 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:36:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 06:36:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 06:36:38 --> Severity: error --> Exception: Call to undefined function alert() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 42
INFO - 2022-06-23 06:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:36:38 --> Controller Class Initialized
INFO - 2022-06-23 06:36:38 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:36:38 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:36:38 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:36:38 --> Final output sent to browser
DEBUG - 2022-06-23 06:36:38 --> Total execution time: 0.0295
INFO - 2022-06-23 06:38:56 --> Config Class Initialized
INFO - 2022-06-23 06:38:56 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:38:56 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:38:56 --> Utf8 Class Initialized
INFO - 2022-06-23 06:38:56 --> URI Class Initialized
INFO - 2022-06-23 06:38:56 --> Router Class Initialized
INFO - 2022-06-23 06:38:56 --> Output Class Initialized
INFO - 2022-06-23 06:38:56 --> Security Class Initialized
DEBUG - 2022-06-23 06:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:38:56 --> Input Class Initialized
INFO - 2022-06-23 06:38:56 --> Language Class Initialized
ERROR - 2022-06-23 06:38:56 --> Severity: error --> Exception: syntax error, unexpected ';', expecting '{' C:\wamp64\www\qr\application\controllers\Tokenctrl.php 39
INFO - 2022-06-23 06:39:39 --> Config Class Initialized
INFO - 2022-06-23 06:39:39 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:39:39 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:39:39 --> Utf8 Class Initialized
INFO - 2022-06-23 06:39:39 --> URI Class Initialized
INFO - 2022-06-23 06:39:39 --> Router Class Initialized
INFO - 2022-06-23 06:39:39 --> Output Class Initialized
INFO - 2022-06-23 06:39:39 --> Security Class Initialized
DEBUG - 2022-06-23 06:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:39:39 --> Input Class Initialized
INFO - 2022-06-23 06:39:39 --> Language Class Initialized
INFO - 2022-06-23 06:39:39 --> Loader Class Initialized
INFO - 2022-06-23 06:39:39 --> Helper loaded: url_helper
INFO - 2022-06-23 06:39:39 --> Helper loaded: file_helper
INFO - 2022-06-23 06:39:39 --> Database Driver Class Initialized
INFO - 2022-06-23 06:39:39 --> Email Class Initialized
DEBUG - 2022-06-23 06:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:39:39 --> Controller Class Initialized
INFO - 2022-06-23 06:39:39 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:39:39 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:39:39 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:39:39 --> Final output sent to browser
DEBUG - 2022-06-23 06:39:39 --> Total execution time: 0.0264
INFO - 2022-06-23 06:39:44 --> Config Class Initialized
INFO - 2022-06-23 06:39:44 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:39:44 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:39:44 --> Utf8 Class Initialized
INFO - 2022-06-23 06:39:44 --> URI Class Initialized
INFO - 2022-06-23 06:39:44 --> Router Class Initialized
INFO - 2022-06-23 06:39:44 --> Output Class Initialized
INFO - 2022-06-23 06:39:44 --> Security Class Initialized
DEBUG - 2022-06-23 06:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:39:44 --> Input Class Initialized
INFO - 2022-06-23 06:39:44 --> Language Class Initialized
INFO - 2022-06-23 06:39:44 --> Loader Class Initialized
INFO - 2022-06-23 06:39:44 --> Helper loaded: url_helper
INFO - 2022-06-23 06:39:44 --> Helper loaded: file_helper
INFO - 2022-06-23 06:39:44 --> Database Driver Class Initialized
INFO - 2022-06-23 06:39:44 --> Email Class Initialized
DEBUG - 2022-06-23 06:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:39:44 --> Controller Class Initialized
INFO - 2022-06-23 06:39:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:39:44 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:39:44 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:39:44 --> Final output sent to browser
DEBUG - 2022-06-23 06:39:44 --> Total execution time: 0.1419
INFO - 2022-06-23 06:39:53 --> Config Class Initialized
INFO - 2022-06-23 06:39:53 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:39:53 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:39:53 --> Utf8 Class Initialized
INFO - 2022-06-23 06:39:53 --> URI Class Initialized
INFO - 2022-06-23 06:39:53 --> Router Class Initialized
INFO - 2022-06-23 06:39:53 --> Output Class Initialized
INFO - 2022-06-23 06:39:53 --> Security Class Initialized
DEBUG - 2022-06-23 06:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:39:53 --> Input Class Initialized
INFO - 2022-06-23 06:39:53 --> Language Class Initialized
INFO - 2022-06-23 06:39:53 --> Loader Class Initialized
INFO - 2022-06-23 06:39:53 --> Helper loaded: url_helper
INFO - 2022-06-23 06:39:53 --> Helper loaded: file_helper
INFO - 2022-06-23 06:39:53 --> Database Driver Class Initialized
INFO - 2022-06-23 06:39:53 --> Config Class Initialized
INFO - 2022-06-23 06:39:53 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:39:53 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:39:53 --> Utf8 Class Initialized
INFO - 2022-06-23 06:39:53 --> URI Class Initialized
INFO - 2022-06-23 06:39:53 --> Router Class Initialized
INFO - 2022-06-23 06:39:53 --> Output Class Initialized
INFO - 2022-06-23 06:39:53 --> Security Class Initialized
DEBUG - 2022-06-23 06:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:39:53 --> Input Class Initialized
INFO - 2022-06-23 06:39:53 --> Language Class Initialized
INFO - 2022-06-23 06:39:53 --> Loader Class Initialized
INFO - 2022-06-23 06:39:53 --> Helper loaded: url_helper
INFO - 2022-06-23 06:39:53 --> Helper loaded: file_helper
INFO - 2022-06-23 06:39:53 --> Database Driver Class Initialized
INFO - 2022-06-23 06:39:53 --> Email Class Initialized
DEBUG - 2022-06-23 06:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:39:53 --> Controller Class Initialized
INFO - 2022-06-23 06:39:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:39:53 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:39:53 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:39:53 --> Final output sent to browser
DEBUG - 2022-06-23 06:39:53 --> Total execution time: 0.0257
INFO - 2022-06-23 06:39:53 --> Email Class Initialized
DEBUG - 2022-06-23 06:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:39:53 --> Controller Class Initialized
INFO - 2022-06-23 06:39:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:39:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 06:39:53 --> Severity: error --> Exception: Call to undefined function check() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 39
INFO - 2022-06-23 06:40:12 --> Config Class Initialized
INFO - 2022-06-23 06:40:12 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:40:12 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:40:12 --> Utf8 Class Initialized
INFO - 2022-06-23 06:40:12 --> URI Class Initialized
INFO - 2022-06-23 06:40:12 --> Router Class Initialized
INFO - 2022-06-23 06:40:12 --> Output Class Initialized
INFO - 2022-06-23 06:40:12 --> Security Class Initialized
DEBUG - 2022-06-23 06:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:40:12 --> Input Class Initialized
INFO - 2022-06-23 06:40:12 --> Language Class Initialized
INFO - 2022-06-23 06:40:12 --> Loader Class Initialized
INFO - 2022-06-23 06:40:12 --> Helper loaded: url_helper
INFO - 2022-06-23 06:40:12 --> Helper loaded: file_helper
INFO - 2022-06-23 06:40:12 --> Database Driver Class Initialized
INFO - 2022-06-23 06:40:12 --> Email Class Initialized
DEBUG - 2022-06-23 06:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:40:12 --> Controller Class Initialized
INFO - 2022-06-23 06:40:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:40:12 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:40:12 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:40:12 --> Final output sent to browser
DEBUG - 2022-06-23 06:40:12 --> Total execution time: 0.1613
INFO - 2022-06-23 06:40:28 --> Config Class Initialized
INFO - 2022-06-23 06:40:28 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:40:28 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:40:28 --> Utf8 Class Initialized
INFO - 2022-06-23 06:40:28 --> Config Class Initialized
INFO - 2022-06-23 06:40:28 --> URI Class Initialized
INFO - 2022-06-23 06:40:28 --> Hooks Class Initialized
INFO - 2022-06-23 06:40:28 --> Router Class Initialized
INFO - 2022-06-23 06:40:28 --> Output Class Initialized
DEBUG - 2022-06-23 06:40:28 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:40:28 --> Utf8 Class Initialized
INFO - 2022-06-23 06:40:28 --> URI Class Initialized
INFO - 2022-06-23 06:40:28 --> Security Class Initialized
DEBUG - 2022-06-23 06:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:40:28 --> Router Class Initialized
INFO - 2022-06-23 06:40:28 --> Input Class Initialized
INFO - 2022-06-23 06:40:28 --> Output Class Initialized
INFO - 2022-06-23 06:40:28 --> Language Class Initialized
INFO - 2022-06-23 06:40:28 --> Security Class Initialized
DEBUG - 2022-06-23 06:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:40:28 --> Loader Class Initialized
INFO - 2022-06-23 06:40:28 --> Input Class Initialized
INFO - 2022-06-23 06:40:28 --> Helper loaded: url_helper
INFO - 2022-06-23 06:40:28 --> Language Class Initialized
INFO - 2022-06-23 06:40:28 --> Helper loaded: file_helper
INFO - 2022-06-23 06:40:28 --> Loader Class Initialized
INFO - 2022-06-23 06:40:28 --> Helper loaded: url_helper
INFO - 2022-06-23 06:40:28 --> Database Driver Class Initialized
INFO - 2022-06-23 06:40:28 --> Helper loaded: file_helper
INFO - 2022-06-23 06:40:28 --> Database Driver Class Initialized
INFO - 2022-06-23 06:40:28 --> Email Class Initialized
DEBUG - 2022-06-23 06:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:40:28 --> Controller Class Initialized
INFO - 2022-06-23 06:40:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:40:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:40:28 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:40:28 --> Final output sent to browser
DEBUG - 2022-06-23 06:40:28 --> Total execution time: 0.0444
INFO - 2022-06-23 06:40:28 --> Email Class Initialized
DEBUG - 2022-06-23 06:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:40:28 --> Controller Class Initialized
INFO - 2022-06-23 06:40:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:40:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 06:40:28 --> Severity: error --> Exception: Call to undefined function alert() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 44
INFO - 2022-06-23 06:40:42 --> Config Class Initialized
INFO - 2022-06-23 06:40:42 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:40:42 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:40:42 --> Utf8 Class Initialized
INFO - 2022-06-23 06:40:42 --> Config Class Initialized
INFO - 2022-06-23 06:40:42 --> Hooks Class Initialized
INFO - 2022-06-23 06:40:42 --> URI Class Initialized
DEBUG - 2022-06-23 06:40:42 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:40:42 --> Utf8 Class Initialized
INFO - 2022-06-23 06:40:42 --> Router Class Initialized
INFO - 2022-06-23 06:40:42 --> URI Class Initialized
INFO - 2022-06-23 06:40:42 --> Output Class Initialized
INFO - 2022-06-23 06:40:42 --> Router Class Initialized
INFO - 2022-06-23 06:40:42 --> Security Class Initialized
INFO - 2022-06-23 06:40:42 --> Output Class Initialized
DEBUG - 2022-06-23 06:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:40:42 --> Security Class Initialized
INFO - 2022-06-23 06:40:42 --> Input Class Initialized
INFO - 2022-06-23 06:40:42 --> Language Class Initialized
DEBUG - 2022-06-23 06:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:40:42 --> Input Class Initialized
INFO - 2022-06-23 06:40:42 --> Loader Class Initialized
INFO - 2022-06-23 06:40:42 --> Language Class Initialized
INFO - 2022-06-23 06:40:42 --> Helper loaded: url_helper
INFO - 2022-06-23 06:40:42 --> Loader Class Initialized
INFO - 2022-06-23 06:40:42 --> Helper loaded: file_helper
INFO - 2022-06-23 06:40:42 --> Helper loaded: url_helper
INFO - 2022-06-23 06:40:42 --> Database Driver Class Initialized
INFO - 2022-06-23 06:40:42 --> Helper loaded: file_helper
INFO - 2022-06-23 06:40:42 --> Database Driver Class Initialized
INFO - 2022-06-23 06:40:42 --> Email Class Initialized
DEBUG - 2022-06-23 06:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:40:42 --> Controller Class Initialized
INFO - 2022-06-23 06:40:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:40:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 06:40:42 --> Severity: error --> Exception: Call to undefined function alert() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 44
INFO - 2022-06-23 06:40:42 --> Email Class Initialized
DEBUG - 2022-06-23 06:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:40:42 --> Controller Class Initialized
INFO - 2022-06-23 06:40:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:40:42 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:40:42 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:40:42 --> Final output sent to browser
DEBUG - 2022-06-23 06:40:42 --> Total execution time: 0.3696
INFO - 2022-06-23 06:40:47 --> Config Class Initialized
INFO - 2022-06-23 06:40:47 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:40:47 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:40:47 --> Utf8 Class Initialized
INFO - 2022-06-23 06:40:47 --> URI Class Initialized
INFO - 2022-06-23 06:40:47 --> Router Class Initialized
INFO - 2022-06-23 06:40:47 --> Output Class Initialized
INFO - 2022-06-23 06:40:47 --> Security Class Initialized
DEBUG - 2022-06-23 06:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:40:47 --> Input Class Initialized
INFO - 2022-06-23 06:40:47 --> Language Class Initialized
INFO - 2022-06-23 06:40:47 --> Loader Class Initialized
INFO - 2022-06-23 06:40:47 --> Helper loaded: url_helper
INFO - 2022-06-23 06:40:47 --> Helper loaded: file_helper
INFO - 2022-06-23 06:40:47 --> Database Driver Class Initialized
INFO - 2022-06-23 06:40:47 --> Email Class Initialized
DEBUG - 2022-06-23 06:40:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:40:47 --> Controller Class Initialized
INFO - 2022-06-23 06:40:47 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:40:47 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:40:47 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:40:47 --> Final output sent to browser
DEBUG - 2022-06-23 06:40:47 --> Total execution time: 0.0212
INFO - 2022-06-23 06:41:06 --> Config Class Initialized
INFO - 2022-06-23 06:41:06 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:41:06 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:41:06 --> Utf8 Class Initialized
INFO - 2022-06-23 06:41:06 --> URI Class Initialized
INFO - 2022-06-23 06:41:06 --> Router Class Initialized
INFO - 2022-06-23 06:41:06 --> Output Class Initialized
INFO - 2022-06-23 06:41:06 --> Security Class Initialized
DEBUG - 2022-06-23 06:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:41:06 --> Input Class Initialized
INFO - 2022-06-23 06:41:06 --> Language Class Initialized
INFO - 2022-06-23 06:41:06 --> Loader Class Initialized
INFO - 2022-06-23 06:41:06 --> Helper loaded: url_helper
INFO - 2022-06-23 06:41:06 --> Helper loaded: file_helper
INFO - 2022-06-23 06:41:06 --> Database Driver Class Initialized
INFO - 2022-06-23 06:41:06 --> Email Class Initialized
DEBUG - 2022-06-23 06:41:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:41:06 --> Controller Class Initialized
INFO - 2022-06-23 06:41:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:41:06 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:41:06 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:41:06 --> Final output sent to browser
DEBUG - 2022-06-23 06:41:06 --> Total execution time: 0.3373
INFO - 2022-06-23 06:41:15 --> Config Class Initialized
INFO - 2022-06-23 06:41:15 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:41:15 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:41:15 --> Utf8 Class Initialized
INFO - 2022-06-23 06:41:15 --> URI Class Initialized
INFO - 2022-06-23 06:41:15 --> Router Class Initialized
INFO - 2022-06-23 06:41:15 --> Output Class Initialized
INFO - 2022-06-23 06:41:15 --> Config Class Initialized
INFO - 2022-06-23 06:41:15 --> Hooks Class Initialized
INFO - 2022-06-23 06:41:15 --> Security Class Initialized
DEBUG - 2022-06-23 06:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:41:15 --> Utf8 Class Initialized
INFO - 2022-06-23 06:41:15 --> Input Class Initialized
INFO - 2022-06-23 06:41:15 --> URI Class Initialized
INFO - 2022-06-23 06:41:15 --> Language Class Initialized
INFO - 2022-06-23 06:41:15 --> Router Class Initialized
INFO - 2022-06-23 06:41:15 --> Loader Class Initialized
INFO - 2022-06-23 06:41:15 --> Output Class Initialized
INFO - 2022-06-23 06:41:15 --> Security Class Initialized
INFO - 2022-06-23 06:41:15 --> Helper loaded: url_helper
DEBUG - 2022-06-23 06:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:41:15 --> Helper loaded: file_helper
INFO - 2022-06-23 06:41:15 --> Input Class Initialized
INFO - 2022-06-23 06:41:15 --> Language Class Initialized
INFO - 2022-06-23 06:41:15 --> Database Driver Class Initialized
INFO - 2022-06-23 06:41:15 --> Loader Class Initialized
INFO - 2022-06-23 06:41:15 --> Helper loaded: url_helper
INFO - 2022-06-23 06:41:15 --> Helper loaded: file_helper
INFO - 2022-06-23 06:41:15 --> Database Driver Class Initialized
INFO - 2022-06-23 06:41:16 --> Email Class Initialized
INFO - 2022-06-23 06:41:16 --> Email Class Initialized
DEBUG - 2022-06-23 06:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 06:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:41:16 --> Controller Class Initialized
INFO - 2022-06-23 06:41:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:41:16 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:41:16 --> Final output sent to browser
DEBUG - 2022-06-23 06:41:16 --> Total execution time: 0.1786
INFO - 2022-06-23 06:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:41:16 --> Controller Class Initialized
INFO - 2022-06-23 06:41:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:41:16 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:41:16 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:41:16 --> Final output sent to browser
DEBUG - 2022-06-23 06:41:16 --> Total execution time: 0.1764
INFO - 2022-06-23 06:41:30 --> Config Class Initialized
INFO - 2022-06-23 06:41:30 --> Hooks Class Initialized
INFO - 2022-06-23 06:41:30 --> Config Class Initialized
INFO - 2022-06-23 06:41:30 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:41:30 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:41:30 --> Utf8 Class Initialized
DEBUG - 2022-06-23 06:41:30 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:41:30 --> URI Class Initialized
INFO - 2022-06-23 06:41:30 --> Utf8 Class Initialized
INFO - 2022-06-23 06:41:30 --> Router Class Initialized
INFO - 2022-06-23 06:41:30 --> URI Class Initialized
INFO - 2022-06-23 06:41:30 --> Output Class Initialized
INFO - 2022-06-23 06:41:30 --> Router Class Initialized
INFO - 2022-06-23 06:41:30 --> Security Class Initialized
INFO - 2022-06-23 06:41:30 --> Output Class Initialized
DEBUG - 2022-06-23 06:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:41:30 --> Input Class Initialized
INFO - 2022-06-23 06:41:30 --> Security Class Initialized
INFO - 2022-06-23 06:41:30 --> Language Class Initialized
DEBUG - 2022-06-23 06:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:41:30 --> Input Class Initialized
INFO - 2022-06-23 06:41:30 --> Loader Class Initialized
INFO - 2022-06-23 06:41:30 --> Language Class Initialized
INFO - 2022-06-23 06:41:30 --> Helper loaded: url_helper
INFO - 2022-06-23 06:41:30 --> Loader Class Initialized
INFO - 2022-06-23 06:41:30 --> Helper loaded: file_helper
INFO - 2022-06-23 06:41:30 --> Helper loaded: url_helper
INFO - 2022-06-23 06:41:30 --> Helper loaded: file_helper
INFO - 2022-06-23 06:41:30 --> Database Driver Class Initialized
INFO - 2022-06-23 06:41:30 --> Database Driver Class Initialized
INFO - 2022-06-23 06:41:30 --> Email Class Initialized
INFO - 2022-06-23 06:41:30 --> Email Class Initialized
DEBUG - 2022-06-23 06:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 06:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:41:30 --> Controller Class Initialized
INFO - 2022-06-23 06:41:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:41:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:41:30 --> Final output sent to browser
DEBUG - 2022-06-23 06:41:30 --> Total execution time: 0.0264
INFO - 2022-06-23 06:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:41:30 --> Controller Class Initialized
INFO - 2022-06-23 06:41:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:41:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:41:30 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:41:30 --> Final output sent to browser
DEBUG - 2022-06-23 06:41:30 --> Total execution time: 0.0311
INFO - 2022-06-23 06:48:59 --> Config Class Initialized
INFO - 2022-06-23 06:48:59 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:48:59 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:48:59 --> Utf8 Class Initialized
INFO - 2022-06-23 06:48:59 --> URI Class Initialized
INFO - 2022-06-23 06:48:59 --> Router Class Initialized
INFO - 2022-06-23 06:48:59 --> Output Class Initialized
INFO - 2022-06-23 06:48:59 --> Security Class Initialized
DEBUG - 2022-06-23 06:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:48:59 --> Input Class Initialized
INFO - 2022-06-23 06:48:59 --> Language Class Initialized
INFO - 2022-06-23 06:48:59 --> Loader Class Initialized
INFO - 2022-06-23 06:48:59 --> Helper loaded: url_helper
INFO - 2022-06-23 06:48:59 --> Helper loaded: file_helper
INFO - 2022-06-23 06:48:59 --> Database Driver Class Initialized
INFO - 2022-06-23 06:48:59 --> Email Class Initialized
DEBUG - 2022-06-23 06:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:48:59 --> Controller Class Initialized
INFO - 2022-06-23 06:48:59 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:48:59 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:48:59 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:48:59 --> Final output sent to browser
DEBUG - 2022-06-23 06:48:59 --> Total execution time: 1.7534
INFO - 2022-06-23 06:49:10 --> Config Class Initialized
INFO - 2022-06-23 06:49:10 --> Config Class Initialized
INFO - 2022-06-23 06:49:10 --> Hooks Class Initialized
INFO - 2022-06-23 06:49:10 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:49:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 06:49:10 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:49:10 --> Utf8 Class Initialized
INFO - 2022-06-23 06:49:10 --> Utf8 Class Initialized
INFO - 2022-06-23 06:49:10 --> URI Class Initialized
INFO - 2022-06-23 06:49:10 --> URI Class Initialized
INFO - 2022-06-23 06:49:10 --> Router Class Initialized
INFO - 2022-06-23 06:49:10 --> Router Class Initialized
INFO - 2022-06-23 06:49:10 --> Output Class Initialized
INFO - 2022-06-23 06:49:10 --> Output Class Initialized
INFO - 2022-06-23 06:49:10 --> Security Class Initialized
INFO - 2022-06-23 06:49:10 --> Security Class Initialized
DEBUG - 2022-06-23 06:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 06:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:49:10 --> Input Class Initialized
INFO - 2022-06-23 06:49:10 --> Input Class Initialized
INFO - 2022-06-23 06:49:10 --> Language Class Initialized
INFO - 2022-06-23 06:49:10 --> Language Class Initialized
INFO - 2022-06-23 06:49:10 --> Loader Class Initialized
INFO - 2022-06-23 06:49:10 --> Loader Class Initialized
INFO - 2022-06-23 06:49:10 --> Helper loaded: url_helper
INFO - 2022-06-23 06:49:10 --> Helper loaded: url_helper
INFO - 2022-06-23 06:49:10 --> Helper loaded: file_helper
INFO - 2022-06-23 06:49:10 --> Helper loaded: file_helper
INFO - 2022-06-23 06:49:10 --> Database Driver Class Initialized
INFO - 2022-06-23 06:49:10 --> Database Driver Class Initialized
INFO - 2022-06-23 06:49:10 --> Email Class Initialized
INFO - 2022-06-23 06:49:10 --> Email Class Initialized
DEBUG - 2022-06-23 06:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 06:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:49:10 --> Controller Class Initialized
INFO - 2022-06-23 06:49:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:49:10 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:49:10 --> Final output sent to browser
DEBUG - 2022-06-23 06:49:10 --> Total execution time: 0.0299
INFO - 2022-06-23 06:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:49:10 --> Controller Class Initialized
INFO - 2022-06-23 06:49:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:49:10 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:49:10 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:49:10 --> Final output sent to browser
DEBUG - 2022-06-23 06:49:10 --> Total execution time: 0.0370
INFO - 2022-06-23 06:49:16 --> Config Class Initialized
INFO - 2022-06-23 06:49:16 --> Hooks Class Initialized
DEBUG - 2022-06-23 06:49:16 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:49:16 --> Utf8 Class Initialized
INFO - 2022-06-23 06:49:16 --> URI Class Initialized
INFO - 2022-06-23 06:49:16 --> Router Class Initialized
INFO - 2022-06-23 06:49:16 --> Config Class Initialized
INFO - 2022-06-23 06:49:16 --> Hooks Class Initialized
INFO - 2022-06-23 06:49:16 --> Output Class Initialized
INFO - 2022-06-23 06:49:17 --> Security Class Initialized
DEBUG - 2022-06-23 06:49:17 --> UTF-8 Support Enabled
INFO - 2022-06-23 06:49:17 --> Utf8 Class Initialized
INFO - 2022-06-23 06:49:17 --> URI Class Initialized
DEBUG - 2022-06-23 06:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:49:17 --> Router Class Initialized
INFO - 2022-06-23 06:49:17 --> Input Class Initialized
INFO - 2022-06-23 06:49:17 --> Output Class Initialized
INFO - 2022-06-23 06:49:17 --> Language Class Initialized
INFO - 2022-06-23 06:49:17 --> Security Class Initialized
INFO - 2022-06-23 06:49:17 --> Loader Class Initialized
INFO - 2022-06-23 06:49:17 --> Helper loaded: url_helper
DEBUG - 2022-06-23 06:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 06:49:17 --> Helper loaded: file_helper
INFO - 2022-06-23 06:49:17 --> Input Class Initialized
INFO - 2022-06-23 06:49:17 --> Database Driver Class Initialized
INFO - 2022-06-23 06:49:17 --> Email Class Initialized
INFO - 2022-06-23 06:49:17 --> Language Class Initialized
DEBUG - 2022-06-23 06:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:49:17 --> Loader Class Initialized
INFO - 2022-06-23 06:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:49:17 --> Helper loaded: url_helper
INFO - 2022-06-23 06:49:17 --> Controller Class Initialized
INFO - 2022-06-23 06:49:17 --> Helper loaded: file_helper
INFO - 2022-06-23 06:49:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:49:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:49:17 --> Database Driver Class Initialized
INFO - 2022-06-23 06:49:17 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 06:49:17 --> Final output sent to browser
DEBUG - 2022-06-23 06:49:17 --> Total execution time: 0.0450
INFO - 2022-06-23 06:49:17 --> Email Class Initialized
DEBUG - 2022-06-23 06:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 06:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 06:49:17 --> Controller Class Initialized
INFO - 2022-06-23 06:49:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 06:49:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 06:49:17 --> Final output sent to browser
DEBUG - 2022-06-23 06:49:17 --> Total execution time: 0.0604
INFO - 2022-06-23 08:56:52 --> Config Class Initialized
INFO - 2022-06-23 08:56:52 --> Hooks Class Initialized
DEBUG - 2022-06-23 08:56:52 --> UTF-8 Support Enabled
INFO - 2022-06-23 08:56:52 --> Utf8 Class Initialized
INFO - 2022-06-23 08:56:52 --> URI Class Initialized
INFO - 2022-06-23 08:56:52 --> Router Class Initialized
INFO - 2022-06-23 08:56:52 --> Output Class Initialized
INFO - 2022-06-23 08:56:52 --> Security Class Initialized
DEBUG - 2022-06-23 08:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 08:56:52 --> Input Class Initialized
INFO - 2022-06-23 08:56:52 --> Language Class Initialized
INFO - 2022-06-23 08:56:52 --> Loader Class Initialized
INFO - 2022-06-23 08:56:52 --> Helper loaded: url_helper
INFO - 2022-06-23 08:56:52 --> Helper loaded: file_helper
INFO - 2022-06-23 08:56:52 --> Database Driver Class Initialized
INFO - 2022-06-23 08:56:52 --> Email Class Initialized
DEBUG - 2022-06-23 08:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 08:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 08:56:52 --> Controller Class Initialized
INFO - 2022-06-23 08:56:52 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 08:56:52 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 08:56:52 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 08:56:52 --> Final output sent to browser
DEBUG - 2022-06-23 08:56:52 --> Total execution time: 0.1057
INFO - 2022-06-23 08:57:12 --> Config Class Initialized
INFO - 2022-06-23 08:57:12 --> Hooks Class Initialized
DEBUG - 2022-06-23 08:57:12 --> UTF-8 Support Enabled
INFO - 2022-06-23 08:57:12 --> Utf8 Class Initialized
INFO - 2022-06-23 08:57:12 --> URI Class Initialized
INFO - 2022-06-23 08:57:12 --> Router Class Initialized
INFO - 2022-06-23 08:57:12 --> Output Class Initialized
INFO - 2022-06-23 08:57:12 --> Security Class Initialized
DEBUG - 2022-06-23 08:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 08:57:12 --> Input Class Initialized
INFO - 2022-06-23 08:57:12 --> Language Class Initialized
INFO - 2022-06-23 08:57:12 --> Loader Class Initialized
INFO - 2022-06-23 08:57:12 --> Helper loaded: url_helper
INFO - 2022-06-23 08:57:12 --> Helper loaded: file_helper
INFO - 2022-06-23 08:57:12 --> Database Driver Class Initialized
INFO - 2022-06-23 08:57:12 --> Email Class Initialized
DEBUG - 2022-06-23 08:57:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 08:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 08:57:12 --> Controller Class Initialized
INFO - 2022-06-23 08:57:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 08:57:12 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 08:57:12 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 08:57:12 --> Final output sent to browser
DEBUG - 2022-06-23 08:57:12 --> Total execution time: 0.0976
INFO - 2022-06-23 08:57:13 --> Config Class Initialized
INFO - 2022-06-23 08:57:13 --> Hooks Class Initialized
DEBUG - 2022-06-23 08:57:13 --> UTF-8 Support Enabled
INFO - 2022-06-23 08:57:13 --> Utf8 Class Initialized
INFO - 2022-06-23 08:57:13 --> URI Class Initialized
INFO - 2022-06-23 08:57:13 --> Router Class Initialized
INFO - 2022-06-23 08:57:13 --> Output Class Initialized
INFO - 2022-06-23 08:57:13 --> Security Class Initialized
DEBUG - 2022-06-23 08:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 08:57:13 --> Input Class Initialized
INFO - 2022-06-23 08:57:13 --> Language Class Initialized
INFO - 2022-06-23 08:57:13 --> Loader Class Initialized
INFO - 2022-06-23 08:57:13 --> Helper loaded: url_helper
INFO - 2022-06-23 08:57:13 --> Helper loaded: file_helper
INFO - 2022-06-23 08:57:13 --> Database Driver Class Initialized
INFO - 2022-06-23 08:57:13 --> Email Class Initialized
DEBUG - 2022-06-23 08:57:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 08:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 08:57:13 --> Controller Class Initialized
INFO - 2022-06-23 08:57:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 08:57:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 08:57:13 --> Severity: error --> Exception: Call to undefined method Tokenmodel::insert() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 39
INFO - 2022-06-23 08:57:28 --> Config Class Initialized
INFO - 2022-06-23 08:57:28 --> Hooks Class Initialized
DEBUG - 2022-06-23 08:57:28 --> UTF-8 Support Enabled
INFO - 2022-06-23 08:57:28 --> Utf8 Class Initialized
INFO - 2022-06-23 08:57:28 --> URI Class Initialized
INFO - 2022-06-23 08:57:28 --> Router Class Initialized
INFO - 2022-06-23 08:57:28 --> Output Class Initialized
INFO - 2022-06-23 08:57:28 --> Security Class Initialized
DEBUG - 2022-06-23 08:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 08:57:28 --> Input Class Initialized
INFO - 2022-06-23 08:57:28 --> Language Class Initialized
INFO - 2022-06-23 08:57:28 --> Loader Class Initialized
INFO - 2022-06-23 08:57:28 --> Helper loaded: url_helper
INFO - 2022-06-23 08:57:28 --> Helper loaded: file_helper
INFO - 2022-06-23 08:57:28 --> Database Driver Class Initialized
INFO - 2022-06-23 08:57:28 --> Email Class Initialized
DEBUG - 2022-06-23 08:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 08:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 08:57:28 --> Controller Class Initialized
INFO - 2022-06-23 08:57:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 08:57:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 08:57:28 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 08:57:28 --> Final output sent to browser
DEBUG - 2022-06-23 08:57:28 --> Total execution time: 0.1601
INFO - 2022-06-23 08:57:40 --> Config Class Initialized
INFO - 2022-06-23 08:57:40 --> Config Class Initialized
INFO - 2022-06-23 08:57:40 --> Hooks Class Initialized
INFO - 2022-06-23 08:57:40 --> Hooks Class Initialized
DEBUG - 2022-06-23 08:57:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 08:57:40 --> UTF-8 Support Enabled
INFO - 2022-06-23 08:57:40 --> Utf8 Class Initialized
INFO - 2022-06-23 08:57:40 --> Utf8 Class Initialized
INFO - 2022-06-23 08:57:40 --> URI Class Initialized
INFO - 2022-06-23 08:57:40 --> URI Class Initialized
INFO - 2022-06-23 08:57:40 --> Router Class Initialized
INFO - 2022-06-23 08:57:40 --> Router Class Initialized
INFO - 2022-06-23 08:57:40 --> Output Class Initialized
INFO - 2022-06-23 08:57:40 --> Output Class Initialized
INFO - 2022-06-23 08:57:40 --> Security Class Initialized
INFO - 2022-06-23 08:57:40 --> Security Class Initialized
DEBUG - 2022-06-23 08:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 08:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 08:57:40 --> Input Class Initialized
INFO - 2022-06-23 08:57:40 --> Input Class Initialized
INFO - 2022-06-23 08:57:40 --> Language Class Initialized
INFO - 2022-06-23 08:57:40 --> Language Class Initialized
INFO - 2022-06-23 08:57:40 --> Loader Class Initialized
INFO - 2022-06-23 08:57:40 --> Loader Class Initialized
INFO - 2022-06-23 08:57:40 --> Helper loaded: url_helper
INFO - 2022-06-23 08:57:40 --> Helper loaded: url_helper
INFO - 2022-06-23 08:57:40 --> Helper loaded: file_helper
INFO - 2022-06-23 08:57:40 --> Helper loaded: file_helper
INFO - 2022-06-23 08:57:40 --> Database Driver Class Initialized
INFO - 2022-06-23 08:57:40 --> Database Driver Class Initialized
INFO - 2022-06-23 08:57:40 --> Email Class Initialized
DEBUG - 2022-06-23 08:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 08:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 08:57:40 --> Controller Class Initialized
INFO - 2022-06-23 08:57:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 08:57:40 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 08:57:40 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 08:57:40 --> Final output sent to browser
DEBUG - 2022-06-23 08:57:40 --> Total execution time: 0.0287
INFO - 2022-06-23 08:57:40 --> Email Class Initialized
DEBUG - 2022-06-23 08:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 08:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 08:57:40 --> Controller Class Initialized
INFO - 2022-06-23 08:57:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 08:57:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 08:57:40 --> Severity: error --> Exception: Call to undefined method Tokenmodel::insert() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 39
INFO - 2022-06-23 08:58:09 --> Config Class Initialized
INFO - 2022-06-23 08:58:09 --> Hooks Class Initialized
DEBUG - 2022-06-23 08:58:09 --> UTF-8 Support Enabled
INFO - 2022-06-23 08:58:09 --> Utf8 Class Initialized
INFO - 2022-06-23 08:58:09 --> URI Class Initialized
INFO - 2022-06-23 08:58:09 --> Router Class Initialized
INFO - 2022-06-23 08:58:09 --> Output Class Initialized
INFO - 2022-06-23 08:58:09 --> Security Class Initialized
DEBUG - 2022-06-23 08:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 08:58:09 --> Input Class Initialized
INFO - 2022-06-23 08:58:09 --> Language Class Initialized
INFO - 2022-06-23 08:58:09 --> Loader Class Initialized
INFO - 2022-06-23 08:58:09 --> Helper loaded: url_helper
INFO - 2022-06-23 08:58:09 --> Helper loaded: file_helper
INFO - 2022-06-23 08:58:09 --> Database Driver Class Initialized
INFO - 2022-06-23 08:58:09 --> Email Class Initialized
DEBUG - 2022-06-23 08:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 08:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 08:58:09 --> Controller Class Initialized
INFO - 2022-06-23 08:58:09 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 08:58:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 08:58:09 --> Severity: error --> Exception: Call to undefined method Tokenmodel::insert() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 39
INFO - 2022-06-23 08:58:36 --> Config Class Initialized
INFO - 2022-06-23 08:58:36 --> Hooks Class Initialized
DEBUG - 2022-06-23 08:58:36 --> UTF-8 Support Enabled
INFO - 2022-06-23 08:58:36 --> Utf8 Class Initialized
INFO - 2022-06-23 08:58:36 --> URI Class Initialized
INFO - 2022-06-23 08:58:36 --> Router Class Initialized
INFO - 2022-06-23 08:58:36 --> Output Class Initialized
INFO - 2022-06-23 08:58:36 --> Security Class Initialized
DEBUG - 2022-06-23 08:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 08:58:36 --> Input Class Initialized
INFO - 2022-06-23 08:58:36 --> Language Class Initialized
INFO - 2022-06-23 08:58:36 --> Loader Class Initialized
INFO - 2022-06-23 08:58:36 --> Helper loaded: url_helper
INFO - 2022-06-23 08:58:36 --> Helper loaded: file_helper
INFO - 2022-06-23 08:58:36 --> Database Driver Class Initialized
INFO - 2022-06-23 08:58:36 --> Email Class Initialized
DEBUG - 2022-06-23 08:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 08:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 08:58:36 --> Controller Class Initialized
INFO - 2022-06-23 08:58:36 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 08:58:36 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 08:58:36 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 08:58:36 --> Final output sent to browser
DEBUG - 2022-06-23 08:58:36 --> Total execution time: 0.0814
INFO - 2022-06-23 08:58:45 --> Config Class Initialized
INFO - 2022-06-23 08:58:45 --> Hooks Class Initialized
DEBUG - 2022-06-23 08:58:45 --> UTF-8 Support Enabled
INFO - 2022-06-23 08:58:45 --> Config Class Initialized
INFO - 2022-06-23 08:58:45 --> Utf8 Class Initialized
INFO - 2022-06-23 08:58:45 --> Hooks Class Initialized
INFO - 2022-06-23 08:58:45 --> URI Class Initialized
DEBUG - 2022-06-23 08:58:45 --> UTF-8 Support Enabled
INFO - 2022-06-23 08:58:45 --> Utf8 Class Initialized
INFO - 2022-06-23 08:58:45 --> Router Class Initialized
INFO - 2022-06-23 08:58:45 --> URI Class Initialized
INFO - 2022-06-23 08:58:45 --> Output Class Initialized
INFO - 2022-06-23 08:58:45 --> Security Class Initialized
INFO - 2022-06-23 08:58:45 --> Router Class Initialized
DEBUG - 2022-06-23 08:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 08:58:45 --> Output Class Initialized
INFO - 2022-06-23 08:58:45 --> Input Class Initialized
INFO - 2022-06-23 08:58:45 --> Language Class Initialized
INFO - 2022-06-23 08:58:45 --> Security Class Initialized
DEBUG - 2022-06-23 08:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 08:58:45 --> Loader Class Initialized
INFO - 2022-06-23 08:58:45 --> Input Class Initialized
INFO - 2022-06-23 08:58:45 --> Language Class Initialized
INFO - 2022-06-23 08:58:45 --> Helper loaded: url_helper
INFO - 2022-06-23 08:58:45 --> Loader Class Initialized
INFO - 2022-06-23 08:58:45 --> Helper loaded: file_helper
INFO - 2022-06-23 08:58:45 --> Helper loaded: url_helper
INFO - 2022-06-23 08:58:45 --> Database Driver Class Initialized
INFO - 2022-06-23 08:58:45 --> Helper loaded: file_helper
INFO - 2022-06-23 08:58:45 --> Database Driver Class Initialized
INFO - 2022-06-23 08:58:46 --> Email Class Initialized
DEBUG - 2022-06-23 08:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 08:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 08:58:46 --> Controller Class Initialized
INFO - 2022-06-23 08:58:46 --> Model "Tokenmodel" initialized
INFO - 2022-06-23 08:58:46 --> Email Class Initialized
DEBUG - 2022-06-23 08:58:46 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 08:58:46 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
DEBUG - 2022-06-23 08:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 08:58:46 --> Final output sent to browser
DEBUG - 2022-06-23 08:58:46 --> Total execution time: 0.4412
INFO - 2022-06-23 08:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 08:58:46 --> Controller Class Initialized
INFO - 2022-06-23 08:58:46 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 08:58:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 08:58:46 --> Query error: Column 'ud_mob' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_mob`, `ud_otp`) VALUES (NULL, NULL)
INFO - 2022-06-23 08:58:46 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-23 08:58:49 --> Config Class Initialized
INFO - 2022-06-23 08:58:49 --> Hooks Class Initialized
DEBUG - 2022-06-23 08:58:49 --> UTF-8 Support Enabled
INFO - 2022-06-23 08:58:49 --> Utf8 Class Initialized
INFO - 2022-06-23 08:58:49 --> URI Class Initialized
INFO - 2022-06-23 08:58:49 --> Router Class Initialized
INFO - 2022-06-23 08:58:49 --> Output Class Initialized
INFO - 2022-06-23 08:58:49 --> Security Class Initialized
DEBUG - 2022-06-23 08:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 08:58:49 --> Input Class Initialized
INFO - 2022-06-23 08:58:49 --> Language Class Initialized
INFO - 2022-06-23 08:58:49 --> Loader Class Initialized
INFO - 2022-06-23 08:58:49 --> Helper loaded: url_helper
INFO - 2022-06-23 08:58:49 --> Helper loaded: file_helper
INFO - 2022-06-23 08:58:49 --> Database Driver Class Initialized
INFO - 2022-06-23 08:58:49 --> Email Class Initialized
DEBUG - 2022-06-23 08:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 08:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 08:58:49 --> Controller Class Initialized
INFO - 2022-06-23 08:58:49 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 08:58:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 08:58:49 --> Query error: Column 'ud_mob' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_mob`, `ud_otp`) VALUES (NULL, NULL)
INFO - 2022-06-23 08:58:49 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-23 08:59:31 --> Config Class Initialized
INFO - 2022-06-23 08:59:31 --> Hooks Class Initialized
DEBUG - 2022-06-23 08:59:31 --> UTF-8 Support Enabled
INFO - 2022-06-23 08:59:31 --> Utf8 Class Initialized
INFO - 2022-06-23 08:59:31 --> URI Class Initialized
INFO - 2022-06-23 08:59:31 --> Config Class Initialized
INFO - 2022-06-23 08:59:31 --> Hooks Class Initialized
INFO - 2022-06-23 08:59:31 --> Router Class Initialized
DEBUG - 2022-06-23 08:59:31 --> UTF-8 Support Enabled
INFO - 2022-06-23 08:59:31 --> Utf8 Class Initialized
INFO - 2022-06-23 08:59:31 --> Output Class Initialized
INFO - 2022-06-23 08:59:31 --> URI Class Initialized
INFO - 2022-06-23 08:59:31 --> Security Class Initialized
INFO - 2022-06-23 08:59:31 --> Router Class Initialized
DEBUG - 2022-06-23 08:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 08:59:31 --> Input Class Initialized
INFO - 2022-06-23 08:59:31 --> Output Class Initialized
INFO - 2022-06-23 08:59:31 --> Language Class Initialized
INFO - 2022-06-23 08:59:31 --> Security Class Initialized
DEBUG - 2022-06-23 08:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 08:59:31 --> Loader Class Initialized
INFO - 2022-06-23 08:59:31 --> Input Class Initialized
INFO - 2022-06-23 08:59:31 --> Helper loaded: url_helper
INFO - 2022-06-23 08:59:31 --> Language Class Initialized
INFO - 2022-06-23 08:59:31 --> Helper loaded: file_helper
INFO - 2022-06-23 08:59:31 --> Loader Class Initialized
INFO - 2022-06-23 08:59:31 --> Database Driver Class Initialized
INFO - 2022-06-23 08:59:31 --> Helper loaded: url_helper
INFO - 2022-06-23 08:59:31 --> Helper loaded: file_helper
INFO - 2022-06-23 08:59:31 --> Database Driver Class Initialized
INFO - 2022-06-23 08:59:31 --> Email Class Initialized
DEBUG - 2022-06-23 08:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 08:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 08:59:31 --> Controller Class Initialized
INFO - 2022-06-23 08:59:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 08:59:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 08:59:31 --> Email Class Initialized
DEBUG - 2022-06-23 08:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-06-23 08:59:31 --> Query error: Column 'ud_mob' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_mob`, `ud_otp`) VALUES (NULL, NULL)
INFO - 2022-06-23 08:59:31 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-23 08:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 08:59:31 --> Controller Class Initialized
INFO - 2022-06-23 08:59:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 08:59:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 08:59:31 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 08:59:31 --> Final output sent to browser
DEBUG - 2022-06-23 08:59:31 --> Total execution time: 0.2780
INFO - 2022-06-23 08:59:49 --> Config Class Initialized
INFO - 2022-06-23 08:59:49 --> Hooks Class Initialized
DEBUG - 2022-06-23 08:59:49 --> UTF-8 Support Enabled
INFO - 2022-06-23 08:59:49 --> Utf8 Class Initialized
INFO - 2022-06-23 08:59:49 --> URI Class Initialized
INFO - 2022-06-23 08:59:49 --> Router Class Initialized
INFO - 2022-06-23 08:59:49 --> Output Class Initialized
INFO - 2022-06-23 08:59:49 --> Config Class Initialized
INFO - 2022-06-23 08:59:49 --> Hooks Class Initialized
INFO - 2022-06-23 08:59:49 --> Security Class Initialized
DEBUG - 2022-06-23 08:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 08:59:49 --> Input Class Initialized
DEBUG - 2022-06-23 08:59:49 --> UTF-8 Support Enabled
INFO - 2022-06-23 08:59:49 --> Language Class Initialized
INFO - 2022-06-23 08:59:49 --> Utf8 Class Initialized
INFO - 2022-06-23 08:59:49 --> URI Class Initialized
INFO - 2022-06-23 08:59:49 --> Router Class Initialized
INFO - 2022-06-23 08:59:49 --> Loader Class Initialized
INFO - 2022-06-23 08:59:49 --> Output Class Initialized
INFO - 2022-06-23 08:59:49 --> Helper loaded: url_helper
INFO - 2022-06-23 08:59:49 --> Security Class Initialized
INFO - 2022-06-23 08:59:49 --> Helper loaded: file_helper
DEBUG - 2022-06-23 08:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 08:59:49 --> Input Class Initialized
INFO - 2022-06-23 08:59:49 --> Database Driver Class Initialized
INFO - 2022-06-23 08:59:49 --> Language Class Initialized
INFO - 2022-06-23 08:59:49 --> Loader Class Initialized
INFO - 2022-06-23 08:59:49 --> Helper loaded: url_helper
INFO - 2022-06-23 08:59:49 --> Helper loaded: file_helper
INFO - 2022-06-23 08:59:49 --> Database Driver Class Initialized
INFO - 2022-06-23 08:59:49 --> Email Class Initialized
INFO - 2022-06-23 08:59:49 --> Email Class Initialized
DEBUG - 2022-06-23 08:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 08:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 08:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 08:59:49 --> Controller Class Initialized
INFO - 2022-06-23 08:59:49 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 08:59:49 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 08:59:49 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 08:59:49 --> Final output sent to browser
DEBUG - 2022-06-23 08:59:49 --> Total execution time: 0.2090
INFO - 2022-06-23 08:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 08:59:49 --> Controller Class Initialized
INFO - 2022-06-23 08:59:49 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 08:59:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 08:59:49 --> Query error: Column 'ud_mob' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_mob`, `ud_otp`) VALUES (NULL, NULL)
INFO - 2022-06-23 08:59:49 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-23 08:59:53 --> Config Class Initialized
INFO - 2022-06-23 08:59:53 --> Hooks Class Initialized
DEBUG - 2022-06-23 08:59:53 --> UTF-8 Support Enabled
INFO - 2022-06-23 08:59:53 --> Utf8 Class Initialized
INFO - 2022-06-23 08:59:53 --> URI Class Initialized
INFO - 2022-06-23 08:59:53 --> Router Class Initialized
INFO - 2022-06-23 08:59:53 --> Output Class Initialized
INFO - 2022-06-23 08:59:53 --> Security Class Initialized
DEBUG - 2022-06-23 08:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 08:59:53 --> Input Class Initialized
INFO - 2022-06-23 08:59:53 --> Language Class Initialized
INFO - 2022-06-23 08:59:53 --> Loader Class Initialized
INFO - 2022-06-23 08:59:53 --> Helper loaded: url_helper
INFO - 2022-06-23 08:59:53 --> Helper loaded: file_helper
INFO - 2022-06-23 08:59:53 --> Database Driver Class Initialized
INFO - 2022-06-23 08:59:53 --> Email Class Initialized
DEBUG - 2022-06-23 08:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 08:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 08:59:53 --> Controller Class Initialized
INFO - 2022-06-23 08:59:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 08:59:53 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 08:59:53 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 08:59:53 --> Final output sent to browser
DEBUG - 2022-06-23 08:59:53 --> Total execution time: 0.0179
INFO - 2022-06-23 08:59:55 --> Config Class Initialized
INFO - 2022-06-23 08:59:55 --> Hooks Class Initialized
DEBUG - 2022-06-23 08:59:55 --> UTF-8 Support Enabled
INFO - 2022-06-23 08:59:55 --> Utf8 Class Initialized
INFO - 2022-06-23 08:59:55 --> URI Class Initialized
INFO - 2022-06-23 08:59:55 --> Router Class Initialized
INFO - 2022-06-23 08:59:55 --> Output Class Initialized
INFO - 2022-06-23 08:59:55 --> Security Class Initialized
DEBUG - 2022-06-23 08:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 08:59:55 --> Input Class Initialized
INFO - 2022-06-23 08:59:55 --> Language Class Initialized
INFO - 2022-06-23 08:59:55 --> Loader Class Initialized
INFO - 2022-06-23 08:59:55 --> Helper loaded: url_helper
INFO - 2022-06-23 08:59:55 --> Helper loaded: file_helper
INFO - 2022-06-23 08:59:55 --> Database Driver Class Initialized
INFO - 2022-06-23 08:59:55 --> Email Class Initialized
DEBUG - 2022-06-23 08:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 08:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 08:59:55 --> Controller Class Initialized
INFO - 2022-06-23 08:59:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 08:59:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 08:59:55 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 08:59:55 --> Final output sent to browser
DEBUG - 2022-06-23 08:59:55 --> Total execution time: 0.1360
INFO - 2022-06-23 09:00:10 --> Config Class Initialized
INFO - 2022-06-23 09:00:10 --> Config Class Initialized
INFO - 2022-06-23 09:00:10 --> Hooks Class Initialized
INFO - 2022-06-23 09:00:10 --> Hooks Class Initialized
DEBUG - 2022-06-23 09:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:00:10 --> UTF-8 Support Enabled
INFO - 2022-06-23 09:00:10 --> Utf8 Class Initialized
INFO - 2022-06-23 09:00:10 --> Utf8 Class Initialized
INFO - 2022-06-23 09:00:10 --> URI Class Initialized
INFO - 2022-06-23 09:00:10 --> URI Class Initialized
INFO - 2022-06-23 09:00:10 --> Router Class Initialized
INFO - 2022-06-23 09:00:10 --> Router Class Initialized
INFO - 2022-06-23 09:00:10 --> Output Class Initialized
INFO - 2022-06-23 09:00:10 --> Output Class Initialized
INFO - 2022-06-23 09:00:10 --> Security Class Initialized
INFO - 2022-06-23 09:00:10 --> Security Class Initialized
DEBUG - 2022-06-23 09:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 09:00:10 --> Input Class Initialized
INFO - 2022-06-23 09:00:10 --> Input Class Initialized
INFO - 2022-06-23 09:00:10 --> Language Class Initialized
INFO - 2022-06-23 09:00:10 --> Language Class Initialized
INFO - 2022-06-23 09:00:10 --> Loader Class Initialized
INFO - 2022-06-23 09:00:10 --> Loader Class Initialized
INFO - 2022-06-23 09:00:10 --> Helper loaded: url_helper
INFO - 2022-06-23 09:00:10 --> Helper loaded: url_helper
INFO - 2022-06-23 09:00:10 --> Helper loaded: file_helper
INFO - 2022-06-23 09:00:10 --> Helper loaded: file_helper
INFO - 2022-06-23 09:00:10 --> Database Driver Class Initialized
INFO - 2022-06-23 09:00:10 --> Database Driver Class Initialized
INFO - 2022-06-23 09:00:10 --> Email Class Initialized
DEBUG - 2022-06-23 09:00:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 09:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 09:00:10 --> Controller Class Initialized
INFO - 2022-06-23 09:00:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 09:00:10 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 09:00:10 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 09:00:10 --> Final output sent to browser
DEBUG - 2022-06-23 09:00:10 --> Total execution time: 0.0252
INFO - 2022-06-23 09:00:10 --> Email Class Initialized
DEBUG - 2022-06-23 09:00:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 09:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 09:00:10 --> Controller Class Initialized
INFO - 2022-06-23 09:00:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 09:00:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 09:00:10 --> Query error: Column 'ud_mob' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_mob`, `ud_otp`) VALUES (NULL, NULL)
INFO - 2022-06-23 09:00:10 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-23 09:00:16 --> Config Class Initialized
INFO - 2022-06-23 09:00:16 --> Hooks Class Initialized
DEBUG - 2022-06-23 09:00:16 --> UTF-8 Support Enabled
INFO - 2022-06-23 09:00:16 --> Utf8 Class Initialized
INFO - 2022-06-23 09:00:16 --> URI Class Initialized
INFO - 2022-06-23 09:00:17 --> Router Class Initialized
INFO - 2022-06-23 09:00:17 --> Output Class Initialized
INFO - 2022-06-23 09:00:17 --> Security Class Initialized
DEBUG - 2022-06-23 09:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 09:00:17 --> Input Class Initialized
INFO - 2022-06-23 09:00:17 --> Language Class Initialized
INFO - 2022-06-23 09:00:17 --> Loader Class Initialized
INFO - 2022-06-23 09:00:17 --> Helper loaded: url_helper
INFO - 2022-06-23 09:00:17 --> Helper loaded: file_helper
INFO - 2022-06-23 09:00:17 --> Database Driver Class Initialized
INFO - 2022-06-23 09:00:17 --> Email Class Initialized
DEBUG - 2022-06-23 09:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 09:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 09:00:17 --> Controller Class Initialized
INFO - 2022-06-23 09:00:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 09:00:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 09:00:17 --> Query error: Column 'ud_mob' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_mob`, `ud_otp`) VALUES (NULL, NULL)
INFO - 2022-06-23 09:00:17 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-23 09:05:11 --> Config Class Initialized
INFO - 2022-06-23 09:05:11 --> Hooks Class Initialized
DEBUG - 2022-06-23 09:05:11 --> UTF-8 Support Enabled
INFO - 2022-06-23 09:05:11 --> Utf8 Class Initialized
INFO - 2022-06-23 09:05:11 --> URI Class Initialized
INFO - 2022-06-23 09:05:11 --> Router Class Initialized
INFO - 2022-06-23 09:05:11 --> Output Class Initialized
INFO - 2022-06-23 09:05:11 --> Security Class Initialized
DEBUG - 2022-06-23 09:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 09:05:11 --> Input Class Initialized
INFO - 2022-06-23 09:05:11 --> Language Class Initialized
INFO - 2022-06-23 09:05:11 --> Loader Class Initialized
INFO - 2022-06-23 09:05:11 --> Helper loaded: url_helper
INFO - 2022-06-23 09:05:11 --> Helper loaded: file_helper
INFO - 2022-06-23 09:05:11 --> Database Driver Class Initialized
INFO - 2022-06-23 09:05:11 --> Email Class Initialized
DEBUG - 2022-06-23 09:05:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 09:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 09:05:11 --> Controller Class Initialized
INFO - 2022-06-23 09:05:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 09:05:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 09:05:11 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 09:05:11 --> Final output sent to browser
DEBUG - 2022-06-23 09:05:11 --> Total execution time: 0.0462
INFO - 2022-06-23 09:05:21 --> Config Class Initialized
INFO - 2022-06-23 09:05:21 --> Hooks Class Initialized
DEBUG - 2022-06-23 09:05:21 --> UTF-8 Support Enabled
INFO - 2022-06-23 09:05:21 --> Utf8 Class Initialized
INFO - 2022-06-23 09:05:21 --> URI Class Initialized
INFO - 2022-06-23 09:05:21 --> Router Class Initialized
INFO - 2022-06-23 09:05:21 --> Config Class Initialized
INFO - 2022-06-23 09:05:21 --> Output Class Initialized
INFO - 2022-06-23 09:05:21 --> Hooks Class Initialized
INFO - 2022-06-23 09:05:21 --> Security Class Initialized
DEBUG - 2022-06-23 09:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 09:05:21 --> Utf8 Class Initialized
INFO - 2022-06-23 09:05:21 --> Input Class Initialized
INFO - 2022-06-23 09:05:21 --> URI Class Initialized
INFO - 2022-06-23 09:05:21 --> Language Class Initialized
INFO - 2022-06-23 09:05:21 --> Router Class Initialized
INFO - 2022-06-23 09:05:21 --> Loader Class Initialized
INFO - 2022-06-23 09:05:21 --> Output Class Initialized
INFO - 2022-06-23 09:05:21 --> Helper loaded: url_helper
INFO - 2022-06-23 09:05:21 --> Security Class Initialized
INFO - 2022-06-23 09:05:21 --> Helper loaded: file_helper
DEBUG - 2022-06-23 09:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 09:05:21 --> Input Class Initialized
INFO - 2022-06-23 09:05:21 --> Database Driver Class Initialized
INFO - 2022-06-23 09:05:21 --> Language Class Initialized
INFO - 2022-06-23 09:05:21 --> Loader Class Initialized
INFO - 2022-06-23 09:05:21 --> Helper loaded: url_helper
INFO - 2022-06-23 09:05:21 --> Helper loaded: file_helper
INFO - 2022-06-23 09:05:21 --> Email Class Initialized
INFO - 2022-06-23 09:05:21 --> Database Driver Class Initialized
DEBUG - 2022-06-23 09:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 09:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 09:05:21 --> Controller Class Initialized
INFO - 2022-06-23 09:05:21 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 09:05:21 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 09:05:21 --> Final output sent to browser
DEBUG - 2022-06-23 09:05:21 --> Total execution time: 0.0273
INFO - 2022-06-23 09:05:21 --> Email Class Initialized
DEBUG - 2022-06-23 09:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 09:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 09:05:21 --> Controller Class Initialized
INFO - 2022-06-23 09:05:21 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 09:05:21 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 09:05:21 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 09:05:21 --> Final output sent to browser
DEBUG - 2022-06-23 09:05:21 --> Total execution time: 0.1497
INFO - 2022-06-23 09:05:46 --> Config Class Initialized
INFO - 2022-06-23 09:05:46 --> Hooks Class Initialized
DEBUG - 2022-06-23 09:05:46 --> UTF-8 Support Enabled
INFO - 2022-06-23 09:05:46 --> Utf8 Class Initialized
INFO - 2022-06-23 09:05:46 --> URI Class Initialized
INFO - 2022-06-23 09:05:46 --> Router Class Initialized
INFO - 2022-06-23 09:05:46 --> Output Class Initialized
INFO - 2022-06-23 09:05:46 --> Security Class Initialized
DEBUG - 2022-06-23 09:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 09:05:46 --> Input Class Initialized
INFO - 2022-06-23 09:05:46 --> Language Class Initialized
INFO - 2022-06-23 09:05:46 --> Loader Class Initialized
INFO - 2022-06-23 09:05:46 --> Helper loaded: url_helper
INFO - 2022-06-23 09:05:46 --> Helper loaded: file_helper
INFO - 2022-06-23 09:05:46 --> Database Driver Class Initialized
INFO - 2022-06-23 09:05:46 --> Email Class Initialized
DEBUG - 2022-06-23 09:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 09:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 09:05:46 --> Controller Class Initialized
INFO - 2022-06-23 09:05:46 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 09:05:46 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 09:05:46 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 09:05:46 --> Final output sent to browser
DEBUG - 2022-06-23 09:05:46 --> Total execution time: 0.0220
INFO - 2022-06-23 09:05:59 --> Config Class Initialized
INFO - 2022-06-23 09:05:59 --> Hooks Class Initialized
INFO - 2022-06-23 09:05:59 --> Config Class Initialized
INFO - 2022-06-23 09:05:59 --> Hooks Class Initialized
DEBUG - 2022-06-23 09:05:59 --> UTF-8 Support Enabled
INFO - 2022-06-23 09:05:59 --> Utf8 Class Initialized
DEBUG - 2022-06-23 09:05:59 --> UTF-8 Support Enabled
INFO - 2022-06-23 09:05:59 --> Utf8 Class Initialized
INFO - 2022-06-23 09:05:59 --> URI Class Initialized
INFO - 2022-06-23 09:05:59 --> URI Class Initialized
INFO - 2022-06-23 09:05:59 --> Router Class Initialized
INFO - 2022-06-23 09:05:59 --> Router Class Initialized
INFO - 2022-06-23 09:05:59 --> Output Class Initialized
INFO - 2022-06-23 09:05:59 --> Output Class Initialized
INFO - 2022-06-23 09:05:59 --> Security Class Initialized
INFO - 2022-06-23 09:05:59 --> Security Class Initialized
DEBUG - 2022-06-23 09:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 09:05:59 --> Input Class Initialized
INFO - 2022-06-23 09:05:59 --> Input Class Initialized
INFO - 2022-06-23 09:05:59 --> Language Class Initialized
INFO - 2022-06-23 09:05:59 --> Language Class Initialized
INFO - 2022-06-23 09:05:59 --> Loader Class Initialized
INFO - 2022-06-23 09:05:59 --> Loader Class Initialized
INFO - 2022-06-23 09:05:59 --> Helper loaded: url_helper
INFO - 2022-06-23 09:05:59 --> Helper loaded: url_helper
INFO - 2022-06-23 09:05:59 --> Helper loaded: file_helper
INFO - 2022-06-23 09:05:59 --> Helper loaded: file_helper
INFO - 2022-06-23 09:05:59 --> Database Driver Class Initialized
INFO - 2022-06-23 09:05:59 --> Database Driver Class Initialized
INFO - 2022-06-23 09:05:59 --> Email Class Initialized
INFO - 2022-06-23 09:05:59 --> Email Class Initialized
DEBUG - 2022-06-23 09:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 09:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 09:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 09:05:59 --> Controller Class Initialized
INFO - 2022-06-23 09:05:59 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 09:05:59 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 09:05:59 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 09:05:59 --> Final output sent to browser
DEBUG - 2022-06-23 09:05:59 --> Total execution time: 0.0299
INFO - 2022-06-23 09:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 09:05:59 --> Controller Class Initialized
INFO - 2022-06-23 09:05:59 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 09:05:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 09:05:59 --> Query error: Column 'ud_mob' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_mob`, `ud_otp`) VALUES (NULL, NULL)
INFO - 2022-06-23 09:05:59 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-23 09:06:02 --> Config Class Initialized
INFO - 2022-06-23 09:06:02 --> Hooks Class Initialized
DEBUG - 2022-06-23 09:06:02 --> UTF-8 Support Enabled
INFO - 2022-06-23 09:06:02 --> Utf8 Class Initialized
INFO - 2022-06-23 09:06:02 --> URI Class Initialized
INFO - 2022-06-23 09:06:02 --> Router Class Initialized
INFO - 2022-06-23 09:06:02 --> Output Class Initialized
INFO - 2022-06-23 09:06:02 --> Security Class Initialized
DEBUG - 2022-06-23 09:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 09:06:02 --> Input Class Initialized
INFO - 2022-06-23 09:06:02 --> Language Class Initialized
INFO - 2022-06-23 09:06:02 --> Loader Class Initialized
INFO - 2022-06-23 09:06:02 --> Helper loaded: url_helper
INFO - 2022-06-23 09:06:02 --> Helper loaded: file_helper
INFO - 2022-06-23 09:06:02 --> Database Driver Class Initialized
INFO - 2022-06-23 09:06:02 --> Email Class Initialized
DEBUG - 2022-06-23 09:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 09:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 09:06:02 --> Controller Class Initialized
INFO - 2022-06-23 09:06:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 09:06:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 09:06:02 --> Query error: Column 'ud_mob' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_mob`, `ud_otp`) VALUES (NULL, NULL)
INFO - 2022-06-23 09:06:02 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-23 09:16:51 --> Config Class Initialized
INFO - 2022-06-23 09:16:51 --> Hooks Class Initialized
DEBUG - 2022-06-23 09:16:51 --> UTF-8 Support Enabled
INFO - 2022-06-23 09:16:51 --> Utf8 Class Initialized
INFO - 2022-06-23 09:16:51 --> URI Class Initialized
INFO - 2022-06-23 09:16:51 --> Router Class Initialized
INFO - 2022-06-23 09:16:51 --> Output Class Initialized
INFO - 2022-06-23 09:16:51 --> Security Class Initialized
DEBUG - 2022-06-23 09:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 09:16:51 --> Input Class Initialized
INFO - 2022-06-23 09:16:51 --> Language Class Initialized
INFO - 2022-06-23 09:16:51 --> Loader Class Initialized
INFO - 2022-06-23 09:16:51 --> Helper loaded: url_helper
INFO - 2022-06-23 09:16:51 --> Helper loaded: file_helper
INFO - 2022-06-23 09:16:51 --> Database Driver Class Initialized
INFO - 2022-06-23 09:16:51 --> Email Class Initialized
DEBUG - 2022-06-23 09:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 09:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 09:16:51 --> Controller Class Initialized
INFO - 2022-06-23 09:16:51 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 09:16:51 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 09:16:51 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 09:16:51 --> Final output sent to browser
DEBUG - 2022-06-23 09:16:51 --> Total execution time: 0.0469
INFO - 2022-06-23 09:17:06 --> Config Class Initialized
INFO - 2022-06-23 09:17:06 --> Hooks Class Initialized
DEBUG - 2022-06-23 09:17:06 --> UTF-8 Support Enabled
INFO - 2022-06-23 09:17:06 --> Config Class Initialized
INFO - 2022-06-23 09:17:06 --> Utf8 Class Initialized
INFO - 2022-06-23 09:17:06 --> Hooks Class Initialized
INFO - 2022-06-23 09:17:06 --> URI Class Initialized
DEBUG - 2022-06-23 09:17:06 --> UTF-8 Support Enabled
INFO - 2022-06-23 09:17:06 --> Utf8 Class Initialized
INFO - 2022-06-23 09:17:06 --> Router Class Initialized
INFO - 2022-06-23 09:17:06 --> Output Class Initialized
INFO - 2022-06-23 09:17:06 --> Security Class Initialized
DEBUG - 2022-06-23 09:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 09:17:06 --> Input Class Initialized
INFO - 2022-06-23 09:17:06 --> Language Class Initialized
INFO - 2022-06-23 09:17:06 --> Loader Class Initialized
INFO - 2022-06-23 09:17:06 --> Helper loaded: url_helper
INFO - 2022-06-23 09:17:06 --> Helper loaded: file_helper
INFO - 2022-06-23 09:17:06 --> Database Driver Class Initialized
INFO - 2022-06-23 09:17:06 --> Email Class Initialized
DEBUG - 2022-06-23 09:17:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 09:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 09:17:06 --> Controller Class Initialized
INFO - 2022-06-23 09:17:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 09:17:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 09:17:06 --> Query error: Column 'ud_mob' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_mob`, `ud_otp`) VALUES (NULL, NULL)
INFO - 2022-06-23 09:17:06 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-23 09:17:06 --> URI Class Initialized
INFO - 2022-06-23 09:17:06 --> Router Class Initialized
INFO - 2022-06-23 09:17:06 --> Output Class Initialized
INFO - 2022-06-23 09:17:06 --> Security Class Initialized
DEBUG - 2022-06-23 09:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 09:17:06 --> Input Class Initialized
INFO - 2022-06-23 09:17:06 --> Language Class Initialized
INFO - 2022-06-23 09:17:06 --> Loader Class Initialized
INFO - 2022-06-23 09:17:06 --> Helper loaded: url_helper
INFO - 2022-06-23 09:17:06 --> Helper loaded: file_helper
INFO - 2022-06-23 09:17:06 --> Database Driver Class Initialized
INFO - 2022-06-23 09:17:06 --> Email Class Initialized
DEBUG - 2022-06-23 09:17:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 09:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 09:17:06 --> Controller Class Initialized
INFO - 2022-06-23 09:17:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 09:17:06 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 09:17:06 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 09:17:06 --> Final output sent to browser
DEBUG - 2022-06-23 09:17:06 --> Total execution time: 0.1371
INFO - 2022-06-23 09:17:10 --> Config Class Initialized
INFO - 2022-06-23 09:17:10 --> Hooks Class Initialized
DEBUG - 2022-06-23 09:17:10 --> UTF-8 Support Enabled
INFO - 2022-06-23 09:17:10 --> Utf8 Class Initialized
INFO - 2022-06-23 09:17:10 --> URI Class Initialized
INFO - 2022-06-23 09:17:10 --> Router Class Initialized
INFO - 2022-06-23 09:17:10 --> Output Class Initialized
INFO - 2022-06-23 09:17:10 --> Security Class Initialized
DEBUG - 2022-06-23 09:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 09:17:10 --> Input Class Initialized
INFO - 2022-06-23 09:17:10 --> Language Class Initialized
INFO - 2022-06-23 09:17:10 --> Loader Class Initialized
INFO - 2022-06-23 09:17:10 --> Helper loaded: url_helper
INFO - 2022-06-23 09:17:10 --> Helper loaded: file_helper
INFO - 2022-06-23 09:17:10 --> Database Driver Class Initialized
INFO - 2022-06-23 09:17:10 --> Email Class Initialized
DEBUG - 2022-06-23 09:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 09:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 09:17:10 --> Controller Class Initialized
INFO - 2022-06-23 09:17:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 09:17:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 09:17:10 --> Query error: Column 'ud_mob' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_mob`, `ud_otp`) VALUES (NULL, NULL)
INFO - 2022-06-23 09:17:10 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-23 09:52:02 --> Config Class Initialized
INFO - 2022-06-23 09:52:02 --> Hooks Class Initialized
DEBUG - 2022-06-23 09:52:02 --> UTF-8 Support Enabled
INFO - 2022-06-23 09:52:02 --> Utf8 Class Initialized
INFO - 2022-06-23 09:52:02 --> URI Class Initialized
INFO - 2022-06-23 09:52:02 --> Router Class Initialized
INFO - 2022-06-23 09:52:02 --> Output Class Initialized
INFO - 2022-06-23 09:52:02 --> Security Class Initialized
DEBUG - 2022-06-23 09:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 09:52:02 --> Input Class Initialized
INFO - 2022-06-23 09:52:02 --> Language Class Initialized
INFO - 2022-06-23 09:52:02 --> Loader Class Initialized
INFO - 2022-06-23 09:52:02 --> Helper loaded: url_helper
INFO - 2022-06-23 09:52:02 --> Helper loaded: file_helper
INFO - 2022-06-23 09:52:02 --> Database Driver Class Initialized
INFO - 2022-06-23 09:52:02 --> Email Class Initialized
DEBUG - 2022-06-23 09:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 09:52:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 09:52:02 --> Controller Class Initialized
INFO - 2022-06-23 09:52:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 09:52:02 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 09:52:02 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 09:52:02 --> Final output sent to browser
DEBUG - 2022-06-23 09:52:02 --> Total execution time: 0.0485
INFO - 2022-06-23 09:52:18 --> Config Class Initialized
INFO - 2022-06-23 09:52:18 --> Hooks Class Initialized
DEBUG - 2022-06-23 09:52:18 --> UTF-8 Support Enabled
INFO - 2022-06-23 09:52:18 --> Utf8 Class Initialized
INFO - 2022-06-23 09:52:18 --> URI Class Initialized
INFO - 2022-06-23 09:52:18 --> Router Class Initialized
INFO - 2022-06-23 09:52:18 --> Output Class Initialized
INFO - 2022-06-23 09:52:18 --> Security Class Initialized
DEBUG - 2022-06-23 09:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 09:52:18 --> Input Class Initialized
INFO - 2022-06-23 09:52:18 --> Language Class Initialized
INFO - 2022-06-23 09:52:18 --> Loader Class Initialized
INFO - 2022-06-23 09:52:18 --> Helper loaded: url_helper
INFO - 2022-06-23 09:52:18 --> Helper loaded: file_helper
INFO - 2022-06-23 09:52:18 --> Database Driver Class Initialized
INFO - 2022-06-23 09:52:18 --> Email Class Initialized
DEBUG - 2022-06-23 09:52:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 09:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 09:52:18 --> Controller Class Initialized
INFO - 2022-06-23 09:52:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 09:52:18 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 09:52:18 --> Config Class Initialized
INFO - 2022-06-23 09:52:18 --> Hooks Class Initialized
ERROR - 2022-06-23 09:52:18 --> Query error: Column 'ud_mob' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_mob`, `ud_otp`) VALUES (NULL, NULL)
DEBUG - 2022-06-23 09:52:18 --> UTF-8 Support Enabled
INFO - 2022-06-23 09:52:18 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-23 09:52:18 --> Utf8 Class Initialized
INFO - 2022-06-23 09:52:18 --> URI Class Initialized
INFO - 2022-06-23 09:52:18 --> Router Class Initialized
INFO - 2022-06-23 09:52:18 --> Output Class Initialized
INFO - 2022-06-23 09:52:18 --> Security Class Initialized
DEBUG - 2022-06-23 09:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 09:52:18 --> Input Class Initialized
INFO - 2022-06-23 09:52:18 --> Language Class Initialized
INFO - 2022-06-23 09:52:18 --> Loader Class Initialized
INFO - 2022-06-23 09:52:18 --> Helper loaded: url_helper
INFO - 2022-06-23 09:52:18 --> Helper loaded: file_helper
INFO - 2022-06-23 09:52:18 --> Database Driver Class Initialized
INFO - 2022-06-23 09:52:18 --> Email Class Initialized
DEBUG - 2022-06-23 09:52:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 09:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 09:52:18 --> Controller Class Initialized
INFO - 2022-06-23 09:52:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 09:52:18 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 09:52:18 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 09:52:18 --> Final output sent to browser
DEBUG - 2022-06-23 09:52:18 --> Total execution time: 0.0346
INFO - 2022-06-23 09:52:24 --> Config Class Initialized
INFO - 2022-06-23 09:52:24 --> Hooks Class Initialized
DEBUG - 2022-06-23 09:52:24 --> UTF-8 Support Enabled
INFO - 2022-06-23 09:52:24 --> Utf8 Class Initialized
INFO - 2022-06-23 09:52:24 --> URI Class Initialized
INFO - 2022-06-23 09:52:24 --> Router Class Initialized
INFO - 2022-06-23 09:52:24 --> Output Class Initialized
INFO - 2022-06-23 09:52:24 --> Security Class Initialized
DEBUG - 2022-06-23 09:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 09:52:24 --> Input Class Initialized
INFO - 2022-06-23 09:52:24 --> Language Class Initialized
INFO - 2022-06-23 09:52:24 --> Loader Class Initialized
INFO - 2022-06-23 09:52:24 --> Helper loaded: url_helper
INFO - 2022-06-23 09:52:24 --> Helper loaded: file_helper
INFO - 2022-06-23 09:52:24 --> Database Driver Class Initialized
INFO - 2022-06-23 09:52:24 --> Email Class Initialized
DEBUG - 2022-06-23 09:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 09:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 09:52:24 --> Controller Class Initialized
INFO - 2022-06-23 09:52:24 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 09:52:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 09:52:24 --> Query error: Column 'ud_mob' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_mob`, `ud_otp`) VALUES (NULL, NULL)
INFO - 2022-06-23 09:52:24 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-23 09:53:56 --> Config Class Initialized
INFO - 2022-06-23 09:53:56 --> Hooks Class Initialized
DEBUG - 2022-06-23 09:53:56 --> UTF-8 Support Enabled
INFO - 2022-06-23 09:53:56 --> Utf8 Class Initialized
INFO - 2022-06-23 09:53:56 --> URI Class Initialized
INFO - 2022-06-23 09:53:56 --> Router Class Initialized
INFO - 2022-06-23 09:53:56 --> Output Class Initialized
INFO - 2022-06-23 09:53:56 --> Security Class Initialized
DEBUG - 2022-06-23 09:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 09:53:56 --> Input Class Initialized
INFO - 2022-06-23 09:53:56 --> Language Class Initialized
INFO - 2022-06-23 09:53:56 --> Loader Class Initialized
INFO - 2022-06-23 09:53:56 --> Helper loaded: url_helper
INFO - 2022-06-23 09:53:56 --> Helper loaded: file_helper
INFO - 2022-06-23 09:53:56 --> Database Driver Class Initialized
INFO - 2022-06-23 09:53:56 --> Email Class Initialized
DEBUG - 2022-06-23 09:53:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 09:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 09:53:56 --> Controller Class Initialized
INFO - 2022-06-23 09:53:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 09:53:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 09:53:56 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 09:53:56 --> Final output sent to browser
DEBUG - 2022-06-23 09:53:56 --> Total execution time: 0.0239
INFO - 2022-06-23 09:54:09 --> Config Class Initialized
INFO - 2022-06-23 09:54:09 --> Hooks Class Initialized
DEBUG - 2022-06-23 09:54:09 --> UTF-8 Support Enabled
INFO - 2022-06-23 09:54:09 --> Utf8 Class Initialized
INFO - 2022-06-23 09:54:09 --> Config Class Initialized
INFO - 2022-06-23 09:54:09 --> URI Class Initialized
INFO - 2022-06-23 09:54:09 --> Hooks Class Initialized
DEBUG - 2022-06-23 09:54:09 --> UTF-8 Support Enabled
INFO - 2022-06-23 09:54:09 --> Utf8 Class Initialized
INFO - 2022-06-23 09:54:09 --> Router Class Initialized
INFO - 2022-06-23 09:54:09 --> URI Class Initialized
INFO - 2022-06-23 09:54:09 --> Output Class Initialized
INFO - 2022-06-23 09:54:09 --> Router Class Initialized
INFO - 2022-06-23 09:54:09 --> Security Class Initialized
INFO - 2022-06-23 09:54:09 --> Output Class Initialized
DEBUG - 2022-06-23 09:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 09:54:09 --> Input Class Initialized
INFO - 2022-06-23 09:54:09 --> Security Class Initialized
INFO - 2022-06-23 09:54:09 --> Language Class Initialized
DEBUG - 2022-06-23 09:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 09:54:09 --> Input Class Initialized
INFO - 2022-06-23 09:54:09 --> Loader Class Initialized
INFO - 2022-06-23 09:54:09 --> Language Class Initialized
INFO - 2022-06-23 09:54:09 --> Loader Class Initialized
INFO - 2022-06-23 09:54:09 --> Helper loaded: url_helper
INFO - 2022-06-23 09:54:09 --> Helper loaded: file_helper
INFO - 2022-06-23 09:54:09 --> Helper loaded: url_helper
INFO - 2022-06-23 09:54:09 --> Helper loaded: file_helper
INFO - 2022-06-23 09:54:09 --> Database Driver Class Initialized
INFO - 2022-06-23 09:54:09 --> Database Driver Class Initialized
INFO - 2022-06-23 09:54:09 --> Email Class Initialized
DEBUG - 2022-06-23 09:54:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 09:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 09:54:09 --> Controller Class Initialized
INFO - 2022-06-23 09:54:09 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 09:54:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 09:54:09 --> Query error: Column 'ud_mob' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_mob`, `ud_otp`) VALUES (NULL, NULL)
INFO - 2022-06-23 09:54:09 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-23 09:54:09 --> Email Class Initialized
DEBUG - 2022-06-23 09:54:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 09:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 09:54:09 --> Controller Class Initialized
INFO - 2022-06-23 09:54:09 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 09:54:09 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 09:54:09 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 09:54:09 --> Final output sent to browser
DEBUG - 2022-06-23 09:54:09 --> Total execution time: 0.0517
INFO - 2022-06-23 09:54:20 --> Config Class Initialized
INFO - 2022-06-23 09:54:20 --> Hooks Class Initialized
DEBUG - 2022-06-23 09:54:20 --> UTF-8 Support Enabled
INFO - 2022-06-23 09:54:20 --> Utf8 Class Initialized
INFO - 2022-06-23 09:54:20 --> URI Class Initialized
INFO - 2022-06-23 09:54:20 --> Router Class Initialized
INFO - 2022-06-23 09:54:20 --> Output Class Initialized
INFO - 2022-06-23 09:54:20 --> Security Class Initialized
DEBUG - 2022-06-23 09:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 09:54:20 --> Input Class Initialized
INFO - 2022-06-23 09:54:20 --> Language Class Initialized
INFO - 2022-06-23 09:54:20 --> Loader Class Initialized
INFO - 2022-06-23 09:54:20 --> Helper loaded: url_helper
INFO - 2022-06-23 09:54:20 --> Helper loaded: file_helper
INFO - 2022-06-23 09:54:20 --> Database Driver Class Initialized
INFO - 2022-06-23 09:54:20 --> Email Class Initialized
DEBUG - 2022-06-23 09:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 09:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 09:54:20 --> Controller Class Initialized
INFO - 2022-06-23 09:54:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 09:54:20 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 09:54:20 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 09:54:20 --> Final output sent to browser
DEBUG - 2022-06-23 09:54:20 --> Total execution time: 0.0400
INFO - 2022-06-23 09:54:31 --> Config Class Initialized
INFO - 2022-06-23 09:54:31 --> Hooks Class Initialized
INFO - 2022-06-23 09:54:31 --> Config Class Initialized
INFO - 2022-06-23 09:54:31 --> Hooks Class Initialized
DEBUG - 2022-06-23 09:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:54:31 --> UTF-8 Support Enabled
INFO - 2022-06-23 09:54:31 --> Utf8 Class Initialized
INFO - 2022-06-23 09:54:31 --> Utf8 Class Initialized
INFO - 2022-06-23 09:54:31 --> URI Class Initialized
INFO - 2022-06-23 09:54:31 --> URI Class Initialized
INFO - 2022-06-23 09:54:31 --> Router Class Initialized
INFO - 2022-06-23 09:54:31 --> Router Class Initialized
INFO - 2022-06-23 09:54:31 --> Output Class Initialized
INFO - 2022-06-23 09:54:31 --> Output Class Initialized
INFO - 2022-06-23 09:54:31 --> Security Class Initialized
INFO - 2022-06-23 09:54:31 --> Security Class Initialized
DEBUG - 2022-06-23 09:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 09:54:31 --> Input Class Initialized
DEBUG - 2022-06-23 09:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 09:54:31 --> Input Class Initialized
INFO - 2022-06-23 09:54:31 --> Language Class Initialized
INFO - 2022-06-23 09:54:31 --> Language Class Initialized
INFO - 2022-06-23 09:54:31 --> Loader Class Initialized
INFO - 2022-06-23 09:54:31 --> Loader Class Initialized
INFO - 2022-06-23 09:54:31 --> Helper loaded: url_helper
INFO - 2022-06-23 09:54:31 --> Helper loaded: url_helper
INFO - 2022-06-23 09:54:31 --> Helper loaded: file_helper
INFO - 2022-06-23 09:54:31 --> Helper loaded: file_helper
INFO - 2022-06-23 09:54:31 --> Database Driver Class Initialized
INFO - 2022-06-23 09:54:31 --> Database Driver Class Initialized
INFO - 2022-06-23 09:54:31 --> Email Class Initialized
INFO - 2022-06-23 09:54:31 --> Email Class Initialized
DEBUG - 2022-06-23 09:54:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 09:54:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 09:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 09:54:31 --> Controller Class Initialized
INFO - 2022-06-23 09:54:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 09:54:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 09:54:31 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 09:54:31 --> Final output sent to browser
DEBUG - 2022-06-23 09:54:31 --> Total execution time: 0.0239
INFO - 2022-06-23 09:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 09:54:31 --> Controller Class Initialized
INFO - 2022-06-23 09:54:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 09:54:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 09:54:31 --> Final output sent to browser
DEBUG - 2022-06-23 09:54:31 --> Total execution time: 0.0309
INFO - 2022-06-23 09:54:35 --> Config Class Initialized
INFO - 2022-06-23 09:54:35 --> Hooks Class Initialized
DEBUG - 2022-06-23 09:54:35 --> UTF-8 Support Enabled
INFO - 2022-06-23 09:54:35 --> Utf8 Class Initialized
INFO - 2022-06-23 09:54:35 --> URI Class Initialized
INFO - 2022-06-23 09:54:35 --> Router Class Initialized
INFO - 2022-06-23 09:54:35 --> Output Class Initialized
INFO - 2022-06-23 09:54:35 --> Security Class Initialized
DEBUG - 2022-06-23 09:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 09:54:35 --> Input Class Initialized
INFO - 2022-06-23 09:54:35 --> Language Class Initialized
INFO - 2022-06-23 09:54:35 --> Loader Class Initialized
INFO - 2022-06-23 09:54:35 --> Helper loaded: url_helper
INFO - 2022-06-23 09:54:35 --> Helper loaded: file_helper
INFO - 2022-06-23 09:54:35 --> Database Driver Class Initialized
INFO - 2022-06-23 09:54:35 --> Email Class Initialized
DEBUG - 2022-06-23 09:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 09:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 09:54:35 --> Controller Class Initialized
INFO - 2022-06-23 09:54:35 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 09:54:35 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 09:54:35 --> Final output sent to browser
DEBUG - 2022-06-23 09:54:35 --> Total execution time: 0.0226
INFO - 2022-06-23 09:54:51 --> Config Class Initialized
INFO - 2022-06-23 09:54:51 --> Hooks Class Initialized
DEBUG - 2022-06-23 09:54:51 --> UTF-8 Support Enabled
INFO - 2022-06-23 09:54:51 --> Utf8 Class Initialized
INFO - 2022-06-23 09:54:51 --> URI Class Initialized
INFO - 2022-06-23 09:54:51 --> Router Class Initialized
INFO - 2022-06-23 09:54:51 --> Output Class Initialized
INFO - 2022-06-23 09:54:51 --> Security Class Initialized
DEBUG - 2022-06-23 09:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 09:54:51 --> Input Class Initialized
INFO - 2022-06-23 09:54:51 --> Language Class Initialized
INFO - 2022-06-23 09:54:51 --> Loader Class Initialized
INFO - 2022-06-23 09:54:51 --> Helper loaded: url_helper
INFO - 2022-06-23 09:54:51 --> Helper loaded: file_helper
INFO - 2022-06-23 09:54:51 --> Database Driver Class Initialized
INFO - 2022-06-23 09:54:51 --> Email Class Initialized
DEBUG - 2022-06-23 09:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 09:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 09:54:51 --> Controller Class Initialized
INFO - 2022-06-23 09:54:51 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 09:54:51 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 09:54:51 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 09:54:51 --> Final output sent to browser
DEBUG - 2022-06-23 09:54:51 --> Total execution time: 0.0193
INFO - 2022-06-23 09:55:03 --> Config Class Initialized
INFO - 2022-06-23 09:55:03 --> Hooks Class Initialized
DEBUG - 2022-06-23 09:55:03 --> UTF-8 Support Enabled
INFO - 2022-06-23 09:55:03 --> Utf8 Class Initialized
INFO - 2022-06-23 09:55:03 --> URI Class Initialized
INFO - 2022-06-23 09:55:03 --> Router Class Initialized
INFO - 2022-06-23 09:55:03 --> Output Class Initialized
INFO - 2022-06-23 09:55:03 --> Security Class Initialized
DEBUG - 2022-06-23 09:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 09:55:03 --> Input Class Initialized
INFO - 2022-06-23 09:55:03 --> Language Class Initialized
INFO - 2022-06-23 09:55:03 --> Loader Class Initialized
INFO - 2022-06-23 09:55:03 --> Helper loaded: url_helper
INFO - 2022-06-23 09:55:03 --> Helper loaded: file_helper
INFO - 2022-06-23 09:55:03 --> Database Driver Class Initialized
INFO - 2022-06-23 09:55:03 --> Email Class Initialized
DEBUG - 2022-06-23 09:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 09:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 09:55:03 --> Controller Class Initialized
INFO - 2022-06-23 09:55:03 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 09:55:03 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 09:55:03 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 09:55:03 --> Final output sent to browser
DEBUG - 2022-06-23 09:55:03 --> Total execution time: 0.0500
INFO - 2022-06-23 09:55:13 --> Config Class Initialized
INFO - 2022-06-23 09:55:13 --> Config Class Initialized
INFO - 2022-06-23 09:55:13 --> Hooks Class Initialized
INFO - 2022-06-23 09:55:13 --> Hooks Class Initialized
DEBUG - 2022-06-23 09:55:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:55:13 --> UTF-8 Support Enabled
INFO - 2022-06-23 09:55:13 --> Utf8 Class Initialized
INFO - 2022-06-23 09:55:13 --> Utf8 Class Initialized
INFO - 2022-06-23 09:55:13 --> URI Class Initialized
INFO - 2022-06-23 09:55:13 --> URI Class Initialized
INFO - 2022-06-23 09:55:13 --> Router Class Initialized
INFO - 2022-06-23 09:55:13 --> Router Class Initialized
INFO - 2022-06-23 09:55:13 --> Output Class Initialized
INFO - 2022-06-23 09:55:13 --> Output Class Initialized
INFO - 2022-06-23 09:55:13 --> Security Class Initialized
INFO - 2022-06-23 09:55:13 --> Security Class Initialized
DEBUG - 2022-06-23 09:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 09:55:13 --> Input Class Initialized
DEBUG - 2022-06-23 09:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 09:55:13 --> Input Class Initialized
INFO - 2022-06-23 09:55:13 --> Language Class Initialized
INFO - 2022-06-23 09:55:13 --> Language Class Initialized
INFO - 2022-06-23 09:55:13 --> Loader Class Initialized
INFO - 2022-06-23 09:55:13 --> Loader Class Initialized
INFO - 2022-06-23 09:55:13 --> Helper loaded: url_helper
INFO - 2022-06-23 09:55:13 --> Helper loaded: url_helper
INFO - 2022-06-23 09:55:13 --> Helper loaded: file_helper
INFO - 2022-06-23 09:55:13 --> Helper loaded: file_helper
INFO - 2022-06-23 09:55:13 --> Database Driver Class Initialized
INFO - 2022-06-23 09:55:13 --> Database Driver Class Initialized
INFO - 2022-06-23 09:55:13 --> Email Class Initialized
DEBUG - 2022-06-23 09:55:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 09:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 09:55:13 --> Controller Class Initialized
INFO - 2022-06-23 09:55:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 09:55:13 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 09:55:13 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 09:55:13 --> Final output sent to browser
DEBUG - 2022-06-23 09:55:13 --> Total execution time: 0.0311
INFO - 2022-06-23 09:55:13 --> Email Class Initialized
DEBUG - 2022-06-23 09:55:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 09:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 09:55:13 --> Controller Class Initialized
INFO - 2022-06-23 09:55:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 09:55:13 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 09:55:13 --> Final output sent to browser
DEBUG - 2022-06-23 09:55:13 --> Total execution time: 0.0484
INFO - 2022-06-23 09:55:16 --> Config Class Initialized
INFO - 2022-06-23 09:55:16 --> Hooks Class Initialized
DEBUG - 2022-06-23 09:55:16 --> UTF-8 Support Enabled
INFO - 2022-06-23 09:55:16 --> Utf8 Class Initialized
INFO - 2022-06-23 09:55:16 --> URI Class Initialized
INFO - 2022-06-23 09:55:16 --> Router Class Initialized
INFO - 2022-06-23 09:55:16 --> Output Class Initialized
INFO - 2022-06-23 09:55:16 --> Security Class Initialized
DEBUG - 2022-06-23 09:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 09:55:16 --> Input Class Initialized
INFO - 2022-06-23 09:55:16 --> Language Class Initialized
INFO - 2022-06-23 09:55:16 --> Loader Class Initialized
INFO - 2022-06-23 09:55:16 --> Helper loaded: url_helper
INFO - 2022-06-23 09:55:16 --> Helper loaded: file_helper
INFO - 2022-06-23 09:55:16 --> Database Driver Class Initialized
INFO - 2022-06-23 09:55:16 --> Email Class Initialized
DEBUG - 2022-06-23 09:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 09:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 09:55:16 --> Controller Class Initialized
INFO - 2022-06-23 09:55:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 09:55:16 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 09:55:16 --> Final output sent to browser
DEBUG - 2022-06-23 09:55:16 --> Total execution time: 0.0223
INFO - 2022-06-23 09:59:11 --> Config Class Initialized
INFO - 2022-06-23 09:59:11 --> Hooks Class Initialized
DEBUG - 2022-06-23 09:59:11 --> UTF-8 Support Enabled
INFO - 2022-06-23 09:59:11 --> Utf8 Class Initialized
INFO - 2022-06-23 09:59:11 --> URI Class Initialized
INFO - 2022-06-23 09:59:11 --> Router Class Initialized
INFO - 2022-06-23 09:59:11 --> Output Class Initialized
INFO - 2022-06-23 09:59:11 --> Security Class Initialized
DEBUG - 2022-06-23 09:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 09:59:11 --> Input Class Initialized
INFO - 2022-06-23 09:59:11 --> Language Class Initialized
INFO - 2022-06-23 09:59:11 --> Loader Class Initialized
INFO - 2022-06-23 09:59:11 --> Helper loaded: url_helper
INFO - 2022-06-23 09:59:11 --> Helper loaded: file_helper
INFO - 2022-06-23 09:59:11 --> Database Driver Class Initialized
INFO - 2022-06-23 09:59:11 --> Email Class Initialized
DEBUG - 2022-06-23 09:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 09:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 09:59:11 --> Controller Class Initialized
INFO - 2022-06-23 09:59:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 09:59:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 09:59:11 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 09:59:11 --> Final output sent to browser
DEBUG - 2022-06-23 09:59:11 --> Total execution time: 0.0552
INFO - 2022-06-23 09:59:33 --> Config Class Initialized
INFO - 2022-06-23 09:59:33 --> Hooks Class Initialized
DEBUG - 2022-06-23 09:59:33 --> UTF-8 Support Enabled
INFO - 2022-06-23 09:59:33 --> Utf8 Class Initialized
INFO - 2022-06-23 09:59:33 --> URI Class Initialized
INFO - 2022-06-23 09:59:33 --> Router Class Initialized
INFO - 2022-06-23 09:59:33 --> Output Class Initialized
INFO - 2022-06-23 09:59:33 --> Config Class Initialized
INFO - 2022-06-23 09:59:33 --> Security Class Initialized
INFO - 2022-06-23 09:59:33 --> Hooks Class Initialized
DEBUG - 2022-06-23 09:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:59:33 --> UTF-8 Support Enabled
INFO - 2022-06-23 09:59:33 --> Input Class Initialized
INFO - 2022-06-23 09:59:33 --> Utf8 Class Initialized
INFO - 2022-06-23 09:59:33 --> Language Class Initialized
INFO - 2022-06-23 09:59:33 --> URI Class Initialized
INFO - 2022-06-23 09:59:33 --> Router Class Initialized
INFO - 2022-06-23 09:59:33 --> Loader Class Initialized
INFO - 2022-06-23 09:59:33 --> Output Class Initialized
INFO - 2022-06-23 09:59:33 --> Helper loaded: url_helper
INFO - 2022-06-23 09:59:33 --> Security Class Initialized
INFO - 2022-06-23 09:59:33 --> Helper loaded: file_helper
DEBUG - 2022-06-23 09:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 09:59:33 --> Input Class Initialized
INFO - 2022-06-23 09:59:33 --> Database Driver Class Initialized
INFO - 2022-06-23 09:59:33 --> Language Class Initialized
INFO - 2022-06-23 09:59:33 --> Loader Class Initialized
INFO - 2022-06-23 09:59:33 --> Helper loaded: url_helper
INFO - 2022-06-23 09:59:33 --> Email Class Initialized
INFO - 2022-06-23 09:59:33 --> Helper loaded: file_helper
INFO - 2022-06-23 09:59:33 --> Database Driver Class Initialized
DEBUG - 2022-06-23 09:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 09:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 09:59:33 --> Controller Class Initialized
INFO - 2022-06-23 09:59:33 --> Email Class Initialized
INFO - 2022-06-23 09:59:33 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 09:59:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 09:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 09:59:33 --> Final output sent to browser
DEBUG - 2022-06-23 09:59:33 --> Total execution time: 0.0318
INFO - 2022-06-23 09:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 09:59:33 --> Controller Class Initialized
INFO - 2022-06-23 09:59:33 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 09:59:33 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 09:59:33 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 09:59:33 --> Final output sent to browser
DEBUG - 2022-06-23 09:59:33 --> Total execution time: 0.0293
INFO - 2022-06-23 09:59:48 --> Config Class Initialized
INFO - 2022-06-23 09:59:48 --> Hooks Class Initialized
INFO - 2022-06-23 09:59:48 --> Config Class Initialized
INFO - 2022-06-23 09:59:48 --> Hooks Class Initialized
DEBUG - 2022-06-23 09:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 09:59:48 --> UTF-8 Support Enabled
INFO - 2022-06-23 09:59:48 --> Utf8 Class Initialized
INFO - 2022-06-23 09:59:48 --> Utf8 Class Initialized
INFO - 2022-06-23 09:59:48 --> URI Class Initialized
INFO - 2022-06-23 09:59:48 --> URI Class Initialized
INFO - 2022-06-23 09:59:48 --> Router Class Initialized
INFO - 2022-06-23 09:59:48 --> Router Class Initialized
INFO - 2022-06-23 09:59:48 --> Output Class Initialized
INFO - 2022-06-23 09:59:48 --> Output Class Initialized
INFO - 2022-06-23 09:59:48 --> Security Class Initialized
INFO - 2022-06-23 09:59:48 --> Security Class Initialized
DEBUG - 2022-06-23 09:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 09:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 09:59:48 --> Input Class Initialized
INFO - 2022-06-23 09:59:48 --> Input Class Initialized
INFO - 2022-06-23 09:59:48 --> Language Class Initialized
INFO - 2022-06-23 09:59:48 --> Language Class Initialized
INFO - 2022-06-23 09:59:48 --> Loader Class Initialized
INFO - 2022-06-23 09:59:48 --> Loader Class Initialized
INFO - 2022-06-23 09:59:48 --> Helper loaded: url_helper
INFO - 2022-06-23 09:59:48 --> Helper loaded: url_helper
INFO - 2022-06-23 09:59:48 --> Helper loaded: file_helper
INFO - 2022-06-23 09:59:48 --> Helper loaded: file_helper
INFO - 2022-06-23 09:59:48 --> Database Driver Class Initialized
INFO - 2022-06-23 09:59:48 --> Database Driver Class Initialized
INFO - 2022-06-23 09:59:48 --> Email Class Initialized
INFO - 2022-06-23 09:59:48 --> Email Class Initialized
DEBUG - 2022-06-23 09:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 09:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 09:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 09:59:48 --> Controller Class Initialized
INFO - 2022-06-23 09:59:48 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 09:59:48 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 09:59:48 --> Final output sent to browser
DEBUG - 2022-06-23 09:59:48 --> Total execution time: 0.0232
INFO - 2022-06-23 09:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 09:59:48 --> Controller Class Initialized
INFO - 2022-06-23 09:59:48 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 09:59:48 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 09:59:48 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 09:59:48 --> Final output sent to browser
DEBUG - 2022-06-23 09:59:48 --> Total execution time: 0.0267
INFO - 2022-06-23 09:59:55 --> Config Class Initialized
INFO - 2022-06-23 09:59:55 --> Hooks Class Initialized
DEBUG - 2022-06-23 09:59:55 --> UTF-8 Support Enabled
INFO - 2022-06-23 09:59:55 --> Utf8 Class Initialized
INFO - 2022-06-23 09:59:55 --> URI Class Initialized
INFO - 2022-06-23 09:59:55 --> Router Class Initialized
INFO - 2022-06-23 09:59:55 --> Output Class Initialized
INFO - 2022-06-23 09:59:55 --> Security Class Initialized
DEBUG - 2022-06-23 09:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 09:59:55 --> Input Class Initialized
INFO - 2022-06-23 09:59:55 --> Language Class Initialized
INFO - 2022-06-23 09:59:55 --> Loader Class Initialized
INFO - 2022-06-23 09:59:55 --> Helper loaded: url_helper
INFO - 2022-06-23 09:59:55 --> Helper loaded: file_helper
INFO - 2022-06-23 09:59:55 --> Database Driver Class Initialized
INFO - 2022-06-23 09:59:55 --> Email Class Initialized
DEBUG - 2022-06-23 09:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 09:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 09:59:55 --> Controller Class Initialized
INFO - 2022-06-23 09:59:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 09:59:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 09:59:55 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 09:59:55 --> Final output sent to browser
DEBUG - 2022-06-23 09:59:55 --> Total execution time: 0.0411
INFO - 2022-06-23 10:00:10 --> Config Class Initialized
INFO - 2022-06-23 10:00:10 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:00:10 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:00:10 --> Utf8 Class Initialized
INFO - 2022-06-23 10:00:10 --> URI Class Initialized
INFO - 2022-06-23 10:00:10 --> Router Class Initialized
INFO - 2022-06-23 10:00:10 --> Output Class Initialized
INFO - 2022-06-23 10:00:10 --> Security Class Initialized
DEBUG - 2022-06-23 10:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:00:10 --> Input Class Initialized
INFO - 2022-06-23 10:00:10 --> Language Class Initialized
INFO - 2022-06-23 10:00:10 --> Loader Class Initialized
INFO - 2022-06-23 10:00:10 --> Helper loaded: url_helper
INFO - 2022-06-23 10:00:10 --> Helper loaded: file_helper
INFO - 2022-06-23 10:00:10 --> Database Driver Class Initialized
INFO - 2022-06-23 10:00:10 --> Email Class Initialized
DEBUG - 2022-06-23 10:00:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:00:10 --> Controller Class Initialized
INFO - 2022-06-23 10:00:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:00:10 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:00:10 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 10:00:10 --> Final output sent to browser
DEBUG - 2022-06-23 10:00:10 --> Total execution time: 0.0412
INFO - 2022-06-23 10:00:13 --> Config Class Initialized
INFO - 2022-06-23 10:00:13 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:00:13 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:00:13 --> Utf8 Class Initialized
INFO - 2022-06-23 10:00:13 --> URI Class Initialized
INFO - 2022-06-23 10:00:13 --> Router Class Initialized
INFO - 2022-06-23 10:00:13 --> Output Class Initialized
INFO - 2022-06-23 10:00:13 --> Security Class Initialized
DEBUG - 2022-06-23 10:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:00:13 --> Input Class Initialized
INFO - 2022-06-23 10:00:13 --> Language Class Initialized
INFO - 2022-06-23 10:00:13 --> Loader Class Initialized
INFO - 2022-06-23 10:00:13 --> Helper loaded: url_helper
INFO - 2022-06-23 10:00:13 --> Helper loaded: file_helper
INFO - 2022-06-23 10:00:13 --> Database Driver Class Initialized
INFO - 2022-06-23 10:00:13 --> Email Class Initialized
DEBUG - 2022-06-23 10:00:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:00:13 --> Controller Class Initialized
INFO - 2022-06-23 10:00:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:00:13 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:00:13 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 10:00:13 --> Final output sent to browser
DEBUG - 2022-06-23 10:00:13 --> Total execution time: 0.0221
INFO - 2022-06-23 10:00:25 --> Config Class Initialized
INFO - 2022-06-23 10:00:25 --> Hooks Class Initialized
INFO - 2022-06-23 10:00:25 --> Config Class Initialized
DEBUG - 2022-06-23 10:00:25 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:00:25 --> Hooks Class Initialized
INFO - 2022-06-23 10:00:25 --> Utf8 Class Initialized
DEBUG - 2022-06-23 10:00:25 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:00:25 --> Utf8 Class Initialized
INFO - 2022-06-23 10:00:25 --> URI Class Initialized
INFO - 2022-06-23 10:00:25 --> URI Class Initialized
INFO - 2022-06-23 10:00:25 --> Router Class Initialized
INFO - 2022-06-23 10:00:25 --> Router Class Initialized
INFO - 2022-06-23 10:00:25 --> Output Class Initialized
INFO - 2022-06-23 10:00:25 --> Output Class Initialized
INFO - 2022-06-23 10:00:25 --> Security Class Initialized
DEBUG - 2022-06-23 10:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:00:25 --> Security Class Initialized
INFO - 2022-06-23 10:00:25 --> Input Class Initialized
DEBUG - 2022-06-23 10:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:00:25 --> Language Class Initialized
INFO - 2022-06-23 10:00:25 --> Input Class Initialized
INFO - 2022-06-23 10:00:25 --> Loader Class Initialized
INFO - 2022-06-23 10:00:25 --> Language Class Initialized
INFO - 2022-06-23 10:00:25 --> Helper loaded: url_helper
INFO - 2022-06-23 10:00:25 --> Loader Class Initialized
INFO - 2022-06-23 10:00:25 --> Helper loaded: file_helper
INFO - 2022-06-23 10:00:25 --> Helper loaded: url_helper
INFO - 2022-06-23 10:00:25 --> Helper loaded: file_helper
INFO - 2022-06-23 10:00:25 --> Database Driver Class Initialized
INFO - 2022-06-23 10:00:25 --> Database Driver Class Initialized
INFO - 2022-06-23 10:00:25 --> Email Class Initialized
INFO - 2022-06-23 10:00:25 --> Email Class Initialized
DEBUG - 2022-06-23 10:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 10:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:00:25 --> Controller Class Initialized
INFO - 2022-06-23 10:00:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:00:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 10:00:25 --> Query error: Column 'ud_mob' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_mob`, `ud_otp`) VALUES (NULL, NULL)
INFO - 2022-06-23 10:00:25 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-23 10:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:00:25 --> Controller Class Initialized
INFO - 2022-06-23 10:00:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:00:25 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:00:25 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 10:00:25 --> Final output sent to browser
DEBUG - 2022-06-23 10:00:25 --> Total execution time: 0.0361
INFO - 2022-06-23 10:00:29 --> Config Class Initialized
INFO - 2022-06-23 10:00:29 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:00:29 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:00:29 --> Utf8 Class Initialized
INFO - 2022-06-23 10:00:29 --> URI Class Initialized
INFO - 2022-06-23 10:00:29 --> Router Class Initialized
INFO - 2022-06-23 10:00:29 --> Output Class Initialized
INFO - 2022-06-23 10:00:29 --> Security Class Initialized
DEBUG - 2022-06-23 10:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:00:29 --> Input Class Initialized
INFO - 2022-06-23 10:00:29 --> Language Class Initialized
INFO - 2022-06-23 10:00:29 --> Loader Class Initialized
INFO - 2022-06-23 10:00:29 --> Helper loaded: url_helper
INFO - 2022-06-23 10:00:29 --> Helper loaded: file_helper
INFO - 2022-06-23 10:00:29 --> Database Driver Class Initialized
INFO - 2022-06-23 10:00:29 --> Email Class Initialized
DEBUG - 2022-06-23 10:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:00:29 --> Controller Class Initialized
INFO - 2022-06-23 10:00:29 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:00:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 10:00:29 --> Query error: Column 'ud_mob' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_mob`, `ud_otp`) VALUES (NULL, NULL)
INFO - 2022-06-23 10:00:29 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-23 10:01:29 --> Config Class Initialized
INFO - 2022-06-23 10:01:29 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:01:29 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:01:29 --> Utf8 Class Initialized
INFO - 2022-06-23 10:01:29 --> URI Class Initialized
INFO - 2022-06-23 10:01:29 --> Router Class Initialized
INFO - 2022-06-23 10:01:29 --> Output Class Initialized
INFO - 2022-06-23 10:01:29 --> Security Class Initialized
DEBUG - 2022-06-23 10:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:01:29 --> Input Class Initialized
INFO - 2022-06-23 10:01:29 --> Language Class Initialized
INFO - 2022-06-23 10:01:29 --> Loader Class Initialized
INFO - 2022-06-23 10:01:29 --> Helper loaded: url_helper
INFO - 2022-06-23 10:01:29 --> Helper loaded: file_helper
INFO - 2022-06-23 10:01:29 --> Database Driver Class Initialized
INFO - 2022-06-23 10:01:29 --> Email Class Initialized
DEBUG - 2022-06-23 10:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:01:29 --> Controller Class Initialized
INFO - 2022-06-23 10:01:29 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:01:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 10:01:29 --> Query error: Column 'ud_mob' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_mob`) VALUES (NULL)
INFO - 2022-06-23 10:01:29 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-23 10:01:33 --> Config Class Initialized
INFO - 2022-06-23 10:01:33 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:01:33 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:01:33 --> Utf8 Class Initialized
INFO - 2022-06-23 10:01:33 --> URI Class Initialized
INFO - 2022-06-23 10:01:33 --> Router Class Initialized
INFO - 2022-06-23 10:01:33 --> Output Class Initialized
INFO - 2022-06-23 10:01:33 --> Security Class Initialized
DEBUG - 2022-06-23 10:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:01:33 --> Input Class Initialized
INFO - 2022-06-23 10:01:33 --> Language Class Initialized
INFO - 2022-06-23 10:01:33 --> Loader Class Initialized
INFO - 2022-06-23 10:01:33 --> Helper loaded: url_helper
INFO - 2022-06-23 10:01:33 --> Helper loaded: file_helper
INFO - 2022-06-23 10:01:33 --> Database Driver Class Initialized
INFO - 2022-06-23 10:01:33 --> Email Class Initialized
DEBUG - 2022-06-23 10:01:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:01:33 --> Controller Class Initialized
INFO - 2022-06-23 10:01:33 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:01:33 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:01:33 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 10:01:33 --> Final output sent to browser
DEBUG - 2022-06-23 10:01:33 --> Total execution time: 0.0222
INFO - 2022-06-23 10:01:43 --> Config Class Initialized
INFO - 2022-06-23 10:01:43 --> Config Class Initialized
INFO - 2022-06-23 10:01:43 --> Hooks Class Initialized
INFO - 2022-06-23 10:01:43 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:01:43 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:01:43 --> Utf8 Class Initialized
INFO - 2022-06-23 10:01:43 --> Utf8 Class Initialized
INFO - 2022-06-23 10:01:43 --> URI Class Initialized
INFO - 2022-06-23 10:01:43 --> URI Class Initialized
INFO - 2022-06-23 10:01:43 --> Router Class Initialized
INFO - 2022-06-23 10:01:43 --> Router Class Initialized
INFO - 2022-06-23 10:01:43 --> Output Class Initialized
INFO - 2022-06-23 10:01:43 --> Output Class Initialized
INFO - 2022-06-23 10:01:43 --> Security Class Initialized
INFO - 2022-06-23 10:01:43 --> Security Class Initialized
DEBUG - 2022-06-23 10:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:01:43 --> Input Class Initialized
INFO - 2022-06-23 10:01:43 --> Input Class Initialized
INFO - 2022-06-23 10:01:43 --> Language Class Initialized
INFO - 2022-06-23 10:01:43 --> Language Class Initialized
INFO - 2022-06-23 10:01:43 --> Loader Class Initialized
INFO - 2022-06-23 10:01:43 --> Loader Class Initialized
INFO - 2022-06-23 10:01:43 --> Helper loaded: url_helper
INFO - 2022-06-23 10:01:43 --> Helper loaded: url_helper
INFO - 2022-06-23 10:01:43 --> Helper loaded: file_helper
INFO - 2022-06-23 10:01:43 --> Helper loaded: file_helper
INFO - 2022-06-23 10:01:43 --> Database Driver Class Initialized
INFO - 2022-06-23 10:01:43 --> Database Driver Class Initialized
INFO - 2022-06-23 10:01:43 --> Email Class Initialized
INFO - 2022-06-23 10:01:43 --> Email Class Initialized
DEBUG - 2022-06-23 10:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 10:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:01:43 --> Controller Class Initialized
INFO - 2022-06-23 10:01:43 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:01:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 10:01:43 --> Query error: Column 'ud_mob' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_mob`) VALUES (NULL)
INFO - 2022-06-23 10:01:43 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-23 10:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:01:43 --> Controller Class Initialized
INFO - 2022-06-23 10:01:43 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:01:43 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:01:43 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 10:01:43 --> Final output sent to browser
DEBUG - 2022-06-23 10:01:43 --> Total execution time: 0.0332
INFO - 2022-06-23 10:01:49 --> Config Class Initialized
INFO - 2022-06-23 10:01:49 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:01:49 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:01:49 --> Utf8 Class Initialized
INFO - 2022-06-23 10:01:49 --> URI Class Initialized
INFO - 2022-06-23 10:01:49 --> Router Class Initialized
INFO - 2022-06-23 10:01:49 --> Output Class Initialized
INFO - 2022-06-23 10:01:49 --> Security Class Initialized
DEBUG - 2022-06-23 10:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:01:49 --> Input Class Initialized
INFO - 2022-06-23 10:01:49 --> Language Class Initialized
INFO - 2022-06-23 10:01:49 --> Loader Class Initialized
INFO - 2022-06-23 10:01:49 --> Helper loaded: url_helper
INFO - 2022-06-23 10:01:49 --> Helper loaded: file_helper
INFO - 2022-06-23 10:01:49 --> Database Driver Class Initialized
INFO - 2022-06-23 10:01:49 --> Email Class Initialized
DEBUG - 2022-06-23 10:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:01:49 --> Controller Class Initialized
INFO - 2022-06-23 10:01:49 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:01:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 10:01:49 --> Query error: Column 'ud_mob' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_mob`) VALUES (NULL)
INFO - 2022-06-23 10:01:49 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-23 10:02:20 --> Config Class Initialized
INFO - 2022-06-23 10:02:20 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:02:20 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:02:20 --> Utf8 Class Initialized
INFO - 2022-06-23 10:02:20 --> URI Class Initialized
INFO - 2022-06-23 10:02:20 --> Router Class Initialized
INFO - 2022-06-23 10:02:20 --> Output Class Initialized
INFO - 2022-06-23 10:02:20 --> Security Class Initialized
DEBUG - 2022-06-23 10:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:02:20 --> Input Class Initialized
INFO - 2022-06-23 10:02:20 --> Language Class Initialized
INFO - 2022-06-23 10:02:20 --> Loader Class Initialized
INFO - 2022-06-23 10:02:20 --> Helper loaded: url_helper
INFO - 2022-06-23 10:02:20 --> Helper loaded: file_helper
INFO - 2022-06-23 10:02:20 --> Database Driver Class Initialized
INFO - 2022-06-23 10:02:20 --> Email Class Initialized
DEBUG - 2022-06-23 10:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:02:20 --> Controller Class Initialized
INFO - 2022-06-23 10:02:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:02:20 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:02:20 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 10:02:20 --> Final output sent to browser
DEBUG - 2022-06-23 10:02:20 --> Total execution time: 0.0192
INFO - 2022-06-23 10:02:29 --> Config Class Initialized
INFO - 2022-06-23 10:02:29 --> Hooks Class Initialized
INFO - 2022-06-23 10:02:29 --> Config Class Initialized
INFO - 2022-06-23 10:02:29 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:02:29 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:02:29 --> Utf8 Class Initialized
DEBUG - 2022-06-23 10:02:29 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:02:29 --> URI Class Initialized
INFO - 2022-06-23 10:02:29 --> Utf8 Class Initialized
INFO - 2022-06-23 10:02:29 --> URI Class Initialized
INFO - 2022-06-23 10:02:29 --> Router Class Initialized
INFO - 2022-06-23 10:02:29 --> Router Class Initialized
INFO - 2022-06-23 10:02:29 --> Output Class Initialized
INFO - 2022-06-23 10:02:29 --> Security Class Initialized
INFO - 2022-06-23 10:02:29 --> Output Class Initialized
DEBUG - 2022-06-23 10:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:02:29 --> Security Class Initialized
INFO - 2022-06-23 10:02:29 --> Input Class Initialized
DEBUG - 2022-06-23 10:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:02:29 --> Language Class Initialized
INFO - 2022-06-23 10:02:29 --> Input Class Initialized
INFO - 2022-06-23 10:02:29 --> Language Class Initialized
INFO - 2022-06-23 10:02:29 --> Loader Class Initialized
INFO - 2022-06-23 10:02:29 --> Loader Class Initialized
INFO - 2022-06-23 10:02:29 --> Helper loaded: url_helper
INFO - 2022-06-23 10:02:29 --> Helper loaded: url_helper
INFO - 2022-06-23 10:02:29 --> Helper loaded: file_helper
INFO - 2022-06-23 10:02:29 --> Helper loaded: file_helper
INFO - 2022-06-23 10:02:29 --> Database Driver Class Initialized
INFO - 2022-06-23 10:02:29 --> Database Driver Class Initialized
INFO - 2022-06-23 10:02:29 --> Email Class Initialized
INFO - 2022-06-23 10:02:29 --> Email Class Initialized
DEBUG - 2022-06-23 10:02:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 10:02:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:02:29 --> Controller Class Initialized
INFO - 2022-06-23 10:02:29 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:02:29 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:02:29 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 10:02:29 --> Final output sent to browser
DEBUG - 2022-06-23 10:02:29 --> Total execution time: 0.0261
INFO - 2022-06-23 10:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:02:29 --> Controller Class Initialized
INFO - 2022-06-23 10:02:29 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:02:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 10:02:29 --> Query error: Column 'ud_mob' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_mob`) VALUES (NULL)
INFO - 2022-06-23 10:02:29 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-23 10:02:32 --> Config Class Initialized
INFO - 2022-06-23 10:02:32 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:02:32 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:02:32 --> Utf8 Class Initialized
INFO - 2022-06-23 10:02:32 --> URI Class Initialized
INFO - 2022-06-23 10:02:32 --> Router Class Initialized
INFO - 2022-06-23 10:02:32 --> Output Class Initialized
INFO - 2022-06-23 10:02:32 --> Security Class Initialized
DEBUG - 2022-06-23 10:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:02:32 --> Input Class Initialized
INFO - 2022-06-23 10:02:32 --> Language Class Initialized
INFO - 2022-06-23 10:02:32 --> Loader Class Initialized
INFO - 2022-06-23 10:02:32 --> Helper loaded: url_helper
INFO - 2022-06-23 10:02:32 --> Helper loaded: file_helper
INFO - 2022-06-23 10:02:32 --> Database Driver Class Initialized
INFO - 2022-06-23 10:02:32 --> Email Class Initialized
DEBUG - 2022-06-23 10:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:02:32 --> Controller Class Initialized
INFO - 2022-06-23 10:02:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:02:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 10:02:32 --> Query error: Column 'ud_mob' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_mob`) VALUES (NULL)
INFO - 2022-06-23 10:02:32 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-23 10:02:59 --> Config Class Initialized
INFO - 2022-06-23 10:02:59 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:02:59 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:02:59 --> Utf8 Class Initialized
INFO - 2022-06-23 10:02:59 --> URI Class Initialized
INFO - 2022-06-23 10:02:59 --> Router Class Initialized
INFO - 2022-06-23 10:02:59 --> Output Class Initialized
INFO - 2022-06-23 10:02:59 --> Security Class Initialized
DEBUG - 2022-06-23 10:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:02:59 --> Input Class Initialized
INFO - 2022-06-23 10:02:59 --> Language Class Initialized
INFO - 2022-06-23 10:02:59 --> Loader Class Initialized
INFO - 2022-06-23 10:02:59 --> Helper loaded: url_helper
INFO - 2022-06-23 10:02:59 --> Helper loaded: file_helper
INFO - 2022-06-23 10:02:59 --> Database Driver Class Initialized
INFO - 2022-06-23 10:02:59 --> Email Class Initialized
DEBUG - 2022-06-23 10:02:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:02:59 --> Controller Class Initialized
INFO - 2022-06-23 10:02:59 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:02:59 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:02:59 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 10:02:59 --> Final output sent to browser
DEBUG - 2022-06-23 10:02:59 --> Total execution time: 0.0347
INFO - 2022-06-23 10:03:47 --> Config Class Initialized
INFO - 2022-06-23 10:03:47 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:03:47 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:03:47 --> Utf8 Class Initialized
INFO - 2022-06-23 10:03:47 --> URI Class Initialized
INFO - 2022-06-23 10:03:47 --> Router Class Initialized
INFO - 2022-06-23 10:03:47 --> Output Class Initialized
INFO - 2022-06-23 10:03:47 --> Security Class Initialized
DEBUG - 2022-06-23 10:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:03:47 --> Input Class Initialized
INFO - 2022-06-23 10:03:47 --> Language Class Initialized
INFO - 2022-06-23 10:03:47 --> Loader Class Initialized
INFO - 2022-06-23 10:03:47 --> Helper loaded: url_helper
INFO - 2022-06-23 10:03:47 --> Helper loaded: file_helper
INFO - 2022-06-23 10:03:47 --> Database Driver Class Initialized
INFO - 2022-06-23 10:03:47 --> Email Class Initialized
DEBUG - 2022-06-23 10:03:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:03:47 --> Controller Class Initialized
INFO - 2022-06-23 10:03:47 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:03:47 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:03:47 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 10:03:47 --> Final output sent to browser
DEBUG - 2022-06-23 10:03:47 --> Total execution time: 0.0196
INFO - 2022-06-23 10:04:00 --> Config Class Initialized
INFO - 2022-06-23 10:04:00 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:04:00 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:04:00 --> Utf8 Class Initialized
INFO - 2022-06-23 10:04:00 --> URI Class Initialized
INFO - 2022-06-23 10:04:00 --> Config Class Initialized
INFO - 2022-06-23 10:04:00 --> Router Class Initialized
INFO - 2022-06-23 10:04:00 --> Hooks Class Initialized
INFO - 2022-06-23 10:04:00 --> Output Class Initialized
DEBUG - 2022-06-23 10:04:00 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:04:00 --> Security Class Initialized
INFO - 2022-06-23 10:04:00 --> Utf8 Class Initialized
INFO - 2022-06-23 10:04:00 --> URI Class Initialized
DEBUG - 2022-06-23 10:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:04:00 --> Input Class Initialized
INFO - 2022-06-23 10:04:00 --> Router Class Initialized
INFO - 2022-06-23 10:04:00 --> Language Class Initialized
INFO - 2022-06-23 10:04:00 --> Output Class Initialized
INFO - 2022-06-23 10:04:00 --> Loader Class Initialized
INFO - 2022-06-23 10:04:00 --> Security Class Initialized
DEBUG - 2022-06-23 10:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:04:00 --> Helper loaded: url_helper
INFO - 2022-06-23 10:04:00 --> Input Class Initialized
INFO - 2022-06-23 10:04:00 --> Language Class Initialized
INFO - 2022-06-23 10:04:00 --> Helper loaded: file_helper
INFO - 2022-06-23 10:04:00 --> Loader Class Initialized
INFO - 2022-06-23 10:04:00 --> Database Driver Class Initialized
INFO - 2022-06-23 10:04:00 --> Helper loaded: url_helper
INFO - 2022-06-23 10:04:00 --> Helper loaded: file_helper
INFO - 2022-06-23 10:04:00 --> Database Driver Class Initialized
INFO - 2022-06-23 10:04:00 --> Email Class Initialized
DEBUG - 2022-06-23 10:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:04:00 --> Email Class Initialized
INFO - 2022-06-23 10:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:04:00 --> Controller Class Initialized
DEBUG - 2022-06-23 10:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:04:00 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:04:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 10:04:00 --> Query error: Column 'ud_mob' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_mob`) VALUES (NULL)
INFO - 2022-06-23 10:04:00 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-23 10:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:04:00 --> Controller Class Initialized
INFO - 2022-06-23 10:04:00 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:04:00 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:04:00 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 10:04:00 --> Final output sent to browser
DEBUG - 2022-06-23 10:04:00 --> Total execution time: 0.0322
INFO - 2022-06-23 10:04:05 --> Config Class Initialized
INFO - 2022-06-23 10:04:05 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:04:05 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:04:05 --> Utf8 Class Initialized
INFO - 2022-06-23 10:04:05 --> URI Class Initialized
INFO - 2022-06-23 10:04:05 --> Router Class Initialized
INFO - 2022-06-23 10:04:05 --> Output Class Initialized
INFO - 2022-06-23 10:04:05 --> Security Class Initialized
DEBUG - 2022-06-23 10:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:04:05 --> Input Class Initialized
INFO - 2022-06-23 10:04:05 --> Language Class Initialized
INFO - 2022-06-23 10:04:05 --> Loader Class Initialized
INFO - 2022-06-23 10:04:05 --> Helper loaded: url_helper
INFO - 2022-06-23 10:04:05 --> Helper loaded: file_helper
INFO - 2022-06-23 10:04:05 --> Database Driver Class Initialized
INFO - 2022-06-23 10:04:05 --> Email Class Initialized
DEBUG - 2022-06-23 10:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:04:05 --> Controller Class Initialized
INFO - 2022-06-23 10:04:05 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:04:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 10:04:05 --> Query error: Column 'ud_mob' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_mob`) VALUES (NULL)
INFO - 2022-06-23 10:04:05 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-23 10:04:49 --> Config Class Initialized
INFO - 2022-06-23 10:04:49 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:04:49 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:04:49 --> Utf8 Class Initialized
INFO - 2022-06-23 10:04:49 --> URI Class Initialized
INFO - 2022-06-23 10:04:49 --> Router Class Initialized
INFO - 2022-06-23 10:04:49 --> Output Class Initialized
INFO - 2022-06-23 10:04:49 --> Security Class Initialized
DEBUG - 2022-06-23 10:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:04:49 --> Input Class Initialized
INFO - 2022-06-23 10:04:49 --> Language Class Initialized
INFO - 2022-06-23 10:04:49 --> Loader Class Initialized
INFO - 2022-06-23 10:04:49 --> Helper loaded: url_helper
INFO - 2022-06-23 10:04:49 --> Helper loaded: file_helper
INFO - 2022-06-23 10:04:49 --> Database Driver Class Initialized
INFO - 2022-06-23 10:04:49 --> Email Class Initialized
DEBUG - 2022-06-23 10:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:04:49 --> Controller Class Initialized
INFO - 2022-06-23 10:04:49 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:04:49 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:04:49 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 10:04:49 --> Final output sent to browser
DEBUG - 2022-06-23 10:04:49 --> Total execution time: 0.0218
INFO - 2022-06-23 10:05:06 --> Config Class Initialized
INFO - 2022-06-23 10:05:06 --> Config Class Initialized
INFO - 2022-06-23 10:05:06 --> Hooks Class Initialized
INFO - 2022-06-23 10:05:06 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:05:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:05:06 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:05:06 --> Utf8 Class Initialized
INFO - 2022-06-23 10:05:06 --> Utf8 Class Initialized
INFO - 2022-06-23 10:05:06 --> URI Class Initialized
INFO - 2022-06-23 10:05:06 --> URI Class Initialized
INFO - 2022-06-23 10:05:06 --> Router Class Initialized
INFO - 2022-06-23 10:05:06 --> Router Class Initialized
INFO - 2022-06-23 10:05:06 --> Output Class Initialized
INFO - 2022-06-23 10:05:06 --> Output Class Initialized
INFO - 2022-06-23 10:05:06 --> Security Class Initialized
INFO - 2022-06-23 10:05:06 --> Security Class Initialized
DEBUG - 2022-06-23 10:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:05:06 --> Input Class Initialized
INFO - 2022-06-23 10:05:06 --> Input Class Initialized
INFO - 2022-06-23 10:05:06 --> Language Class Initialized
INFO - 2022-06-23 10:05:06 --> Language Class Initialized
INFO - 2022-06-23 10:05:06 --> Loader Class Initialized
INFO - 2022-06-23 10:05:06 --> Loader Class Initialized
INFO - 2022-06-23 10:05:06 --> Helper loaded: url_helper
INFO - 2022-06-23 10:05:06 --> Helper loaded: url_helper
INFO - 2022-06-23 10:05:06 --> Helper loaded: file_helper
INFO - 2022-06-23 10:05:06 --> Helper loaded: file_helper
INFO - 2022-06-23 10:05:06 --> Database Driver Class Initialized
INFO - 2022-06-23 10:05:06 --> Database Driver Class Initialized
INFO - 2022-06-23 10:05:06 --> Email Class Initialized
INFO - 2022-06-23 10:05:06 --> Email Class Initialized
DEBUG - 2022-06-23 10:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 10:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:05:06 --> Controller Class Initialized
INFO - 2022-06-23 10:05:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:05:06 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:05:06 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 10:05:06 --> Final output sent to browser
DEBUG - 2022-06-23 10:05:06 --> Total execution time: 0.0273
INFO - 2022-06-23 10:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:05:06 --> Controller Class Initialized
INFO - 2022-06-23 10:05:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:05:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 10:05:06 --> Query error: Column 'ud_mob' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_mob`) VALUES (NULL)
INFO - 2022-06-23 10:05:06 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-23 10:05:13 --> Config Class Initialized
INFO - 2022-06-23 10:05:13 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:05:13 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:05:13 --> Utf8 Class Initialized
INFO - 2022-06-23 10:05:13 --> URI Class Initialized
INFO - 2022-06-23 10:05:13 --> Router Class Initialized
INFO - 2022-06-23 10:05:13 --> Output Class Initialized
INFO - 2022-06-23 10:05:13 --> Security Class Initialized
DEBUG - 2022-06-23 10:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:05:13 --> Input Class Initialized
INFO - 2022-06-23 10:05:13 --> Language Class Initialized
INFO - 2022-06-23 10:05:13 --> Loader Class Initialized
INFO - 2022-06-23 10:05:13 --> Helper loaded: url_helper
INFO - 2022-06-23 10:05:13 --> Helper loaded: file_helper
INFO - 2022-06-23 10:05:13 --> Database Driver Class Initialized
INFO - 2022-06-23 10:05:13 --> Email Class Initialized
DEBUG - 2022-06-23 10:05:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:05:13 --> Controller Class Initialized
INFO - 2022-06-23 10:05:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:05:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 10:05:13 --> Query error: Column 'ud_mob' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_mob`) VALUES (NULL)
INFO - 2022-06-23 10:05:13 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-23 10:07:06 --> Config Class Initialized
INFO - 2022-06-23 10:07:06 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:07:06 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:07:06 --> Utf8 Class Initialized
INFO - 2022-06-23 10:07:06 --> URI Class Initialized
INFO - 2022-06-23 10:07:06 --> Router Class Initialized
INFO - 2022-06-23 10:07:06 --> Output Class Initialized
INFO - 2022-06-23 10:07:06 --> Security Class Initialized
DEBUG - 2022-06-23 10:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:07:06 --> Input Class Initialized
INFO - 2022-06-23 10:07:06 --> Language Class Initialized
INFO - 2022-06-23 10:07:06 --> Loader Class Initialized
INFO - 2022-06-23 10:07:06 --> Helper loaded: url_helper
INFO - 2022-06-23 10:07:06 --> Helper loaded: file_helper
INFO - 2022-06-23 10:07:06 --> Database Driver Class Initialized
INFO - 2022-06-23 10:07:06 --> Email Class Initialized
DEBUG - 2022-06-23 10:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:07:06 --> Controller Class Initialized
INFO - 2022-06-23 10:07:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:07:06 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:07:06 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 10:07:06 --> Final output sent to browser
DEBUG - 2022-06-23 10:07:06 --> Total execution time: 0.0586
INFO - 2022-06-23 10:07:11 --> Config Class Initialized
INFO - 2022-06-23 10:07:11 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:07:11 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:07:11 --> Utf8 Class Initialized
INFO - 2022-06-23 10:07:11 --> URI Class Initialized
INFO - 2022-06-23 10:07:11 --> Router Class Initialized
INFO - 2022-06-23 10:07:11 --> Output Class Initialized
INFO - 2022-06-23 10:07:11 --> Security Class Initialized
DEBUG - 2022-06-23 10:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:07:11 --> Input Class Initialized
INFO - 2022-06-23 10:07:11 --> Language Class Initialized
INFO - 2022-06-23 10:07:11 --> Loader Class Initialized
INFO - 2022-06-23 10:07:11 --> Helper loaded: url_helper
INFO - 2022-06-23 10:07:11 --> Helper loaded: file_helper
INFO - 2022-06-23 10:07:11 --> Database Driver Class Initialized
INFO - 2022-06-23 10:07:11 --> Email Class Initialized
DEBUG - 2022-06-23 10:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:07:11 --> Controller Class Initialized
INFO - 2022-06-23 10:07:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:07:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:07:11 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 10:07:11 --> Final output sent to browser
DEBUG - 2022-06-23 10:07:11 --> Total execution time: 0.0435
INFO - 2022-06-23 10:07:23 --> Config Class Initialized
INFO - 2022-06-23 10:07:23 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:07:23 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:07:23 --> Utf8 Class Initialized
INFO - 2022-06-23 10:07:23 --> URI Class Initialized
INFO - 2022-06-23 10:07:23 --> Config Class Initialized
INFO - 2022-06-23 10:07:23 --> Router Class Initialized
INFO - 2022-06-23 10:07:23 --> Hooks Class Initialized
INFO - 2022-06-23 10:07:23 --> Output Class Initialized
DEBUG - 2022-06-23 10:07:23 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:07:23 --> Utf8 Class Initialized
INFO - 2022-06-23 10:07:23 --> Security Class Initialized
INFO - 2022-06-23 10:07:23 --> URI Class Initialized
DEBUG - 2022-06-23 10:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:07:23 --> Input Class Initialized
INFO - 2022-06-23 10:07:23 --> Language Class Initialized
INFO - 2022-06-23 10:07:23 --> Router Class Initialized
INFO - 2022-06-23 10:07:23 --> Loader Class Initialized
INFO - 2022-06-23 10:07:23 --> Output Class Initialized
INFO - 2022-06-23 10:07:23 --> Helper loaded: url_helper
INFO - 2022-06-23 10:07:23 --> Security Class Initialized
INFO - 2022-06-23 10:07:23 --> Helper loaded: file_helper
DEBUG - 2022-06-23 10:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:07:23 --> Input Class Initialized
INFO - 2022-06-23 10:07:23 --> Database Driver Class Initialized
INFO - 2022-06-23 10:07:23 --> Language Class Initialized
INFO - 2022-06-23 10:07:23 --> Loader Class Initialized
INFO - 2022-06-23 10:07:23 --> Helper loaded: url_helper
INFO - 2022-06-23 10:07:23 --> Helper loaded: file_helper
INFO - 2022-06-23 10:07:23 --> Email Class Initialized
INFO - 2022-06-23 10:07:23 --> Database Driver Class Initialized
DEBUG - 2022-06-23 10:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:07:23 --> Email Class Initialized
INFO - 2022-06-23 10:07:23 --> Controller Class Initialized
INFO - 2022-06-23 10:07:23 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 10:07:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 10:07:23 --> Query error: Column 'ud_mob' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_mob`) VALUES (NULL)
INFO - 2022-06-23 10:07:23 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-23 10:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:07:23 --> Controller Class Initialized
INFO - 2022-06-23 10:07:23 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:07:23 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:07:23 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 10:07:23 --> Final output sent to browser
DEBUG - 2022-06-23 10:07:23 --> Total execution time: 0.0280
INFO - 2022-06-23 10:07:54 --> Config Class Initialized
INFO - 2022-06-23 10:07:54 --> Hooks Class Initialized
INFO - 2022-06-23 10:07:54 --> Config Class Initialized
INFO - 2022-06-23 10:07:54 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:07:54 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:07:54 --> Utf8 Class Initialized
INFO - 2022-06-23 10:07:54 --> Utf8 Class Initialized
INFO - 2022-06-23 10:07:54 --> URI Class Initialized
INFO - 2022-06-23 10:07:54 --> URI Class Initialized
INFO - 2022-06-23 10:07:54 --> Router Class Initialized
INFO - 2022-06-23 10:07:54 --> Router Class Initialized
INFO - 2022-06-23 10:07:54 --> Output Class Initialized
INFO - 2022-06-23 10:07:54 --> Output Class Initialized
INFO - 2022-06-23 10:07:54 --> Security Class Initialized
INFO - 2022-06-23 10:07:54 --> Security Class Initialized
DEBUG - 2022-06-23 10:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:07:54 --> Input Class Initialized
INFO - 2022-06-23 10:07:54 --> Input Class Initialized
INFO - 2022-06-23 10:07:54 --> Language Class Initialized
INFO - 2022-06-23 10:07:54 --> Language Class Initialized
INFO - 2022-06-23 10:07:54 --> Loader Class Initialized
INFO - 2022-06-23 10:07:54 --> Loader Class Initialized
INFO - 2022-06-23 10:07:54 --> Helper loaded: url_helper
INFO - 2022-06-23 10:07:54 --> Helper loaded: url_helper
INFO - 2022-06-23 10:07:54 --> Helper loaded: file_helper
INFO - 2022-06-23 10:07:54 --> Helper loaded: file_helper
INFO - 2022-06-23 10:07:54 --> Database Driver Class Initialized
INFO - 2022-06-23 10:07:54 --> Database Driver Class Initialized
INFO - 2022-06-23 10:07:54 --> Email Class Initialized
INFO - 2022-06-23 10:07:54 --> Email Class Initialized
DEBUG - 2022-06-23 10:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 10:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:07:54 --> Controller Class Initialized
INFO - 2022-06-23 10:07:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:07:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 10:07:54 --> Query error: Column 'ud_mob' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_mob`) VALUES (NULL)
INFO - 2022-06-23 10:07:54 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-23 10:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:07:54 --> Controller Class Initialized
INFO - 2022-06-23 10:07:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:07:54 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:07:54 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 10:07:54 --> Final output sent to browser
DEBUG - 2022-06-23 10:07:54 --> Total execution time: 0.0460
INFO - 2022-06-23 10:08:22 --> Config Class Initialized
INFO - 2022-06-23 10:08:22 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:08:22 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:08:22 --> Utf8 Class Initialized
INFO - 2022-06-23 10:08:22 --> URI Class Initialized
INFO - 2022-06-23 10:08:22 --> Router Class Initialized
INFO - 2022-06-23 10:08:22 --> Output Class Initialized
INFO - 2022-06-23 10:08:22 --> Security Class Initialized
DEBUG - 2022-06-23 10:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:08:22 --> Input Class Initialized
INFO - 2022-06-23 10:08:22 --> Language Class Initialized
INFO - 2022-06-23 10:08:22 --> Loader Class Initialized
INFO - 2022-06-23 10:08:22 --> Helper loaded: url_helper
INFO - 2022-06-23 10:08:22 --> Helper loaded: file_helper
INFO - 2022-06-23 10:08:22 --> Database Driver Class Initialized
INFO - 2022-06-23 10:08:22 --> Email Class Initialized
DEBUG - 2022-06-23 10:08:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:08:22 --> Controller Class Initialized
INFO - 2022-06-23 10:08:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:08:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:08:22 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 10:08:22 --> Final output sent to browser
DEBUG - 2022-06-23 10:08:22 --> Total execution time: 0.0426
INFO - 2022-06-23 10:08:32 --> Config Class Initialized
INFO - 2022-06-23 10:08:32 --> Config Class Initialized
INFO - 2022-06-23 10:08:32 --> Hooks Class Initialized
INFO - 2022-06-23 10:08:32 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:08:32 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:08:32 --> Utf8 Class Initialized
INFO - 2022-06-23 10:08:32 --> Utf8 Class Initialized
INFO - 2022-06-23 10:08:32 --> URI Class Initialized
INFO - 2022-06-23 10:08:32 --> URI Class Initialized
INFO - 2022-06-23 10:08:32 --> Router Class Initialized
INFO - 2022-06-23 10:08:32 --> Router Class Initialized
INFO - 2022-06-23 10:08:32 --> Output Class Initialized
INFO - 2022-06-23 10:08:32 --> Output Class Initialized
INFO - 2022-06-23 10:08:32 --> Security Class Initialized
INFO - 2022-06-23 10:08:32 --> Security Class Initialized
DEBUG - 2022-06-23 10:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:08:32 --> Input Class Initialized
INFO - 2022-06-23 10:08:32 --> Input Class Initialized
INFO - 2022-06-23 10:08:32 --> Language Class Initialized
INFO - 2022-06-23 10:08:32 --> Language Class Initialized
INFO - 2022-06-23 10:08:32 --> Loader Class Initialized
INFO - 2022-06-23 10:08:32 --> Loader Class Initialized
INFO - 2022-06-23 10:08:32 --> Helper loaded: url_helper
INFO - 2022-06-23 10:08:32 --> Helper loaded: url_helper
INFO - 2022-06-23 10:08:32 --> Helper loaded: file_helper
INFO - 2022-06-23 10:08:32 --> Helper loaded: file_helper
INFO - 2022-06-23 10:08:32 --> Database Driver Class Initialized
INFO - 2022-06-23 10:08:32 --> Database Driver Class Initialized
INFO - 2022-06-23 10:08:32 --> Email Class Initialized
INFO - 2022-06-23 10:08:32 --> Email Class Initialized
DEBUG - 2022-06-23 10:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 10:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:08:32 --> Controller Class Initialized
INFO - 2022-06-23 10:08:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:08:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 10:08:32 --> Query error: Column 'ud_mob' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_mob`) VALUES (NULL)
INFO - 2022-06-23 10:08:32 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-23 10:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:08:32 --> Controller Class Initialized
INFO - 2022-06-23 10:08:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:08:32 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:08:32 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 10:08:32 --> Final output sent to browser
DEBUG - 2022-06-23 10:08:32 --> Total execution time: 0.0269
INFO - 2022-06-23 10:08:37 --> Config Class Initialized
INFO - 2022-06-23 10:08:37 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:08:37 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:08:37 --> Utf8 Class Initialized
INFO - 2022-06-23 10:08:37 --> URI Class Initialized
INFO - 2022-06-23 10:08:37 --> Router Class Initialized
INFO - 2022-06-23 10:08:37 --> Output Class Initialized
INFO - 2022-06-23 10:08:37 --> Security Class Initialized
DEBUG - 2022-06-23 10:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:08:37 --> Input Class Initialized
INFO - 2022-06-23 10:08:37 --> Language Class Initialized
INFO - 2022-06-23 10:08:37 --> Loader Class Initialized
INFO - 2022-06-23 10:08:37 --> Helper loaded: url_helper
INFO - 2022-06-23 10:08:37 --> Helper loaded: file_helper
INFO - 2022-06-23 10:08:37 --> Database Driver Class Initialized
INFO - 2022-06-23 10:08:37 --> Email Class Initialized
DEBUG - 2022-06-23 10:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:08:37 --> Controller Class Initialized
INFO - 2022-06-23 10:08:37 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:08:37 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:08:37 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 10:08:37 --> Final output sent to browser
DEBUG - 2022-06-23 10:08:37 --> Total execution time: 0.0189
INFO - 2022-06-23 10:08:46 --> Config Class Initialized
INFO - 2022-06-23 10:08:46 --> Config Class Initialized
INFO - 2022-06-23 10:08:46 --> Hooks Class Initialized
INFO - 2022-06-23 10:08:46 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:08:46 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:08:46 --> Utf8 Class Initialized
INFO - 2022-06-23 10:08:46 --> Utf8 Class Initialized
INFO - 2022-06-23 10:08:46 --> URI Class Initialized
INFO - 2022-06-23 10:08:46 --> URI Class Initialized
INFO - 2022-06-23 10:08:46 --> Router Class Initialized
INFO - 2022-06-23 10:08:46 --> Router Class Initialized
INFO - 2022-06-23 10:08:46 --> Output Class Initialized
INFO - 2022-06-23 10:08:46 --> Output Class Initialized
INFO - 2022-06-23 10:08:46 --> Security Class Initialized
INFO - 2022-06-23 10:08:46 --> Security Class Initialized
DEBUG - 2022-06-23 10:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:08:46 --> Input Class Initialized
INFO - 2022-06-23 10:08:46 --> Input Class Initialized
INFO - 2022-06-23 10:08:46 --> Language Class Initialized
INFO - 2022-06-23 10:08:46 --> Language Class Initialized
INFO - 2022-06-23 10:08:46 --> Loader Class Initialized
INFO - 2022-06-23 10:08:46 --> Loader Class Initialized
INFO - 2022-06-23 10:08:46 --> Helper loaded: url_helper
INFO - 2022-06-23 10:08:46 --> Helper loaded: url_helper
INFO - 2022-06-23 10:08:46 --> Helper loaded: file_helper
INFO - 2022-06-23 10:08:46 --> Helper loaded: file_helper
INFO - 2022-06-23 10:08:46 --> Database Driver Class Initialized
INFO - 2022-06-23 10:08:46 --> Database Driver Class Initialized
INFO - 2022-06-23 10:08:46 --> Email Class Initialized
DEBUG - 2022-06-23 10:08:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:08:46 --> Controller Class Initialized
INFO - 2022-06-23 10:08:46 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:08:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 10:08:46 --> Query error: Column 'ud_mob' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_mob`) VALUES (NULL)
INFO - 2022-06-23 10:08:46 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-23 10:08:46 --> Email Class Initialized
DEBUG - 2022-06-23 10:08:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:08:46 --> Controller Class Initialized
INFO - 2022-06-23 10:08:46 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:08:46 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:08:46 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 10:08:46 --> Final output sent to browser
DEBUG - 2022-06-23 10:08:46 --> Total execution time: 0.0448
INFO - 2022-06-23 10:09:24 --> Config Class Initialized
INFO - 2022-06-23 10:09:24 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:09:24 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:09:24 --> Utf8 Class Initialized
INFO - 2022-06-23 10:09:24 --> URI Class Initialized
INFO - 2022-06-23 10:09:24 --> Router Class Initialized
INFO - 2022-06-23 10:09:24 --> Output Class Initialized
INFO - 2022-06-23 10:09:24 --> Security Class Initialized
DEBUG - 2022-06-23 10:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:09:24 --> Input Class Initialized
INFO - 2022-06-23 10:09:24 --> Language Class Initialized
INFO - 2022-06-23 10:09:24 --> Loader Class Initialized
INFO - 2022-06-23 10:09:24 --> Helper loaded: url_helper
INFO - 2022-06-23 10:09:24 --> Helper loaded: file_helper
INFO - 2022-06-23 10:09:24 --> Database Driver Class Initialized
INFO - 2022-06-23 10:09:24 --> Email Class Initialized
DEBUG - 2022-06-23 10:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:09:24 --> Controller Class Initialized
INFO - 2022-06-23 10:09:24 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:09:24 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:09:24 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 10:09:24 --> Final output sent to browser
DEBUG - 2022-06-23 10:09:24 --> Total execution time: 0.0414
INFO - 2022-06-23 10:09:32 --> Config Class Initialized
INFO - 2022-06-23 10:09:32 --> Config Class Initialized
INFO - 2022-06-23 10:09:32 --> Hooks Class Initialized
INFO - 2022-06-23 10:09:32 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:09:32 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:09:32 --> Utf8 Class Initialized
INFO - 2022-06-23 10:09:32 --> Utf8 Class Initialized
INFO - 2022-06-23 10:09:32 --> URI Class Initialized
INFO - 2022-06-23 10:09:32 --> URI Class Initialized
INFO - 2022-06-23 10:09:32 --> Router Class Initialized
INFO - 2022-06-23 10:09:32 --> Router Class Initialized
INFO - 2022-06-23 10:09:32 --> Output Class Initialized
INFO - 2022-06-23 10:09:32 --> Output Class Initialized
INFO - 2022-06-23 10:09:32 --> Security Class Initialized
INFO - 2022-06-23 10:09:32 --> Security Class Initialized
DEBUG - 2022-06-23 10:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:09:32 --> Input Class Initialized
INFO - 2022-06-23 10:09:32 --> Input Class Initialized
INFO - 2022-06-23 10:09:32 --> Language Class Initialized
INFO - 2022-06-23 10:09:32 --> Language Class Initialized
INFO - 2022-06-23 10:09:32 --> Loader Class Initialized
INFO - 2022-06-23 10:09:32 --> Loader Class Initialized
INFO - 2022-06-23 10:09:32 --> Helper loaded: url_helper
INFO - 2022-06-23 10:09:32 --> Helper loaded: url_helper
INFO - 2022-06-23 10:09:32 --> Helper loaded: file_helper
INFO - 2022-06-23 10:09:32 --> Helper loaded: file_helper
INFO - 2022-06-23 10:09:32 --> Database Driver Class Initialized
INFO - 2022-06-23 10:09:32 --> Database Driver Class Initialized
INFO - 2022-06-23 10:09:32 --> Email Class Initialized
INFO - 2022-06-23 10:09:32 --> Email Class Initialized
DEBUG - 2022-06-23 10:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 10:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:09:32 --> Controller Class Initialized
INFO - 2022-06-23 10:09:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:09:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 10:09:32 --> Query error: Column 'ud_mob' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_mob`) VALUES (NULL)
INFO - 2022-06-23 10:09:32 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-23 10:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:09:32 --> Controller Class Initialized
INFO - 2022-06-23 10:09:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:09:32 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:09:32 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 10:09:32 --> Final output sent to browser
DEBUG - 2022-06-23 10:09:32 --> Total execution time: 0.0271
INFO - 2022-06-23 10:09:45 --> Config Class Initialized
INFO - 2022-06-23 10:09:45 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:09:45 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:09:45 --> Config Class Initialized
INFO - 2022-06-23 10:09:45 --> Utf8 Class Initialized
INFO - 2022-06-23 10:09:45 --> Hooks Class Initialized
INFO - 2022-06-23 10:09:45 --> URI Class Initialized
DEBUG - 2022-06-23 10:09:45 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:09:45 --> Utf8 Class Initialized
INFO - 2022-06-23 10:09:45 --> Router Class Initialized
INFO - 2022-06-23 10:09:45 --> URI Class Initialized
INFO - 2022-06-23 10:09:45 --> Output Class Initialized
INFO - 2022-06-23 10:09:45 --> Router Class Initialized
INFO - 2022-06-23 10:09:45 --> Security Class Initialized
INFO - 2022-06-23 10:09:45 --> Output Class Initialized
DEBUG - 2022-06-23 10:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:09:45 --> Input Class Initialized
INFO - 2022-06-23 10:09:45 --> Security Class Initialized
INFO - 2022-06-23 10:09:45 --> Language Class Initialized
DEBUG - 2022-06-23 10:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:09:45 --> Input Class Initialized
INFO - 2022-06-23 10:09:45 --> Loader Class Initialized
INFO - 2022-06-23 10:09:45 --> Language Class Initialized
INFO - 2022-06-23 10:09:45 --> Helper loaded: url_helper
INFO - 2022-06-23 10:09:45 --> Loader Class Initialized
INFO - 2022-06-23 10:09:45 --> Helper loaded: file_helper
INFO - 2022-06-23 10:09:45 --> Helper loaded: url_helper
INFO - 2022-06-23 10:09:45 --> Database Driver Class Initialized
INFO - 2022-06-23 10:09:45 --> Helper loaded: file_helper
INFO - 2022-06-23 10:09:45 --> Database Driver Class Initialized
INFO - 2022-06-23 10:09:45 --> Email Class Initialized
INFO - 2022-06-23 10:09:45 --> Email Class Initialized
DEBUG - 2022-06-23 10:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 10:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:09:45 --> Controller Class Initialized
INFO - 2022-06-23 10:09:45 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:09:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 10:09:45 --> Query error: Column 'ud_mob' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_mob`) VALUES (NULL)
INFO - 2022-06-23 10:09:45 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-23 10:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:09:45 --> Controller Class Initialized
INFO - 2022-06-23 10:09:45 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:09:45 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:09:45 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 10:09:45 --> Final output sent to browser
DEBUG - 2022-06-23 10:09:45 --> Total execution time: 0.0456
INFO - 2022-06-23 10:09:49 --> Config Class Initialized
INFO - 2022-06-23 10:09:49 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:09:49 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:09:49 --> Utf8 Class Initialized
INFO - 2022-06-23 10:09:49 --> URI Class Initialized
INFO - 2022-06-23 10:09:49 --> Router Class Initialized
INFO - 2022-06-23 10:09:49 --> Output Class Initialized
INFO - 2022-06-23 10:09:49 --> Security Class Initialized
DEBUG - 2022-06-23 10:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:09:49 --> Input Class Initialized
INFO - 2022-06-23 10:09:49 --> Language Class Initialized
INFO - 2022-06-23 10:09:49 --> Loader Class Initialized
INFO - 2022-06-23 10:09:49 --> Helper loaded: url_helper
INFO - 2022-06-23 10:09:49 --> Helper loaded: file_helper
INFO - 2022-06-23 10:09:49 --> Database Driver Class Initialized
INFO - 2022-06-23 10:09:49 --> Email Class Initialized
DEBUG - 2022-06-23 10:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:09:49 --> Controller Class Initialized
INFO - 2022-06-23 10:09:49 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:09:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 10:09:49 --> Query error: Column 'ud_mob' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_mob`) VALUES (NULL)
INFO - 2022-06-23 10:09:49 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-23 10:10:05 --> Config Class Initialized
INFO - 2022-06-23 10:10:05 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:10:05 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:10:05 --> Utf8 Class Initialized
INFO - 2022-06-23 10:10:05 --> URI Class Initialized
INFO - 2022-06-23 10:10:05 --> Router Class Initialized
INFO - 2022-06-23 10:10:05 --> Output Class Initialized
INFO - 2022-06-23 10:10:05 --> Security Class Initialized
DEBUG - 2022-06-23 10:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:10:05 --> Input Class Initialized
INFO - 2022-06-23 10:10:05 --> Language Class Initialized
INFO - 2022-06-23 10:10:05 --> Loader Class Initialized
INFO - 2022-06-23 10:10:05 --> Helper loaded: url_helper
INFO - 2022-06-23 10:10:05 --> Helper loaded: file_helper
INFO - 2022-06-23 10:10:05 --> Database Driver Class Initialized
INFO - 2022-06-23 10:10:05 --> Email Class Initialized
DEBUG - 2022-06-23 10:10:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:10:05 --> Controller Class Initialized
INFO - 2022-06-23 10:10:05 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:10:05 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:10:05 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 10:10:05 --> Final output sent to browser
DEBUG - 2022-06-23 10:10:05 --> Total execution time: 0.0414
INFO - 2022-06-23 10:10:14 --> Config Class Initialized
INFO - 2022-06-23 10:10:14 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:10:14 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:10:14 --> Utf8 Class Initialized
INFO - 2022-06-23 10:10:14 --> Config Class Initialized
INFO - 2022-06-23 10:10:14 --> URI Class Initialized
INFO - 2022-06-23 10:10:14 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:10:14 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:10:14 --> Router Class Initialized
INFO - 2022-06-23 10:10:14 --> Utf8 Class Initialized
INFO - 2022-06-23 10:10:14 --> Output Class Initialized
INFO - 2022-06-23 10:10:14 --> URI Class Initialized
INFO - 2022-06-23 10:10:14 --> Security Class Initialized
INFO - 2022-06-23 10:10:14 --> Router Class Initialized
DEBUG - 2022-06-23 10:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:10:14 --> Output Class Initialized
INFO - 2022-06-23 10:10:14 --> Input Class Initialized
INFO - 2022-06-23 10:10:14 --> Security Class Initialized
INFO - 2022-06-23 10:10:14 --> Language Class Initialized
DEBUG - 2022-06-23 10:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:10:14 --> Input Class Initialized
INFO - 2022-06-23 10:10:14 --> Loader Class Initialized
INFO - 2022-06-23 10:10:14 --> Language Class Initialized
INFO - 2022-06-23 10:10:14 --> Loader Class Initialized
INFO - 2022-06-23 10:10:14 --> Helper loaded: url_helper
INFO - 2022-06-23 10:10:14 --> Helper loaded: file_helper
INFO - 2022-06-23 10:10:14 --> Helper loaded: url_helper
INFO - 2022-06-23 10:10:14 --> Helper loaded: file_helper
INFO - 2022-06-23 10:10:14 --> Database Driver Class Initialized
INFO - 2022-06-23 10:10:14 --> Database Driver Class Initialized
INFO - 2022-06-23 10:10:14 --> Email Class Initialized
INFO - 2022-06-23 10:10:14 --> Email Class Initialized
DEBUG - 2022-06-23 10:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 10:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:10:14 --> Controller Class Initialized
INFO - 2022-06-23 10:10:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:10:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 10:10:14 --> Query error: Column 'ud_mob' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_mob`) VALUES (NULL)
INFO - 2022-06-23 10:10:14 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-23 10:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:10:14 --> Controller Class Initialized
INFO - 2022-06-23 10:10:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:10:14 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:10:14 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 10:10:14 --> Final output sent to browser
DEBUG - 2022-06-23 10:10:14 --> Total execution time: 0.0274
INFO - 2022-06-23 10:10:19 --> Config Class Initialized
INFO - 2022-06-23 10:10:19 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:10:19 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:10:19 --> Utf8 Class Initialized
INFO - 2022-06-23 10:10:19 --> URI Class Initialized
INFO - 2022-06-23 10:10:19 --> Router Class Initialized
INFO - 2022-06-23 10:10:19 --> Output Class Initialized
INFO - 2022-06-23 10:10:19 --> Security Class Initialized
DEBUG - 2022-06-23 10:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:10:19 --> Input Class Initialized
INFO - 2022-06-23 10:10:19 --> Language Class Initialized
INFO - 2022-06-23 10:10:19 --> Loader Class Initialized
INFO - 2022-06-23 10:10:19 --> Helper loaded: url_helper
INFO - 2022-06-23 10:10:19 --> Helper loaded: file_helper
INFO - 2022-06-23 10:10:19 --> Database Driver Class Initialized
INFO - 2022-06-23 10:10:19 --> Email Class Initialized
DEBUG - 2022-06-23 10:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:10:19 --> Controller Class Initialized
INFO - 2022-06-23 10:10:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:10:19 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:10:19 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 10:10:19 --> Final output sent to browser
DEBUG - 2022-06-23 10:10:19 --> Total execution time: 0.0234
INFO - 2022-06-23 10:10:26 --> Config Class Initialized
INFO - 2022-06-23 10:10:26 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:10:26 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:10:26 --> Utf8 Class Initialized
INFO - 2022-06-23 10:10:26 --> URI Class Initialized
INFO - 2022-06-23 10:10:26 --> Router Class Initialized
INFO - 2022-06-23 10:10:26 --> Output Class Initialized
INFO - 2022-06-23 10:10:26 --> Security Class Initialized
DEBUG - 2022-06-23 10:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:10:26 --> Input Class Initialized
INFO - 2022-06-23 10:10:26 --> Language Class Initialized
INFO - 2022-06-23 10:10:26 --> Loader Class Initialized
INFO - 2022-06-23 10:10:26 --> Helper loaded: url_helper
INFO - 2022-06-23 10:10:26 --> Helper loaded: file_helper
INFO - 2022-06-23 10:10:26 --> Database Driver Class Initialized
INFO - 2022-06-23 10:10:26 --> Config Class Initialized
INFO - 2022-06-23 10:10:26 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:10:26 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:10:26 --> Utf8 Class Initialized
INFO - 2022-06-23 10:10:26 --> URI Class Initialized
INFO - 2022-06-23 10:10:26 --> Router Class Initialized
INFO - 2022-06-23 10:10:26 --> Output Class Initialized
INFO - 2022-06-23 10:10:26 --> Security Class Initialized
DEBUG - 2022-06-23 10:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:10:26 --> Input Class Initialized
INFO - 2022-06-23 10:10:26 --> Language Class Initialized
INFO - 2022-06-23 10:10:26 --> Loader Class Initialized
INFO - 2022-06-23 10:10:26 --> Helper loaded: url_helper
INFO - 2022-06-23 10:10:26 --> Helper loaded: file_helper
INFO - 2022-06-23 10:10:26 --> Database Driver Class Initialized
INFO - 2022-06-23 10:10:26 --> Email Class Initialized
INFO - 2022-06-23 10:10:26 --> Email Class Initialized
DEBUG - 2022-06-23 10:10:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:10:26 --> Controller Class Initialized
INFO - 2022-06-23 10:10:26 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:10:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 10:10:26 --> Query error: Column 'ud_mob' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_mob`) VALUES (NULL)
INFO - 2022-06-23 10:10:26 --> Language file loaded: language/english/db_lang.php
DEBUG - 2022-06-23 10:10:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:10:26 --> Controller Class Initialized
INFO - 2022-06-23 10:10:26 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:10:26 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:10:26 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 10:10:26 --> Final output sent to browser
DEBUG - 2022-06-23 10:10:26 --> Total execution time: 0.0494
INFO - 2022-06-23 10:10:30 --> Config Class Initialized
INFO - 2022-06-23 10:10:30 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:10:30 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:10:30 --> Utf8 Class Initialized
INFO - 2022-06-23 10:10:30 --> URI Class Initialized
INFO - 2022-06-23 10:10:30 --> Router Class Initialized
INFO - 2022-06-23 10:10:30 --> Output Class Initialized
INFO - 2022-06-23 10:10:30 --> Security Class Initialized
DEBUG - 2022-06-23 10:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:10:30 --> Input Class Initialized
INFO - 2022-06-23 10:10:30 --> Language Class Initialized
INFO - 2022-06-23 10:10:30 --> Loader Class Initialized
INFO - 2022-06-23 10:10:30 --> Helper loaded: url_helper
INFO - 2022-06-23 10:10:30 --> Helper loaded: file_helper
INFO - 2022-06-23 10:10:30 --> Database Driver Class Initialized
INFO - 2022-06-23 10:10:30 --> Email Class Initialized
DEBUG - 2022-06-23 10:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:10:30 --> Controller Class Initialized
INFO - 2022-06-23 10:10:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:10:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:10:30 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 10:10:30 --> Final output sent to browser
DEBUG - 2022-06-23 10:10:30 --> Total execution time: 0.0256
INFO - 2022-06-23 10:10:38 --> Config Class Initialized
INFO - 2022-06-23 10:10:38 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:10:38 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:10:38 --> Utf8 Class Initialized
INFO - 2022-06-23 10:10:38 --> URI Class Initialized
INFO - 2022-06-23 10:10:38 --> Router Class Initialized
INFO - 2022-06-23 10:10:38 --> Config Class Initialized
INFO - 2022-06-23 10:10:38 --> Output Class Initialized
INFO - 2022-06-23 10:10:38 --> Hooks Class Initialized
INFO - 2022-06-23 10:10:38 --> Security Class Initialized
DEBUG - 2022-06-23 10:10:38 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:10:38 --> Utf8 Class Initialized
DEBUG - 2022-06-23 10:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:10:38 --> URI Class Initialized
INFO - 2022-06-23 10:10:38 --> Input Class Initialized
INFO - 2022-06-23 10:10:38 --> Language Class Initialized
INFO - 2022-06-23 10:10:38 --> Router Class Initialized
INFO - 2022-06-23 10:10:38 --> Loader Class Initialized
INFO - 2022-06-23 10:10:38 --> Output Class Initialized
INFO - 2022-06-23 10:10:38 --> Security Class Initialized
INFO - 2022-06-23 10:10:38 --> Helper loaded: url_helper
DEBUG - 2022-06-23 10:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:10:38 --> Helper loaded: file_helper
INFO - 2022-06-23 10:10:38 --> Input Class Initialized
INFO - 2022-06-23 10:10:38 --> Language Class Initialized
INFO - 2022-06-23 10:10:38 --> Database Driver Class Initialized
INFO - 2022-06-23 10:10:38 --> Loader Class Initialized
INFO - 2022-06-23 10:10:38 --> Helper loaded: url_helper
INFO - 2022-06-23 10:10:38 --> Helper loaded: file_helper
INFO - 2022-06-23 10:10:38 --> Database Driver Class Initialized
INFO - 2022-06-23 10:10:38 --> Email Class Initialized
DEBUG - 2022-06-23 10:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:10:38 --> Controller Class Initialized
INFO - 2022-06-23 10:10:38 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:10:38 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:10:38 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 10:10:38 --> Final output sent to browser
DEBUG - 2022-06-23 10:10:38 --> Total execution time: 0.0224
INFO - 2022-06-23 10:10:38 --> Email Class Initialized
DEBUG - 2022-06-23 10:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:10:38 --> Controller Class Initialized
INFO - 2022-06-23 10:10:38 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:10:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 10:10:38 --> Query error: Column 'ud_mob' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_mob`) VALUES (NULL)
INFO - 2022-06-23 10:10:38 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-23 10:10:45 --> Config Class Initialized
INFO - 2022-06-23 10:10:45 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:10:45 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:10:45 --> Utf8 Class Initialized
INFO - 2022-06-23 10:10:45 --> URI Class Initialized
INFO - 2022-06-23 10:10:45 --> Router Class Initialized
INFO - 2022-06-23 10:10:45 --> Output Class Initialized
INFO - 2022-06-23 10:10:45 --> Security Class Initialized
DEBUG - 2022-06-23 10:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:10:45 --> Input Class Initialized
INFO - 2022-06-23 10:10:45 --> Language Class Initialized
INFO - 2022-06-23 10:10:45 --> Config Class Initialized
INFO - 2022-06-23 10:10:45 --> Hooks Class Initialized
INFO - 2022-06-23 10:10:45 --> Loader Class Initialized
DEBUG - 2022-06-23 10:10:45 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:10:45 --> Utf8 Class Initialized
INFO - 2022-06-23 10:10:45 --> Helper loaded: url_helper
INFO - 2022-06-23 10:10:45 --> URI Class Initialized
INFO - 2022-06-23 10:10:45 --> Helper loaded: file_helper
INFO - 2022-06-23 10:10:45 --> Router Class Initialized
INFO - 2022-06-23 10:10:45 --> Output Class Initialized
INFO - 2022-06-23 10:10:45 --> Database Driver Class Initialized
INFO - 2022-06-23 10:10:45 --> Security Class Initialized
DEBUG - 2022-06-23 10:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:10:45 --> Input Class Initialized
INFO - 2022-06-23 10:10:45 --> Email Class Initialized
INFO - 2022-06-23 10:10:45 --> Language Class Initialized
INFO - 2022-06-23 10:10:45 --> Loader Class Initialized
DEBUG - 2022-06-23 10:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:10:45 --> Helper loaded: url_helper
INFO - 2022-06-23 10:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:10:45 --> Helper loaded: file_helper
INFO - 2022-06-23 10:10:45 --> Controller Class Initialized
INFO - 2022-06-23 10:10:45 --> Database Driver Class Initialized
INFO - 2022-06-23 10:10:45 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:10:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 10:10:45 --> Query error: Column 'ud_mob' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_mob`) VALUES (NULL)
INFO - 2022-06-23 10:10:45 --> Email Class Initialized
INFO - 2022-06-23 10:10:45 --> Language file loaded: language/english/db_lang.php
DEBUG - 2022-06-23 10:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:10:45 --> Controller Class Initialized
INFO - 2022-06-23 10:10:45 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:10:45 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:10:45 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 10:10:45 --> Final output sent to browser
DEBUG - 2022-06-23 10:10:45 --> Total execution time: 0.0221
INFO - 2022-06-23 10:10:53 --> Config Class Initialized
INFO - 2022-06-23 10:10:53 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:10:53 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:10:53 --> Utf8 Class Initialized
INFO - 2022-06-23 10:10:53 --> URI Class Initialized
INFO - 2022-06-23 10:10:53 --> Router Class Initialized
INFO - 2022-06-23 10:10:53 --> Output Class Initialized
INFO - 2022-06-23 10:10:53 --> Security Class Initialized
DEBUG - 2022-06-23 10:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:10:53 --> Input Class Initialized
INFO - 2022-06-23 10:10:53 --> Language Class Initialized
INFO - 2022-06-23 10:10:53 --> Loader Class Initialized
INFO - 2022-06-23 10:10:53 --> Helper loaded: url_helper
INFO - 2022-06-23 10:10:53 --> Helper loaded: file_helper
INFO - 2022-06-23 10:10:53 --> Database Driver Class Initialized
INFO - 2022-06-23 10:10:53 --> Email Class Initialized
DEBUG - 2022-06-23 10:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:10:53 --> Controller Class Initialized
INFO - 2022-06-23 10:10:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:10:53 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:10:53 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 10:10:53 --> Final output sent to browser
DEBUG - 2022-06-23 10:10:53 --> Total execution time: 0.0434
INFO - 2022-06-23 10:12:08 --> Config Class Initialized
INFO - 2022-06-23 10:12:08 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:12:08 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:12:08 --> Utf8 Class Initialized
INFO - 2022-06-23 10:12:08 --> URI Class Initialized
INFO - 2022-06-23 10:12:08 --> Router Class Initialized
INFO - 2022-06-23 10:12:08 --> Output Class Initialized
INFO - 2022-06-23 10:12:08 --> Security Class Initialized
DEBUG - 2022-06-23 10:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:12:08 --> Input Class Initialized
INFO - 2022-06-23 10:12:08 --> Language Class Initialized
INFO - 2022-06-23 10:12:08 --> Loader Class Initialized
INFO - 2022-06-23 10:12:08 --> Helper loaded: url_helper
INFO - 2022-06-23 10:12:08 --> Helper loaded: file_helper
INFO - 2022-06-23 10:12:08 --> Database Driver Class Initialized
INFO - 2022-06-23 10:12:08 --> Email Class Initialized
DEBUG - 2022-06-23 10:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:12:08 --> Controller Class Initialized
INFO - 2022-06-23 10:12:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:12:08 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:12:08 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 10:12:08 --> Final output sent to browser
DEBUG - 2022-06-23 10:12:08 --> Total execution time: 0.0205
INFO - 2022-06-23 10:12:17 --> Config Class Initialized
INFO - 2022-06-23 10:12:17 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:12:17 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:12:17 --> Utf8 Class Initialized
INFO - 2022-06-23 10:12:17 --> URI Class Initialized
INFO - 2022-06-23 10:12:17 --> Router Class Initialized
INFO - 2022-06-23 10:12:17 --> Output Class Initialized
INFO - 2022-06-23 10:12:17 --> Security Class Initialized
DEBUG - 2022-06-23 10:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:12:17 --> Input Class Initialized
INFO - 2022-06-23 10:12:17 --> Language Class Initialized
INFO - 2022-06-23 10:12:17 --> Loader Class Initialized
INFO - 2022-06-23 10:12:17 --> Helper loaded: url_helper
INFO - 2022-06-23 10:12:17 --> Helper loaded: file_helper
INFO - 2022-06-23 10:12:17 --> Database Driver Class Initialized
INFO - 2022-06-23 10:12:17 --> Email Class Initialized
DEBUG - 2022-06-23 10:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:12:17 --> Controller Class Initialized
INFO - 2022-06-23 10:12:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:12:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:12:17 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 10:12:17 --> Final output sent to browser
DEBUG - 2022-06-23 10:12:17 --> Total execution time: 0.0181
INFO - 2022-06-23 10:12:28 --> Config Class Initialized
INFO - 2022-06-23 10:12:28 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:12:28 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:12:28 --> Utf8 Class Initialized
INFO - 2022-06-23 10:12:28 --> URI Class Initialized
INFO - 2022-06-23 10:12:28 --> Router Class Initialized
INFO - 2022-06-23 10:12:28 --> Output Class Initialized
INFO - 2022-06-23 10:12:28 --> Security Class Initialized
DEBUG - 2022-06-23 10:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:12:28 --> Input Class Initialized
INFO - 2022-06-23 10:12:28 --> Language Class Initialized
INFO - 2022-06-23 10:12:28 --> Loader Class Initialized
INFO - 2022-06-23 10:12:28 --> Helper loaded: url_helper
INFO - 2022-06-23 10:12:28 --> Helper loaded: file_helper
INFO - 2022-06-23 10:12:28 --> Database Driver Class Initialized
INFO - 2022-06-23 10:12:28 --> Email Class Initialized
DEBUG - 2022-06-23 10:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:12:28 --> Controller Class Initialized
INFO - 2022-06-23 10:12:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:12:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:12:28 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 10:12:28 --> Final output sent to browser
DEBUG - 2022-06-23 10:12:28 --> Total execution time: 0.0306
INFO - 2022-06-23 10:12:42 --> Config Class Initialized
INFO - 2022-06-23 10:12:42 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:12:42 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:12:42 --> Utf8 Class Initialized
INFO - 2022-06-23 10:12:42 --> URI Class Initialized
INFO - 2022-06-23 10:12:42 --> Router Class Initialized
INFO - 2022-06-23 10:12:42 --> Output Class Initialized
INFO - 2022-06-23 10:12:42 --> Security Class Initialized
DEBUG - 2022-06-23 10:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:12:42 --> Input Class Initialized
INFO - 2022-06-23 10:12:42 --> Language Class Initialized
INFO - 2022-06-23 10:12:42 --> Loader Class Initialized
INFO - 2022-06-23 10:12:42 --> Helper loaded: url_helper
INFO - 2022-06-23 10:12:42 --> Helper loaded: file_helper
INFO - 2022-06-23 10:12:42 --> Database Driver Class Initialized
INFO - 2022-06-23 10:12:42 --> Email Class Initialized
DEBUG - 2022-06-23 10:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:12:42 --> Controller Class Initialized
INFO - 2022-06-23 10:12:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:12:42 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:12:42 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 10:12:42 --> Final output sent to browser
DEBUG - 2022-06-23 10:12:42 --> Total execution time: 0.0336
INFO - 2022-06-23 10:13:01 --> Config Class Initialized
INFO - 2022-06-23 10:13:01 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:13:01 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:13:01 --> Utf8 Class Initialized
INFO - 2022-06-23 10:13:01 --> URI Class Initialized
INFO - 2022-06-23 10:13:01 --> Router Class Initialized
INFO - 2022-06-23 10:13:01 --> Output Class Initialized
INFO - 2022-06-23 10:13:01 --> Security Class Initialized
DEBUG - 2022-06-23 10:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:13:01 --> Input Class Initialized
INFO - 2022-06-23 10:13:01 --> Language Class Initialized
INFO - 2022-06-23 10:13:01 --> Loader Class Initialized
INFO - 2022-06-23 10:13:01 --> Helper loaded: url_helper
INFO - 2022-06-23 10:13:01 --> Helper loaded: file_helper
INFO - 2022-06-23 10:13:01 --> Database Driver Class Initialized
INFO - 2022-06-23 10:13:01 --> Email Class Initialized
DEBUG - 2022-06-23 10:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:13:01 --> Controller Class Initialized
INFO - 2022-06-23 10:13:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:13:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:13:01 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 10:13:01 --> Final output sent to browser
DEBUG - 2022-06-23 10:13:01 --> Total execution time: 0.0361
INFO - 2022-06-23 10:13:12 --> Config Class Initialized
INFO - 2022-06-23 10:13:12 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:13:12 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:13:12 --> Utf8 Class Initialized
INFO - 2022-06-23 10:13:12 --> URI Class Initialized
INFO - 2022-06-23 10:13:12 --> Config Class Initialized
INFO - 2022-06-23 10:13:12 --> Hooks Class Initialized
INFO - 2022-06-23 10:13:12 --> Router Class Initialized
DEBUG - 2022-06-23 10:13:12 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:13:12 --> Output Class Initialized
INFO - 2022-06-23 10:13:12 --> Utf8 Class Initialized
INFO - 2022-06-23 10:13:12 --> URI Class Initialized
INFO - 2022-06-23 10:13:12 --> Security Class Initialized
DEBUG - 2022-06-23 10:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:13:12 --> Router Class Initialized
INFO - 2022-06-23 10:13:12 --> Input Class Initialized
INFO - 2022-06-23 10:13:12 --> Output Class Initialized
INFO - 2022-06-23 10:13:12 --> Language Class Initialized
INFO - 2022-06-23 10:13:12 --> Security Class Initialized
INFO - 2022-06-23 10:13:12 --> Loader Class Initialized
DEBUG - 2022-06-23 10:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:13:12 --> Input Class Initialized
INFO - 2022-06-23 10:13:12 --> Helper loaded: url_helper
INFO - 2022-06-23 10:13:12 --> Language Class Initialized
INFO - 2022-06-23 10:13:12 --> Helper loaded: file_helper
INFO - 2022-06-23 10:13:12 --> Loader Class Initialized
INFO - 2022-06-23 10:13:12 --> Database Driver Class Initialized
INFO - 2022-06-23 10:13:12 --> Helper loaded: url_helper
INFO - 2022-06-23 10:13:12 --> Helper loaded: file_helper
INFO - 2022-06-23 10:13:12 --> Email Class Initialized
INFO - 2022-06-23 10:13:12 --> Database Driver Class Initialized
DEBUG - 2022-06-23 10:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:13:12 --> Email Class Initialized
INFO - 2022-06-23 10:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:13:12 --> Controller Class Initialized
DEBUG - 2022-06-23 10:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:13:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:13:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 10:13:12 --> Query error: Column 'ud_mob' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_mob`) VALUES (NULL)
INFO - 2022-06-23 10:13:12 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-23 10:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:13:12 --> Controller Class Initialized
INFO - 2022-06-23 10:13:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:13:12 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:13:12 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 10:13:12 --> Final output sent to browser
DEBUG - 2022-06-23 10:13:12 --> Total execution time: 0.0299
INFO - 2022-06-23 10:13:16 --> Config Class Initialized
INFO - 2022-06-23 10:13:16 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:13:16 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:13:16 --> Utf8 Class Initialized
INFO - 2022-06-23 10:13:16 --> URI Class Initialized
INFO - 2022-06-23 10:13:16 --> Router Class Initialized
INFO - 2022-06-23 10:13:16 --> Output Class Initialized
INFO - 2022-06-23 10:13:16 --> Security Class Initialized
DEBUG - 2022-06-23 10:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:13:16 --> Input Class Initialized
INFO - 2022-06-23 10:13:16 --> Language Class Initialized
INFO - 2022-06-23 10:13:16 --> Loader Class Initialized
INFO - 2022-06-23 10:13:16 --> Helper loaded: url_helper
INFO - 2022-06-23 10:13:16 --> Helper loaded: file_helper
INFO - 2022-06-23 10:13:16 --> Database Driver Class Initialized
INFO - 2022-06-23 10:13:16 --> Email Class Initialized
DEBUG - 2022-06-23 10:13:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:13:16 --> Controller Class Initialized
INFO - 2022-06-23 10:13:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:13:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 10:13:16 --> Query error: Column 'ud_mob' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_mob`) VALUES (NULL)
INFO - 2022-06-23 10:13:16 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-23 10:13:43 --> Config Class Initialized
INFO - 2022-06-23 10:13:43 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:13:43 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:13:43 --> Utf8 Class Initialized
INFO - 2022-06-23 10:13:43 --> URI Class Initialized
INFO - 2022-06-23 10:13:43 --> Router Class Initialized
INFO - 2022-06-23 10:13:43 --> Output Class Initialized
INFO - 2022-06-23 10:13:43 --> Security Class Initialized
DEBUG - 2022-06-23 10:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:13:43 --> Input Class Initialized
INFO - 2022-06-23 10:13:43 --> Language Class Initialized
INFO - 2022-06-23 10:13:43 --> Loader Class Initialized
INFO - 2022-06-23 10:13:43 --> Helper loaded: url_helper
INFO - 2022-06-23 10:13:43 --> Helper loaded: file_helper
INFO - 2022-06-23 10:13:43 --> Database Driver Class Initialized
INFO - 2022-06-23 10:13:43 --> Email Class Initialized
DEBUG - 2022-06-23 10:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:13:43 --> Controller Class Initialized
INFO - 2022-06-23 10:13:43 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:13:43 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:13:43 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 10:13:43 --> Final output sent to browser
DEBUG - 2022-06-23 10:13:43 --> Total execution time: 0.0319
INFO - 2022-06-23 10:13:52 --> Config Class Initialized
INFO - 2022-06-23 10:13:52 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:13:52 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:13:52 --> Utf8 Class Initialized
INFO - 2022-06-23 10:13:52 --> URI Class Initialized
INFO - 2022-06-23 10:13:52 --> Router Class Initialized
INFO - 2022-06-23 10:13:52 --> Config Class Initialized
INFO - 2022-06-23 10:13:52 --> Hooks Class Initialized
INFO - 2022-06-23 10:13:52 --> Output Class Initialized
DEBUG - 2022-06-23 10:13:52 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:13:52 --> Security Class Initialized
INFO - 2022-06-23 10:13:52 --> Utf8 Class Initialized
DEBUG - 2022-06-23 10:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:13:52 --> URI Class Initialized
INFO - 2022-06-23 10:13:52 --> Input Class Initialized
INFO - 2022-06-23 10:13:52 --> Language Class Initialized
INFO - 2022-06-23 10:13:52 --> Router Class Initialized
INFO - 2022-06-23 10:13:52 --> Loader Class Initialized
INFO - 2022-06-23 10:13:52 --> Output Class Initialized
INFO - 2022-06-23 10:13:52 --> Helper loaded: url_helper
INFO - 2022-06-23 10:13:52 --> Security Class Initialized
INFO - 2022-06-23 10:13:52 --> Helper loaded: file_helper
DEBUG - 2022-06-23 10:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:13:52 --> Input Class Initialized
INFO - 2022-06-23 10:13:52 --> Database Driver Class Initialized
INFO - 2022-06-23 10:13:52 --> Language Class Initialized
INFO - 2022-06-23 10:13:52 --> Email Class Initialized
INFO - 2022-06-23 10:13:52 --> Loader Class Initialized
INFO - 2022-06-23 10:13:52 --> Helper loaded: url_helper
INFO - 2022-06-23 10:13:52 --> Helper loaded: file_helper
DEBUG - 2022-06-23 10:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:13:52 --> Database Driver Class Initialized
INFO - 2022-06-23 10:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:13:52 --> Controller Class Initialized
INFO - 2022-06-23 10:13:52 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:13:52 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:13:52 --> Email Class Initialized
INFO - 2022-06-23 10:13:52 --> Final output sent to browser
DEBUG - 2022-06-23 10:13:52 --> Total execution time: 0.0305
DEBUG - 2022-06-23 10:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:13:52 --> Controller Class Initialized
INFO - 2022-06-23 10:13:52 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:13:52 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:13:52 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 10:13:52 --> Final output sent to browser
DEBUG - 2022-06-23 10:13:52 --> Total execution time: 0.0304
INFO - 2022-06-23 10:14:00 --> Config Class Initialized
INFO - 2022-06-23 10:14:00 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:14:00 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:14:00 --> Utf8 Class Initialized
INFO - 2022-06-23 10:14:00 --> URI Class Initialized
INFO - 2022-06-23 10:14:00 --> Config Class Initialized
INFO - 2022-06-23 10:14:00 --> Hooks Class Initialized
INFO - 2022-06-23 10:14:00 --> Router Class Initialized
DEBUG - 2022-06-23 10:14:00 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:14:00 --> Output Class Initialized
INFO - 2022-06-23 10:14:00 --> Utf8 Class Initialized
INFO - 2022-06-23 10:14:00 --> Security Class Initialized
INFO - 2022-06-23 10:14:00 --> URI Class Initialized
DEBUG - 2022-06-23 10:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:14:00 --> Router Class Initialized
INFO - 2022-06-23 10:14:00 --> Input Class Initialized
INFO - 2022-06-23 10:14:00 --> Output Class Initialized
INFO - 2022-06-23 10:14:00 --> Language Class Initialized
INFO - 2022-06-23 10:14:00 --> Security Class Initialized
DEBUG - 2022-06-23 10:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:14:00 --> Loader Class Initialized
INFO - 2022-06-23 10:14:00 --> Input Class Initialized
INFO - 2022-06-23 10:14:00 --> Language Class Initialized
INFO - 2022-06-23 10:14:00 --> Helper loaded: url_helper
INFO - 2022-06-23 10:14:00 --> Helper loaded: file_helper
INFO - 2022-06-23 10:14:00 --> Loader Class Initialized
INFO - 2022-06-23 10:14:00 --> Database Driver Class Initialized
INFO - 2022-06-23 10:14:00 --> Helper loaded: url_helper
INFO - 2022-06-23 10:14:00 --> Helper loaded: file_helper
INFO - 2022-06-23 10:14:00 --> Database Driver Class Initialized
INFO - 2022-06-23 10:14:00 --> Email Class Initialized
DEBUG - 2022-06-23 10:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:14:00 --> Controller Class Initialized
INFO - 2022-06-23 10:14:00 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:14:00 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:14:00 --> Final output sent to browser
DEBUG - 2022-06-23 10:14:00 --> Total execution time: 0.0236
INFO - 2022-06-23 10:14:00 --> Email Class Initialized
DEBUG - 2022-06-23 10:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:14:00 --> Controller Class Initialized
INFO - 2022-06-23 10:14:00 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:14:00 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:14:00 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 10:14:00 --> Final output sent to browser
DEBUG - 2022-06-23 10:14:00 --> Total execution time: 0.0437
INFO - 2022-06-23 10:19:16 --> Config Class Initialized
INFO - 2022-06-23 10:19:16 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:19:16 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:19:16 --> Utf8 Class Initialized
INFO - 2022-06-23 10:19:16 --> URI Class Initialized
INFO - 2022-06-23 10:19:16 --> Router Class Initialized
INFO - 2022-06-23 10:19:16 --> Output Class Initialized
INFO - 2022-06-23 10:19:16 --> Security Class Initialized
DEBUG - 2022-06-23 10:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:19:16 --> Input Class Initialized
INFO - 2022-06-23 10:19:16 --> Language Class Initialized
INFO - 2022-06-23 10:19:16 --> Loader Class Initialized
INFO - 2022-06-23 10:19:16 --> Helper loaded: url_helper
INFO - 2022-06-23 10:19:16 --> Helper loaded: file_helper
INFO - 2022-06-23 10:19:16 --> Database Driver Class Initialized
INFO - 2022-06-23 10:19:16 --> Email Class Initialized
DEBUG - 2022-06-23 10:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:19:16 --> Controller Class Initialized
INFO - 2022-06-23 10:19:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:19:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 10:19:16 --> Query error: Unknown column 'td_tk' in 'field list' - Invalid query: SELECT MAX(`td_tk`) AS `td_tk`
FROM `tokendetails`
INFO - 2022-06-23 10:19:16 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-23 10:19:36 --> Config Class Initialized
INFO - 2022-06-23 10:19:36 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:19:36 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:19:36 --> Utf8 Class Initialized
INFO - 2022-06-23 10:19:36 --> URI Class Initialized
INFO - 2022-06-23 10:19:36 --> Router Class Initialized
INFO - 2022-06-23 10:19:36 --> Output Class Initialized
INFO - 2022-06-23 10:19:36 --> Security Class Initialized
DEBUG - 2022-06-23 10:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:19:36 --> Input Class Initialized
INFO - 2022-06-23 10:19:36 --> Language Class Initialized
INFO - 2022-06-23 10:19:36 --> Loader Class Initialized
INFO - 2022-06-23 10:19:36 --> Helper loaded: url_helper
INFO - 2022-06-23 10:19:36 --> Helper loaded: file_helper
INFO - 2022-06-23 10:19:36 --> Database Driver Class Initialized
INFO - 2022-06-23 10:19:36 --> Email Class Initialized
DEBUG - 2022-06-23 10:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:19:36 --> Controller Class Initialized
INFO - 2022-06-23 10:19:36 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:19:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 10:19:36 --> Query error: Unknown column 'td_tk' in 'field list' - Invalid query: SELECT MAX(`td_tk`) AS `td_tk`
FROM `tokendetails`
INFO - 2022-06-23 10:19:36 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-23 10:20:33 --> Config Class Initialized
INFO - 2022-06-23 10:20:33 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:20:33 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:20:33 --> Utf8 Class Initialized
INFO - 2022-06-23 10:20:33 --> URI Class Initialized
INFO - 2022-06-23 10:20:33 --> Router Class Initialized
INFO - 2022-06-23 10:20:33 --> Output Class Initialized
INFO - 2022-06-23 10:20:33 --> Security Class Initialized
DEBUG - 2022-06-23 10:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:20:33 --> Input Class Initialized
INFO - 2022-06-23 10:20:33 --> Language Class Initialized
INFO - 2022-06-23 10:20:33 --> Loader Class Initialized
INFO - 2022-06-23 10:20:33 --> Helper loaded: url_helper
INFO - 2022-06-23 10:20:33 --> Helper loaded: file_helper
INFO - 2022-06-23 10:20:33 --> Database Driver Class Initialized
INFO - 2022-06-23 10:20:33 --> Email Class Initialized
DEBUG - 2022-06-23 10:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:20:33 --> Controller Class Initialized
INFO - 2022-06-23 10:20:33 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:20:33 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:20:33 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 10:20:33 --> Final output sent to browser
DEBUG - 2022-06-23 10:20:33 --> Total execution time: 0.0264
INFO - 2022-06-23 10:20:59 --> Config Class Initialized
INFO - 2022-06-23 10:20:59 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:20:59 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:20:59 --> Utf8 Class Initialized
INFO - 2022-06-23 10:20:59 --> URI Class Initialized
INFO - 2022-06-23 10:20:59 --> Config Class Initialized
INFO - 2022-06-23 10:20:59 --> Hooks Class Initialized
INFO - 2022-06-23 10:20:59 --> Router Class Initialized
DEBUG - 2022-06-23 10:20:59 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:20:59 --> Output Class Initialized
INFO - 2022-06-23 10:20:59 --> Utf8 Class Initialized
INFO - 2022-06-23 10:20:59 --> Security Class Initialized
INFO - 2022-06-23 10:20:59 --> URI Class Initialized
DEBUG - 2022-06-23 10:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:20:59 --> Input Class Initialized
INFO - 2022-06-23 10:20:59 --> Router Class Initialized
INFO - 2022-06-23 10:20:59 --> Language Class Initialized
INFO - 2022-06-23 10:20:59 --> Output Class Initialized
INFO - 2022-06-23 10:20:59 --> Loader Class Initialized
INFO - 2022-06-23 10:20:59 --> Security Class Initialized
DEBUG - 2022-06-23 10:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:20:59 --> Helper loaded: url_helper
INFO - 2022-06-23 10:20:59 --> Input Class Initialized
INFO - 2022-06-23 10:20:59 --> Helper loaded: file_helper
INFO - 2022-06-23 10:20:59 --> Language Class Initialized
INFO - 2022-06-23 10:20:59 --> Database Driver Class Initialized
INFO - 2022-06-23 10:20:59 --> Loader Class Initialized
INFO - 2022-06-23 10:20:59 --> Helper loaded: url_helper
INFO - 2022-06-23 10:20:59 --> Helper loaded: file_helper
INFO - 2022-06-23 10:20:59 --> Database Driver Class Initialized
INFO - 2022-06-23 10:20:59 --> Email Class Initialized
DEBUG - 2022-06-23 10:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:20:59 --> Controller Class Initialized
INFO - 2022-06-23 10:20:59 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:20:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 10:20:59 --> test
INFO - 2022-06-23 10:20:59 --> Final output sent to browser
DEBUG - 2022-06-23 10:20:59 --> Total execution time: 0.0192
INFO - 2022-06-23 10:20:59 --> Email Class Initialized
DEBUG - 2022-06-23 10:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:20:59 --> Controller Class Initialized
INFO - 2022-06-23 10:20:59 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:20:59 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:20:59 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 10:20:59 --> Final output sent to browser
DEBUG - 2022-06-23 10:20:59 --> Total execution time: 0.0375
INFO - 2022-06-23 10:22:36 --> Config Class Initialized
INFO - 2022-06-23 10:22:36 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:22:36 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:22:36 --> Utf8 Class Initialized
INFO - 2022-06-23 10:22:36 --> URI Class Initialized
INFO - 2022-06-23 10:22:36 --> Router Class Initialized
INFO - 2022-06-23 10:22:36 --> Output Class Initialized
INFO - 2022-06-23 10:22:36 --> Security Class Initialized
DEBUG - 2022-06-23 10:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:22:36 --> Input Class Initialized
INFO - 2022-06-23 10:22:36 --> Language Class Initialized
INFO - 2022-06-23 10:22:36 --> Loader Class Initialized
INFO - 2022-06-23 10:22:36 --> Helper loaded: url_helper
INFO - 2022-06-23 10:22:36 --> Helper loaded: file_helper
INFO - 2022-06-23 10:22:36 --> Database Driver Class Initialized
INFO - 2022-06-23 10:22:36 --> Email Class Initialized
DEBUG - 2022-06-23 10:22:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:22:36 --> Controller Class Initialized
INFO - 2022-06-23 10:22:36 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:22:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 10:22:36 --> Query error: Unknown column 'td_tk' in 'field list' - Invalid query: SELECT MAX(`td_tk`) AS `td_tk`
FROM `tokendetails`
INFO - 2022-06-23 10:22:36 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-23 10:27:05 --> Config Class Initialized
INFO - 2022-06-23 10:27:05 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:27:05 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:27:05 --> Utf8 Class Initialized
INFO - 2022-06-23 10:27:05 --> URI Class Initialized
INFO - 2022-06-23 10:27:05 --> Router Class Initialized
INFO - 2022-06-23 10:27:05 --> Output Class Initialized
INFO - 2022-06-23 10:27:05 --> Security Class Initialized
DEBUG - 2022-06-23 10:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:27:05 --> Input Class Initialized
INFO - 2022-06-23 10:27:05 --> Language Class Initialized
INFO - 2022-06-23 10:27:05 --> Loader Class Initialized
INFO - 2022-06-23 10:27:05 --> Helper loaded: url_helper
INFO - 2022-06-23 10:27:05 --> Helper loaded: file_helper
INFO - 2022-06-23 10:27:05 --> Database Driver Class Initialized
INFO - 2022-06-23 10:27:05 --> Email Class Initialized
DEBUG - 2022-06-23 10:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:27:05 --> Controller Class Initialized
INFO - 2022-06-23 10:27:05 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:27:05 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:27:05 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-23 10:27:05 --> Final output sent to browser
DEBUG - 2022-06-23 10:27:05 --> Total execution time: 0.1406
INFO - 2022-06-23 10:29:10 --> Config Class Initialized
INFO - 2022-06-23 10:29:10 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:29:10 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:29:10 --> Utf8 Class Initialized
INFO - 2022-06-23 10:29:10 --> URI Class Initialized
INFO - 2022-06-23 10:29:10 --> Router Class Initialized
INFO - 2022-06-23 10:29:10 --> Output Class Initialized
INFO - 2022-06-23 10:29:10 --> Security Class Initialized
DEBUG - 2022-06-23 10:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:29:10 --> Input Class Initialized
INFO - 2022-06-23 10:29:10 --> Language Class Initialized
INFO - 2022-06-23 10:29:10 --> Loader Class Initialized
INFO - 2022-06-23 10:29:10 --> Helper loaded: url_helper
INFO - 2022-06-23 10:29:10 --> Helper loaded: file_helper
INFO - 2022-06-23 10:29:10 --> Database Driver Class Initialized
INFO - 2022-06-23 10:29:10 --> Email Class Initialized
DEBUG - 2022-06-23 10:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:29:10 --> Controller Class Initialized
INFO - 2022-06-23 10:29:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:29:10 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:29:10 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-23 10:29:10 --> Final output sent to browser
DEBUG - 2022-06-23 10:29:10 --> Total execution time: 0.0434
INFO - 2022-06-23 10:29:14 --> Config Class Initialized
INFO - 2022-06-23 10:29:14 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:29:14 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:29:14 --> Utf8 Class Initialized
INFO - 2022-06-23 10:29:14 --> URI Class Initialized
INFO - 2022-06-23 10:29:14 --> Router Class Initialized
INFO - 2022-06-23 10:29:14 --> Output Class Initialized
INFO - 2022-06-23 10:29:14 --> Security Class Initialized
DEBUG - 2022-06-23 10:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:29:14 --> Input Class Initialized
INFO - 2022-06-23 10:29:14 --> Language Class Initialized
INFO - 2022-06-23 10:29:14 --> Loader Class Initialized
INFO - 2022-06-23 10:29:14 --> Helper loaded: url_helper
INFO - 2022-06-23 10:29:14 --> Helper loaded: file_helper
INFO - 2022-06-23 10:29:14 --> Database Driver Class Initialized
INFO - 2022-06-23 10:29:14 --> Email Class Initialized
DEBUG - 2022-06-23 10:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:29:14 --> Controller Class Initialized
INFO - 2022-06-23 10:29:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:29:14 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:29:14 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-23 10:29:14 --> Final output sent to browser
DEBUG - 2022-06-23 10:29:14 --> Total execution time: 0.0463
INFO - 2022-06-23 10:29:17 --> Config Class Initialized
INFO - 2022-06-23 10:29:17 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:29:17 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:29:17 --> Utf8 Class Initialized
INFO - 2022-06-23 10:29:17 --> URI Class Initialized
INFO - 2022-06-23 10:29:17 --> Router Class Initialized
INFO - 2022-06-23 10:29:17 --> Output Class Initialized
INFO - 2022-06-23 10:29:17 --> Security Class Initialized
DEBUG - 2022-06-23 10:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:29:17 --> Input Class Initialized
INFO - 2022-06-23 10:29:17 --> Language Class Initialized
INFO - 2022-06-23 10:29:17 --> Loader Class Initialized
INFO - 2022-06-23 10:29:17 --> Helper loaded: url_helper
INFO - 2022-06-23 10:29:17 --> Helper loaded: file_helper
INFO - 2022-06-23 10:29:17 --> Database Driver Class Initialized
INFO - 2022-06-23 10:29:17 --> Email Class Initialized
DEBUG - 2022-06-23 10:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:29:17 --> Controller Class Initialized
INFO - 2022-06-23 10:29:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:29:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:29:17 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 10:29:17 --> Final output sent to browser
DEBUG - 2022-06-23 10:29:17 --> Total execution time: 0.0167
INFO - 2022-06-23 10:29:31 --> Config Class Initialized
INFO - 2022-06-23 10:29:31 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:29:31 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:29:31 --> Utf8 Class Initialized
INFO - 2022-06-23 10:29:31 --> URI Class Initialized
INFO - 2022-06-23 10:29:31 --> Router Class Initialized
INFO - 2022-06-23 10:29:31 --> Output Class Initialized
INFO - 2022-06-23 10:29:31 --> Security Class Initialized
INFO - 2022-06-23 10:29:31 --> Config Class Initialized
INFO - 2022-06-23 10:29:31 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:29:31 --> Input Class Initialized
DEBUG - 2022-06-23 10:29:31 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:29:31 --> Utf8 Class Initialized
INFO - 2022-06-23 10:29:31 --> Language Class Initialized
INFO - 2022-06-23 10:29:31 --> URI Class Initialized
INFO - 2022-06-23 10:29:31 --> Loader Class Initialized
INFO - 2022-06-23 10:29:31 --> Router Class Initialized
INFO - 2022-06-23 10:29:31 --> Helper loaded: url_helper
INFO - 2022-06-23 10:29:31 --> Output Class Initialized
INFO - 2022-06-23 10:29:31 --> Helper loaded: file_helper
INFO - 2022-06-23 10:29:31 --> Security Class Initialized
DEBUG - 2022-06-23 10:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:29:31 --> Database Driver Class Initialized
INFO - 2022-06-23 10:29:31 --> Input Class Initialized
INFO - 2022-06-23 10:29:31 --> Language Class Initialized
INFO - 2022-06-23 10:29:31 --> Loader Class Initialized
INFO - 2022-06-23 10:29:31 --> Email Class Initialized
INFO - 2022-06-23 10:29:31 --> Helper loaded: url_helper
INFO - 2022-06-23 10:29:31 --> Helper loaded: file_helper
INFO - 2022-06-23 10:29:31 --> Database Driver Class Initialized
DEBUG - 2022-06-23 10:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:29:31 --> Controller Class Initialized
INFO - 2022-06-23 10:29:31 --> Email Class Initialized
INFO - 2022-06-23 10:29:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:29:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 10:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 10:29:31 --> test
INFO - 2022-06-23 10:29:31 --> Final output sent to browser
DEBUG - 2022-06-23 10:29:31 --> Total execution time: 0.0197
INFO - 2022-06-23 10:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:29:31 --> Controller Class Initialized
INFO - 2022-06-23 10:29:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:29:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:29:31 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 10:29:31 --> Final output sent to browser
DEBUG - 2022-06-23 10:29:31 --> Total execution time: 0.0212
INFO - 2022-06-23 10:32:52 --> Config Class Initialized
INFO - 2022-06-23 10:32:52 --> Hooks Class Initialized
INFO - 2022-06-23 10:32:52 --> Config Class Initialized
INFO - 2022-06-23 10:32:52 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 10:32:52 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:32:52 --> Utf8 Class Initialized
INFO - 2022-06-23 10:32:52 --> Utf8 Class Initialized
INFO - 2022-06-23 10:32:52 --> URI Class Initialized
INFO - 2022-06-23 10:32:52 --> URI Class Initialized
INFO - 2022-06-23 10:32:52 --> Router Class Initialized
INFO - 2022-06-23 10:32:52 --> Router Class Initialized
INFO - 2022-06-23 10:32:52 --> Output Class Initialized
INFO - 2022-06-23 10:32:52 --> Output Class Initialized
INFO - 2022-06-23 10:32:52 --> Security Class Initialized
INFO - 2022-06-23 10:32:52 --> Security Class Initialized
DEBUG - 2022-06-23 10:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 10:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:32:52 --> Input Class Initialized
INFO - 2022-06-23 10:32:52 --> Input Class Initialized
INFO - 2022-06-23 10:32:52 --> Language Class Initialized
INFO - 2022-06-23 10:32:52 --> Language Class Initialized
INFO - 2022-06-23 10:32:52 --> Loader Class Initialized
INFO - 2022-06-23 10:32:52 --> Loader Class Initialized
INFO - 2022-06-23 10:32:52 --> Helper loaded: url_helper
INFO - 2022-06-23 10:32:52 --> Helper loaded: url_helper
INFO - 2022-06-23 10:32:52 --> Helper loaded: file_helper
INFO - 2022-06-23 10:32:52 --> Helper loaded: file_helper
INFO - 2022-06-23 10:32:52 --> Database Driver Class Initialized
INFO - 2022-06-23 10:32:52 --> Database Driver Class Initialized
INFO - 2022-06-23 10:32:52 --> Email Class Initialized
INFO - 2022-06-23 10:32:52 --> Email Class Initialized
DEBUG - 2022-06-23 10:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 10:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:32:52 --> Controller Class Initialized
INFO - 2022-06-23 10:32:52 --> Controller Class Initialized
INFO - 2022-06-23 10:32:52 --> Model "Tokenmodel" initialized
INFO - 2022-06-23 10:32:52 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:32:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 10:32:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 10:32:52 --> test
INFO - 2022-06-23 10:32:52 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 10:32:52 --> Final output sent to browser
INFO - 2022-06-23 10:32:52 --> Final output sent to browser
DEBUG - 2022-06-23 10:32:52 --> Total execution time: 0.0237
DEBUG - 2022-06-23 10:32:52 --> Total execution time: 0.0231
INFO - 2022-06-23 10:34:27 --> Config Class Initialized
INFO - 2022-06-23 10:34:27 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:34:27 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:34:27 --> Utf8 Class Initialized
INFO - 2022-06-23 10:34:27 --> Config Class Initialized
INFO - 2022-06-23 10:34:27 --> URI Class Initialized
INFO - 2022-06-23 10:34:27 --> Hooks Class Initialized
INFO - 2022-06-23 10:34:27 --> Router Class Initialized
DEBUG - 2022-06-23 10:34:27 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:34:27 --> Utf8 Class Initialized
INFO - 2022-06-23 10:34:27 --> Output Class Initialized
INFO - 2022-06-23 10:34:27 --> URI Class Initialized
INFO - 2022-06-23 10:34:27 --> Security Class Initialized
INFO - 2022-06-23 10:34:27 --> Router Class Initialized
DEBUG - 2022-06-23 10:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:34:27 --> Input Class Initialized
INFO - 2022-06-23 10:34:27 --> Output Class Initialized
INFO - 2022-06-23 10:34:27 --> Language Class Initialized
INFO - 2022-06-23 10:34:27 --> Security Class Initialized
DEBUG - 2022-06-23 10:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:34:27 --> Input Class Initialized
INFO - 2022-06-23 10:34:27 --> Loader Class Initialized
INFO - 2022-06-23 10:34:27 --> Language Class Initialized
INFO - 2022-06-23 10:34:27 --> Helper loaded: url_helper
INFO - 2022-06-23 10:34:27 --> Loader Class Initialized
INFO - 2022-06-23 10:34:27 --> Helper loaded: file_helper
INFO - 2022-06-23 10:34:27 --> Helper loaded: url_helper
INFO - 2022-06-23 10:34:27 --> Helper loaded: file_helper
INFO - 2022-06-23 10:34:27 --> Database Driver Class Initialized
INFO - 2022-06-23 10:34:27 --> Database Driver Class Initialized
INFO - 2022-06-23 10:34:27 --> Email Class Initialized
INFO - 2022-06-23 10:34:27 --> Email Class Initialized
DEBUG - 2022-06-23 10:34:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 10:34:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:34:27 --> Controller Class Initialized
INFO - 2022-06-23 10:34:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:34:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 10:34:27 --> test
INFO - 2022-06-23 10:34:27 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 10:34:27 --> Final output sent to browser
DEBUG - 2022-06-23 10:34:27 --> Total execution time: 0.0213
INFO - 2022-06-23 10:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:34:27 --> Controller Class Initialized
INFO - 2022-06-23 10:34:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:34:27 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:34:27 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 10:34:27 --> Final output sent to browser
DEBUG - 2022-06-23 10:34:27 --> Total execution time: 0.0247
INFO - 2022-06-23 10:35:49 --> Config Class Initialized
INFO - 2022-06-23 10:35:49 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:35:49 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:35:49 --> Utf8 Class Initialized
INFO - 2022-06-23 10:35:49 --> URI Class Initialized
INFO - 2022-06-23 10:35:49 --> Router Class Initialized
INFO - 2022-06-23 10:35:49 --> Output Class Initialized
INFO - 2022-06-23 10:35:49 --> Security Class Initialized
DEBUG - 2022-06-23 10:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:35:49 --> Input Class Initialized
INFO - 2022-06-23 10:35:49 --> Language Class Initialized
INFO - 2022-06-23 10:35:49 --> Loader Class Initialized
INFO - 2022-06-23 10:35:49 --> Helper loaded: url_helper
INFO - 2022-06-23 10:35:49 --> Helper loaded: file_helper
INFO - 2022-06-23 10:35:49 --> Database Driver Class Initialized
INFO - 2022-06-23 10:35:49 --> Email Class Initialized
DEBUG - 2022-06-23 10:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:35:49 --> Controller Class Initialized
INFO - 2022-06-23 10:35:49 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:35:49 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:35:49 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 10:35:49 --> Final output sent to browser
DEBUG - 2022-06-23 10:35:49 --> Total execution time: 0.0370
INFO - 2022-06-23 10:36:00 --> Config Class Initialized
INFO - 2022-06-23 10:36:00 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:36:00 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:36:00 --> Config Class Initialized
INFO - 2022-06-23 10:36:00 --> Hooks Class Initialized
INFO - 2022-06-23 10:36:00 --> Utf8 Class Initialized
INFO - 2022-06-23 10:36:00 --> URI Class Initialized
DEBUG - 2022-06-23 10:36:00 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:36:00 --> Utf8 Class Initialized
INFO - 2022-06-23 10:36:00 --> Router Class Initialized
INFO - 2022-06-23 10:36:00 --> URI Class Initialized
INFO - 2022-06-23 10:36:00 --> Output Class Initialized
INFO - 2022-06-23 10:36:00 --> Router Class Initialized
INFO - 2022-06-23 10:36:00 --> Security Class Initialized
INFO - 2022-06-23 10:36:00 --> Output Class Initialized
DEBUG - 2022-06-23 10:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:36:00 --> Security Class Initialized
INFO - 2022-06-23 10:36:00 --> Input Class Initialized
DEBUG - 2022-06-23 10:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:36:00 --> Language Class Initialized
INFO - 2022-06-23 10:36:00 --> Input Class Initialized
INFO - 2022-06-23 10:36:00 --> Language Class Initialized
INFO - 2022-06-23 10:36:00 --> Loader Class Initialized
INFO - 2022-06-23 10:36:00 --> Loader Class Initialized
INFO - 2022-06-23 10:36:00 --> Helper loaded: url_helper
INFO - 2022-06-23 10:36:00 --> Helper loaded: url_helper
INFO - 2022-06-23 10:36:00 --> Helper loaded: file_helper
INFO - 2022-06-23 10:36:00 --> Helper loaded: file_helper
INFO - 2022-06-23 10:36:00 --> Database Driver Class Initialized
INFO - 2022-06-23 10:36:00 --> Database Driver Class Initialized
INFO - 2022-06-23 10:36:00 --> Email Class Initialized
INFO - 2022-06-23 10:36:00 --> Email Class Initialized
DEBUG - 2022-06-23 10:36:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 10:36:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:36:00 --> Controller Class Initialized
INFO - 2022-06-23 10:36:00 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:36:00 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:36:00 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 10:36:00 --> Final output sent to browser
DEBUG - 2022-06-23 10:36:00 --> Total execution time: 0.0173
INFO - 2022-06-23 10:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:36:00 --> Controller Class Initialized
INFO - 2022-06-23 10:36:00 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:36:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 10:36:00 --> test
INFO - 2022-06-23 10:36:00 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 10:36:00 --> Final output sent to browser
DEBUG - 2022-06-23 10:36:00 --> Total execution time: 0.0277
INFO - 2022-06-23 10:51:23 --> Config Class Initialized
INFO - 2022-06-23 10:51:23 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:51:23 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:51:23 --> Utf8 Class Initialized
INFO - 2022-06-23 10:51:23 --> URI Class Initialized
INFO - 2022-06-23 10:51:23 --> Router Class Initialized
INFO - 2022-06-23 10:51:23 --> Output Class Initialized
INFO - 2022-06-23 10:51:23 --> Security Class Initialized
DEBUG - 2022-06-23 10:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:51:23 --> Input Class Initialized
INFO - 2022-06-23 10:51:23 --> Language Class Initialized
ERROR - 2022-06-23 10:51:23 --> Severity: error --> Exception: syntax error, unexpected '}' C:\wamp64\www\qr\application\controllers\Tokenctrl.php 113
INFO - 2022-06-23 10:51:35 --> Config Class Initialized
INFO - 2022-06-23 10:51:35 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:51:35 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:51:35 --> Utf8 Class Initialized
INFO - 2022-06-23 10:51:35 --> URI Class Initialized
INFO - 2022-06-23 10:51:35 --> Router Class Initialized
INFO - 2022-06-23 10:51:35 --> Output Class Initialized
INFO - 2022-06-23 10:51:35 --> Security Class Initialized
DEBUG - 2022-06-23 10:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:51:35 --> Input Class Initialized
INFO - 2022-06-23 10:51:35 --> Language Class Initialized
INFO - 2022-06-23 10:51:35 --> Loader Class Initialized
INFO - 2022-06-23 10:51:35 --> Helper loaded: url_helper
INFO - 2022-06-23 10:51:35 --> Helper loaded: file_helper
INFO - 2022-06-23 10:51:35 --> Database Driver Class Initialized
INFO - 2022-06-23 10:51:35 --> Email Class Initialized
DEBUG - 2022-06-23 10:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:51:35 --> Controller Class Initialized
INFO - 2022-06-23 10:51:35 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:51:35 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:51:35 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 10:51:35 --> Final output sent to browser
DEBUG - 2022-06-23 10:51:35 --> Total execution time: 0.0441
INFO - 2022-06-23 10:51:43 --> Config Class Initialized
INFO - 2022-06-23 10:51:43 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:51:43 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:51:43 --> Utf8 Class Initialized
INFO - 2022-06-23 10:51:43 --> URI Class Initialized
INFO - 2022-06-23 10:51:43 --> Config Class Initialized
INFO - 2022-06-23 10:51:43 --> Hooks Class Initialized
INFO - 2022-06-23 10:51:43 --> Router Class Initialized
DEBUG - 2022-06-23 10:51:43 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:51:43 --> Utf8 Class Initialized
INFO - 2022-06-23 10:51:43 --> Output Class Initialized
INFO - 2022-06-23 10:51:43 --> URI Class Initialized
INFO - 2022-06-23 10:51:43 --> Security Class Initialized
DEBUG - 2022-06-23 10:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:51:43 --> Router Class Initialized
INFO - 2022-06-23 10:51:43 --> Input Class Initialized
INFO - 2022-06-23 10:51:43 --> Output Class Initialized
INFO - 2022-06-23 10:51:43 --> Language Class Initialized
INFO - 2022-06-23 10:51:43 --> Security Class Initialized
INFO - 2022-06-23 10:51:43 --> Loader Class Initialized
DEBUG - 2022-06-23 10:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:51:43 --> Input Class Initialized
INFO - 2022-06-23 10:51:43 --> Helper loaded: url_helper
INFO - 2022-06-23 10:51:43 --> Language Class Initialized
INFO - 2022-06-23 10:51:43 --> Helper loaded: file_helper
INFO - 2022-06-23 10:51:43 --> Loader Class Initialized
INFO - 2022-06-23 10:51:43 --> Helper loaded: url_helper
INFO - 2022-06-23 10:51:43 --> Database Driver Class Initialized
INFO - 2022-06-23 10:51:43 --> Helper loaded: file_helper
INFO - 2022-06-23 10:51:43 --> Database Driver Class Initialized
INFO - 2022-06-23 10:51:43 --> Email Class Initialized
INFO - 2022-06-23 10:51:43 --> Email Class Initialized
DEBUG - 2022-06-23 10:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 10:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:51:43 --> Controller Class Initialized
INFO - 2022-06-23 10:51:43 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:51:43 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:51:43 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 10:51:43 --> Final output sent to browser
DEBUG - 2022-06-23 10:51:43 --> Total execution time: 0.0329
INFO - 2022-06-23 10:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:51:43 --> Controller Class Initialized
INFO - 2022-06-23 10:51:43 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:51:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 10:51:43 --> test
INFO - 2022-06-23 10:52:46 --> Config Class Initialized
INFO - 2022-06-23 10:52:46 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:52:46 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:52:46 --> Utf8 Class Initialized
INFO - 2022-06-23 10:52:46 --> URI Class Initialized
INFO - 2022-06-23 10:52:46 --> Router Class Initialized
INFO - 2022-06-23 10:52:46 --> Output Class Initialized
INFO - 2022-06-23 10:52:46 --> Security Class Initialized
DEBUG - 2022-06-23 10:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:52:46 --> Input Class Initialized
INFO - 2022-06-23 10:52:46 --> Language Class Initialized
INFO - 2022-06-23 10:52:46 --> Loader Class Initialized
INFO - 2022-06-23 10:52:46 --> Helper loaded: url_helper
INFO - 2022-06-23 10:52:46 --> Helper loaded: file_helper
INFO - 2022-06-23 10:52:46 --> Database Driver Class Initialized
INFO - 2022-06-23 10:52:46 --> Email Class Initialized
DEBUG - 2022-06-23 10:52:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:52:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:52:46 --> Controller Class Initialized
INFO - 2022-06-23 10:52:46 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:52:46 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:52:46 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 10:52:46 --> Final output sent to browser
DEBUG - 2022-06-23 10:52:46 --> Total execution time: 0.0184
INFO - 2022-06-23 10:52:58 --> Config Class Initialized
INFO - 2022-06-23 10:52:58 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:52:58 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:52:58 --> Utf8 Class Initialized
INFO - 2022-06-23 10:52:58 --> URI Class Initialized
INFO - 2022-06-23 10:52:58 --> Config Class Initialized
INFO - 2022-06-23 10:52:58 --> Hooks Class Initialized
INFO - 2022-06-23 10:52:58 --> Router Class Initialized
DEBUG - 2022-06-23 10:52:58 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:52:58 --> Utf8 Class Initialized
INFO - 2022-06-23 10:52:58 --> Output Class Initialized
INFO - 2022-06-23 10:52:58 --> URI Class Initialized
INFO - 2022-06-23 10:52:58 --> Security Class Initialized
DEBUG - 2022-06-23 10:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:52:58 --> Router Class Initialized
INFO - 2022-06-23 10:52:58 --> Input Class Initialized
INFO - 2022-06-23 10:52:58 --> Output Class Initialized
INFO - 2022-06-23 10:52:58 --> Language Class Initialized
INFO - 2022-06-23 10:52:58 --> Security Class Initialized
INFO - 2022-06-23 10:52:58 --> Loader Class Initialized
DEBUG - 2022-06-23 10:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:52:58 --> Input Class Initialized
INFO - 2022-06-23 10:52:58 --> Helper loaded: url_helper
INFO - 2022-06-23 10:52:58 --> Language Class Initialized
INFO - 2022-06-23 10:52:58 --> Helper loaded: file_helper
INFO - 2022-06-23 10:52:58 --> Loader Class Initialized
INFO - 2022-06-23 10:52:58 --> Database Driver Class Initialized
INFO - 2022-06-23 10:52:58 --> Helper loaded: url_helper
INFO - 2022-06-23 10:52:58 --> Helper loaded: file_helper
INFO - 2022-06-23 10:52:58 --> Database Driver Class Initialized
INFO - 2022-06-23 10:52:58 --> Email Class Initialized
DEBUG - 2022-06-23 10:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:52:58 --> Email Class Initialized
INFO - 2022-06-23 10:52:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2022-06-23 10:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:52:58 --> Controller Class Initialized
INFO - 2022-06-23 10:52:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:52:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 10:52:58 --> test
INFO - 2022-06-23 10:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:52:58 --> Controller Class Initialized
INFO - 2022-06-23 10:52:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:52:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:52:58 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 10:52:58 --> Final output sent to browser
DEBUG - 2022-06-23 10:52:58 --> Total execution time: 0.0215
INFO - 2022-06-23 10:52:58 --> Config Class Initialized
INFO - 2022-06-23 10:52:58 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:52:58 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:52:58 --> Utf8 Class Initialized
INFO - 2022-06-23 10:52:58 --> URI Class Initialized
INFO - 2022-06-23 10:52:58 --> Router Class Initialized
INFO - 2022-06-23 10:52:58 --> Output Class Initialized
INFO - 2022-06-23 10:52:58 --> Security Class Initialized
DEBUG - 2022-06-23 10:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:52:58 --> Input Class Initialized
INFO - 2022-06-23 10:52:58 --> Language Class Initialized
ERROR - 2022-06-23 10:52:58 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-23 10:56:02 --> Config Class Initialized
INFO - 2022-06-23 10:56:02 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:56:02 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:56:02 --> Utf8 Class Initialized
INFO - 2022-06-23 10:56:02 --> URI Class Initialized
INFO - 2022-06-23 10:56:02 --> Router Class Initialized
INFO - 2022-06-23 10:56:02 --> Output Class Initialized
INFO - 2022-06-23 10:56:02 --> Security Class Initialized
DEBUG - 2022-06-23 10:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:56:02 --> Input Class Initialized
INFO - 2022-06-23 10:56:02 --> Language Class Initialized
INFO - 2022-06-23 10:56:02 --> Loader Class Initialized
INFO - 2022-06-23 10:56:02 --> Helper loaded: url_helper
INFO - 2022-06-23 10:56:02 --> Helper loaded: file_helper
INFO - 2022-06-23 10:56:02 --> Database Driver Class Initialized
INFO - 2022-06-23 10:56:02 --> Email Class Initialized
DEBUG - 2022-06-23 10:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:56:02 --> Controller Class Initialized
INFO - 2022-06-23 10:56:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:56:02 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:56:02 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 10:56:02 --> Final output sent to browser
DEBUG - 2022-06-23 10:56:02 --> Total execution time: 0.0419
INFO - 2022-06-23 10:56:14 --> Config Class Initialized
INFO - 2022-06-23 10:56:14 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:56:14 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:56:14 --> Utf8 Class Initialized
INFO - 2022-06-23 10:56:14 --> Config Class Initialized
INFO - 2022-06-23 10:56:14 --> URI Class Initialized
INFO - 2022-06-23 10:56:14 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:56:14 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:56:14 --> Router Class Initialized
INFO - 2022-06-23 10:56:14 --> Utf8 Class Initialized
INFO - 2022-06-23 10:56:14 --> Output Class Initialized
INFO - 2022-06-23 10:56:14 --> URI Class Initialized
INFO - 2022-06-23 10:56:14 --> Security Class Initialized
INFO - 2022-06-23 10:56:14 --> Router Class Initialized
DEBUG - 2022-06-23 10:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:56:14 --> Input Class Initialized
INFO - 2022-06-23 10:56:14 --> Output Class Initialized
INFO - 2022-06-23 10:56:14 --> Language Class Initialized
INFO - 2022-06-23 10:56:14 --> Security Class Initialized
DEBUG - 2022-06-23 10:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:56:14 --> Loader Class Initialized
INFO - 2022-06-23 10:56:14 --> Input Class Initialized
INFO - 2022-06-23 10:56:14 --> Language Class Initialized
INFO - 2022-06-23 10:56:14 --> Helper loaded: url_helper
INFO - 2022-06-23 10:56:14 --> Loader Class Initialized
INFO - 2022-06-23 10:56:14 --> Helper loaded: file_helper
INFO - 2022-06-23 10:56:14 --> Helper loaded: url_helper
INFO - 2022-06-23 10:56:14 --> Helper loaded: file_helper
INFO - 2022-06-23 10:56:14 --> Database Driver Class Initialized
INFO - 2022-06-23 10:56:14 --> Database Driver Class Initialized
INFO - 2022-06-23 10:56:14 --> Email Class Initialized
INFO - 2022-06-23 10:56:14 --> Email Class Initialized
DEBUG - 2022-06-23 10:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 10:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:56:14 --> Controller Class Initialized
INFO - 2022-06-23 10:56:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:56:14 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:56:14 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 10:56:14 --> Final output sent to browser
DEBUG - 2022-06-23 10:56:14 --> Total execution time: 0.0181
INFO - 2022-06-23 10:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:56:14 --> Controller Class Initialized
INFO - 2022-06-23 10:56:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:56:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 10:56:14 --> test
INFO - 2022-06-23 10:57:55 --> Config Class Initialized
INFO - 2022-06-23 10:57:55 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:57:55 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:57:55 --> Utf8 Class Initialized
INFO - 2022-06-23 10:57:55 --> URI Class Initialized
INFO - 2022-06-23 10:57:55 --> Router Class Initialized
INFO - 2022-06-23 10:57:55 --> Output Class Initialized
INFO - 2022-06-23 10:57:55 --> Security Class Initialized
DEBUG - 2022-06-23 10:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:57:55 --> Input Class Initialized
INFO - 2022-06-23 10:57:55 --> Language Class Initialized
INFO - 2022-06-23 10:57:55 --> Loader Class Initialized
INFO - 2022-06-23 10:57:55 --> Helper loaded: url_helper
INFO - 2022-06-23 10:57:55 --> Helper loaded: file_helper
INFO - 2022-06-23 10:57:55 --> Database Driver Class Initialized
INFO - 2022-06-23 10:57:55 --> Email Class Initialized
DEBUG - 2022-06-23 10:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:57:55 --> Controller Class Initialized
INFO - 2022-06-23 10:57:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:57:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:57:55 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 10:57:55 --> Final output sent to browser
DEBUG - 2022-06-23 10:57:55 --> Total execution time: 0.0234
INFO - 2022-06-23 10:58:05 --> Config Class Initialized
INFO - 2022-06-23 10:58:05 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:58:05 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:58:05 --> Config Class Initialized
INFO - 2022-06-23 10:58:05 --> Utf8 Class Initialized
INFO - 2022-06-23 10:58:05 --> Hooks Class Initialized
INFO - 2022-06-23 10:58:05 --> URI Class Initialized
DEBUG - 2022-06-23 10:58:05 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:58:05 --> Utf8 Class Initialized
INFO - 2022-06-23 10:58:05 --> Router Class Initialized
INFO - 2022-06-23 10:58:05 --> URI Class Initialized
INFO - 2022-06-23 10:58:05 --> Output Class Initialized
INFO - 2022-06-23 10:58:05 --> Router Class Initialized
INFO - 2022-06-23 10:58:05 --> Security Class Initialized
INFO - 2022-06-23 10:58:05 --> Output Class Initialized
DEBUG - 2022-06-23 10:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:58:05 --> Input Class Initialized
INFO - 2022-06-23 10:58:05 --> Security Class Initialized
INFO - 2022-06-23 10:58:05 --> Language Class Initialized
DEBUG - 2022-06-23 10:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:58:05 --> Loader Class Initialized
INFO - 2022-06-23 10:58:05 --> Input Class Initialized
INFO - 2022-06-23 10:58:05 --> Language Class Initialized
INFO - 2022-06-23 10:58:05 --> Helper loaded: url_helper
INFO - 2022-06-23 10:58:05 --> Loader Class Initialized
INFO - 2022-06-23 10:58:05 --> Helper loaded: file_helper
INFO - 2022-06-23 10:58:05 --> Helper loaded: url_helper
INFO - 2022-06-23 10:58:05 --> Database Driver Class Initialized
INFO - 2022-06-23 10:58:05 --> Helper loaded: file_helper
INFO - 2022-06-23 10:58:05 --> Database Driver Class Initialized
INFO - 2022-06-23 10:58:05 --> Email Class Initialized
DEBUG - 2022-06-23 10:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:58:05 --> Email Class Initialized
INFO - 2022-06-23 10:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:58:05 --> Controller Class Initialized
DEBUG - 2022-06-23 10:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 10:58:05 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:58:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 10:58:05 --> test
INFO - 2022-06-23 10:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 10:58:05 --> Controller Class Initialized
INFO - 2022-06-23 10:58:05 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 10:58:05 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 10:58:05 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 10:58:05 --> Final output sent to browser
DEBUG - 2022-06-23 10:58:05 --> Total execution time: 0.0338
INFO - 2022-06-23 10:58:05 --> Config Class Initialized
INFO - 2022-06-23 10:58:05 --> Hooks Class Initialized
DEBUG - 2022-06-23 10:58:05 --> UTF-8 Support Enabled
INFO - 2022-06-23 10:58:05 --> Utf8 Class Initialized
INFO - 2022-06-23 10:58:05 --> URI Class Initialized
INFO - 2022-06-23 10:58:05 --> Router Class Initialized
INFO - 2022-06-23 10:58:05 --> Output Class Initialized
INFO - 2022-06-23 10:58:05 --> Security Class Initialized
DEBUG - 2022-06-23 10:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 10:58:05 --> Input Class Initialized
INFO - 2022-06-23 10:58:05 --> Language Class Initialized
ERROR - 2022-06-23 10:58:05 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-23 11:00:37 --> Config Class Initialized
INFO - 2022-06-23 11:00:37 --> Hooks Class Initialized
DEBUG - 2022-06-23 11:00:37 --> UTF-8 Support Enabled
INFO - 2022-06-23 11:00:37 --> Utf8 Class Initialized
INFO - 2022-06-23 11:00:37 --> URI Class Initialized
INFO - 2022-06-23 11:00:37 --> Router Class Initialized
INFO - 2022-06-23 11:00:37 --> Output Class Initialized
INFO - 2022-06-23 11:00:37 --> Config Class Initialized
INFO - 2022-06-23 11:00:37 --> Hooks Class Initialized
INFO - 2022-06-23 11:00:37 --> Security Class Initialized
DEBUG - 2022-06-23 11:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 11:00:37 --> UTF-8 Support Enabled
INFO - 2022-06-23 11:00:37 --> Utf8 Class Initialized
INFO - 2022-06-23 11:00:37 --> Input Class Initialized
INFO - 2022-06-23 11:00:37 --> URI Class Initialized
INFO - 2022-06-23 11:00:37 --> Language Class Initialized
INFO - 2022-06-23 11:00:37 --> Router Class Initialized
INFO - 2022-06-23 11:00:37 --> Loader Class Initialized
INFO - 2022-06-23 11:00:37 --> Output Class Initialized
INFO - 2022-06-23 11:00:37 --> Security Class Initialized
INFO - 2022-06-23 11:00:37 --> Helper loaded: url_helper
DEBUG - 2022-06-23 11:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 11:00:37 --> Helper loaded: file_helper
INFO - 2022-06-23 11:00:37 --> Input Class Initialized
INFO - 2022-06-23 11:00:37 --> Language Class Initialized
INFO - 2022-06-23 11:00:37 --> Database Driver Class Initialized
INFO - 2022-06-23 11:00:37 --> Loader Class Initialized
INFO - 2022-06-23 11:00:37 --> Helper loaded: url_helper
INFO - 2022-06-23 11:00:37 --> Helper loaded: file_helper
INFO - 2022-06-23 11:00:37 --> Database Driver Class Initialized
INFO - 2022-06-23 11:00:37 --> Email Class Initialized
DEBUG - 2022-06-23 11:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 11:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 11:00:37 --> Controller Class Initialized
INFO - 2022-06-23 11:00:37 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 11:00:37 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 11:00:37 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 11:00:37 --> Final output sent to browser
DEBUG - 2022-06-23 11:00:37 --> Total execution time: 0.0208
INFO - 2022-06-23 11:00:37 --> Email Class Initialized
DEBUG - 2022-06-23 11:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 11:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 11:00:37 --> Controller Class Initialized
INFO - 2022-06-23 11:00:37 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 11:00:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 11:00:37 --> test
INFO - 2022-06-23 11:01:44 --> Config Class Initialized
INFO - 2022-06-23 11:01:44 --> Hooks Class Initialized
DEBUG - 2022-06-23 11:01:44 --> UTF-8 Support Enabled
INFO - 2022-06-23 11:01:44 --> Utf8 Class Initialized
INFO - 2022-06-23 11:01:44 --> URI Class Initialized
INFO - 2022-06-23 11:01:44 --> Router Class Initialized
INFO - 2022-06-23 11:01:44 --> Output Class Initialized
INFO - 2022-06-23 11:01:44 --> Security Class Initialized
DEBUG - 2022-06-23 11:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 11:01:44 --> Input Class Initialized
INFO - 2022-06-23 11:01:44 --> Language Class Initialized
INFO - 2022-06-23 11:01:44 --> Loader Class Initialized
INFO - 2022-06-23 11:01:44 --> Helper loaded: url_helper
INFO - 2022-06-23 11:01:44 --> Helper loaded: file_helper
INFO - 2022-06-23 11:01:44 --> Database Driver Class Initialized
INFO - 2022-06-23 11:01:44 --> Email Class Initialized
DEBUG - 2022-06-23 11:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 11:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 11:01:44 --> Controller Class Initialized
INFO - 2022-06-23 11:01:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 11:01:44 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 11:01:44 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 11:01:44 --> Final output sent to browser
DEBUG - 2022-06-23 11:01:44 --> Total execution time: 0.0200
INFO - 2022-06-23 11:01:52 --> Config Class Initialized
INFO - 2022-06-23 11:01:52 --> Config Class Initialized
INFO - 2022-06-23 11:01:52 --> Hooks Class Initialized
INFO - 2022-06-23 11:01:52 --> Hooks Class Initialized
DEBUG - 2022-06-23 11:01:52 --> UTF-8 Support Enabled
INFO - 2022-06-23 11:01:52 --> Utf8 Class Initialized
DEBUG - 2022-06-23 11:01:52 --> UTF-8 Support Enabled
INFO - 2022-06-23 11:01:52 --> Utf8 Class Initialized
INFO - 2022-06-23 11:01:52 --> URI Class Initialized
INFO - 2022-06-23 11:01:52 --> URI Class Initialized
INFO - 2022-06-23 11:01:52 --> Router Class Initialized
INFO - 2022-06-23 11:01:52 --> Output Class Initialized
INFO - 2022-06-23 11:01:52 --> Router Class Initialized
INFO - 2022-06-23 11:01:52 --> Security Class Initialized
INFO - 2022-06-23 11:01:52 --> Output Class Initialized
DEBUG - 2022-06-23 11:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 11:01:52 --> Security Class Initialized
INFO - 2022-06-23 11:01:52 --> Input Class Initialized
DEBUG - 2022-06-23 11:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 11:01:52 --> Language Class Initialized
INFO - 2022-06-23 11:01:52 --> Input Class Initialized
INFO - 2022-06-23 11:01:52 --> Loader Class Initialized
INFO - 2022-06-23 11:01:52 --> Language Class Initialized
INFO - 2022-06-23 11:01:52 --> Loader Class Initialized
INFO - 2022-06-23 11:01:52 --> Helper loaded: url_helper
INFO - 2022-06-23 11:01:52 --> Helper loaded: file_helper
INFO - 2022-06-23 11:01:52 --> Helper loaded: url_helper
INFO - 2022-06-23 11:01:52 --> Helper loaded: file_helper
INFO - 2022-06-23 11:01:52 --> Database Driver Class Initialized
INFO - 2022-06-23 11:01:52 --> Database Driver Class Initialized
INFO - 2022-06-23 11:01:53 --> Email Class Initialized
INFO - 2022-06-23 11:01:53 --> Email Class Initialized
DEBUG - 2022-06-23 11:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 11:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 11:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 11:01:53 --> Controller Class Initialized
INFO - 2022-06-23 11:01:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 11:01:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 11:01:53 --> test
INFO - 2022-06-23 11:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 11:01:53 --> Controller Class Initialized
INFO - 2022-06-23 11:01:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 11:01:53 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 11:01:53 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 11:01:53 --> Final output sent to browser
DEBUG - 2022-06-23 11:01:53 --> Total execution time: 0.0257
INFO - 2022-06-23 11:01:53 --> Config Class Initialized
INFO - 2022-06-23 11:01:53 --> Hooks Class Initialized
DEBUG - 2022-06-23 11:01:53 --> UTF-8 Support Enabled
INFO - 2022-06-23 11:01:53 --> Utf8 Class Initialized
INFO - 2022-06-23 11:01:53 --> URI Class Initialized
INFO - 2022-06-23 11:01:53 --> Router Class Initialized
INFO - 2022-06-23 11:01:53 --> Output Class Initialized
INFO - 2022-06-23 11:01:53 --> Security Class Initialized
DEBUG - 2022-06-23 11:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 11:01:53 --> Input Class Initialized
INFO - 2022-06-23 11:01:53 --> Language Class Initialized
ERROR - 2022-06-23 11:01:53 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-23 11:03:15 --> Config Class Initialized
INFO - 2022-06-23 11:03:15 --> Hooks Class Initialized
DEBUG - 2022-06-23 11:03:15 --> UTF-8 Support Enabled
INFO - 2022-06-23 11:03:15 --> Utf8 Class Initialized
INFO - 2022-06-23 11:03:15 --> URI Class Initialized
INFO - 2022-06-23 11:03:15 --> Router Class Initialized
INFO - 2022-06-23 11:03:15 --> Output Class Initialized
INFO - 2022-06-23 11:03:15 --> Security Class Initialized
DEBUG - 2022-06-23 11:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 11:03:15 --> Input Class Initialized
INFO - 2022-06-23 11:03:15 --> Language Class Initialized
INFO - 2022-06-23 11:03:15 --> Loader Class Initialized
INFO - 2022-06-23 11:03:15 --> Helper loaded: url_helper
INFO - 2022-06-23 11:03:15 --> Helper loaded: file_helper
INFO - 2022-06-23 11:03:15 --> Database Driver Class Initialized
INFO - 2022-06-23 11:03:15 --> Email Class Initialized
DEBUG - 2022-06-23 11:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 11:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 11:03:15 --> Controller Class Initialized
INFO - 2022-06-23 11:03:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 11:03:15 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 11:03:15 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 11:03:15 --> Final output sent to browser
DEBUG - 2022-06-23 11:03:15 --> Total execution time: 0.0331
INFO - 2022-06-23 11:03:21 --> Config Class Initialized
INFO - 2022-06-23 11:03:21 --> Hooks Class Initialized
DEBUG - 2022-06-23 11:03:21 --> UTF-8 Support Enabled
INFO - 2022-06-23 11:03:21 --> Utf8 Class Initialized
INFO - 2022-06-23 11:03:21 --> URI Class Initialized
INFO - 2022-06-23 11:03:21 --> Router Class Initialized
INFO - 2022-06-23 11:03:21 --> Output Class Initialized
INFO - 2022-06-23 11:03:21 --> Security Class Initialized
DEBUG - 2022-06-23 11:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 11:03:21 --> Input Class Initialized
INFO - 2022-06-23 11:03:21 --> Language Class Initialized
INFO - 2022-06-23 11:03:21 --> Loader Class Initialized
INFO - 2022-06-23 11:03:21 --> Helper loaded: url_helper
INFO - 2022-06-23 11:03:21 --> Helper loaded: file_helper
INFO - 2022-06-23 11:03:21 --> Database Driver Class Initialized
INFO - 2022-06-23 11:03:21 --> Email Class Initialized
DEBUG - 2022-06-23 11:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 11:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 11:03:21 --> Controller Class Initialized
INFO - 2022-06-23 11:03:21 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 11:03:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 11:03:21 --> test
INFO - 2022-06-23 11:03:21 --> Config Class Initialized
INFO - 2022-06-23 11:03:21 --> Hooks Class Initialized
DEBUG - 2022-06-23 11:03:21 --> UTF-8 Support Enabled
INFO - 2022-06-23 11:03:21 --> Utf8 Class Initialized
INFO - 2022-06-23 11:03:21 --> URI Class Initialized
INFO - 2022-06-23 11:03:21 --> Router Class Initialized
INFO - 2022-06-23 11:03:21 --> Output Class Initialized
INFO - 2022-06-23 11:03:21 --> Security Class Initialized
DEBUG - 2022-06-23 11:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 11:03:21 --> Input Class Initialized
INFO - 2022-06-23 11:03:21 --> Language Class Initialized
ERROR - 2022-06-23 11:03:21 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-23 11:03:43 --> Config Class Initialized
INFO - 2022-06-23 11:03:43 --> Hooks Class Initialized
DEBUG - 2022-06-23 11:03:43 --> UTF-8 Support Enabled
INFO - 2022-06-23 11:03:43 --> Utf8 Class Initialized
INFO - 2022-06-23 11:03:43 --> URI Class Initialized
INFO - 2022-06-23 11:03:43 --> Router Class Initialized
INFO - 2022-06-23 11:03:43 --> Output Class Initialized
INFO - 2022-06-23 11:03:43 --> Security Class Initialized
DEBUG - 2022-06-23 11:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 11:03:43 --> Input Class Initialized
INFO - 2022-06-23 11:03:43 --> Language Class Initialized
INFO - 2022-06-23 11:03:43 --> Loader Class Initialized
INFO - 2022-06-23 11:03:43 --> Helper loaded: url_helper
INFO - 2022-06-23 11:03:43 --> Helper loaded: file_helper
INFO - 2022-06-23 11:03:43 --> Database Driver Class Initialized
INFO - 2022-06-23 11:03:43 --> Email Class Initialized
DEBUG - 2022-06-23 11:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 11:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 11:03:43 --> Controller Class Initialized
INFO - 2022-06-23 11:03:43 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 11:03:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 11:03:43 --> test
INFO - 2022-06-23 11:03:43 --> Config Class Initialized
INFO - 2022-06-23 11:03:43 --> Hooks Class Initialized
DEBUG - 2022-06-23 11:03:43 --> UTF-8 Support Enabled
INFO - 2022-06-23 11:03:43 --> Utf8 Class Initialized
INFO - 2022-06-23 11:03:43 --> URI Class Initialized
INFO - 2022-06-23 11:03:43 --> Router Class Initialized
INFO - 2022-06-23 11:03:43 --> Output Class Initialized
INFO - 2022-06-23 11:03:43 --> Security Class Initialized
DEBUG - 2022-06-23 11:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 11:03:43 --> Input Class Initialized
INFO - 2022-06-23 11:03:43 --> Language Class Initialized
ERROR - 2022-06-23 11:03:43 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-23 11:05:42 --> Config Class Initialized
INFO - 2022-06-23 11:05:42 --> Hooks Class Initialized
DEBUG - 2022-06-23 11:05:42 --> UTF-8 Support Enabled
INFO - 2022-06-23 11:05:42 --> Utf8 Class Initialized
INFO - 2022-06-23 11:05:42 --> URI Class Initialized
INFO - 2022-06-23 11:05:42 --> Router Class Initialized
INFO - 2022-06-23 11:05:42 --> Output Class Initialized
INFO - 2022-06-23 11:05:42 --> Security Class Initialized
DEBUG - 2022-06-23 11:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 11:05:42 --> Input Class Initialized
INFO - 2022-06-23 11:05:42 --> Language Class Initialized
INFO - 2022-06-23 11:05:42 --> Loader Class Initialized
INFO - 2022-06-23 11:05:42 --> Helper loaded: url_helper
INFO - 2022-06-23 11:05:42 --> Helper loaded: file_helper
INFO - 2022-06-23 11:05:42 --> Database Driver Class Initialized
INFO - 2022-06-23 11:05:42 --> Email Class Initialized
DEBUG - 2022-06-23 11:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 11:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 11:05:42 --> Controller Class Initialized
INFO - 2022-06-23 11:05:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 11:05:42 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 11:05:42 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 11:05:42 --> Final output sent to browser
DEBUG - 2022-06-23 11:05:42 --> Total execution time: 0.0176
INFO - 2022-06-23 11:05:50 --> Config Class Initialized
INFO - 2022-06-23 11:05:50 --> Hooks Class Initialized
DEBUG - 2022-06-23 11:05:50 --> UTF-8 Support Enabled
INFO - 2022-06-23 11:05:50 --> Utf8 Class Initialized
INFO - 2022-06-23 11:05:50 --> URI Class Initialized
INFO - 2022-06-23 11:05:50 --> Router Class Initialized
INFO - 2022-06-23 11:05:50 --> Output Class Initialized
INFO - 2022-06-23 11:05:50 --> Security Class Initialized
DEBUG - 2022-06-23 11:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 11:05:50 --> Input Class Initialized
INFO - 2022-06-23 11:05:50 --> Language Class Initialized
INFO - 2022-06-23 11:05:50 --> Loader Class Initialized
INFO - 2022-06-23 11:05:50 --> Helper loaded: url_helper
INFO - 2022-06-23 11:05:50 --> Helper loaded: file_helper
INFO - 2022-06-23 11:05:50 --> Database Driver Class Initialized
INFO - 2022-06-23 11:05:50 --> Email Class Initialized
DEBUG - 2022-06-23 11:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 11:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 11:05:50 --> Controller Class Initialized
INFO - 2022-06-23 11:05:50 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 11:05:50 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 11:05:50 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 11:05:50 --> Final output sent to browser
DEBUG - 2022-06-23 11:05:50 --> Total execution time: 0.0201
INFO - 2022-06-23 11:06:01 --> Config Class Initialized
INFO - 2022-06-23 11:06:01 --> Hooks Class Initialized
DEBUG - 2022-06-23 11:06:01 --> UTF-8 Support Enabled
INFO - 2022-06-23 11:06:01 --> Utf8 Class Initialized
INFO - 2022-06-23 11:06:01 --> URI Class Initialized
INFO - 2022-06-23 11:06:01 --> Router Class Initialized
INFO - 2022-06-23 11:06:01 --> Output Class Initialized
INFO - 2022-06-23 11:06:01 --> Security Class Initialized
DEBUG - 2022-06-23 11:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 11:06:01 --> Input Class Initialized
INFO - 2022-06-23 11:06:01 --> Language Class Initialized
INFO - 2022-06-23 11:06:01 --> Loader Class Initialized
INFO - 2022-06-23 11:06:01 --> Helper loaded: url_helper
INFO - 2022-06-23 11:06:01 --> Helper loaded: file_helper
INFO - 2022-06-23 11:06:01 --> Database Driver Class Initialized
INFO - 2022-06-23 11:06:01 --> Email Class Initialized
DEBUG - 2022-06-23 11:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 11:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 11:06:01 --> Controller Class Initialized
INFO - 2022-06-23 11:06:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 11:06:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 11:06:01 --> test
INFO - 2022-06-23 11:06:01 --> Config Class Initialized
INFO - 2022-06-23 11:06:01 --> Hooks Class Initialized
DEBUG - 2022-06-23 11:06:01 --> UTF-8 Support Enabled
INFO - 2022-06-23 11:06:01 --> Utf8 Class Initialized
INFO - 2022-06-23 11:06:01 --> URI Class Initialized
INFO - 2022-06-23 11:06:01 --> Router Class Initialized
INFO - 2022-06-23 11:06:01 --> Output Class Initialized
INFO - 2022-06-23 11:06:01 --> Security Class Initialized
DEBUG - 2022-06-23 11:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 11:06:01 --> Input Class Initialized
INFO - 2022-06-23 11:06:01 --> Language Class Initialized
ERROR - 2022-06-23 11:06:01 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-23 11:09:25 --> Config Class Initialized
INFO - 2022-06-23 11:09:25 --> Hooks Class Initialized
DEBUG - 2022-06-23 11:09:25 --> UTF-8 Support Enabled
INFO - 2022-06-23 11:09:25 --> Utf8 Class Initialized
INFO - 2022-06-23 11:09:25 --> URI Class Initialized
INFO - 2022-06-23 11:09:25 --> Router Class Initialized
INFO - 2022-06-23 11:09:25 --> Output Class Initialized
INFO - 2022-06-23 11:09:25 --> Security Class Initialized
DEBUG - 2022-06-23 11:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 11:09:25 --> Input Class Initialized
INFO - 2022-06-23 11:09:25 --> Language Class Initialized
INFO - 2022-06-23 11:09:25 --> Loader Class Initialized
INFO - 2022-06-23 11:09:25 --> Helper loaded: url_helper
INFO - 2022-06-23 11:09:25 --> Helper loaded: file_helper
INFO - 2022-06-23 11:09:25 --> Database Driver Class Initialized
INFO - 2022-06-23 11:09:25 --> Email Class Initialized
DEBUG - 2022-06-23 11:09:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 11:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 11:09:25 --> Controller Class Initialized
INFO - 2022-06-23 11:09:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 11:09:25 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 11:09:25 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 11:09:25 --> Final output sent to browser
DEBUG - 2022-06-23 11:09:25 --> Total execution time: 0.0274
INFO - 2022-06-23 11:09:37 --> Config Class Initialized
INFO - 2022-06-23 11:09:37 --> Hooks Class Initialized
DEBUG - 2022-06-23 11:09:37 --> UTF-8 Support Enabled
INFO - 2022-06-23 11:09:37 --> Utf8 Class Initialized
INFO - 2022-06-23 11:09:37 --> URI Class Initialized
INFO - 2022-06-23 11:09:37 --> Router Class Initialized
INFO - 2022-06-23 11:09:37 --> Output Class Initialized
INFO - 2022-06-23 11:09:37 --> Security Class Initialized
DEBUG - 2022-06-23 11:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 11:09:37 --> Input Class Initialized
INFO - 2022-06-23 11:09:37 --> Language Class Initialized
INFO - 2022-06-23 11:09:37 --> Loader Class Initialized
INFO - 2022-06-23 11:09:37 --> Helper loaded: url_helper
INFO - 2022-06-23 11:09:37 --> Helper loaded: file_helper
INFO - 2022-06-23 11:09:37 --> Database Driver Class Initialized
INFO - 2022-06-23 11:09:37 --> Email Class Initialized
DEBUG - 2022-06-23 11:09:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 11:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 11:09:37 --> Controller Class Initialized
INFO - 2022-06-23 11:09:37 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 11:09:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 11:09:37 --> test
INFO - 2022-06-23 11:09:37 --> Final output sent to browser
DEBUG - 2022-06-23 11:09:37 --> Total execution time: 0.0309
INFO - 2022-06-23 11:10:58 --> Config Class Initialized
INFO - 2022-06-23 11:10:58 --> Hooks Class Initialized
DEBUG - 2022-06-23 11:10:58 --> UTF-8 Support Enabled
INFO - 2022-06-23 11:10:58 --> Utf8 Class Initialized
INFO - 2022-06-23 11:10:58 --> URI Class Initialized
INFO - 2022-06-23 11:10:58 --> Router Class Initialized
INFO - 2022-06-23 11:10:58 --> Output Class Initialized
INFO - 2022-06-23 11:10:58 --> Security Class Initialized
DEBUG - 2022-06-23 11:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 11:10:58 --> Input Class Initialized
INFO - 2022-06-23 11:10:58 --> Language Class Initialized
INFO - 2022-06-23 11:10:58 --> Loader Class Initialized
INFO - 2022-06-23 11:10:58 --> Helper loaded: url_helper
INFO - 2022-06-23 11:10:58 --> Helper loaded: file_helper
INFO - 2022-06-23 11:10:58 --> Database Driver Class Initialized
INFO - 2022-06-23 11:10:58 --> Email Class Initialized
DEBUG - 2022-06-23 11:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 11:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 11:10:58 --> Controller Class Initialized
INFO - 2022-06-23 11:10:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 11:10:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 11:10:58 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 11:10:58 --> Final output sent to browser
DEBUG - 2022-06-23 11:10:58 --> Total execution time: 0.0293
INFO - 2022-06-23 11:11:09 --> Config Class Initialized
INFO - 2022-06-23 11:11:09 --> Hooks Class Initialized
DEBUG - 2022-06-23 11:11:09 --> UTF-8 Support Enabled
INFO - 2022-06-23 11:11:09 --> Utf8 Class Initialized
INFO - 2022-06-23 11:11:09 --> URI Class Initialized
INFO - 2022-06-23 11:11:09 --> Router Class Initialized
INFO - 2022-06-23 11:11:09 --> Output Class Initialized
INFO - 2022-06-23 11:11:09 --> Security Class Initialized
DEBUG - 2022-06-23 11:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 11:11:09 --> Input Class Initialized
INFO - 2022-06-23 11:11:09 --> Language Class Initialized
INFO - 2022-06-23 11:11:09 --> Loader Class Initialized
INFO - 2022-06-23 11:11:09 --> Helper loaded: url_helper
INFO - 2022-06-23 11:11:09 --> Helper loaded: file_helper
INFO - 2022-06-23 11:11:09 --> Database Driver Class Initialized
INFO - 2022-06-23 11:11:09 --> Email Class Initialized
DEBUG - 2022-06-23 11:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 11:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 11:11:09 --> Controller Class Initialized
INFO - 2022-06-23 11:11:09 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 11:11:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 11:11:09 --> test
INFO - 2022-06-23 11:11:09 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 11:11:09 --> Final output sent to browser
DEBUG - 2022-06-23 11:11:09 --> Total execution time: 0.0412
INFO - 2022-06-23 11:29:22 --> Config Class Initialized
INFO - 2022-06-23 11:29:22 --> Hooks Class Initialized
DEBUG - 2022-06-23 11:29:22 --> UTF-8 Support Enabled
INFO - 2022-06-23 11:29:22 --> Utf8 Class Initialized
INFO - 2022-06-23 11:29:22 --> URI Class Initialized
INFO - 2022-06-23 11:29:22 --> Router Class Initialized
INFO - 2022-06-23 11:29:22 --> Output Class Initialized
INFO - 2022-06-23 11:29:22 --> Security Class Initialized
DEBUG - 2022-06-23 11:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 11:29:22 --> Input Class Initialized
INFO - 2022-06-23 11:29:22 --> Language Class Initialized
INFO - 2022-06-23 11:29:22 --> Loader Class Initialized
INFO - 2022-06-23 11:29:22 --> Helper loaded: url_helper
INFO - 2022-06-23 11:29:22 --> Helper loaded: file_helper
INFO - 2022-06-23 11:29:22 --> Database Driver Class Initialized
INFO - 2022-06-23 11:29:22 --> Email Class Initialized
DEBUG - 2022-06-23 11:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 11:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 11:29:22 --> Controller Class Initialized
INFO - 2022-06-23 11:29:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 11:29:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-23 11:29:22 --> Severity: error --> Exception: syntax error, unexpected ')', expecting ';' or ',' C:\wamp64\www\qr\application\views\filldetails\filldetails.php 350
INFO - 2022-06-23 11:30:02 --> Config Class Initialized
INFO - 2022-06-23 11:30:02 --> Hooks Class Initialized
DEBUG - 2022-06-23 11:30:02 --> UTF-8 Support Enabled
INFO - 2022-06-23 11:30:02 --> Utf8 Class Initialized
INFO - 2022-06-23 11:30:02 --> URI Class Initialized
INFO - 2022-06-23 11:30:02 --> Router Class Initialized
INFO - 2022-06-23 11:30:02 --> Output Class Initialized
INFO - 2022-06-23 11:30:02 --> Security Class Initialized
DEBUG - 2022-06-23 11:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 11:30:02 --> Input Class Initialized
INFO - 2022-06-23 11:30:02 --> Language Class Initialized
INFO - 2022-06-23 11:30:02 --> Loader Class Initialized
INFO - 2022-06-23 11:30:02 --> Helper loaded: url_helper
INFO - 2022-06-23 11:30:02 --> Helper loaded: file_helper
INFO - 2022-06-23 11:30:02 --> Database Driver Class Initialized
INFO - 2022-06-23 11:30:02 --> Email Class Initialized
DEBUG - 2022-06-23 11:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 11:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 11:30:02 --> Controller Class Initialized
INFO - 2022-06-23 11:30:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 11:30:02 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 11:30:02 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 11:30:02 --> Final output sent to browser
DEBUG - 2022-06-23 11:30:02 --> Total execution time: 0.0510
INFO - 2022-06-23 11:31:17 --> Config Class Initialized
INFO - 2022-06-23 11:31:17 --> Hooks Class Initialized
DEBUG - 2022-06-23 11:31:17 --> UTF-8 Support Enabled
INFO - 2022-06-23 11:31:17 --> Utf8 Class Initialized
INFO - 2022-06-23 11:31:17 --> URI Class Initialized
INFO - 2022-06-23 11:31:17 --> Router Class Initialized
INFO - 2022-06-23 11:31:17 --> Output Class Initialized
INFO - 2022-06-23 11:31:17 --> Security Class Initialized
DEBUG - 2022-06-23 11:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 11:31:17 --> Input Class Initialized
INFO - 2022-06-23 11:31:17 --> Language Class Initialized
INFO - 2022-06-23 11:31:17 --> Loader Class Initialized
INFO - 2022-06-23 11:31:17 --> Helper loaded: url_helper
INFO - 2022-06-23 11:31:17 --> Helper loaded: file_helper
INFO - 2022-06-23 11:31:17 --> Database Driver Class Initialized
INFO - 2022-06-23 11:31:17 --> Email Class Initialized
DEBUG - 2022-06-23 11:31:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 11:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 11:31:17 --> Controller Class Initialized
INFO - 2022-06-23 11:31:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 11:31:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 11:31:17 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 11:31:17 --> Final output sent to browser
DEBUG - 2022-06-23 11:31:17 --> Total execution time: 0.0228
INFO - 2022-06-23 11:31:30 --> Config Class Initialized
INFO - 2022-06-23 11:31:30 --> Hooks Class Initialized
DEBUG - 2022-06-23 11:31:30 --> UTF-8 Support Enabled
INFO - 2022-06-23 11:31:30 --> Utf8 Class Initialized
INFO - 2022-06-23 11:31:30 --> URI Class Initialized
INFO - 2022-06-23 11:31:30 --> Router Class Initialized
INFO - 2022-06-23 11:31:30 --> Output Class Initialized
INFO - 2022-06-23 11:31:30 --> Security Class Initialized
DEBUG - 2022-06-23 11:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 11:31:30 --> Input Class Initialized
INFO - 2022-06-23 11:31:30 --> Language Class Initialized
INFO - 2022-06-23 11:31:30 --> Loader Class Initialized
INFO - 2022-06-23 11:31:30 --> Helper loaded: url_helper
INFO - 2022-06-23 11:31:30 --> Helper loaded: file_helper
INFO - 2022-06-23 11:31:30 --> Database Driver Class Initialized
INFO - 2022-06-23 11:31:30 --> Email Class Initialized
DEBUG - 2022-06-23 11:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 11:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 11:31:30 --> Controller Class Initialized
INFO - 2022-06-23 11:31:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 11:31:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 11:31:30 --> test
ERROR - 2022-06-23 11:31:30 --> Severity: Notice --> Undefined property: CI_DB_mysqli_driver::$insert_id C:\wamp64\www\qr\application\models\Tokenmodel.php 28
INFO - 2022-06-23 11:31:30 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 11:31:30 --> Final output sent to browser
DEBUG - 2022-06-23 11:31:30 --> Total execution time: 0.0287
INFO - 2022-06-23 11:32:57 --> Config Class Initialized
INFO - 2022-06-23 11:32:57 --> Hooks Class Initialized
DEBUG - 2022-06-23 11:32:57 --> UTF-8 Support Enabled
INFO - 2022-06-23 11:32:57 --> Utf8 Class Initialized
INFO - 2022-06-23 11:32:57 --> URI Class Initialized
INFO - 2022-06-23 11:32:57 --> Router Class Initialized
INFO - 2022-06-23 11:32:57 --> Output Class Initialized
INFO - 2022-06-23 11:32:57 --> Security Class Initialized
DEBUG - 2022-06-23 11:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 11:32:57 --> Input Class Initialized
INFO - 2022-06-23 11:32:57 --> Language Class Initialized
INFO - 2022-06-23 11:32:57 --> Loader Class Initialized
INFO - 2022-06-23 11:32:57 --> Helper loaded: url_helper
INFO - 2022-06-23 11:32:57 --> Helper loaded: file_helper
INFO - 2022-06-23 11:32:57 --> Database Driver Class Initialized
INFO - 2022-06-23 11:32:57 --> Email Class Initialized
DEBUG - 2022-06-23 11:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 11:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 11:32:57 --> Controller Class Initialized
INFO - 2022-06-23 11:32:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 11:32:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 11:32:57 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 11:32:57 --> Final output sent to browser
DEBUG - 2022-06-23 11:32:57 --> Total execution time: 0.3216
INFO - 2022-06-23 11:33:05 --> Config Class Initialized
INFO - 2022-06-23 11:33:05 --> Hooks Class Initialized
DEBUG - 2022-06-23 11:33:05 --> UTF-8 Support Enabled
INFO - 2022-06-23 11:33:05 --> Utf8 Class Initialized
INFO - 2022-06-23 11:33:05 --> URI Class Initialized
INFO - 2022-06-23 11:33:05 --> Router Class Initialized
INFO - 2022-06-23 11:33:05 --> Output Class Initialized
INFO - 2022-06-23 11:33:05 --> Security Class Initialized
DEBUG - 2022-06-23 11:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 11:33:05 --> Input Class Initialized
INFO - 2022-06-23 11:33:05 --> Language Class Initialized
INFO - 2022-06-23 11:33:05 --> Loader Class Initialized
INFO - 2022-06-23 11:33:05 --> Helper loaded: url_helper
INFO - 2022-06-23 11:33:05 --> Helper loaded: file_helper
INFO - 2022-06-23 11:33:05 --> Database Driver Class Initialized
INFO - 2022-06-23 11:33:05 --> Email Class Initialized
DEBUG - 2022-06-23 11:33:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 11:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 11:33:05 --> Controller Class Initialized
INFO - 2022-06-23 11:33:05 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 11:33:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 11:33:05 --> test
INFO - 2022-06-23 11:33:05 --> Final output sent to browser
DEBUG - 2022-06-23 11:33:05 --> Total execution time: 0.0395
INFO - 2022-06-23 11:37:33 --> Config Class Initialized
INFO - 2022-06-23 11:37:33 --> Hooks Class Initialized
DEBUG - 2022-06-23 11:37:33 --> UTF-8 Support Enabled
INFO - 2022-06-23 11:37:33 --> Utf8 Class Initialized
INFO - 2022-06-23 11:37:33 --> URI Class Initialized
INFO - 2022-06-23 11:37:33 --> Router Class Initialized
INFO - 2022-06-23 11:37:33 --> Output Class Initialized
INFO - 2022-06-23 11:37:33 --> Security Class Initialized
DEBUG - 2022-06-23 11:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 11:37:33 --> Input Class Initialized
INFO - 2022-06-23 11:37:33 --> Language Class Initialized
INFO - 2022-06-23 11:37:33 --> Loader Class Initialized
INFO - 2022-06-23 11:37:33 --> Helper loaded: url_helper
INFO - 2022-06-23 11:37:33 --> Helper loaded: file_helper
INFO - 2022-06-23 11:37:33 --> Database Driver Class Initialized
INFO - 2022-06-23 11:37:33 --> Email Class Initialized
DEBUG - 2022-06-23 11:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 11:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 11:37:33 --> Controller Class Initialized
INFO - 2022-06-23 11:37:33 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 11:37:33 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 11:37:33 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 11:37:33 --> Final output sent to browser
DEBUG - 2022-06-23 11:37:33 --> Total execution time: 0.0396
INFO - 2022-06-23 11:37:49 --> Config Class Initialized
INFO - 2022-06-23 11:37:49 --> Hooks Class Initialized
DEBUG - 2022-06-23 11:37:49 --> UTF-8 Support Enabled
INFO - 2022-06-23 11:37:49 --> Utf8 Class Initialized
INFO - 2022-06-23 11:37:49 --> URI Class Initialized
INFO - 2022-06-23 11:37:49 --> Router Class Initialized
INFO - 2022-06-23 11:37:49 --> Output Class Initialized
INFO - 2022-06-23 11:37:49 --> Security Class Initialized
DEBUG - 2022-06-23 11:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 11:37:49 --> Input Class Initialized
INFO - 2022-06-23 11:37:49 --> Language Class Initialized
INFO - 2022-06-23 11:37:49 --> Loader Class Initialized
INFO - 2022-06-23 11:37:49 --> Helper loaded: url_helper
INFO - 2022-06-23 11:37:49 --> Helper loaded: file_helper
INFO - 2022-06-23 11:37:49 --> Database Driver Class Initialized
INFO - 2022-06-23 11:37:49 --> Email Class Initialized
DEBUG - 2022-06-23 11:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 11:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 11:37:49 --> Controller Class Initialized
INFO - 2022-06-23 11:37:49 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 11:37:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 11:37:49 --> test
INFO - 2022-06-23 11:37:49 --> Final output sent to browser
DEBUG - 2022-06-23 11:37:49 --> Total execution time: 0.0323
INFO - 2022-06-23 11:39:20 --> Config Class Initialized
INFO - 2022-06-23 11:39:20 --> Hooks Class Initialized
DEBUG - 2022-06-23 11:39:20 --> UTF-8 Support Enabled
INFO - 2022-06-23 11:39:20 --> Utf8 Class Initialized
INFO - 2022-06-23 11:39:20 --> URI Class Initialized
INFO - 2022-06-23 11:39:20 --> Router Class Initialized
INFO - 2022-06-23 11:39:20 --> Output Class Initialized
INFO - 2022-06-23 11:39:20 --> Security Class Initialized
DEBUG - 2022-06-23 11:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 11:39:20 --> Input Class Initialized
INFO - 2022-06-23 11:39:20 --> Language Class Initialized
INFO - 2022-06-23 11:39:20 --> Loader Class Initialized
INFO - 2022-06-23 11:39:20 --> Helper loaded: url_helper
INFO - 2022-06-23 11:39:20 --> Helper loaded: file_helper
INFO - 2022-06-23 11:39:20 --> Database Driver Class Initialized
INFO - 2022-06-23 11:39:20 --> Email Class Initialized
DEBUG - 2022-06-23 11:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 11:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 11:39:20 --> Controller Class Initialized
INFO - 2022-06-23 11:39:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 11:39:20 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 11:39:20 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 11:39:20 --> Final output sent to browser
DEBUG - 2022-06-23 11:39:20 --> Total execution time: 0.0410
INFO - 2022-06-23 11:39:28 --> Config Class Initialized
INFO - 2022-06-23 11:39:28 --> Hooks Class Initialized
DEBUG - 2022-06-23 11:39:28 --> UTF-8 Support Enabled
INFO - 2022-06-23 11:39:28 --> Utf8 Class Initialized
INFO - 2022-06-23 11:39:28 --> URI Class Initialized
INFO - 2022-06-23 11:39:28 --> Router Class Initialized
INFO - 2022-06-23 11:39:28 --> Output Class Initialized
INFO - 2022-06-23 11:39:28 --> Security Class Initialized
DEBUG - 2022-06-23 11:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 11:39:28 --> Input Class Initialized
INFO - 2022-06-23 11:39:28 --> Language Class Initialized
INFO - 2022-06-23 11:39:28 --> Loader Class Initialized
INFO - 2022-06-23 11:39:28 --> Helper loaded: url_helper
INFO - 2022-06-23 11:39:28 --> Helper loaded: file_helper
INFO - 2022-06-23 11:39:28 --> Database Driver Class Initialized
INFO - 2022-06-23 11:39:28 --> Email Class Initialized
DEBUG - 2022-06-23 11:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 11:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 11:39:28 --> Controller Class Initialized
INFO - 2022-06-23 11:39:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 11:39:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 11:39:28 --> test
INFO - 2022-06-23 11:39:28 --> Final output sent to browser
DEBUG - 2022-06-23 11:39:28 --> Total execution time: 0.0268
INFO - 2022-06-23 11:41:05 --> Config Class Initialized
INFO - 2022-06-23 11:41:05 --> Hooks Class Initialized
DEBUG - 2022-06-23 11:41:05 --> UTF-8 Support Enabled
INFO - 2022-06-23 11:41:05 --> Utf8 Class Initialized
INFO - 2022-06-23 11:41:05 --> URI Class Initialized
INFO - 2022-06-23 11:41:05 --> Router Class Initialized
INFO - 2022-06-23 11:41:05 --> Output Class Initialized
INFO - 2022-06-23 11:41:05 --> Security Class Initialized
DEBUG - 2022-06-23 11:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 11:41:05 --> Input Class Initialized
INFO - 2022-06-23 11:41:05 --> Language Class Initialized
INFO - 2022-06-23 11:41:05 --> Loader Class Initialized
INFO - 2022-06-23 11:41:05 --> Helper loaded: url_helper
INFO - 2022-06-23 11:41:05 --> Helper loaded: file_helper
INFO - 2022-06-23 11:41:05 --> Database Driver Class Initialized
INFO - 2022-06-23 11:41:05 --> Email Class Initialized
DEBUG - 2022-06-23 11:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 11:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 11:41:05 --> Controller Class Initialized
INFO - 2022-06-23 11:41:05 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 11:41:05 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 11:41:05 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 11:41:05 --> Final output sent to browser
DEBUG - 2022-06-23 11:41:05 --> Total execution time: 0.0396
INFO - 2022-06-23 11:41:12 --> Config Class Initialized
INFO - 2022-06-23 11:41:12 --> Hooks Class Initialized
DEBUG - 2022-06-23 11:41:12 --> UTF-8 Support Enabled
INFO - 2022-06-23 11:41:12 --> Utf8 Class Initialized
INFO - 2022-06-23 11:41:12 --> URI Class Initialized
INFO - 2022-06-23 11:41:12 --> Router Class Initialized
INFO - 2022-06-23 11:41:12 --> Output Class Initialized
INFO - 2022-06-23 11:41:12 --> Security Class Initialized
DEBUG - 2022-06-23 11:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 11:41:12 --> Input Class Initialized
INFO - 2022-06-23 11:41:12 --> Language Class Initialized
INFO - 2022-06-23 11:41:12 --> Loader Class Initialized
INFO - 2022-06-23 11:41:12 --> Helper loaded: url_helper
INFO - 2022-06-23 11:41:12 --> Helper loaded: file_helper
INFO - 2022-06-23 11:41:12 --> Database Driver Class Initialized
INFO - 2022-06-23 11:41:12 --> Email Class Initialized
DEBUG - 2022-06-23 11:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 11:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 11:41:12 --> Controller Class Initialized
INFO - 2022-06-23 11:41:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 11:41:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 11:41:12 --> test
INFO - 2022-06-23 11:41:12 --> Final output sent to browser
DEBUG - 2022-06-23 11:41:12 --> Total execution time: 0.0273
INFO - 2022-06-23 11:41:12 --> Config Class Initialized
INFO - 2022-06-23 11:41:12 --> Hooks Class Initialized
DEBUG - 2022-06-23 11:41:12 --> UTF-8 Support Enabled
INFO - 2022-06-23 11:41:12 --> Utf8 Class Initialized
INFO - 2022-06-23 11:41:12 --> URI Class Initialized
INFO - 2022-06-23 11:41:12 --> Router Class Initialized
INFO - 2022-06-23 11:41:13 --> Output Class Initialized
INFO - 2022-06-23 11:41:13 --> Security Class Initialized
DEBUG - 2022-06-23 11:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 11:41:13 --> Input Class Initialized
INFO - 2022-06-23 11:41:13 --> Language Class Initialized
ERROR - 2022-06-23 11:41:13 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-23 11:42:13 --> Config Class Initialized
INFO - 2022-06-23 11:42:13 --> Hooks Class Initialized
DEBUG - 2022-06-23 11:42:13 --> UTF-8 Support Enabled
INFO - 2022-06-23 11:42:13 --> Utf8 Class Initialized
INFO - 2022-06-23 11:42:13 --> URI Class Initialized
INFO - 2022-06-23 11:42:13 --> Router Class Initialized
INFO - 2022-06-23 11:42:13 --> Output Class Initialized
INFO - 2022-06-23 11:42:13 --> Security Class Initialized
DEBUG - 2022-06-23 11:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 11:42:13 --> Input Class Initialized
INFO - 2022-06-23 11:42:13 --> Language Class Initialized
ERROR - 2022-06-23 11:42:13 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-23 11:42:16 --> Config Class Initialized
INFO - 2022-06-23 11:42:16 --> Hooks Class Initialized
DEBUG - 2022-06-23 11:42:16 --> UTF-8 Support Enabled
INFO - 2022-06-23 11:42:16 --> Utf8 Class Initialized
INFO - 2022-06-23 11:42:16 --> URI Class Initialized
INFO - 2022-06-23 11:42:16 --> Router Class Initialized
INFO - 2022-06-23 11:42:16 --> Output Class Initialized
INFO - 2022-06-23 11:42:16 --> Security Class Initialized
DEBUG - 2022-06-23 11:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 11:42:16 --> Input Class Initialized
INFO - 2022-06-23 11:42:16 --> Language Class Initialized
INFO - 2022-06-23 11:42:16 --> Loader Class Initialized
INFO - 2022-06-23 11:42:16 --> Helper loaded: url_helper
INFO - 2022-06-23 11:42:16 --> Helper loaded: file_helper
INFO - 2022-06-23 11:42:16 --> Database Driver Class Initialized
INFO - 2022-06-23 11:42:16 --> Email Class Initialized
DEBUG - 2022-06-23 11:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 11:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 11:42:16 --> Controller Class Initialized
INFO - 2022-06-23 11:42:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 11:42:16 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 11:42:16 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 11:42:16 --> Final output sent to browser
DEBUG - 2022-06-23 11:42:16 --> Total execution time: 0.0325
INFO - 2022-06-23 11:42:18 --> Config Class Initialized
INFO - 2022-06-23 11:42:18 --> Hooks Class Initialized
DEBUG - 2022-06-23 11:42:18 --> UTF-8 Support Enabled
INFO - 2022-06-23 11:42:18 --> Utf8 Class Initialized
INFO - 2022-06-23 11:42:18 --> URI Class Initialized
INFO - 2022-06-23 11:42:18 --> Router Class Initialized
INFO - 2022-06-23 11:42:18 --> Output Class Initialized
INFO - 2022-06-23 11:42:18 --> Security Class Initialized
DEBUG - 2022-06-23 11:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 11:42:18 --> Input Class Initialized
INFO - 2022-06-23 11:42:18 --> Language Class Initialized
INFO - 2022-06-23 11:42:18 --> Loader Class Initialized
INFO - 2022-06-23 11:42:18 --> Helper loaded: url_helper
INFO - 2022-06-23 11:42:18 --> Helper loaded: file_helper
INFO - 2022-06-23 11:42:18 --> Database Driver Class Initialized
INFO - 2022-06-23 11:42:18 --> Email Class Initialized
DEBUG - 2022-06-23 11:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 11:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 11:42:18 --> Controller Class Initialized
INFO - 2022-06-23 11:42:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 11:42:18 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 11:42:18 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 11:42:18 --> Final output sent to browser
DEBUG - 2022-06-23 11:42:18 --> Total execution time: 0.0219
INFO - 2022-06-23 11:42:25 --> Config Class Initialized
INFO - 2022-06-23 11:42:25 --> Hooks Class Initialized
DEBUG - 2022-06-23 11:42:25 --> UTF-8 Support Enabled
INFO - 2022-06-23 11:42:25 --> Utf8 Class Initialized
INFO - 2022-06-23 11:42:25 --> URI Class Initialized
INFO - 2022-06-23 11:42:25 --> Router Class Initialized
INFO - 2022-06-23 11:42:25 --> Output Class Initialized
INFO - 2022-06-23 11:42:25 --> Security Class Initialized
DEBUG - 2022-06-23 11:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 11:42:25 --> Input Class Initialized
INFO - 2022-06-23 11:42:25 --> Language Class Initialized
INFO - 2022-06-23 11:42:25 --> Loader Class Initialized
INFO - 2022-06-23 11:42:25 --> Helper loaded: url_helper
INFO - 2022-06-23 11:42:25 --> Helper loaded: file_helper
INFO - 2022-06-23 11:42:25 --> Database Driver Class Initialized
INFO - 2022-06-23 11:42:25 --> Email Class Initialized
DEBUG - 2022-06-23 11:42:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 11:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 11:42:25 --> Controller Class Initialized
INFO - 2022-06-23 11:42:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 11:42:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 11:42:25 --> test
INFO - 2022-06-23 11:42:25 --> Final output sent to browser
DEBUG - 2022-06-23 11:42:25 --> Total execution time: 0.0277
INFO - 2022-06-23 11:42:25 --> Config Class Initialized
INFO - 2022-06-23 11:42:25 --> Hooks Class Initialized
DEBUG - 2022-06-23 11:42:25 --> UTF-8 Support Enabled
INFO - 2022-06-23 11:42:25 --> Utf8 Class Initialized
INFO - 2022-06-23 11:42:25 --> URI Class Initialized
INFO - 2022-06-23 11:42:25 --> Router Class Initialized
INFO - 2022-06-23 11:42:25 --> Output Class Initialized
INFO - 2022-06-23 11:42:25 --> Security Class Initialized
DEBUG - 2022-06-23 11:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 11:42:25 --> Input Class Initialized
INFO - 2022-06-23 11:42:25 --> Language Class Initialized
ERROR - 2022-06-23 11:42:25 --> 404 Page Not Found: Tokenctrl/Tokenctrl
INFO - 2022-06-23 11:42:53 --> Config Class Initialized
INFO - 2022-06-23 11:42:53 --> Hooks Class Initialized
DEBUG - 2022-06-23 11:42:53 --> UTF-8 Support Enabled
INFO - 2022-06-23 11:42:53 --> Utf8 Class Initialized
INFO - 2022-06-23 11:42:53 --> URI Class Initialized
INFO - 2022-06-23 11:42:53 --> Router Class Initialized
INFO - 2022-06-23 11:42:53 --> Output Class Initialized
INFO - 2022-06-23 11:42:53 --> Security Class Initialized
DEBUG - 2022-06-23 11:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 11:42:53 --> Input Class Initialized
INFO - 2022-06-23 11:42:53 --> Language Class Initialized
ERROR - 2022-06-23 11:42:53 --> 404 Page Not Found: Tokenctrl/Tokenctrl
INFO - 2022-06-23 11:42:55 --> Config Class Initialized
INFO - 2022-06-23 11:42:55 --> Hooks Class Initialized
DEBUG - 2022-06-23 11:42:55 --> UTF-8 Support Enabled
INFO - 2022-06-23 11:42:55 --> Utf8 Class Initialized
INFO - 2022-06-23 11:42:55 --> URI Class Initialized
INFO - 2022-06-23 11:42:55 --> Router Class Initialized
INFO - 2022-06-23 11:42:55 --> Output Class Initialized
INFO - 2022-06-23 11:42:55 --> Security Class Initialized
DEBUG - 2022-06-23 11:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 11:42:55 --> Input Class Initialized
INFO - 2022-06-23 11:42:55 --> Language Class Initialized
INFO - 2022-06-23 11:42:55 --> Loader Class Initialized
INFO - 2022-06-23 11:42:55 --> Helper loaded: url_helper
INFO - 2022-06-23 11:42:55 --> Helper loaded: file_helper
INFO - 2022-06-23 11:42:55 --> Database Driver Class Initialized
INFO - 2022-06-23 11:42:55 --> Email Class Initialized
DEBUG - 2022-06-23 11:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 11:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 11:42:55 --> Controller Class Initialized
INFO - 2022-06-23 11:42:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 11:42:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 11:42:55 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 11:42:55 --> Final output sent to browser
DEBUG - 2022-06-23 11:42:55 --> Total execution time: 0.0396
INFO - 2022-06-23 11:42:58 --> Config Class Initialized
INFO - 2022-06-23 11:42:58 --> Hooks Class Initialized
DEBUG - 2022-06-23 11:42:58 --> UTF-8 Support Enabled
INFO - 2022-06-23 11:42:58 --> Utf8 Class Initialized
INFO - 2022-06-23 11:42:58 --> URI Class Initialized
INFO - 2022-06-23 11:42:58 --> Router Class Initialized
INFO - 2022-06-23 11:42:58 --> Output Class Initialized
INFO - 2022-06-23 11:42:58 --> Security Class Initialized
DEBUG - 2022-06-23 11:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 11:42:58 --> Input Class Initialized
INFO - 2022-06-23 11:42:58 --> Language Class Initialized
INFO - 2022-06-23 11:42:58 --> Loader Class Initialized
INFO - 2022-06-23 11:42:58 --> Helper loaded: url_helper
INFO - 2022-06-23 11:42:58 --> Helper loaded: file_helper
INFO - 2022-06-23 11:42:58 --> Database Driver Class Initialized
INFO - 2022-06-23 11:42:58 --> Email Class Initialized
DEBUG - 2022-06-23 11:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 11:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 11:42:58 --> Controller Class Initialized
INFO - 2022-06-23 11:42:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 11:42:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 11:42:58 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 11:42:58 --> Final output sent to browser
DEBUG - 2022-06-23 11:42:58 --> Total execution time: 0.0198
INFO - 2022-06-23 11:43:05 --> Config Class Initialized
INFO - 2022-06-23 11:43:05 --> Hooks Class Initialized
DEBUG - 2022-06-23 11:43:05 --> UTF-8 Support Enabled
INFO - 2022-06-23 11:43:05 --> Utf8 Class Initialized
INFO - 2022-06-23 11:43:05 --> URI Class Initialized
INFO - 2022-06-23 11:43:05 --> Router Class Initialized
INFO - 2022-06-23 11:43:05 --> Output Class Initialized
INFO - 2022-06-23 11:43:05 --> Security Class Initialized
DEBUG - 2022-06-23 11:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 11:43:05 --> Input Class Initialized
INFO - 2022-06-23 11:43:05 --> Language Class Initialized
INFO - 2022-06-23 11:43:05 --> Loader Class Initialized
INFO - 2022-06-23 11:43:05 --> Helper loaded: url_helper
INFO - 2022-06-23 11:43:05 --> Helper loaded: file_helper
INFO - 2022-06-23 11:43:05 --> Database Driver Class Initialized
INFO - 2022-06-23 11:43:05 --> Email Class Initialized
DEBUG - 2022-06-23 11:43:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 11:43:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 11:43:05 --> Controller Class Initialized
INFO - 2022-06-23 11:43:05 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 11:43:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 11:43:05 --> test
INFO - 2022-06-23 11:43:05 --> Final output sent to browser
DEBUG - 2022-06-23 11:43:05 --> Total execution time: 0.0274
INFO - 2022-06-23 11:43:05 --> Config Class Initialized
INFO - 2022-06-23 11:43:05 --> Hooks Class Initialized
DEBUG - 2022-06-23 11:43:05 --> UTF-8 Support Enabled
INFO - 2022-06-23 11:43:05 --> Utf8 Class Initialized
INFO - 2022-06-23 11:43:05 --> URI Class Initialized
INFO - 2022-06-23 11:43:05 --> Router Class Initialized
INFO - 2022-06-23 11:43:05 --> Output Class Initialized
INFO - 2022-06-23 11:43:05 --> Security Class Initialized
DEBUG - 2022-06-23 11:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 11:43:05 --> Input Class Initialized
INFO - 2022-06-23 11:43:05 --> Language Class Initialized
INFO - 2022-06-23 11:43:05 --> Loader Class Initialized
INFO - 2022-06-23 11:43:05 --> Helper loaded: url_helper
INFO - 2022-06-23 11:43:05 --> Helper loaded: file_helper
INFO - 2022-06-23 11:43:05 --> Database Driver Class Initialized
INFO - 2022-06-23 11:43:05 --> Email Class Initialized
DEBUG - 2022-06-23 11:43:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 11:43:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 11:43:05 --> Controller Class Initialized
INFO - 2022-06-23 11:43:05 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 11:43:05 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 11:43:05 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 11:43:05 --> Final output sent to browser
DEBUG - 2022-06-23 11:43:05 --> Total execution time: 0.0188
INFO - 2022-06-23 12:20:18 --> Config Class Initialized
INFO - 2022-06-23 12:20:18 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:20:18 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:20:18 --> Utf8 Class Initialized
INFO - 2022-06-23 12:20:18 --> URI Class Initialized
INFO - 2022-06-23 12:20:18 --> Router Class Initialized
INFO - 2022-06-23 12:20:18 --> Output Class Initialized
INFO - 2022-06-23 12:20:18 --> Security Class Initialized
DEBUG - 2022-06-23 12:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:20:18 --> Input Class Initialized
INFO - 2022-06-23 12:20:18 --> Language Class Initialized
INFO - 2022-06-23 12:20:18 --> Loader Class Initialized
INFO - 2022-06-23 12:20:18 --> Helper loaded: url_helper
INFO - 2022-06-23 12:20:18 --> Helper loaded: file_helper
INFO - 2022-06-23 12:20:18 --> Database Driver Class Initialized
INFO - 2022-06-23 12:20:18 --> Email Class Initialized
DEBUG - 2022-06-23 12:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:20:18 --> Controller Class Initialized
INFO - 2022-06-23 12:20:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:20:18 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:20:18 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 12:20:18 --> Final output sent to browser
DEBUG - 2022-06-23 12:20:18 --> Total execution time: 0.1096
INFO - 2022-06-23 12:20:51 --> Config Class Initialized
INFO - 2022-06-23 12:20:51 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:20:51 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:20:51 --> Utf8 Class Initialized
INFO - 2022-06-23 12:20:51 --> URI Class Initialized
INFO - 2022-06-23 12:20:51 --> Router Class Initialized
INFO - 2022-06-23 12:20:51 --> Output Class Initialized
INFO - 2022-06-23 12:20:51 --> Security Class Initialized
DEBUG - 2022-06-23 12:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:20:51 --> Input Class Initialized
INFO - 2022-06-23 12:20:51 --> Language Class Initialized
INFO - 2022-06-23 12:20:51 --> Loader Class Initialized
INFO - 2022-06-23 12:20:51 --> Helper loaded: url_helper
INFO - 2022-06-23 12:20:51 --> Helper loaded: file_helper
INFO - 2022-06-23 12:20:51 --> Database Driver Class Initialized
INFO - 2022-06-23 12:20:51 --> Email Class Initialized
DEBUG - 2022-06-23 12:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:20:51 --> Controller Class Initialized
INFO - 2022-06-23 12:20:51 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:20:51 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:20:51 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 12:20:51 --> Final output sent to browser
DEBUG - 2022-06-23 12:20:51 --> Total execution time: 0.0217
INFO - 2022-06-23 12:20:55 --> Config Class Initialized
INFO - 2022-06-23 12:20:55 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:20:55 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:20:55 --> Utf8 Class Initialized
INFO - 2022-06-23 12:20:55 --> URI Class Initialized
INFO - 2022-06-23 12:20:55 --> Router Class Initialized
INFO - 2022-06-23 12:20:55 --> Output Class Initialized
INFO - 2022-06-23 12:20:55 --> Security Class Initialized
DEBUG - 2022-06-23 12:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:20:55 --> Input Class Initialized
INFO - 2022-06-23 12:20:55 --> Language Class Initialized
INFO - 2022-06-23 12:20:55 --> Loader Class Initialized
INFO - 2022-06-23 12:20:55 --> Helper loaded: url_helper
INFO - 2022-06-23 12:20:55 --> Helper loaded: file_helper
INFO - 2022-06-23 12:20:55 --> Database Driver Class Initialized
INFO - 2022-06-23 12:20:55 --> Email Class Initialized
DEBUG - 2022-06-23 12:20:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:20:55 --> Controller Class Initialized
INFO - 2022-06-23 12:20:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:20:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:20:55 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 12:20:55 --> Final output sent to browser
DEBUG - 2022-06-23 12:20:55 --> Total execution time: 0.0233
INFO - 2022-06-23 12:20:56 --> Config Class Initialized
INFO - 2022-06-23 12:20:56 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:20:56 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:20:56 --> Utf8 Class Initialized
INFO - 2022-06-23 12:20:56 --> URI Class Initialized
INFO - 2022-06-23 12:20:56 --> Router Class Initialized
INFO - 2022-06-23 12:20:56 --> Output Class Initialized
INFO - 2022-06-23 12:20:56 --> Security Class Initialized
DEBUG - 2022-06-23 12:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:20:56 --> Input Class Initialized
INFO - 2022-06-23 12:20:56 --> Language Class Initialized
INFO - 2022-06-23 12:20:56 --> Loader Class Initialized
INFO - 2022-06-23 12:20:56 --> Helper loaded: url_helper
INFO - 2022-06-23 12:20:56 --> Helper loaded: file_helper
INFO - 2022-06-23 12:20:56 --> Database Driver Class Initialized
INFO - 2022-06-23 12:20:56 --> Email Class Initialized
DEBUG - 2022-06-23 12:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:20:56 --> Controller Class Initialized
INFO - 2022-06-23 12:20:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:20:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:20:56 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 12:20:56 --> Final output sent to browser
DEBUG - 2022-06-23 12:20:56 --> Total execution time: 0.0175
INFO - 2022-06-23 12:20:57 --> Config Class Initialized
INFO - 2022-06-23 12:20:57 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:20:57 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:20:57 --> Utf8 Class Initialized
INFO - 2022-06-23 12:20:57 --> URI Class Initialized
INFO - 2022-06-23 12:20:57 --> Router Class Initialized
INFO - 2022-06-23 12:20:57 --> Output Class Initialized
INFO - 2022-06-23 12:20:57 --> Security Class Initialized
DEBUG - 2022-06-23 12:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:20:57 --> Input Class Initialized
INFO - 2022-06-23 12:20:57 --> Language Class Initialized
INFO - 2022-06-23 12:20:57 --> Loader Class Initialized
INFO - 2022-06-23 12:20:57 --> Helper loaded: url_helper
INFO - 2022-06-23 12:20:57 --> Helper loaded: file_helper
INFO - 2022-06-23 12:20:57 --> Database Driver Class Initialized
INFO - 2022-06-23 12:20:57 --> Email Class Initialized
DEBUG - 2022-06-23 12:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:20:57 --> Controller Class Initialized
INFO - 2022-06-23 12:20:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:20:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:20:57 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 12:20:57 --> Final output sent to browser
DEBUG - 2022-06-23 12:20:57 --> Total execution time: 0.0459
INFO - 2022-06-23 12:20:57 --> Config Class Initialized
INFO - 2022-06-23 12:20:57 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:20:57 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:20:57 --> Utf8 Class Initialized
INFO - 2022-06-23 12:20:57 --> URI Class Initialized
INFO - 2022-06-23 12:20:57 --> Router Class Initialized
INFO - 2022-06-23 12:20:57 --> Output Class Initialized
INFO - 2022-06-23 12:20:57 --> Security Class Initialized
DEBUG - 2022-06-23 12:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:20:57 --> Input Class Initialized
INFO - 2022-06-23 12:20:57 --> Language Class Initialized
INFO - 2022-06-23 12:20:57 --> Loader Class Initialized
INFO - 2022-06-23 12:20:57 --> Helper loaded: url_helper
INFO - 2022-06-23 12:20:57 --> Helper loaded: file_helper
INFO - 2022-06-23 12:20:57 --> Database Driver Class Initialized
INFO - 2022-06-23 12:20:57 --> Email Class Initialized
DEBUG - 2022-06-23 12:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:20:57 --> Controller Class Initialized
INFO - 2022-06-23 12:20:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:20:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:20:57 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 12:20:57 --> Final output sent to browser
DEBUG - 2022-06-23 12:20:57 --> Total execution time: 0.0255
INFO - 2022-06-23 12:20:58 --> Config Class Initialized
INFO - 2022-06-23 12:20:58 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:20:58 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:20:58 --> Utf8 Class Initialized
INFO - 2022-06-23 12:20:58 --> URI Class Initialized
INFO - 2022-06-23 12:20:58 --> Router Class Initialized
INFO - 2022-06-23 12:20:58 --> Output Class Initialized
INFO - 2022-06-23 12:20:58 --> Security Class Initialized
DEBUG - 2022-06-23 12:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:20:58 --> Input Class Initialized
INFO - 2022-06-23 12:20:58 --> Language Class Initialized
INFO - 2022-06-23 12:20:58 --> Loader Class Initialized
INFO - 2022-06-23 12:20:58 --> Helper loaded: url_helper
INFO - 2022-06-23 12:20:58 --> Helper loaded: file_helper
INFO - 2022-06-23 12:20:58 --> Database Driver Class Initialized
INFO - 2022-06-23 12:20:58 --> Email Class Initialized
DEBUG - 2022-06-23 12:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:20:58 --> Controller Class Initialized
INFO - 2022-06-23 12:20:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:20:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:20:58 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 12:20:58 --> Final output sent to browser
DEBUG - 2022-06-23 12:20:58 --> Total execution time: 0.0414
INFO - 2022-06-23 12:20:58 --> Config Class Initialized
INFO - 2022-06-23 12:20:58 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:20:58 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:20:58 --> Utf8 Class Initialized
INFO - 2022-06-23 12:20:58 --> URI Class Initialized
INFO - 2022-06-23 12:20:58 --> Router Class Initialized
INFO - 2022-06-23 12:20:58 --> Output Class Initialized
INFO - 2022-06-23 12:20:58 --> Security Class Initialized
DEBUG - 2022-06-23 12:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:20:58 --> Input Class Initialized
INFO - 2022-06-23 12:20:58 --> Language Class Initialized
INFO - 2022-06-23 12:20:58 --> Loader Class Initialized
INFO - 2022-06-23 12:20:58 --> Helper loaded: url_helper
INFO - 2022-06-23 12:20:58 --> Helper loaded: file_helper
INFO - 2022-06-23 12:20:58 --> Database Driver Class Initialized
INFO - 2022-06-23 12:20:58 --> Email Class Initialized
DEBUG - 2022-06-23 12:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:20:58 --> Controller Class Initialized
INFO - 2022-06-23 12:20:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:20:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:20:58 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 12:20:58 --> Final output sent to browser
DEBUG - 2022-06-23 12:20:58 --> Total execution time: 0.1464
INFO - 2022-06-23 12:20:59 --> Config Class Initialized
INFO - 2022-06-23 12:20:59 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:20:59 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:20:59 --> Utf8 Class Initialized
INFO - 2022-06-23 12:20:59 --> URI Class Initialized
INFO - 2022-06-23 12:20:59 --> Router Class Initialized
INFO - 2022-06-23 12:20:59 --> Output Class Initialized
INFO - 2022-06-23 12:20:59 --> Security Class Initialized
DEBUG - 2022-06-23 12:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:20:59 --> Input Class Initialized
INFO - 2022-06-23 12:20:59 --> Language Class Initialized
INFO - 2022-06-23 12:20:59 --> Loader Class Initialized
INFO - 2022-06-23 12:20:59 --> Helper loaded: url_helper
INFO - 2022-06-23 12:20:59 --> Helper loaded: file_helper
INFO - 2022-06-23 12:20:59 --> Database Driver Class Initialized
INFO - 2022-06-23 12:20:59 --> Email Class Initialized
DEBUG - 2022-06-23 12:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:20:59 --> Controller Class Initialized
INFO - 2022-06-23 12:20:59 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:20:59 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:20:59 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 12:20:59 --> Final output sent to browser
DEBUG - 2022-06-23 12:20:59 --> Total execution time: 0.0262
INFO - 2022-06-23 12:20:59 --> Config Class Initialized
INFO - 2022-06-23 12:20:59 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:20:59 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:20:59 --> Utf8 Class Initialized
INFO - 2022-06-23 12:20:59 --> URI Class Initialized
INFO - 2022-06-23 12:20:59 --> Router Class Initialized
INFO - 2022-06-23 12:20:59 --> Output Class Initialized
INFO - 2022-06-23 12:20:59 --> Security Class Initialized
DEBUG - 2022-06-23 12:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:20:59 --> Input Class Initialized
INFO - 2022-06-23 12:20:59 --> Language Class Initialized
INFO - 2022-06-23 12:20:59 --> Loader Class Initialized
INFO - 2022-06-23 12:20:59 --> Helper loaded: url_helper
INFO - 2022-06-23 12:20:59 --> Helper loaded: file_helper
INFO - 2022-06-23 12:20:59 --> Database Driver Class Initialized
INFO - 2022-06-23 12:20:59 --> Email Class Initialized
DEBUG - 2022-06-23 12:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:20:59 --> Controller Class Initialized
INFO - 2022-06-23 12:20:59 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:20:59 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:20:59 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 12:20:59 --> Final output sent to browser
DEBUG - 2022-06-23 12:20:59 --> Total execution time: 0.0244
INFO - 2022-06-23 12:20:59 --> Config Class Initialized
INFO - 2022-06-23 12:20:59 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:20:59 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:20:59 --> Utf8 Class Initialized
INFO - 2022-06-23 12:20:59 --> URI Class Initialized
INFO - 2022-06-23 12:20:59 --> Router Class Initialized
INFO - 2022-06-23 12:20:59 --> Output Class Initialized
INFO - 2022-06-23 12:20:59 --> Security Class Initialized
DEBUG - 2022-06-23 12:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:20:59 --> Input Class Initialized
INFO - 2022-06-23 12:20:59 --> Language Class Initialized
INFO - 2022-06-23 12:20:59 --> Loader Class Initialized
INFO - 2022-06-23 12:20:59 --> Helper loaded: url_helper
INFO - 2022-06-23 12:20:59 --> Helper loaded: file_helper
INFO - 2022-06-23 12:20:59 --> Database Driver Class Initialized
INFO - 2022-06-23 12:20:59 --> Email Class Initialized
DEBUG - 2022-06-23 12:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:20:59 --> Controller Class Initialized
INFO - 2022-06-23 12:20:59 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:20:59 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:20:59 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 12:20:59 --> Final output sent to browser
DEBUG - 2022-06-23 12:20:59 --> Total execution time: 0.0281
INFO - 2022-06-23 12:20:59 --> Config Class Initialized
INFO - 2022-06-23 12:20:59 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:20:59 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:20:59 --> Utf8 Class Initialized
INFO - 2022-06-23 12:20:59 --> URI Class Initialized
INFO - 2022-06-23 12:20:59 --> Router Class Initialized
INFO - 2022-06-23 12:20:59 --> Output Class Initialized
INFO - 2022-06-23 12:20:59 --> Security Class Initialized
DEBUG - 2022-06-23 12:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:20:59 --> Input Class Initialized
INFO - 2022-06-23 12:20:59 --> Language Class Initialized
INFO - 2022-06-23 12:20:59 --> Loader Class Initialized
INFO - 2022-06-23 12:20:59 --> Helper loaded: url_helper
INFO - 2022-06-23 12:20:59 --> Helper loaded: file_helper
INFO - 2022-06-23 12:20:59 --> Database Driver Class Initialized
INFO - 2022-06-23 12:20:59 --> Email Class Initialized
DEBUG - 2022-06-23 12:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:20:59 --> Controller Class Initialized
INFO - 2022-06-23 12:20:59 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:20:59 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:20:59 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 12:20:59 --> Final output sent to browser
DEBUG - 2022-06-23 12:20:59 --> Total execution time: 0.0291
INFO - 2022-06-23 12:21:00 --> Config Class Initialized
INFO - 2022-06-23 12:21:00 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:21:00 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:21:00 --> Utf8 Class Initialized
INFO - 2022-06-23 12:21:00 --> URI Class Initialized
INFO - 2022-06-23 12:21:00 --> Router Class Initialized
INFO - 2022-06-23 12:21:00 --> Output Class Initialized
INFO - 2022-06-23 12:21:00 --> Security Class Initialized
DEBUG - 2022-06-23 12:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:21:00 --> Input Class Initialized
INFO - 2022-06-23 12:21:00 --> Language Class Initialized
INFO - 2022-06-23 12:21:00 --> Loader Class Initialized
INFO - 2022-06-23 12:21:00 --> Helper loaded: url_helper
INFO - 2022-06-23 12:21:00 --> Helper loaded: file_helper
INFO - 2022-06-23 12:21:00 --> Database Driver Class Initialized
INFO - 2022-06-23 12:21:00 --> Email Class Initialized
DEBUG - 2022-06-23 12:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:21:00 --> Controller Class Initialized
INFO - 2022-06-23 12:21:00 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:21:00 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:21:00 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 12:21:00 --> Final output sent to browser
DEBUG - 2022-06-23 12:21:00 --> Total execution time: 0.0224
INFO - 2022-06-23 12:21:00 --> Config Class Initialized
INFO - 2022-06-23 12:21:00 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:21:00 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:21:00 --> Utf8 Class Initialized
INFO - 2022-06-23 12:21:00 --> URI Class Initialized
INFO - 2022-06-23 12:21:00 --> Router Class Initialized
INFO - 2022-06-23 12:21:00 --> Output Class Initialized
INFO - 2022-06-23 12:21:00 --> Security Class Initialized
DEBUG - 2022-06-23 12:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:21:00 --> Input Class Initialized
INFO - 2022-06-23 12:21:00 --> Language Class Initialized
INFO - 2022-06-23 12:21:00 --> Loader Class Initialized
INFO - 2022-06-23 12:21:00 --> Helper loaded: url_helper
INFO - 2022-06-23 12:21:00 --> Helper loaded: file_helper
INFO - 2022-06-23 12:21:00 --> Database Driver Class Initialized
INFO - 2022-06-23 12:21:00 --> Email Class Initialized
DEBUG - 2022-06-23 12:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:21:00 --> Controller Class Initialized
INFO - 2022-06-23 12:21:00 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:21:00 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:21:00 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-23 12:21:00 --> Final output sent to browser
DEBUG - 2022-06-23 12:21:00 --> Total execution time: 0.0214
INFO - 2022-06-23 12:21:00 --> Config Class Initialized
INFO - 2022-06-23 12:21:00 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:21:00 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:21:00 --> Utf8 Class Initialized
INFO - 2022-06-23 12:21:00 --> URI Class Initialized
INFO - 2022-06-23 12:21:00 --> Router Class Initialized
INFO - 2022-06-23 12:21:00 --> Output Class Initialized
INFO - 2022-06-23 12:21:00 --> Security Class Initialized
DEBUG - 2022-06-23 12:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:21:00 --> Input Class Initialized
INFO - 2022-06-23 12:21:00 --> Language Class Initialized
INFO - 2022-06-23 12:21:00 --> Loader Class Initialized
INFO - 2022-06-23 12:21:00 --> Helper loaded: url_helper
INFO - 2022-06-23 12:21:00 --> Helper loaded: file_helper
INFO - 2022-06-23 12:21:00 --> Database Driver Class Initialized
INFO - 2022-06-23 12:21:00 --> Email Class Initialized
DEBUG - 2022-06-23 12:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:21:00 --> Controller Class Initialized
INFO - 2022-06-23 12:21:00 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:21:00 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:21:00 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 12:21:00 --> Final output sent to browser
DEBUG - 2022-06-23 12:21:00 --> Total execution time: 0.0231
INFO - 2022-06-23 12:22:38 --> Config Class Initialized
INFO - 2022-06-23 12:22:38 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:22:38 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:22:38 --> Utf8 Class Initialized
INFO - 2022-06-23 12:22:38 --> URI Class Initialized
INFO - 2022-06-23 12:22:38 --> Router Class Initialized
INFO - 2022-06-23 12:22:38 --> Output Class Initialized
INFO - 2022-06-23 12:22:38 --> Security Class Initialized
DEBUG - 2022-06-23 12:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:22:38 --> Input Class Initialized
INFO - 2022-06-23 12:22:38 --> Language Class Initialized
INFO - 2022-06-23 12:22:38 --> Loader Class Initialized
INFO - 2022-06-23 12:22:38 --> Helper loaded: url_helper
INFO - 2022-06-23 12:22:38 --> Helper loaded: file_helper
INFO - 2022-06-23 12:22:38 --> Database Driver Class Initialized
INFO - 2022-06-23 12:22:38 --> Email Class Initialized
DEBUG - 2022-06-23 12:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:22:38 --> Controller Class Initialized
INFO - 2022-06-23 12:22:38 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:22:38 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:22:38 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 12:22:38 --> Final output sent to browser
DEBUG - 2022-06-23 12:22:38 --> Total execution time: 0.0216
INFO - 2022-06-23 12:22:46 --> Config Class Initialized
INFO - 2022-06-23 12:22:46 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:22:46 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:22:46 --> Utf8 Class Initialized
INFO - 2022-06-23 12:22:46 --> URI Class Initialized
INFO - 2022-06-23 12:22:46 --> Router Class Initialized
INFO - 2022-06-23 12:22:46 --> Output Class Initialized
INFO - 2022-06-23 12:22:46 --> Security Class Initialized
DEBUG - 2022-06-23 12:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:22:46 --> Input Class Initialized
INFO - 2022-06-23 12:22:46 --> Language Class Initialized
INFO - 2022-06-23 12:22:46 --> Loader Class Initialized
INFO - 2022-06-23 12:22:46 --> Helper loaded: url_helper
INFO - 2022-06-23 12:22:46 --> Helper loaded: file_helper
INFO - 2022-06-23 12:22:46 --> Database Driver Class Initialized
INFO - 2022-06-23 12:22:46 --> Email Class Initialized
DEBUG - 2022-06-23 12:22:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:22:46 --> Controller Class Initialized
INFO - 2022-06-23 12:22:46 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:22:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 12:22:46 --> test
INFO - 2022-06-23 12:22:46 --> Final output sent to browser
DEBUG - 2022-06-23 12:22:46 --> Total execution time: 0.0178
INFO - 2022-06-23 12:22:46 --> Config Class Initialized
INFO - 2022-06-23 12:22:46 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:22:46 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:22:46 --> Utf8 Class Initialized
INFO - 2022-06-23 12:22:46 --> URI Class Initialized
INFO - 2022-06-23 12:22:46 --> Router Class Initialized
INFO - 2022-06-23 12:22:46 --> Output Class Initialized
INFO - 2022-06-23 12:22:46 --> Security Class Initialized
DEBUG - 2022-06-23 12:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:22:46 --> Input Class Initialized
INFO - 2022-06-23 12:22:46 --> Language Class Initialized
INFO - 2022-06-23 12:22:46 --> Loader Class Initialized
INFO - 2022-06-23 12:22:46 --> Helper loaded: url_helper
INFO - 2022-06-23 12:22:46 --> Helper loaded: file_helper
INFO - 2022-06-23 12:22:46 --> Database Driver Class Initialized
INFO - 2022-06-23 12:22:46 --> Email Class Initialized
DEBUG - 2022-06-23 12:22:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:22:46 --> Controller Class Initialized
INFO - 2022-06-23 12:22:46 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:22:46 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:22:46 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 12:22:46 --> Final output sent to browser
DEBUG - 2022-06-23 12:22:46 --> Total execution time: 0.0642
INFO - 2022-06-23 12:22:51 --> Config Class Initialized
INFO - 2022-06-23 12:22:51 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:22:51 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:22:51 --> Utf8 Class Initialized
INFO - 2022-06-23 12:22:51 --> URI Class Initialized
INFO - 2022-06-23 12:22:51 --> Router Class Initialized
INFO - 2022-06-23 12:22:51 --> Output Class Initialized
INFO - 2022-06-23 12:22:51 --> Security Class Initialized
DEBUG - 2022-06-23 12:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:22:51 --> Input Class Initialized
INFO - 2022-06-23 12:22:51 --> Language Class Initialized
INFO - 2022-06-23 12:22:51 --> Loader Class Initialized
INFO - 2022-06-23 12:22:51 --> Helper loaded: url_helper
INFO - 2022-06-23 12:22:51 --> Helper loaded: file_helper
INFO - 2022-06-23 12:22:51 --> Database Driver Class Initialized
INFO - 2022-06-23 12:22:51 --> Email Class Initialized
DEBUG - 2022-06-23 12:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:22:51 --> Controller Class Initialized
INFO - 2022-06-23 12:22:51 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:22:51 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:22:51 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 12:22:51 --> Final output sent to browser
DEBUG - 2022-06-23 12:22:51 --> Total execution time: 0.0187
INFO - 2022-06-23 12:23:41 --> Config Class Initialized
INFO - 2022-06-23 12:23:41 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:23:41 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:23:41 --> Utf8 Class Initialized
INFO - 2022-06-23 12:23:41 --> URI Class Initialized
INFO - 2022-06-23 12:23:41 --> Router Class Initialized
INFO - 2022-06-23 12:23:41 --> Output Class Initialized
INFO - 2022-06-23 12:23:41 --> Security Class Initialized
DEBUG - 2022-06-23 12:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:23:41 --> Input Class Initialized
INFO - 2022-06-23 12:23:41 --> Language Class Initialized
INFO - 2022-06-23 12:23:41 --> Loader Class Initialized
INFO - 2022-06-23 12:23:41 --> Helper loaded: url_helper
INFO - 2022-06-23 12:23:41 --> Helper loaded: file_helper
INFO - 2022-06-23 12:23:41 --> Database Driver Class Initialized
INFO - 2022-06-23 12:23:41 --> Email Class Initialized
DEBUG - 2022-06-23 12:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:23:41 --> Controller Class Initialized
INFO - 2022-06-23 12:23:41 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:23:41 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:23:41 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 12:23:41 --> Final output sent to browser
DEBUG - 2022-06-23 12:23:41 --> Total execution time: 0.0223
INFO - 2022-06-23 12:23:43 --> Config Class Initialized
INFO - 2022-06-23 12:23:43 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:23:43 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:23:43 --> Utf8 Class Initialized
INFO - 2022-06-23 12:23:43 --> URI Class Initialized
INFO - 2022-06-23 12:23:43 --> Router Class Initialized
INFO - 2022-06-23 12:23:43 --> Output Class Initialized
INFO - 2022-06-23 12:23:43 --> Security Class Initialized
DEBUG - 2022-06-23 12:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:23:43 --> Input Class Initialized
INFO - 2022-06-23 12:23:43 --> Language Class Initialized
INFO - 2022-06-23 12:23:43 --> Loader Class Initialized
INFO - 2022-06-23 12:23:43 --> Config Class Initialized
INFO - 2022-06-23 12:23:43 --> Hooks Class Initialized
INFO - 2022-06-23 12:23:43 --> Helper loaded: url_helper
DEBUG - 2022-06-23 12:23:43 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:23:43 --> Helper loaded: file_helper
INFO - 2022-06-23 12:23:43 --> Utf8 Class Initialized
INFO - 2022-06-23 12:23:43 --> Database Driver Class Initialized
INFO - 2022-06-23 12:23:43 --> URI Class Initialized
INFO - 2022-06-23 12:23:43 --> Router Class Initialized
INFO - 2022-06-23 12:23:43 --> Output Class Initialized
INFO - 2022-06-23 12:23:43 --> Security Class Initialized
DEBUG - 2022-06-23 12:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:23:43 --> Input Class Initialized
INFO - 2022-06-23 12:23:43 --> Language Class Initialized
INFO - 2022-06-23 12:23:43 --> Loader Class Initialized
INFO - 2022-06-23 12:23:43 --> Helper loaded: url_helper
INFO - 2022-06-23 12:23:43 --> Helper loaded: file_helper
INFO - 2022-06-23 12:23:43 --> Database Driver Class Initialized
INFO - 2022-06-23 12:23:43 --> Email Class Initialized
DEBUG - 2022-06-23 12:23:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:23:43 --> Controller Class Initialized
INFO - 2022-06-23 12:23:43 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:23:43 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:23:43 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 12:23:43 --> Final output sent to browser
INFO - 2022-06-23 12:23:43 --> Email Class Initialized
DEBUG - 2022-06-23 12:23:43 --> Total execution time: 0.0246
DEBUG - 2022-06-23 12:23:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:23:43 --> Controller Class Initialized
INFO - 2022-06-23 12:23:43 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:23:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 12:23:43 --> test
INFO - 2022-06-23 12:23:43 --> Final output sent to browser
DEBUG - 2022-06-23 12:23:43 --> Total execution time: 0.0431
INFO - 2022-06-23 12:23:44 --> Config Class Initialized
INFO - 2022-06-23 12:23:44 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:23:44 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:23:44 --> Utf8 Class Initialized
INFO - 2022-06-23 12:23:44 --> URI Class Initialized
INFO - 2022-06-23 12:23:44 --> Router Class Initialized
INFO - 2022-06-23 12:23:44 --> Config Class Initialized
INFO - 2022-06-23 12:23:44 --> Output Class Initialized
INFO - 2022-06-23 12:23:44 --> Hooks Class Initialized
INFO - 2022-06-23 12:23:44 --> Security Class Initialized
DEBUG - 2022-06-23 12:23:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:23:44 --> Utf8 Class Initialized
INFO - 2022-06-23 12:23:44 --> Input Class Initialized
INFO - 2022-06-23 12:23:44 --> URI Class Initialized
INFO - 2022-06-23 12:23:44 --> Language Class Initialized
INFO - 2022-06-23 12:23:44 --> Router Class Initialized
INFO - 2022-06-23 12:23:44 --> Loader Class Initialized
INFO - 2022-06-23 12:23:44 --> Output Class Initialized
INFO - 2022-06-23 12:23:44 --> Helper loaded: url_helper
INFO - 2022-06-23 12:23:44 --> Security Class Initialized
INFO - 2022-06-23 12:23:44 --> Helper loaded: file_helper
DEBUG - 2022-06-23 12:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:23:44 --> Input Class Initialized
INFO - 2022-06-23 12:23:44 --> Language Class Initialized
INFO - 2022-06-23 12:23:44 --> Database Driver Class Initialized
INFO - 2022-06-23 12:23:44 --> Loader Class Initialized
INFO - 2022-06-23 12:23:44 --> Helper loaded: url_helper
INFO - 2022-06-23 12:23:44 --> Helper loaded: file_helper
INFO - 2022-06-23 12:23:44 --> Database Driver Class Initialized
INFO - 2022-06-23 12:23:44 --> Email Class Initialized
INFO - 2022-06-23 12:23:44 --> Email Class Initialized
DEBUG - 2022-06-23 12:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 12:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:23:44 --> Controller Class Initialized
INFO - 2022-06-23 12:23:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:23:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 12:23:44 --> test
INFO - 2022-06-23 12:23:44 --> Final output sent to browser
DEBUG - 2022-06-23 12:23:44 --> Total execution time: 0.0370
INFO - 2022-06-23 12:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:23:44 --> Controller Class Initialized
INFO - 2022-06-23 12:23:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:23:44 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:23:44 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 12:23:44 --> Final output sent to browser
DEBUG - 2022-06-23 12:23:44 --> Total execution time: 0.0360
INFO - 2022-06-23 12:23:44 --> Config Class Initialized
INFO - 2022-06-23 12:23:44 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:23:44 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:23:44 --> Utf8 Class Initialized
INFO - 2022-06-23 12:23:44 --> URI Class Initialized
INFO - 2022-06-23 12:23:44 --> Router Class Initialized
INFO - 2022-06-23 12:23:44 --> Output Class Initialized
INFO - 2022-06-23 12:23:44 --> Security Class Initialized
DEBUG - 2022-06-23 12:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:23:44 --> Input Class Initialized
INFO - 2022-06-23 12:23:44 --> Language Class Initialized
INFO - 2022-06-23 12:23:44 --> Loader Class Initialized
INFO - 2022-06-23 12:23:44 --> Helper loaded: url_helper
INFO - 2022-06-23 12:23:44 --> Helper loaded: file_helper
INFO - 2022-06-23 12:23:44 --> Database Driver Class Initialized
INFO - 2022-06-23 12:23:44 --> Email Class Initialized
DEBUG - 2022-06-23 12:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:23:44 --> Controller Class Initialized
INFO - 2022-06-23 12:23:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:23:44 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:23:44 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 12:23:44 --> Final output sent to browser
DEBUG - 2022-06-23 12:23:44 --> Total execution time: 0.0168
INFO - 2022-06-23 12:23:48 --> Config Class Initialized
INFO - 2022-06-23 12:23:48 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:23:48 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:23:48 --> Utf8 Class Initialized
INFO - 2022-06-23 12:23:48 --> URI Class Initialized
INFO - 2022-06-23 12:23:48 --> Router Class Initialized
INFO - 2022-06-23 12:23:48 --> Output Class Initialized
INFO - 2022-06-23 12:23:48 --> Security Class Initialized
DEBUG - 2022-06-23 12:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:23:48 --> Input Class Initialized
INFO - 2022-06-23 12:23:48 --> Language Class Initialized
INFO - 2022-06-23 12:23:48 --> Loader Class Initialized
INFO - 2022-06-23 12:23:48 --> Helper loaded: url_helper
INFO - 2022-06-23 12:23:48 --> Helper loaded: file_helper
INFO - 2022-06-23 12:23:48 --> Database Driver Class Initialized
INFO - 2022-06-23 12:23:48 --> Email Class Initialized
DEBUG - 2022-06-23 12:23:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:23:48 --> Controller Class Initialized
INFO - 2022-06-23 12:23:48 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:23:48 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:23:48 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 12:23:48 --> Final output sent to browser
DEBUG - 2022-06-23 12:23:48 --> Total execution time: 0.0173
INFO - 2022-06-23 12:23:50 --> Config Class Initialized
INFO - 2022-06-23 12:23:50 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:23:50 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:23:50 --> Utf8 Class Initialized
INFO - 2022-06-23 12:23:50 --> URI Class Initialized
INFO - 2022-06-23 12:23:50 --> Router Class Initialized
INFO - 2022-06-23 12:23:50 --> Output Class Initialized
INFO - 2022-06-23 12:23:50 --> Security Class Initialized
DEBUG - 2022-06-23 12:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:23:50 --> Input Class Initialized
INFO - 2022-06-23 12:23:50 --> Language Class Initialized
INFO - 2022-06-23 12:23:50 --> Loader Class Initialized
INFO - 2022-06-23 12:23:50 --> Helper loaded: url_helper
INFO - 2022-06-23 12:23:50 --> Helper loaded: file_helper
INFO - 2022-06-23 12:23:50 --> Database Driver Class Initialized
INFO - 2022-06-23 12:23:50 --> Email Class Initialized
DEBUG - 2022-06-23 12:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:23:50 --> Controller Class Initialized
INFO - 2022-06-23 12:23:50 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:23:50 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:23:50 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 12:23:50 --> Final output sent to browser
DEBUG - 2022-06-23 12:23:50 --> Total execution time: 0.0184
INFO - 2022-06-23 12:23:53 --> Config Class Initialized
INFO - 2022-06-23 12:23:53 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:23:53 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:23:53 --> Utf8 Class Initialized
INFO - 2022-06-23 12:23:53 --> URI Class Initialized
INFO - 2022-06-23 12:23:53 --> Router Class Initialized
INFO - 2022-06-23 12:23:53 --> Output Class Initialized
INFO - 2022-06-23 12:23:53 --> Security Class Initialized
DEBUG - 2022-06-23 12:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:23:53 --> Input Class Initialized
INFO - 2022-06-23 12:23:53 --> Language Class Initialized
INFO - 2022-06-23 12:23:53 --> Loader Class Initialized
INFO - 2022-06-23 12:23:53 --> Config Class Initialized
INFO - 2022-06-23 12:23:53 --> Helper loaded: url_helper
INFO - 2022-06-23 12:23:53 --> Hooks Class Initialized
INFO - 2022-06-23 12:23:53 --> Helper loaded: file_helper
DEBUG - 2022-06-23 12:23:53 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:23:53 --> Utf8 Class Initialized
INFO - 2022-06-23 12:23:53 --> Database Driver Class Initialized
INFO - 2022-06-23 12:23:53 --> URI Class Initialized
INFO - 2022-06-23 12:23:53 --> Router Class Initialized
INFO - 2022-06-23 12:23:53 --> Output Class Initialized
INFO - 2022-06-23 12:23:53 --> Security Class Initialized
DEBUG - 2022-06-23 12:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:23:53 --> Input Class Initialized
INFO - 2022-06-23 12:23:53 --> Language Class Initialized
INFO - 2022-06-23 12:23:53 --> Loader Class Initialized
INFO - 2022-06-23 12:23:53 --> Helper loaded: url_helper
INFO - 2022-06-23 12:23:53 --> Helper loaded: file_helper
INFO - 2022-06-23 12:23:53 --> Database Driver Class Initialized
INFO - 2022-06-23 12:23:53 --> Email Class Initialized
DEBUG - 2022-06-23 12:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:23:53 --> Controller Class Initialized
INFO - 2022-06-23 12:23:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:23:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 12:23:53 --> test
INFO - 2022-06-23 12:23:53 --> Email Class Initialized
DEBUG - 2022-06-23 12:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:23:53 --> Final output sent to browser
DEBUG - 2022-06-23 12:23:53 --> Total execution time: 0.0797
INFO - 2022-06-23 12:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:23:53 --> Controller Class Initialized
INFO - 2022-06-23 12:23:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:23:53 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:23:53 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 12:23:53 --> Final output sent to browser
DEBUG - 2022-06-23 12:23:53 --> Total execution time: 0.0744
INFO - 2022-06-23 12:23:53 --> Config Class Initialized
INFO - 2022-06-23 12:23:53 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:23:53 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:23:53 --> Utf8 Class Initialized
INFO - 2022-06-23 12:23:53 --> URI Class Initialized
INFO - 2022-06-23 12:23:53 --> Router Class Initialized
INFO - 2022-06-23 12:23:53 --> Output Class Initialized
INFO - 2022-06-23 12:23:53 --> Security Class Initialized
DEBUG - 2022-06-23 12:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:23:53 --> Input Class Initialized
INFO - 2022-06-23 12:23:53 --> Language Class Initialized
INFO - 2022-06-23 12:23:53 --> Loader Class Initialized
INFO - 2022-06-23 12:23:53 --> Helper loaded: url_helper
INFO - 2022-06-23 12:23:53 --> Helper loaded: file_helper
INFO - 2022-06-23 12:23:53 --> Database Driver Class Initialized
INFO - 2022-06-23 12:23:53 --> Email Class Initialized
DEBUG - 2022-06-23 12:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:23:53 --> Controller Class Initialized
INFO - 2022-06-23 12:23:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:23:53 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:23:53 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 12:23:53 --> Final output sent to browser
DEBUG - 2022-06-23 12:23:53 --> Total execution time: 0.0272
INFO - 2022-06-23 12:23:55 --> Config Class Initialized
INFO - 2022-06-23 12:23:55 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:23:55 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:23:55 --> Utf8 Class Initialized
INFO - 2022-06-23 12:23:55 --> URI Class Initialized
INFO - 2022-06-23 12:23:55 --> Router Class Initialized
INFO - 2022-06-23 12:23:55 --> Output Class Initialized
INFO - 2022-06-23 12:23:55 --> Security Class Initialized
DEBUG - 2022-06-23 12:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:23:55 --> Input Class Initialized
INFO - 2022-06-23 12:23:55 --> Language Class Initialized
INFO - 2022-06-23 12:23:55 --> Loader Class Initialized
INFO - 2022-06-23 12:23:55 --> Helper loaded: url_helper
INFO - 2022-06-23 12:23:55 --> Helper loaded: file_helper
INFO - 2022-06-23 12:23:55 --> Database Driver Class Initialized
INFO - 2022-06-23 12:23:55 --> Email Class Initialized
DEBUG - 2022-06-23 12:23:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:23:55 --> Controller Class Initialized
INFO - 2022-06-23 12:23:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:23:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:23:55 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 12:23:55 --> Final output sent to browser
DEBUG - 2022-06-23 12:23:55 --> Total execution time: 0.0173
INFO - 2022-06-23 12:24:24 --> Config Class Initialized
INFO - 2022-06-23 12:24:24 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:24:24 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:24:24 --> Utf8 Class Initialized
INFO - 2022-06-23 12:24:24 --> URI Class Initialized
INFO - 2022-06-23 12:24:24 --> Router Class Initialized
INFO - 2022-06-23 12:24:24 --> Output Class Initialized
INFO - 2022-06-23 12:24:24 --> Security Class Initialized
DEBUG - 2022-06-23 12:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:24:24 --> Input Class Initialized
INFO - 2022-06-23 12:24:24 --> Language Class Initialized
INFO - 2022-06-23 12:24:24 --> Loader Class Initialized
INFO - 2022-06-23 12:24:24 --> Helper loaded: url_helper
INFO - 2022-06-23 12:24:24 --> Helper loaded: file_helper
INFO - 2022-06-23 12:24:24 --> Database Driver Class Initialized
INFO - 2022-06-23 12:24:24 --> Email Class Initialized
DEBUG - 2022-06-23 12:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:24:24 --> Controller Class Initialized
INFO - 2022-06-23 12:24:24 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:24:24 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:24:24 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 12:24:24 --> Final output sent to browser
DEBUG - 2022-06-23 12:24:24 --> Total execution time: 0.0190
INFO - 2022-06-23 12:33:58 --> Config Class Initialized
INFO - 2022-06-23 12:33:58 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:33:58 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:33:58 --> Utf8 Class Initialized
INFO - 2022-06-23 12:33:58 --> URI Class Initialized
INFO - 2022-06-23 12:33:58 --> Router Class Initialized
INFO - 2022-06-23 12:33:58 --> Output Class Initialized
INFO - 2022-06-23 12:33:58 --> Security Class Initialized
DEBUG - 2022-06-23 12:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:33:58 --> Input Class Initialized
INFO - 2022-06-23 12:33:58 --> Language Class Initialized
INFO - 2022-06-23 12:33:58 --> Loader Class Initialized
INFO - 2022-06-23 12:33:58 --> Helper loaded: url_helper
INFO - 2022-06-23 12:33:58 --> Helper loaded: file_helper
INFO - 2022-06-23 12:33:58 --> Database Driver Class Initialized
INFO - 2022-06-23 12:33:58 --> Email Class Initialized
DEBUG - 2022-06-23 12:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:33:58 --> Controller Class Initialized
INFO - 2022-06-23 12:33:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:33:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:33:58 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-23 12:33:58 --> Final output sent to browser
DEBUG - 2022-06-23 12:33:58 --> Total execution time: 0.0449
INFO - 2022-06-23 12:34:02 --> Config Class Initialized
INFO - 2022-06-23 12:34:02 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:34:02 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:34:02 --> Utf8 Class Initialized
INFO - 2022-06-23 12:34:02 --> URI Class Initialized
INFO - 2022-06-23 12:34:02 --> Router Class Initialized
INFO - 2022-06-23 12:34:02 --> Output Class Initialized
INFO - 2022-06-23 12:34:02 --> Security Class Initialized
DEBUG - 2022-06-23 12:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:34:02 --> Input Class Initialized
INFO - 2022-06-23 12:34:02 --> Language Class Initialized
INFO - 2022-06-23 12:34:02 --> Loader Class Initialized
INFO - 2022-06-23 12:34:02 --> Helper loaded: url_helper
INFO - 2022-06-23 12:34:02 --> Helper loaded: file_helper
INFO - 2022-06-23 12:34:02 --> Database Driver Class Initialized
INFO - 2022-06-23 12:34:02 --> Email Class Initialized
DEBUG - 2022-06-23 12:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:34:02 --> Controller Class Initialized
INFO - 2022-06-23 12:34:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:34:02 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:34:02 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-23 12:34:02 --> Final output sent to browser
DEBUG - 2022-06-23 12:34:02 --> Total execution time: 0.1078
INFO - 2022-06-23 12:34:07 --> Config Class Initialized
INFO - 2022-06-23 12:34:07 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:34:07 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:34:07 --> Utf8 Class Initialized
INFO - 2022-06-23 12:34:07 --> URI Class Initialized
INFO - 2022-06-23 12:34:07 --> Router Class Initialized
INFO - 2022-06-23 12:34:07 --> Output Class Initialized
INFO - 2022-06-23 12:34:07 --> Security Class Initialized
DEBUG - 2022-06-23 12:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:34:07 --> Input Class Initialized
INFO - 2022-06-23 12:34:07 --> Language Class Initialized
INFO - 2022-06-23 12:34:07 --> Loader Class Initialized
INFO - 2022-06-23 12:34:07 --> Helper loaded: url_helper
INFO - 2022-06-23 12:34:07 --> Helper loaded: file_helper
INFO - 2022-06-23 12:34:07 --> Database Driver Class Initialized
INFO - 2022-06-23 12:34:07 --> Email Class Initialized
DEBUG - 2022-06-23 12:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:34:07 --> Controller Class Initialized
INFO - 2022-06-23 12:34:07 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:34:07 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:34:07 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 12:34:07 --> Final output sent to browser
DEBUG - 2022-06-23 12:34:07 --> Total execution time: 0.0273
INFO - 2022-06-23 12:34:21 --> Config Class Initialized
INFO - 2022-06-23 12:34:21 --> Hooks Class Initialized
INFO - 2022-06-23 12:34:21 --> Config Class Initialized
INFO - 2022-06-23 12:34:21 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:34:21 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:34:21 --> Utf8 Class Initialized
DEBUG - 2022-06-23 12:34:21 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:34:21 --> URI Class Initialized
INFO - 2022-06-23 12:34:21 --> Utf8 Class Initialized
INFO - 2022-06-23 12:34:21 --> URI Class Initialized
INFO - 2022-06-23 12:34:21 --> Router Class Initialized
INFO - 2022-06-23 12:34:21 --> Router Class Initialized
INFO - 2022-06-23 12:34:21 --> Output Class Initialized
INFO - 2022-06-23 12:34:21 --> Output Class Initialized
INFO - 2022-06-23 12:34:21 --> Security Class Initialized
INFO - 2022-06-23 12:34:21 --> Security Class Initialized
DEBUG - 2022-06-23 12:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:34:21 --> Input Class Initialized
DEBUG - 2022-06-23 12:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:34:21 --> Input Class Initialized
INFO - 2022-06-23 12:34:21 --> Language Class Initialized
INFO - 2022-06-23 12:34:21 --> Language Class Initialized
INFO - 2022-06-23 12:34:21 --> Loader Class Initialized
INFO - 2022-06-23 12:34:21 --> Loader Class Initialized
INFO - 2022-06-23 12:34:21 --> Helper loaded: url_helper
INFO - 2022-06-23 12:34:21 --> Helper loaded: file_helper
INFO - 2022-06-23 12:34:21 --> Helper loaded: url_helper
INFO - 2022-06-23 12:34:21 --> Helper loaded: file_helper
INFO - 2022-06-23 12:34:21 --> Database Driver Class Initialized
INFO - 2022-06-23 12:34:21 --> Database Driver Class Initialized
INFO - 2022-06-23 12:34:21 --> Email Class Initialized
DEBUG - 2022-06-23 12:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:34:21 --> Controller Class Initialized
INFO - 2022-06-23 12:34:21 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:34:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 12:34:21 --> test
INFO - 2022-06-23 12:34:21 --> Email Class Initialized
DEBUG - 2022-06-23 12:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:34:21 --> Final output sent to browser
DEBUG - 2022-06-23 12:34:21 --> Total execution time: 0.0786
INFO - 2022-06-23 12:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:34:21 --> Controller Class Initialized
INFO - 2022-06-23 12:34:21 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:34:21 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:34:21 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 12:34:21 --> Final output sent to browser
DEBUG - 2022-06-23 12:34:21 --> Total execution time: 0.0825
INFO - 2022-06-23 12:34:21 --> Config Class Initialized
INFO - 2022-06-23 12:34:21 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:34:21 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:34:21 --> Utf8 Class Initialized
INFO - 2022-06-23 12:34:21 --> URI Class Initialized
INFO - 2022-06-23 12:34:21 --> Router Class Initialized
INFO - 2022-06-23 12:34:21 --> Output Class Initialized
INFO - 2022-06-23 12:34:21 --> Security Class Initialized
DEBUG - 2022-06-23 12:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:34:21 --> Input Class Initialized
INFO - 2022-06-23 12:34:21 --> Language Class Initialized
INFO - 2022-06-23 12:34:21 --> Loader Class Initialized
INFO - 2022-06-23 12:34:21 --> Helper loaded: url_helper
INFO - 2022-06-23 12:34:21 --> Helper loaded: file_helper
INFO - 2022-06-23 12:34:21 --> Database Driver Class Initialized
INFO - 2022-06-23 12:34:21 --> Email Class Initialized
DEBUG - 2022-06-23 12:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:34:21 --> Controller Class Initialized
INFO - 2022-06-23 12:34:21 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:34:21 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:34:21 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 12:34:21 --> Final output sent to browser
DEBUG - 2022-06-23 12:34:21 --> Total execution time: 0.0345
INFO - 2022-06-23 12:34:30 --> Config Class Initialized
INFO - 2022-06-23 12:34:30 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:34:30 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:34:30 --> Utf8 Class Initialized
INFO - 2022-06-23 12:34:30 --> Config Class Initialized
INFO - 2022-06-23 12:34:30 --> Hooks Class Initialized
INFO - 2022-06-23 12:34:30 --> URI Class Initialized
DEBUG - 2022-06-23 12:34:30 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:34:30 --> Utf8 Class Initialized
INFO - 2022-06-23 12:34:30 --> Router Class Initialized
INFO - 2022-06-23 12:34:30 --> URI Class Initialized
INFO - 2022-06-23 12:34:30 --> Output Class Initialized
INFO - 2022-06-23 12:34:30 --> Router Class Initialized
INFO - 2022-06-23 12:34:30 --> Security Class Initialized
INFO - 2022-06-23 12:34:30 --> Output Class Initialized
DEBUG - 2022-06-23 12:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:34:30 --> Security Class Initialized
INFO - 2022-06-23 12:34:30 --> Input Class Initialized
DEBUG - 2022-06-23 12:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:34:30 --> Language Class Initialized
INFO - 2022-06-23 12:34:30 --> Input Class Initialized
INFO - 2022-06-23 12:34:30 --> Language Class Initialized
INFO - 2022-06-23 12:34:30 --> Loader Class Initialized
INFO - 2022-06-23 12:34:30 --> Loader Class Initialized
INFO - 2022-06-23 12:34:30 --> Helper loaded: url_helper
INFO - 2022-06-23 12:34:30 --> Helper loaded: url_helper
INFO - 2022-06-23 12:34:30 --> Helper loaded: file_helper
INFO - 2022-06-23 12:34:30 --> Helper loaded: file_helper
INFO - 2022-06-23 12:34:30 --> Database Driver Class Initialized
INFO - 2022-06-23 12:34:30 --> Database Driver Class Initialized
INFO - 2022-06-23 12:34:30 --> Email Class Initialized
INFO - 2022-06-23 12:34:30 --> Email Class Initialized
DEBUG - 2022-06-23 12:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 12:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:34:30 --> Controller Class Initialized
INFO - 2022-06-23 12:34:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:34:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:34:30 --> Final output sent to browser
DEBUG - 2022-06-23 12:34:30 --> Total execution time: 0.0473
INFO - 2022-06-23 12:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:34:30 --> Controller Class Initialized
INFO - 2022-06-23 12:34:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:34:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:34:30 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 12:34:30 --> Final output sent to browser
DEBUG - 2022-06-23 12:34:30 --> Total execution time: 0.0483
INFO - 2022-06-23 12:44:01 --> Config Class Initialized
INFO - 2022-06-23 12:44:01 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:44:01 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:44:01 --> Utf8 Class Initialized
INFO - 2022-06-23 12:44:01 --> URI Class Initialized
INFO - 2022-06-23 12:44:01 --> Router Class Initialized
INFO - 2022-06-23 12:44:01 --> Output Class Initialized
INFO - 2022-06-23 12:44:01 --> Security Class Initialized
DEBUG - 2022-06-23 12:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:44:01 --> Input Class Initialized
INFO - 2022-06-23 12:44:01 --> Language Class Initialized
INFO - 2022-06-23 12:44:01 --> Loader Class Initialized
INFO - 2022-06-23 12:44:01 --> Helper loaded: url_helper
INFO - 2022-06-23 12:44:01 --> Helper loaded: file_helper
INFO - 2022-06-23 12:44:01 --> Database Driver Class Initialized
INFO - 2022-06-23 12:44:01 --> Email Class Initialized
DEBUG - 2022-06-23 12:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:44:01 --> Controller Class Initialized
INFO - 2022-06-23 12:44:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:44:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:44:01 --> Final output sent to browser
DEBUG - 2022-06-23 12:44:01 --> Total execution time: 0.0317
INFO - 2022-06-23 12:44:01 --> Config Class Initialized
INFO - 2022-06-23 12:44:01 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:44:01 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:44:01 --> Utf8 Class Initialized
INFO - 2022-06-23 12:44:01 --> URI Class Initialized
INFO - 2022-06-23 12:44:01 --> Router Class Initialized
INFO - 2022-06-23 12:44:01 --> Output Class Initialized
INFO - 2022-06-23 12:44:01 --> Security Class Initialized
DEBUG - 2022-06-23 12:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:44:01 --> Input Class Initialized
INFO - 2022-06-23 12:44:01 --> Language Class Initialized
INFO - 2022-06-23 12:44:01 --> Loader Class Initialized
INFO - 2022-06-23 12:44:01 --> Helper loaded: url_helper
INFO - 2022-06-23 12:44:01 --> Helper loaded: file_helper
INFO - 2022-06-23 12:44:01 --> Database Driver Class Initialized
INFO - 2022-06-23 12:44:01 --> Email Class Initialized
DEBUG - 2022-06-23 12:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:44:01 --> Controller Class Initialized
INFO - 2022-06-23 12:44:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:44:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:44:01 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 12:44:01 --> Final output sent to browser
DEBUG - 2022-06-23 12:44:01 --> Total execution time: 0.0460
INFO - 2022-06-23 12:45:39 --> Config Class Initialized
INFO - 2022-06-23 12:45:39 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:45:39 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:45:39 --> Utf8 Class Initialized
INFO - 2022-06-23 12:45:39 --> URI Class Initialized
INFO - 2022-06-23 12:45:39 --> Router Class Initialized
INFO - 2022-06-23 12:45:39 --> Output Class Initialized
INFO - 2022-06-23 12:45:39 --> Security Class Initialized
DEBUG - 2022-06-23 12:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:45:39 --> Input Class Initialized
INFO - 2022-06-23 12:45:39 --> Language Class Initialized
INFO - 2022-06-23 12:45:39 --> Loader Class Initialized
INFO - 2022-06-23 12:45:39 --> Helper loaded: url_helper
INFO - 2022-06-23 12:45:39 --> Helper loaded: file_helper
INFO - 2022-06-23 12:45:39 --> Database Driver Class Initialized
INFO - 2022-06-23 12:45:39 --> Email Class Initialized
DEBUG - 2022-06-23 12:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:45:39 --> Controller Class Initialized
INFO - 2022-06-23 12:45:39 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:45:39 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:45:39 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 12:45:39 --> Final output sent to browser
DEBUG - 2022-06-23 12:45:39 --> Total execution time: 0.3789
INFO - 2022-06-23 12:45:55 --> Config Class Initialized
INFO - 2022-06-23 12:45:55 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:45:55 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:45:55 --> Utf8 Class Initialized
INFO - 2022-06-23 12:45:55 --> Config Class Initialized
INFO - 2022-06-23 12:45:55 --> Hooks Class Initialized
INFO - 2022-06-23 12:45:55 --> URI Class Initialized
DEBUG - 2022-06-23 12:45:55 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:45:55 --> Utf8 Class Initialized
INFO - 2022-06-23 12:45:55 --> Router Class Initialized
INFO - 2022-06-23 12:45:55 --> URI Class Initialized
INFO - 2022-06-23 12:45:55 --> Output Class Initialized
INFO - 2022-06-23 12:45:55 --> Router Class Initialized
INFO - 2022-06-23 12:45:55 --> Security Class Initialized
INFO - 2022-06-23 12:45:55 --> Output Class Initialized
DEBUG - 2022-06-23 12:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:45:55 --> Security Class Initialized
INFO - 2022-06-23 12:45:55 --> Input Class Initialized
DEBUG - 2022-06-23 12:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:45:55 --> Input Class Initialized
INFO - 2022-06-23 12:45:55 --> Language Class Initialized
INFO - 2022-06-23 12:45:55 --> Language Class Initialized
INFO - 2022-06-23 12:45:55 --> Loader Class Initialized
INFO - 2022-06-23 12:45:55 --> Loader Class Initialized
INFO - 2022-06-23 12:45:55 --> Helper loaded: url_helper
INFO - 2022-06-23 12:45:55 --> Helper loaded: url_helper
INFO - 2022-06-23 12:45:55 --> Helper loaded: file_helper
INFO - 2022-06-23 12:45:55 --> Helper loaded: file_helper
INFO - 2022-06-23 12:45:55 --> Database Driver Class Initialized
INFO - 2022-06-23 12:45:55 --> Database Driver Class Initialized
INFO - 2022-06-23 12:45:55 --> Email Class Initialized
INFO - 2022-06-23 12:45:55 --> Email Class Initialized
DEBUG - 2022-06-23 12:45:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 12:45:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:45:55 --> Controller Class Initialized
INFO - 2022-06-23 12:45:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:45:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:45:55 --> Final output sent to browser
DEBUG - 2022-06-23 12:45:55 --> Total execution time: 0.1268
INFO - 2022-06-23 12:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:45:55 --> Controller Class Initialized
INFO - 2022-06-23 12:45:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:45:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:45:55 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 12:45:55 --> Final output sent to browser
DEBUG - 2022-06-23 12:45:55 --> Total execution time: 0.1284
INFO - 2022-06-23 12:50:33 --> Config Class Initialized
INFO - 2022-06-23 12:50:33 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:50:33 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:50:33 --> Utf8 Class Initialized
INFO - 2022-06-23 12:50:33 --> URI Class Initialized
INFO - 2022-06-23 12:50:33 --> Router Class Initialized
INFO - 2022-06-23 12:50:33 --> Output Class Initialized
INFO - 2022-06-23 12:50:33 --> Security Class Initialized
DEBUG - 2022-06-23 12:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:50:33 --> Input Class Initialized
INFO - 2022-06-23 12:50:33 --> Language Class Initialized
INFO - 2022-06-23 12:50:33 --> Loader Class Initialized
INFO - 2022-06-23 12:50:33 --> Helper loaded: url_helper
INFO - 2022-06-23 12:50:33 --> Helper loaded: file_helper
INFO - 2022-06-23 12:50:33 --> Database Driver Class Initialized
INFO - 2022-06-23 12:50:33 --> Email Class Initialized
DEBUG - 2022-06-23 12:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:50:33 --> Controller Class Initialized
INFO - 2022-06-23 12:50:33 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:50:33 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:50:33 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-23 12:50:33 --> Final output sent to browser
DEBUG - 2022-06-23 12:50:33 --> Total execution time: 0.0287
INFO - 2022-06-23 12:50:37 --> Config Class Initialized
INFO - 2022-06-23 12:50:37 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:50:37 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:50:37 --> Utf8 Class Initialized
INFO - 2022-06-23 12:50:37 --> URI Class Initialized
INFO - 2022-06-23 12:50:37 --> Router Class Initialized
INFO - 2022-06-23 12:50:37 --> Output Class Initialized
INFO - 2022-06-23 12:50:37 --> Security Class Initialized
DEBUG - 2022-06-23 12:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:50:37 --> Input Class Initialized
INFO - 2022-06-23 12:50:37 --> Language Class Initialized
INFO - 2022-06-23 12:50:37 --> Loader Class Initialized
INFO - 2022-06-23 12:50:37 --> Helper loaded: url_helper
INFO - 2022-06-23 12:50:37 --> Helper loaded: file_helper
INFO - 2022-06-23 12:50:37 --> Database Driver Class Initialized
INFO - 2022-06-23 12:50:37 --> Email Class Initialized
DEBUG - 2022-06-23 12:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:50:37 --> Controller Class Initialized
INFO - 2022-06-23 12:50:37 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:50:37 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:50:37 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-23 12:50:37 --> Final output sent to browser
DEBUG - 2022-06-23 12:50:37 --> Total execution time: 0.1330
INFO - 2022-06-23 12:50:41 --> Config Class Initialized
INFO - 2022-06-23 12:50:41 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:50:41 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:50:41 --> Utf8 Class Initialized
INFO - 2022-06-23 12:50:41 --> URI Class Initialized
INFO - 2022-06-23 12:50:41 --> Router Class Initialized
INFO - 2022-06-23 12:50:41 --> Output Class Initialized
INFO - 2022-06-23 12:50:41 --> Security Class Initialized
DEBUG - 2022-06-23 12:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:50:41 --> Input Class Initialized
INFO - 2022-06-23 12:50:41 --> Language Class Initialized
INFO - 2022-06-23 12:50:41 --> Loader Class Initialized
INFO - 2022-06-23 12:50:41 --> Helper loaded: url_helper
INFO - 2022-06-23 12:50:41 --> Helper loaded: file_helper
INFO - 2022-06-23 12:50:41 --> Database Driver Class Initialized
INFO - 2022-06-23 12:50:41 --> Email Class Initialized
DEBUG - 2022-06-23 12:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:50:41 --> Controller Class Initialized
INFO - 2022-06-23 12:50:41 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:50:41 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:50:41 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 12:50:41 --> Final output sent to browser
DEBUG - 2022-06-23 12:50:41 --> Total execution time: 0.0202
INFO - 2022-06-23 12:51:01 --> Config Class Initialized
INFO - 2022-06-23 12:51:01 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:51:01 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:51:01 --> Utf8 Class Initialized
INFO - 2022-06-23 12:51:01 --> Config Class Initialized
INFO - 2022-06-23 12:51:01 --> URI Class Initialized
INFO - 2022-06-23 12:51:01 --> Hooks Class Initialized
INFO - 2022-06-23 12:51:01 --> Router Class Initialized
DEBUG - 2022-06-23 12:51:01 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:51:01 --> Utf8 Class Initialized
INFO - 2022-06-23 12:51:01 --> Output Class Initialized
INFO - 2022-06-23 12:51:01 --> URI Class Initialized
INFO - 2022-06-23 12:51:01 --> Security Class Initialized
INFO - 2022-06-23 12:51:01 --> Router Class Initialized
DEBUG - 2022-06-23 12:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:51:01 --> Input Class Initialized
INFO - 2022-06-23 12:51:01 --> Output Class Initialized
INFO - 2022-06-23 12:51:01 --> Language Class Initialized
INFO - 2022-06-23 12:51:01 --> Security Class Initialized
DEBUG - 2022-06-23 12:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:51:01 --> Input Class Initialized
INFO - 2022-06-23 12:51:01 --> Loader Class Initialized
INFO - 2022-06-23 12:51:01 --> Language Class Initialized
INFO - 2022-06-23 12:51:01 --> Helper loaded: url_helper
INFO - 2022-06-23 12:51:01 --> Loader Class Initialized
INFO - 2022-06-23 12:51:01 --> Helper loaded: file_helper
INFO - 2022-06-23 12:51:01 --> Helper loaded: url_helper
INFO - 2022-06-23 12:51:01 --> Database Driver Class Initialized
INFO - 2022-06-23 12:51:01 --> Helper loaded: file_helper
INFO - 2022-06-23 12:51:01 --> Database Driver Class Initialized
INFO - 2022-06-23 12:51:01 --> Email Class Initialized
INFO - 2022-06-23 12:51:01 --> Email Class Initialized
DEBUG - 2022-06-23 12:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 12:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:51:01 --> Controller Class Initialized
INFO - 2022-06-23 12:51:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:51:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-23 12:51:01 --> test
INFO - 2022-06-23 12:51:01 --> Final output sent to browser
DEBUG - 2022-06-23 12:51:01 --> Total execution time: 0.0419
INFO - 2022-06-23 12:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:51:01 --> Controller Class Initialized
INFO - 2022-06-23 12:51:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:51:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:51:01 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-23 12:51:01 --> Final output sent to browser
DEBUG - 2022-06-23 12:51:01 --> Total execution time: 0.0450
INFO - 2022-06-23 12:51:01 --> Config Class Initialized
INFO - 2022-06-23 12:51:01 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:51:01 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:51:01 --> Utf8 Class Initialized
INFO - 2022-06-23 12:51:01 --> URI Class Initialized
INFO - 2022-06-23 12:51:01 --> Router Class Initialized
INFO - 2022-06-23 12:51:01 --> Output Class Initialized
INFO - 2022-06-23 12:51:01 --> Security Class Initialized
DEBUG - 2022-06-23 12:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:51:01 --> Input Class Initialized
INFO - 2022-06-23 12:51:01 --> Language Class Initialized
INFO - 2022-06-23 12:51:01 --> Loader Class Initialized
INFO - 2022-06-23 12:51:01 --> Helper loaded: url_helper
INFO - 2022-06-23 12:51:01 --> Helper loaded: file_helper
INFO - 2022-06-23 12:51:01 --> Database Driver Class Initialized
INFO - 2022-06-23 12:51:01 --> Email Class Initialized
DEBUG - 2022-06-23 12:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:51:01 --> Controller Class Initialized
INFO - 2022-06-23 12:51:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:51:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:51:01 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 12:51:01 --> Final output sent to browser
DEBUG - 2022-06-23 12:51:01 --> Total execution time: 0.0201
INFO - 2022-06-23 12:56:57 --> Config Class Initialized
INFO - 2022-06-23 12:56:57 --> Config Class Initialized
INFO - 2022-06-23 12:56:57 --> Hooks Class Initialized
INFO - 2022-06-23 12:56:57 --> Hooks Class Initialized
DEBUG - 2022-06-23 12:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-23 12:56:57 --> UTF-8 Support Enabled
INFO - 2022-06-23 12:56:57 --> Utf8 Class Initialized
INFO - 2022-06-23 12:56:57 --> Utf8 Class Initialized
INFO - 2022-06-23 12:56:57 --> URI Class Initialized
INFO - 2022-06-23 12:56:57 --> URI Class Initialized
INFO - 2022-06-23 12:56:57 --> Router Class Initialized
INFO - 2022-06-23 12:56:57 --> Router Class Initialized
INFO - 2022-06-23 12:56:57 --> Output Class Initialized
INFO - 2022-06-23 12:56:57 --> Output Class Initialized
INFO - 2022-06-23 12:56:57 --> Security Class Initialized
INFO - 2022-06-23 12:56:57 --> Security Class Initialized
DEBUG - 2022-06-23 12:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-23 12:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-23 12:56:57 --> Input Class Initialized
INFO - 2022-06-23 12:56:57 --> Input Class Initialized
INFO - 2022-06-23 12:56:57 --> Language Class Initialized
INFO - 2022-06-23 12:56:57 --> Language Class Initialized
INFO - 2022-06-23 12:56:57 --> Loader Class Initialized
INFO - 2022-06-23 12:56:57 --> Loader Class Initialized
INFO - 2022-06-23 12:56:57 --> Helper loaded: url_helper
INFO - 2022-06-23 12:56:57 --> Helper loaded: url_helper
INFO - 2022-06-23 12:56:57 --> Helper loaded: file_helper
INFO - 2022-06-23 12:56:57 --> Helper loaded: file_helper
INFO - 2022-06-23 12:56:57 --> Database Driver Class Initialized
INFO - 2022-06-23 12:56:57 --> Database Driver Class Initialized
INFO - 2022-06-23 12:56:57 --> Email Class Initialized
INFO - 2022-06-23 12:56:57 --> Email Class Initialized
DEBUG - 2022-06-23 12:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-23 12:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-23 12:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:56:57 --> Controller Class Initialized
INFO - 2022-06-23 12:56:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:56:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:56:57 --> Final output sent to browser
DEBUG - 2022-06-23 12:56:57 --> Total execution time: 0.0690
INFO - 2022-06-23 12:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-23 12:56:57 --> Controller Class Initialized
INFO - 2022-06-23 12:56:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-23 12:56:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-23 12:56:57 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-23 12:56:57 --> Final output sent to browser
DEBUG - 2022-06-23 12:56:57 --> Total execution time: 0.0750
