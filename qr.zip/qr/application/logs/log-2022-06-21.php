<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-06-21 11:34:09 --> Config Class Initialized
INFO - 2022-06-21 11:34:09 --> Hooks Class Initialized
DEBUG - 2022-06-21 11:34:09 --> UTF-8 Support Enabled
INFO - 2022-06-21 11:34:09 --> Utf8 Class Initialized
INFO - 2022-06-21 11:34:09 --> URI Class Initialized
INFO - 2022-06-21 11:34:09 --> Router Class Initialized
INFO - 2022-06-21 11:34:09 --> Output Class Initialized
INFO - 2022-06-21 11:34:09 --> Security Class Initialized
DEBUG - 2022-06-21 11:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 11:34:09 --> Input Class Initialized
INFO - 2022-06-21 11:34:09 --> Language Class Initialized
INFO - 2022-06-21 11:34:09 --> Loader Class Initialized
INFO - 2022-06-21 11:34:09 --> Helper loaded: url_helper
INFO - 2022-06-21 11:34:09 --> Helper loaded: file_helper
INFO - 2022-06-21 11:34:09 --> Database Driver Class Initialized
INFO - 2022-06-21 11:34:10 --> Email Class Initialized
DEBUG - 2022-06-21 11:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 11:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 11:34:10 --> Controller Class Initialized
INFO - 2022-06-21 11:34:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 11:34:10 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-21 11:34:10 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-21 11:34:10 --> Final output sent to browser
DEBUG - 2022-06-21 11:34:10 --> Total execution time: 0.2108
INFO - 2022-06-21 11:34:16 --> Config Class Initialized
INFO - 2022-06-21 11:34:16 --> Hooks Class Initialized
DEBUG - 2022-06-21 11:34:16 --> UTF-8 Support Enabled
INFO - 2022-06-21 11:34:16 --> Utf8 Class Initialized
INFO - 2022-06-21 11:34:16 --> URI Class Initialized
INFO - 2022-06-21 11:34:16 --> Router Class Initialized
INFO - 2022-06-21 11:34:16 --> Output Class Initialized
INFO - 2022-06-21 11:34:16 --> Security Class Initialized
DEBUG - 2022-06-21 11:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 11:34:16 --> Input Class Initialized
INFO - 2022-06-21 11:34:16 --> Language Class Initialized
INFO - 2022-06-21 11:34:16 --> Loader Class Initialized
INFO - 2022-06-21 11:34:16 --> Helper loaded: url_helper
INFO - 2022-06-21 11:34:16 --> Helper loaded: file_helper
INFO - 2022-06-21 11:34:16 --> Database Driver Class Initialized
INFO - 2022-06-21 11:34:16 --> Config Class Initialized
INFO - 2022-06-21 11:34:16 --> Hooks Class Initialized
DEBUG - 2022-06-21 11:34:16 --> UTF-8 Support Enabled
INFO - 2022-06-21 11:34:16 --> Utf8 Class Initialized
INFO - 2022-06-21 11:34:16 --> URI Class Initialized
INFO - 2022-06-21 11:34:16 --> Router Class Initialized
INFO - 2022-06-21 11:34:16 --> Output Class Initialized
INFO - 2022-06-21 11:34:16 --> Security Class Initialized
DEBUG - 2022-06-21 11:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 11:34:16 --> Input Class Initialized
INFO - 2022-06-21 11:34:16 --> Language Class Initialized
INFO - 2022-06-21 11:34:16 --> Loader Class Initialized
INFO - 2022-06-21 11:34:16 --> Helper loaded: url_helper
INFO - 2022-06-21 11:34:16 --> Helper loaded: file_helper
INFO - 2022-06-21 11:34:16 --> Database Driver Class Initialized
INFO - 2022-06-21 11:34:16 --> Email Class Initialized
DEBUG - 2022-06-21 11:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 11:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 11:34:16 --> Controller Class Initialized
INFO - 2022-06-21 11:34:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 11:34:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 11:34:16 --> test
ERROR - 2022-06-21 11:34:16 --> Query error: Column 'ud_name' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_name`, `ud_age`) VALUES (NULL, NULL)
INFO - 2022-06-21 11:34:16 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-21 11:34:16 --> Email Class Initialized
DEBUG - 2022-06-21 11:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 11:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 11:34:16 --> Controller Class Initialized
INFO - 2022-06-21 11:34:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 11:34:16 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-21 11:34:16 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-21 11:34:16 --> Final output sent to browser
DEBUG - 2022-06-21 11:34:16 --> Total execution time: 0.2110
INFO - 2022-06-21 11:34:27 --> Config Class Initialized
INFO - 2022-06-21 11:34:27 --> Hooks Class Initialized
DEBUG - 2022-06-21 11:34:27 --> UTF-8 Support Enabled
INFO - 2022-06-21 11:34:27 --> Utf8 Class Initialized
INFO - 2022-06-21 11:34:27 --> URI Class Initialized
INFO - 2022-06-21 11:34:27 --> Router Class Initialized
INFO - 2022-06-21 11:34:27 --> Output Class Initialized
INFO - 2022-06-21 11:34:27 --> Security Class Initialized
DEBUG - 2022-06-21 11:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 11:34:27 --> Input Class Initialized
INFO - 2022-06-21 11:34:27 --> Language Class Initialized
INFO - 2022-06-21 11:34:27 --> Loader Class Initialized
INFO - 2022-06-21 11:34:27 --> Helper loaded: url_helper
INFO - 2022-06-21 11:34:27 --> Helper loaded: file_helper
INFO - 2022-06-21 11:34:27 --> Database Driver Class Initialized
INFO - 2022-06-21 11:34:27 --> Email Class Initialized
DEBUG - 2022-06-21 11:34:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 11:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 11:34:27 --> Controller Class Initialized
INFO - 2022-06-21 11:34:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 11:34:27 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-21 11:34:27 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-21 11:34:27 --> Final output sent to browser
DEBUG - 2022-06-21 11:34:27 --> Total execution time: 0.0271
INFO - 2022-06-21 11:34:30 --> Config Class Initialized
INFO - 2022-06-21 11:34:30 --> Hooks Class Initialized
DEBUG - 2022-06-21 11:34:30 --> UTF-8 Support Enabled
INFO - 2022-06-21 11:34:30 --> Utf8 Class Initialized
INFO - 2022-06-21 11:34:30 --> URI Class Initialized
INFO - 2022-06-21 11:34:30 --> Router Class Initialized
INFO - 2022-06-21 11:34:30 --> Output Class Initialized
INFO - 2022-06-21 11:34:30 --> Security Class Initialized
DEBUG - 2022-06-21 11:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 11:34:30 --> Input Class Initialized
INFO - 2022-06-21 11:34:30 --> Language Class Initialized
INFO - 2022-06-21 11:34:30 --> Loader Class Initialized
INFO - 2022-06-21 11:34:30 --> Helper loaded: url_helper
INFO - 2022-06-21 11:34:30 --> Helper loaded: file_helper
INFO - 2022-06-21 11:34:30 --> Database Driver Class Initialized
INFO - 2022-06-21 11:34:30 --> Email Class Initialized
DEBUG - 2022-06-21 11:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 11:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 11:34:30 --> Controller Class Initialized
INFO - 2022-06-21 11:34:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 11:34:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-21 11:34:30 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-21 11:34:30 --> Final output sent to browser
DEBUG - 2022-06-21 11:34:30 --> Total execution time: 0.1882
INFO - 2022-06-21 11:35:52 --> Config Class Initialized
INFO - 2022-06-21 11:35:52 --> Config Class Initialized
INFO - 2022-06-21 11:35:52 --> Hooks Class Initialized
INFO - 2022-06-21 11:35:52 --> Hooks Class Initialized
DEBUG - 2022-06-21 11:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:35:52 --> UTF-8 Support Enabled
INFO - 2022-06-21 11:35:52 --> Utf8 Class Initialized
INFO - 2022-06-21 11:35:52 --> Utf8 Class Initialized
INFO - 2022-06-21 11:35:52 --> URI Class Initialized
INFO - 2022-06-21 11:35:52 --> URI Class Initialized
INFO - 2022-06-21 11:35:52 --> Router Class Initialized
INFO - 2022-06-21 11:35:52 --> Router Class Initialized
INFO - 2022-06-21 11:35:52 --> Output Class Initialized
INFO - 2022-06-21 11:35:52 --> Output Class Initialized
INFO - 2022-06-21 11:35:52 --> Security Class Initialized
INFO - 2022-06-21 11:35:52 --> Security Class Initialized
DEBUG - 2022-06-21 11:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 11:35:52 --> Input Class Initialized
INFO - 2022-06-21 11:35:52 --> Input Class Initialized
INFO - 2022-06-21 11:35:52 --> Language Class Initialized
INFO - 2022-06-21 11:35:52 --> Language Class Initialized
INFO - 2022-06-21 11:35:52 --> Loader Class Initialized
INFO - 2022-06-21 11:35:52 --> Loader Class Initialized
INFO - 2022-06-21 11:35:52 --> Helper loaded: url_helper
INFO - 2022-06-21 11:35:52 --> Helper loaded: url_helper
INFO - 2022-06-21 11:35:52 --> Helper loaded: file_helper
INFO - 2022-06-21 11:35:52 --> Helper loaded: file_helper
INFO - 2022-06-21 11:35:52 --> Database Driver Class Initialized
INFO - 2022-06-21 11:35:52 --> Database Driver Class Initialized
INFO - 2022-06-21 11:35:53 --> Email Class Initialized
DEBUG - 2022-06-21 11:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 11:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 11:35:53 --> Controller Class Initialized
INFO - 2022-06-21 11:35:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 11:35:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 11:35:53 --> test
INFO - 2022-06-21 11:35:53 --> Email Class Initialized
DEBUG - 2022-06-21 11:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-06-21 11:35:53 --> Query error: Column 'ud_name' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_name`, `ud_age`) VALUES (NULL, NULL)
INFO - 2022-06-21 11:35:53 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-21 11:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 11:35:53 --> Controller Class Initialized
INFO - 2022-06-21 11:35:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 11:35:53 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-21 11:35:53 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-21 11:35:53 --> Final output sent to browser
DEBUG - 2022-06-21 11:35:53 --> Total execution time: 0.3032
INFO - 2022-06-21 11:36:10 --> Config Class Initialized
INFO - 2022-06-21 11:36:10 --> Hooks Class Initialized
DEBUG - 2022-06-21 11:36:10 --> UTF-8 Support Enabled
INFO - 2022-06-21 11:36:10 --> Utf8 Class Initialized
INFO - 2022-06-21 11:36:10 --> URI Class Initialized
INFO - 2022-06-21 11:36:10 --> Config Class Initialized
INFO - 2022-06-21 11:36:10 --> Hooks Class Initialized
INFO - 2022-06-21 11:36:10 --> Router Class Initialized
DEBUG - 2022-06-21 11:36:10 --> UTF-8 Support Enabled
INFO - 2022-06-21 11:36:10 --> Utf8 Class Initialized
INFO - 2022-06-21 11:36:10 --> Output Class Initialized
INFO - 2022-06-21 11:36:10 --> URI Class Initialized
INFO - 2022-06-21 11:36:10 --> Security Class Initialized
DEBUG - 2022-06-21 11:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 11:36:10 --> Router Class Initialized
INFO - 2022-06-21 11:36:10 --> Input Class Initialized
INFO - 2022-06-21 11:36:10 --> Output Class Initialized
INFO - 2022-06-21 11:36:10 --> Language Class Initialized
INFO - 2022-06-21 11:36:10 --> Security Class Initialized
INFO - 2022-06-21 11:36:10 --> Loader Class Initialized
DEBUG - 2022-06-21 11:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 11:36:10 --> Input Class Initialized
INFO - 2022-06-21 11:36:10 --> Helper loaded: url_helper
INFO - 2022-06-21 11:36:10 --> Language Class Initialized
INFO - 2022-06-21 11:36:10 --> Helper loaded: file_helper
INFO - 2022-06-21 11:36:10 --> Loader Class Initialized
INFO - 2022-06-21 11:36:10 --> Database Driver Class Initialized
INFO - 2022-06-21 11:36:10 --> Helper loaded: url_helper
INFO - 2022-06-21 11:36:10 --> Helper loaded: file_helper
INFO - 2022-06-21 11:36:10 --> Database Driver Class Initialized
INFO - 2022-06-21 11:36:10 --> Email Class Initialized
DEBUG - 2022-06-21 11:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 11:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 11:36:10 --> Controller Class Initialized
INFO - 2022-06-21 11:36:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 11:36:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 11:36:10 --> test
INFO - 2022-06-21 11:36:10 --> Email Class Initialized
DEBUG - 2022-06-21 11:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-06-21 11:36:10 --> Query error: Column 'ud_name' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_name`, `ud_age`) VALUES (NULL, NULL)
INFO - 2022-06-21 11:36:10 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-21 11:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 11:36:10 --> Controller Class Initialized
INFO - 2022-06-21 11:36:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 11:36:10 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-21 11:36:10 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-21 11:36:10 --> Final output sent to browser
DEBUG - 2022-06-21 11:36:10 --> Total execution time: 0.2543
INFO - 2022-06-21 11:36:26 --> Config Class Initialized
INFO - 2022-06-21 11:36:26 --> Hooks Class Initialized
DEBUG - 2022-06-21 11:36:26 --> UTF-8 Support Enabled
INFO - 2022-06-21 11:36:26 --> Utf8 Class Initialized
INFO - 2022-06-21 11:36:26 --> URI Class Initialized
INFO - 2022-06-21 11:36:26 --> Router Class Initialized
INFO - 2022-06-21 11:36:26 --> Output Class Initialized
INFO - 2022-06-21 11:36:26 --> Security Class Initialized
DEBUG - 2022-06-21 11:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 11:36:26 --> Input Class Initialized
INFO - 2022-06-21 11:36:26 --> Language Class Initialized
INFO - 2022-06-21 11:36:26 --> Loader Class Initialized
INFO - 2022-06-21 11:36:26 --> Helper loaded: url_helper
INFO - 2022-06-21 11:36:26 --> Helper loaded: file_helper
INFO - 2022-06-21 11:36:26 --> Database Driver Class Initialized
INFO - 2022-06-21 11:36:26 --> Email Class Initialized
DEBUG - 2022-06-21 11:36:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 11:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 11:36:26 --> Controller Class Initialized
INFO - 2022-06-21 11:36:26 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 11:36:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 11:36:26 --> test
ERROR - 2022-06-21 11:36:26 --> Query error: Column 'ud_name' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_name`, `ud_age`) VALUES (NULL, NULL)
INFO - 2022-06-21 11:36:26 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-21 11:37:40 --> Config Class Initialized
INFO - 2022-06-21 11:37:40 --> Hooks Class Initialized
DEBUG - 2022-06-21 11:37:40 --> UTF-8 Support Enabled
INFO - 2022-06-21 11:37:40 --> Config Class Initialized
INFO - 2022-06-21 11:37:40 --> Utf8 Class Initialized
INFO - 2022-06-21 11:37:40 --> Hooks Class Initialized
INFO - 2022-06-21 11:37:40 --> URI Class Initialized
DEBUG - 2022-06-21 11:37:40 --> UTF-8 Support Enabled
INFO - 2022-06-21 11:37:40 --> Router Class Initialized
INFO - 2022-06-21 11:37:40 --> Utf8 Class Initialized
INFO - 2022-06-21 11:37:40 --> Output Class Initialized
INFO - 2022-06-21 11:37:40 --> URI Class Initialized
INFO - 2022-06-21 11:37:40 --> Security Class Initialized
INFO - 2022-06-21 11:37:40 --> Router Class Initialized
DEBUG - 2022-06-21 11:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 11:37:40 --> Input Class Initialized
INFO - 2022-06-21 11:37:40 --> Output Class Initialized
INFO - 2022-06-21 11:37:40 --> Language Class Initialized
INFO - 2022-06-21 11:37:40 --> Security Class Initialized
DEBUG - 2022-06-21 11:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 11:37:40 --> Input Class Initialized
INFO - 2022-06-21 11:37:40 --> Loader Class Initialized
INFO - 2022-06-21 11:37:40 --> Language Class Initialized
INFO - 2022-06-21 11:37:40 --> Loader Class Initialized
INFO - 2022-06-21 11:37:40 --> Helper loaded: url_helper
INFO - 2022-06-21 11:37:40 --> Helper loaded: url_helper
INFO - 2022-06-21 11:37:40 --> Helper loaded: file_helper
INFO - 2022-06-21 11:37:40 --> Helper loaded: file_helper
INFO - 2022-06-21 11:37:40 --> Database Driver Class Initialized
INFO - 2022-06-21 11:37:40 --> Database Driver Class Initialized
INFO - 2022-06-21 11:37:40 --> Email Class Initialized
DEBUG - 2022-06-21 11:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 11:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 11:37:40 --> Controller Class Initialized
INFO - 2022-06-21 11:37:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 11:37:40 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-21 11:37:40 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-21 11:37:40 --> Final output sent to browser
DEBUG - 2022-06-21 11:37:40 --> Total execution time: 0.2082
INFO - 2022-06-21 11:37:40 --> Email Class Initialized
DEBUG - 2022-06-21 11:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 11:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 11:37:40 --> Controller Class Initialized
INFO - 2022-06-21 11:37:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 11:37:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 11:37:40 --> test
INFO - 2022-06-21 11:37:40 --> Final output sent to browser
DEBUG - 2022-06-21 11:37:40 --> Total execution time: 0.2628
INFO - 2022-06-21 11:37:49 --> Config Class Initialized
INFO - 2022-06-21 11:37:49 --> Hooks Class Initialized
DEBUG - 2022-06-21 11:37:49 --> UTF-8 Support Enabled
INFO - 2022-06-21 11:37:49 --> Utf8 Class Initialized
INFO - 2022-06-21 11:37:49 --> URI Class Initialized
INFO - 2022-06-21 11:37:49 --> Router Class Initialized
INFO - 2022-06-21 11:37:49 --> Output Class Initialized
INFO - 2022-06-21 11:37:49 --> Security Class Initialized
DEBUG - 2022-06-21 11:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 11:37:49 --> Input Class Initialized
INFO - 2022-06-21 11:37:49 --> Language Class Initialized
INFO - 2022-06-21 11:37:49 --> Loader Class Initialized
INFO - 2022-06-21 11:37:49 --> Helper loaded: url_helper
INFO - 2022-06-21 11:37:49 --> Helper loaded: file_helper
INFO - 2022-06-21 11:37:49 --> Database Driver Class Initialized
INFO - 2022-06-21 11:37:49 --> Email Class Initialized
DEBUG - 2022-06-21 11:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 11:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 11:37:49 --> Controller Class Initialized
INFO - 2022-06-21 11:37:49 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 11:37:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 11:37:49 --> test
ERROR - 2022-06-21 11:37:49 --> Query error: Column 'ud_name' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_name`, `ud_age`) VALUES (NULL, NULL)
INFO - 2022-06-21 11:37:49 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-21 11:38:09 --> Config Class Initialized
INFO - 2022-06-21 11:38:09 --> Hooks Class Initialized
DEBUG - 2022-06-21 11:38:09 --> UTF-8 Support Enabled
INFO - 2022-06-21 11:38:09 --> Utf8 Class Initialized
INFO - 2022-06-21 11:38:09 --> URI Class Initialized
INFO - 2022-06-21 11:38:09 --> Router Class Initialized
INFO - 2022-06-21 11:38:09 --> Output Class Initialized
INFO - 2022-06-21 11:38:09 --> Security Class Initialized
DEBUG - 2022-06-21 11:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 11:38:09 --> Input Class Initialized
INFO - 2022-06-21 11:38:09 --> Language Class Initialized
INFO - 2022-06-21 11:38:09 --> Loader Class Initialized
INFO - 2022-06-21 11:38:09 --> Helper loaded: url_helper
INFO - 2022-06-21 11:38:09 --> Helper loaded: file_helper
INFO - 2022-06-21 11:38:09 --> Database Driver Class Initialized
INFO - 2022-06-21 11:38:09 --> Email Class Initialized
DEBUG - 2022-06-21 11:38:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 11:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 11:38:09 --> Controller Class Initialized
INFO - 2022-06-21 11:38:09 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 11:38:09 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-21 11:38:09 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-21 11:38:09 --> Final output sent to browser
DEBUG - 2022-06-21 11:38:09 --> Total execution time: 0.1733
INFO - 2022-06-21 11:38:13 --> Config Class Initialized
INFO - 2022-06-21 11:38:13 --> Hooks Class Initialized
DEBUG - 2022-06-21 11:38:13 --> UTF-8 Support Enabled
INFO - 2022-06-21 11:38:13 --> Utf8 Class Initialized
INFO - 2022-06-21 11:38:13 --> URI Class Initialized
INFO - 2022-06-21 11:38:13 --> Router Class Initialized
INFO - 2022-06-21 11:38:13 --> Output Class Initialized
INFO - 2022-06-21 11:38:13 --> Security Class Initialized
DEBUG - 2022-06-21 11:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 11:38:13 --> Input Class Initialized
INFO - 2022-06-21 11:38:13 --> Language Class Initialized
INFO - 2022-06-21 11:38:13 --> Loader Class Initialized
INFO - 2022-06-21 11:38:13 --> Helper loaded: url_helper
INFO - 2022-06-21 11:38:13 --> Helper loaded: file_helper
INFO - 2022-06-21 11:38:13 --> Database Driver Class Initialized
INFO - 2022-06-21 11:38:14 --> Email Class Initialized
DEBUG - 2022-06-21 11:38:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 11:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 11:38:14 --> Controller Class Initialized
INFO - 2022-06-21 11:38:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 11:38:14 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-21 11:38:14 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-21 11:38:14 --> Final output sent to browser
DEBUG - 2022-06-21 11:38:14 --> Total execution time: 0.1589
INFO - 2022-06-21 11:38:27 --> Config Class Initialized
INFO - 2022-06-21 11:38:27 --> Hooks Class Initialized
DEBUG - 2022-06-21 11:38:27 --> UTF-8 Support Enabled
INFO - 2022-06-21 11:38:27 --> Utf8 Class Initialized
INFO - 2022-06-21 11:38:27 --> URI Class Initialized
INFO - 2022-06-21 11:38:27 --> Router Class Initialized
INFO - 2022-06-21 11:38:27 --> Output Class Initialized
INFO - 2022-06-21 11:38:27 --> Security Class Initialized
DEBUG - 2022-06-21 11:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 11:38:27 --> Input Class Initialized
INFO - 2022-06-21 11:38:27 --> Language Class Initialized
INFO - 2022-06-21 11:38:27 --> Loader Class Initialized
INFO - 2022-06-21 11:38:27 --> Config Class Initialized
INFO - 2022-06-21 11:38:27 --> Hooks Class Initialized
INFO - 2022-06-21 11:38:27 --> Helper loaded: url_helper
DEBUG - 2022-06-21 11:38:27 --> UTF-8 Support Enabled
INFO - 2022-06-21 11:38:27 --> Helper loaded: file_helper
INFO - 2022-06-21 11:38:27 --> Utf8 Class Initialized
INFO - 2022-06-21 11:38:27 --> URI Class Initialized
INFO - 2022-06-21 11:38:27 --> Database Driver Class Initialized
INFO - 2022-06-21 11:38:27 --> Router Class Initialized
INFO - 2022-06-21 11:38:27 --> Output Class Initialized
INFO - 2022-06-21 11:38:27 --> Security Class Initialized
DEBUG - 2022-06-21 11:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 11:38:27 --> Input Class Initialized
INFO - 2022-06-21 11:38:27 --> Language Class Initialized
INFO - 2022-06-21 11:38:27 --> Loader Class Initialized
INFO - 2022-06-21 11:38:27 --> Helper loaded: url_helper
INFO - 2022-06-21 11:38:27 --> Helper loaded: file_helper
INFO - 2022-06-21 11:38:27 --> Database Driver Class Initialized
INFO - 2022-06-21 11:38:27 --> Email Class Initialized
DEBUG - 2022-06-21 11:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 11:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 11:38:27 --> Controller Class Initialized
INFO - 2022-06-21 11:38:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 11:38:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 11:38:27 --> test
INFO - 2022-06-21 11:38:27 --> Final output sent to browser
DEBUG - 2022-06-21 11:38:27 --> Total execution time: 0.1784
INFO - 2022-06-21 11:38:27 --> Email Class Initialized
DEBUG - 2022-06-21 11:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 11:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 11:38:27 --> Controller Class Initialized
INFO - 2022-06-21 11:38:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 11:38:27 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-21 11:38:27 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-21 11:38:27 --> Final output sent to browser
DEBUG - 2022-06-21 11:38:27 --> Total execution time: 0.1837
INFO - 2022-06-21 11:38:35 --> Config Class Initialized
INFO - 2022-06-21 11:38:35 --> Hooks Class Initialized
DEBUG - 2022-06-21 11:38:35 --> UTF-8 Support Enabled
INFO - 2022-06-21 11:38:35 --> Utf8 Class Initialized
INFO - 2022-06-21 11:38:35 --> URI Class Initialized
INFO - 2022-06-21 11:38:35 --> Router Class Initialized
INFO - 2022-06-21 11:38:35 --> Output Class Initialized
INFO - 2022-06-21 11:38:35 --> Security Class Initialized
DEBUG - 2022-06-21 11:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 11:38:35 --> Input Class Initialized
INFO - 2022-06-21 11:38:35 --> Language Class Initialized
INFO - 2022-06-21 11:38:35 --> Loader Class Initialized
INFO - 2022-06-21 11:38:35 --> Helper loaded: url_helper
INFO - 2022-06-21 11:38:35 --> Helper loaded: file_helper
INFO - 2022-06-21 11:38:35 --> Database Driver Class Initialized
INFO - 2022-06-21 11:38:35 --> Email Class Initialized
DEBUG - 2022-06-21 11:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 11:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 11:38:35 --> Controller Class Initialized
INFO - 2022-06-21 11:38:35 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 11:38:35 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-21 11:38:35 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-21 11:38:35 --> Final output sent to browser
DEBUG - 2022-06-21 11:38:35 --> Total execution time: 0.1097
INFO - 2022-06-21 12:23:44 --> Config Class Initialized
INFO - 2022-06-21 12:23:44 --> Hooks Class Initialized
DEBUG - 2022-06-21 12:23:44 --> UTF-8 Support Enabled
INFO - 2022-06-21 12:23:44 --> Utf8 Class Initialized
INFO - 2022-06-21 12:23:44 --> URI Class Initialized
INFO - 2022-06-21 12:23:44 --> Router Class Initialized
INFO - 2022-06-21 12:23:44 --> Output Class Initialized
INFO - 2022-06-21 12:23:44 --> Security Class Initialized
DEBUG - 2022-06-21 12:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 12:23:44 --> Input Class Initialized
INFO - 2022-06-21 12:23:44 --> Language Class Initialized
INFO - 2022-06-21 12:23:44 --> Loader Class Initialized
INFO - 2022-06-21 12:23:44 --> Helper loaded: url_helper
INFO - 2022-06-21 12:23:44 --> Helper loaded: file_helper
INFO - 2022-06-21 12:23:44 --> Database Driver Class Initialized
INFO - 2022-06-21 12:23:44 --> Config Class Initialized
INFO - 2022-06-21 12:23:44 --> Hooks Class Initialized
DEBUG - 2022-06-21 12:23:44 --> UTF-8 Support Enabled
INFO - 2022-06-21 12:23:44 --> Utf8 Class Initialized
INFO - 2022-06-21 12:23:44 --> Email Class Initialized
DEBUG - 2022-06-21 12:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 12:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 12:23:44 --> Controller Class Initialized
INFO - 2022-06-21 12:23:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 12:23:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 12:23:44 --> test
INFO - 2022-06-21 12:23:44 --> URI Class Initialized
INFO - 2022-06-21 12:23:44 --> Router Class Initialized
INFO - 2022-06-21 12:23:44 --> Output Class Initialized
INFO - 2022-06-21 12:23:44 --> Security Class Initialized
DEBUG - 2022-06-21 12:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 12:23:44 --> Input Class Initialized
INFO - 2022-06-21 12:23:44 --> Language Class Initialized
INFO - 2022-06-21 12:23:44 --> Loader Class Initialized
INFO - 2022-06-21 12:23:44 --> Helper loaded: url_helper
INFO - 2022-06-21 12:23:44 --> Helper loaded: file_helper
ERROR - 2022-06-21 12:23:44 --> Query error: Column 'ud_gender' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_name`, `ud_age`, `ud_gender`) VALUES ('shibil tt', '22', NULL)
INFO - 2022-06-21 12:23:44 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-21 12:23:44 --> Database Driver Class Initialized
INFO - 2022-06-21 12:23:44 --> Email Class Initialized
DEBUG - 2022-06-21 12:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 12:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 12:23:45 --> Controller Class Initialized
INFO - 2022-06-21 12:23:45 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 12:23:45 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-21 12:23:45 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-21 12:23:45 --> Final output sent to browser
DEBUG - 2022-06-21 12:23:45 --> Total execution time: 0.1919
INFO - 2022-06-21 12:23:49 --> Config Class Initialized
INFO - 2022-06-21 12:23:49 --> Hooks Class Initialized
DEBUG - 2022-06-21 12:23:49 --> UTF-8 Support Enabled
INFO - 2022-06-21 12:23:49 --> Utf8 Class Initialized
INFO - 2022-06-21 12:23:49 --> URI Class Initialized
INFO - 2022-06-21 12:23:49 --> Router Class Initialized
INFO - 2022-06-21 12:23:49 --> Output Class Initialized
INFO - 2022-06-21 12:23:49 --> Security Class Initialized
DEBUG - 2022-06-21 12:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 12:23:49 --> Input Class Initialized
INFO - 2022-06-21 12:23:49 --> Language Class Initialized
INFO - 2022-06-21 12:23:49 --> Loader Class Initialized
INFO - 2022-06-21 12:23:49 --> Helper loaded: url_helper
INFO - 2022-06-21 12:23:49 --> Helper loaded: file_helper
INFO - 2022-06-21 12:23:49 --> Database Driver Class Initialized
INFO - 2022-06-21 12:23:49 --> Email Class Initialized
DEBUG - 2022-06-21 12:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 12:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 12:23:49 --> Controller Class Initialized
INFO - 2022-06-21 12:23:49 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 12:23:49 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-21 12:23:49 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-21 12:23:49 --> Final output sent to browser
DEBUG - 2022-06-21 12:23:49 --> Total execution time: 0.0749
INFO - 2022-06-21 12:24:17 --> Config Class Initialized
INFO - 2022-06-21 12:24:17 --> Hooks Class Initialized
DEBUG - 2022-06-21 12:24:17 --> UTF-8 Support Enabled
INFO - 2022-06-21 12:24:17 --> Utf8 Class Initialized
INFO - 2022-06-21 12:24:17 --> URI Class Initialized
INFO - 2022-06-21 12:24:17 --> Router Class Initialized
INFO - 2022-06-21 12:24:17 --> Output Class Initialized
INFO - 2022-06-21 12:24:17 --> Security Class Initialized
DEBUG - 2022-06-21 12:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 12:24:17 --> Input Class Initialized
INFO - 2022-06-21 12:24:17 --> Language Class Initialized
INFO - 2022-06-21 12:24:17 --> Loader Class Initialized
INFO - 2022-06-21 12:24:17 --> Helper loaded: url_helper
INFO - 2022-06-21 12:24:17 --> Helper loaded: file_helper
INFO - 2022-06-21 12:24:17 --> Database Driver Class Initialized
INFO - 2022-06-21 12:24:18 --> Email Class Initialized
DEBUG - 2022-06-21 12:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 12:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 12:24:18 --> Controller Class Initialized
INFO - 2022-06-21 12:24:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 12:24:18 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-21 12:24:18 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-21 12:24:18 --> Final output sent to browser
DEBUG - 2022-06-21 12:24:18 --> Total execution time: 0.1337
INFO - 2022-06-21 12:24:49 --> Config Class Initialized
INFO - 2022-06-21 12:24:49 --> Hooks Class Initialized
INFO - 2022-06-21 12:24:49 --> Config Class Initialized
DEBUG - 2022-06-21 12:24:49 --> UTF-8 Support Enabled
INFO - 2022-06-21 12:24:49 --> Hooks Class Initialized
INFO - 2022-06-21 12:24:49 --> Utf8 Class Initialized
DEBUG - 2022-06-21 12:24:49 --> UTF-8 Support Enabled
INFO - 2022-06-21 12:24:49 --> URI Class Initialized
INFO - 2022-06-21 12:24:49 --> Utf8 Class Initialized
INFO - 2022-06-21 12:24:49 --> URI Class Initialized
INFO - 2022-06-21 12:24:49 --> Router Class Initialized
INFO - 2022-06-21 12:24:49 --> Router Class Initialized
INFO - 2022-06-21 12:24:49 --> Output Class Initialized
INFO - 2022-06-21 12:24:49 --> Output Class Initialized
INFO - 2022-06-21 12:24:49 --> Security Class Initialized
INFO - 2022-06-21 12:24:49 --> Security Class Initialized
DEBUG - 2022-06-21 12:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 12:24:49 --> Input Class Initialized
INFO - 2022-06-21 12:24:49 --> Input Class Initialized
INFO - 2022-06-21 12:24:49 --> Language Class Initialized
INFO - 2022-06-21 12:24:49 --> Language Class Initialized
INFO - 2022-06-21 12:24:49 --> Loader Class Initialized
INFO - 2022-06-21 12:24:49 --> Loader Class Initialized
INFO - 2022-06-21 12:24:49 --> Helper loaded: url_helper
INFO - 2022-06-21 12:24:49 --> Helper loaded: url_helper
INFO - 2022-06-21 12:24:49 --> Helper loaded: file_helper
INFO - 2022-06-21 12:24:49 --> Helper loaded: file_helper
INFO - 2022-06-21 12:24:49 --> Database Driver Class Initialized
INFO - 2022-06-21 12:24:49 --> Database Driver Class Initialized
INFO - 2022-06-21 12:24:49 --> Email Class Initialized
DEBUG - 2022-06-21 12:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 12:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 12:24:49 --> Controller Class Initialized
INFO - 2022-06-21 12:24:49 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 12:24:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 12:24:49 --> test
INFO - 2022-06-21 12:24:49 --> Final output sent to browser
DEBUG - 2022-06-21 12:24:49 --> Total execution time: 0.0240
INFO - 2022-06-21 12:24:50 --> Email Class Initialized
DEBUG - 2022-06-21 12:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 12:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 12:24:50 --> Controller Class Initialized
INFO - 2022-06-21 12:24:50 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 12:24:50 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-21 12:24:50 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-21 12:24:50 --> Final output sent to browser
DEBUG - 2022-06-21 12:24:50 --> Total execution time: 0.6283
INFO - 2022-06-21 12:39:11 --> Config Class Initialized
INFO - 2022-06-21 12:39:11 --> Hooks Class Initialized
DEBUG - 2022-06-21 12:39:11 --> UTF-8 Support Enabled
INFO - 2022-06-21 12:39:11 --> Utf8 Class Initialized
INFO - 2022-06-21 12:39:11 --> URI Class Initialized
INFO - 2022-06-21 12:39:11 --> Router Class Initialized
INFO - 2022-06-21 12:39:11 --> Output Class Initialized
INFO - 2022-06-21 12:39:11 --> Security Class Initialized
DEBUG - 2022-06-21 12:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 12:39:11 --> Input Class Initialized
INFO - 2022-06-21 12:39:11 --> Language Class Initialized
INFO - 2022-06-21 12:39:11 --> Loader Class Initialized
INFO - 2022-06-21 12:39:11 --> Helper loaded: url_helper
INFO - 2022-06-21 12:39:11 --> Helper loaded: file_helper
INFO - 2022-06-21 12:39:11 --> Database Driver Class Initialized
INFO - 2022-06-21 12:39:11 --> Email Class Initialized
DEBUG - 2022-06-21 12:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 12:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 12:39:11 --> Controller Class Initialized
INFO - 2022-06-21 12:39:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 12:39:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-21 12:39:11 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-21 12:39:11 --> Final output sent to browser
DEBUG - 2022-06-21 12:39:11 --> Total execution time: 0.2656
INFO - 2022-06-21 12:39:22 --> Config Class Initialized
INFO - 2022-06-21 12:39:22 --> Hooks Class Initialized
DEBUG - 2022-06-21 12:39:22 --> UTF-8 Support Enabled
INFO - 2022-06-21 12:39:22 --> Utf8 Class Initialized
INFO - 2022-06-21 12:39:22 --> URI Class Initialized
INFO - 2022-06-21 12:39:22 --> Config Class Initialized
INFO - 2022-06-21 12:39:22 --> Hooks Class Initialized
INFO - 2022-06-21 12:39:22 --> Router Class Initialized
DEBUG - 2022-06-21 12:39:22 --> UTF-8 Support Enabled
INFO - 2022-06-21 12:39:22 --> Utf8 Class Initialized
INFO - 2022-06-21 12:39:22 --> Output Class Initialized
INFO - 2022-06-21 12:39:22 --> URI Class Initialized
INFO - 2022-06-21 12:39:22 --> Security Class Initialized
DEBUG - 2022-06-21 12:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 12:39:22 --> Router Class Initialized
INFO - 2022-06-21 12:39:22 --> Input Class Initialized
INFO - 2022-06-21 12:39:22 --> Output Class Initialized
INFO - 2022-06-21 12:39:22 --> Language Class Initialized
INFO - 2022-06-21 12:39:22 --> Security Class Initialized
INFO - 2022-06-21 12:39:22 --> Loader Class Initialized
DEBUG - 2022-06-21 12:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 12:39:22 --> Input Class Initialized
INFO - 2022-06-21 12:39:22 --> Helper loaded: url_helper
INFO - 2022-06-21 12:39:22 --> Language Class Initialized
INFO - 2022-06-21 12:39:22 --> Helper loaded: file_helper
INFO - 2022-06-21 12:39:22 --> Loader Class Initialized
INFO - 2022-06-21 12:39:22 --> Database Driver Class Initialized
INFO - 2022-06-21 12:39:22 --> Helper loaded: url_helper
INFO - 2022-06-21 12:39:22 --> Helper loaded: file_helper
INFO - 2022-06-21 12:39:22 --> Database Driver Class Initialized
INFO - 2022-06-21 12:39:22 --> Email Class Initialized
DEBUG - 2022-06-21 12:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 12:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 12:39:22 --> Controller Class Initialized
INFO - 2022-06-21 12:39:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 12:39:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 12:39:22 --> test
INFO - 2022-06-21 12:39:23 --> Email Class Initialized
DEBUG - 2022-06-21 12:39:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 12:39:23 --> Final output sent to browser
DEBUG - 2022-06-21 12:39:23 --> Total execution time: 0.1599
INFO - 2022-06-21 12:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 12:39:23 --> Controller Class Initialized
INFO - 2022-06-21 12:39:23 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 12:39:23 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-21 12:39:23 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-21 12:39:23 --> Final output sent to browser
DEBUG - 2022-06-21 12:39:23 --> Total execution time: 0.1619
INFO - 2022-06-21 12:40:37 --> Config Class Initialized
INFO - 2022-06-21 12:40:37 --> Hooks Class Initialized
DEBUG - 2022-06-21 12:40:37 --> UTF-8 Support Enabled
INFO - 2022-06-21 12:40:37 --> Utf8 Class Initialized
INFO - 2022-06-21 12:40:37 --> URI Class Initialized
INFO - 2022-06-21 12:40:37 --> Router Class Initialized
INFO - 2022-06-21 12:40:37 --> Output Class Initialized
INFO - 2022-06-21 12:40:37 --> Security Class Initialized
DEBUG - 2022-06-21 12:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 12:40:37 --> Input Class Initialized
INFO - 2022-06-21 12:40:37 --> Language Class Initialized
INFO - 2022-06-21 12:40:37 --> Loader Class Initialized
INFO - 2022-06-21 12:40:37 --> Helper loaded: url_helper
INFO - 2022-06-21 12:40:37 --> Helper loaded: file_helper
INFO - 2022-06-21 12:40:37 --> Database Driver Class Initialized
INFO - 2022-06-21 12:40:37 --> Email Class Initialized
DEBUG - 2022-06-21 12:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 12:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 12:40:37 --> Controller Class Initialized
INFO - 2022-06-21 12:40:37 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 12:40:37 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-21 12:40:37 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-21 12:40:37 --> Final output sent to browser
DEBUG - 2022-06-21 12:40:37 --> Total execution time: 0.0906
INFO - 2022-06-21 12:40:40 --> Config Class Initialized
INFO - 2022-06-21 12:40:40 --> Hooks Class Initialized
DEBUG - 2022-06-21 12:40:40 --> UTF-8 Support Enabled
INFO - 2022-06-21 12:40:40 --> Utf8 Class Initialized
INFO - 2022-06-21 12:40:40 --> URI Class Initialized
INFO - 2022-06-21 12:40:40 --> Router Class Initialized
INFO - 2022-06-21 12:40:40 --> Output Class Initialized
INFO - 2022-06-21 12:40:40 --> Security Class Initialized
DEBUG - 2022-06-21 12:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 12:40:40 --> Input Class Initialized
INFO - 2022-06-21 12:40:40 --> Language Class Initialized
INFO - 2022-06-21 12:40:40 --> Loader Class Initialized
INFO - 2022-06-21 12:40:40 --> Helper loaded: url_helper
INFO - 2022-06-21 12:40:40 --> Helper loaded: file_helper
INFO - 2022-06-21 12:40:40 --> Database Driver Class Initialized
INFO - 2022-06-21 12:40:40 --> Email Class Initialized
DEBUG - 2022-06-21 12:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 12:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 12:40:40 --> Controller Class Initialized
INFO - 2022-06-21 12:40:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 12:40:40 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-21 12:40:40 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-21 12:40:40 --> Final output sent to browser
DEBUG - 2022-06-21 12:40:40 --> Total execution time: 0.1547
INFO - 2022-06-21 12:40:56 --> Config Class Initialized
INFO - 2022-06-21 12:40:56 --> Hooks Class Initialized
DEBUG - 2022-06-21 12:40:56 --> UTF-8 Support Enabled
INFO - 2022-06-21 12:40:56 --> Config Class Initialized
INFO - 2022-06-21 12:40:56 --> Utf8 Class Initialized
INFO - 2022-06-21 12:40:56 --> Hooks Class Initialized
INFO - 2022-06-21 12:40:56 --> URI Class Initialized
DEBUG - 2022-06-21 12:40:56 --> UTF-8 Support Enabled
INFO - 2022-06-21 12:40:56 --> Utf8 Class Initialized
INFO - 2022-06-21 12:40:56 --> Router Class Initialized
INFO - 2022-06-21 12:40:56 --> URI Class Initialized
INFO - 2022-06-21 12:40:56 --> Output Class Initialized
INFO - 2022-06-21 12:40:56 --> Security Class Initialized
INFO - 2022-06-21 12:40:56 --> Router Class Initialized
DEBUG - 2022-06-21 12:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 12:40:56 --> Input Class Initialized
INFO - 2022-06-21 12:40:56 --> Output Class Initialized
INFO - 2022-06-21 12:40:56 --> Language Class Initialized
INFO - 2022-06-21 12:40:56 --> Security Class Initialized
INFO - 2022-06-21 12:40:56 --> Loader Class Initialized
DEBUG - 2022-06-21 12:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 12:40:56 --> Input Class Initialized
INFO - 2022-06-21 12:40:56 --> Helper loaded: url_helper
INFO - 2022-06-21 12:40:56 --> Language Class Initialized
INFO - 2022-06-21 12:40:56 --> Helper loaded: file_helper
INFO - 2022-06-21 12:40:56 --> Loader Class Initialized
INFO - 2022-06-21 12:40:56 --> Database Driver Class Initialized
INFO - 2022-06-21 12:40:56 --> Helper loaded: url_helper
INFO - 2022-06-21 12:40:56 --> Helper loaded: file_helper
INFO - 2022-06-21 12:40:56 --> Database Driver Class Initialized
INFO - 2022-06-21 12:40:56 --> Email Class Initialized
INFO - 2022-06-21 12:40:56 --> Email Class Initialized
DEBUG - 2022-06-21 12:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-21 12:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 12:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 12:40:56 --> Controller Class Initialized
INFO - 2022-06-21 12:40:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 12:40:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 12:40:56 --> test
INFO - 2022-06-21 12:40:56 --> Final output sent to browser
DEBUG - 2022-06-21 12:40:56 --> Total execution time: 0.0807
INFO - 2022-06-21 12:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 12:40:56 --> Controller Class Initialized
INFO - 2022-06-21 12:40:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 12:40:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-21 12:40:56 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-21 12:40:56 --> Final output sent to browser
DEBUG - 2022-06-21 12:40:56 --> Total execution time: 0.0829
INFO - 2022-06-21 12:40:58 --> Config Class Initialized
INFO - 2022-06-21 12:40:58 --> Hooks Class Initialized
DEBUG - 2022-06-21 12:40:58 --> UTF-8 Support Enabled
INFO - 2022-06-21 12:40:58 --> Utf8 Class Initialized
INFO - 2022-06-21 12:40:58 --> URI Class Initialized
INFO - 2022-06-21 12:40:58 --> Router Class Initialized
INFO - 2022-06-21 12:40:58 --> Output Class Initialized
INFO - 2022-06-21 12:40:58 --> Security Class Initialized
DEBUG - 2022-06-21 12:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 12:40:58 --> Input Class Initialized
INFO - 2022-06-21 12:40:58 --> Language Class Initialized
INFO - 2022-06-21 12:40:58 --> Loader Class Initialized
INFO - 2022-06-21 12:40:58 --> Helper loaded: url_helper
INFO - 2022-06-21 12:40:58 --> Helper loaded: file_helper
INFO - 2022-06-21 12:40:58 --> Database Driver Class Initialized
INFO - 2022-06-21 12:40:58 --> Email Class Initialized
DEBUG - 2022-06-21 12:40:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 12:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 12:40:58 --> Controller Class Initialized
INFO - 2022-06-21 12:40:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 12:40:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-21 12:40:58 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-21 12:40:58 --> Final output sent to browser
DEBUG - 2022-06-21 12:40:58 --> Total execution time: 0.1412
INFO - 2022-06-21 12:50:14 --> Config Class Initialized
INFO - 2022-06-21 12:50:14 --> Hooks Class Initialized
DEBUG - 2022-06-21 12:50:14 --> UTF-8 Support Enabled
INFO - 2022-06-21 12:50:14 --> Utf8 Class Initialized
INFO - 2022-06-21 12:50:14 --> URI Class Initialized
INFO - 2022-06-21 12:50:14 --> Router Class Initialized
INFO - 2022-06-21 12:50:14 --> Output Class Initialized
INFO - 2022-06-21 12:50:14 --> Security Class Initialized
DEBUG - 2022-06-21 12:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 12:50:14 --> Input Class Initialized
INFO - 2022-06-21 12:50:14 --> Language Class Initialized
INFO - 2022-06-21 12:50:14 --> Loader Class Initialized
INFO - 2022-06-21 12:50:14 --> Helper loaded: url_helper
INFO - 2022-06-21 12:50:14 --> Helper loaded: file_helper
INFO - 2022-06-21 12:50:14 --> Database Driver Class Initialized
INFO - 2022-06-21 12:50:14 --> Email Class Initialized
DEBUG - 2022-06-21 12:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 12:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 12:50:14 --> Controller Class Initialized
INFO - 2022-06-21 12:50:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 12:50:14 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-21 12:50:14 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-21 12:50:14 --> Final output sent to browser
DEBUG - 2022-06-21 12:50:14 --> Total execution time: 0.2571
INFO - 2022-06-21 12:50:28 --> Config Class Initialized
INFO - 2022-06-21 12:50:28 --> Hooks Class Initialized
DEBUG - 2022-06-21 12:50:28 --> UTF-8 Support Enabled
INFO - 2022-06-21 12:50:28 --> Config Class Initialized
INFO - 2022-06-21 12:50:28 --> Utf8 Class Initialized
INFO - 2022-06-21 12:50:28 --> Hooks Class Initialized
INFO - 2022-06-21 12:50:28 --> URI Class Initialized
DEBUG - 2022-06-21 12:50:28 --> UTF-8 Support Enabled
INFO - 2022-06-21 12:50:28 --> Utf8 Class Initialized
INFO - 2022-06-21 12:50:28 --> Router Class Initialized
INFO - 2022-06-21 12:50:28 --> URI Class Initialized
INFO - 2022-06-21 12:50:28 --> Output Class Initialized
INFO - 2022-06-21 12:50:28 --> Router Class Initialized
INFO - 2022-06-21 12:50:28 --> Security Class Initialized
INFO - 2022-06-21 12:50:28 --> Output Class Initialized
DEBUG - 2022-06-21 12:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 12:50:28 --> Input Class Initialized
INFO - 2022-06-21 12:50:28 --> Security Class Initialized
INFO - 2022-06-21 12:50:28 --> Language Class Initialized
DEBUG - 2022-06-21 12:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 12:50:28 --> Input Class Initialized
INFO - 2022-06-21 12:50:28 --> Loader Class Initialized
INFO - 2022-06-21 12:50:28 --> Language Class Initialized
INFO - 2022-06-21 12:50:28 --> Helper loaded: url_helper
INFO - 2022-06-21 12:50:28 --> Loader Class Initialized
INFO - 2022-06-21 12:50:28 --> Helper loaded: file_helper
INFO - 2022-06-21 12:50:28 --> Helper loaded: url_helper
INFO - 2022-06-21 12:50:28 --> Database Driver Class Initialized
INFO - 2022-06-21 12:50:28 --> Helper loaded: file_helper
INFO - 2022-06-21 12:50:28 --> Database Driver Class Initialized
INFO - 2022-06-21 12:50:28 --> Email Class Initialized
DEBUG - 2022-06-21 12:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 12:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 12:50:28 --> Controller Class Initialized
INFO - 2022-06-21 12:50:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 12:50:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-21 12:50:28 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-21 12:50:28 --> Final output sent to browser
DEBUG - 2022-06-21 12:50:28 --> Total execution time: 0.0193
INFO - 2022-06-21 12:50:28 --> Email Class Initialized
DEBUG - 2022-06-21 12:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 12:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 12:50:28 --> Controller Class Initialized
INFO - 2022-06-21 12:50:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 12:50:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 12:50:28 --> test
INFO - 2022-06-21 12:50:28 --> Final output sent to browser
DEBUG - 2022-06-21 12:50:28 --> Total execution time: 0.1276
INFO - 2022-06-21 12:50:57 --> Config Class Initialized
INFO - 2022-06-21 12:50:57 --> Hooks Class Initialized
DEBUG - 2022-06-21 12:50:57 --> UTF-8 Support Enabled
INFO - 2022-06-21 12:50:57 --> Utf8 Class Initialized
INFO - 2022-06-21 12:50:57 --> Config Class Initialized
INFO - 2022-06-21 12:50:57 --> URI Class Initialized
INFO - 2022-06-21 12:50:57 --> Hooks Class Initialized
DEBUG - 2022-06-21 12:50:57 --> UTF-8 Support Enabled
INFO - 2022-06-21 12:50:57 --> Router Class Initialized
INFO - 2022-06-21 12:50:57 --> Utf8 Class Initialized
INFO - 2022-06-21 12:50:57 --> Output Class Initialized
INFO - 2022-06-21 12:50:57 --> URI Class Initialized
INFO - 2022-06-21 12:50:57 --> Security Class Initialized
INFO - 2022-06-21 12:50:57 --> Router Class Initialized
DEBUG - 2022-06-21 12:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 12:50:57 --> Output Class Initialized
INFO - 2022-06-21 12:50:57 --> Input Class Initialized
INFO - 2022-06-21 12:50:57 --> Security Class Initialized
INFO - 2022-06-21 12:50:57 --> Language Class Initialized
DEBUG - 2022-06-21 12:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 12:50:57 --> Loader Class Initialized
INFO - 2022-06-21 12:50:57 --> Input Class Initialized
INFO - 2022-06-21 12:50:57 --> Language Class Initialized
INFO - 2022-06-21 12:50:57 --> Helper loaded: url_helper
INFO - 2022-06-21 12:50:57 --> Loader Class Initialized
INFO - 2022-06-21 12:50:57 --> Helper loaded: file_helper
INFO - 2022-06-21 12:50:57 --> Helper loaded: url_helper
INFO - 2022-06-21 12:50:57 --> Database Driver Class Initialized
INFO - 2022-06-21 12:50:57 --> Helper loaded: file_helper
INFO - 2022-06-21 12:50:57 --> Database Driver Class Initialized
INFO - 2022-06-21 12:50:57 --> Email Class Initialized
INFO - 2022-06-21 12:50:57 --> Email Class Initialized
DEBUG - 2022-06-21 12:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-21 12:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 12:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 12:50:57 --> Controller Class Initialized
INFO - 2022-06-21 12:50:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 12:50:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 12:50:57 --> test
INFO - 2022-06-21 12:50:57 --> Final output sent to browser
DEBUG - 2022-06-21 12:50:57 --> Total execution time: 0.1375
INFO - 2022-06-21 12:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 12:50:57 --> Controller Class Initialized
INFO - 2022-06-21 12:50:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 12:50:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-21 12:50:57 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-21 12:50:57 --> Final output sent to browser
DEBUG - 2022-06-21 12:50:57 --> Total execution time: 0.1487
INFO - 2022-06-21 12:51:36 --> Config Class Initialized
INFO - 2022-06-21 12:51:36 --> Hooks Class Initialized
DEBUG - 2022-06-21 12:51:36 --> UTF-8 Support Enabled
INFO - 2022-06-21 12:51:36 --> Utf8 Class Initialized
INFO - 2022-06-21 12:51:36 --> URI Class Initialized
INFO - 2022-06-21 12:51:36 --> Router Class Initialized
INFO - 2022-06-21 12:51:36 --> Output Class Initialized
INFO - 2022-06-21 12:51:36 --> Security Class Initialized
DEBUG - 2022-06-21 12:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 12:51:36 --> Input Class Initialized
INFO - 2022-06-21 12:51:36 --> Language Class Initialized
INFO - 2022-06-21 12:51:36 --> Loader Class Initialized
INFO - 2022-06-21 12:51:36 --> Helper loaded: url_helper
INFO - 2022-06-21 12:51:36 --> Helper loaded: file_helper
INFO - 2022-06-21 12:51:36 --> Database Driver Class Initialized
INFO - 2022-06-21 12:51:36 --> Email Class Initialized
DEBUG - 2022-06-21 12:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 12:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 12:51:36 --> Controller Class Initialized
INFO - 2022-06-21 12:51:36 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 12:51:36 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-21 12:51:36 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-21 12:51:36 --> Final output sent to browser
DEBUG - 2022-06-21 12:51:36 --> Total execution time: 0.0597
INFO - 2022-06-21 12:51:40 --> Config Class Initialized
INFO - 2022-06-21 12:51:40 --> Hooks Class Initialized
DEBUG - 2022-06-21 12:51:40 --> UTF-8 Support Enabled
INFO - 2022-06-21 12:51:40 --> Utf8 Class Initialized
INFO - 2022-06-21 12:51:40 --> URI Class Initialized
INFO - 2022-06-21 12:51:40 --> Router Class Initialized
INFO - 2022-06-21 12:51:40 --> Output Class Initialized
INFO - 2022-06-21 12:51:40 --> Security Class Initialized
DEBUG - 2022-06-21 12:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 12:51:40 --> Input Class Initialized
INFO - 2022-06-21 12:51:40 --> Language Class Initialized
INFO - 2022-06-21 12:51:40 --> Loader Class Initialized
INFO - 2022-06-21 12:51:40 --> Helper loaded: url_helper
INFO - 2022-06-21 12:51:40 --> Helper loaded: file_helper
INFO - 2022-06-21 12:51:40 --> Database Driver Class Initialized
INFO - 2022-06-21 12:51:40 --> Email Class Initialized
DEBUG - 2022-06-21 12:51:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 12:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 12:51:40 --> Controller Class Initialized
INFO - 2022-06-21 12:51:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 12:51:40 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-21 12:51:40 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-21 12:51:40 --> Final output sent to browser
DEBUG - 2022-06-21 12:51:40 --> Total execution time: 0.1285
INFO - 2022-06-21 12:51:43 --> Config Class Initialized
INFO - 2022-06-21 12:51:43 --> Hooks Class Initialized
DEBUG - 2022-06-21 12:51:43 --> UTF-8 Support Enabled
INFO - 2022-06-21 12:51:43 --> Utf8 Class Initialized
INFO - 2022-06-21 12:51:43 --> URI Class Initialized
INFO - 2022-06-21 12:51:43 --> Router Class Initialized
INFO - 2022-06-21 12:51:43 --> Output Class Initialized
INFO - 2022-06-21 12:51:43 --> Security Class Initialized
DEBUG - 2022-06-21 12:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 12:51:43 --> Input Class Initialized
INFO - 2022-06-21 12:51:43 --> Language Class Initialized
INFO - 2022-06-21 12:51:43 --> Loader Class Initialized
INFO - 2022-06-21 12:51:43 --> Helper loaded: url_helper
INFO - 2022-06-21 12:51:43 --> Helper loaded: file_helper
INFO - 2022-06-21 12:51:43 --> Database Driver Class Initialized
INFO - 2022-06-21 12:51:43 --> Email Class Initialized
DEBUG - 2022-06-21 12:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 12:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 12:51:43 --> Controller Class Initialized
INFO - 2022-06-21 12:51:43 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 12:51:43 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-21 12:51:43 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-21 12:51:43 --> Final output sent to browser
DEBUG - 2022-06-21 12:51:43 --> Total execution time: 0.1537
INFO - 2022-06-21 12:51:46 --> Config Class Initialized
INFO - 2022-06-21 12:51:46 --> Hooks Class Initialized
DEBUG - 2022-06-21 12:51:46 --> UTF-8 Support Enabled
INFO - 2022-06-21 12:51:46 --> Utf8 Class Initialized
INFO - 2022-06-21 12:51:46 --> URI Class Initialized
INFO - 2022-06-21 12:51:46 --> Router Class Initialized
INFO - 2022-06-21 12:51:46 --> Output Class Initialized
INFO - 2022-06-21 12:51:46 --> Security Class Initialized
DEBUG - 2022-06-21 12:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 12:51:46 --> Input Class Initialized
INFO - 2022-06-21 12:51:46 --> Language Class Initialized
INFO - 2022-06-21 12:51:46 --> Loader Class Initialized
INFO - 2022-06-21 12:51:46 --> Helper loaded: url_helper
INFO - 2022-06-21 12:51:46 --> Helper loaded: file_helper
INFO - 2022-06-21 12:51:46 --> Database Driver Class Initialized
INFO - 2022-06-21 12:51:46 --> Email Class Initialized
DEBUG - 2022-06-21 12:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 12:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 12:51:46 --> Controller Class Initialized
INFO - 2022-06-21 12:51:46 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 12:51:46 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-21 12:51:46 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-21 12:51:46 --> Final output sent to browser
DEBUG - 2022-06-21 12:51:46 --> Total execution time: 0.1765
INFO - 2022-06-21 12:51:49 --> Config Class Initialized
INFO - 2022-06-21 12:51:49 --> Hooks Class Initialized
DEBUG - 2022-06-21 12:51:49 --> UTF-8 Support Enabled
INFO - 2022-06-21 12:51:49 --> Utf8 Class Initialized
INFO - 2022-06-21 12:51:49 --> URI Class Initialized
INFO - 2022-06-21 12:51:49 --> Router Class Initialized
INFO - 2022-06-21 12:51:49 --> Output Class Initialized
INFO - 2022-06-21 12:51:49 --> Security Class Initialized
DEBUG - 2022-06-21 12:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 12:51:49 --> Input Class Initialized
INFO - 2022-06-21 12:51:49 --> Language Class Initialized
INFO - 2022-06-21 12:51:49 --> Loader Class Initialized
INFO - 2022-06-21 12:51:49 --> Helper loaded: url_helper
INFO - 2022-06-21 12:51:49 --> Helper loaded: file_helper
INFO - 2022-06-21 12:51:49 --> Database Driver Class Initialized
INFO - 2022-06-21 12:51:49 --> Email Class Initialized
DEBUG - 2022-06-21 12:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 12:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 12:51:49 --> Controller Class Initialized
INFO - 2022-06-21 12:51:49 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 12:51:49 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-21 12:51:49 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-21 12:51:49 --> Final output sent to browser
DEBUG - 2022-06-21 12:51:49 --> Total execution time: 0.0374
INFO - 2022-06-21 12:51:58 --> Config Class Initialized
INFO - 2022-06-21 12:51:58 --> Hooks Class Initialized
DEBUG - 2022-06-21 12:51:58 --> UTF-8 Support Enabled
INFO - 2022-06-21 12:51:58 --> Config Class Initialized
INFO - 2022-06-21 12:51:58 --> Utf8 Class Initialized
INFO - 2022-06-21 12:51:58 --> Hooks Class Initialized
INFO - 2022-06-21 12:51:58 --> URI Class Initialized
DEBUG - 2022-06-21 12:51:58 --> UTF-8 Support Enabled
INFO - 2022-06-21 12:51:58 --> Utf8 Class Initialized
INFO - 2022-06-21 12:51:58 --> Router Class Initialized
INFO - 2022-06-21 12:51:58 --> URI Class Initialized
INFO - 2022-06-21 12:51:58 --> Output Class Initialized
INFO - 2022-06-21 12:51:58 --> Router Class Initialized
INFO - 2022-06-21 12:51:58 --> Security Class Initialized
INFO - 2022-06-21 12:51:58 --> Output Class Initialized
DEBUG - 2022-06-21 12:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 12:51:58 --> Security Class Initialized
INFO - 2022-06-21 12:51:58 --> Input Class Initialized
DEBUG - 2022-06-21 12:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 12:51:58 --> Language Class Initialized
INFO - 2022-06-21 12:51:58 --> Input Class Initialized
INFO - 2022-06-21 12:51:58 --> Language Class Initialized
INFO - 2022-06-21 12:51:58 --> Loader Class Initialized
INFO - 2022-06-21 12:51:58 --> Loader Class Initialized
INFO - 2022-06-21 12:51:58 --> Helper loaded: url_helper
INFO - 2022-06-21 12:51:58 --> Helper loaded: file_helper
INFO - 2022-06-21 12:51:58 --> Helper loaded: url_helper
INFO - 2022-06-21 12:51:58 --> Database Driver Class Initialized
INFO - 2022-06-21 12:51:58 --> Helper loaded: file_helper
INFO - 2022-06-21 12:51:58 --> Database Driver Class Initialized
INFO - 2022-06-21 12:51:58 --> Email Class Initialized
DEBUG - 2022-06-21 12:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 12:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 12:51:58 --> Controller Class Initialized
INFO - 2022-06-21 12:51:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 12:51:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 12:51:58 --> test
INFO - 2022-06-21 12:51:58 --> Final output sent to browser
DEBUG - 2022-06-21 12:51:58 --> Total execution time: 0.0335
INFO - 2022-06-21 12:51:58 --> Email Class Initialized
DEBUG - 2022-06-21 12:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 12:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 12:51:58 --> Controller Class Initialized
INFO - 2022-06-21 12:51:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 12:51:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-21 12:51:58 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-21 12:51:58 --> Final output sent to browser
DEBUG - 2022-06-21 12:51:58 --> Total execution time: 0.0717
INFO - 2022-06-21 12:53:13 --> Config Class Initialized
INFO - 2022-06-21 12:53:13 --> Hooks Class Initialized
DEBUG - 2022-06-21 12:53:13 --> UTF-8 Support Enabled
INFO - 2022-06-21 12:53:13 --> Utf8 Class Initialized
INFO - 2022-06-21 12:53:13 --> URI Class Initialized
INFO - 2022-06-21 12:53:13 --> Router Class Initialized
INFO - 2022-06-21 12:53:13 --> Output Class Initialized
INFO - 2022-06-21 12:53:13 --> Security Class Initialized
DEBUG - 2022-06-21 12:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 12:53:13 --> Input Class Initialized
INFO - 2022-06-21 12:53:13 --> Language Class Initialized
INFO - 2022-06-21 12:53:13 --> Loader Class Initialized
INFO - 2022-06-21 12:53:13 --> Helper loaded: url_helper
INFO - 2022-06-21 12:53:13 --> Helper loaded: file_helper
INFO - 2022-06-21 12:53:13 --> Database Driver Class Initialized
INFO - 2022-06-21 12:53:13 --> Email Class Initialized
DEBUG - 2022-06-21 12:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 12:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 12:53:13 --> Controller Class Initialized
INFO - 2022-06-21 12:53:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 12:53:13 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-21 12:53:13 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-21 12:53:13 --> Final output sent to browser
DEBUG - 2022-06-21 12:53:13 --> Total execution time: 0.0174
INFO - 2022-06-21 12:53:14 --> Config Class Initialized
INFO - 2022-06-21 12:53:14 --> Hooks Class Initialized
DEBUG - 2022-06-21 12:53:14 --> UTF-8 Support Enabled
INFO - 2022-06-21 12:53:14 --> Utf8 Class Initialized
INFO - 2022-06-21 12:53:14 --> URI Class Initialized
INFO - 2022-06-21 12:53:14 --> Router Class Initialized
INFO - 2022-06-21 12:53:14 --> Output Class Initialized
INFO - 2022-06-21 12:53:14 --> Security Class Initialized
DEBUG - 2022-06-21 12:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 12:53:14 --> Input Class Initialized
INFO - 2022-06-21 12:53:14 --> Language Class Initialized
INFO - 2022-06-21 12:53:14 --> Loader Class Initialized
INFO - 2022-06-21 12:53:14 --> Helper loaded: url_helper
INFO - 2022-06-21 12:53:14 --> Helper loaded: file_helper
INFO - 2022-06-21 12:53:14 --> Database Driver Class Initialized
INFO - 2022-06-21 12:53:14 --> Email Class Initialized
DEBUG - 2022-06-21 12:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 12:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 12:53:14 --> Controller Class Initialized
INFO - 2022-06-21 12:53:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 12:53:14 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-21 12:53:14 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-21 12:53:14 --> Final output sent to browser
DEBUG - 2022-06-21 12:53:14 --> Total execution time: 0.1448
INFO - 2022-06-21 12:53:19 --> Config Class Initialized
INFO - 2022-06-21 12:53:19 --> Hooks Class Initialized
DEBUG - 2022-06-21 12:53:19 --> UTF-8 Support Enabled
INFO - 2022-06-21 12:53:19 --> Utf8 Class Initialized
INFO - 2022-06-21 12:53:19 --> URI Class Initialized
INFO - 2022-06-21 12:53:19 --> Router Class Initialized
INFO - 2022-06-21 12:53:19 --> Output Class Initialized
INFO - 2022-06-21 12:53:19 --> Security Class Initialized
DEBUG - 2022-06-21 12:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 12:53:19 --> Input Class Initialized
INFO - 2022-06-21 12:53:19 --> Language Class Initialized
INFO - 2022-06-21 12:53:19 --> Loader Class Initialized
INFO - 2022-06-21 12:53:19 --> Helper loaded: url_helper
INFO - 2022-06-21 12:53:19 --> Helper loaded: file_helper
INFO - 2022-06-21 12:53:19 --> Database Driver Class Initialized
INFO - 2022-06-21 12:53:19 --> Email Class Initialized
DEBUG - 2022-06-21 12:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 12:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 12:53:19 --> Controller Class Initialized
INFO - 2022-06-21 12:53:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 12:53:19 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-21 12:53:19 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-21 12:53:19 --> Final output sent to browser
DEBUG - 2022-06-21 12:53:19 --> Total execution time: 0.0442
INFO - 2022-06-21 15:23:50 --> Config Class Initialized
INFO - 2022-06-21 15:23:50 --> Config Class Initialized
INFO - 2022-06-21 15:23:50 --> Hooks Class Initialized
INFO - 2022-06-21 15:23:50 --> Hooks Class Initialized
DEBUG - 2022-06-21 15:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 15:23:50 --> UTF-8 Support Enabled
INFO - 2022-06-21 15:23:50 --> Utf8 Class Initialized
INFO - 2022-06-21 15:23:50 --> Utf8 Class Initialized
INFO - 2022-06-21 15:23:50 --> URI Class Initialized
INFO - 2022-06-21 15:23:50 --> URI Class Initialized
INFO - 2022-06-21 15:23:50 --> Router Class Initialized
INFO - 2022-06-21 15:23:50 --> Router Class Initialized
INFO - 2022-06-21 15:23:50 --> Output Class Initialized
INFO - 2022-06-21 15:23:50 --> Output Class Initialized
INFO - 2022-06-21 15:23:50 --> Security Class Initialized
INFO - 2022-06-21 15:23:50 --> Security Class Initialized
DEBUG - 2022-06-21 15:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 15:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 15:23:50 --> Input Class Initialized
INFO - 2022-06-21 15:23:50 --> Input Class Initialized
INFO - 2022-06-21 15:23:50 --> Language Class Initialized
INFO - 2022-06-21 15:23:50 --> Language Class Initialized
INFO - 2022-06-21 15:23:51 --> Loader Class Initialized
INFO - 2022-06-21 15:23:51 --> Loader Class Initialized
INFO - 2022-06-21 15:23:51 --> Helper loaded: url_helper
INFO - 2022-06-21 15:23:51 --> Helper loaded: url_helper
INFO - 2022-06-21 15:23:51 --> Helper loaded: file_helper
INFO - 2022-06-21 15:23:51 --> Helper loaded: file_helper
INFO - 2022-06-21 15:23:51 --> Database Driver Class Initialized
INFO - 2022-06-21 15:23:51 --> Database Driver Class Initialized
INFO - 2022-06-21 15:23:51 --> Email Class Initialized
DEBUG - 2022-06-21 15:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 15:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 15:23:51 --> Controller Class Initialized
INFO - 2022-06-21 15:23:51 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 15:23:51 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-21 15:23:51 --> Email Class Initialized
DEBUG - 2022-06-21 15:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-21 15:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-21 15:23:51 --> Controller Class Initialized
INFO - 2022-06-21 15:23:51 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-21 15:23:51 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-21 15:23:51 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-21 15:23:51 --> Final output sent to browser
DEBUG - 2022-06-21 15:23:51 --> Total execution time: 1.1019
INFO - 2022-06-21 15:23:52 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-21 15:23:52 --> Final output sent to browser
DEBUG - 2022-06-21 15:23:52 --> Total execution time: 1.3867
INFO - 2022-06-21 15:23:52 --> Config Class Initialized
INFO - 2022-06-21 15:23:52 --> Hooks Class Initialized
DEBUG - 2022-06-21 15:23:52 --> UTF-8 Support Enabled
INFO - 2022-06-21 15:23:52 --> Utf8 Class Initialized
INFO - 2022-06-21 15:23:52 --> URI Class Initialized
INFO - 2022-06-21 15:23:52 --> Router Class Initialized
INFO - 2022-06-21 15:23:52 --> Output Class Initialized
INFO - 2022-06-21 15:23:52 --> Security Class Initialized
DEBUG - 2022-06-21 15:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 15:23:52 --> Input Class Initialized
INFO - 2022-06-21 15:23:52 --> Language Class Initialized
ERROR - 2022-06-21 15:23:52 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-21 15:23:52 --> Config Class Initialized
INFO - 2022-06-21 15:23:52 --> Hooks Class Initialized
DEBUG - 2022-06-21 15:23:52 --> UTF-8 Support Enabled
INFO - 2022-06-21 15:23:52 --> Utf8 Class Initialized
INFO - 2022-06-21 15:23:52 --> URI Class Initialized
INFO - 2022-06-21 15:23:52 --> Router Class Initialized
INFO - 2022-06-21 15:23:52 --> Output Class Initialized
INFO - 2022-06-21 15:23:52 --> Security Class Initialized
DEBUG - 2022-06-21 15:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-21 15:23:52 --> Input Class Initialized
INFO - 2022-06-21 15:23:52 --> Language Class Initialized
ERROR - 2022-06-21 15:23:52 --> 404 Page Not Found: Tokenctrl/localhost
