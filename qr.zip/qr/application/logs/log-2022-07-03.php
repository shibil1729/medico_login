<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-07-03 15:09:23 --> Config Class Initialized
INFO - 2022-07-03 15:09:23 --> Hooks Class Initialized
DEBUG - 2022-07-03 15:09:23 --> UTF-8 Support Enabled
INFO - 2022-07-03 15:09:23 --> Utf8 Class Initialized
INFO - 2022-07-03 15:09:23 --> URI Class Initialized
INFO - 2022-07-03 15:09:23 --> Router Class Initialized
INFO - 2022-07-03 15:09:23 --> Output Class Initialized
INFO - 2022-07-03 15:09:23 --> Security Class Initialized
DEBUG - 2022-07-03 15:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-03 15:09:23 --> Input Class Initialized
INFO - 2022-07-03 15:09:23 --> Language Class Initialized
INFO - 2022-07-03 15:09:23 --> Loader Class Initialized
INFO - 2022-07-03 15:09:23 --> Helper loaded: url_helper
INFO - 2022-07-03 15:09:23 --> Helper loaded: file_helper
INFO - 2022-07-03 15:09:23 --> Database Driver Class Initialized
INFO - 2022-07-03 15:09:24 --> Email Class Initialized
DEBUG - 2022-07-03 15:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-03 15:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-03 15:09:24 --> Controller Class Initialized
INFO - 2022-07-03 15:09:24 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-03 15:09:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-03 15:09:24 --> Severity: Notice --> Undefined variable: last_id C:\wamp64\www\qr\application\views\tokenscreen\Tokenscreen.php 281
INFO - 2022-07-03 15:09:24 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-03 15:09:24 --> Final output sent to browser
DEBUG - 2022-07-03 15:09:24 --> Total execution time: 1.2579
INFO - 2022-07-03 15:09:54 --> Config Class Initialized
INFO - 2022-07-03 15:09:54 --> Hooks Class Initialized
DEBUG - 2022-07-03 15:09:54 --> UTF-8 Support Enabled
INFO - 2022-07-03 15:09:54 --> Utf8 Class Initialized
INFO - 2022-07-03 15:09:54 --> URI Class Initialized
INFO - 2022-07-03 15:09:54 --> Router Class Initialized
INFO - 2022-07-03 15:09:54 --> Output Class Initialized
INFO - 2022-07-03 15:09:54 --> Security Class Initialized
DEBUG - 2022-07-03 15:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-03 15:09:54 --> Input Class Initialized
INFO - 2022-07-03 15:09:54 --> Language Class Initialized
INFO - 2022-07-03 15:09:54 --> Loader Class Initialized
INFO - 2022-07-03 15:09:54 --> Helper loaded: url_helper
INFO - 2022-07-03 15:09:54 --> Helper loaded: file_helper
INFO - 2022-07-03 15:09:54 --> Database Driver Class Initialized
INFO - 2022-07-03 15:09:55 --> Email Class Initialized
DEBUG - 2022-07-03 15:09:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-03 15:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-03 15:09:55 --> Controller Class Initialized
INFO - 2022-07-03 15:09:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-03 15:09:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-03 15:09:55 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-03 15:09:55 --> Final output sent to browser
DEBUG - 2022-07-03 15:09:55 --> Total execution time: 0.2440
