<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-07-17 00:20:31 --> Severity: Notice --> A non well formed numeric value encountered C:\wamp64\www\qr\application\controllers\Tokenctrl.php 417
INFO - 2022-07-17 00:20:31 --> Final output sent to browser
DEBUG - 2022-07-17 00:20:31 --> Total execution time: 0.1801
ERROR - 2022-07-17 00:20:33 --> Severity: Notice --> A non well formed numeric value encountered C:\wamp64\www\qr\application\controllers\Tokenctrl.php 417
INFO - 2022-07-17 00:20:33 --> Final output sent to browser
DEBUG - 2022-07-17 00:20:33 --> Total execution time: 0.1526
ERROR - 2022-07-17 00:20:35 --> Severity: Notice --> A non well formed numeric value encountered C:\wamp64\www\qr\application\controllers\Tokenctrl.php 417
INFO - 2022-07-17 00:20:35 --> Final output sent to browser
DEBUG - 2022-07-17 00:20:35 --> Total execution time: 0.1755
ERROR - 2022-07-17 00:20:36 --> Severity: Notice --> A non well formed numeric value encountered C:\wamp64\www\qr\application\controllers\Tokenctrl.php 417
INFO - 2022-07-17 00:20:36 --> Final output sent to browser
DEBUG - 2022-07-17 00:20:36 --> Total execution time: 0.1558
ERROR - 2022-07-17 00:20:36 --> Severity: Notice --> A non well formed numeric value encountered C:\wamp64\www\qr\application\controllers\Tokenctrl.php 417
INFO - 2022-07-17 00:20:36 --> Final output sent to browser
DEBUG - 2022-07-17 00:20:36 --> Total execution time: 0.1700
ERROR - 2022-07-17 00:20:37 --> Severity: Notice --> A non well formed numeric value encountered C:\wamp64\www\qr\application\controllers\Tokenctrl.php 417
INFO - 2022-07-17 00:20:37 --> Final output sent to browser
DEBUG - 2022-07-17 00:20:37 --> Total execution time: 0.1152
ERROR - 2022-07-17 00:20:37 --> Severity: Notice --> A non well formed numeric value encountered C:\wamp64\www\qr\application\controllers\Tokenctrl.php 417
INFO - 2022-07-17 00:20:37 --> Final output sent to browser
DEBUG - 2022-07-17 00:20:37 --> Total execution time: 0.1358
ERROR - 2022-07-17 00:20:38 --> Severity: Notice --> A non well formed numeric value encountered C:\wamp64\www\qr\application\controllers\Tokenctrl.php 417
INFO - 2022-07-17 00:20:38 --> Final output sent to browser
DEBUG - 2022-07-17 00:20:38 --> Total execution time: 0.1430
ERROR - 2022-07-17 00:23:46 --> Severity: Notice --> A non well formed numeric value encountered C:\wamp64\www\qr\application\controllers\Tokenctrl.php 417
INFO - 2022-07-17 00:23:46 --> Final output sent to browser
DEBUG - 2022-07-17 00:23:46 --> Total execution time: 0.1269
ERROR - 2022-07-17 00:24:08 --> Severity: Notice --> A non well formed numeric value encountered C:\wamp64\www\qr\application\controllers\Tokenctrl.php 417
INFO - 2022-07-17 00:24:08 --> Final output sent to browser
DEBUG - 2022-07-17 00:24:08 --> Total execution time: 0.1354
ERROR - 2022-07-17 00:24:11 --> Severity: Notice --> A non well formed numeric value encountered C:\wamp64\www\qr\application\controllers\Tokenctrl.php 417
INFO - 2022-07-17 00:24:11 --> Final output sent to browser
DEBUG - 2022-07-17 00:24:11 --> Total execution time: 0.1144
ERROR - 2022-07-17 00:24:13 --> Severity: Notice --> A non well formed numeric value encountered C:\wamp64\www\qr\application\controllers\Tokenctrl.php 417
INFO - 2022-07-17 00:24:13 --> Final output sent to browser
DEBUG - 2022-07-17 00:24:13 --> Total execution time: 0.0433
ERROR - 2022-07-17 00:24:15 --> Severity: Notice --> A non well formed numeric value encountered C:\wamp64\www\qr\application\controllers\Tokenctrl.php 417
INFO - 2022-07-17 00:24:15 --> Final output sent to browser
DEBUG - 2022-07-17 00:24:15 --> Total execution time: 0.1077
ERROR - 2022-07-17 00:24:15 --> Severity: Notice --> A non well formed numeric value encountered C:\wamp64\www\qr\application\controllers\Tokenctrl.php 417
INFO - 2022-07-17 00:24:15 --> Final output sent to browser
DEBUG - 2022-07-17 00:24:15 --> Total execution time: 0.1367
ERROR - 2022-07-17 00:24:15 --> Severity: Notice --> A non well formed numeric value encountered C:\wamp64\www\qr\application\controllers\Tokenctrl.php 417
INFO - 2022-07-17 00:24:15 --> Final output sent to browser
DEBUG - 2022-07-17 00:24:16 --> Total execution time: 0.1184
ERROR - 2022-07-17 00:24:16 --> Severity: Notice --> A non well formed numeric value encountered C:\wamp64\www\qr\application\controllers\Tokenctrl.php 417
INFO - 2022-07-17 00:24:16 --> Final output sent to browser
DEBUG - 2022-07-17 00:24:16 --> Total execution time: 0.1483
ERROR - 2022-07-17 00:24:16 --> Severity: Notice --> A non well formed numeric value encountered C:\wamp64\www\qr\application\controllers\Tokenctrl.php 417
INFO - 2022-07-17 00:24:16 --> Final output sent to browser
DEBUG - 2022-07-17 00:24:16 --> Total execution time: 0.0789
ERROR - 2022-07-17 00:24:16 --> Severity: Notice --> A non well formed numeric value encountered C:\wamp64\www\qr\application\controllers\Tokenctrl.php 417
INFO - 2022-07-17 00:24:16 --> Final output sent to browser
DEBUG - 2022-07-17 00:24:16 --> Total execution time: 0.1157
ERROR - 2022-07-17 00:24:16 --> Severity: Notice --> A non well formed numeric value encountered C:\wamp64\www\qr\application\controllers\Tokenctrl.php 417
INFO - 2022-07-17 00:24:16 --> Final output sent to browser
DEBUG - 2022-07-17 00:24:16 --> Total execution time: 0.0484
ERROR - 2022-07-17 00:24:16 --> Severity: Notice --> A non well formed numeric value encountered C:\wamp64\www\qr\application\controllers\Tokenctrl.php 417
INFO - 2022-07-17 00:24:16 --> Final output sent to browser
DEBUG - 2022-07-17 00:24:16 --> Total execution time: 0.0484
ERROR - 2022-07-17 00:24:17 --> Severity: Notice --> A non well formed numeric value encountered C:\wamp64\www\qr\application\controllers\Tokenctrl.php 417
INFO - 2022-07-17 00:24:17 --> Final output sent to browser
DEBUG - 2022-07-17 00:24:17 --> Total execution time: 0.1424
ERROR - 2022-07-17 00:24:17 --> Severity: Notice --> A non well formed numeric value encountered C:\wamp64\www\qr\application\controllers\Tokenctrl.php 417
INFO - 2022-07-17 00:24:17 --> Final output sent to browser
DEBUG - 2022-07-17 00:24:17 --> Total execution time: 0.1212
ERROR - 2022-07-17 00:24:17 --> Severity: Notice --> A non well formed numeric value encountered C:\wamp64\www\qr\application\controllers\Tokenctrl.php 417
INFO - 2022-07-17 00:24:17 --> Final output sent to browser
DEBUG - 2022-07-17 00:24:17 --> Total execution time: 0.0766
ERROR - 2022-07-17 00:24:17 --> Severity: Notice --> A non well formed numeric value encountered C:\wamp64\www\qr\application\controllers\Tokenctrl.php 417
INFO - 2022-07-17 00:24:17 --> Final output sent to browser
DEBUG - 2022-07-17 00:24:17 --> Total execution time: 0.0491
ERROR - 2022-07-17 00:26:20 --> Severity: Notice --> A non well formed numeric value encountered C:\wamp64\www\qr\application\controllers\Tokenctrl.php 417
INFO - 2022-07-17 00:26:20 --> Final output sent to browser
DEBUG - 2022-07-17 00:26:20 --> Total execution time: 0.1527
ERROR - 2022-07-17 00:26:22 --> Severity: Notice --> A non well formed numeric value encountered C:\wamp64\www\qr\application\controllers\Tokenctrl.php 417
INFO - 2022-07-17 00:26:22 --> Final output sent to browser
DEBUG - 2022-07-17 00:26:22 --> Total execution time: 0.1271
INFO - 2022-07-17 00:26:33 --> Final output sent to browser
DEBUG - 2022-07-17 00:26:33 --> Total execution time: 0.1105
INFO - 2022-07-17 00:28:39 --> Final output sent to browser
DEBUG - 2022-07-17 00:28:39 --> Total execution time: 0.1320
INFO - 2022-07-17 00:28:48 --> Final output sent to browser
DEBUG - 2022-07-17 00:28:48 --> Total execution time: 0.1627
INFO - 2022-07-17 00:28:57 --> Final output sent to browser
DEBUG - 2022-07-17 00:28:57 --> Total execution time: 0.1025
INFO - 2022-07-17 00:29:12 --> Final output sent to browser
DEBUG - 2022-07-17 00:29:12 --> Total execution time: 0.2049
ERROR - 2022-07-17 00:30:15 --> Severity: Notice --> A non well formed numeric value encountered C:\wamp64\www\qr\application\controllers\Tokenctrl.php 419
ERROR - 2022-07-17 00:30:15 --> Severity: Notice --> A non well formed numeric value encountered C:\wamp64\www\qr\application\controllers\Tokenctrl.php 419
INFO - 2022-07-17 00:30:15 --> Final output sent to browser
DEBUG - 2022-07-17 00:30:15 --> Total execution time: 0.1232
INFO - 2022-07-17 05:16:59 --> Config Class Initialized
INFO - 2022-07-17 05:16:59 --> Hooks Class Initialized
DEBUG - 2022-07-17 05:16:59 --> UTF-8 Support Enabled
INFO - 2022-07-17 05:16:59 --> Utf8 Class Initialized
INFO - 2022-07-17 05:16:59 --> URI Class Initialized
INFO - 2022-07-17 05:16:59 --> Router Class Initialized
INFO - 2022-07-17 05:16:59 --> Output Class Initialized
INFO - 2022-07-17 05:16:59 --> Security Class Initialized
DEBUG - 2022-07-17 05:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 05:16:59 --> Input Class Initialized
INFO - 2022-07-17 05:16:59 --> Language Class Initialized
INFO - 2022-07-17 05:16:59 --> Loader Class Initialized
INFO - 2022-07-17 05:16:59 --> Helper loaded: url_helper
INFO - 2022-07-17 05:16:59 --> Helper loaded: file_helper
INFO - 2022-07-17 05:16:59 --> Database Driver Class Initialized
INFO - 2022-07-17 05:16:59 --> Email Class Initialized
DEBUG - 2022-07-17 05:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 05:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 05:16:59 --> Controller Class Initialized
INFO - 2022-07-17 05:16:59 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 05:16:59 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 05:16:59 --> Final output sent to browser
DEBUG - 2022-07-17 05:16:59 --> Total execution time: 0.0358
INFO - 2022-07-17 05:17:10 --> Config Class Initialized
INFO - 2022-07-17 05:17:10 --> Hooks Class Initialized
DEBUG - 2022-07-17 05:17:10 --> UTF-8 Support Enabled
INFO - 2022-07-17 05:17:10 --> Utf8 Class Initialized
INFO - 2022-07-17 05:17:10 --> URI Class Initialized
INFO - 2022-07-17 05:17:10 --> Router Class Initialized
INFO - 2022-07-17 05:17:10 --> Output Class Initialized
INFO - 2022-07-17 05:17:10 --> Security Class Initialized
DEBUG - 2022-07-17 05:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 05:17:10 --> Input Class Initialized
INFO - 2022-07-17 05:17:10 --> Language Class Initialized
INFO - 2022-07-17 05:17:10 --> Loader Class Initialized
INFO - 2022-07-17 05:17:10 --> Helper loaded: url_helper
INFO - 2022-07-17 05:17:10 --> Helper loaded: file_helper
INFO - 2022-07-17 05:17:10 --> Database Driver Class Initialized
INFO - 2022-07-17 05:17:10 --> Email Class Initialized
DEBUG - 2022-07-17 05:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 05:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 05:17:10 --> Controller Class Initialized
INFO - 2022-07-17 05:17:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 05:17:10 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 05:17:10 --> Final output sent to browser
DEBUG - 2022-07-17 05:17:10 --> Total execution time: 0.0294
INFO - 2022-07-17 05:17:21 --> Config Class Initialized
INFO - 2022-07-17 05:17:21 --> Hooks Class Initialized
DEBUG - 2022-07-17 05:17:21 --> UTF-8 Support Enabled
INFO - 2022-07-17 05:17:21 --> Utf8 Class Initialized
INFO - 2022-07-17 05:17:21 --> URI Class Initialized
INFO - 2022-07-17 05:17:21 --> Router Class Initialized
INFO - 2022-07-17 05:17:21 --> Output Class Initialized
INFO - 2022-07-17 05:17:21 --> Security Class Initialized
DEBUG - 2022-07-17 05:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 05:17:21 --> Input Class Initialized
INFO - 2022-07-17 05:17:21 --> Language Class Initialized
INFO - 2022-07-17 05:17:21 --> Loader Class Initialized
INFO - 2022-07-17 05:17:21 --> Helper loaded: url_helper
INFO - 2022-07-17 05:17:21 --> Helper loaded: file_helper
INFO - 2022-07-17 05:17:21 --> Database Driver Class Initialized
INFO - 2022-07-17 05:17:21 --> Email Class Initialized
DEBUG - 2022-07-17 05:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 05:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 05:17:21 --> Controller Class Initialized
INFO - 2022-07-17 05:17:21 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 05:17:21 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 05:17:21 --> Final output sent to browser
DEBUG - 2022-07-17 05:17:21 --> Total execution time: 0.0690
INFO - 2022-07-17 05:17:32 --> Config Class Initialized
INFO - 2022-07-17 05:17:32 --> Hooks Class Initialized
DEBUG - 2022-07-17 05:17:32 --> UTF-8 Support Enabled
INFO - 2022-07-17 05:17:32 --> Utf8 Class Initialized
INFO - 2022-07-17 05:17:32 --> URI Class Initialized
INFO - 2022-07-17 05:17:33 --> Router Class Initialized
INFO - 2022-07-17 05:17:33 --> Output Class Initialized
INFO - 2022-07-17 05:17:33 --> Security Class Initialized
DEBUG - 2022-07-17 05:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 05:17:33 --> Input Class Initialized
INFO - 2022-07-17 05:17:33 --> Language Class Initialized
INFO - 2022-07-17 05:17:33 --> Loader Class Initialized
INFO - 2022-07-17 05:17:33 --> Helper loaded: url_helper
INFO - 2022-07-17 05:17:33 --> Helper loaded: file_helper
INFO - 2022-07-17 05:17:33 --> Database Driver Class Initialized
INFO - 2022-07-17 05:17:33 --> Email Class Initialized
DEBUG - 2022-07-17 05:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 05:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 05:17:33 --> Controller Class Initialized
INFO - 2022-07-17 05:17:33 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 05:17:33 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 05:17:33 --> Final output sent to browser
DEBUG - 2022-07-17 05:17:33 --> Total execution time: 0.2411
INFO - 2022-07-17 05:17:43 --> Config Class Initialized
INFO - 2022-07-17 05:17:43 --> Hooks Class Initialized
DEBUG - 2022-07-17 05:17:43 --> UTF-8 Support Enabled
INFO - 2022-07-17 05:17:43 --> Utf8 Class Initialized
INFO - 2022-07-17 05:17:43 --> URI Class Initialized
INFO - 2022-07-17 05:17:43 --> Router Class Initialized
INFO - 2022-07-17 05:17:43 --> Output Class Initialized
INFO - 2022-07-17 05:17:43 --> Security Class Initialized
DEBUG - 2022-07-17 05:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 05:17:43 --> Input Class Initialized
INFO - 2022-07-17 05:17:43 --> Language Class Initialized
INFO - 2022-07-17 05:17:43 --> Loader Class Initialized
INFO - 2022-07-17 05:17:43 --> Helper loaded: url_helper
INFO - 2022-07-17 05:17:43 --> Helper loaded: file_helper
INFO - 2022-07-17 05:17:43 --> Database Driver Class Initialized
INFO - 2022-07-17 05:17:43 --> Email Class Initialized
DEBUG - 2022-07-17 05:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 05:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 05:17:43 --> Controller Class Initialized
INFO - 2022-07-17 05:17:43 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 05:17:43 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 05:17:43 --> Final output sent to browser
DEBUG - 2022-07-17 05:17:43 --> Total execution time: 0.0248
INFO - 2022-07-17 05:17:54 --> Config Class Initialized
INFO - 2022-07-17 05:17:54 --> Hooks Class Initialized
DEBUG - 2022-07-17 05:17:54 --> UTF-8 Support Enabled
INFO - 2022-07-17 05:17:54 --> Utf8 Class Initialized
INFO - 2022-07-17 05:17:54 --> URI Class Initialized
INFO - 2022-07-17 05:17:54 --> Router Class Initialized
INFO - 2022-07-17 05:17:54 --> Output Class Initialized
INFO - 2022-07-17 05:17:54 --> Security Class Initialized
DEBUG - 2022-07-17 05:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 05:17:54 --> Input Class Initialized
INFO - 2022-07-17 05:17:54 --> Language Class Initialized
INFO - 2022-07-17 05:17:54 --> Loader Class Initialized
INFO - 2022-07-17 05:17:54 --> Helper loaded: url_helper
INFO - 2022-07-17 05:17:54 --> Helper loaded: file_helper
INFO - 2022-07-17 05:17:54 --> Database Driver Class Initialized
INFO - 2022-07-17 05:17:54 --> Email Class Initialized
DEBUG - 2022-07-17 05:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 05:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 05:17:54 --> Controller Class Initialized
INFO - 2022-07-17 05:17:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 05:17:54 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 05:17:54 --> Final output sent to browser
DEBUG - 2022-07-17 05:17:54 --> Total execution time: 0.0320
INFO - 2022-07-17 05:18:05 --> Config Class Initialized
INFO - 2022-07-17 05:18:05 --> Hooks Class Initialized
DEBUG - 2022-07-17 05:18:05 --> UTF-8 Support Enabled
INFO - 2022-07-17 05:18:05 --> Utf8 Class Initialized
INFO - 2022-07-17 05:18:05 --> URI Class Initialized
INFO - 2022-07-17 05:18:05 --> Router Class Initialized
INFO - 2022-07-17 05:18:05 --> Output Class Initialized
INFO - 2022-07-17 05:18:05 --> Security Class Initialized
DEBUG - 2022-07-17 05:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 05:18:05 --> Input Class Initialized
INFO - 2022-07-17 05:18:05 --> Language Class Initialized
INFO - 2022-07-17 05:18:05 --> Loader Class Initialized
INFO - 2022-07-17 05:18:05 --> Helper loaded: url_helper
INFO - 2022-07-17 05:18:05 --> Helper loaded: file_helper
INFO - 2022-07-17 05:18:05 --> Database Driver Class Initialized
INFO - 2022-07-17 05:18:05 --> Email Class Initialized
DEBUG - 2022-07-17 05:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 05:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 05:18:05 --> Controller Class Initialized
INFO - 2022-07-17 05:18:05 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 05:18:05 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 05:18:05 --> Final output sent to browser
DEBUG - 2022-07-17 05:18:05 --> Total execution time: 0.0242
INFO - 2022-07-17 05:18:16 --> Config Class Initialized
INFO - 2022-07-17 05:18:16 --> Hooks Class Initialized
DEBUG - 2022-07-17 05:18:16 --> UTF-8 Support Enabled
INFO - 2022-07-17 05:18:16 --> Utf8 Class Initialized
INFO - 2022-07-17 05:18:16 --> URI Class Initialized
INFO - 2022-07-17 05:18:16 --> Router Class Initialized
INFO - 2022-07-17 05:18:16 --> Output Class Initialized
INFO - 2022-07-17 05:18:16 --> Security Class Initialized
DEBUG - 2022-07-17 05:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 05:18:16 --> Input Class Initialized
INFO - 2022-07-17 05:18:16 --> Language Class Initialized
INFO - 2022-07-17 05:18:16 --> Loader Class Initialized
INFO - 2022-07-17 05:18:16 --> Helper loaded: url_helper
INFO - 2022-07-17 05:18:16 --> Helper loaded: file_helper
INFO - 2022-07-17 05:18:16 --> Database Driver Class Initialized
INFO - 2022-07-17 05:18:16 --> Email Class Initialized
DEBUG - 2022-07-17 05:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 05:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 05:18:16 --> Controller Class Initialized
INFO - 2022-07-17 05:18:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 05:18:16 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 05:18:16 --> Final output sent to browser
DEBUG - 2022-07-17 05:18:16 --> Total execution time: 0.0244
INFO - 2022-07-17 05:18:27 --> Config Class Initialized
INFO - 2022-07-17 05:18:27 --> Hooks Class Initialized
DEBUG - 2022-07-17 05:18:27 --> UTF-8 Support Enabled
INFO - 2022-07-17 05:18:27 --> Utf8 Class Initialized
INFO - 2022-07-17 05:18:27 --> URI Class Initialized
INFO - 2022-07-17 05:18:27 --> Router Class Initialized
INFO - 2022-07-17 05:18:27 --> Output Class Initialized
INFO - 2022-07-17 05:18:27 --> Security Class Initialized
DEBUG - 2022-07-17 05:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 05:18:27 --> Input Class Initialized
INFO - 2022-07-17 05:18:27 --> Language Class Initialized
INFO - 2022-07-17 05:18:27 --> Loader Class Initialized
INFO - 2022-07-17 05:18:27 --> Helper loaded: url_helper
INFO - 2022-07-17 05:18:27 --> Helper loaded: file_helper
INFO - 2022-07-17 05:18:27 --> Database Driver Class Initialized
INFO - 2022-07-17 05:18:27 --> Email Class Initialized
DEBUG - 2022-07-17 05:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 05:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 05:18:27 --> Controller Class Initialized
INFO - 2022-07-17 05:18:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 05:18:27 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 05:18:27 --> Final output sent to browser
DEBUG - 2022-07-17 05:18:27 --> Total execution time: 0.0468
INFO - 2022-07-17 05:18:42 --> Config Class Initialized
INFO - 2022-07-17 05:18:42 --> Hooks Class Initialized
DEBUG - 2022-07-17 05:18:42 --> UTF-8 Support Enabled
INFO - 2022-07-17 05:18:42 --> Utf8 Class Initialized
INFO - 2022-07-17 05:18:42 --> URI Class Initialized
INFO - 2022-07-17 05:18:42 --> Router Class Initialized
INFO - 2022-07-17 05:18:42 --> Output Class Initialized
INFO - 2022-07-17 05:18:42 --> Security Class Initialized
DEBUG - 2022-07-17 05:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 05:18:42 --> Input Class Initialized
INFO - 2022-07-17 05:18:42 --> Language Class Initialized
INFO - 2022-07-17 05:18:42 --> Loader Class Initialized
INFO - 2022-07-17 05:18:42 --> Helper loaded: url_helper
INFO - 2022-07-17 05:18:42 --> Helper loaded: file_helper
INFO - 2022-07-17 05:18:42 --> Database Driver Class Initialized
INFO - 2022-07-17 05:18:42 --> Email Class Initialized
DEBUG - 2022-07-17 05:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 05:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 05:18:42 --> Controller Class Initialized
INFO - 2022-07-17 05:18:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 05:18:42 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 05:18:42 --> Final output sent to browser
DEBUG - 2022-07-17 05:18:42 --> Total execution time: 0.0225
INFO - 2022-07-17 05:18:52 --> Config Class Initialized
INFO - 2022-07-17 05:18:52 --> Hooks Class Initialized
DEBUG - 2022-07-17 05:18:52 --> UTF-8 Support Enabled
INFO - 2022-07-17 05:18:52 --> Utf8 Class Initialized
INFO - 2022-07-17 05:18:52 --> URI Class Initialized
INFO - 2022-07-17 05:18:52 --> Router Class Initialized
INFO - 2022-07-17 05:18:52 --> Output Class Initialized
INFO - 2022-07-17 05:18:52 --> Security Class Initialized
DEBUG - 2022-07-17 05:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 05:18:52 --> Input Class Initialized
INFO - 2022-07-17 05:18:52 --> Language Class Initialized
INFO - 2022-07-17 05:18:52 --> Loader Class Initialized
INFO - 2022-07-17 05:18:52 --> Helper loaded: url_helper
INFO - 2022-07-17 05:18:52 --> Helper loaded: file_helper
INFO - 2022-07-17 05:18:52 --> Database Driver Class Initialized
INFO - 2022-07-17 05:18:52 --> Email Class Initialized
DEBUG - 2022-07-17 05:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 05:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 05:18:52 --> Controller Class Initialized
INFO - 2022-07-17 05:18:52 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 05:18:52 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 05:18:52 --> Final output sent to browser
DEBUG - 2022-07-17 05:18:52 --> Total execution time: 0.0266
INFO - 2022-07-17 05:19:03 --> Config Class Initialized
INFO - 2022-07-17 05:19:03 --> Hooks Class Initialized
DEBUG - 2022-07-17 05:19:03 --> UTF-8 Support Enabled
INFO - 2022-07-17 05:19:03 --> Utf8 Class Initialized
INFO - 2022-07-17 05:19:03 --> URI Class Initialized
INFO - 2022-07-17 05:19:03 --> Router Class Initialized
INFO - 2022-07-17 05:19:03 --> Output Class Initialized
INFO - 2022-07-17 05:19:03 --> Security Class Initialized
DEBUG - 2022-07-17 05:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 05:19:03 --> Input Class Initialized
INFO - 2022-07-17 05:19:03 --> Language Class Initialized
INFO - 2022-07-17 05:19:03 --> Loader Class Initialized
INFO - 2022-07-17 05:19:03 --> Helper loaded: url_helper
INFO - 2022-07-17 05:19:03 --> Helper loaded: file_helper
INFO - 2022-07-17 05:19:03 --> Database Driver Class Initialized
INFO - 2022-07-17 05:19:03 --> Email Class Initialized
DEBUG - 2022-07-17 05:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 05:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 05:19:03 --> Controller Class Initialized
INFO - 2022-07-17 05:19:03 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 05:19:03 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 05:19:03 --> Final output sent to browser
DEBUG - 2022-07-17 05:19:03 --> Total execution time: 0.0242
INFO - 2022-07-17 05:19:14 --> Config Class Initialized
INFO - 2022-07-17 05:19:14 --> Hooks Class Initialized
DEBUG - 2022-07-17 05:19:14 --> UTF-8 Support Enabled
INFO - 2022-07-17 05:19:14 --> Utf8 Class Initialized
INFO - 2022-07-17 05:19:14 --> URI Class Initialized
INFO - 2022-07-17 05:19:14 --> Router Class Initialized
INFO - 2022-07-17 05:19:14 --> Output Class Initialized
INFO - 2022-07-17 05:19:14 --> Security Class Initialized
DEBUG - 2022-07-17 05:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 05:19:14 --> Input Class Initialized
INFO - 2022-07-17 05:19:14 --> Language Class Initialized
INFO - 2022-07-17 05:19:14 --> Loader Class Initialized
INFO - 2022-07-17 05:19:14 --> Helper loaded: url_helper
INFO - 2022-07-17 05:19:14 --> Helper loaded: file_helper
INFO - 2022-07-17 05:19:14 --> Database Driver Class Initialized
INFO - 2022-07-17 05:19:14 --> Email Class Initialized
DEBUG - 2022-07-17 05:19:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 05:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 05:19:14 --> Controller Class Initialized
INFO - 2022-07-17 05:19:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 05:19:14 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 05:19:14 --> Final output sent to browser
DEBUG - 2022-07-17 05:19:14 --> Total execution time: 0.0288
INFO - 2022-07-17 05:19:25 --> Config Class Initialized
INFO - 2022-07-17 05:19:25 --> Hooks Class Initialized
DEBUG - 2022-07-17 05:19:25 --> UTF-8 Support Enabled
INFO - 2022-07-17 05:19:25 --> Utf8 Class Initialized
INFO - 2022-07-17 05:19:25 --> URI Class Initialized
INFO - 2022-07-17 05:19:25 --> Router Class Initialized
INFO - 2022-07-17 05:19:25 --> Output Class Initialized
INFO - 2022-07-17 05:19:25 --> Security Class Initialized
DEBUG - 2022-07-17 05:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 05:19:25 --> Input Class Initialized
INFO - 2022-07-17 05:19:25 --> Language Class Initialized
INFO - 2022-07-17 05:19:25 --> Loader Class Initialized
INFO - 2022-07-17 05:19:25 --> Helper loaded: url_helper
INFO - 2022-07-17 05:19:25 --> Helper loaded: file_helper
INFO - 2022-07-17 05:19:25 --> Database Driver Class Initialized
INFO - 2022-07-17 05:19:25 --> Email Class Initialized
DEBUG - 2022-07-17 05:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 05:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 05:19:25 --> Controller Class Initialized
INFO - 2022-07-17 05:19:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 05:19:25 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 05:19:25 --> Final output sent to browser
DEBUG - 2022-07-17 05:19:25 --> Total execution time: 0.0216
INFO - 2022-07-17 05:19:36 --> Config Class Initialized
INFO - 2022-07-17 05:19:36 --> Hooks Class Initialized
DEBUG - 2022-07-17 05:19:36 --> UTF-8 Support Enabled
INFO - 2022-07-17 05:19:36 --> Utf8 Class Initialized
INFO - 2022-07-17 05:19:36 --> URI Class Initialized
INFO - 2022-07-17 05:19:36 --> Router Class Initialized
INFO - 2022-07-17 05:19:36 --> Output Class Initialized
INFO - 2022-07-17 05:19:36 --> Security Class Initialized
DEBUG - 2022-07-17 05:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 05:19:36 --> Input Class Initialized
INFO - 2022-07-17 05:19:36 --> Language Class Initialized
INFO - 2022-07-17 05:19:36 --> Loader Class Initialized
INFO - 2022-07-17 05:19:36 --> Helper loaded: url_helper
INFO - 2022-07-17 05:19:36 --> Helper loaded: file_helper
INFO - 2022-07-17 05:19:36 --> Database Driver Class Initialized
INFO - 2022-07-17 05:19:36 --> Email Class Initialized
DEBUG - 2022-07-17 05:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 05:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 05:19:36 --> Controller Class Initialized
INFO - 2022-07-17 05:19:36 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 05:19:36 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 05:19:36 --> Final output sent to browser
DEBUG - 2022-07-17 05:19:36 --> Total execution time: 0.0359
INFO - 2022-07-17 05:19:47 --> Config Class Initialized
INFO - 2022-07-17 05:19:47 --> Hooks Class Initialized
DEBUG - 2022-07-17 05:19:47 --> UTF-8 Support Enabled
INFO - 2022-07-17 05:19:47 --> Utf8 Class Initialized
INFO - 2022-07-17 05:19:47 --> URI Class Initialized
INFO - 2022-07-17 05:19:47 --> Router Class Initialized
INFO - 2022-07-17 05:19:47 --> Output Class Initialized
INFO - 2022-07-17 05:19:47 --> Security Class Initialized
DEBUG - 2022-07-17 05:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 05:19:47 --> Input Class Initialized
INFO - 2022-07-17 05:19:47 --> Language Class Initialized
INFO - 2022-07-17 05:19:47 --> Loader Class Initialized
INFO - 2022-07-17 05:19:47 --> Helper loaded: url_helper
INFO - 2022-07-17 05:19:47 --> Helper loaded: file_helper
INFO - 2022-07-17 05:19:47 --> Database Driver Class Initialized
INFO - 2022-07-17 05:19:47 --> Email Class Initialized
DEBUG - 2022-07-17 05:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 05:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 05:19:47 --> Controller Class Initialized
INFO - 2022-07-17 05:19:47 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 05:19:47 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 05:19:47 --> Final output sent to browser
DEBUG - 2022-07-17 05:19:47 --> Total execution time: 0.0487
INFO - 2022-07-17 07:12:33 --> Config Class Initialized
INFO - 2022-07-17 07:12:33 --> Hooks Class Initialized
DEBUG - 2022-07-17 07:12:33 --> UTF-8 Support Enabled
INFO - 2022-07-17 07:12:33 --> Utf8 Class Initialized
INFO - 2022-07-17 07:12:33 --> URI Class Initialized
INFO - 2022-07-17 07:12:33 --> Router Class Initialized
INFO - 2022-07-17 07:12:33 --> Output Class Initialized
INFO - 2022-07-17 07:12:33 --> Security Class Initialized
DEBUG - 2022-07-17 07:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 07:12:33 --> Input Class Initialized
INFO - 2022-07-17 07:12:33 --> Language Class Initialized
INFO - 2022-07-17 07:12:33 --> Loader Class Initialized
INFO - 2022-07-17 07:12:33 --> Helper loaded: url_helper
INFO - 2022-07-17 07:12:33 --> Helper loaded: file_helper
INFO - 2022-07-17 07:12:33 --> Database Driver Class Initialized
INFO - 2022-07-17 07:12:33 --> Email Class Initialized
DEBUG - 2022-07-17 07:12:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 07:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 07:12:33 --> Controller Class Initialized
INFO - 2022-07-17 07:12:33 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 07:12:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 07:12:33 --> Severity: Notice --> Undefined variable: Date C:\wamp64\www\qr\application\controllers\Tokenctrl.php 458
ERROR - 2022-07-17 07:12:33 --> Severity: Notice --> Trying to get property 'td_tk' of non-object C:\wamp64\www\qr\application\controllers\Tokenctrl.php 477
ERROR - 2022-07-17 07:12:33 --> Severity: Notice --> Undefined variable: time_avg C:\wamp64\www\qr\application\controllers\Tokenctrl.php 478
DEBUG - 2022-07-17 07:12:33 --> insertedINSERT INTO `tokendetails` (`td_tk`, `td_cs`, `td_visited_date`) VALUES (1, 0, '2022-07-17')
INFO - 2022-07-17 07:12:33 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-17 07:12:33 --> Final output sent to browser
DEBUG - 2022-07-17 07:12:33 --> Total execution time: 0.6826
INFO - 2022-07-17 07:12:41 --> Config Class Initialized
INFO - 2022-07-17 07:12:41 --> Hooks Class Initialized
DEBUG - 2022-07-17 07:12:41 --> UTF-8 Support Enabled
INFO - 2022-07-17 07:12:41 --> Utf8 Class Initialized
INFO - 2022-07-17 07:12:41 --> URI Class Initialized
INFO - 2022-07-17 07:12:41 --> Router Class Initialized
INFO - 2022-07-17 07:12:41 --> Output Class Initialized
INFO - 2022-07-17 07:12:41 --> Security Class Initialized
DEBUG - 2022-07-17 07:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 07:12:41 --> Input Class Initialized
INFO - 2022-07-17 07:12:41 --> Language Class Initialized
INFO - 2022-07-17 07:12:41 --> Loader Class Initialized
INFO - 2022-07-17 07:12:41 --> Helper loaded: url_helper
INFO - 2022-07-17 07:12:41 --> Helper loaded: file_helper
INFO - 2022-07-17 07:12:41 --> Database Driver Class Initialized
INFO - 2022-07-17 07:12:41 --> Email Class Initialized
DEBUG - 2022-07-17 07:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 07:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 07:12:41 --> Controller Class Initialized
INFO - 2022-07-17 07:12:41 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 07:12:41 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 07:12:41 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-17 07:12:41 --> Final output sent to browser
DEBUG - 2022-07-17 07:12:41 --> Total execution time: 0.1828
INFO - 2022-07-17 07:13:53 --> Config Class Initialized
INFO - 2022-07-17 07:13:53 --> Hooks Class Initialized
DEBUG - 2022-07-17 07:13:53 --> UTF-8 Support Enabled
INFO - 2022-07-17 07:13:53 --> Utf8 Class Initialized
INFO - 2022-07-17 07:13:53 --> URI Class Initialized
INFO - 2022-07-17 07:13:53 --> Router Class Initialized
INFO - 2022-07-17 07:13:53 --> Output Class Initialized
INFO - 2022-07-17 07:13:53 --> Security Class Initialized
DEBUG - 2022-07-17 07:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 07:13:53 --> Input Class Initialized
INFO - 2022-07-17 07:13:53 --> Language Class Initialized
INFO - 2022-07-17 07:13:53 --> Loader Class Initialized
INFO - 2022-07-17 07:13:53 --> Helper loaded: url_helper
INFO - 2022-07-17 07:13:53 --> Helper loaded: file_helper
INFO - 2022-07-17 07:13:53 --> Database Driver Class Initialized
INFO - 2022-07-17 07:13:53 --> Email Class Initialized
DEBUG - 2022-07-17 07:13:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 07:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 07:13:53 --> Controller Class Initialized
INFO - 2022-07-17 07:13:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 07:13:53 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 07:13:53 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-17 07:13:53 --> Final output sent to browser
DEBUG - 2022-07-17 07:13:54 --> Total execution time: 0.1408
INFO - 2022-07-17 07:54:49 --> Config Class Initialized
INFO - 2022-07-17 07:54:49 --> Hooks Class Initialized
DEBUG - 2022-07-17 07:54:49 --> UTF-8 Support Enabled
INFO - 2022-07-17 07:54:49 --> Utf8 Class Initialized
INFO - 2022-07-17 07:54:49 --> URI Class Initialized
INFO - 2022-07-17 07:54:49 --> Router Class Initialized
INFO - 2022-07-17 07:54:49 --> Output Class Initialized
INFO - 2022-07-17 07:54:49 --> Security Class Initialized
DEBUG - 2022-07-17 07:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 07:54:49 --> Input Class Initialized
INFO - 2022-07-17 07:54:49 --> Language Class Initialized
INFO - 2022-07-17 07:54:49 --> Loader Class Initialized
INFO - 2022-07-17 07:54:49 --> Helper loaded: url_helper
INFO - 2022-07-17 07:54:49 --> Helper loaded: file_helper
INFO - 2022-07-17 07:54:49 --> Database Driver Class Initialized
INFO - 2022-07-17 07:54:49 --> Email Class Initialized
DEBUG - 2022-07-17 07:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 07:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 07:54:49 --> Controller Class Initialized
INFO - 2022-07-17 07:54:49 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 07:54:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 13:24:50 --> Severity: Notice --> A non well formed numeric value encountered C:\wamp64\www\qr\application\controllers\Tokenctrl.php 419
ERROR - 2022-07-17 13:24:50 --> Severity: Notice --> A non well formed numeric value encountered C:\wamp64\www\qr\application\controllers\Tokenctrl.php 419
INFO - 2022-07-17 13:24:50 --> Final output sent to browser
DEBUG - 2022-07-17 13:24:50 --> Total execution time: 0.8217
INFO - 2022-07-17 07:58:58 --> Config Class Initialized
INFO - 2022-07-17 07:58:58 --> Hooks Class Initialized
DEBUG - 2022-07-17 07:58:58 --> UTF-8 Support Enabled
INFO - 2022-07-17 07:58:58 --> Utf8 Class Initialized
INFO - 2022-07-17 07:58:58 --> URI Class Initialized
INFO - 2022-07-17 07:58:58 --> Router Class Initialized
INFO - 2022-07-17 07:58:58 --> Output Class Initialized
INFO - 2022-07-17 07:58:58 --> Security Class Initialized
DEBUG - 2022-07-17 07:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 07:58:58 --> Input Class Initialized
INFO - 2022-07-17 07:58:58 --> Language Class Initialized
ERROR - 2022-07-17 07:58:59 --> Severity: error --> Exception: syntax error, unexpected 'var_dump' (T_STRING) C:\wamp64\www\qr\application\controllers\Tokenctrl.php 421
INFO - 2022-07-17 07:59:00 --> Config Class Initialized
INFO - 2022-07-17 07:59:00 --> Hooks Class Initialized
DEBUG - 2022-07-17 07:59:00 --> UTF-8 Support Enabled
INFO - 2022-07-17 07:59:00 --> Utf8 Class Initialized
INFO - 2022-07-17 07:59:00 --> URI Class Initialized
INFO - 2022-07-17 07:59:00 --> Router Class Initialized
INFO - 2022-07-17 07:59:00 --> Output Class Initialized
INFO - 2022-07-17 07:59:00 --> Security Class Initialized
DEBUG - 2022-07-17 07:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 07:59:00 --> Input Class Initialized
INFO - 2022-07-17 07:59:00 --> Language Class Initialized
ERROR - 2022-07-17 07:59:00 --> Severity: error --> Exception: syntax error, unexpected 'var_dump' (T_STRING) C:\wamp64\www\qr\application\controllers\Tokenctrl.php 421
INFO - 2022-07-17 07:59:22 --> Config Class Initialized
INFO - 2022-07-17 07:59:22 --> Hooks Class Initialized
DEBUG - 2022-07-17 07:59:22 --> UTF-8 Support Enabled
INFO - 2022-07-17 07:59:22 --> Utf8 Class Initialized
INFO - 2022-07-17 07:59:22 --> URI Class Initialized
INFO - 2022-07-17 07:59:22 --> Router Class Initialized
INFO - 2022-07-17 07:59:22 --> Output Class Initialized
INFO - 2022-07-17 07:59:22 --> Security Class Initialized
DEBUG - 2022-07-17 07:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 07:59:22 --> Input Class Initialized
INFO - 2022-07-17 07:59:22 --> Language Class Initialized
ERROR - 2022-07-17 07:59:22 --> Severity: error --> Exception: syntax error, unexpected 'var_dump' (T_STRING) C:\wamp64\www\qr\application\controllers\Tokenctrl.php 421
INFO - 2022-07-17 07:59:24 --> Config Class Initialized
INFO - 2022-07-17 07:59:24 --> Hooks Class Initialized
DEBUG - 2022-07-17 07:59:24 --> UTF-8 Support Enabled
INFO - 2022-07-17 07:59:24 --> Utf8 Class Initialized
INFO - 2022-07-17 07:59:24 --> URI Class Initialized
INFO - 2022-07-17 07:59:24 --> Router Class Initialized
INFO - 2022-07-17 07:59:24 --> Output Class Initialized
INFO - 2022-07-17 07:59:24 --> Security Class Initialized
DEBUG - 2022-07-17 07:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 07:59:24 --> Input Class Initialized
INFO - 2022-07-17 07:59:24 --> Language Class Initialized
ERROR - 2022-07-17 07:59:24 --> Severity: error --> Exception: syntax error, unexpected 'var_dump' (T_STRING) C:\wamp64\www\qr\application\controllers\Tokenctrl.php 421
INFO - 2022-07-17 07:59:25 --> Config Class Initialized
INFO - 2022-07-17 07:59:25 --> Hooks Class Initialized
DEBUG - 2022-07-17 07:59:25 --> UTF-8 Support Enabled
INFO - 2022-07-17 07:59:25 --> Utf8 Class Initialized
INFO - 2022-07-17 07:59:25 --> URI Class Initialized
INFO - 2022-07-17 07:59:25 --> Router Class Initialized
INFO - 2022-07-17 07:59:25 --> Output Class Initialized
INFO - 2022-07-17 07:59:25 --> Security Class Initialized
DEBUG - 2022-07-17 07:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 07:59:25 --> Input Class Initialized
INFO - 2022-07-17 07:59:25 --> Language Class Initialized
ERROR - 2022-07-17 07:59:25 --> Severity: error --> Exception: syntax error, unexpected 'var_dump' (T_STRING) C:\wamp64\www\qr\application\controllers\Tokenctrl.php 421
INFO - 2022-07-17 07:59:45 --> Config Class Initialized
INFO - 2022-07-17 07:59:45 --> Hooks Class Initialized
DEBUG - 2022-07-17 07:59:45 --> UTF-8 Support Enabled
INFO - 2022-07-17 07:59:45 --> Utf8 Class Initialized
INFO - 2022-07-17 07:59:45 --> URI Class Initialized
INFO - 2022-07-17 07:59:45 --> Router Class Initialized
INFO - 2022-07-17 07:59:45 --> Output Class Initialized
INFO - 2022-07-17 07:59:45 --> Security Class Initialized
DEBUG - 2022-07-17 07:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 07:59:45 --> Input Class Initialized
INFO - 2022-07-17 07:59:45 --> Language Class Initialized
INFO - 2022-07-17 07:59:45 --> Loader Class Initialized
INFO - 2022-07-17 07:59:45 --> Helper loaded: url_helper
INFO - 2022-07-17 07:59:45 --> Helper loaded: file_helper
INFO - 2022-07-17 07:59:45 --> Database Driver Class Initialized
INFO - 2022-07-17 07:59:45 --> Email Class Initialized
DEBUG - 2022-07-17 07:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 07:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 07:59:45 --> Controller Class Initialized
INFO - 2022-07-17 07:59:45 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 07:59:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 13:29:45 --> Severity: Notice --> A non well formed numeric value encountered C:\wamp64\www\qr\application\controllers\Tokenctrl.php 419
ERROR - 2022-07-17 13:29:45 --> Severity: Notice --> A non well formed numeric value encountered C:\wamp64\www\qr\application\controllers\Tokenctrl.php 419
INFO - 2022-07-17 13:29:45 --> Final output sent to browser
DEBUG - 2022-07-17 13:29:45 --> Total execution time: 0.2342
INFO - 2022-07-17 08:03:38 --> Config Class Initialized
INFO - 2022-07-17 08:03:38 --> Hooks Class Initialized
DEBUG - 2022-07-17 08:03:38 --> UTF-8 Support Enabled
INFO - 2022-07-17 08:03:38 --> Utf8 Class Initialized
INFO - 2022-07-17 08:03:38 --> URI Class Initialized
INFO - 2022-07-17 08:03:38 --> Router Class Initialized
INFO - 2022-07-17 08:03:38 --> Output Class Initialized
INFO - 2022-07-17 08:03:38 --> Security Class Initialized
DEBUG - 2022-07-17 08:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 08:03:38 --> Input Class Initialized
INFO - 2022-07-17 08:03:38 --> Language Class Initialized
INFO - 2022-07-17 08:03:38 --> Loader Class Initialized
INFO - 2022-07-17 08:03:38 --> Helper loaded: url_helper
INFO - 2022-07-17 08:03:38 --> Helper loaded: file_helper
INFO - 2022-07-17 08:03:38 --> Database Driver Class Initialized
INFO - 2022-07-17 08:03:38 --> Email Class Initialized
DEBUG - 2022-07-17 08:03:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 08:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 08:03:38 --> Controller Class Initialized
INFO - 2022-07-17 08:03:38 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 08:03:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 13:33:38 --> Severity: Notice --> Trying to get property 'td_tk' of non-object C:\wamp64\www\qr\application\controllers\Tokenctrl.php 431
ERROR - 2022-07-17 13:33:38 --> Severity: Notice --> Undefined variable: token C:\wamp64\www\qr\application\controllers\Tokenctrl.php 431
INFO - 2022-07-17 13:33:38 --> Final output sent to browser
DEBUG - 2022-07-17 13:33:38 --> Total execution time: 0.2022
INFO - 2022-07-17 08:03:50 --> Config Class Initialized
INFO - 2022-07-17 08:03:50 --> Hooks Class Initialized
DEBUG - 2022-07-17 08:03:50 --> UTF-8 Support Enabled
INFO - 2022-07-17 08:03:50 --> Utf8 Class Initialized
INFO - 2022-07-17 08:03:50 --> URI Class Initialized
INFO - 2022-07-17 08:03:50 --> Router Class Initialized
INFO - 2022-07-17 08:03:50 --> Output Class Initialized
INFO - 2022-07-17 08:03:50 --> Security Class Initialized
DEBUG - 2022-07-17 08:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 08:03:50 --> Input Class Initialized
INFO - 2022-07-17 08:03:50 --> Language Class Initialized
INFO - 2022-07-17 08:03:50 --> Loader Class Initialized
INFO - 2022-07-17 08:03:50 --> Helper loaded: url_helper
INFO - 2022-07-17 08:03:50 --> Helper loaded: file_helper
INFO - 2022-07-17 08:03:50 --> Database Driver Class Initialized
INFO - 2022-07-17 08:03:50 --> Email Class Initialized
DEBUG - 2022-07-17 08:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 08:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 08:03:50 --> Controller Class Initialized
INFO - 2022-07-17 08:03:50 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 08:03:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 13:33:50 --> Severity: Notice --> Trying to get property 'td_tk' of non-object C:\wamp64\www\qr\application\controllers\Tokenctrl.php 431
ERROR - 2022-07-17 13:33:50 --> Severity: Notice --> Undefined variable: token C:\wamp64\www\qr\application\controllers\Tokenctrl.php 431
INFO - 2022-07-17 13:33:50 --> Final output sent to browser
DEBUG - 2022-07-17 13:33:50 --> Total execution time: 0.2100
INFO - 2022-07-17 08:04:23 --> Config Class Initialized
INFO - 2022-07-17 08:04:23 --> Hooks Class Initialized
DEBUG - 2022-07-17 08:04:23 --> UTF-8 Support Enabled
INFO - 2022-07-17 08:04:23 --> Utf8 Class Initialized
INFO - 2022-07-17 08:04:23 --> URI Class Initialized
INFO - 2022-07-17 08:04:23 --> Router Class Initialized
INFO - 2022-07-17 08:04:23 --> Output Class Initialized
INFO - 2022-07-17 08:04:23 --> Security Class Initialized
DEBUG - 2022-07-17 08:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 08:04:23 --> Input Class Initialized
INFO - 2022-07-17 08:04:23 --> Language Class Initialized
ERROR - 2022-07-17 08:04:23 --> Severity: error --> Exception: syntax error, unexpected '10' (T_LNUMBER), expecting variable (T_VARIABLE) or '{' or '$' C:\wamp64\www\qr\application\controllers\Tokenctrl.php 431
INFO - 2022-07-17 08:04:44 --> Config Class Initialized
INFO - 2022-07-17 08:04:44 --> Hooks Class Initialized
DEBUG - 2022-07-17 08:04:44 --> UTF-8 Support Enabled
INFO - 2022-07-17 08:04:44 --> Utf8 Class Initialized
INFO - 2022-07-17 08:04:44 --> URI Class Initialized
INFO - 2022-07-17 08:04:44 --> Router Class Initialized
INFO - 2022-07-17 08:04:44 --> Output Class Initialized
INFO - 2022-07-17 08:04:44 --> Security Class Initialized
DEBUG - 2022-07-17 08:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 08:04:44 --> Input Class Initialized
INFO - 2022-07-17 08:04:44 --> Language Class Initialized
INFO - 2022-07-17 08:04:44 --> Loader Class Initialized
INFO - 2022-07-17 08:04:44 --> Helper loaded: url_helper
INFO - 2022-07-17 08:04:44 --> Helper loaded: file_helper
INFO - 2022-07-17 08:04:44 --> Database Driver Class Initialized
INFO - 2022-07-17 08:04:44 --> Email Class Initialized
DEBUG - 2022-07-17 08:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 08:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 08:04:44 --> Controller Class Initialized
INFO - 2022-07-17 08:04:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 08:04:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 13:34:45 --> Severity: Notice --> Trying to get property 'td_tk' of non-object C:\wamp64\www\qr\application\controllers\Tokenctrl.php 431
INFO - 2022-07-17 13:34:45 --> Final output sent to browser
DEBUG - 2022-07-17 13:34:45 --> Total execution time: 0.2527
INFO - 2022-07-17 08:05:05 --> Config Class Initialized
INFO - 2022-07-17 08:05:05 --> Hooks Class Initialized
DEBUG - 2022-07-17 08:05:05 --> UTF-8 Support Enabled
INFO - 2022-07-17 08:05:05 --> Utf8 Class Initialized
INFO - 2022-07-17 08:05:05 --> URI Class Initialized
INFO - 2022-07-17 08:05:05 --> Router Class Initialized
INFO - 2022-07-17 08:05:05 --> Output Class Initialized
INFO - 2022-07-17 08:05:05 --> Security Class Initialized
DEBUG - 2022-07-17 08:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 08:05:05 --> Input Class Initialized
INFO - 2022-07-17 08:05:05 --> Language Class Initialized
INFO - 2022-07-17 08:05:05 --> Loader Class Initialized
INFO - 2022-07-17 08:05:05 --> Helper loaded: url_helper
INFO - 2022-07-17 08:05:05 --> Helper loaded: file_helper
INFO - 2022-07-17 08:05:05 --> Database Driver Class Initialized
INFO - 2022-07-17 08:05:05 --> Email Class Initialized
DEBUG - 2022-07-17 08:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 08:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 08:05:05 --> Controller Class Initialized
INFO - 2022-07-17 08:05:05 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 08:05:05 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 13:35:05 --> Final output sent to browser
DEBUG - 2022-07-17 13:35:05 --> Total execution time: 0.1955
INFO - 2022-07-17 08:05:49 --> Config Class Initialized
INFO - 2022-07-17 08:05:49 --> Hooks Class Initialized
DEBUG - 2022-07-17 08:05:49 --> UTF-8 Support Enabled
INFO - 2022-07-17 08:05:49 --> Utf8 Class Initialized
INFO - 2022-07-17 08:05:49 --> URI Class Initialized
INFO - 2022-07-17 08:05:49 --> Router Class Initialized
INFO - 2022-07-17 08:05:49 --> Output Class Initialized
INFO - 2022-07-17 08:05:49 --> Security Class Initialized
DEBUG - 2022-07-17 08:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 08:05:49 --> Input Class Initialized
INFO - 2022-07-17 08:05:49 --> Language Class Initialized
INFO - 2022-07-17 08:05:49 --> Loader Class Initialized
INFO - 2022-07-17 08:05:49 --> Helper loaded: url_helper
INFO - 2022-07-17 08:05:49 --> Helper loaded: file_helper
INFO - 2022-07-17 08:05:49 --> Database Driver Class Initialized
INFO - 2022-07-17 08:05:49 --> Email Class Initialized
DEBUG - 2022-07-17 08:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 08:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 08:05:49 --> Controller Class Initialized
INFO - 2022-07-17 08:05:49 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 08:05:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 13:35:49 --> Severity: Notice --> Trying to get property 'td_tk' of non-object C:\wamp64\www\qr\application\controllers\Tokenctrl.php 430
INFO - 2022-07-17 13:35:49 --> Final output sent to browser
DEBUG - 2022-07-17 13:35:49 --> Total execution time: 0.1764
INFO - 2022-07-17 08:06:56 --> Config Class Initialized
INFO - 2022-07-17 08:06:56 --> Hooks Class Initialized
DEBUG - 2022-07-17 08:06:56 --> UTF-8 Support Enabled
INFO - 2022-07-17 08:06:56 --> Utf8 Class Initialized
INFO - 2022-07-17 08:06:56 --> URI Class Initialized
INFO - 2022-07-17 08:06:56 --> Router Class Initialized
INFO - 2022-07-17 08:06:56 --> Output Class Initialized
INFO - 2022-07-17 08:06:56 --> Security Class Initialized
DEBUG - 2022-07-17 08:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 08:06:56 --> Input Class Initialized
INFO - 2022-07-17 08:06:56 --> Language Class Initialized
INFO - 2022-07-17 08:06:56 --> Loader Class Initialized
INFO - 2022-07-17 08:06:56 --> Helper loaded: url_helper
INFO - 2022-07-17 08:06:56 --> Helper loaded: file_helper
INFO - 2022-07-17 08:06:56 --> Database Driver Class Initialized
INFO - 2022-07-17 08:06:56 --> Email Class Initialized
DEBUG - 2022-07-17 08:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 08:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 08:06:56 --> Controller Class Initialized
INFO - 2022-07-17 08:06:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 08:06:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 08:06:56 --> Severity: Notice --> Undefined variable: Date C:\wamp64\www\qr\application\controllers\Tokenctrl.php 471
ERROR - 2022-07-17 08:06:57 --> Severity: Notice --> Trying to get property 'td_tk' of non-object C:\wamp64\www\qr\application\controllers\Tokenctrl.php 490
DEBUG - 2022-07-17 08:06:57 --> insertedINSERT INTO `tokendetails` (`td_tk`, `td_cs`, `td_visited_date`) VALUES (2, 0, '2022-07-17')
INFO - 2022-07-17 08:06:57 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-17 08:06:57 --> Final output sent to browser
DEBUG - 2022-07-17 08:06:57 --> Total execution time: 0.3745
INFO - 2022-07-17 08:06:59 --> Config Class Initialized
INFO - 2022-07-17 08:06:59 --> Hooks Class Initialized
DEBUG - 2022-07-17 08:06:59 --> UTF-8 Support Enabled
INFO - 2022-07-17 08:06:59 --> Utf8 Class Initialized
INFO - 2022-07-17 08:06:59 --> URI Class Initialized
INFO - 2022-07-17 08:06:59 --> Router Class Initialized
INFO - 2022-07-17 08:06:59 --> Output Class Initialized
INFO - 2022-07-17 08:06:59 --> Security Class Initialized
DEBUG - 2022-07-17 08:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 08:06:59 --> Input Class Initialized
INFO - 2022-07-17 08:06:59 --> Language Class Initialized
INFO - 2022-07-17 08:06:59 --> Loader Class Initialized
INFO - 2022-07-17 08:06:59 --> Helper loaded: url_helper
INFO - 2022-07-17 08:06:59 --> Helper loaded: file_helper
INFO - 2022-07-17 08:06:59 --> Database Driver Class Initialized
INFO - 2022-07-17 08:06:59 --> Email Class Initialized
DEBUG - 2022-07-17 08:06:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 08:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 08:06:59 --> Controller Class Initialized
INFO - 2022-07-17 08:06:59 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 08:06:59 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 08:06:59 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-17 08:06:59 --> Final output sent to browser
DEBUG - 2022-07-17 08:06:59 --> Total execution time: 0.2846
INFO - 2022-07-17 08:07:02 --> Config Class Initialized
INFO - 2022-07-17 08:07:02 --> Hooks Class Initialized
DEBUG - 2022-07-17 08:07:02 --> UTF-8 Support Enabled
INFO - 2022-07-17 08:07:02 --> Utf8 Class Initialized
INFO - 2022-07-17 08:07:02 --> URI Class Initialized
INFO - 2022-07-17 08:07:02 --> Router Class Initialized
INFO - 2022-07-17 08:07:02 --> Output Class Initialized
INFO - 2022-07-17 08:07:02 --> Security Class Initialized
DEBUG - 2022-07-17 08:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 08:07:02 --> Input Class Initialized
INFO - 2022-07-17 08:07:02 --> Language Class Initialized
INFO - 2022-07-17 08:07:02 --> Loader Class Initialized
INFO - 2022-07-17 08:07:02 --> Helper loaded: url_helper
INFO - 2022-07-17 08:07:02 --> Helper loaded: file_helper
INFO - 2022-07-17 08:07:02 --> Database Driver Class Initialized
INFO - 2022-07-17 08:07:02 --> Email Class Initialized
DEBUG - 2022-07-17 08:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 08:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 08:07:02 --> Controller Class Initialized
INFO - 2022-07-17 08:07:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 08:07:02 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 08:07:02 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-17 08:07:02 --> Final output sent to browser
DEBUG - 2022-07-17 08:07:02 --> Total execution time: 0.0731
INFO - 2022-07-17 08:07:16 --> Config Class Initialized
INFO - 2022-07-17 08:07:16 --> Hooks Class Initialized
DEBUG - 2022-07-17 08:07:16 --> UTF-8 Support Enabled
INFO - 2022-07-17 08:07:16 --> Utf8 Class Initialized
INFO - 2022-07-17 08:07:16 --> URI Class Initialized
INFO - 2022-07-17 08:07:16 --> Router Class Initialized
INFO - 2022-07-17 08:07:16 --> Output Class Initialized
INFO - 2022-07-17 08:07:16 --> Security Class Initialized
DEBUG - 2022-07-17 08:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 08:07:16 --> Input Class Initialized
INFO - 2022-07-17 08:07:16 --> Language Class Initialized
INFO - 2022-07-17 08:07:16 --> Loader Class Initialized
INFO - 2022-07-17 08:07:16 --> Helper loaded: url_helper
INFO - 2022-07-17 08:07:16 --> Helper loaded: file_helper
INFO - 2022-07-17 08:07:16 --> Database Driver Class Initialized
INFO - 2022-07-17 08:07:16 --> Email Class Initialized
DEBUG - 2022-07-17 08:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 08:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 08:07:16 --> Controller Class Initialized
INFO - 2022-07-17 08:07:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 08:07:16 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 08:07:16 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-17 08:07:16 --> Final output sent to browser
DEBUG - 2022-07-17 08:07:16 --> Total execution time: 0.0574
INFO - 2022-07-17 08:07:41 --> Config Class Initialized
INFO - 2022-07-17 08:07:41 --> Hooks Class Initialized
DEBUG - 2022-07-17 08:07:41 --> UTF-8 Support Enabled
INFO - 2022-07-17 08:07:41 --> Utf8 Class Initialized
INFO - 2022-07-17 08:07:41 --> URI Class Initialized
INFO - 2022-07-17 08:07:41 --> Router Class Initialized
INFO - 2022-07-17 08:07:41 --> Output Class Initialized
INFO - 2022-07-17 08:07:41 --> Security Class Initialized
DEBUG - 2022-07-17 08:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 08:07:41 --> Input Class Initialized
INFO - 2022-07-17 08:07:41 --> Language Class Initialized
INFO - 2022-07-17 08:07:41 --> Loader Class Initialized
INFO - 2022-07-17 08:07:41 --> Helper loaded: url_helper
INFO - 2022-07-17 08:07:41 --> Helper loaded: file_helper
INFO - 2022-07-17 08:07:41 --> Database Driver Class Initialized
INFO - 2022-07-17 08:07:41 --> Email Class Initialized
DEBUG - 2022-07-17 08:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 08:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 08:07:41 --> Controller Class Initialized
INFO - 2022-07-17 08:07:41 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 08:07:41 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 13:37:41 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-07-17 13:37:41 --> Final output sent to browser
DEBUG - 2022-07-17 13:37:41 --> Total execution time: 0.1394
INFO - 2022-07-17 08:07:55 --> Config Class Initialized
INFO - 2022-07-17 08:07:55 --> Hooks Class Initialized
DEBUG - 2022-07-17 08:07:55 --> UTF-8 Support Enabled
INFO - 2022-07-17 08:07:55 --> Utf8 Class Initialized
INFO - 2022-07-17 08:07:55 --> URI Class Initialized
INFO - 2022-07-17 08:07:55 --> Router Class Initialized
INFO - 2022-07-17 08:07:55 --> Output Class Initialized
INFO - 2022-07-17 08:07:55 --> Security Class Initialized
DEBUG - 2022-07-17 08:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 08:07:55 --> Input Class Initialized
INFO - 2022-07-17 08:07:55 --> Language Class Initialized
INFO - 2022-07-17 08:07:55 --> Loader Class Initialized
INFO - 2022-07-17 08:07:55 --> Helper loaded: url_helper
INFO - 2022-07-17 08:07:55 --> Helper loaded: file_helper
INFO - 2022-07-17 08:07:55 --> Database Driver Class Initialized
INFO - 2022-07-17 08:07:55 --> Email Class Initialized
DEBUG - 2022-07-17 08:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 08:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 08:07:55 --> Controller Class Initialized
INFO - 2022-07-17 08:07:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 08:07:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 13:37:55 --> Final output sent to browser
DEBUG - 2022-07-17 13:37:55 --> Total execution time: 0.1208
INFO - 2022-07-17 08:15:55 --> Config Class Initialized
INFO - 2022-07-17 08:15:55 --> Hooks Class Initialized
DEBUG - 2022-07-17 08:15:55 --> UTF-8 Support Enabled
INFO - 2022-07-17 08:15:55 --> Utf8 Class Initialized
INFO - 2022-07-17 08:15:55 --> URI Class Initialized
INFO - 2022-07-17 08:15:55 --> Router Class Initialized
INFO - 2022-07-17 08:15:55 --> Output Class Initialized
INFO - 2022-07-17 08:15:55 --> Security Class Initialized
DEBUG - 2022-07-17 08:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 08:15:55 --> Input Class Initialized
INFO - 2022-07-17 08:15:55 --> Language Class Initialized
INFO - 2022-07-17 08:15:55 --> Loader Class Initialized
INFO - 2022-07-17 08:15:55 --> Helper loaded: url_helper
INFO - 2022-07-17 08:15:55 --> Helper loaded: file_helper
INFO - 2022-07-17 08:15:55 --> Database Driver Class Initialized
INFO - 2022-07-17 08:15:55 --> Email Class Initialized
DEBUG - 2022-07-17 08:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 08:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 08:15:55 --> Controller Class Initialized
INFO - 2022-07-17 08:15:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 08:15:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 13:45:55 --> Severity: Warning --> time() expects exactly 0 parameters, 2 given C:\wamp64\www\qr\application\controllers\Tokenctrl.php 437
INFO - 2022-07-17 13:45:55 --> Final output sent to browser
DEBUG - 2022-07-17 13:45:55 --> Total execution time: 0.0611
INFO - 2022-07-17 08:34:24 --> Config Class Initialized
INFO - 2022-07-17 08:34:24 --> Hooks Class Initialized
DEBUG - 2022-07-17 08:34:24 --> UTF-8 Support Enabled
INFO - 2022-07-17 08:34:24 --> Utf8 Class Initialized
INFO - 2022-07-17 08:34:24 --> URI Class Initialized
INFO - 2022-07-17 08:34:24 --> Router Class Initialized
INFO - 2022-07-17 08:34:24 --> Output Class Initialized
INFO - 2022-07-17 08:34:24 --> Security Class Initialized
DEBUG - 2022-07-17 08:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 08:34:24 --> Input Class Initialized
INFO - 2022-07-17 08:34:24 --> Language Class Initialized
INFO - 2022-07-17 08:34:24 --> Loader Class Initialized
INFO - 2022-07-17 08:34:24 --> Helper loaded: url_helper
INFO - 2022-07-17 08:34:24 --> Helper loaded: file_helper
INFO - 2022-07-17 08:34:24 --> Database Driver Class Initialized
INFO - 2022-07-17 08:34:24 --> Email Class Initialized
DEBUG - 2022-07-17 08:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 08:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 08:34:24 --> Controller Class Initialized
INFO - 2022-07-17 08:34:24 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 08:34:24 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 14:04:24 --> Final output sent to browser
DEBUG - 2022-07-17 14:04:24 --> Total execution time: 0.1806
INFO - 2022-07-17 08:34:27 --> Config Class Initialized
INFO - 2022-07-17 08:34:27 --> Hooks Class Initialized
DEBUG - 2022-07-17 08:34:27 --> UTF-8 Support Enabled
INFO - 2022-07-17 08:34:27 --> Utf8 Class Initialized
INFO - 2022-07-17 08:34:27 --> URI Class Initialized
INFO - 2022-07-17 08:34:27 --> Router Class Initialized
INFO - 2022-07-17 08:34:27 --> Output Class Initialized
INFO - 2022-07-17 08:34:27 --> Security Class Initialized
DEBUG - 2022-07-17 08:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 08:34:27 --> Input Class Initialized
INFO - 2022-07-17 08:34:27 --> Language Class Initialized
INFO - 2022-07-17 08:34:27 --> Loader Class Initialized
INFO - 2022-07-17 08:34:27 --> Helper loaded: url_helper
INFO - 2022-07-17 08:34:27 --> Helper loaded: file_helper
INFO - 2022-07-17 08:34:27 --> Database Driver Class Initialized
INFO - 2022-07-17 08:34:27 --> Email Class Initialized
DEBUG - 2022-07-17 08:34:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 08:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 08:34:27 --> Controller Class Initialized
INFO - 2022-07-17 08:34:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 08:34:27 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 14:04:27 --> Final output sent to browser
DEBUG - 2022-07-17 14:04:27 --> Total execution time: 0.0513
INFO - 2022-07-17 08:37:43 --> Config Class Initialized
INFO - 2022-07-17 08:37:43 --> Hooks Class Initialized
DEBUG - 2022-07-17 08:37:43 --> UTF-8 Support Enabled
INFO - 2022-07-17 08:37:43 --> Utf8 Class Initialized
INFO - 2022-07-17 08:37:43 --> URI Class Initialized
INFO - 2022-07-17 08:37:43 --> Router Class Initialized
INFO - 2022-07-17 08:37:43 --> Output Class Initialized
INFO - 2022-07-17 08:37:43 --> Security Class Initialized
DEBUG - 2022-07-17 08:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 08:37:43 --> Input Class Initialized
INFO - 2022-07-17 08:37:43 --> Language Class Initialized
INFO - 2022-07-17 08:37:43 --> Loader Class Initialized
INFO - 2022-07-17 08:37:43 --> Helper loaded: url_helper
INFO - 2022-07-17 08:37:43 --> Helper loaded: file_helper
INFO - 2022-07-17 08:37:43 --> Database Driver Class Initialized
INFO - 2022-07-17 08:37:43 --> Email Class Initialized
DEBUG - 2022-07-17 08:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 08:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 08:37:43 --> Controller Class Initialized
INFO - 2022-07-17 08:37:43 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 08:37:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 08:37:43 --> Severity: Notice --> Undefined variable: Date C:\wamp64\www\qr\application\controllers\Tokenctrl.php 476
DEBUG - 2022-07-17 14:07:43 --> insertedINSERT INTO `tokendetails` (`td_tk`, `td_cs`, `td_visited_date`, `td_est_time`) VALUES (3, 0, '2022-07-17', '05:30:00')
INFO - 2022-07-17 14:07:43 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-17 14:07:43 --> Final output sent to browser
DEBUG - 2022-07-17 14:07:43 --> Total execution time: 0.0856
INFO - 2022-07-17 08:38:49 --> Config Class Initialized
INFO - 2022-07-17 08:38:49 --> Hooks Class Initialized
DEBUG - 2022-07-17 08:38:49 --> UTF-8 Support Enabled
INFO - 2022-07-17 08:38:49 --> Utf8 Class Initialized
INFO - 2022-07-17 08:38:49 --> URI Class Initialized
INFO - 2022-07-17 08:38:49 --> Router Class Initialized
INFO - 2022-07-17 08:38:49 --> Output Class Initialized
INFO - 2022-07-17 08:38:49 --> Security Class Initialized
DEBUG - 2022-07-17 08:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 08:38:49 --> Input Class Initialized
INFO - 2022-07-17 08:38:49 --> Language Class Initialized
INFO - 2022-07-17 08:38:49 --> Loader Class Initialized
INFO - 2022-07-17 08:38:49 --> Helper loaded: url_helper
INFO - 2022-07-17 08:38:49 --> Helper loaded: file_helper
INFO - 2022-07-17 08:38:49 --> Database Driver Class Initialized
INFO - 2022-07-17 08:38:49 --> Email Class Initialized
DEBUG - 2022-07-17 08:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 08:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 08:38:49 --> Controller Class Initialized
INFO - 2022-07-17 08:38:49 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 08:38:49 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 08:38:49 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-17 08:38:49 --> Final output sent to browser
DEBUG - 2022-07-17 08:38:49 --> Total execution time: 0.1890
INFO - 2022-07-17 08:39:40 --> Config Class Initialized
INFO - 2022-07-17 08:39:40 --> Hooks Class Initialized
DEBUG - 2022-07-17 08:39:40 --> UTF-8 Support Enabled
INFO - 2022-07-17 08:39:40 --> Utf8 Class Initialized
INFO - 2022-07-17 08:39:40 --> URI Class Initialized
INFO - 2022-07-17 08:39:40 --> Router Class Initialized
INFO - 2022-07-17 08:39:40 --> Output Class Initialized
INFO - 2022-07-17 08:39:40 --> Security Class Initialized
DEBUG - 2022-07-17 08:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 08:39:40 --> Input Class Initialized
INFO - 2022-07-17 08:39:40 --> Language Class Initialized
INFO - 2022-07-17 08:39:40 --> Loader Class Initialized
INFO - 2022-07-17 08:39:40 --> Helper loaded: url_helper
INFO - 2022-07-17 08:39:40 --> Helper loaded: file_helper
INFO - 2022-07-17 08:39:40 --> Database Driver Class Initialized
INFO - 2022-07-17 08:39:40 --> Email Class Initialized
DEBUG - 2022-07-17 08:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 08:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 08:39:40 --> Controller Class Initialized
INFO - 2022-07-17 08:39:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 08:39:40 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 14:09:40 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-07-17 14:09:40 --> Final output sent to browser
DEBUG - 2022-07-17 14:09:40 --> Total execution time: 0.1263
INFO - 2022-07-17 08:39:56 --> Config Class Initialized
INFO - 2022-07-17 08:39:56 --> Hooks Class Initialized
DEBUG - 2022-07-17 08:39:56 --> UTF-8 Support Enabled
INFO - 2022-07-17 08:39:56 --> Utf8 Class Initialized
INFO - 2022-07-17 08:39:56 --> URI Class Initialized
INFO - 2022-07-17 08:39:56 --> Router Class Initialized
INFO - 2022-07-17 08:39:56 --> Output Class Initialized
INFO - 2022-07-17 08:39:56 --> Security Class Initialized
DEBUG - 2022-07-17 08:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 08:39:56 --> Input Class Initialized
INFO - 2022-07-17 08:39:56 --> Language Class Initialized
INFO - 2022-07-17 08:39:56 --> Loader Class Initialized
INFO - 2022-07-17 08:39:56 --> Helper loaded: url_helper
INFO - 2022-07-17 08:39:56 --> Helper loaded: file_helper
INFO - 2022-07-17 08:39:56 --> Database Driver Class Initialized
INFO - 2022-07-17 08:39:56 --> Email Class Initialized
DEBUG - 2022-07-17 08:39:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 08:39:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 08:39:56 --> Controller Class Initialized
INFO - 2022-07-17 08:39:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 08:39:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 14:09:56 --> Final output sent to browser
DEBUG - 2022-07-17 14:09:56 --> Total execution time: 0.0289
INFO - 2022-07-17 08:39:57 --> Config Class Initialized
INFO - 2022-07-17 08:39:57 --> Hooks Class Initialized
DEBUG - 2022-07-17 08:39:57 --> UTF-8 Support Enabled
INFO - 2022-07-17 08:39:57 --> Utf8 Class Initialized
INFO - 2022-07-17 08:39:57 --> URI Class Initialized
INFO - 2022-07-17 08:39:57 --> Router Class Initialized
INFO - 2022-07-17 08:39:57 --> Output Class Initialized
INFO - 2022-07-17 08:39:57 --> Security Class Initialized
DEBUG - 2022-07-17 08:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 08:39:57 --> Input Class Initialized
INFO - 2022-07-17 08:39:57 --> Language Class Initialized
INFO - 2022-07-17 08:39:57 --> Loader Class Initialized
INFO - 2022-07-17 08:39:57 --> Helper loaded: url_helper
INFO - 2022-07-17 08:39:57 --> Helper loaded: file_helper
INFO - 2022-07-17 08:39:57 --> Database Driver Class Initialized
INFO - 2022-07-17 08:39:57 --> Email Class Initialized
DEBUG - 2022-07-17 08:39:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 08:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 08:39:57 --> Controller Class Initialized
INFO - 2022-07-17 08:39:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 08:39:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 14:09:57 --> Final output sent to browser
DEBUG - 2022-07-17 14:09:57 --> Total execution time: 0.1229
INFO - 2022-07-17 08:39:58 --> Config Class Initialized
INFO - 2022-07-17 08:39:58 --> Hooks Class Initialized
DEBUG - 2022-07-17 08:39:58 --> UTF-8 Support Enabled
INFO - 2022-07-17 08:39:58 --> Utf8 Class Initialized
INFO - 2022-07-17 08:39:58 --> URI Class Initialized
INFO - 2022-07-17 08:39:58 --> Router Class Initialized
INFO - 2022-07-17 08:39:58 --> Output Class Initialized
INFO - 2022-07-17 08:39:58 --> Security Class Initialized
DEBUG - 2022-07-17 08:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 08:39:58 --> Input Class Initialized
INFO - 2022-07-17 08:39:58 --> Language Class Initialized
INFO - 2022-07-17 08:39:58 --> Loader Class Initialized
INFO - 2022-07-17 08:39:58 --> Helper loaded: url_helper
INFO - 2022-07-17 08:39:58 --> Helper loaded: file_helper
INFO - 2022-07-17 08:39:58 --> Database Driver Class Initialized
INFO - 2022-07-17 08:39:58 --> Email Class Initialized
DEBUG - 2022-07-17 08:39:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 08:39:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 08:39:58 --> Controller Class Initialized
INFO - 2022-07-17 08:39:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 08:39:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 14:09:58 --> Final output sent to browser
DEBUG - 2022-07-17 14:09:58 --> Total execution time: 0.0703
INFO - 2022-07-17 08:39:58 --> Config Class Initialized
INFO - 2022-07-17 08:39:58 --> Hooks Class Initialized
DEBUG - 2022-07-17 08:39:58 --> UTF-8 Support Enabled
INFO - 2022-07-17 08:39:58 --> Utf8 Class Initialized
INFO - 2022-07-17 08:39:58 --> URI Class Initialized
INFO - 2022-07-17 08:39:58 --> Router Class Initialized
INFO - 2022-07-17 08:39:58 --> Output Class Initialized
INFO - 2022-07-17 08:39:58 --> Security Class Initialized
DEBUG - 2022-07-17 08:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 08:39:58 --> Input Class Initialized
INFO - 2022-07-17 08:39:58 --> Language Class Initialized
INFO - 2022-07-17 08:39:58 --> Loader Class Initialized
INFO - 2022-07-17 08:39:58 --> Helper loaded: url_helper
INFO - 2022-07-17 08:39:58 --> Helper loaded: file_helper
INFO - 2022-07-17 08:39:58 --> Database Driver Class Initialized
INFO - 2022-07-17 08:39:58 --> Email Class Initialized
DEBUG - 2022-07-17 08:39:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 08:39:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 08:39:58 --> Controller Class Initialized
INFO - 2022-07-17 08:39:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 08:39:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 14:09:58 --> Final output sent to browser
DEBUG - 2022-07-17 14:09:58 --> Total execution time: 0.1358
INFO - 2022-07-17 08:39:58 --> Config Class Initialized
INFO - 2022-07-17 08:39:58 --> Hooks Class Initialized
DEBUG - 2022-07-17 08:39:58 --> UTF-8 Support Enabled
INFO - 2022-07-17 08:39:58 --> Utf8 Class Initialized
INFO - 2022-07-17 08:39:58 --> URI Class Initialized
INFO - 2022-07-17 08:39:58 --> Router Class Initialized
INFO - 2022-07-17 08:39:58 --> Output Class Initialized
INFO - 2022-07-17 08:39:58 --> Security Class Initialized
DEBUG - 2022-07-17 08:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 08:39:58 --> Input Class Initialized
INFO - 2022-07-17 08:39:58 --> Language Class Initialized
INFO - 2022-07-17 08:39:58 --> Loader Class Initialized
INFO - 2022-07-17 08:39:58 --> Helper loaded: url_helper
INFO - 2022-07-17 08:39:58 --> Helper loaded: file_helper
INFO - 2022-07-17 08:39:58 --> Database Driver Class Initialized
INFO - 2022-07-17 08:39:58 --> Email Class Initialized
DEBUG - 2022-07-17 08:39:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 08:39:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 08:39:58 --> Controller Class Initialized
INFO - 2022-07-17 08:39:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 08:39:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 14:09:58 --> Final output sent to browser
DEBUG - 2022-07-17 14:09:58 --> Total execution time: 0.0645
INFO - 2022-07-17 08:39:58 --> Config Class Initialized
INFO - 2022-07-17 08:39:58 --> Hooks Class Initialized
DEBUG - 2022-07-17 08:39:58 --> UTF-8 Support Enabled
INFO - 2022-07-17 08:39:58 --> Utf8 Class Initialized
INFO - 2022-07-17 08:39:58 --> URI Class Initialized
INFO - 2022-07-17 08:39:58 --> Router Class Initialized
INFO - 2022-07-17 08:39:58 --> Output Class Initialized
INFO - 2022-07-17 08:39:58 --> Security Class Initialized
DEBUG - 2022-07-17 08:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 08:39:58 --> Input Class Initialized
INFO - 2022-07-17 08:39:58 --> Language Class Initialized
INFO - 2022-07-17 08:39:58 --> Loader Class Initialized
INFO - 2022-07-17 08:39:58 --> Helper loaded: url_helper
INFO - 2022-07-17 08:39:58 --> Helper loaded: file_helper
INFO - 2022-07-17 08:39:58 --> Database Driver Class Initialized
INFO - 2022-07-17 08:39:58 --> Email Class Initialized
DEBUG - 2022-07-17 08:39:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 08:39:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 08:39:58 --> Controller Class Initialized
INFO - 2022-07-17 08:39:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 08:39:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 14:09:58 --> Final output sent to browser
DEBUG - 2022-07-17 14:09:58 --> Total execution time: 0.0349
INFO - 2022-07-17 08:39:59 --> Config Class Initialized
INFO - 2022-07-17 08:39:59 --> Hooks Class Initialized
DEBUG - 2022-07-17 08:39:59 --> UTF-8 Support Enabled
INFO - 2022-07-17 08:39:59 --> Utf8 Class Initialized
INFO - 2022-07-17 08:39:59 --> URI Class Initialized
INFO - 2022-07-17 08:39:59 --> Router Class Initialized
INFO - 2022-07-17 08:39:59 --> Output Class Initialized
INFO - 2022-07-17 08:39:59 --> Security Class Initialized
DEBUG - 2022-07-17 08:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 08:39:59 --> Input Class Initialized
INFO - 2022-07-17 08:39:59 --> Language Class Initialized
INFO - 2022-07-17 08:39:59 --> Loader Class Initialized
INFO - 2022-07-17 08:39:59 --> Helper loaded: url_helper
INFO - 2022-07-17 08:39:59 --> Helper loaded: file_helper
INFO - 2022-07-17 08:39:59 --> Database Driver Class Initialized
INFO - 2022-07-17 08:39:59 --> Email Class Initialized
DEBUG - 2022-07-17 08:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 08:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 08:39:59 --> Controller Class Initialized
INFO - 2022-07-17 08:39:59 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 08:39:59 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 14:09:59 --> Final output sent to browser
DEBUG - 2022-07-17 14:09:59 --> Total execution time: 0.1237
INFO - 2022-07-17 08:39:59 --> Config Class Initialized
INFO - 2022-07-17 08:39:59 --> Hooks Class Initialized
DEBUG - 2022-07-17 08:39:59 --> UTF-8 Support Enabled
INFO - 2022-07-17 08:39:59 --> Utf8 Class Initialized
INFO - 2022-07-17 08:39:59 --> URI Class Initialized
INFO - 2022-07-17 08:39:59 --> Router Class Initialized
INFO - 2022-07-17 08:39:59 --> Output Class Initialized
INFO - 2022-07-17 08:39:59 --> Security Class Initialized
DEBUG - 2022-07-17 08:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 08:39:59 --> Input Class Initialized
INFO - 2022-07-17 08:39:59 --> Language Class Initialized
INFO - 2022-07-17 08:39:59 --> Loader Class Initialized
INFO - 2022-07-17 08:39:59 --> Helper loaded: url_helper
INFO - 2022-07-17 08:39:59 --> Helper loaded: file_helper
INFO - 2022-07-17 08:39:59 --> Database Driver Class Initialized
INFO - 2022-07-17 08:39:59 --> Email Class Initialized
DEBUG - 2022-07-17 08:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 08:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 08:39:59 --> Controller Class Initialized
INFO - 2022-07-17 08:39:59 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 08:39:59 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 14:09:59 --> Final output sent to browser
DEBUG - 2022-07-17 14:09:59 --> Total execution time: 0.0439
INFO - 2022-07-17 08:39:59 --> Config Class Initialized
INFO - 2022-07-17 08:39:59 --> Hooks Class Initialized
DEBUG - 2022-07-17 08:39:59 --> UTF-8 Support Enabled
INFO - 2022-07-17 08:39:59 --> Utf8 Class Initialized
INFO - 2022-07-17 08:39:59 --> URI Class Initialized
INFO - 2022-07-17 08:39:59 --> Router Class Initialized
INFO - 2022-07-17 08:39:59 --> Output Class Initialized
INFO - 2022-07-17 08:39:59 --> Security Class Initialized
DEBUG - 2022-07-17 08:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 08:39:59 --> Input Class Initialized
INFO - 2022-07-17 08:39:59 --> Language Class Initialized
INFO - 2022-07-17 08:39:59 --> Loader Class Initialized
INFO - 2022-07-17 08:39:59 --> Helper loaded: url_helper
INFO - 2022-07-17 08:39:59 --> Helper loaded: file_helper
INFO - 2022-07-17 08:39:59 --> Database Driver Class Initialized
INFO - 2022-07-17 08:39:59 --> Email Class Initialized
DEBUG - 2022-07-17 08:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 08:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 08:39:59 --> Controller Class Initialized
INFO - 2022-07-17 08:39:59 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 08:39:59 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 14:09:59 --> Final output sent to browser
DEBUG - 2022-07-17 14:09:59 --> Total execution time: 0.0434
INFO - 2022-07-17 08:39:59 --> Config Class Initialized
INFO - 2022-07-17 08:39:59 --> Hooks Class Initialized
DEBUG - 2022-07-17 08:39:59 --> UTF-8 Support Enabled
INFO - 2022-07-17 08:39:59 --> Utf8 Class Initialized
INFO - 2022-07-17 08:39:59 --> URI Class Initialized
INFO - 2022-07-17 08:39:59 --> Router Class Initialized
INFO - 2022-07-17 08:39:59 --> Output Class Initialized
INFO - 2022-07-17 08:39:59 --> Security Class Initialized
DEBUG - 2022-07-17 08:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 08:39:59 --> Input Class Initialized
INFO - 2022-07-17 08:39:59 --> Language Class Initialized
INFO - 2022-07-17 08:39:59 --> Loader Class Initialized
INFO - 2022-07-17 08:39:59 --> Helper loaded: url_helper
INFO - 2022-07-17 08:39:59 --> Helper loaded: file_helper
INFO - 2022-07-17 08:39:59 --> Database Driver Class Initialized
INFO - 2022-07-17 08:39:59 --> Email Class Initialized
DEBUG - 2022-07-17 08:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 08:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 08:39:59 --> Controller Class Initialized
INFO - 2022-07-17 08:39:59 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 08:39:59 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 14:09:59 --> Final output sent to browser
DEBUG - 2022-07-17 14:09:59 --> Total execution time: 0.0522
INFO - 2022-07-17 08:39:59 --> Config Class Initialized
INFO - 2022-07-17 08:39:59 --> Hooks Class Initialized
DEBUG - 2022-07-17 08:39:59 --> UTF-8 Support Enabled
INFO - 2022-07-17 08:39:59 --> Utf8 Class Initialized
INFO - 2022-07-17 08:39:59 --> URI Class Initialized
INFO - 2022-07-17 08:39:59 --> Router Class Initialized
INFO - 2022-07-17 08:39:59 --> Output Class Initialized
INFO - 2022-07-17 08:39:59 --> Security Class Initialized
DEBUG - 2022-07-17 08:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 08:39:59 --> Input Class Initialized
INFO - 2022-07-17 08:39:59 --> Language Class Initialized
INFO - 2022-07-17 08:39:59 --> Loader Class Initialized
INFO - 2022-07-17 08:39:59 --> Helper loaded: url_helper
INFO - 2022-07-17 08:39:59 --> Helper loaded: file_helper
INFO - 2022-07-17 08:39:59 --> Database Driver Class Initialized
INFO - 2022-07-17 08:39:59 --> Email Class Initialized
DEBUG - 2022-07-17 08:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 08:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 08:39:59 --> Controller Class Initialized
INFO - 2022-07-17 08:39:59 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 08:39:59 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 14:09:59 --> Final output sent to browser
DEBUG - 2022-07-17 14:09:59 --> Total execution time: 0.0590
INFO - 2022-07-17 08:40:00 --> Config Class Initialized
INFO - 2022-07-17 08:40:00 --> Hooks Class Initialized
DEBUG - 2022-07-17 08:40:00 --> UTF-8 Support Enabled
INFO - 2022-07-17 08:40:00 --> Utf8 Class Initialized
INFO - 2022-07-17 08:40:00 --> URI Class Initialized
INFO - 2022-07-17 08:40:00 --> Router Class Initialized
INFO - 2022-07-17 08:40:00 --> Output Class Initialized
INFO - 2022-07-17 08:40:00 --> Security Class Initialized
DEBUG - 2022-07-17 08:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 08:40:00 --> Input Class Initialized
INFO - 2022-07-17 08:40:00 --> Language Class Initialized
INFO - 2022-07-17 08:40:00 --> Loader Class Initialized
INFO - 2022-07-17 08:40:00 --> Helper loaded: url_helper
INFO - 2022-07-17 08:40:00 --> Helper loaded: file_helper
INFO - 2022-07-17 08:40:00 --> Database Driver Class Initialized
INFO - 2022-07-17 08:40:00 --> Email Class Initialized
DEBUG - 2022-07-17 08:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 08:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 08:40:00 --> Controller Class Initialized
INFO - 2022-07-17 08:40:00 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 08:40:00 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 14:10:00 --> Final output sent to browser
DEBUG - 2022-07-17 14:10:00 --> Total execution time: 0.0383
INFO - 2022-07-17 08:40:00 --> Config Class Initialized
INFO - 2022-07-17 08:40:00 --> Hooks Class Initialized
DEBUG - 2022-07-17 08:40:00 --> UTF-8 Support Enabled
INFO - 2022-07-17 08:40:00 --> Utf8 Class Initialized
INFO - 2022-07-17 08:40:00 --> URI Class Initialized
INFO - 2022-07-17 08:40:00 --> Router Class Initialized
INFO - 2022-07-17 08:40:00 --> Output Class Initialized
INFO - 2022-07-17 08:40:00 --> Security Class Initialized
DEBUG - 2022-07-17 08:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 08:40:00 --> Input Class Initialized
INFO - 2022-07-17 08:40:00 --> Language Class Initialized
INFO - 2022-07-17 08:40:00 --> Loader Class Initialized
INFO - 2022-07-17 08:40:00 --> Helper loaded: url_helper
INFO - 2022-07-17 08:40:00 --> Helper loaded: file_helper
INFO - 2022-07-17 08:40:00 --> Database Driver Class Initialized
INFO - 2022-07-17 08:40:00 --> Email Class Initialized
DEBUG - 2022-07-17 08:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 08:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 08:40:00 --> Controller Class Initialized
INFO - 2022-07-17 08:40:00 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 08:40:00 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 14:10:00 --> Final output sent to browser
DEBUG - 2022-07-17 14:10:00 --> Total execution time: 0.0593
INFO - 2022-07-17 08:44:02 --> Config Class Initialized
INFO - 2022-07-17 08:44:02 --> Hooks Class Initialized
DEBUG - 2022-07-17 08:44:02 --> UTF-8 Support Enabled
INFO - 2022-07-17 08:44:02 --> Utf8 Class Initialized
INFO - 2022-07-17 08:44:02 --> URI Class Initialized
INFO - 2022-07-17 08:44:02 --> Router Class Initialized
INFO - 2022-07-17 08:44:02 --> Output Class Initialized
INFO - 2022-07-17 08:44:02 --> Security Class Initialized
DEBUG - 2022-07-17 08:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 08:44:02 --> Input Class Initialized
INFO - 2022-07-17 08:44:02 --> Language Class Initialized
INFO - 2022-07-17 08:44:02 --> Loader Class Initialized
INFO - 2022-07-17 08:44:02 --> Helper loaded: url_helper
INFO - 2022-07-17 08:44:02 --> Helper loaded: file_helper
INFO - 2022-07-17 08:44:02 --> Database Driver Class Initialized
INFO - 2022-07-17 08:44:02 --> Email Class Initialized
DEBUG - 2022-07-17 08:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 08:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 08:44:02 --> Controller Class Initialized
INFO - 2022-07-17 08:44:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 08:44:02 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 08:44:02 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-17 08:44:02 --> Final output sent to browser
DEBUG - 2022-07-17 08:44:02 --> Total execution time: 0.1927
INFO - 2022-07-17 09:03:28 --> Config Class Initialized
INFO - 2022-07-17 09:03:28 --> Hooks Class Initialized
DEBUG - 2022-07-17 09:03:28 --> UTF-8 Support Enabled
INFO - 2022-07-17 09:03:28 --> Utf8 Class Initialized
INFO - 2022-07-17 09:03:28 --> URI Class Initialized
INFO - 2022-07-17 09:03:28 --> Router Class Initialized
INFO - 2022-07-17 09:03:28 --> Output Class Initialized
INFO - 2022-07-17 09:03:28 --> Security Class Initialized
DEBUG - 2022-07-17 09:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 09:03:28 --> Input Class Initialized
INFO - 2022-07-17 09:03:28 --> Language Class Initialized
INFO - 2022-07-17 09:03:28 --> Loader Class Initialized
INFO - 2022-07-17 09:03:28 --> Helper loaded: url_helper
INFO - 2022-07-17 09:03:28 --> Helper loaded: file_helper
INFO - 2022-07-17 09:03:28 --> Database Driver Class Initialized
INFO - 2022-07-17 09:03:29 --> Email Class Initialized
DEBUG - 2022-07-17 09:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 09:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 09:03:29 --> Controller Class Initialized
INFO - 2022-07-17 09:03:29 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 09:03:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 09:03:29 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\qr\application\views\tokenscreen\Tokenscreen_1.php 194
INFO - 2022-07-17 09:04:05 --> Config Class Initialized
INFO - 2022-07-17 09:04:05 --> Hooks Class Initialized
DEBUG - 2022-07-17 09:04:05 --> UTF-8 Support Enabled
INFO - 2022-07-17 09:04:05 --> Utf8 Class Initialized
INFO - 2022-07-17 09:04:05 --> URI Class Initialized
INFO - 2022-07-17 09:04:05 --> Router Class Initialized
INFO - 2022-07-17 09:04:05 --> Output Class Initialized
INFO - 2022-07-17 09:04:05 --> Security Class Initialized
DEBUG - 2022-07-17 09:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 09:04:05 --> Input Class Initialized
INFO - 2022-07-17 09:04:05 --> Language Class Initialized
INFO - 2022-07-17 09:04:05 --> Loader Class Initialized
INFO - 2022-07-17 09:04:05 --> Helper loaded: url_helper
INFO - 2022-07-17 09:04:05 --> Helper loaded: file_helper
INFO - 2022-07-17 09:04:05 --> Database Driver Class Initialized
INFO - 2022-07-17 09:04:05 --> Email Class Initialized
DEBUG - 2022-07-17 09:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 09:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 09:04:05 --> Controller Class Initialized
INFO - 2022-07-17 09:04:05 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 09:04:05 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 09:04:25 --> Config Class Initialized
INFO - 2022-07-17 09:04:25 --> Hooks Class Initialized
DEBUG - 2022-07-17 09:04:25 --> UTF-8 Support Enabled
INFO - 2022-07-17 09:04:25 --> Utf8 Class Initialized
INFO - 2022-07-17 09:04:25 --> URI Class Initialized
INFO - 2022-07-17 09:04:25 --> Router Class Initialized
INFO - 2022-07-17 09:04:25 --> Output Class Initialized
INFO - 2022-07-17 09:04:25 --> Security Class Initialized
DEBUG - 2022-07-17 09:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 09:04:25 --> Input Class Initialized
INFO - 2022-07-17 09:04:25 --> Language Class Initialized
INFO - 2022-07-17 09:04:25 --> Loader Class Initialized
INFO - 2022-07-17 09:04:25 --> Helper loaded: url_helper
INFO - 2022-07-17 09:04:25 --> Helper loaded: file_helper
INFO - 2022-07-17 09:04:25 --> Database Driver Class Initialized
INFO - 2022-07-17 09:04:25 --> Email Class Initialized
DEBUG - 2022-07-17 09:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 09:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 09:04:25 --> Controller Class Initialized
INFO - 2022-07-17 09:04:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 09:04:25 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 09:06:12 --> Config Class Initialized
INFO - 2022-07-17 09:06:12 --> Hooks Class Initialized
DEBUG - 2022-07-17 09:06:12 --> UTF-8 Support Enabled
INFO - 2022-07-17 09:06:12 --> Utf8 Class Initialized
INFO - 2022-07-17 09:06:12 --> URI Class Initialized
INFO - 2022-07-17 09:06:12 --> Router Class Initialized
INFO - 2022-07-17 09:06:12 --> Output Class Initialized
INFO - 2022-07-17 09:06:12 --> Security Class Initialized
DEBUG - 2022-07-17 09:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 09:06:12 --> Input Class Initialized
INFO - 2022-07-17 09:06:12 --> Language Class Initialized
INFO - 2022-07-17 09:06:12 --> Loader Class Initialized
INFO - 2022-07-17 09:06:12 --> Helper loaded: url_helper
INFO - 2022-07-17 09:06:12 --> Helper loaded: file_helper
INFO - 2022-07-17 09:06:12 --> Database Driver Class Initialized
INFO - 2022-07-17 09:06:12 --> Email Class Initialized
DEBUG - 2022-07-17 09:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 09:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 09:06:12 --> Controller Class Initialized
INFO - 2022-07-17 09:06:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 09:06:12 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 09:06:14 --> Config Class Initialized
INFO - 2022-07-17 09:06:14 --> Hooks Class Initialized
DEBUG - 2022-07-17 09:06:14 --> UTF-8 Support Enabled
INFO - 2022-07-17 09:06:14 --> Utf8 Class Initialized
INFO - 2022-07-17 09:06:14 --> URI Class Initialized
INFO - 2022-07-17 09:06:14 --> Router Class Initialized
INFO - 2022-07-17 09:06:14 --> Output Class Initialized
INFO - 2022-07-17 09:06:14 --> Security Class Initialized
DEBUG - 2022-07-17 09:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 09:06:14 --> Input Class Initialized
INFO - 2022-07-17 09:06:14 --> Language Class Initialized
INFO - 2022-07-17 09:06:14 --> Loader Class Initialized
INFO - 2022-07-17 09:06:14 --> Helper loaded: url_helper
INFO - 2022-07-17 09:06:14 --> Helper loaded: file_helper
INFO - 2022-07-17 09:06:14 --> Database Driver Class Initialized
INFO - 2022-07-17 09:06:14 --> Email Class Initialized
DEBUG - 2022-07-17 09:06:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 09:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 09:06:14 --> Controller Class Initialized
INFO - 2022-07-17 09:06:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 09:06:14 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 09:06:16 --> Config Class Initialized
INFO - 2022-07-17 09:06:16 --> Hooks Class Initialized
DEBUG - 2022-07-17 09:06:16 --> UTF-8 Support Enabled
INFO - 2022-07-17 09:06:16 --> Utf8 Class Initialized
INFO - 2022-07-17 09:06:16 --> URI Class Initialized
INFO - 2022-07-17 09:06:16 --> Router Class Initialized
INFO - 2022-07-17 09:06:16 --> Output Class Initialized
INFO - 2022-07-17 09:06:16 --> Security Class Initialized
DEBUG - 2022-07-17 09:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 09:06:16 --> Input Class Initialized
INFO - 2022-07-17 09:06:16 --> Language Class Initialized
INFO - 2022-07-17 09:06:16 --> Loader Class Initialized
INFO - 2022-07-17 09:06:16 --> Helper loaded: url_helper
INFO - 2022-07-17 09:06:16 --> Helper loaded: file_helper
INFO - 2022-07-17 09:06:16 --> Database Driver Class Initialized
INFO - 2022-07-17 09:06:16 --> Email Class Initialized
DEBUG - 2022-07-17 09:06:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 09:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 09:06:16 --> Controller Class Initialized
INFO - 2022-07-17 09:06:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 09:06:16 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 09:07:31 --> Config Class Initialized
INFO - 2022-07-17 09:07:31 --> Hooks Class Initialized
DEBUG - 2022-07-17 09:07:31 --> UTF-8 Support Enabled
INFO - 2022-07-17 09:07:31 --> Utf8 Class Initialized
INFO - 2022-07-17 09:07:31 --> URI Class Initialized
INFO - 2022-07-17 09:07:31 --> Router Class Initialized
INFO - 2022-07-17 09:07:31 --> Output Class Initialized
INFO - 2022-07-17 09:07:31 --> Security Class Initialized
DEBUG - 2022-07-17 09:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 09:07:31 --> Input Class Initialized
INFO - 2022-07-17 09:07:31 --> Language Class Initialized
INFO - 2022-07-17 09:07:31 --> Loader Class Initialized
INFO - 2022-07-17 09:07:31 --> Helper loaded: url_helper
INFO - 2022-07-17 09:07:31 --> Helper loaded: file_helper
INFO - 2022-07-17 09:07:31 --> Database Driver Class Initialized
INFO - 2022-07-17 09:07:31 --> Email Class Initialized
DEBUG - 2022-07-17 09:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 09:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 09:07:31 --> Controller Class Initialized
INFO - 2022-07-17 09:07:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 09:07:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 09:07:31 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-17 09:07:31 --> Final output sent to browser
DEBUG - 2022-07-17 09:07:31 --> Total execution time: 0.1727
INFO - 2022-07-17 09:07:57 --> Config Class Initialized
INFO - 2022-07-17 09:07:57 --> Hooks Class Initialized
DEBUG - 2022-07-17 09:07:57 --> UTF-8 Support Enabled
INFO - 2022-07-17 09:07:57 --> Utf8 Class Initialized
INFO - 2022-07-17 09:07:57 --> URI Class Initialized
INFO - 2022-07-17 09:07:57 --> Router Class Initialized
INFO - 2022-07-17 09:07:57 --> Output Class Initialized
INFO - 2022-07-17 09:07:57 --> Security Class Initialized
DEBUG - 2022-07-17 09:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 09:07:57 --> Input Class Initialized
INFO - 2022-07-17 09:07:57 --> Language Class Initialized
INFO - 2022-07-17 09:07:57 --> Loader Class Initialized
INFO - 2022-07-17 09:07:57 --> Helper loaded: url_helper
INFO - 2022-07-17 09:07:57 --> Helper loaded: file_helper
INFO - 2022-07-17 09:07:57 --> Database Driver Class Initialized
INFO - 2022-07-17 09:07:58 --> Email Class Initialized
DEBUG - 2022-07-17 09:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 09:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 09:07:58 --> Controller Class Initialized
INFO - 2022-07-17 09:07:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 09:07:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 09:07:58 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-17 09:07:58 --> Final output sent to browser
DEBUG - 2022-07-17 09:07:58 --> Total execution time: 0.2296
INFO - 2022-07-17 09:08:11 --> Config Class Initialized
INFO - 2022-07-17 09:08:11 --> Hooks Class Initialized
DEBUG - 2022-07-17 09:08:11 --> UTF-8 Support Enabled
INFO - 2022-07-17 09:08:11 --> Utf8 Class Initialized
INFO - 2022-07-17 09:08:11 --> URI Class Initialized
INFO - 2022-07-17 09:08:11 --> Router Class Initialized
INFO - 2022-07-17 09:08:11 --> Output Class Initialized
INFO - 2022-07-17 09:08:11 --> Security Class Initialized
DEBUG - 2022-07-17 09:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 09:08:11 --> Input Class Initialized
INFO - 2022-07-17 09:08:11 --> Language Class Initialized
INFO - 2022-07-17 09:08:11 --> Loader Class Initialized
INFO - 2022-07-17 09:08:11 --> Helper loaded: url_helper
INFO - 2022-07-17 09:08:11 --> Helper loaded: file_helper
INFO - 2022-07-17 09:08:11 --> Database Driver Class Initialized
INFO - 2022-07-17 09:08:11 --> Email Class Initialized
DEBUG - 2022-07-17 09:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 09:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 09:08:11 --> Controller Class Initialized
INFO - 2022-07-17 09:08:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 09:08:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 09:08:11 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-17 09:08:11 --> Final output sent to browser
DEBUG - 2022-07-17 09:08:11 --> Total execution time: 0.1303
INFO - 2022-07-17 09:09:26 --> Config Class Initialized
INFO - 2022-07-17 09:09:26 --> Hooks Class Initialized
DEBUG - 2022-07-17 09:09:26 --> UTF-8 Support Enabled
INFO - 2022-07-17 09:09:26 --> Utf8 Class Initialized
INFO - 2022-07-17 09:09:26 --> URI Class Initialized
INFO - 2022-07-17 09:09:26 --> Router Class Initialized
INFO - 2022-07-17 09:09:26 --> Output Class Initialized
INFO - 2022-07-17 09:09:26 --> Security Class Initialized
DEBUG - 2022-07-17 09:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 09:09:26 --> Input Class Initialized
INFO - 2022-07-17 09:09:26 --> Language Class Initialized
INFO - 2022-07-17 09:09:26 --> Loader Class Initialized
INFO - 2022-07-17 09:09:26 --> Helper loaded: url_helper
INFO - 2022-07-17 09:09:26 --> Helper loaded: file_helper
INFO - 2022-07-17 09:09:26 --> Database Driver Class Initialized
INFO - 2022-07-17 09:09:26 --> Email Class Initialized
DEBUG - 2022-07-17 09:09:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 09:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 09:09:26 --> Controller Class Initialized
INFO - 2022-07-17 09:09:26 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 09:09:26 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 09:09:26 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-17 09:09:26 --> Final output sent to browser
DEBUG - 2022-07-17 09:09:26 --> Total execution time: 0.1421
INFO - 2022-07-17 09:10:14 --> Config Class Initialized
INFO - 2022-07-17 09:10:14 --> Hooks Class Initialized
DEBUG - 2022-07-17 09:10:14 --> UTF-8 Support Enabled
INFO - 2022-07-17 09:10:14 --> Utf8 Class Initialized
INFO - 2022-07-17 09:10:14 --> URI Class Initialized
INFO - 2022-07-17 09:10:14 --> Router Class Initialized
INFO - 2022-07-17 09:10:14 --> Output Class Initialized
INFO - 2022-07-17 09:10:14 --> Security Class Initialized
DEBUG - 2022-07-17 09:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 09:10:14 --> Input Class Initialized
INFO - 2022-07-17 09:10:14 --> Language Class Initialized
INFO - 2022-07-17 09:10:14 --> Loader Class Initialized
INFO - 2022-07-17 09:10:14 --> Helper loaded: url_helper
INFO - 2022-07-17 09:10:14 --> Helper loaded: file_helper
INFO - 2022-07-17 09:10:14 --> Database Driver Class Initialized
INFO - 2022-07-17 09:10:14 --> Email Class Initialized
DEBUG - 2022-07-17 09:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 09:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 09:10:14 --> Controller Class Initialized
INFO - 2022-07-17 09:10:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 09:10:14 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 09:10:14 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-17 09:10:14 --> Final output sent to browser
DEBUG - 2022-07-17 09:10:14 --> Total execution time: 0.1408
INFO - 2022-07-17 09:10:42 --> Config Class Initialized
INFO - 2022-07-17 09:10:42 --> Hooks Class Initialized
DEBUG - 2022-07-17 09:10:42 --> UTF-8 Support Enabled
INFO - 2022-07-17 09:10:42 --> Utf8 Class Initialized
INFO - 2022-07-17 09:10:42 --> URI Class Initialized
INFO - 2022-07-17 09:10:42 --> Router Class Initialized
INFO - 2022-07-17 09:10:42 --> Output Class Initialized
INFO - 2022-07-17 09:10:42 --> Security Class Initialized
DEBUG - 2022-07-17 09:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 09:10:42 --> Input Class Initialized
INFO - 2022-07-17 09:10:42 --> Language Class Initialized
INFO - 2022-07-17 09:10:42 --> Loader Class Initialized
INFO - 2022-07-17 09:10:42 --> Helper loaded: url_helper
INFO - 2022-07-17 09:10:42 --> Helper loaded: file_helper
INFO - 2022-07-17 09:10:42 --> Database Driver Class Initialized
INFO - 2022-07-17 09:10:42 --> Email Class Initialized
DEBUG - 2022-07-17 09:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 09:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 09:10:42 --> Controller Class Initialized
INFO - 2022-07-17 09:10:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 09:10:42 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 09:10:42 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-17 09:10:42 --> Final output sent to browser
DEBUG - 2022-07-17 09:10:42 --> Total execution time: 0.1535
INFO - 2022-07-17 09:10:44 --> Config Class Initialized
INFO - 2022-07-17 09:10:44 --> Hooks Class Initialized
DEBUG - 2022-07-17 09:10:44 --> UTF-8 Support Enabled
INFO - 2022-07-17 09:10:44 --> Utf8 Class Initialized
INFO - 2022-07-17 09:10:44 --> URI Class Initialized
INFO - 2022-07-17 09:10:44 --> Router Class Initialized
INFO - 2022-07-17 09:10:44 --> Output Class Initialized
INFO - 2022-07-17 09:10:44 --> Security Class Initialized
DEBUG - 2022-07-17 09:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 09:10:44 --> Input Class Initialized
INFO - 2022-07-17 09:10:44 --> Language Class Initialized
INFO - 2022-07-17 09:10:44 --> Loader Class Initialized
INFO - 2022-07-17 09:10:44 --> Helper loaded: url_helper
INFO - 2022-07-17 09:10:44 --> Helper loaded: file_helper
INFO - 2022-07-17 09:10:44 --> Database Driver Class Initialized
INFO - 2022-07-17 09:10:44 --> Email Class Initialized
DEBUG - 2022-07-17 09:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 09:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 09:10:44 --> Controller Class Initialized
INFO - 2022-07-17 09:10:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 09:10:44 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 09:10:44 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-17 09:10:44 --> Final output sent to browser
DEBUG - 2022-07-17 09:10:44 --> Total execution time: 0.1469
INFO - 2022-07-17 09:11:05 --> Config Class Initialized
INFO - 2022-07-17 09:11:05 --> Hooks Class Initialized
DEBUG - 2022-07-17 09:11:05 --> UTF-8 Support Enabled
INFO - 2022-07-17 09:11:05 --> Utf8 Class Initialized
INFO - 2022-07-17 09:11:05 --> URI Class Initialized
INFO - 2022-07-17 09:11:05 --> Router Class Initialized
INFO - 2022-07-17 09:11:05 --> Output Class Initialized
INFO - 2022-07-17 09:11:05 --> Security Class Initialized
DEBUG - 2022-07-17 09:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 09:11:05 --> Input Class Initialized
INFO - 2022-07-17 09:11:05 --> Language Class Initialized
INFO - 2022-07-17 09:11:05 --> Loader Class Initialized
INFO - 2022-07-17 09:11:05 --> Helper loaded: url_helper
INFO - 2022-07-17 09:11:05 --> Helper loaded: file_helper
INFO - 2022-07-17 09:11:05 --> Database Driver Class Initialized
INFO - 2022-07-17 09:11:05 --> Email Class Initialized
DEBUG - 2022-07-17 09:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 09:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 09:11:05 --> Controller Class Initialized
INFO - 2022-07-17 09:11:05 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 09:11:05 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 14:41:05 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-07-17 14:41:05 --> Final output sent to browser
DEBUG - 2022-07-17 14:41:05 --> Total execution time: 0.3908
INFO - 2022-07-17 09:11:10 --> Config Class Initialized
INFO - 2022-07-17 09:11:10 --> Hooks Class Initialized
DEBUG - 2022-07-17 09:11:10 --> UTF-8 Support Enabled
INFO - 2022-07-17 09:11:10 --> Utf8 Class Initialized
INFO - 2022-07-17 09:11:10 --> URI Class Initialized
INFO - 2022-07-17 09:11:10 --> Router Class Initialized
INFO - 2022-07-17 09:11:10 --> Output Class Initialized
INFO - 2022-07-17 09:11:10 --> Security Class Initialized
DEBUG - 2022-07-17 09:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 09:11:10 --> Input Class Initialized
INFO - 2022-07-17 09:11:10 --> Language Class Initialized
INFO - 2022-07-17 09:11:10 --> Loader Class Initialized
INFO - 2022-07-17 09:11:10 --> Helper loaded: url_helper
INFO - 2022-07-17 09:11:10 --> Helper loaded: file_helper
INFO - 2022-07-17 09:11:10 --> Database Driver Class Initialized
INFO - 2022-07-17 09:11:10 --> Email Class Initialized
DEBUG - 2022-07-17 09:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 09:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 09:11:10 --> Controller Class Initialized
INFO - 2022-07-17 09:11:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 09:11:10 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 09:11:10 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-17 09:11:10 --> Final output sent to browser
DEBUG - 2022-07-17 09:11:10 --> Total execution time: 0.1000
INFO - 2022-07-17 09:12:09 --> Config Class Initialized
INFO - 2022-07-17 09:12:09 --> Hooks Class Initialized
DEBUG - 2022-07-17 09:12:09 --> UTF-8 Support Enabled
INFO - 2022-07-17 09:12:09 --> Utf8 Class Initialized
INFO - 2022-07-17 09:12:09 --> URI Class Initialized
INFO - 2022-07-17 09:12:09 --> Router Class Initialized
INFO - 2022-07-17 09:12:09 --> Output Class Initialized
INFO - 2022-07-17 09:12:09 --> Security Class Initialized
DEBUG - 2022-07-17 09:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 09:12:09 --> Input Class Initialized
INFO - 2022-07-17 09:12:09 --> Language Class Initialized
INFO - 2022-07-17 09:12:09 --> Loader Class Initialized
INFO - 2022-07-17 09:12:09 --> Helper loaded: url_helper
INFO - 2022-07-17 09:12:09 --> Helper loaded: file_helper
INFO - 2022-07-17 09:12:09 --> Database Driver Class Initialized
INFO - 2022-07-17 09:12:09 --> Email Class Initialized
DEBUG - 2022-07-17 09:12:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 09:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 09:12:09 --> Controller Class Initialized
INFO - 2022-07-17 09:12:09 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 09:12:09 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 09:12:09 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-17 09:12:09 --> Final output sent to browser
DEBUG - 2022-07-17 09:12:09 --> Total execution time: 0.1163
INFO - 2022-07-17 09:16:14 --> Config Class Initialized
INFO - 2022-07-17 09:16:14 --> Hooks Class Initialized
DEBUG - 2022-07-17 09:16:14 --> UTF-8 Support Enabled
INFO - 2022-07-17 09:16:14 --> Utf8 Class Initialized
INFO - 2022-07-17 09:16:14 --> URI Class Initialized
INFO - 2022-07-17 09:16:14 --> Router Class Initialized
INFO - 2022-07-17 09:16:14 --> Output Class Initialized
INFO - 2022-07-17 09:16:14 --> Security Class Initialized
DEBUG - 2022-07-17 09:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 09:16:14 --> Input Class Initialized
INFO - 2022-07-17 09:16:14 --> Language Class Initialized
INFO - 2022-07-17 09:16:14 --> Loader Class Initialized
INFO - 2022-07-17 09:16:14 --> Helper loaded: url_helper
INFO - 2022-07-17 09:16:14 --> Helper loaded: file_helper
INFO - 2022-07-17 09:16:14 --> Database Driver Class Initialized
INFO - 2022-07-17 09:16:14 --> Email Class Initialized
DEBUG - 2022-07-17 09:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 09:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 09:16:14 --> Controller Class Initialized
INFO - 2022-07-17 09:16:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 09:16:14 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 09:16:14 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/login.php
INFO - 2022-07-17 09:16:14 --> Final output sent to browser
DEBUG - 2022-07-17 09:16:14 --> Total execution time: 0.1721
INFO - 2022-07-17 09:16:42 --> Config Class Initialized
INFO - 2022-07-17 09:16:42 --> Hooks Class Initialized
DEBUG - 2022-07-17 09:16:42 --> UTF-8 Support Enabled
INFO - 2022-07-17 09:16:42 --> Utf8 Class Initialized
INFO - 2022-07-17 09:16:42 --> URI Class Initialized
INFO - 2022-07-17 09:16:42 --> Router Class Initialized
INFO - 2022-07-17 09:16:42 --> Output Class Initialized
INFO - 2022-07-17 09:16:42 --> Security Class Initialized
DEBUG - 2022-07-17 09:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 09:16:42 --> Input Class Initialized
INFO - 2022-07-17 09:16:42 --> Language Class Initialized
INFO - 2022-07-17 09:16:42 --> Loader Class Initialized
INFO - 2022-07-17 09:16:42 --> Helper loaded: url_helper
INFO - 2022-07-17 09:16:42 --> Helper loaded: file_helper
INFO - 2022-07-17 09:16:42 --> Database Driver Class Initialized
INFO - 2022-07-17 09:16:42 --> Email Class Initialized
DEBUG - 2022-07-17 09:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 09:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 09:16:42 --> Controller Class Initialized
INFO - 2022-07-17 09:16:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 09:16:42 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 09:16:42 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/login.php
INFO - 2022-07-17 09:16:42 --> Final output sent to browser
DEBUG - 2022-07-17 09:16:42 --> Total execution time: 0.5323
INFO - 2022-07-17 09:17:48 --> Config Class Initialized
INFO - 2022-07-17 09:17:48 --> Hooks Class Initialized
DEBUG - 2022-07-17 09:17:48 --> UTF-8 Support Enabled
INFO - 2022-07-17 09:17:48 --> Utf8 Class Initialized
INFO - 2022-07-17 09:17:48 --> URI Class Initialized
INFO - 2022-07-17 09:17:48 --> Router Class Initialized
INFO - 2022-07-17 09:17:48 --> Output Class Initialized
INFO - 2022-07-17 09:17:48 --> Security Class Initialized
DEBUG - 2022-07-17 09:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 09:17:48 --> Input Class Initialized
INFO - 2022-07-17 09:17:48 --> Language Class Initialized
INFO - 2022-07-17 09:17:48 --> Loader Class Initialized
INFO - 2022-07-17 09:17:48 --> Helper loaded: url_helper
INFO - 2022-07-17 09:17:48 --> Helper loaded: file_helper
INFO - 2022-07-17 09:17:48 --> Database Driver Class Initialized
INFO - 2022-07-17 09:17:48 --> Email Class Initialized
DEBUG - 2022-07-17 09:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 09:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 09:17:48 --> Controller Class Initialized
INFO - 2022-07-17 09:17:48 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 09:17:48 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 09:17:48 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/login_1.php
INFO - 2022-07-17 09:17:48 --> Final output sent to browser
DEBUG - 2022-07-17 09:17:48 --> Total execution time: 0.0318
INFO - 2022-07-17 09:17:49 --> Config Class Initialized
INFO - 2022-07-17 09:17:49 --> Hooks Class Initialized
DEBUG - 2022-07-17 09:17:49 --> UTF-8 Support Enabled
INFO - 2022-07-17 09:17:49 --> Utf8 Class Initialized
INFO - 2022-07-17 09:17:49 --> URI Class Initialized
INFO - 2022-07-17 09:17:49 --> Router Class Initialized
INFO - 2022-07-17 09:17:50 --> Output Class Initialized
INFO - 2022-07-17 09:17:50 --> Security Class Initialized
DEBUG - 2022-07-17 09:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 09:17:50 --> Input Class Initialized
INFO - 2022-07-17 09:17:50 --> Language Class Initialized
INFO - 2022-07-17 09:17:50 --> Loader Class Initialized
INFO - 2022-07-17 09:17:50 --> Helper loaded: url_helper
INFO - 2022-07-17 09:17:50 --> Helper loaded: file_helper
INFO - 2022-07-17 09:17:50 --> Database Driver Class Initialized
INFO - 2022-07-17 09:17:50 --> Email Class Initialized
DEBUG - 2022-07-17 09:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 09:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 09:17:50 --> Controller Class Initialized
INFO - 2022-07-17 09:17:50 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 09:17:50 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 09:17:50 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/login_1.php
INFO - 2022-07-17 09:17:50 --> Final output sent to browser
DEBUG - 2022-07-17 09:17:50 --> Total execution time: 0.1989
INFO - 2022-07-17 09:20:33 --> Config Class Initialized
INFO - 2022-07-17 09:20:33 --> Hooks Class Initialized
DEBUG - 2022-07-17 09:20:33 --> UTF-8 Support Enabled
INFO - 2022-07-17 09:20:33 --> Utf8 Class Initialized
INFO - 2022-07-17 09:20:33 --> URI Class Initialized
INFO - 2022-07-17 09:20:33 --> Router Class Initialized
INFO - 2022-07-17 09:20:33 --> Output Class Initialized
INFO - 2022-07-17 09:20:33 --> Security Class Initialized
DEBUG - 2022-07-17 09:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 09:20:33 --> Input Class Initialized
INFO - 2022-07-17 09:20:33 --> Language Class Initialized
INFO - 2022-07-17 09:20:34 --> Loader Class Initialized
INFO - 2022-07-17 09:20:34 --> Helper loaded: url_helper
INFO - 2022-07-17 09:20:34 --> Helper loaded: file_helper
INFO - 2022-07-17 09:20:34 --> Database Driver Class Initialized
INFO - 2022-07-17 09:20:34 --> Email Class Initialized
DEBUG - 2022-07-17 09:20:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 09:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 09:20:34 --> Controller Class Initialized
INFO - 2022-07-17 09:20:34 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 09:20:34 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 09:20:34 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/login_1.php
INFO - 2022-07-17 09:20:34 --> Final output sent to browser
DEBUG - 2022-07-17 09:20:34 --> Total execution time: 0.3260
INFO - 2022-07-17 09:20:45 --> Config Class Initialized
INFO - 2022-07-17 09:20:45 --> Hooks Class Initialized
DEBUG - 2022-07-17 09:20:45 --> UTF-8 Support Enabled
INFO - 2022-07-17 09:20:45 --> Utf8 Class Initialized
INFO - 2022-07-17 09:20:45 --> URI Class Initialized
INFO - 2022-07-17 09:20:45 --> Router Class Initialized
INFO - 2022-07-17 09:20:45 --> Output Class Initialized
INFO - 2022-07-17 09:20:45 --> Security Class Initialized
DEBUG - 2022-07-17 09:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 09:20:45 --> Input Class Initialized
INFO - 2022-07-17 09:20:45 --> Language Class Initialized
INFO - 2022-07-17 09:20:45 --> Loader Class Initialized
INFO - 2022-07-17 09:20:45 --> Helper loaded: url_helper
INFO - 2022-07-17 09:20:45 --> Helper loaded: file_helper
INFO - 2022-07-17 09:20:45 --> Database Driver Class Initialized
INFO - 2022-07-17 09:20:45 --> Email Class Initialized
DEBUG - 2022-07-17 09:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 09:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 09:20:45 --> Controller Class Initialized
INFO - 2022-07-17 09:20:45 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 09:20:45 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 09:20:45 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/login.php
INFO - 2022-07-17 09:20:45 --> Final output sent to browser
DEBUG - 2022-07-17 09:20:45 --> Total execution time: 0.1576
INFO - 2022-07-17 09:20:45 --> Config Class Initialized
INFO - 2022-07-17 09:20:45 --> Hooks Class Initialized
DEBUG - 2022-07-17 09:20:45 --> UTF-8 Support Enabled
INFO - 2022-07-17 09:20:45 --> Utf8 Class Initialized
INFO - 2022-07-17 09:20:45 --> Config Class Initialized
INFO - 2022-07-17 09:20:45 --> Hooks Class Initialized
INFO - 2022-07-17 09:20:45 --> URI Class Initialized
DEBUG - 2022-07-17 09:20:45 --> UTF-8 Support Enabled
INFO - 2022-07-17 09:20:45 --> Router Class Initialized
INFO - 2022-07-17 09:20:45 --> Utf8 Class Initialized
INFO - 2022-07-17 09:20:45 --> Output Class Initialized
INFO - 2022-07-17 09:20:45 --> URI Class Initialized
INFO - 2022-07-17 09:20:45 --> Security Class Initialized
DEBUG - 2022-07-17 09:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 09:20:45 --> Router Class Initialized
INFO - 2022-07-17 09:20:45 --> Input Class Initialized
INFO - 2022-07-17 09:20:45 --> Output Class Initialized
INFO - 2022-07-17 09:20:45 --> Language Class Initialized
INFO - 2022-07-17 09:20:45 --> Security Class Initialized
ERROR - 2022-07-17 09:20:45 --> 404 Page Not Found: Tokenctrl/style.css
DEBUG - 2022-07-17 09:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 09:20:45 --> Input Class Initialized
INFO - 2022-07-17 09:20:45 --> Language Class Initialized
ERROR - 2022-07-17 09:20:45 --> 404 Page Not Found: Tokenctrl/pic2.png
INFO - 2022-07-17 09:20:46 --> Config Class Initialized
INFO - 2022-07-17 09:20:46 --> Hooks Class Initialized
DEBUG - 2022-07-17 09:20:46 --> UTF-8 Support Enabled
INFO - 2022-07-17 09:20:46 --> Utf8 Class Initialized
INFO - 2022-07-17 09:20:46 --> URI Class Initialized
INFO - 2022-07-17 09:20:46 --> Router Class Initialized
INFO - 2022-07-17 09:20:46 --> Output Class Initialized
INFO - 2022-07-17 09:20:46 --> Security Class Initialized
DEBUG - 2022-07-17 09:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 09:20:46 --> Input Class Initialized
INFO - 2022-07-17 09:20:46 --> Language Class Initialized
ERROR - 2022-07-17 09:20:46 --> 404 Page Not Found: Tokenctrl/ya.jpg
INFO - 2022-07-17 09:21:43 --> Config Class Initialized
INFO - 2022-07-17 09:21:43 --> Hooks Class Initialized
DEBUG - 2022-07-17 09:21:43 --> UTF-8 Support Enabled
INFO - 2022-07-17 09:21:43 --> Utf8 Class Initialized
INFO - 2022-07-17 09:21:43 --> URI Class Initialized
INFO - 2022-07-17 09:21:43 --> Router Class Initialized
INFO - 2022-07-17 09:21:43 --> Output Class Initialized
INFO - 2022-07-17 09:21:43 --> Security Class Initialized
DEBUG - 2022-07-17 09:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 09:21:43 --> Input Class Initialized
INFO - 2022-07-17 09:21:43 --> Language Class Initialized
INFO - 2022-07-17 09:21:43 --> Loader Class Initialized
INFO - 2022-07-17 09:21:43 --> Helper loaded: url_helper
INFO - 2022-07-17 09:21:43 --> Helper loaded: file_helper
INFO - 2022-07-17 09:21:43 --> Database Driver Class Initialized
INFO - 2022-07-17 09:21:43 --> Email Class Initialized
DEBUG - 2022-07-17 09:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 09:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 09:21:43 --> Controller Class Initialized
INFO - 2022-07-17 09:21:43 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 09:21:43 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 09:21:43 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/login.php
INFO - 2022-07-17 09:21:43 --> Final output sent to browser
DEBUG - 2022-07-17 09:21:43 --> Total execution time: 0.0380
INFO - 2022-07-17 09:21:43 --> Config Class Initialized
INFO - 2022-07-17 09:21:43 --> Hooks Class Initialized
DEBUG - 2022-07-17 09:21:43 --> UTF-8 Support Enabled
INFO - 2022-07-17 09:21:43 --> Utf8 Class Initialized
INFO - 2022-07-17 09:21:43 --> URI Class Initialized
INFO - 2022-07-17 09:21:43 --> Router Class Initialized
INFO - 2022-07-17 09:21:43 --> Output Class Initialized
INFO - 2022-07-17 09:21:43 --> Security Class Initialized
DEBUG - 2022-07-17 09:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 09:21:43 --> Input Class Initialized
INFO - 2022-07-17 09:21:43 --> Language Class Initialized
ERROR - 2022-07-17 09:21:43 --> 404 Page Not Found: Tokenctrl/style.css
INFO - 2022-07-17 09:21:43 --> Config Class Initialized
INFO - 2022-07-17 09:21:43 --> Hooks Class Initialized
DEBUG - 2022-07-17 09:21:43 --> UTF-8 Support Enabled
INFO - 2022-07-17 09:21:43 --> Utf8 Class Initialized
INFO - 2022-07-17 09:21:43 --> URI Class Initialized
INFO - 2022-07-17 09:21:43 --> Router Class Initialized
INFO - 2022-07-17 09:21:43 --> Output Class Initialized
INFO - 2022-07-17 09:21:43 --> Security Class Initialized
DEBUG - 2022-07-17 09:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 09:21:43 --> Input Class Initialized
INFO - 2022-07-17 09:21:43 --> Language Class Initialized
ERROR - 2022-07-17 09:21:43 --> 404 Page Not Found: Tokenctrl/ya.jpg
INFO - 2022-07-17 09:51:07 --> Config Class Initialized
INFO - 2022-07-17 09:51:07 --> Hooks Class Initialized
DEBUG - 2022-07-17 09:51:07 --> UTF-8 Support Enabled
INFO - 2022-07-17 09:51:07 --> Utf8 Class Initialized
INFO - 2022-07-17 09:51:07 --> URI Class Initialized
INFO - 2022-07-17 09:51:07 --> Router Class Initialized
INFO - 2022-07-17 09:51:07 --> Output Class Initialized
INFO - 2022-07-17 09:51:07 --> Security Class Initialized
DEBUG - 2022-07-17 09:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 09:51:07 --> Input Class Initialized
INFO - 2022-07-17 09:51:07 --> Language Class Initialized
INFO - 2022-07-17 09:51:07 --> Loader Class Initialized
INFO - 2022-07-17 09:51:07 --> Helper loaded: url_helper
INFO - 2022-07-17 09:51:07 --> Helper loaded: file_helper
INFO - 2022-07-17 09:51:07 --> Database Driver Class Initialized
INFO - 2022-07-17 09:51:08 --> Email Class Initialized
DEBUG - 2022-07-17 09:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 09:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 09:51:08 --> Controller Class Initialized
INFO - 2022-07-17 09:51:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 09:51:08 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 09:51:08 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-17 09:51:08 --> Final output sent to browser
DEBUG - 2022-07-17 09:51:08 --> Total execution time: 0.4010
INFO - 2022-07-17 09:52:39 --> Config Class Initialized
INFO - 2022-07-17 09:52:39 --> Hooks Class Initialized
DEBUG - 2022-07-17 09:52:39 --> UTF-8 Support Enabled
INFO - 2022-07-17 09:52:39 --> Utf8 Class Initialized
INFO - 2022-07-17 09:52:39 --> URI Class Initialized
INFO - 2022-07-17 09:52:39 --> Router Class Initialized
INFO - 2022-07-17 09:52:39 --> Output Class Initialized
INFO - 2022-07-17 09:52:39 --> Security Class Initialized
DEBUG - 2022-07-17 09:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 09:52:39 --> Input Class Initialized
INFO - 2022-07-17 09:52:39 --> Language Class Initialized
INFO - 2022-07-17 09:52:39 --> Loader Class Initialized
INFO - 2022-07-17 09:52:39 --> Helper loaded: url_helper
INFO - 2022-07-17 09:52:39 --> Helper loaded: file_helper
INFO - 2022-07-17 09:52:39 --> Database Driver Class Initialized
INFO - 2022-07-17 09:52:39 --> Email Class Initialized
DEBUG - 2022-07-17 09:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 09:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 09:52:39 --> Controller Class Initialized
INFO - 2022-07-17 09:52:39 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 09:52:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 09:52:39 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 429
ERROR - 2022-07-17 09:52:39 --> Severity: Notice --> Undefined variable: tdid C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 434
ERROR - 2022-07-17 09:52:39 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 437
ERROR - 2022-07-17 09:52:39 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 484
ERROR - 2022-07-17 09:52:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 484
INFO - 2022-07-17 09:52:39 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 09:52:39 --> Final output sent to browser
DEBUG - 2022-07-17 09:52:39 --> Total execution time: 0.1951
INFO - 2022-07-17 09:56:07 --> Config Class Initialized
INFO - 2022-07-17 09:56:07 --> Hooks Class Initialized
DEBUG - 2022-07-17 09:56:07 --> UTF-8 Support Enabled
INFO - 2022-07-17 09:56:07 --> Utf8 Class Initialized
INFO - 2022-07-17 09:56:07 --> URI Class Initialized
INFO - 2022-07-17 09:56:07 --> Router Class Initialized
INFO - 2022-07-17 09:56:07 --> Output Class Initialized
INFO - 2022-07-17 09:56:07 --> Security Class Initialized
DEBUG - 2022-07-17 09:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 09:56:07 --> Input Class Initialized
INFO - 2022-07-17 09:56:07 --> Language Class Initialized
INFO - 2022-07-17 09:56:07 --> Loader Class Initialized
INFO - 2022-07-17 09:56:07 --> Helper loaded: url_helper
INFO - 2022-07-17 09:56:07 --> Helper loaded: file_helper
INFO - 2022-07-17 09:56:07 --> Database Driver Class Initialized
INFO - 2022-07-17 09:56:08 --> Email Class Initialized
DEBUG - 2022-07-17 09:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 09:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 09:56:08 --> Controller Class Initialized
INFO - 2022-07-17 09:56:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 09:56:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 09:56:08 --> Severity: error --> Exception: syntax error, unexpected '?>' C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 434
INFO - 2022-07-17 09:56:21 --> Config Class Initialized
INFO - 2022-07-17 09:56:21 --> Hooks Class Initialized
DEBUG - 2022-07-17 09:56:21 --> UTF-8 Support Enabled
INFO - 2022-07-17 09:56:21 --> Utf8 Class Initialized
INFO - 2022-07-17 09:56:21 --> URI Class Initialized
INFO - 2022-07-17 09:56:21 --> Router Class Initialized
INFO - 2022-07-17 09:56:21 --> Output Class Initialized
INFO - 2022-07-17 09:56:21 --> Security Class Initialized
DEBUG - 2022-07-17 09:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 09:56:21 --> Input Class Initialized
INFO - 2022-07-17 09:56:21 --> Language Class Initialized
INFO - 2022-07-17 09:56:21 --> Loader Class Initialized
INFO - 2022-07-17 09:56:21 --> Helper loaded: url_helper
INFO - 2022-07-17 09:56:21 --> Helper loaded: file_helper
INFO - 2022-07-17 09:56:21 --> Database Driver Class Initialized
INFO - 2022-07-17 09:56:21 --> Email Class Initialized
DEBUG - 2022-07-17 09:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 09:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 09:56:21 --> Controller Class Initialized
INFO - 2022-07-17 09:56:21 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 09:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 09:56:21 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 429
ERROR - 2022-07-17 09:56:21 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 437
ERROR - 2022-07-17 09:56:21 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 484
ERROR - 2022-07-17 09:56:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 484
INFO - 2022-07-17 09:56:21 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 09:56:21 --> Final output sent to browser
DEBUG - 2022-07-17 09:56:21 --> Total execution time: 0.0209
INFO - 2022-07-17 09:57:56 --> Config Class Initialized
INFO - 2022-07-17 09:57:56 --> Hooks Class Initialized
DEBUG - 2022-07-17 09:57:56 --> UTF-8 Support Enabled
INFO - 2022-07-17 09:57:56 --> Utf8 Class Initialized
INFO - 2022-07-17 09:57:56 --> URI Class Initialized
INFO - 2022-07-17 09:57:56 --> Router Class Initialized
INFO - 2022-07-17 09:57:56 --> Output Class Initialized
INFO - 2022-07-17 09:57:56 --> Security Class Initialized
DEBUG - 2022-07-17 09:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 09:57:56 --> Input Class Initialized
INFO - 2022-07-17 09:57:56 --> Language Class Initialized
INFO - 2022-07-17 09:57:56 --> Loader Class Initialized
INFO - 2022-07-17 09:57:56 --> Helper loaded: url_helper
INFO - 2022-07-17 09:57:56 --> Helper loaded: file_helper
INFO - 2022-07-17 09:57:56 --> Database Driver Class Initialized
INFO - 2022-07-17 09:57:56 --> Email Class Initialized
DEBUG - 2022-07-17 09:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 09:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 09:57:56 --> Controller Class Initialized
INFO - 2022-07-17 09:57:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 09:57:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 09:57:56 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 430
ERROR - 2022-07-17 09:57:56 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 438
ERROR - 2022-07-17 09:57:56 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 485
ERROR - 2022-07-17 09:57:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 485
INFO - 2022-07-17 09:57:56 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 09:57:56 --> Final output sent to browser
DEBUG - 2022-07-17 09:57:56 --> Total execution time: 0.0413
INFO - 2022-07-17 09:58:20 --> Config Class Initialized
INFO - 2022-07-17 09:58:20 --> Hooks Class Initialized
DEBUG - 2022-07-17 09:58:20 --> UTF-8 Support Enabled
INFO - 2022-07-17 09:58:20 --> Utf8 Class Initialized
INFO - 2022-07-17 09:58:20 --> URI Class Initialized
INFO - 2022-07-17 09:58:20 --> Router Class Initialized
INFO - 2022-07-17 09:58:20 --> Output Class Initialized
INFO - 2022-07-17 09:58:20 --> Security Class Initialized
DEBUG - 2022-07-17 09:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 09:58:20 --> Input Class Initialized
INFO - 2022-07-17 09:58:20 --> Language Class Initialized
INFO - 2022-07-17 09:58:20 --> Loader Class Initialized
INFO - 2022-07-17 09:58:20 --> Helper loaded: url_helper
INFO - 2022-07-17 09:58:20 --> Helper loaded: file_helper
INFO - 2022-07-17 09:58:20 --> Database Driver Class Initialized
INFO - 2022-07-17 09:58:20 --> Email Class Initialized
DEBUG - 2022-07-17 09:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 09:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 09:58:20 --> Controller Class Initialized
INFO - 2022-07-17 09:58:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 09:58:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 09:58:20 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 431
ERROR - 2022-07-17 09:58:20 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 439
ERROR - 2022-07-17 09:58:20 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 486
ERROR - 2022-07-17 09:58:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 486
INFO - 2022-07-17 09:58:20 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 09:58:20 --> Final output sent to browser
DEBUG - 2022-07-17 09:58:20 --> Total execution time: 0.0326
INFO - 2022-07-17 09:59:27 --> Config Class Initialized
INFO - 2022-07-17 09:59:27 --> Hooks Class Initialized
DEBUG - 2022-07-17 09:59:27 --> UTF-8 Support Enabled
INFO - 2022-07-17 09:59:27 --> Utf8 Class Initialized
INFO - 2022-07-17 09:59:27 --> URI Class Initialized
INFO - 2022-07-17 09:59:27 --> Router Class Initialized
INFO - 2022-07-17 09:59:27 --> Output Class Initialized
INFO - 2022-07-17 09:59:27 --> Security Class Initialized
DEBUG - 2022-07-17 09:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 09:59:27 --> Input Class Initialized
INFO - 2022-07-17 09:59:27 --> Language Class Initialized
INFO - 2022-07-17 09:59:27 --> Loader Class Initialized
INFO - 2022-07-17 09:59:27 --> Helper loaded: url_helper
INFO - 2022-07-17 09:59:27 --> Helper loaded: file_helper
INFO - 2022-07-17 09:59:27 --> Database Driver Class Initialized
INFO - 2022-07-17 09:59:27 --> Email Class Initialized
DEBUG - 2022-07-17 09:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 09:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 09:59:27 --> Controller Class Initialized
INFO - 2022-07-17 09:59:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 09:59:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 09:59:27 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 431
ERROR - 2022-07-17 09:59:27 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 439
ERROR - 2022-07-17 09:59:27 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 486
ERROR - 2022-07-17 09:59:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 486
INFO - 2022-07-17 09:59:27 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 09:59:27 --> Final output sent to browser
DEBUG - 2022-07-17 09:59:27 --> Total execution time: 0.1926
INFO - 2022-07-17 10:00:26 --> Config Class Initialized
INFO - 2022-07-17 10:00:26 --> Hooks Class Initialized
DEBUG - 2022-07-17 10:00:26 --> UTF-8 Support Enabled
INFO - 2022-07-17 10:00:26 --> Utf8 Class Initialized
INFO - 2022-07-17 10:00:26 --> URI Class Initialized
INFO - 2022-07-17 10:00:26 --> Router Class Initialized
INFO - 2022-07-17 10:00:26 --> Output Class Initialized
INFO - 2022-07-17 10:00:26 --> Security Class Initialized
DEBUG - 2022-07-17 10:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 10:00:26 --> Input Class Initialized
INFO - 2022-07-17 10:00:26 --> Language Class Initialized
INFO - 2022-07-17 10:00:26 --> Loader Class Initialized
INFO - 2022-07-17 10:00:26 --> Helper loaded: url_helper
INFO - 2022-07-17 10:00:26 --> Helper loaded: file_helper
INFO - 2022-07-17 10:00:26 --> Database Driver Class Initialized
INFO - 2022-07-17 10:00:26 --> Email Class Initialized
DEBUG - 2022-07-17 10:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 10:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 10:00:26 --> Controller Class Initialized
INFO - 2022-07-17 10:00:26 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 10:00:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 10:00:26 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 431
ERROR - 2022-07-17 10:00:26 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 439
ERROR - 2022-07-17 10:00:26 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 486
ERROR - 2022-07-17 10:00:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 486
INFO - 2022-07-17 10:00:26 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 10:00:26 --> Final output sent to browser
DEBUG - 2022-07-17 10:00:26 --> Total execution time: 0.1385
INFO - 2022-07-17 10:00:40 --> Config Class Initialized
INFO - 2022-07-17 10:00:40 --> Hooks Class Initialized
DEBUG - 2022-07-17 10:00:40 --> UTF-8 Support Enabled
INFO - 2022-07-17 10:00:40 --> Utf8 Class Initialized
INFO - 2022-07-17 10:00:40 --> URI Class Initialized
INFO - 2022-07-17 10:00:40 --> Router Class Initialized
INFO - 2022-07-17 10:00:40 --> Output Class Initialized
INFO - 2022-07-17 10:00:40 --> Security Class Initialized
DEBUG - 2022-07-17 10:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 10:00:40 --> Input Class Initialized
INFO - 2022-07-17 10:00:40 --> Language Class Initialized
INFO - 2022-07-17 10:00:40 --> Loader Class Initialized
INFO - 2022-07-17 10:00:40 --> Helper loaded: url_helper
INFO - 2022-07-17 10:00:40 --> Helper loaded: file_helper
INFO - 2022-07-17 10:00:40 --> Database Driver Class Initialized
INFO - 2022-07-17 10:00:40 --> Email Class Initialized
DEBUG - 2022-07-17 10:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 10:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 10:00:40 --> Controller Class Initialized
INFO - 2022-07-17 10:00:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 10:00:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 10:00:40 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 431
ERROR - 2022-07-17 10:00:40 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 439
ERROR - 2022-07-17 10:00:40 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 486
ERROR - 2022-07-17 10:00:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 486
INFO - 2022-07-17 10:00:40 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 10:00:40 --> Final output sent to browser
DEBUG - 2022-07-17 10:00:40 --> Total execution time: 0.1571
INFO - 2022-07-17 10:01:45 --> Config Class Initialized
INFO - 2022-07-17 10:01:45 --> Hooks Class Initialized
DEBUG - 2022-07-17 10:01:45 --> UTF-8 Support Enabled
INFO - 2022-07-17 10:01:45 --> Utf8 Class Initialized
INFO - 2022-07-17 10:01:45 --> URI Class Initialized
INFO - 2022-07-17 10:01:45 --> Router Class Initialized
INFO - 2022-07-17 10:01:45 --> Output Class Initialized
INFO - 2022-07-17 10:01:45 --> Security Class Initialized
DEBUG - 2022-07-17 10:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 10:01:45 --> Input Class Initialized
INFO - 2022-07-17 10:01:45 --> Language Class Initialized
INFO - 2022-07-17 10:01:45 --> Loader Class Initialized
INFO - 2022-07-17 10:01:45 --> Helper loaded: url_helper
INFO - 2022-07-17 10:01:45 --> Helper loaded: file_helper
INFO - 2022-07-17 10:01:45 --> Database Driver Class Initialized
INFO - 2022-07-17 10:01:45 --> Email Class Initialized
DEBUG - 2022-07-17 10:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 10:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 10:01:45 --> Controller Class Initialized
INFO - 2022-07-17 10:01:45 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 10:01:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 10:01:45 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 435
ERROR - 2022-07-17 10:01:45 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 443
ERROR - 2022-07-17 10:01:45 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 490
ERROR - 2022-07-17 10:01:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 490
INFO - 2022-07-17 10:01:45 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 10:01:45 --> Final output sent to browser
DEBUG - 2022-07-17 10:01:45 --> Total execution time: 0.1460
INFO - 2022-07-17 10:02:11 --> Config Class Initialized
INFO - 2022-07-17 10:02:11 --> Hooks Class Initialized
DEBUG - 2022-07-17 10:02:11 --> UTF-8 Support Enabled
INFO - 2022-07-17 10:02:11 --> Utf8 Class Initialized
INFO - 2022-07-17 10:02:11 --> URI Class Initialized
INFO - 2022-07-17 10:02:11 --> Router Class Initialized
INFO - 2022-07-17 10:02:11 --> Output Class Initialized
INFO - 2022-07-17 10:02:11 --> Security Class Initialized
DEBUG - 2022-07-17 10:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 10:02:11 --> Input Class Initialized
INFO - 2022-07-17 10:02:11 --> Language Class Initialized
INFO - 2022-07-17 10:02:11 --> Loader Class Initialized
INFO - 2022-07-17 10:02:11 --> Helper loaded: url_helper
INFO - 2022-07-17 10:02:11 --> Helper loaded: file_helper
INFO - 2022-07-17 10:02:11 --> Database Driver Class Initialized
INFO - 2022-07-17 10:02:11 --> Email Class Initialized
DEBUG - 2022-07-17 10:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 10:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 10:02:11 --> Controller Class Initialized
INFO - 2022-07-17 10:02:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 10:02:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 10:02:11 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 435
ERROR - 2022-07-17 10:02:11 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 443
ERROR - 2022-07-17 10:02:11 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 490
ERROR - 2022-07-17 10:02:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 490
INFO - 2022-07-17 10:02:11 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 10:02:11 --> Final output sent to browser
DEBUG - 2022-07-17 10:02:11 --> Total execution time: 0.1684
INFO - 2022-07-17 10:05:11 --> Config Class Initialized
INFO - 2022-07-17 10:05:11 --> Hooks Class Initialized
DEBUG - 2022-07-17 10:05:11 --> UTF-8 Support Enabled
INFO - 2022-07-17 10:05:11 --> Utf8 Class Initialized
INFO - 2022-07-17 10:05:11 --> URI Class Initialized
INFO - 2022-07-17 10:05:11 --> Router Class Initialized
INFO - 2022-07-17 10:05:11 --> Output Class Initialized
INFO - 2022-07-17 10:05:11 --> Security Class Initialized
DEBUG - 2022-07-17 10:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 10:05:11 --> Input Class Initialized
INFO - 2022-07-17 10:05:11 --> Language Class Initialized
INFO - 2022-07-17 10:05:11 --> Loader Class Initialized
INFO - 2022-07-17 10:05:11 --> Helper loaded: url_helper
INFO - 2022-07-17 10:05:11 --> Helper loaded: file_helper
INFO - 2022-07-17 10:05:11 --> Database Driver Class Initialized
INFO - 2022-07-17 10:05:11 --> Email Class Initialized
DEBUG - 2022-07-17 10:05:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 10:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 10:05:11 --> Controller Class Initialized
INFO - 2022-07-17 10:05:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 10:05:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 10:05:12 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 437
ERROR - 2022-07-17 10:05:12 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 445
ERROR - 2022-07-17 10:05:12 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 492
ERROR - 2022-07-17 10:05:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 492
INFO - 2022-07-17 10:05:12 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 10:05:12 --> Final output sent to browser
DEBUG - 2022-07-17 10:05:12 --> Total execution time: 0.1254
INFO - 2022-07-17 10:06:14 --> Config Class Initialized
INFO - 2022-07-17 10:06:14 --> Hooks Class Initialized
DEBUG - 2022-07-17 10:06:14 --> UTF-8 Support Enabled
INFO - 2022-07-17 10:06:14 --> Utf8 Class Initialized
INFO - 2022-07-17 10:06:14 --> URI Class Initialized
INFO - 2022-07-17 10:06:14 --> Router Class Initialized
INFO - 2022-07-17 10:06:14 --> Output Class Initialized
INFO - 2022-07-17 10:06:14 --> Security Class Initialized
DEBUG - 2022-07-17 10:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 10:06:14 --> Input Class Initialized
INFO - 2022-07-17 10:06:14 --> Language Class Initialized
INFO - 2022-07-17 10:06:14 --> Loader Class Initialized
INFO - 2022-07-17 10:06:14 --> Helper loaded: url_helper
INFO - 2022-07-17 10:06:14 --> Helper loaded: file_helper
INFO - 2022-07-17 10:06:14 --> Database Driver Class Initialized
INFO - 2022-07-17 10:06:14 --> Email Class Initialized
DEBUG - 2022-07-17 10:06:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 10:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 10:06:14 --> Controller Class Initialized
INFO - 2022-07-17 10:06:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 10:06:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 10:06:14 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 438
ERROR - 2022-07-17 10:06:14 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 446
ERROR - 2022-07-17 10:06:14 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 493
ERROR - 2022-07-17 10:06:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 493
INFO - 2022-07-17 10:06:14 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 10:06:14 --> Final output sent to browser
DEBUG - 2022-07-17 10:06:14 --> Total execution time: 0.1174
INFO - 2022-07-17 10:06:53 --> Config Class Initialized
INFO - 2022-07-17 10:06:53 --> Hooks Class Initialized
DEBUG - 2022-07-17 10:06:53 --> UTF-8 Support Enabled
INFO - 2022-07-17 10:06:53 --> Utf8 Class Initialized
INFO - 2022-07-17 10:06:53 --> URI Class Initialized
INFO - 2022-07-17 10:06:53 --> Router Class Initialized
INFO - 2022-07-17 10:06:53 --> Output Class Initialized
INFO - 2022-07-17 10:06:53 --> Security Class Initialized
DEBUG - 2022-07-17 10:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 10:06:53 --> Input Class Initialized
INFO - 2022-07-17 10:06:53 --> Language Class Initialized
INFO - 2022-07-17 10:06:53 --> Loader Class Initialized
INFO - 2022-07-17 10:06:53 --> Helper loaded: url_helper
INFO - 2022-07-17 10:06:53 --> Helper loaded: file_helper
INFO - 2022-07-17 10:06:53 --> Database Driver Class Initialized
INFO - 2022-07-17 10:06:53 --> Email Class Initialized
DEBUG - 2022-07-17 10:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 10:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 10:06:53 --> Controller Class Initialized
INFO - 2022-07-17 10:06:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 10:06:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 10:06:53 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 438
ERROR - 2022-07-17 10:06:53 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 446
ERROR - 2022-07-17 10:06:53 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 493
ERROR - 2022-07-17 10:06:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 493
INFO - 2022-07-17 10:06:53 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 10:06:53 --> Final output sent to browser
DEBUG - 2022-07-17 10:06:53 --> Total execution time: 0.1474
INFO - 2022-07-17 10:07:30 --> Config Class Initialized
INFO - 2022-07-17 10:07:30 --> Hooks Class Initialized
DEBUG - 2022-07-17 10:07:30 --> UTF-8 Support Enabled
INFO - 2022-07-17 10:07:30 --> Utf8 Class Initialized
INFO - 2022-07-17 10:07:30 --> URI Class Initialized
INFO - 2022-07-17 10:07:30 --> Router Class Initialized
INFO - 2022-07-17 10:07:30 --> Output Class Initialized
INFO - 2022-07-17 10:07:30 --> Security Class Initialized
DEBUG - 2022-07-17 10:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 10:07:30 --> Input Class Initialized
INFO - 2022-07-17 10:07:30 --> Language Class Initialized
INFO - 2022-07-17 10:07:30 --> Loader Class Initialized
INFO - 2022-07-17 10:07:30 --> Helper loaded: url_helper
INFO - 2022-07-17 10:07:30 --> Helper loaded: file_helper
INFO - 2022-07-17 10:07:30 --> Database Driver Class Initialized
INFO - 2022-07-17 10:07:30 --> Email Class Initialized
DEBUG - 2022-07-17 10:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 10:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 10:07:30 --> Controller Class Initialized
INFO - 2022-07-17 10:07:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 10:07:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 10:07:30 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 438
ERROR - 2022-07-17 10:07:30 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 446
ERROR - 2022-07-17 10:07:30 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 493
ERROR - 2022-07-17 10:07:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 493
INFO - 2022-07-17 10:07:30 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 10:07:30 --> Final output sent to browser
DEBUG - 2022-07-17 10:07:30 --> Total execution time: 0.1510
INFO - 2022-07-17 10:08:51 --> Config Class Initialized
INFO - 2022-07-17 10:08:51 --> Hooks Class Initialized
DEBUG - 2022-07-17 10:08:51 --> UTF-8 Support Enabled
INFO - 2022-07-17 10:08:51 --> Utf8 Class Initialized
INFO - 2022-07-17 10:08:51 --> URI Class Initialized
INFO - 2022-07-17 10:08:51 --> Router Class Initialized
INFO - 2022-07-17 10:08:51 --> Output Class Initialized
INFO - 2022-07-17 10:08:51 --> Security Class Initialized
DEBUG - 2022-07-17 10:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 10:08:51 --> Input Class Initialized
INFO - 2022-07-17 10:08:51 --> Language Class Initialized
INFO - 2022-07-17 10:08:51 --> Loader Class Initialized
INFO - 2022-07-17 10:08:51 --> Helper loaded: url_helper
INFO - 2022-07-17 10:08:51 --> Helper loaded: file_helper
INFO - 2022-07-17 10:08:51 --> Database Driver Class Initialized
INFO - 2022-07-17 10:08:52 --> Email Class Initialized
DEBUG - 2022-07-17 10:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 10:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 10:08:52 --> Controller Class Initialized
INFO - 2022-07-17 10:08:52 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 10:08:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 10:08:52 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 438
ERROR - 2022-07-17 10:08:52 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 446
ERROR - 2022-07-17 10:08:52 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 493
ERROR - 2022-07-17 10:08:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 493
INFO - 2022-07-17 10:08:52 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 10:08:52 --> Final output sent to browser
DEBUG - 2022-07-17 10:08:52 --> Total execution time: 0.2509
INFO - 2022-07-17 10:08:53 --> Config Class Initialized
INFO - 2022-07-17 10:08:53 --> Hooks Class Initialized
DEBUG - 2022-07-17 10:08:53 --> UTF-8 Support Enabled
INFO - 2022-07-17 10:08:53 --> Utf8 Class Initialized
INFO - 2022-07-17 10:08:53 --> URI Class Initialized
INFO - 2022-07-17 10:08:53 --> Router Class Initialized
INFO - 2022-07-17 10:08:53 --> Output Class Initialized
INFO - 2022-07-17 10:08:53 --> Security Class Initialized
DEBUG - 2022-07-17 10:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 10:08:53 --> Input Class Initialized
INFO - 2022-07-17 10:08:53 --> Language Class Initialized
INFO - 2022-07-17 10:08:53 --> Loader Class Initialized
INFO - 2022-07-17 10:08:53 --> Helper loaded: url_helper
INFO - 2022-07-17 10:08:53 --> Helper loaded: file_helper
INFO - 2022-07-17 10:08:53 --> Database Driver Class Initialized
INFO - 2022-07-17 10:08:53 --> Email Class Initialized
DEBUG - 2022-07-17 10:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 10:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 10:08:53 --> Controller Class Initialized
INFO - 2022-07-17 10:08:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 10:08:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 10:08:53 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 438
ERROR - 2022-07-17 10:08:53 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 446
ERROR - 2022-07-17 10:08:53 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 493
ERROR - 2022-07-17 10:08:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 493
INFO - 2022-07-17 10:08:53 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 10:08:53 --> Final output sent to browser
DEBUG - 2022-07-17 10:08:53 --> Total execution time: 0.0464
INFO - 2022-07-17 10:09:58 --> Config Class Initialized
INFO - 2022-07-17 10:09:58 --> Hooks Class Initialized
DEBUG - 2022-07-17 10:09:58 --> UTF-8 Support Enabled
INFO - 2022-07-17 10:09:58 --> Utf8 Class Initialized
INFO - 2022-07-17 10:09:58 --> URI Class Initialized
INFO - 2022-07-17 10:09:58 --> Router Class Initialized
INFO - 2022-07-17 10:09:58 --> Output Class Initialized
INFO - 2022-07-17 10:09:58 --> Security Class Initialized
DEBUG - 2022-07-17 10:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 10:09:58 --> Input Class Initialized
INFO - 2022-07-17 10:09:58 --> Language Class Initialized
INFO - 2022-07-17 10:09:58 --> Loader Class Initialized
INFO - 2022-07-17 10:09:58 --> Helper loaded: url_helper
INFO - 2022-07-17 10:09:58 --> Helper loaded: file_helper
INFO - 2022-07-17 10:09:58 --> Database Driver Class Initialized
INFO - 2022-07-17 10:09:58 --> Email Class Initialized
DEBUG - 2022-07-17 10:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 10:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 10:09:58 --> Controller Class Initialized
INFO - 2022-07-17 10:09:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 10:09:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 10:09:58 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 438
ERROR - 2022-07-17 10:09:58 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 446
ERROR - 2022-07-17 10:09:58 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 493
ERROR - 2022-07-17 10:09:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 493
INFO - 2022-07-17 10:09:58 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 10:09:58 --> Final output sent to browser
DEBUG - 2022-07-17 10:09:58 --> Total execution time: 0.0214
INFO - 2022-07-17 10:10:00 --> Config Class Initialized
INFO - 2022-07-17 10:10:00 --> Hooks Class Initialized
DEBUG - 2022-07-17 10:10:00 --> UTF-8 Support Enabled
INFO - 2022-07-17 10:10:00 --> Utf8 Class Initialized
INFO - 2022-07-17 10:10:00 --> URI Class Initialized
INFO - 2022-07-17 10:10:00 --> Router Class Initialized
INFO - 2022-07-17 10:10:00 --> Output Class Initialized
INFO - 2022-07-17 10:10:00 --> Security Class Initialized
DEBUG - 2022-07-17 10:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 10:10:00 --> Input Class Initialized
INFO - 2022-07-17 10:10:00 --> Language Class Initialized
INFO - 2022-07-17 10:10:00 --> Loader Class Initialized
INFO - 2022-07-17 10:10:00 --> Helper loaded: url_helper
INFO - 2022-07-17 10:10:00 --> Helper loaded: file_helper
INFO - 2022-07-17 10:10:00 --> Database Driver Class Initialized
INFO - 2022-07-17 10:10:00 --> Email Class Initialized
DEBUG - 2022-07-17 10:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 10:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 10:10:00 --> Controller Class Initialized
INFO - 2022-07-17 10:10:00 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 10:10:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 10:10:00 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 438
ERROR - 2022-07-17 10:10:00 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 446
ERROR - 2022-07-17 10:10:00 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 493
ERROR - 2022-07-17 10:10:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 493
INFO - 2022-07-17 10:10:00 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 10:10:00 --> Final output sent to browser
DEBUG - 2022-07-17 10:10:00 --> Total execution time: 0.0189
INFO - 2022-07-17 10:10:01 --> Config Class Initialized
INFO - 2022-07-17 10:10:01 --> Hooks Class Initialized
DEBUG - 2022-07-17 10:10:01 --> UTF-8 Support Enabled
INFO - 2022-07-17 10:10:01 --> Utf8 Class Initialized
INFO - 2022-07-17 10:10:01 --> URI Class Initialized
INFO - 2022-07-17 10:10:01 --> Router Class Initialized
INFO - 2022-07-17 10:10:01 --> Output Class Initialized
INFO - 2022-07-17 10:10:01 --> Security Class Initialized
DEBUG - 2022-07-17 10:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 10:10:01 --> Input Class Initialized
INFO - 2022-07-17 10:10:01 --> Language Class Initialized
INFO - 2022-07-17 10:10:01 --> Loader Class Initialized
INFO - 2022-07-17 10:10:01 --> Helper loaded: url_helper
INFO - 2022-07-17 10:10:01 --> Helper loaded: file_helper
INFO - 2022-07-17 10:10:01 --> Database Driver Class Initialized
INFO - 2022-07-17 10:10:01 --> Email Class Initialized
DEBUG - 2022-07-17 10:10:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 10:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 10:10:01 --> Controller Class Initialized
INFO - 2022-07-17 10:10:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 10:10:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 10:10:01 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 438
ERROR - 2022-07-17 10:10:01 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 446
ERROR - 2022-07-17 10:10:01 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 493
ERROR - 2022-07-17 10:10:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 493
INFO - 2022-07-17 10:10:01 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 10:10:01 --> Final output sent to browser
DEBUG - 2022-07-17 10:10:01 --> Total execution time: 0.1211
INFO - 2022-07-17 10:10:02 --> Config Class Initialized
INFO - 2022-07-17 10:10:02 --> Hooks Class Initialized
DEBUG - 2022-07-17 10:10:02 --> UTF-8 Support Enabled
INFO - 2022-07-17 10:10:02 --> Utf8 Class Initialized
INFO - 2022-07-17 10:10:02 --> URI Class Initialized
INFO - 2022-07-17 10:10:02 --> Router Class Initialized
INFO - 2022-07-17 10:10:02 --> Output Class Initialized
INFO - 2022-07-17 10:10:02 --> Security Class Initialized
DEBUG - 2022-07-17 10:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 10:10:02 --> Input Class Initialized
INFO - 2022-07-17 10:10:02 --> Language Class Initialized
INFO - 2022-07-17 10:10:02 --> Loader Class Initialized
INFO - 2022-07-17 10:10:02 --> Helper loaded: url_helper
INFO - 2022-07-17 10:10:02 --> Helper loaded: file_helper
INFO - 2022-07-17 10:10:02 --> Database Driver Class Initialized
INFO - 2022-07-17 10:10:02 --> Email Class Initialized
DEBUG - 2022-07-17 10:10:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 10:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 10:10:02 --> Controller Class Initialized
INFO - 2022-07-17 10:10:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 10:10:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 10:10:02 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 438
ERROR - 2022-07-17 10:10:02 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 446
ERROR - 2022-07-17 10:10:02 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 493
ERROR - 2022-07-17 10:10:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 493
INFO - 2022-07-17 10:10:02 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 10:10:02 --> Final output sent to browser
DEBUG - 2022-07-17 10:10:02 --> Total execution time: 0.0783
INFO - 2022-07-17 10:10:02 --> Config Class Initialized
INFO - 2022-07-17 10:10:02 --> Hooks Class Initialized
DEBUG - 2022-07-17 10:10:02 --> UTF-8 Support Enabled
INFO - 2022-07-17 10:10:02 --> Utf8 Class Initialized
INFO - 2022-07-17 10:10:02 --> URI Class Initialized
INFO - 2022-07-17 10:10:02 --> Router Class Initialized
INFO - 2022-07-17 10:10:02 --> Output Class Initialized
INFO - 2022-07-17 10:10:02 --> Security Class Initialized
DEBUG - 2022-07-17 10:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 10:10:02 --> Input Class Initialized
INFO - 2022-07-17 10:10:02 --> Language Class Initialized
INFO - 2022-07-17 10:10:02 --> Loader Class Initialized
INFO - 2022-07-17 10:10:02 --> Helper loaded: url_helper
INFO - 2022-07-17 10:10:02 --> Helper loaded: file_helper
INFO - 2022-07-17 10:10:02 --> Database Driver Class Initialized
INFO - 2022-07-17 10:10:02 --> Email Class Initialized
DEBUG - 2022-07-17 10:10:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 10:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 10:10:02 --> Controller Class Initialized
INFO - 2022-07-17 10:10:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 10:10:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 10:10:02 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 438
ERROR - 2022-07-17 10:10:02 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 446
ERROR - 2022-07-17 10:10:02 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 493
ERROR - 2022-07-17 10:10:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 493
INFO - 2022-07-17 10:10:02 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 10:10:02 --> Final output sent to browser
DEBUG - 2022-07-17 10:10:02 --> Total execution time: 0.0280
INFO - 2022-07-17 10:10:02 --> Config Class Initialized
INFO - 2022-07-17 10:10:02 --> Hooks Class Initialized
DEBUG - 2022-07-17 10:10:02 --> UTF-8 Support Enabled
INFO - 2022-07-17 10:10:02 --> Utf8 Class Initialized
INFO - 2022-07-17 10:10:02 --> URI Class Initialized
INFO - 2022-07-17 10:10:02 --> Router Class Initialized
INFO - 2022-07-17 10:10:02 --> Output Class Initialized
INFO - 2022-07-17 10:10:02 --> Security Class Initialized
DEBUG - 2022-07-17 10:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 10:10:02 --> Input Class Initialized
INFO - 2022-07-17 10:10:02 --> Language Class Initialized
INFO - 2022-07-17 10:10:02 --> Loader Class Initialized
INFO - 2022-07-17 10:10:02 --> Helper loaded: url_helper
INFO - 2022-07-17 10:10:02 --> Helper loaded: file_helper
INFO - 2022-07-17 10:10:02 --> Database Driver Class Initialized
INFO - 2022-07-17 10:10:02 --> Email Class Initialized
DEBUG - 2022-07-17 10:10:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 10:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 10:10:02 --> Controller Class Initialized
INFO - 2022-07-17 10:10:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 10:10:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 10:10:02 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 438
ERROR - 2022-07-17 10:10:02 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 446
ERROR - 2022-07-17 10:10:02 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 493
ERROR - 2022-07-17 10:10:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 493
INFO - 2022-07-17 10:10:02 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 10:10:02 --> Final output sent to browser
DEBUG - 2022-07-17 10:10:02 --> Total execution time: 0.0312
INFO - 2022-07-17 10:11:57 --> Config Class Initialized
INFO - 2022-07-17 10:11:57 --> Hooks Class Initialized
DEBUG - 2022-07-17 10:11:57 --> UTF-8 Support Enabled
INFO - 2022-07-17 10:11:57 --> Utf8 Class Initialized
INFO - 2022-07-17 10:11:57 --> URI Class Initialized
INFO - 2022-07-17 10:11:57 --> Router Class Initialized
INFO - 2022-07-17 10:11:57 --> Output Class Initialized
INFO - 2022-07-17 10:11:57 --> Security Class Initialized
DEBUG - 2022-07-17 10:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 10:11:57 --> Input Class Initialized
INFO - 2022-07-17 10:11:57 --> Language Class Initialized
INFO - 2022-07-17 10:11:57 --> Loader Class Initialized
INFO - 2022-07-17 10:11:57 --> Helper loaded: url_helper
INFO - 2022-07-17 10:11:57 --> Helper loaded: file_helper
INFO - 2022-07-17 10:11:57 --> Database Driver Class Initialized
INFO - 2022-07-17 10:11:58 --> Email Class Initialized
DEBUG - 2022-07-17 10:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 10:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 10:11:58 --> Controller Class Initialized
INFO - 2022-07-17 10:11:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 10:11:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 10:11:58 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 442
ERROR - 2022-07-17 10:11:58 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 450
ERROR - 2022-07-17 10:11:58 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 497
ERROR - 2022-07-17 10:11:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 497
INFO - 2022-07-17 10:11:58 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 10:11:58 --> Final output sent to browser
DEBUG - 2022-07-17 10:11:58 --> Total execution time: 0.1363
INFO - 2022-07-17 10:14:28 --> Config Class Initialized
INFO - 2022-07-17 10:14:28 --> Hooks Class Initialized
DEBUG - 2022-07-17 10:14:28 --> UTF-8 Support Enabled
INFO - 2022-07-17 10:14:28 --> Utf8 Class Initialized
INFO - 2022-07-17 10:14:28 --> URI Class Initialized
INFO - 2022-07-17 10:14:28 --> Router Class Initialized
INFO - 2022-07-17 10:14:28 --> Output Class Initialized
INFO - 2022-07-17 10:14:28 --> Security Class Initialized
DEBUG - 2022-07-17 10:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 10:14:28 --> Input Class Initialized
INFO - 2022-07-17 10:14:28 --> Language Class Initialized
INFO - 2022-07-17 10:14:28 --> Loader Class Initialized
INFO - 2022-07-17 10:14:28 --> Helper loaded: url_helper
INFO - 2022-07-17 10:14:28 --> Helper loaded: file_helper
INFO - 2022-07-17 10:14:28 --> Database Driver Class Initialized
INFO - 2022-07-17 10:14:28 --> Email Class Initialized
DEBUG - 2022-07-17 10:14:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 10:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 10:14:28 --> Controller Class Initialized
INFO - 2022-07-17 10:14:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 10:14:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 10:14:28 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 442
ERROR - 2022-07-17 10:14:28 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 450
ERROR - 2022-07-17 10:14:28 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 497
ERROR - 2022-07-17 10:14:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 497
INFO - 2022-07-17 10:14:28 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 10:14:28 --> Final output sent to browser
DEBUG - 2022-07-17 10:14:28 --> Total execution time: 0.0280
INFO - 2022-07-17 10:14:55 --> Config Class Initialized
INFO - 2022-07-17 10:14:55 --> Hooks Class Initialized
DEBUG - 2022-07-17 10:14:55 --> UTF-8 Support Enabled
INFO - 2022-07-17 10:14:55 --> Utf8 Class Initialized
INFO - 2022-07-17 10:14:55 --> URI Class Initialized
INFO - 2022-07-17 10:14:55 --> Router Class Initialized
INFO - 2022-07-17 10:14:55 --> Output Class Initialized
INFO - 2022-07-17 10:14:55 --> Security Class Initialized
DEBUG - 2022-07-17 10:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 10:14:55 --> Input Class Initialized
INFO - 2022-07-17 10:14:55 --> Language Class Initialized
INFO - 2022-07-17 10:14:55 --> Loader Class Initialized
INFO - 2022-07-17 10:14:55 --> Helper loaded: url_helper
INFO - 2022-07-17 10:14:55 --> Helper loaded: file_helper
INFO - 2022-07-17 10:14:55 --> Database Driver Class Initialized
INFO - 2022-07-17 10:14:55 --> Email Class Initialized
DEBUG - 2022-07-17 10:14:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 10:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 10:14:55 --> Controller Class Initialized
INFO - 2022-07-17 10:14:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 10:14:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 10:14:55 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 442
ERROR - 2022-07-17 10:14:55 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 450
ERROR - 2022-07-17 10:14:55 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 497
ERROR - 2022-07-17 10:14:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 497
INFO - 2022-07-17 10:14:55 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 10:14:55 --> Final output sent to browser
DEBUG - 2022-07-17 10:14:55 --> Total execution time: 0.0360
INFO - 2022-07-17 10:16:12 --> Config Class Initialized
INFO - 2022-07-17 10:16:12 --> Hooks Class Initialized
DEBUG - 2022-07-17 10:16:12 --> UTF-8 Support Enabled
INFO - 2022-07-17 10:16:12 --> Utf8 Class Initialized
INFO - 2022-07-17 10:16:12 --> URI Class Initialized
INFO - 2022-07-17 10:16:12 --> Router Class Initialized
INFO - 2022-07-17 10:16:12 --> Output Class Initialized
INFO - 2022-07-17 10:16:12 --> Security Class Initialized
DEBUG - 2022-07-17 10:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 10:16:12 --> Input Class Initialized
INFO - 2022-07-17 10:16:12 --> Language Class Initialized
INFO - 2022-07-17 10:16:12 --> Loader Class Initialized
INFO - 2022-07-17 10:16:12 --> Helper loaded: url_helper
INFO - 2022-07-17 10:16:12 --> Helper loaded: file_helper
INFO - 2022-07-17 10:16:12 --> Database Driver Class Initialized
INFO - 2022-07-17 10:16:12 --> Email Class Initialized
DEBUG - 2022-07-17 10:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 10:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 10:16:12 --> Controller Class Initialized
INFO - 2022-07-17 10:16:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 10:16:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 10:16:12 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 445
ERROR - 2022-07-17 10:16:12 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 453
ERROR - 2022-07-17 10:16:12 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 500
ERROR - 2022-07-17 10:16:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 500
INFO - 2022-07-17 10:16:12 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 10:16:12 --> Final output sent to browser
DEBUG - 2022-07-17 10:16:12 --> Total execution time: 0.0396
INFO - 2022-07-17 10:16:13 --> Config Class Initialized
INFO - 2022-07-17 10:16:13 --> Hooks Class Initialized
DEBUG - 2022-07-17 10:16:13 --> UTF-8 Support Enabled
INFO - 2022-07-17 10:16:13 --> Utf8 Class Initialized
INFO - 2022-07-17 10:16:13 --> URI Class Initialized
INFO - 2022-07-17 10:16:13 --> Router Class Initialized
INFO - 2022-07-17 10:16:13 --> Output Class Initialized
INFO - 2022-07-17 10:16:13 --> Security Class Initialized
DEBUG - 2022-07-17 10:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 10:16:13 --> Input Class Initialized
INFO - 2022-07-17 10:16:13 --> Language Class Initialized
INFO - 2022-07-17 10:16:13 --> Loader Class Initialized
INFO - 2022-07-17 10:16:13 --> Helper loaded: url_helper
INFO - 2022-07-17 10:16:13 --> Helper loaded: file_helper
INFO - 2022-07-17 10:16:13 --> Database Driver Class Initialized
INFO - 2022-07-17 10:16:13 --> Email Class Initialized
DEBUG - 2022-07-17 10:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 10:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 10:16:13 --> Controller Class Initialized
INFO - 2022-07-17 10:16:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 10:16:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 10:16:13 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 445
ERROR - 2022-07-17 10:16:13 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 453
ERROR - 2022-07-17 10:16:13 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 500
ERROR - 2022-07-17 10:16:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 500
INFO - 2022-07-17 10:16:13 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 10:16:13 --> Final output sent to browser
DEBUG - 2022-07-17 10:16:13 --> Total execution time: 0.1337
INFO - 2022-07-17 10:16:14 --> Config Class Initialized
INFO - 2022-07-17 10:16:14 --> Hooks Class Initialized
DEBUG - 2022-07-17 10:16:14 --> UTF-8 Support Enabled
INFO - 2022-07-17 10:16:14 --> Utf8 Class Initialized
INFO - 2022-07-17 10:16:14 --> URI Class Initialized
INFO - 2022-07-17 10:16:14 --> Router Class Initialized
INFO - 2022-07-17 10:16:14 --> Output Class Initialized
INFO - 2022-07-17 10:16:14 --> Security Class Initialized
DEBUG - 2022-07-17 10:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 10:16:14 --> Input Class Initialized
INFO - 2022-07-17 10:16:14 --> Language Class Initialized
INFO - 2022-07-17 10:16:14 --> Loader Class Initialized
INFO - 2022-07-17 10:16:14 --> Helper loaded: url_helper
INFO - 2022-07-17 10:16:14 --> Helper loaded: file_helper
INFO - 2022-07-17 10:16:14 --> Database Driver Class Initialized
INFO - 2022-07-17 10:16:14 --> Email Class Initialized
DEBUG - 2022-07-17 10:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 10:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 10:16:14 --> Controller Class Initialized
INFO - 2022-07-17 10:16:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 10:16:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 10:16:14 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 445
ERROR - 2022-07-17 10:16:14 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 453
ERROR - 2022-07-17 10:16:14 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 500
ERROR - 2022-07-17 10:16:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 500
INFO - 2022-07-17 10:16:14 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 10:16:14 --> Final output sent to browser
DEBUG - 2022-07-17 10:16:14 --> Total execution time: 0.0411
INFO - 2022-07-17 10:16:14 --> Config Class Initialized
INFO - 2022-07-17 10:16:14 --> Hooks Class Initialized
DEBUG - 2022-07-17 10:16:14 --> UTF-8 Support Enabled
INFO - 2022-07-17 10:16:14 --> Utf8 Class Initialized
INFO - 2022-07-17 10:16:14 --> URI Class Initialized
INFO - 2022-07-17 10:16:14 --> Router Class Initialized
INFO - 2022-07-17 10:16:14 --> Output Class Initialized
INFO - 2022-07-17 10:16:14 --> Security Class Initialized
DEBUG - 2022-07-17 10:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 10:16:14 --> Input Class Initialized
INFO - 2022-07-17 10:16:14 --> Language Class Initialized
INFO - 2022-07-17 10:16:14 --> Loader Class Initialized
INFO - 2022-07-17 10:16:14 --> Helper loaded: url_helper
INFO - 2022-07-17 10:16:14 --> Helper loaded: file_helper
INFO - 2022-07-17 10:16:14 --> Database Driver Class Initialized
INFO - 2022-07-17 10:16:14 --> Email Class Initialized
DEBUG - 2022-07-17 10:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 10:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 10:16:14 --> Controller Class Initialized
INFO - 2022-07-17 10:16:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 10:16:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 10:16:14 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 445
ERROR - 2022-07-17 10:16:14 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 453
ERROR - 2022-07-17 10:16:14 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 500
ERROR - 2022-07-17 10:16:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 500
INFO - 2022-07-17 10:16:14 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 10:16:14 --> Final output sent to browser
DEBUG - 2022-07-17 10:16:14 --> Total execution time: 0.0265
INFO - 2022-07-17 10:16:14 --> Config Class Initialized
INFO - 2022-07-17 10:16:14 --> Hooks Class Initialized
DEBUG - 2022-07-17 10:16:14 --> UTF-8 Support Enabled
INFO - 2022-07-17 10:16:14 --> Utf8 Class Initialized
INFO - 2022-07-17 10:16:14 --> URI Class Initialized
INFO - 2022-07-17 10:16:14 --> Router Class Initialized
INFO - 2022-07-17 10:16:14 --> Output Class Initialized
INFO - 2022-07-17 10:16:14 --> Security Class Initialized
DEBUG - 2022-07-17 10:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 10:16:14 --> Input Class Initialized
INFO - 2022-07-17 10:16:14 --> Language Class Initialized
INFO - 2022-07-17 10:16:14 --> Loader Class Initialized
INFO - 2022-07-17 10:16:14 --> Helper loaded: url_helper
INFO - 2022-07-17 10:16:14 --> Helper loaded: file_helper
INFO - 2022-07-17 10:16:14 --> Database Driver Class Initialized
INFO - 2022-07-17 10:16:14 --> Email Class Initialized
DEBUG - 2022-07-17 10:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 10:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 10:16:14 --> Controller Class Initialized
INFO - 2022-07-17 10:16:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 10:16:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 10:16:14 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 445
ERROR - 2022-07-17 10:16:14 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 453
ERROR - 2022-07-17 10:16:14 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 500
ERROR - 2022-07-17 10:16:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 500
INFO - 2022-07-17 10:16:14 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 10:16:14 --> Final output sent to browser
DEBUG - 2022-07-17 10:16:14 --> Total execution time: 0.0564
INFO - 2022-07-17 10:16:14 --> Config Class Initialized
INFO - 2022-07-17 10:16:14 --> Hooks Class Initialized
DEBUG - 2022-07-17 10:16:14 --> UTF-8 Support Enabled
INFO - 2022-07-17 10:16:14 --> Utf8 Class Initialized
INFO - 2022-07-17 10:16:14 --> URI Class Initialized
INFO - 2022-07-17 10:16:14 --> Router Class Initialized
INFO - 2022-07-17 10:16:14 --> Output Class Initialized
INFO - 2022-07-17 10:16:14 --> Security Class Initialized
DEBUG - 2022-07-17 10:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 10:16:14 --> Input Class Initialized
INFO - 2022-07-17 10:16:14 --> Language Class Initialized
INFO - 2022-07-17 10:16:14 --> Loader Class Initialized
INFO - 2022-07-17 10:16:14 --> Helper loaded: url_helper
INFO - 2022-07-17 10:16:14 --> Helper loaded: file_helper
INFO - 2022-07-17 10:16:14 --> Database Driver Class Initialized
INFO - 2022-07-17 10:16:14 --> Email Class Initialized
DEBUG - 2022-07-17 10:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 10:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 10:16:14 --> Controller Class Initialized
INFO - 2022-07-17 10:16:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 10:16:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 10:16:14 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 445
ERROR - 2022-07-17 10:16:14 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 453
ERROR - 2022-07-17 10:16:14 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 500
ERROR - 2022-07-17 10:16:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 500
INFO - 2022-07-17 10:16:14 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 10:16:14 --> Final output sent to browser
DEBUG - 2022-07-17 10:16:14 --> Total execution time: 0.0245
INFO - 2022-07-17 10:16:15 --> Config Class Initialized
INFO - 2022-07-17 10:16:15 --> Hooks Class Initialized
DEBUG - 2022-07-17 10:16:15 --> UTF-8 Support Enabled
INFO - 2022-07-17 10:16:15 --> Utf8 Class Initialized
INFO - 2022-07-17 10:16:15 --> URI Class Initialized
INFO - 2022-07-17 10:16:15 --> Router Class Initialized
INFO - 2022-07-17 10:16:15 --> Output Class Initialized
INFO - 2022-07-17 10:16:15 --> Security Class Initialized
DEBUG - 2022-07-17 10:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 10:16:15 --> Input Class Initialized
INFO - 2022-07-17 10:16:15 --> Language Class Initialized
INFO - 2022-07-17 10:16:15 --> Loader Class Initialized
INFO - 2022-07-17 10:16:15 --> Helper loaded: url_helper
INFO - 2022-07-17 10:16:15 --> Helper loaded: file_helper
INFO - 2022-07-17 10:16:15 --> Database Driver Class Initialized
INFO - 2022-07-17 10:16:15 --> Email Class Initialized
DEBUG - 2022-07-17 10:16:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 10:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 10:16:15 --> Controller Class Initialized
INFO - 2022-07-17 10:16:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 10:16:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 10:16:15 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 445
ERROR - 2022-07-17 10:16:15 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 453
ERROR - 2022-07-17 10:16:15 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 500
ERROR - 2022-07-17 10:16:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 500
INFO - 2022-07-17 10:16:15 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 10:16:15 --> Final output sent to browser
DEBUG - 2022-07-17 10:16:15 --> Total execution time: 0.0307
INFO - 2022-07-17 10:17:53 --> Config Class Initialized
INFO - 2022-07-17 10:17:53 --> Hooks Class Initialized
DEBUG - 2022-07-17 10:17:53 --> UTF-8 Support Enabled
INFO - 2022-07-17 10:17:53 --> Utf8 Class Initialized
INFO - 2022-07-17 10:17:53 --> URI Class Initialized
INFO - 2022-07-17 10:17:53 --> Router Class Initialized
INFO - 2022-07-17 10:17:53 --> Output Class Initialized
INFO - 2022-07-17 10:17:53 --> Security Class Initialized
DEBUG - 2022-07-17 10:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 10:17:53 --> Input Class Initialized
INFO - 2022-07-17 10:17:53 --> Language Class Initialized
INFO - 2022-07-17 10:17:53 --> Loader Class Initialized
INFO - 2022-07-17 10:17:53 --> Helper loaded: url_helper
INFO - 2022-07-17 10:17:53 --> Helper loaded: file_helper
INFO - 2022-07-17 10:17:53 --> Database Driver Class Initialized
INFO - 2022-07-17 10:17:53 --> Email Class Initialized
DEBUG - 2022-07-17 10:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 10:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 10:17:53 --> Controller Class Initialized
INFO - 2022-07-17 10:17:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 10:17:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 10:17:53 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 445
ERROR - 2022-07-17 10:17:53 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 453
ERROR - 2022-07-17 10:17:53 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 500
ERROR - 2022-07-17 10:17:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 500
INFO - 2022-07-17 10:17:53 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 10:17:53 --> Final output sent to browser
DEBUG - 2022-07-17 10:17:53 --> Total execution time: 0.0235
INFO - 2022-07-17 10:19:14 --> Config Class Initialized
INFO - 2022-07-17 10:19:14 --> Hooks Class Initialized
DEBUG - 2022-07-17 10:19:14 --> UTF-8 Support Enabled
INFO - 2022-07-17 10:19:14 --> Utf8 Class Initialized
INFO - 2022-07-17 10:19:14 --> URI Class Initialized
INFO - 2022-07-17 10:19:14 --> Router Class Initialized
INFO - 2022-07-17 10:19:14 --> Output Class Initialized
INFO - 2022-07-17 10:19:14 --> Security Class Initialized
DEBUG - 2022-07-17 10:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 10:19:14 --> Input Class Initialized
INFO - 2022-07-17 10:19:14 --> Language Class Initialized
INFO - 2022-07-17 10:19:14 --> Loader Class Initialized
INFO - 2022-07-17 10:19:14 --> Helper loaded: url_helper
INFO - 2022-07-17 10:19:14 --> Helper loaded: file_helper
INFO - 2022-07-17 10:19:14 --> Database Driver Class Initialized
INFO - 2022-07-17 10:19:15 --> Email Class Initialized
DEBUG - 2022-07-17 10:19:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 10:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 10:19:15 --> Controller Class Initialized
INFO - 2022-07-17 10:19:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 10:19:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 10:19:15 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 445
ERROR - 2022-07-17 10:19:15 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 453
ERROR - 2022-07-17 10:19:15 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 500
ERROR - 2022-07-17 10:19:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 500
INFO - 2022-07-17 10:19:15 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 10:19:15 --> Final output sent to browser
DEBUG - 2022-07-17 10:19:15 --> Total execution time: 0.3387
INFO - 2022-07-17 10:19:16 --> Config Class Initialized
INFO - 2022-07-17 10:19:16 --> Hooks Class Initialized
DEBUG - 2022-07-17 10:19:16 --> UTF-8 Support Enabled
INFO - 2022-07-17 10:19:16 --> Utf8 Class Initialized
INFO - 2022-07-17 10:19:16 --> URI Class Initialized
INFO - 2022-07-17 10:19:16 --> Router Class Initialized
INFO - 2022-07-17 10:19:16 --> Output Class Initialized
INFO - 2022-07-17 10:19:16 --> Security Class Initialized
DEBUG - 2022-07-17 10:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 10:19:16 --> Input Class Initialized
INFO - 2022-07-17 10:19:16 --> Language Class Initialized
INFO - 2022-07-17 10:19:16 --> Loader Class Initialized
INFO - 2022-07-17 10:19:16 --> Helper loaded: url_helper
INFO - 2022-07-17 10:19:16 --> Helper loaded: file_helper
INFO - 2022-07-17 10:19:16 --> Database Driver Class Initialized
INFO - 2022-07-17 10:19:16 --> Email Class Initialized
DEBUG - 2022-07-17 10:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 10:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 10:19:16 --> Controller Class Initialized
INFO - 2022-07-17 10:19:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 10:19:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 10:19:16 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 445
ERROR - 2022-07-17 10:19:16 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 453
ERROR - 2022-07-17 10:19:16 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 500
ERROR - 2022-07-17 10:19:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 500
INFO - 2022-07-17 10:19:16 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 10:19:16 --> Final output sent to browser
DEBUG - 2022-07-17 10:19:16 --> Total execution time: 0.0233
INFO - 2022-07-17 10:51:02 --> Config Class Initialized
INFO - 2022-07-17 10:51:02 --> Hooks Class Initialized
DEBUG - 2022-07-17 10:51:02 --> UTF-8 Support Enabled
INFO - 2022-07-17 10:51:02 --> Utf8 Class Initialized
INFO - 2022-07-17 10:51:02 --> URI Class Initialized
INFO - 2022-07-17 10:51:02 --> Router Class Initialized
INFO - 2022-07-17 10:51:02 --> Output Class Initialized
INFO - 2022-07-17 10:51:02 --> Security Class Initialized
DEBUG - 2022-07-17 10:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 10:51:02 --> Input Class Initialized
INFO - 2022-07-17 10:51:02 --> Language Class Initialized
INFO - 2022-07-17 10:51:02 --> Loader Class Initialized
INFO - 2022-07-17 10:51:02 --> Helper loaded: url_helper
INFO - 2022-07-17 10:51:02 --> Helper loaded: file_helper
INFO - 2022-07-17 10:51:02 --> Database Driver Class Initialized
INFO - 2022-07-17 10:51:03 --> Email Class Initialized
DEBUG - 2022-07-17 10:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 10:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 10:51:03 --> Controller Class Initialized
INFO - 2022-07-17 10:51:03 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 10:51:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 10:51:03 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 445
ERROR - 2022-07-17 10:51:03 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 453
ERROR - 2022-07-17 10:51:03 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 500
ERROR - 2022-07-17 10:51:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 500
INFO - 2022-07-17 10:51:03 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 10:51:03 --> Final output sent to browser
DEBUG - 2022-07-17 10:51:03 --> Total execution time: 0.2666
INFO - 2022-07-17 10:51:55 --> Config Class Initialized
INFO - 2022-07-17 10:51:55 --> Hooks Class Initialized
DEBUG - 2022-07-17 10:51:55 --> UTF-8 Support Enabled
INFO - 2022-07-17 10:51:55 --> Utf8 Class Initialized
INFO - 2022-07-17 10:51:55 --> URI Class Initialized
INFO - 2022-07-17 10:51:55 --> Router Class Initialized
INFO - 2022-07-17 10:51:55 --> Output Class Initialized
INFO - 2022-07-17 10:51:55 --> Security Class Initialized
DEBUG - 2022-07-17 10:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 10:51:55 --> Input Class Initialized
INFO - 2022-07-17 10:51:55 --> Language Class Initialized
INFO - 2022-07-17 10:51:55 --> Loader Class Initialized
INFO - 2022-07-17 10:51:55 --> Helper loaded: url_helper
INFO - 2022-07-17 10:51:55 --> Helper loaded: file_helper
INFO - 2022-07-17 10:51:55 --> Database Driver Class Initialized
INFO - 2022-07-17 10:51:55 --> Email Class Initialized
DEBUG - 2022-07-17 10:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 10:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 10:51:55 --> Controller Class Initialized
INFO - 2022-07-17 10:51:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 10:51:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 10:51:55 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 445
ERROR - 2022-07-17 10:51:55 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 453
ERROR - 2022-07-17 10:51:55 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 498
ERROR - 2022-07-17 10:51:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 498
INFO - 2022-07-17 10:51:55 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 10:51:55 --> Final output sent to browser
DEBUG - 2022-07-17 10:51:55 --> Total execution time: 0.1362
INFO - 2022-07-17 10:53:18 --> Config Class Initialized
INFO - 2022-07-17 10:53:18 --> Hooks Class Initialized
DEBUG - 2022-07-17 10:53:18 --> UTF-8 Support Enabled
INFO - 2022-07-17 10:53:18 --> Utf8 Class Initialized
INFO - 2022-07-17 10:53:18 --> URI Class Initialized
INFO - 2022-07-17 10:53:18 --> Router Class Initialized
INFO - 2022-07-17 10:53:18 --> Output Class Initialized
INFO - 2022-07-17 10:53:18 --> Security Class Initialized
DEBUG - 2022-07-17 10:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 10:53:18 --> Input Class Initialized
INFO - 2022-07-17 10:53:18 --> Language Class Initialized
INFO - 2022-07-17 10:53:18 --> Loader Class Initialized
INFO - 2022-07-17 10:53:18 --> Helper loaded: url_helper
INFO - 2022-07-17 10:53:18 --> Helper loaded: file_helper
INFO - 2022-07-17 10:53:18 --> Database Driver Class Initialized
INFO - 2022-07-17 10:53:18 --> Email Class Initialized
DEBUG - 2022-07-17 10:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 10:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 10:53:18 --> Controller Class Initialized
INFO - 2022-07-17 10:53:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 10:53:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 10:53:18 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 445
ERROR - 2022-07-17 10:53:18 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 453
ERROR - 2022-07-17 10:53:18 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 498
ERROR - 2022-07-17 10:53:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 498
INFO - 2022-07-17 10:53:18 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 10:53:18 --> Final output sent to browser
DEBUG - 2022-07-17 10:53:18 --> Total execution time: 0.1470
INFO - 2022-07-17 10:53:19 --> Config Class Initialized
INFO - 2022-07-17 10:53:19 --> Hooks Class Initialized
DEBUG - 2022-07-17 10:53:19 --> UTF-8 Support Enabled
INFO - 2022-07-17 10:53:19 --> Utf8 Class Initialized
INFO - 2022-07-17 10:53:19 --> URI Class Initialized
INFO - 2022-07-17 10:53:19 --> Router Class Initialized
INFO - 2022-07-17 10:53:19 --> Output Class Initialized
INFO - 2022-07-17 10:53:19 --> Security Class Initialized
DEBUG - 2022-07-17 10:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 10:53:19 --> Input Class Initialized
INFO - 2022-07-17 10:53:19 --> Language Class Initialized
INFO - 2022-07-17 10:53:19 --> Loader Class Initialized
INFO - 2022-07-17 10:53:19 --> Helper loaded: url_helper
INFO - 2022-07-17 10:53:19 --> Helper loaded: file_helper
INFO - 2022-07-17 10:53:19 --> Database Driver Class Initialized
INFO - 2022-07-17 10:53:19 --> Email Class Initialized
DEBUG - 2022-07-17 10:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 10:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 10:53:19 --> Controller Class Initialized
INFO - 2022-07-17 10:53:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 10:53:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 10:53:19 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 445
ERROR - 2022-07-17 10:53:19 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 453
ERROR - 2022-07-17 10:53:19 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 498
ERROR - 2022-07-17 10:53:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 498
INFO - 2022-07-17 10:53:19 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 10:53:19 --> Final output sent to browser
DEBUG - 2022-07-17 10:53:19 --> Total execution time: 0.1302
INFO - 2022-07-17 10:53:20 --> Config Class Initialized
INFO - 2022-07-17 10:53:20 --> Hooks Class Initialized
DEBUG - 2022-07-17 10:53:20 --> UTF-8 Support Enabled
INFO - 2022-07-17 10:53:20 --> Utf8 Class Initialized
INFO - 2022-07-17 10:53:20 --> URI Class Initialized
INFO - 2022-07-17 10:53:20 --> Router Class Initialized
INFO - 2022-07-17 10:53:20 --> Output Class Initialized
INFO - 2022-07-17 10:53:20 --> Security Class Initialized
DEBUG - 2022-07-17 10:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 10:53:20 --> Input Class Initialized
INFO - 2022-07-17 10:53:20 --> Language Class Initialized
INFO - 2022-07-17 10:53:20 --> Loader Class Initialized
INFO - 2022-07-17 10:53:20 --> Helper loaded: url_helper
INFO - 2022-07-17 10:53:20 --> Helper loaded: file_helper
INFO - 2022-07-17 10:53:20 --> Database Driver Class Initialized
INFO - 2022-07-17 10:53:20 --> Email Class Initialized
DEBUG - 2022-07-17 10:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 10:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 10:53:20 --> Controller Class Initialized
INFO - 2022-07-17 10:53:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 10:53:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 10:53:20 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 445
ERROR - 2022-07-17 10:53:20 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 453
ERROR - 2022-07-17 10:53:20 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 498
ERROR - 2022-07-17 10:53:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 498
INFO - 2022-07-17 10:53:20 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 10:53:20 --> Final output sent to browser
DEBUG - 2022-07-17 10:53:20 --> Total execution time: 0.0571
INFO - 2022-07-17 10:53:20 --> Config Class Initialized
INFO - 2022-07-17 10:53:20 --> Hooks Class Initialized
DEBUG - 2022-07-17 10:53:20 --> UTF-8 Support Enabled
INFO - 2022-07-17 10:53:20 --> Utf8 Class Initialized
INFO - 2022-07-17 10:53:20 --> URI Class Initialized
INFO - 2022-07-17 10:53:20 --> Router Class Initialized
INFO - 2022-07-17 10:53:20 --> Output Class Initialized
INFO - 2022-07-17 10:53:20 --> Security Class Initialized
DEBUG - 2022-07-17 10:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 10:53:20 --> Input Class Initialized
INFO - 2022-07-17 10:53:20 --> Language Class Initialized
INFO - 2022-07-17 10:53:20 --> Loader Class Initialized
INFO - 2022-07-17 10:53:20 --> Helper loaded: url_helper
INFO - 2022-07-17 10:53:20 --> Helper loaded: file_helper
INFO - 2022-07-17 10:53:20 --> Database Driver Class Initialized
INFO - 2022-07-17 10:53:20 --> Email Class Initialized
DEBUG - 2022-07-17 10:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 10:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 10:53:20 --> Controller Class Initialized
INFO - 2022-07-17 10:53:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 10:53:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 10:53:20 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 445
ERROR - 2022-07-17 10:53:20 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 453
ERROR - 2022-07-17 10:53:20 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 498
ERROR - 2022-07-17 10:53:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 498
INFO - 2022-07-17 10:53:20 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 10:53:20 --> Final output sent to browser
DEBUG - 2022-07-17 10:53:20 --> Total execution time: 0.0372
INFO - 2022-07-17 10:53:20 --> Config Class Initialized
INFO - 2022-07-17 10:53:20 --> Hooks Class Initialized
DEBUG - 2022-07-17 10:53:20 --> UTF-8 Support Enabled
INFO - 2022-07-17 10:53:20 --> Utf8 Class Initialized
INFO - 2022-07-17 10:53:20 --> URI Class Initialized
INFO - 2022-07-17 10:53:20 --> Router Class Initialized
INFO - 2022-07-17 10:53:20 --> Output Class Initialized
INFO - 2022-07-17 10:53:20 --> Security Class Initialized
DEBUG - 2022-07-17 10:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 10:53:20 --> Input Class Initialized
INFO - 2022-07-17 10:53:20 --> Language Class Initialized
INFO - 2022-07-17 10:53:20 --> Loader Class Initialized
INFO - 2022-07-17 10:53:20 --> Helper loaded: url_helper
INFO - 2022-07-17 10:53:20 --> Helper loaded: file_helper
INFO - 2022-07-17 10:53:20 --> Database Driver Class Initialized
INFO - 2022-07-17 10:53:20 --> Email Class Initialized
DEBUG - 2022-07-17 10:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 10:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 10:53:20 --> Controller Class Initialized
INFO - 2022-07-17 10:53:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 10:53:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 10:53:21 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 445
ERROR - 2022-07-17 10:53:21 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 453
ERROR - 2022-07-17 10:53:21 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 498
ERROR - 2022-07-17 10:53:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 498
INFO - 2022-07-17 10:53:21 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 10:53:21 --> Final output sent to browser
DEBUG - 2022-07-17 10:53:21 --> Total execution time: 0.0255
INFO - 2022-07-17 10:53:21 --> Config Class Initialized
INFO - 2022-07-17 10:53:21 --> Hooks Class Initialized
DEBUG - 2022-07-17 10:53:21 --> UTF-8 Support Enabled
INFO - 2022-07-17 10:53:21 --> Utf8 Class Initialized
INFO - 2022-07-17 10:53:21 --> URI Class Initialized
INFO - 2022-07-17 10:53:21 --> Router Class Initialized
INFO - 2022-07-17 10:53:21 --> Output Class Initialized
INFO - 2022-07-17 10:53:21 --> Security Class Initialized
DEBUG - 2022-07-17 10:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 10:53:21 --> Input Class Initialized
INFO - 2022-07-17 10:53:21 --> Language Class Initialized
INFO - 2022-07-17 10:53:21 --> Loader Class Initialized
INFO - 2022-07-17 10:53:21 --> Helper loaded: url_helper
INFO - 2022-07-17 10:53:21 --> Helper loaded: file_helper
INFO - 2022-07-17 10:53:21 --> Database Driver Class Initialized
INFO - 2022-07-17 10:53:21 --> Email Class Initialized
DEBUG - 2022-07-17 10:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 10:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 10:53:21 --> Controller Class Initialized
INFO - 2022-07-17 10:53:21 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 10:53:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 10:53:21 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 445
ERROR - 2022-07-17 10:53:21 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 453
ERROR - 2022-07-17 10:53:21 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 498
ERROR - 2022-07-17 10:53:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 498
INFO - 2022-07-17 10:53:21 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 10:53:21 --> Final output sent to browser
DEBUG - 2022-07-17 10:53:21 --> Total execution time: 0.0419
INFO - 2022-07-17 10:53:28 --> Config Class Initialized
INFO - 2022-07-17 10:53:28 --> Hooks Class Initialized
DEBUG - 2022-07-17 10:53:28 --> UTF-8 Support Enabled
INFO - 2022-07-17 10:53:28 --> Utf8 Class Initialized
INFO - 2022-07-17 10:53:28 --> URI Class Initialized
INFO - 2022-07-17 10:53:28 --> Router Class Initialized
INFO - 2022-07-17 10:53:28 --> Output Class Initialized
INFO - 2022-07-17 10:53:28 --> Security Class Initialized
DEBUG - 2022-07-17 10:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 10:53:28 --> Input Class Initialized
INFO - 2022-07-17 10:53:28 --> Language Class Initialized
INFO - 2022-07-17 10:53:28 --> Loader Class Initialized
INFO - 2022-07-17 10:53:28 --> Helper loaded: url_helper
INFO - 2022-07-17 10:53:28 --> Helper loaded: file_helper
INFO - 2022-07-17 10:53:28 --> Database Driver Class Initialized
INFO - 2022-07-17 10:53:28 --> Email Class Initialized
DEBUG - 2022-07-17 10:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 10:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 10:53:28 --> Controller Class Initialized
INFO - 2022-07-17 10:53:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 10:53:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 10:53:28 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 445
ERROR - 2022-07-17 10:53:28 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 453
ERROR - 2022-07-17 10:53:28 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 498
ERROR - 2022-07-17 10:53:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 498
INFO - 2022-07-17 10:53:28 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 10:53:28 --> Final output sent to browser
DEBUG - 2022-07-17 10:53:28 --> Total execution time: 0.0443
INFO - 2022-07-17 10:54:40 --> Config Class Initialized
INFO - 2022-07-17 10:54:40 --> Hooks Class Initialized
DEBUG - 2022-07-17 10:54:40 --> UTF-8 Support Enabled
INFO - 2022-07-17 10:54:40 --> Utf8 Class Initialized
INFO - 2022-07-17 10:54:40 --> URI Class Initialized
INFO - 2022-07-17 10:54:40 --> Router Class Initialized
INFO - 2022-07-17 10:54:40 --> Output Class Initialized
INFO - 2022-07-17 10:54:40 --> Security Class Initialized
DEBUG - 2022-07-17 10:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 10:54:40 --> Input Class Initialized
INFO - 2022-07-17 10:54:40 --> Language Class Initialized
INFO - 2022-07-17 10:54:40 --> Loader Class Initialized
INFO - 2022-07-17 10:54:40 --> Helper loaded: url_helper
INFO - 2022-07-17 10:54:40 --> Helper loaded: file_helper
INFO - 2022-07-17 10:54:40 --> Database Driver Class Initialized
INFO - 2022-07-17 10:54:40 --> Email Class Initialized
DEBUG - 2022-07-17 10:54:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 10:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 10:54:40 --> Controller Class Initialized
INFO - 2022-07-17 10:54:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 10:54:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 10:54:40 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 445
ERROR - 2022-07-17 10:54:40 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 453
ERROR - 2022-07-17 10:54:40 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 498
ERROR - 2022-07-17 10:54:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 498
INFO - 2022-07-17 10:54:40 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 10:54:40 --> Final output sent to browser
DEBUG - 2022-07-17 10:54:40 --> Total execution time: 0.0602
INFO - 2022-07-17 10:57:11 --> Config Class Initialized
INFO - 2022-07-17 10:57:11 --> Hooks Class Initialized
DEBUG - 2022-07-17 10:57:11 --> UTF-8 Support Enabled
INFO - 2022-07-17 10:57:11 --> Utf8 Class Initialized
INFO - 2022-07-17 10:57:11 --> URI Class Initialized
INFO - 2022-07-17 10:57:11 --> Router Class Initialized
INFO - 2022-07-17 10:57:11 --> Output Class Initialized
INFO - 2022-07-17 10:57:11 --> Security Class Initialized
DEBUG - 2022-07-17 10:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 10:57:11 --> Input Class Initialized
INFO - 2022-07-17 10:57:11 --> Language Class Initialized
INFO - 2022-07-17 10:57:11 --> Loader Class Initialized
INFO - 2022-07-17 10:57:11 --> Helper loaded: url_helper
INFO - 2022-07-17 10:57:11 --> Helper loaded: file_helper
INFO - 2022-07-17 10:57:11 --> Database Driver Class Initialized
INFO - 2022-07-17 10:57:11 --> Email Class Initialized
DEBUG - 2022-07-17 10:57:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 10:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 10:57:11 --> Controller Class Initialized
INFO - 2022-07-17 10:57:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 10:57:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 10:57:11 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 445
ERROR - 2022-07-17 10:57:11 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 453
ERROR - 2022-07-17 10:57:11 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 498
ERROR - 2022-07-17 10:57:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 498
INFO - 2022-07-17 10:57:11 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 10:57:11 --> Final output sent to browser
DEBUG - 2022-07-17 10:57:11 --> Total execution time: 0.0476
INFO - 2022-07-17 10:58:11 --> Config Class Initialized
INFO - 2022-07-17 10:58:11 --> Hooks Class Initialized
DEBUG - 2022-07-17 10:58:11 --> UTF-8 Support Enabled
INFO - 2022-07-17 10:58:11 --> Utf8 Class Initialized
INFO - 2022-07-17 10:58:12 --> URI Class Initialized
INFO - 2022-07-17 10:58:12 --> Router Class Initialized
INFO - 2022-07-17 10:58:12 --> Output Class Initialized
INFO - 2022-07-17 10:58:12 --> Security Class Initialized
DEBUG - 2022-07-17 10:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 10:58:12 --> Input Class Initialized
INFO - 2022-07-17 10:58:12 --> Language Class Initialized
INFO - 2022-07-17 10:58:12 --> Loader Class Initialized
INFO - 2022-07-17 10:58:12 --> Helper loaded: url_helper
INFO - 2022-07-17 10:58:12 --> Helper loaded: file_helper
INFO - 2022-07-17 10:58:12 --> Database Driver Class Initialized
INFO - 2022-07-17 10:58:12 --> Email Class Initialized
DEBUG - 2022-07-17 10:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 10:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 10:58:12 --> Controller Class Initialized
INFO - 2022-07-17 10:58:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 10:58:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 10:58:12 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 445
ERROR - 2022-07-17 10:58:12 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 453
ERROR - 2022-07-17 10:58:12 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 501
ERROR - 2022-07-17 10:58:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 501
INFO - 2022-07-17 10:58:12 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 10:58:12 --> Final output sent to browser
DEBUG - 2022-07-17 10:58:12 --> Total execution time: 0.0749
INFO - 2022-07-17 10:58:42 --> Config Class Initialized
INFO - 2022-07-17 10:58:42 --> Hooks Class Initialized
DEBUG - 2022-07-17 10:58:42 --> UTF-8 Support Enabled
INFO - 2022-07-17 10:58:42 --> Utf8 Class Initialized
INFO - 2022-07-17 10:58:42 --> URI Class Initialized
INFO - 2022-07-17 10:58:42 --> Router Class Initialized
INFO - 2022-07-17 10:58:42 --> Output Class Initialized
INFO - 2022-07-17 10:58:42 --> Security Class Initialized
DEBUG - 2022-07-17 10:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 10:58:42 --> Input Class Initialized
INFO - 2022-07-17 10:58:42 --> Language Class Initialized
INFO - 2022-07-17 10:58:42 --> Loader Class Initialized
INFO - 2022-07-17 10:58:42 --> Helper loaded: url_helper
INFO - 2022-07-17 10:58:42 --> Helper loaded: file_helper
INFO - 2022-07-17 10:58:42 --> Database Driver Class Initialized
INFO - 2022-07-17 10:58:43 --> Email Class Initialized
DEBUG - 2022-07-17 10:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 10:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 10:58:43 --> Controller Class Initialized
INFO - 2022-07-17 10:58:43 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 10:58:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 10:58:43 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 445
ERROR - 2022-07-17 10:58:43 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 453
ERROR - 2022-07-17 10:58:43 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 504
ERROR - 2022-07-17 10:58:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 504
INFO - 2022-07-17 10:58:43 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 10:58:43 --> Final output sent to browser
DEBUG - 2022-07-17 10:58:43 --> Total execution time: 0.1416
INFO - 2022-07-17 12:01:27 --> Config Class Initialized
INFO - 2022-07-17 12:01:27 --> Hooks Class Initialized
DEBUG - 2022-07-17 12:01:27 --> UTF-8 Support Enabled
INFO - 2022-07-17 12:01:27 --> Utf8 Class Initialized
INFO - 2022-07-17 12:01:27 --> URI Class Initialized
INFO - 2022-07-17 12:01:27 --> Router Class Initialized
INFO - 2022-07-17 12:01:27 --> Output Class Initialized
INFO - 2022-07-17 12:01:27 --> Security Class Initialized
DEBUG - 2022-07-17 12:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 12:01:27 --> Input Class Initialized
INFO - 2022-07-17 12:01:27 --> Language Class Initialized
INFO - 2022-07-17 12:01:27 --> Loader Class Initialized
INFO - 2022-07-17 12:01:27 --> Helper loaded: url_helper
INFO - 2022-07-17 12:01:27 --> Helper loaded: file_helper
INFO - 2022-07-17 12:01:27 --> Database Driver Class Initialized
INFO - 2022-07-17 12:01:28 --> Email Class Initialized
DEBUG - 2022-07-17 12:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 12:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 12:01:28 --> Controller Class Initialized
INFO - 2022-07-17 12:01:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 12:01:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 12:01:28 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 445
ERROR - 2022-07-17 12:01:28 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 453
ERROR - 2022-07-17 12:01:28 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 504
ERROR - 2022-07-17 12:01:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 504
INFO - 2022-07-17 12:01:28 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 12:01:28 --> Final output sent to browser
DEBUG - 2022-07-17 12:01:28 --> Total execution time: 0.4567
INFO - 2022-07-17 12:03:39 --> Config Class Initialized
INFO - 2022-07-17 12:03:39 --> Hooks Class Initialized
DEBUG - 2022-07-17 12:03:39 --> UTF-8 Support Enabled
INFO - 2022-07-17 12:03:39 --> Utf8 Class Initialized
INFO - 2022-07-17 12:03:39 --> URI Class Initialized
INFO - 2022-07-17 12:03:39 --> Router Class Initialized
INFO - 2022-07-17 12:03:39 --> Output Class Initialized
INFO - 2022-07-17 12:03:39 --> Security Class Initialized
DEBUG - 2022-07-17 12:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 12:03:39 --> Input Class Initialized
INFO - 2022-07-17 12:03:39 --> Language Class Initialized
INFO - 2022-07-17 12:03:39 --> Loader Class Initialized
INFO - 2022-07-17 12:03:39 --> Helper loaded: url_helper
INFO - 2022-07-17 12:03:39 --> Helper loaded: file_helper
INFO - 2022-07-17 12:03:39 --> Database Driver Class Initialized
INFO - 2022-07-17 12:03:39 --> Email Class Initialized
DEBUG - 2022-07-17 12:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 12:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 12:03:39 --> Controller Class Initialized
INFO - 2022-07-17 12:03:39 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 12:03:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 12:03:39 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 445
ERROR - 2022-07-17 12:03:39 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 453
ERROR - 2022-07-17 12:03:39 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 504
ERROR - 2022-07-17 12:03:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 504
INFO - 2022-07-17 12:03:39 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 12:03:39 --> Final output sent to browser
DEBUG - 2022-07-17 12:03:39 --> Total execution time: 0.2322
INFO - 2022-07-17 12:05:14 --> Config Class Initialized
INFO - 2022-07-17 12:05:14 --> Hooks Class Initialized
DEBUG - 2022-07-17 12:05:14 --> UTF-8 Support Enabled
INFO - 2022-07-17 12:05:14 --> Utf8 Class Initialized
INFO - 2022-07-17 12:05:14 --> URI Class Initialized
INFO - 2022-07-17 12:05:14 --> Router Class Initialized
INFO - 2022-07-17 12:05:14 --> Output Class Initialized
INFO - 2022-07-17 12:05:14 --> Security Class Initialized
DEBUG - 2022-07-17 12:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 12:05:14 --> Input Class Initialized
INFO - 2022-07-17 12:05:14 --> Language Class Initialized
INFO - 2022-07-17 12:05:14 --> Loader Class Initialized
INFO - 2022-07-17 12:05:14 --> Helper loaded: url_helper
INFO - 2022-07-17 12:05:14 --> Helper loaded: file_helper
INFO - 2022-07-17 12:05:14 --> Database Driver Class Initialized
INFO - 2022-07-17 12:05:14 --> Email Class Initialized
DEBUG - 2022-07-17 12:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 12:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 12:05:14 --> Controller Class Initialized
INFO - 2022-07-17 12:05:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 12:05:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 12:05:14 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 444
ERROR - 2022-07-17 12:05:14 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 452
ERROR - 2022-07-17 12:05:14 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 503
ERROR - 2022-07-17 12:05:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 503
INFO - 2022-07-17 12:05:14 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 12:05:14 --> Final output sent to browser
DEBUG - 2022-07-17 12:05:14 --> Total execution time: 0.0901
INFO - 2022-07-17 12:05:48 --> Config Class Initialized
INFO - 2022-07-17 12:05:48 --> Hooks Class Initialized
DEBUG - 2022-07-17 12:05:48 --> UTF-8 Support Enabled
INFO - 2022-07-17 12:05:48 --> Utf8 Class Initialized
INFO - 2022-07-17 12:05:48 --> URI Class Initialized
INFO - 2022-07-17 12:05:48 --> Router Class Initialized
INFO - 2022-07-17 12:05:48 --> Output Class Initialized
INFO - 2022-07-17 12:05:48 --> Security Class Initialized
DEBUG - 2022-07-17 12:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 12:05:48 --> Input Class Initialized
INFO - 2022-07-17 12:05:48 --> Language Class Initialized
INFO - 2022-07-17 12:05:48 --> Loader Class Initialized
INFO - 2022-07-17 12:05:48 --> Helper loaded: url_helper
INFO - 2022-07-17 12:05:48 --> Helper loaded: file_helper
INFO - 2022-07-17 12:05:48 --> Database Driver Class Initialized
INFO - 2022-07-17 12:05:48 --> Email Class Initialized
DEBUG - 2022-07-17 12:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 12:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 12:05:49 --> Controller Class Initialized
INFO - 2022-07-17 12:05:49 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 12:05:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 12:05:49 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 444
ERROR - 2022-07-17 12:05:49 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 452
ERROR - 2022-07-17 12:05:49 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 503
ERROR - 2022-07-17 12:05:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 503
INFO - 2022-07-17 12:05:49 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 12:05:49 --> Final output sent to browser
DEBUG - 2022-07-17 12:05:49 --> Total execution time: 0.0382
INFO - 2022-07-17 12:07:04 --> Config Class Initialized
INFO - 2022-07-17 12:07:04 --> Hooks Class Initialized
DEBUG - 2022-07-17 12:07:04 --> UTF-8 Support Enabled
INFO - 2022-07-17 12:07:04 --> Utf8 Class Initialized
INFO - 2022-07-17 12:07:04 --> URI Class Initialized
INFO - 2022-07-17 12:07:04 --> Router Class Initialized
INFO - 2022-07-17 12:07:04 --> Output Class Initialized
INFO - 2022-07-17 12:07:04 --> Security Class Initialized
DEBUG - 2022-07-17 12:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 12:07:04 --> Input Class Initialized
INFO - 2022-07-17 12:07:04 --> Language Class Initialized
INFO - 2022-07-17 12:07:04 --> Loader Class Initialized
INFO - 2022-07-17 12:07:04 --> Helper loaded: url_helper
INFO - 2022-07-17 12:07:04 --> Helper loaded: file_helper
INFO - 2022-07-17 12:07:04 --> Database Driver Class Initialized
INFO - 2022-07-17 12:07:04 --> Email Class Initialized
DEBUG - 2022-07-17 12:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 12:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 12:07:04 --> Controller Class Initialized
INFO - 2022-07-17 12:07:04 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 12:07:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 12:07:04 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 445
ERROR - 2022-07-17 12:07:04 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 453
ERROR - 2022-07-17 12:07:04 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 504
ERROR - 2022-07-17 12:07:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 504
INFO - 2022-07-17 12:07:04 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 12:07:04 --> Final output sent to browser
DEBUG - 2022-07-17 12:07:04 --> Total execution time: 0.0510
INFO - 2022-07-17 12:07:06 --> Config Class Initialized
INFO - 2022-07-17 12:07:06 --> Hooks Class Initialized
DEBUG - 2022-07-17 12:07:06 --> UTF-8 Support Enabled
INFO - 2022-07-17 12:07:06 --> Utf8 Class Initialized
INFO - 2022-07-17 12:07:06 --> URI Class Initialized
INFO - 2022-07-17 12:07:06 --> Router Class Initialized
INFO - 2022-07-17 12:07:06 --> Output Class Initialized
INFO - 2022-07-17 12:07:06 --> Security Class Initialized
DEBUG - 2022-07-17 12:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 12:07:06 --> Input Class Initialized
INFO - 2022-07-17 12:07:06 --> Language Class Initialized
INFO - 2022-07-17 12:07:06 --> Loader Class Initialized
INFO - 2022-07-17 12:07:06 --> Helper loaded: url_helper
INFO - 2022-07-17 12:07:06 --> Helper loaded: file_helper
INFO - 2022-07-17 12:07:06 --> Database Driver Class Initialized
INFO - 2022-07-17 12:07:06 --> Email Class Initialized
DEBUG - 2022-07-17 12:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 12:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 12:07:06 --> Controller Class Initialized
INFO - 2022-07-17 12:07:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 12:07:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 12:07:06 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 445
ERROR - 2022-07-17 12:07:06 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 453
ERROR - 2022-07-17 12:07:06 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 504
ERROR - 2022-07-17 12:07:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 504
INFO - 2022-07-17 12:07:06 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 12:07:06 --> Final output sent to browser
DEBUG - 2022-07-17 12:07:06 --> Total execution time: 0.1451
INFO - 2022-07-17 12:07:07 --> Config Class Initialized
INFO - 2022-07-17 12:07:07 --> Hooks Class Initialized
DEBUG - 2022-07-17 12:07:07 --> UTF-8 Support Enabled
INFO - 2022-07-17 12:07:07 --> Utf8 Class Initialized
INFO - 2022-07-17 12:07:07 --> URI Class Initialized
INFO - 2022-07-17 12:07:07 --> Router Class Initialized
INFO - 2022-07-17 12:07:07 --> Output Class Initialized
INFO - 2022-07-17 12:07:07 --> Security Class Initialized
DEBUG - 2022-07-17 12:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 12:07:07 --> Input Class Initialized
INFO - 2022-07-17 12:07:07 --> Language Class Initialized
INFO - 2022-07-17 12:07:07 --> Loader Class Initialized
INFO - 2022-07-17 12:07:07 --> Helper loaded: url_helper
INFO - 2022-07-17 12:07:07 --> Helper loaded: file_helper
INFO - 2022-07-17 12:07:07 --> Database Driver Class Initialized
INFO - 2022-07-17 12:07:07 --> Email Class Initialized
DEBUG - 2022-07-17 12:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 12:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 12:07:07 --> Controller Class Initialized
INFO - 2022-07-17 12:07:07 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 12:07:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 12:07:07 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 445
ERROR - 2022-07-17 12:07:07 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 453
ERROR - 2022-07-17 12:07:07 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 504
ERROR - 2022-07-17 12:07:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 504
INFO - 2022-07-17 12:07:07 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 12:07:07 --> Final output sent to browser
DEBUG - 2022-07-17 12:07:07 --> Total execution time: 0.0454
INFO - 2022-07-17 12:10:27 --> Config Class Initialized
INFO - 2022-07-17 12:10:27 --> Hooks Class Initialized
DEBUG - 2022-07-17 12:10:27 --> UTF-8 Support Enabled
INFO - 2022-07-17 12:10:27 --> Utf8 Class Initialized
INFO - 2022-07-17 12:10:27 --> URI Class Initialized
INFO - 2022-07-17 12:10:27 --> Router Class Initialized
INFO - 2022-07-17 12:10:27 --> Output Class Initialized
INFO - 2022-07-17 12:10:27 --> Security Class Initialized
DEBUG - 2022-07-17 12:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 12:10:27 --> Input Class Initialized
INFO - 2022-07-17 12:10:27 --> Language Class Initialized
INFO - 2022-07-17 12:10:27 --> Loader Class Initialized
INFO - 2022-07-17 12:10:27 --> Helper loaded: url_helper
INFO - 2022-07-17 12:10:27 --> Helper loaded: file_helper
INFO - 2022-07-17 12:10:27 --> Database Driver Class Initialized
INFO - 2022-07-17 12:10:27 --> Email Class Initialized
DEBUG - 2022-07-17 12:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 12:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 12:10:27 --> Controller Class Initialized
INFO - 2022-07-17 12:10:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 12:10:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 12:10:27 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 445
ERROR - 2022-07-17 12:10:27 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 453
ERROR - 2022-07-17 12:10:27 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 505
ERROR - 2022-07-17 12:10:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 505
INFO - 2022-07-17 12:10:27 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 12:10:27 --> Final output sent to browser
DEBUG - 2022-07-17 12:10:27 --> Total execution time: 0.1641
INFO - 2022-07-17 15:52:16 --> Config Class Initialized
INFO - 2022-07-17 15:52:16 --> Hooks Class Initialized
DEBUG - 2022-07-17 15:52:16 --> UTF-8 Support Enabled
INFO - 2022-07-17 15:52:16 --> Utf8 Class Initialized
INFO - 2022-07-17 15:52:16 --> URI Class Initialized
INFO - 2022-07-17 15:52:16 --> Router Class Initialized
INFO - 2022-07-17 15:52:16 --> Output Class Initialized
INFO - 2022-07-17 15:52:16 --> Security Class Initialized
DEBUG - 2022-07-17 15:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 15:52:16 --> Input Class Initialized
INFO - 2022-07-17 15:52:16 --> Language Class Initialized
INFO - 2022-07-17 15:52:16 --> Loader Class Initialized
INFO - 2022-07-17 15:52:16 --> Helper loaded: url_helper
INFO - 2022-07-17 15:52:16 --> Helper loaded: file_helper
INFO - 2022-07-17 15:52:16 --> Database Driver Class Initialized
INFO - 2022-07-17 15:52:16 --> Email Class Initialized
DEBUG - 2022-07-17 15:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 15:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 15:52:16 --> Controller Class Initialized
INFO - 2022-07-17 15:52:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 15:52:16 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 15:52:16 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-07-17 15:52:16 --> Final output sent to browser
DEBUG - 2022-07-17 15:52:16 --> Total execution time: 0.2088
INFO - 2022-07-17 15:52:19 --> Config Class Initialized
INFO - 2022-07-17 15:52:19 --> Hooks Class Initialized
DEBUG - 2022-07-17 15:52:19 --> UTF-8 Support Enabled
INFO - 2022-07-17 15:52:19 --> Utf8 Class Initialized
INFO - 2022-07-17 15:52:19 --> URI Class Initialized
INFO - 2022-07-17 15:52:19 --> Router Class Initialized
INFO - 2022-07-17 15:52:19 --> Output Class Initialized
INFO - 2022-07-17 15:52:19 --> Security Class Initialized
DEBUG - 2022-07-17 15:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 15:52:19 --> Input Class Initialized
INFO - 2022-07-17 15:52:19 --> Language Class Initialized
INFO - 2022-07-17 15:52:19 --> Loader Class Initialized
INFO - 2022-07-17 15:52:19 --> Helper loaded: url_helper
INFO - 2022-07-17 15:52:19 --> Helper loaded: file_helper
INFO - 2022-07-17 15:52:19 --> Database Driver Class Initialized
INFO - 2022-07-17 15:52:19 --> Email Class Initialized
DEBUG - 2022-07-17 15:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 15:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 15:52:19 --> Controller Class Initialized
INFO - 2022-07-17 15:52:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 15:52:19 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-17 21:22:22 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-07-17 21:22:22 --> Final output sent to browser
DEBUG - 2022-07-17 21:22:22 --> Total execution time: 2.9226
INFO - 2022-07-17 15:54:40 --> Config Class Initialized
INFO - 2022-07-17 15:54:40 --> Hooks Class Initialized
DEBUG - 2022-07-17 15:54:40 --> UTF-8 Support Enabled
INFO - 2022-07-17 15:54:40 --> Utf8 Class Initialized
INFO - 2022-07-17 15:54:40 --> URI Class Initialized
INFO - 2022-07-17 15:54:40 --> Router Class Initialized
INFO - 2022-07-17 15:54:40 --> Output Class Initialized
INFO - 2022-07-17 15:54:40 --> Security Class Initialized
DEBUG - 2022-07-17 15:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 15:54:40 --> Input Class Initialized
INFO - 2022-07-17 15:54:40 --> Language Class Initialized
INFO - 2022-07-17 15:54:40 --> Loader Class Initialized
INFO - 2022-07-17 15:54:40 --> Helper loaded: url_helper
INFO - 2022-07-17 15:54:40 --> Helper loaded: file_helper
INFO - 2022-07-17 15:54:40 --> Database Driver Class Initialized
INFO - 2022-07-17 15:54:40 --> Email Class Initialized
DEBUG - 2022-07-17 15:54:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 15:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 15:54:41 --> Controller Class Initialized
INFO - 2022-07-17 15:54:41 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 15:54:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 15:54:41 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 447
ERROR - 2022-07-17 15:54:41 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 455
ERROR - 2022-07-17 15:54:41 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 507
ERROR - 2022-07-17 15:54:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 507
INFO - 2022-07-17 15:54:41 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 15:54:41 --> Final output sent to browser
DEBUG - 2022-07-17 15:54:41 --> Total execution time: 0.9508
INFO - 2022-07-17 15:56:36 --> Config Class Initialized
INFO - 2022-07-17 15:56:36 --> Hooks Class Initialized
DEBUG - 2022-07-17 15:56:36 --> UTF-8 Support Enabled
INFO - 2022-07-17 15:56:36 --> Utf8 Class Initialized
INFO - 2022-07-17 15:56:36 --> URI Class Initialized
INFO - 2022-07-17 15:56:36 --> Router Class Initialized
INFO - 2022-07-17 15:56:36 --> Output Class Initialized
INFO - 2022-07-17 15:56:36 --> Security Class Initialized
DEBUG - 2022-07-17 15:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 15:56:36 --> Input Class Initialized
INFO - 2022-07-17 15:56:36 --> Language Class Initialized
INFO - 2022-07-17 15:56:36 --> Loader Class Initialized
INFO - 2022-07-17 15:56:36 --> Helper loaded: url_helper
INFO - 2022-07-17 15:56:36 --> Helper loaded: file_helper
INFO - 2022-07-17 15:56:36 --> Database Driver Class Initialized
INFO - 2022-07-17 15:56:37 --> Email Class Initialized
DEBUG - 2022-07-17 15:56:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 15:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 15:56:37 --> Controller Class Initialized
INFO - 2022-07-17 15:56:37 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 15:56:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 15:56:37 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 448
ERROR - 2022-07-17 15:56:37 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 456
ERROR - 2022-07-17 15:56:37 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 508
ERROR - 2022-07-17 15:56:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 508
INFO - 2022-07-17 15:56:37 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 15:56:37 --> Final output sent to browser
DEBUG - 2022-07-17 15:56:37 --> Total execution time: 0.2449
INFO - 2022-07-17 15:57:19 --> Config Class Initialized
INFO - 2022-07-17 15:57:19 --> Hooks Class Initialized
DEBUG - 2022-07-17 15:57:19 --> UTF-8 Support Enabled
INFO - 2022-07-17 15:57:19 --> Utf8 Class Initialized
INFO - 2022-07-17 15:57:19 --> URI Class Initialized
INFO - 2022-07-17 15:57:19 --> Router Class Initialized
INFO - 2022-07-17 15:57:19 --> Output Class Initialized
INFO - 2022-07-17 15:57:19 --> Security Class Initialized
DEBUG - 2022-07-17 15:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 15:57:19 --> Input Class Initialized
INFO - 2022-07-17 15:57:19 --> Language Class Initialized
INFO - 2022-07-17 15:57:19 --> Loader Class Initialized
INFO - 2022-07-17 15:57:19 --> Helper loaded: url_helper
INFO - 2022-07-17 15:57:19 --> Helper loaded: file_helper
INFO - 2022-07-17 15:57:19 --> Database Driver Class Initialized
INFO - 2022-07-17 15:57:19 --> Email Class Initialized
DEBUG - 2022-07-17 15:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 15:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 15:57:19 --> Controller Class Initialized
INFO - 2022-07-17 15:57:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 15:57:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 15:57:19 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 448
ERROR - 2022-07-17 15:57:19 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 456
ERROR - 2022-07-17 15:57:19 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 508
ERROR - 2022-07-17 15:57:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 508
INFO - 2022-07-17 15:57:19 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 15:57:19 --> Final output sent to browser
DEBUG - 2022-07-17 15:57:19 --> Total execution time: 0.0927
INFO - 2022-07-17 15:57:29 --> Config Class Initialized
INFO - 2022-07-17 15:57:29 --> Hooks Class Initialized
DEBUG - 2022-07-17 15:57:29 --> UTF-8 Support Enabled
INFO - 2022-07-17 15:57:29 --> Utf8 Class Initialized
INFO - 2022-07-17 15:57:29 --> URI Class Initialized
INFO - 2022-07-17 15:57:29 --> Router Class Initialized
INFO - 2022-07-17 15:57:29 --> Output Class Initialized
INFO - 2022-07-17 15:57:29 --> Security Class Initialized
DEBUG - 2022-07-17 15:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 15:57:29 --> Input Class Initialized
INFO - 2022-07-17 15:57:29 --> Language Class Initialized
INFO - 2022-07-17 15:57:29 --> Loader Class Initialized
INFO - 2022-07-17 15:57:29 --> Helper loaded: url_helper
INFO - 2022-07-17 15:57:29 --> Helper loaded: file_helper
INFO - 2022-07-17 15:57:29 --> Database Driver Class Initialized
INFO - 2022-07-17 15:57:29 --> Email Class Initialized
DEBUG - 2022-07-17 15:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 15:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 15:57:29 --> Controller Class Initialized
INFO - 2022-07-17 15:57:29 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 15:57:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 15:57:29 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 448
ERROR - 2022-07-17 15:57:29 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 456
ERROR - 2022-07-17 15:57:29 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 508
ERROR - 2022-07-17 15:57:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 508
INFO - 2022-07-17 15:57:29 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 15:57:29 --> Final output sent to browser
DEBUG - 2022-07-17 15:57:29 --> Total execution time: 0.2607
INFO - 2022-07-17 15:57:38 --> Config Class Initialized
INFO - 2022-07-17 15:57:38 --> Hooks Class Initialized
DEBUG - 2022-07-17 15:57:38 --> UTF-8 Support Enabled
INFO - 2022-07-17 15:57:38 --> Utf8 Class Initialized
INFO - 2022-07-17 15:57:38 --> URI Class Initialized
INFO - 2022-07-17 15:57:38 --> Router Class Initialized
INFO - 2022-07-17 15:57:38 --> Output Class Initialized
INFO - 2022-07-17 15:57:38 --> Security Class Initialized
DEBUG - 2022-07-17 15:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 15:57:38 --> Input Class Initialized
INFO - 2022-07-17 15:57:38 --> Language Class Initialized
INFO - 2022-07-17 15:57:38 --> Loader Class Initialized
INFO - 2022-07-17 15:57:38 --> Helper loaded: url_helper
INFO - 2022-07-17 15:57:38 --> Helper loaded: file_helper
INFO - 2022-07-17 15:57:38 --> Database Driver Class Initialized
INFO - 2022-07-17 15:57:38 --> Email Class Initialized
DEBUG - 2022-07-17 15:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 15:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 15:57:38 --> Controller Class Initialized
INFO - 2022-07-17 15:57:38 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 15:57:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 15:57:38 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 448
ERROR - 2022-07-17 15:57:38 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 456
ERROR - 2022-07-17 15:57:38 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 508
ERROR - 2022-07-17 15:57:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 508
INFO - 2022-07-17 15:57:38 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 15:57:38 --> Final output sent to browser
DEBUG - 2022-07-17 15:57:38 --> Total execution time: 0.0620
INFO - 2022-07-17 15:58:22 --> Config Class Initialized
INFO - 2022-07-17 15:58:22 --> Hooks Class Initialized
DEBUG - 2022-07-17 15:58:22 --> UTF-8 Support Enabled
INFO - 2022-07-17 15:58:22 --> Utf8 Class Initialized
INFO - 2022-07-17 15:58:22 --> URI Class Initialized
INFO - 2022-07-17 15:58:22 --> Router Class Initialized
INFO - 2022-07-17 15:58:22 --> Output Class Initialized
INFO - 2022-07-17 15:58:22 --> Security Class Initialized
DEBUG - 2022-07-17 15:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 15:58:22 --> Input Class Initialized
INFO - 2022-07-17 15:58:22 --> Language Class Initialized
INFO - 2022-07-17 15:58:22 --> Loader Class Initialized
INFO - 2022-07-17 15:58:22 --> Helper loaded: url_helper
INFO - 2022-07-17 15:58:22 --> Helper loaded: file_helper
INFO - 2022-07-17 15:58:22 --> Database Driver Class Initialized
INFO - 2022-07-17 15:58:22 --> Email Class Initialized
DEBUG - 2022-07-17 15:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 15:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 15:58:22 --> Controller Class Initialized
INFO - 2022-07-17 15:58:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 15:58:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 15:58:22 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 448
ERROR - 2022-07-17 15:58:22 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 456
ERROR - 2022-07-17 15:58:22 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 511
ERROR - 2022-07-17 15:58:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 511
INFO - 2022-07-17 15:58:22 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 15:58:22 --> Final output sent to browser
DEBUG - 2022-07-17 15:58:22 --> Total execution time: 0.0932
INFO - 2022-07-17 15:59:36 --> Config Class Initialized
INFO - 2022-07-17 15:59:36 --> Hooks Class Initialized
DEBUG - 2022-07-17 15:59:36 --> UTF-8 Support Enabled
INFO - 2022-07-17 15:59:36 --> Utf8 Class Initialized
INFO - 2022-07-17 15:59:36 --> URI Class Initialized
INFO - 2022-07-17 15:59:36 --> Router Class Initialized
INFO - 2022-07-17 15:59:36 --> Output Class Initialized
INFO - 2022-07-17 15:59:36 --> Security Class Initialized
DEBUG - 2022-07-17 15:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 15:59:36 --> Input Class Initialized
INFO - 2022-07-17 15:59:36 --> Language Class Initialized
INFO - 2022-07-17 15:59:36 --> Loader Class Initialized
INFO - 2022-07-17 15:59:36 --> Helper loaded: url_helper
INFO - 2022-07-17 15:59:36 --> Helper loaded: file_helper
INFO - 2022-07-17 15:59:36 --> Database Driver Class Initialized
INFO - 2022-07-17 15:59:36 --> Email Class Initialized
DEBUG - 2022-07-17 15:59:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 15:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 15:59:36 --> Controller Class Initialized
INFO - 2022-07-17 15:59:36 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 15:59:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 15:59:36 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 450
ERROR - 2022-07-17 15:59:36 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 458
ERROR - 2022-07-17 15:59:36 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 513
ERROR - 2022-07-17 15:59:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 513
INFO - 2022-07-17 15:59:36 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 15:59:36 --> Final output sent to browser
DEBUG - 2022-07-17 15:59:36 --> Total execution time: 0.1691
INFO - 2022-07-17 16:00:18 --> Config Class Initialized
INFO - 2022-07-17 16:00:18 --> Hooks Class Initialized
DEBUG - 2022-07-17 16:00:18 --> UTF-8 Support Enabled
INFO - 2022-07-17 16:00:18 --> Utf8 Class Initialized
INFO - 2022-07-17 16:00:18 --> URI Class Initialized
INFO - 2022-07-17 16:00:18 --> Router Class Initialized
INFO - 2022-07-17 16:00:18 --> Output Class Initialized
INFO - 2022-07-17 16:00:18 --> Security Class Initialized
DEBUG - 2022-07-17 16:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 16:00:18 --> Input Class Initialized
INFO - 2022-07-17 16:00:18 --> Language Class Initialized
INFO - 2022-07-17 16:00:18 --> Loader Class Initialized
INFO - 2022-07-17 16:00:18 --> Helper loaded: url_helper
INFO - 2022-07-17 16:00:18 --> Helper loaded: file_helper
INFO - 2022-07-17 16:00:18 --> Database Driver Class Initialized
INFO - 2022-07-17 16:00:19 --> Email Class Initialized
DEBUG - 2022-07-17 16:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 16:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 16:00:19 --> Controller Class Initialized
INFO - 2022-07-17 16:00:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 16:00:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 16:00:19 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 450
ERROR - 2022-07-17 16:00:19 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 458
ERROR - 2022-07-17 16:00:19 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 513
ERROR - 2022-07-17 16:00:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 513
INFO - 2022-07-17 16:00:19 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 16:00:19 --> Final output sent to browser
DEBUG - 2022-07-17 16:00:19 --> Total execution time: 0.1361
INFO - 2022-07-17 16:02:19 --> Config Class Initialized
INFO - 2022-07-17 16:02:19 --> Hooks Class Initialized
DEBUG - 2022-07-17 16:02:19 --> UTF-8 Support Enabled
INFO - 2022-07-17 16:02:19 --> Utf8 Class Initialized
INFO - 2022-07-17 16:02:19 --> URI Class Initialized
INFO - 2022-07-17 16:02:19 --> Router Class Initialized
INFO - 2022-07-17 16:02:19 --> Output Class Initialized
INFO - 2022-07-17 16:02:19 --> Security Class Initialized
DEBUG - 2022-07-17 16:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 16:02:19 --> Input Class Initialized
INFO - 2022-07-17 16:02:19 --> Language Class Initialized
INFO - 2022-07-17 16:02:19 --> Loader Class Initialized
INFO - 2022-07-17 16:02:19 --> Helper loaded: url_helper
INFO - 2022-07-17 16:02:19 --> Helper loaded: file_helper
INFO - 2022-07-17 16:02:19 --> Database Driver Class Initialized
INFO - 2022-07-17 16:02:19 --> Email Class Initialized
DEBUG - 2022-07-17 16:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 16:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 16:02:19 --> Controller Class Initialized
INFO - 2022-07-17 16:02:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 16:02:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 16:02:19 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 450
ERROR - 2022-07-17 16:02:19 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 458
ERROR - 2022-07-17 16:02:19 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 513
ERROR - 2022-07-17 16:02:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 513
INFO - 2022-07-17 16:02:19 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 16:02:19 --> Final output sent to browser
DEBUG - 2022-07-17 16:02:19 --> Total execution time: 0.1912
INFO - 2022-07-17 16:03:21 --> Config Class Initialized
INFO - 2022-07-17 16:03:21 --> Hooks Class Initialized
DEBUG - 2022-07-17 16:03:21 --> UTF-8 Support Enabled
INFO - 2022-07-17 16:03:21 --> Utf8 Class Initialized
INFO - 2022-07-17 16:03:21 --> URI Class Initialized
INFO - 2022-07-17 16:03:21 --> Router Class Initialized
INFO - 2022-07-17 16:03:21 --> Output Class Initialized
INFO - 2022-07-17 16:03:21 --> Security Class Initialized
DEBUG - 2022-07-17 16:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 16:03:21 --> Input Class Initialized
INFO - 2022-07-17 16:03:21 --> Language Class Initialized
INFO - 2022-07-17 16:03:21 --> Loader Class Initialized
INFO - 2022-07-17 16:03:21 --> Helper loaded: url_helper
INFO - 2022-07-17 16:03:21 --> Helper loaded: file_helper
INFO - 2022-07-17 16:03:21 --> Database Driver Class Initialized
INFO - 2022-07-17 16:03:21 --> Email Class Initialized
DEBUG - 2022-07-17 16:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 16:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 16:03:21 --> Controller Class Initialized
INFO - 2022-07-17 16:03:21 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 16:03:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 16:03:21 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 450
ERROR - 2022-07-17 16:03:21 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 458
ERROR - 2022-07-17 16:03:21 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 513
ERROR - 2022-07-17 16:03:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 513
INFO - 2022-07-17 16:03:21 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 16:03:21 --> Final output sent to browser
DEBUG - 2022-07-17 16:03:21 --> Total execution time: 0.2305
INFO - 2022-07-17 16:13:26 --> Config Class Initialized
INFO - 2022-07-17 16:13:26 --> Hooks Class Initialized
DEBUG - 2022-07-17 16:13:26 --> UTF-8 Support Enabled
INFO - 2022-07-17 16:13:26 --> Utf8 Class Initialized
INFO - 2022-07-17 16:13:26 --> URI Class Initialized
INFO - 2022-07-17 16:13:26 --> Router Class Initialized
INFO - 2022-07-17 16:13:26 --> Output Class Initialized
INFO - 2022-07-17 16:13:26 --> Security Class Initialized
DEBUG - 2022-07-17 16:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 16:13:26 --> Input Class Initialized
INFO - 2022-07-17 16:13:26 --> Language Class Initialized
INFO - 2022-07-17 16:13:26 --> Loader Class Initialized
INFO - 2022-07-17 16:13:26 --> Helper loaded: url_helper
INFO - 2022-07-17 16:13:26 --> Helper loaded: file_helper
INFO - 2022-07-17 16:13:26 --> Database Driver Class Initialized
INFO - 2022-07-17 16:13:26 --> Email Class Initialized
DEBUG - 2022-07-17 16:13:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 16:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 16:13:26 --> Controller Class Initialized
INFO - 2022-07-17 16:13:26 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 16:13:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 16:13:26 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 450
ERROR - 2022-07-17 16:13:26 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 458
ERROR - 2022-07-17 16:13:26 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 513
ERROR - 2022-07-17 16:13:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 513
INFO - 2022-07-17 16:13:26 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 16:13:26 --> Final output sent to browser
DEBUG - 2022-07-17 16:13:26 --> Total execution time: 0.2492
INFO - 2022-07-17 16:25:39 --> Config Class Initialized
INFO - 2022-07-17 16:25:39 --> Hooks Class Initialized
DEBUG - 2022-07-17 16:25:39 --> UTF-8 Support Enabled
INFO - 2022-07-17 16:25:39 --> Utf8 Class Initialized
INFO - 2022-07-17 16:25:39 --> URI Class Initialized
INFO - 2022-07-17 16:25:39 --> Router Class Initialized
INFO - 2022-07-17 16:25:39 --> Output Class Initialized
INFO - 2022-07-17 16:25:39 --> Security Class Initialized
DEBUG - 2022-07-17 16:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 16:25:39 --> Input Class Initialized
INFO - 2022-07-17 16:25:39 --> Language Class Initialized
INFO - 2022-07-17 16:25:39 --> Loader Class Initialized
INFO - 2022-07-17 16:25:39 --> Helper loaded: url_helper
INFO - 2022-07-17 16:25:39 --> Helper loaded: file_helper
INFO - 2022-07-17 16:25:39 --> Database Driver Class Initialized
INFO - 2022-07-17 16:25:39 --> Email Class Initialized
DEBUG - 2022-07-17 16:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 16:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 16:25:39 --> Controller Class Initialized
INFO - 2022-07-17 16:25:39 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 16:25:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 16:25:39 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 450
ERROR - 2022-07-17 16:25:39 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 458
ERROR - 2022-07-17 16:25:39 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 516
ERROR - 2022-07-17 16:25:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 516
INFO - 2022-07-17 16:25:39 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 16:25:39 --> Final output sent to browser
DEBUG - 2022-07-17 16:25:39 --> Total execution time: 0.2558
INFO - 2022-07-17 16:29:12 --> Config Class Initialized
INFO - 2022-07-17 16:29:12 --> Hooks Class Initialized
DEBUG - 2022-07-17 16:29:12 --> UTF-8 Support Enabled
INFO - 2022-07-17 16:29:12 --> Utf8 Class Initialized
INFO - 2022-07-17 16:29:12 --> URI Class Initialized
INFO - 2022-07-17 16:29:12 --> Router Class Initialized
INFO - 2022-07-17 16:29:12 --> Output Class Initialized
INFO - 2022-07-17 16:29:12 --> Security Class Initialized
DEBUG - 2022-07-17 16:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 16:29:12 --> Input Class Initialized
INFO - 2022-07-17 16:29:12 --> Language Class Initialized
INFO - 2022-07-17 16:29:12 --> Loader Class Initialized
INFO - 2022-07-17 16:29:12 --> Helper loaded: url_helper
INFO - 2022-07-17 16:29:12 --> Helper loaded: file_helper
INFO - 2022-07-17 16:29:12 --> Database Driver Class Initialized
INFO - 2022-07-17 16:29:12 --> Email Class Initialized
DEBUG - 2022-07-17 16:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 16:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 16:29:12 --> Controller Class Initialized
INFO - 2022-07-17 16:29:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 16:29:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 16:29:12 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 459
ERROR - 2022-07-17 16:29:12 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 467
ERROR - 2022-07-17 16:29:12 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 525
ERROR - 2022-07-17 16:29:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 525
INFO - 2022-07-17 16:29:12 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 16:29:12 --> Final output sent to browser
DEBUG - 2022-07-17 16:29:12 --> Total execution time: 0.1322
INFO - 2022-07-17 16:29:15 --> Config Class Initialized
INFO - 2022-07-17 16:29:15 --> Hooks Class Initialized
DEBUG - 2022-07-17 16:29:15 --> UTF-8 Support Enabled
INFO - 2022-07-17 16:29:15 --> Utf8 Class Initialized
INFO - 2022-07-17 16:29:15 --> URI Class Initialized
INFO - 2022-07-17 16:29:15 --> Router Class Initialized
INFO - 2022-07-17 16:29:15 --> Output Class Initialized
INFO - 2022-07-17 16:29:15 --> Security Class Initialized
DEBUG - 2022-07-17 16:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 16:29:15 --> Input Class Initialized
INFO - 2022-07-17 16:29:15 --> Language Class Initialized
INFO - 2022-07-17 16:29:15 --> Loader Class Initialized
INFO - 2022-07-17 16:29:15 --> Helper loaded: url_helper
INFO - 2022-07-17 16:29:15 --> Helper loaded: file_helper
INFO - 2022-07-17 16:29:15 --> Database Driver Class Initialized
INFO - 2022-07-17 16:29:15 --> Email Class Initialized
DEBUG - 2022-07-17 16:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 16:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 16:29:15 --> Controller Class Initialized
INFO - 2022-07-17 16:29:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 16:29:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 16:29:15 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 459
ERROR - 2022-07-17 16:29:15 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 467
ERROR - 2022-07-17 16:29:15 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 525
ERROR - 2022-07-17 16:29:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 525
INFO - 2022-07-17 16:29:15 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 16:29:15 --> Final output sent to browser
DEBUG - 2022-07-17 16:29:15 --> Total execution time: 0.0753
INFO - 2022-07-17 20:05:36 --> Config Class Initialized
INFO - 2022-07-17 20:05:36 --> Hooks Class Initialized
DEBUG - 2022-07-17 20:05:36 --> UTF-8 Support Enabled
INFO - 2022-07-17 20:05:36 --> Utf8 Class Initialized
INFO - 2022-07-17 20:05:37 --> URI Class Initialized
INFO - 2022-07-17 20:05:37 --> Router Class Initialized
INFO - 2022-07-17 20:05:37 --> Output Class Initialized
INFO - 2022-07-17 20:05:37 --> Security Class Initialized
DEBUG - 2022-07-17 20:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 20:05:37 --> Input Class Initialized
INFO - 2022-07-17 20:05:37 --> Language Class Initialized
INFO - 2022-07-17 20:05:37 --> Loader Class Initialized
INFO - 2022-07-17 20:05:37 --> Helper loaded: url_helper
INFO - 2022-07-17 20:05:37 --> Helper loaded: file_helper
INFO - 2022-07-17 20:05:37 --> Database Driver Class Initialized
INFO - 2022-07-17 20:05:37 --> Email Class Initialized
DEBUG - 2022-07-17 20:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 20:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 20:05:37 --> Controller Class Initialized
INFO - 2022-07-17 20:05:37 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 20:05:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 20:05:37 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 459
ERROR - 2022-07-17 20:05:37 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 467
ERROR - 2022-07-17 20:05:37 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 526
ERROR - 2022-07-17 20:05:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 526
INFO - 2022-07-17 20:05:37 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 20:05:37 --> Final output sent to browser
DEBUG - 2022-07-17 20:05:37 --> Total execution time: 0.2947
INFO - 2022-07-17 20:11:34 --> Config Class Initialized
INFO - 2022-07-17 20:11:34 --> Hooks Class Initialized
DEBUG - 2022-07-17 20:11:34 --> UTF-8 Support Enabled
INFO - 2022-07-17 20:11:34 --> Utf8 Class Initialized
INFO - 2022-07-17 20:11:34 --> URI Class Initialized
INFO - 2022-07-17 20:11:34 --> Router Class Initialized
INFO - 2022-07-17 20:11:34 --> Output Class Initialized
INFO - 2022-07-17 20:11:34 --> Security Class Initialized
DEBUG - 2022-07-17 20:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 20:11:34 --> Input Class Initialized
INFO - 2022-07-17 20:11:34 --> Language Class Initialized
INFO - 2022-07-17 20:11:34 --> Loader Class Initialized
INFO - 2022-07-17 20:11:34 --> Helper loaded: url_helper
INFO - 2022-07-17 20:11:34 --> Helper loaded: file_helper
INFO - 2022-07-17 20:11:34 --> Database Driver Class Initialized
INFO - 2022-07-17 20:11:34 --> Email Class Initialized
DEBUG - 2022-07-17 20:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 20:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 20:11:34 --> Controller Class Initialized
INFO - 2022-07-17 20:11:34 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 20:11:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 20:11:34 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 475
ERROR - 2022-07-17 20:11:35 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 483
ERROR - 2022-07-17 20:11:35 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 542
ERROR - 2022-07-17 20:11:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 542
ERROR - 2022-07-17 20:11:35 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 560
ERROR - 2022-07-17 20:11:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 560
ERROR - 2022-07-17 20:11:35 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 578
ERROR - 2022-07-17 20:11:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 578
INFO - 2022-07-17 20:11:35 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 20:11:35 --> Final output sent to browser
DEBUG - 2022-07-17 20:11:35 --> Total execution time: 0.5421
INFO - 2022-07-17 20:13:54 --> Config Class Initialized
INFO - 2022-07-17 20:13:54 --> Hooks Class Initialized
DEBUG - 2022-07-17 20:13:54 --> UTF-8 Support Enabled
INFO - 2022-07-17 20:13:54 --> Utf8 Class Initialized
INFO - 2022-07-17 20:13:54 --> URI Class Initialized
INFO - 2022-07-17 20:13:54 --> Router Class Initialized
INFO - 2022-07-17 20:13:54 --> Output Class Initialized
INFO - 2022-07-17 20:13:54 --> Security Class Initialized
DEBUG - 2022-07-17 20:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 20:13:54 --> Input Class Initialized
INFO - 2022-07-17 20:13:54 --> Language Class Initialized
INFO - 2022-07-17 20:13:54 --> Loader Class Initialized
INFO - 2022-07-17 20:13:54 --> Helper loaded: url_helper
INFO - 2022-07-17 20:13:54 --> Helper loaded: file_helper
INFO - 2022-07-17 20:13:54 --> Database Driver Class Initialized
INFO - 2022-07-17 20:13:54 --> Email Class Initialized
DEBUG - 2022-07-17 20:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 20:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 20:13:54 --> Controller Class Initialized
INFO - 2022-07-17 20:13:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 20:13:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 20:13:54 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 475
ERROR - 2022-07-17 20:13:54 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 483
ERROR - 2022-07-17 20:13:54 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 542
ERROR - 2022-07-17 20:13:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 542
ERROR - 2022-07-17 20:13:54 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 560
ERROR - 2022-07-17 20:13:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 560
ERROR - 2022-07-17 20:13:55 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 578
ERROR - 2022-07-17 20:13:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 578
INFO - 2022-07-17 20:13:55 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 20:13:55 --> Final output sent to browser
DEBUG - 2022-07-17 20:13:55 --> Total execution time: 0.3306
INFO - 2022-07-17 20:14:11 --> Config Class Initialized
INFO - 2022-07-17 20:14:11 --> Hooks Class Initialized
DEBUG - 2022-07-17 20:14:11 --> UTF-8 Support Enabled
INFO - 2022-07-17 20:14:11 --> Utf8 Class Initialized
INFO - 2022-07-17 20:14:11 --> URI Class Initialized
INFO - 2022-07-17 20:14:11 --> Router Class Initialized
INFO - 2022-07-17 20:14:11 --> Output Class Initialized
INFO - 2022-07-17 20:14:11 --> Security Class Initialized
DEBUG - 2022-07-17 20:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 20:14:11 --> Input Class Initialized
INFO - 2022-07-17 20:14:11 --> Language Class Initialized
INFO - 2022-07-17 20:14:11 --> Loader Class Initialized
INFO - 2022-07-17 20:14:11 --> Helper loaded: url_helper
INFO - 2022-07-17 20:14:11 --> Helper loaded: file_helper
INFO - 2022-07-17 20:14:11 --> Database Driver Class Initialized
INFO - 2022-07-17 20:14:11 --> Email Class Initialized
DEBUG - 2022-07-17 20:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 20:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 20:14:11 --> Controller Class Initialized
INFO - 2022-07-17 20:14:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 20:14:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 20:14:11 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 475
ERROR - 2022-07-17 20:14:11 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 483
ERROR - 2022-07-17 20:14:11 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 542
ERROR - 2022-07-17 20:14:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 542
ERROR - 2022-07-17 20:14:11 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 560
ERROR - 2022-07-17 20:14:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 560
ERROR - 2022-07-17 20:14:11 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 578
ERROR - 2022-07-17 20:14:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 578
INFO - 2022-07-17 20:14:11 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 20:14:11 --> Final output sent to browser
DEBUG - 2022-07-17 20:14:11 --> Total execution time: 0.2405
INFO - 2022-07-17 20:14:31 --> Config Class Initialized
INFO - 2022-07-17 20:14:31 --> Hooks Class Initialized
DEBUG - 2022-07-17 20:14:31 --> UTF-8 Support Enabled
INFO - 2022-07-17 20:14:31 --> Utf8 Class Initialized
INFO - 2022-07-17 20:14:31 --> URI Class Initialized
INFO - 2022-07-17 20:14:31 --> Router Class Initialized
INFO - 2022-07-17 20:14:31 --> Output Class Initialized
INFO - 2022-07-17 20:14:31 --> Security Class Initialized
DEBUG - 2022-07-17 20:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 20:14:31 --> Input Class Initialized
INFO - 2022-07-17 20:14:31 --> Language Class Initialized
INFO - 2022-07-17 20:14:31 --> Loader Class Initialized
INFO - 2022-07-17 20:14:31 --> Helper loaded: url_helper
INFO - 2022-07-17 20:14:31 --> Helper loaded: file_helper
INFO - 2022-07-17 20:14:31 --> Database Driver Class Initialized
INFO - 2022-07-17 20:14:31 --> Email Class Initialized
DEBUG - 2022-07-17 20:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 20:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 20:14:31 --> Controller Class Initialized
INFO - 2022-07-17 20:14:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 20:14:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 20:14:31 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 475
ERROR - 2022-07-17 20:14:31 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 483
ERROR - 2022-07-17 20:14:31 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 542
ERROR - 2022-07-17 20:14:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 542
ERROR - 2022-07-17 20:14:31 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 560
ERROR - 2022-07-17 20:14:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 560
ERROR - 2022-07-17 20:14:31 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 578
ERROR - 2022-07-17 20:14:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 578
INFO - 2022-07-17 20:14:31 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 20:14:31 --> Final output sent to browser
DEBUG - 2022-07-17 20:14:31 --> Total execution time: 0.2915
INFO - 2022-07-17 20:14:31 --> Config Class Initialized
INFO - 2022-07-17 20:14:31 --> Hooks Class Initialized
DEBUG - 2022-07-17 20:14:31 --> UTF-8 Support Enabled
INFO - 2022-07-17 20:14:31 --> Utf8 Class Initialized
INFO - 2022-07-17 20:14:31 --> URI Class Initialized
INFO - 2022-07-17 20:14:31 --> Router Class Initialized
INFO - 2022-07-17 20:14:31 --> Output Class Initialized
INFO - 2022-07-17 20:14:31 --> Security Class Initialized
DEBUG - 2022-07-17 20:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 20:14:31 --> Input Class Initialized
INFO - 2022-07-17 20:14:31 --> Language Class Initialized
INFO - 2022-07-17 20:14:31 --> Loader Class Initialized
INFO - 2022-07-17 20:14:31 --> Helper loaded: url_helper
INFO - 2022-07-17 20:14:31 --> Helper loaded: file_helper
INFO - 2022-07-17 20:14:31 --> Database Driver Class Initialized
INFO - 2022-07-17 20:14:32 --> Email Class Initialized
DEBUG - 2022-07-17 20:14:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 20:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 20:14:32 --> Controller Class Initialized
INFO - 2022-07-17 20:14:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 20:14:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 20:14:32 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 475
ERROR - 2022-07-17 20:14:32 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 483
ERROR - 2022-07-17 20:14:32 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 542
ERROR - 2022-07-17 20:14:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 542
ERROR - 2022-07-17 20:14:32 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 560
ERROR - 2022-07-17 20:14:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 560
ERROR - 2022-07-17 20:14:32 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 578
ERROR - 2022-07-17 20:14:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 578
INFO - 2022-07-17 20:14:32 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 20:14:32 --> Final output sent to browser
DEBUG - 2022-07-17 20:14:32 --> Total execution time: 0.2823
INFO - 2022-07-17 20:19:25 --> Config Class Initialized
INFO - 2022-07-17 20:19:25 --> Hooks Class Initialized
DEBUG - 2022-07-17 20:19:25 --> UTF-8 Support Enabled
INFO - 2022-07-17 20:19:25 --> Utf8 Class Initialized
INFO - 2022-07-17 20:19:25 --> URI Class Initialized
INFO - 2022-07-17 20:19:25 --> Router Class Initialized
INFO - 2022-07-17 20:19:25 --> Output Class Initialized
INFO - 2022-07-17 20:19:25 --> Security Class Initialized
DEBUG - 2022-07-17 20:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 20:19:25 --> Input Class Initialized
INFO - 2022-07-17 20:19:25 --> Language Class Initialized
INFO - 2022-07-17 20:19:25 --> Loader Class Initialized
INFO - 2022-07-17 20:19:25 --> Helper loaded: url_helper
INFO - 2022-07-17 20:19:25 --> Helper loaded: file_helper
INFO - 2022-07-17 20:19:25 --> Database Driver Class Initialized
INFO - 2022-07-17 20:19:26 --> Email Class Initialized
DEBUG - 2022-07-17 20:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 20:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 20:19:26 --> Controller Class Initialized
INFO - 2022-07-17 20:19:26 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 20:19:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 20:19:26 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 499
ERROR - 2022-07-17 20:19:26 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 507
ERROR - 2022-07-17 20:19:26 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 568
ERROR - 2022-07-17 20:19:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 568
ERROR - 2022-07-17 20:19:26 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 586
ERROR - 2022-07-17 20:19:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 586
ERROR - 2022-07-17 20:19:26 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 604
ERROR - 2022-07-17 20:19:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 604
INFO - 2022-07-17 20:19:26 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 20:19:26 --> Final output sent to browser
DEBUG - 2022-07-17 20:19:26 --> Total execution time: 0.5156
INFO - 2022-07-17 20:20:49 --> Config Class Initialized
INFO - 2022-07-17 20:20:49 --> Hooks Class Initialized
DEBUG - 2022-07-17 20:20:49 --> UTF-8 Support Enabled
INFO - 2022-07-17 20:20:49 --> Utf8 Class Initialized
INFO - 2022-07-17 20:20:49 --> URI Class Initialized
INFO - 2022-07-17 20:20:49 --> Router Class Initialized
INFO - 2022-07-17 20:20:49 --> Output Class Initialized
INFO - 2022-07-17 20:20:49 --> Security Class Initialized
DEBUG - 2022-07-17 20:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 20:20:49 --> Input Class Initialized
INFO - 2022-07-17 20:20:49 --> Language Class Initialized
INFO - 2022-07-17 20:20:49 --> Loader Class Initialized
INFO - 2022-07-17 20:20:49 --> Helper loaded: url_helper
INFO - 2022-07-17 20:20:49 --> Helper loaded: file_helper
INFO - 2022-07-17 20:20:49 --> Database Driver Class Initialized
INFO - 2022-07-17 20:20:49 --> Email Class Initialized
DEBUG - 2022-07-17 20:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 20:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 20:20:49 --> Controller Class Initialized
INFO - 2022-07-17 20:20:49 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 20:20:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 20:20:49 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 502
ERROR - 2022-07-17 20:20:49 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 510
ERROR - 2022-07-17 20:20:49 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 571
ERROR - 2022-07-17 20:20:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 571
ERROR - 2022-07-17 20:20:49 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 589
ERROR - 2022-07-17 20:20:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 589
ERROR - 2022-07-17 20:20:49 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 607
ERROR - 2022-07-17 20:20:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 607
INFO - 2022-07-17 20:20:49 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 20:20:49 --> Final output sent to browser
DEBUG - 2022-07-17 20:20:49 --> Total execution time: 0.1770
INFO - 2022-07-17 20:25:10 --> Config Class Initialized
INFO - 2022-07-17 20:25:10 --> Hooks Class Initialized
DEBUG - 2022-07-17 20:25:10 --> UTF-8 Support Enabled
INFO - 2022-07-17 20:25:10 --> Utf8 Class Initialized
INFO - 2022-07-17 20:25:10 --> URI Class Initialized
INFO - 2022-07-17 20:25:10 --> Router Class Initialized
INFO - 2022-07-17 20:25:10 --> Output Class Initialized
INFO - 2022-07-17 20:25:10 --> Security Class Initialized
DEBUG - 2022-07-17 20:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 20:25:10 --> Input Class Initialized
INFO - 2022-07-17 20:25:10 --> Language Class Initialized
INFO - 2022-07-17 20:25:10 --> Loader Class Initialized
INFO - 2022-07-17 20:25:10 --> Helper loaded: url_helper
INFO - 2022-07-17 20:25:10 --> Helper loaded: file_helper
INFO - 2022-07-17 20:25:10 --> Database Driver Class Initialized
INFO - 2022-07-17 20:25:10 --> Email Class Initialized
DEBUG - 2022-07-17 20:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 20:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 20:25:10 --> Controller Class Initialized
INFO - 2022-07-17 20:25:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 20:25:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 20:25:10 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 513
ERROR - 2022-07-17 20:25:10 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 521
ERROR - 2022-07-17 20:25:10 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 584
ERROR - 2022-07-17 20:25:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 584
ERROR - 2022-07-17 20:25:10 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 602
ERROR - 2022-07-17 20:25:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 602
ERROR - 2022-07-17 20:25:10 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 620
ERROR - 2022-07-17 20:25:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 620
INFO - 2022-07-17 20:25:10 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 20:25:10 --> Final output sent to browser
DEBUG - 2022-07-17 20:25:10 --> Total execution time: 0.2603
INFO - 2022-07-17 20:26:17 --> Config Class Initialized
INFO - 2022-07-17 20:26:17 --> Hooks Class Initialized
DEBUG - 2022-07-17 20:26:17 --> UTF-8 Support Enabled
INFO - 2022-07-17 20:26:17 --> Utf8 Class Initialized
INFO - 2022-07-17 20:26:17 --> URI Class Initialized
INFO - 2022-07-17 20:26:17 --> Router Class Initialized
INFO - 2022-07-17 20:26:17 --> Output Class Initialized
INFO - 2022-07-17 20:26:17 --> Security Class Initialized
DEBUG - 2022-07-17 20:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 20:26:17 --> Input Class Initialized
INFO - 2022-07-17 20:26:17 --> Language Class Initialized
INFO - 2022-07-17 20:26:17 --> Loader Class Initialized
INFO - 2022-07-17 20:26:17 --> Helper loaded: url_helper
INFO - 2022-07-17 20:26:17 --> Helper loaded: file_helper
INFO - 2022-07-17 20:26:17 --> Database Driver Class Initialized
INFO - 2022-07-17 20:26:17 --> Email Class Initialized
DEBUG - 2022-07-17 20:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 20:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 20:26:18 --> Controller Class Initialized
INFO - 2022-07-17 20:26:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 20:26:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 20:26:18 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 513
ERROR - 2022-07-17 20:26:18 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 521
ERROR - 2022-07-17 20:26:18 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 584
ERROR - 2022-07-17 20:26:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 584
ERROR - 2022-07-17 20:26:18 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 602
ERROR - 2022-07-17 20:26:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 602
ERROR - 2022-07-17 20:26:18 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 620
ERROR - 2022-07-17 20:26:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 620
INFO - 2022-07-17 20:26:18 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 20:26:18 --> Final output sent to browser
DEBUG - 2022-07-17 20:26:18 --> Total execution time: 0.5119
INFO - 2022-07-17 20:28:01 --> Config Class Initialized
INFO - 2022-07-17 20:28:01 --> Hooks Class Initialized
DEBUG - 2022-07-17 20:28:01 --> UTF-8 Support Enabled
INFO - 2022-07-17 20:28:01 --> Utf8 Class Initialized
INFO - 2022-07-17 20:28:01 --> URI Class Initialized
INFO - 2022-07-17 20:28:01 --> Router Class Initialized
INFO - 2022-07-17 20:28:01 --> Output Class Initialized
INFO - 2022-07-17 20:28:01 --> Security Class Initialized
DEBUG - 2022-07-17 20:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 20:28:01 --> Input Class Initialized
INFO - 2022-07-17 20:28:01 --> Language Class Initialized
INFO - 2022-07-17 20:28:01 --> Loader Class Initialized
INFO - 2022-07-17 20:28:01 --> Helper loaded: url_helper
INFO - 2022-07-17 20:28:01 --> Helper loaded: file_helper
INFO - 2022-07-17 20:28:01 --> Database Driver Class Initialized
INFO - 2022-07-17 20:28:01 --> Email Class Initialized
DEBUG - 2022-07-17 20:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 20:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 20:28:01 --> Controller Class Initialized
INFO - 2022-07-17 20:28:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 20:28:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 20:28:01 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 513
ERROR - 2022-07-17 20:28:01 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 521
ERROR - 2022-07-17 20:28:01 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 586
ERROR - 2022-07-17 20:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 586
ERROR - 2022-07-17 20:28:01 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 604
ERROR - 2022-07-17 20:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 604
ERROR - 2022-07-17 20:28:01 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 622
ERROR - 2022-07-17 20:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 622
INFO - 2022-07-17 20:28:01 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 20:28:01 --> Final output sent to browser
DEBUG - 2022-07-17 20:28:01 --> Total execution time: 0.2810
INFO - 2022-07-17 20:30:17 --> Config Class Initialized
INFO - 2022-07-17 20:30:17 --> Hooks Class Initialized
DEBUG - 2022-07-17 20:30:17 --> UTF-8 Support Enabled
INFO - 2022-07-17 20:30:17 --> Utf8 Class Initialized
INFO - 2022-07-17 20:30:17 --> URI Class Initialized
INFO - 2022-07-17 20:30:17 --> Router Class Initialized
INFO - 2022-07-17 20:30:17 --> Output Class Initialized
INFO - 2022-07-17 20:30:17 --> Security Class Initialized
DEBUG - 2022-07-17 20:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 20:30:17 --> Input Class Initialized
INFO - 2022-07-17 20:30:17 --> Language Class Initialized
INFO - 2022-07-17 20:30:17 --> Loader Class Initialized
INFO - 2022-07-17 20:30:17 --> Helper loaded: url_helper
INFO - 2022-07-17 20:30:17 --> Helper loaded: file_helper
INFO - 2022-07-17 20:30:17 --> Database Driver Class Initialized
INFO - 2022-07-17 20:30:17 --> Email Class Initialized
DEBUG - 2022-07-17 20:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 20:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 20:30:17 --> Controller Class Initialized
INFO - 2022-07-17 20:30:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 20:30:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 20:30:17 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 517
ERROR - 2022-07-17 20:30:17 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 525
ERROR - 2022-07-17 20:30:17 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 595
ERROR - 2022-07-17 20:30:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 595
ERROR - 2022-07-17 20:30:17 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 613
ERROR - 2022-07-17 20:30:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 613
ERROR - 2022-07-17 20:30:17 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 631
ERROR - 2022-07-17 20:30:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 631
INFO - 2022-07-17 20:30:17 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 20:30:17 --> Final output sent to browser
DEBUG - 2022-07-17 20:30:17 --> Total execution time: 0.2063
INFO - 2022-07-17 20:30:20 --> Config Class Initialized
INFO - 2022-07-17 20:30:20 --> Hooks Class Initialized
DEBUG - 2022-07-17 20:30:20 --> UTF-8 Support Enabled
INFO - 2022-07-17 20:30:20 --> Utf8 Class Initialized
INFO - 2022-07-17 20:30:20 --> URI Class Initialized
INFO - 2022-07-17 20:30:21 --> Router Class Initialized
INFO - 2022-07-17 20:30:21 --> Output Class Initialized
INFO - 2022-07-17 20:30:21 --> Security Class Initialized
DEBUG - 2022-07-17 20:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 20:30:21 --> Input Class Initialized
INFO - 2022-07-17 20:30:21 --> Language Class Initialized
INFO - 2022-07-17 20:30:21 --> Loader Class Initialized
INFO - 2022-07-17 20:30:21 --> Helper loaded: url_helper
INFO - 2022-07-17 20:30:21 --> Helper loaded: file_helper
INFO - 2022-07-17 20:30:21 --> Database Driver Class Initialized
INFO - 2022-07-17 20:30:21 --> Email Class Initialized
DEBUG - 2022-07-17 20:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 20:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 20:30:21 --> Controller Class Initialized
INFO - 2022-07-17 20:30:21 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 20:30:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 20:30:21 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 517
ERROR - 2022-07-17 20:30:21 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 525
ERROR - 2022-07-17 20:30:21 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 595
ERROR - 2022-07-17 20:30:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 595
ERROR - 2022-07-17 20:30:21 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 613
ERROR - 2022-07-17 20:30:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 613
ERROR - 2022-07-17 20:30:21 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 631
ERROR - 2022-07-17 20:30:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 631
INFO - 2022-07-17 20:30:21 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 20:30:21 --> Final output sent to browser
DEBUG - 2022-07-17 20:30:21 --> Total execution time: 0.1939
INFO - 2022-07-17 20:31:17 --> Config Class Initialized
INFO - 2022-07-17 20:31:17 --> Hooks Class Initialized
DEBUG - 2022-07-17 20:31:17 --> UTF-8 Support Enabled
INFO - 2022-07-17 20:31:17 --> Utf8 Class Initialized
INFO - 2022-07-17 20:31:17 --> URI Class Initialized
INFO - 2022-07-17 20:31:17 --> Router Class Initialized
INFO - 2022-07-17 20:31:17 --> Output Class Initialized
INFO - 2022-07-17 20:31:17 --> Security Class Initialized
DEBUG - 2022-07-17 20:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 20:31:17 --> Input Class Initialized
INFO - 2022-07-17 20:31:17 --> Language Class Initialized
INFO - 2022-07-17 20:31:17 --> Loader Class Initialized
INFO - 2022-07-17 20:31:17 --> Helper loaded: url_helper
INFO - 2022-07-17 20:31:17 --> Helper loaded: file_helper
INFO - 2022-07-17 20:31:17 --> Database Driver Class Initialized
INFO - 2022-07-17 20:31:17 --> Email Class Initialized
DEBUG - 2022-07-17 20:31:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 20:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 20:31:17 --> Controller Class Initialized
INFO - 2022-07-17 20:31:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 20:31:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 20:31:17 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 517
ERROR - 2022-07-17 20:31:17 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 525
ERROR - 2022-07-17 20:31:17 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 595
ERROR - 2022-07-17 20:31:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 595
ERROR - 2022-07-17 20:31:17 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 613
ERROR - 2022-07-17 20:31:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 613
ERROR - 2022-07-17 20:31:17 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 631
ERROR - 2022-07-17 20:31:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 631
INFO - 2022-07-17 20:31:17 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 20:31:17 --> Final output sent to browser
DEBUG - 2022-07-17 20:31:17 --> Total execution time: 0.0802
INFO - 2022-07-17 20:32:14 --> Config Class Initialized
INFO - 2022-07-17 20:32:14 --> Hooks Class Initialized
DEBUG - 2022-07-17 20:32:14 --> UTF-8 Support Enabled
INFO - 2022-07-17 20:32:14 --> Utf8 Class Initialized
INFO - 2022-07-17 20:32:14 --> URI Class Initialized
INFO - 2022-07-17 20:32:14 --> Router Class Initialized
INFO - 2022-07-17 20:32:14 --> Output Class Initialized
INFO - 2022-07-17 20:32:14 --> Security Class Initialized
DEBUG - 2022-07-17 20:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 20:32:14 --> Input Class Initialized
INFO - 2022-07-17 20:32:14 --> Language Class Initialized
INFO - 2022-07-17 20:32:14 --> Loader Class Initialized
INFO - 2022-07-17 20:32:14 --> Helper loaded: url_helper
INFO - 2022-07-17 20:32:14 --> Helper loaded: file_helper
INFO - 2022-07-17 20:32:14 --> Database Driver Class Initialized
INFO - 2022-07-17 20:32:14 --> Email Class Initialized
DEBUG - 2022-07-17 20:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 20:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 20:32:14 --> Controller Class Initialized
INFO - 2022-07-17 20:32:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 20:32:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 20:32:15 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 520
ERROR - 2022-07-17 20:32:15 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 528
ERROR - 2022-07-17 20:32:15 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 598
ERROR - 2022-07-17 20:32:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 598
ERROR - 2022-07-17 20:32:15 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 616
ERROR - 2022-07-17 20:32:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 616
ERROR - 2022-07-17 20:32:15 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 634
ERROR - 2022-07-17 20:32:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 634
INFO - 2022-07-17 20:32:15 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 20:32:15 --> Final output sent to browser
DEBUG - 2022-07-17 20:32:15 --> Total execution time: 0.2385
INFO - 2022-07-17 20:33:04 --> Config Class Initialized
INFO - 2022-07-17 20:33:04 --> Hooks Class Initialized
DEBUG - 2022-07-17 20:33:04 --> UTF-8 Support Enabled
INFO - 2022-07-17 20:33:04 --> Utf8 Class Initialized
INFO - 2022-07-17 20:33:04 --> URI Class Initialized
INFO - 2022-07-17 20:33:04 --> Router Class Initialized
INFO - 2022-07-17 20:33:04 --> Output Class Initialized
INFO - 2022-07-17 20:33:04 --> Security Class Initialized
DEBUG - 2022-07-17 20:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 20:33:04 --> Input Class Initialized
INFO - 2022-07-17 20:33:04 --> Language Class Initialized
INFO - 2022-07-17 20:33:04 --> Loader Class Initialized
INFO - 2022-07-17 20:33:04 --> Helper loaded: url_helper
INFO - 2022-07-17 20:33:04 --> Helper loaded: file_helper
INFO - 2022-07-17 20:33:04 --> Database Driver Class Initialized
INFO - 2022-07-17 20:33:04 --> Email Class Initialized
DEBUG - 2022-07-17 20:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 20:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 20:33:04 --> Controller Class Initialized
INFO - 2022-07-17 20:33:04 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 20:33:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 20:33:05 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 520
ERROR - 2022-07-17 20:33:05 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 528
ERROR - 2022-07-17 20:33:05 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 598
ERROR - 2022-07-17 20:33:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 598
ERROR - 2022-07-17 20:33:05 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 616
ERROR - 2022-07-17 20:33:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 616
ERROR - 2022-07-17 20:33:05 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 634
ERROR - 2022-07-17 20:33:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 634
INFO - 2022-07-17 20:33:05 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 20:33:05 --> Final output sent to browser
DEBUG - 2022-07-17 20:33:05 --> Total execution time: 0.2864
INFO - 2022-07-17 20:34:55 --> Config Class Initialized
INFO - 2022-07-17 20:34:55 --> Hooks Class Initialized
DEBUG - 2022-07-17 20:34:55 --> UTF-8 Support Enabled
INFO - 2022-07-17 20:34:55 --> Utf8 Class Initialized
INFO - 2022-07-17 20:34:55 --> URI Class Initialized
INFO - 2022-07-17 20:34:55 --> Router Class Initialized
INFO - 2022-07-17 20:34:55 --> Output Class Initialized
INFO - 2022-07-17 20:34:55 --> Security Class Initialized
DEBUG - 2022-07-17 20:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-17 20:34:55 --> Input Class Initialized
INFO - 2022-07-17 20:34:55 --> Language Class Initialized
INFO - 2022-07-17 20:34:55 --> Loader Class Initialized
INFO - 2022-07-17 20:34:55 --> Helper loaded: url_helper
INFO - 2022-07-17 20:34:55 --> Helper loaded: file_helper
INFO - 2022-07-17 20:34:55 --> Database Driver Class Initialized
INFO - 2022-07-17 20:34:55 --> Email Class Initialized
DEBUG - 2022-07-17 20:34:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-17 20:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-17 20:34:55 --> Controller Class Initialized
INFO - 2022-07-17 20:34:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-17 20:34:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-17 20:34:55 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 520
ERROR - 2022-07-17 20:34:55 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 528
ERROR - 2022-07-17 20:34:55 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 598
ERROR - 2022-07-17 20:34:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 598
ERROR - 2022-07-17 20:34:55 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 616
ERROR - 2022-07-17 20:34:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 616
ERROR - 2022-07-17 20:34:55 --> Severity: Notice --> Undefined variable: skipped_token C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 634
ERROR - 2022-07-17 20:34:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\qr\application\views\doc_screen\doc_2.php 634
INFO - 2022-07-17 20:34:55 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doc_2.php
INFO - 2022-07-17 20:34:55 --> Final output sent to browser
DEBUG - 2022-07-17 20:34:55 --> Total execution time: 0.2779
