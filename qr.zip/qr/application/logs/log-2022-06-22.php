<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-06-22 04:51:44 --> Config Class Initialized
INFO - 2022-06-22 04:51:44 --> Hooks Class Initialized
DEBUG - 2022-06-22 04:51:44 --> UTF-8 Support Enabled
INFO - 2022-06-22 04:51:44 --> Utf8 Class Initialized
INFO - 2022-06-22 04:51:44 --> URI Class Initialized
INFO - 2022-06-22 04:51:44 --> Router Class Initialized
INFO - 2022-06-22 04:51:44 --> Output Class Initialized
INFO - 2022-06-22 04:51:44 --> Security Class Initialized
DEBUG - 2022-06-22 04:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 04:51:44 --> Input Class Initialized
INFO - 2022-06-22 04:51:44 --> Language Class Initialized
INFO - 2022-06-22 04:51:44 --> Loader Class Initialized
INFO - 2022-06-22 04:51:44 --> Helper loaded: url_helper
INFO - 2022-06-22 04:51:44 --> Helper loaded: file_helper
INFO - 2022-06-22 04:51:44 --> Database Driver Class Initialized
INFO - 2022-06-22 04:51:44 --> Email Class Initialized
DEBUG - 2022-06-22 04:51:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 04:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 04:51:44 --> Controller Class Initialized
INFO - 2022-06-22 04:51:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 04:51:44 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 04:51:45 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-22 04:51:45 --> Final output sent to browser
DEBUG - 2022-06-22 04:51:45 --> Total execution time: 1.0705
INFO - 2022-06-22 04:52:08 --> Config Class Initialized
INFO - 2022-06-22 04:52:08 --> Hooks Class Initialized
DEBUG - 2022-06-22 04:52:08 --> UTF-8 Support Enabled
INFO - 2022-06-22 04:52:08 --> Utf8 Class Initialized
INFO - 2022-06-22 04:52:08 --> URI Class Initialized
INFO - 2022-06-22 04:52:08 --> Router Class Initialized
INFO - 2022-06-22 04:52:08 --> Output Class Initialized
INFO - 2022-06-22 04:52:08 --> Security Class Initialized
DEBUG - 2022-06-22 04:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 04:52:08 --> Input Class Initialized
INFO - 2022-06-22 04:52:08 --> Language Class Initialized
INFO - 2022-06-22 04:52:08 --> Loader Class Initialized
INFO - 2022-06-22 04:52:08 --> Helper loaded: url_helper
INFO - 2022-06-22 04:52:08 --> Helper loaded: file_helper
INFO - 2022-06-22 04:52:08 --> Database Driver Class Initialized
INFO - 2022-06-22 04:52:08 --> Email Class Initialized
DEBUG - 2022-06-22 04:52:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 04:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 04:52:08 --> Controller Class Initialized
INFO - 2022-06-22 04:52:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 04:52:08 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 04:52:08 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-22 04:52:08 --> Final output sent to browser
DEBUG - 2022-06-22 04:52:08 --> Total execution time: 0.1799
INFO - 2022-06-22 04:53:22 --> Config Class Initialized
INFO - 2022-06-22 04:53:22 --> Hooks Class Initialized
DEBUG - 2022-06-22 04:53:22 --> UTF-8 Support Enabled
INFO - 2022-06-22 04:53:22 --> Utf8 Class Initialized
INFO - 2022-06-22 04:53:22 --> URI Class Initialized
INFO - 2022-06-22 04:53:22 --> Router Class Initialized
INFO - 2022-06-22 04:53:22 --> Output Class Initialized
INFO - 2022-06-22 04:53:22 --> Security Class Initialized
DEBUG - 2022-06-22 04:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 04:53:22 --> Input Class Initialized
INFO - 2022-06-22 04:53:22 --> Language Class Initialized
INFO - 2022-06-22 04:53:22 --> Loader Class Initialized
INFO - 2022-06-22 04:53:22 --> Helper loaded: url_helper
INFO - 2022-06-22 04:53:22 --> Helper loaded: file_helper
INFO - 2022-06-22 04:53:22 --> Database Driver Class Initialized
INFO - 2022-06-22 04:53:22 --> Email Class Initialized
DEBUG - 2022-06-22 04:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 04:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 04:53:22 --> Controller Class Initialized
INFO - 2022-06-22 04:53:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 04:53:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 04:53:22 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-22 04:53:22 --> Final output sent to browser
DEBUG - 2022-06-22 04:53:22 --> Total execution time: 0.0176
INFO - 2022-06-22 04:53:26 --> Config Class Initialized
INFO - 2022-06-22 04:53:26 --> Hooks Class Initialized
DEBUG - 2022-06-22 04:53:26 --> UTF-8 Support Enabled
INFO - 2022-06-22 04:53:26 --> Utf8 Class Initialized
INFO - 2022-06-22 04:53:26 --> URI Class Initialized
INFO - 2022-06-22 04:53:26 --> Router Class Initialized
INFO - 2022-06-22 04:53:26 --> Output Class Initialized
INFO - 2022-06-22 04:53:26 --> Security Class Initialized
DEBUG - 2022-06-22 04:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 04:53:26 --> Input Class Initialized
INFO - 2022-06-22 04:53:26 --> Language Class Initialized
INFO - 2022-06-22 04:53:26 --> Loader Class Initialized
INFO - 2022-06-22 04:53:26 --> Helper loaded: url_helper
INFO - 2022-06-22 04:53:26 --> Helper loaded: file_helper
INFO - 2022-06-22 04:53:26 --> Database Driver Class Initialized
INFO - 2022-06-22 04:53:26 --> Email Class Initialized
DEBUG - 2022-06-22 04:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 04:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 04:53:26 --> Controller Class Initialized
INFO - 2022-06-22 04:53:26 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 04:53:26 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 04:53:26 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-22 04:53:26 --> Final output sent to browser
DEBUG - 2022-06-22 04:53:26 --> Total execution time: 0.0314
INFO - 2022-06-22 04:53:28 --> Config Class Initialized
INFO - 2022-06-22 04:53:28 --> Hooks Class Initialized
DEBUG - 2022-06-22 04:53:28 --> UTF-8 Support Enabled
INFO - 2022-06-22 04:53:28 --> Utf8 Class Initialized
INFO - 2022-06-22 04:53:28 --> URI Class Initialized
INFO - 2022-06-22 04:53:28 --> Router Class Initialized
INFO - 2022-06-22 04:53:28 --> Output Class Initialized
INFO - 2022-06-22 04:53:28 --> Security Class Initialized
DEBUG - 2022-06-22 04:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 04:53:28 --> Input Class Initialized
INFO - 2022-06-22 04:53:28 --> Language Class Initialized
INFO - 2022-06-22 04:53:28 --> Loader Class Initialized
INFO - 2022-06-22 04:53:28 --> Helper loaded: url_helper
INFO - 2022-06-22 04:53:28 --> Helper loaded: file_helper
INFO - 2022-06-22 04:53:28 --> Database Driver Class Initialized
INFO - 2022-06-22 04:53:28 --> Email Class Initialized
DEBUG - 2022-06-22 04:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 04:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 04:53:28 --> Controller Class Initialized
INFO - 2022-06-22 04:53:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 04:53:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 04:53:28 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-22 04:53:28 --> Final output sent to browser
DEBUG - 2022-06-22 04:53:28 --> Total execution time: 0.0452
INFO - 2022-06-22 04:54:08 --> Config Class Initialized
INFO - 2022-06-22 04:54:08 --> Hooks Class Initialized
DEBUG - 2022-06-22 04:54:08 --> UTF-8 Support Enabled
INFO - 2022-06-22 04:54:08 --> Utf8 Class Initialized
INFO - 2022-06-22 04:54:08 --> URI Class Initialized
INFO - 2022-06-22 04:54:08 --> Router Class Initialized
INFO - 2022-06-22 04:54:08 --> Output Class Initialized
INFO - 2022-06-22 04:54:08 --> Security Class Initialized
DEBUG - 2022-06-22 04:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 04:54:08 --> Input Class Initialized
INFO - 2022-06-22 04:54:08 --> Language Class Initialized
INFO - 2022-06-22 04:54:08 --> Loader Class Initialized
INFO - 2022-06-22 04:54:08 --> Helper loaded: url_helper
INFO - 2022-06-22 04:54:08 --> Helper loaded: file_helper
INFO - 2022-06-22 04:54:08 --> Database Driver Class Initialized
INFO - 2022-06-22 04:54:08 --> Email Class Initialized
DEBUG - 2022-06-22 04:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 04:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 04:54:08 --> Controller Class Initialized
INFO - 2022-06-22 04:54:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 04:54:08 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 04:54:09 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-22 04:54:09 --> Final output sent to browser
DEBUG - 2022-06-22 04:54:09 --> Total execution time: 0.5040
INFO - 2022-06-22 04:54:12 --> Config Class Initialized
INFO - 2022-06-22 04:54:12 --> Hooks Class Initialized
DEBUG - 2022-06-22 04:54:12 --> UTF-8 Support Enabled
INFO - 2022-06-22 04:54:12 --> Utf8 Class Initialized
INFO - 2022-06-22 04:54:12 --> URI Class Initialized
INFO - 2022-06-22 04:54:12 --> Router Class Initialized
INFO - 2022-06-22 04:54:12 --> Output Class Initialized
INFO - 2022-06-22 04:54:12 --> Security Class Initialized
DEBUG - 2022-06-22 04:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 04:54:12 --> Input Class Initialized
INFO - 2022-06-22 04:54:12 --> Language Class Initialized
INFO - 2022-06-22 04:54:12 --> Loader Class Initialized
INFO - 2022-06-22 04:54:12 --> Helper loaded: url_helper
INFO - 2022-06-22 04:54:12 --> Helper loaded: file_helper
INFO - 2022-06-22 04:54:12 --> Database Driver Class Initialized
INFO - 2022-06-22 04:54:12 --> Email Class Initialized
DEBUG - 2022-06-22 04:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 04:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 04:54:12 --> Controller Class Initialized
INFO - 2022-06-22 04:54:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 04:54:12 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 04:54:12 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-22 04:54:12 --> Final output sent to browser
DEBUG - 2022-06-22 04:54:12 --> Total execution time: 0.0204
INFO - 2022-06-22 04:54:13 --> Config Class Initialized
INFO - 2022-06-22 04:54:13 --> Hooks Class Initialized
DEBUG - 2022-06-22 04:54:13 --> UTF-8 Support Enabled
INFO - 2022-06-22 04:54:13 --> Utf8 Class Initialized
INFO - 2022-06-22 04:54:13 --> URI Class Initialized
INFO - 2022-06-22 04:54:13 --> Router Class Initialized
INFO - 2022-06-22 04:54:13 --> Output Class Initialized
INFO - 2022-06-22 04:54:13 --> Security Class Initialized
DEBUG - 2022-06-22 04:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 04:54:13 --> Input Class Initialized
INFO - 2022-06-22 04:54:13 --> Language Class Initialized
INFO - 2022-06-22 04:54:13 --> Loader Class Initialized
INFO - 2022-06-22 04:54:13 --> Helper loaded: url_helper
INFO - 2022-06-22 04:54:13 --> Helper loaded: file_helper
INFO - 2022-06-22 04:54:13 --> Database Driver Class Initialized
INFO - 2022-06-22 04:54:13 --> Email Class Initialized
DEBUG - 2022-06-22 04:54:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 04:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 04:54:13 --> Controller Class Initialized
INFO - 2022-06-22 04:54:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 04:54:13 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 04:54:13 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-22 04:54:13 --> Final output sent to browser
DEBUG - 2022-06-22 04:54:13 --> Total execution time: 0.1298
INFO - 2022-06-22 04:54:14 --> Config Class Initialized
INFO - 2022-06-22 04:54:14 --> Hooks Class Initialized
DEBUG - 2022-06-22 04:54:14 --> UTF-8 Support Enabled
INFO - 2022-06-22 04:54:14 --> Utf8 Class Initialized
INFO - 2022-06-22 04:54:14 --> URI Class Initialized
INFO - 2022-06-22 04:54:14 --> Router Class Initialized
INFO - 2022-06-22 04:54:14 --> Output Class Initialized
INFO - 2022-06-22 04:54:14 --> Security Class Initialized
DEBUG - 2022-06-22 04:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 04:54:14 --> Input Class Initialized
INFO - 2022-06-22 04:54:14 --> Language Class Initialized
INFO - 2022-06-22 04:54:14 --> Loader Class Initialized
INFO - 2022-06-22 04:54:14 --> Helper loaded: url_helper
INFO - 2022-06-22 04:54:14 --> Helper loaded: file_helper
INFO - 2022-06-22 04:54:14 --> Database Driver Class Initialized
INFO - 2022-06-22 04:54:14 --> Email Class Initialized
DEBUG - 2022-06-22 04:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 04:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 04:54:14 --> Controller Class Initialized
INFO - 2022-06-22 04:54:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 04:54:14 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 04:54:14 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-22 04:54:14 --> Final output sent to browser
DEBUG - 2022-06-22 04:54:14 --> Total execution time: 0.1613
INFO - 2022-06-22 04:54:15 --> Config Class Initialized
INFO - 2022-06-22 04:54:15 --> Hooks Class Initialized
DEBUG - 2022-06-22 04:54:15 --> UTF-8 Support Enabled
INFO - 2022-06-22 04:54:15 --> Utf8 Class Initialized
INFO - 2022-06-22 04:54:15 --> URI Class Initialized
INFO - 2022-06-22 04:54:15 --> Router Class Initialized
INFO - 2022-06-22 04:54:15 --> Output Class Initialized
INFO - 2022-06-22 04:54:15 --> Security Class Initialized
DEBUG - 2022-06-22 04:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 04:54:15 --> Input Class Initialized
INFO - 2022-06-22 04:54:15 --> Language Class Initialized
INFO - 2022-06-22 04:54:15 --> Loader Class Initialized
INFO - 2022-06-22 04:54:15 --> Helper loaded: url_helper
INFO - 2022-06-22 04:54:15 --> Helper loaded: file_helper
INFO - 2022-06-22 04:54:15 --> Database Driver Class Initialized
INFO - 2022-06-22 04:54:15 --> Email Class Initialized
DEBUG - 2022-06-22 04:54:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 04:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 04:54:15 --> Controller Class Initialized
INFO - 2022-06-22 04:54:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 04:54:15 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 04:54:15 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-22 04:54:15 --> Final output sent to browser
DEBUG - 2022-06-22 04:54:15 --> Total execution time: 0.0772
INFO - 2022-06-22 04:54:16 --> Config Class Initialized
INFO - 2022-06-22 04:54:16 --> Hooks Class Initialized
DEBUG - 2022-06-22 04:54:16 --> UTF-8 Support Enabled
INFO - 2022-06-22 04:54:16 --> Utf8 Class Initialized
INFO - 2022-06-22 04:54:16 --> URI Class Initialized
INFO - 2022-06-22 04:54:16 --> Router Class Initialized
INFO - 2022-06-22 04:54:16 --> Output Class Initialized
INFO - 2022-06-22 04:54:16 --> Security Class Initialized
DEBUG - 2022-06-22 04:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 04:54:16 --> Input Class Initialized
INFO - 2022-06-22 04:54:16 --> Language Class Initialized
INFO - 2022-06-22 04:54:16 --> Loader Class Initialized
INFO - 2022-06-22 04:54:16 --> Helper loaded: url_helper
INFO - 2022-06-22 04:54:16 --> Helper loaded: file_helper
INFO - 2022-06-22 04:54:16 --> Database Driver Class Initialized
INFO - 2022-06-22 04:54:16 --> Email Class Initialized
DEBUG - 2022-06-22 04:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 04:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 04:54:16 --> Controller Class Initialized
INFO - 2022-06-22 04:54:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 04:54:16 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 04:54:16 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-22 04:54:16 --> Final output sent to browser
DEBUG - 2022-06-22 04:54:16 --> Total execution time: 0.0564
INFO - 2022-06-22 04:54:16 --> Config Class Initialized
INFO - 2022-06-22 04:54:16 --> Hooks Class Initialized
DEBUG - 2022-06-22 04:54:16 --> UTF-8 Support Enabled
INFO - 2022-06-22 04:54:16 --> Utf8 Class Initialized
INFO - 2022-06-22 04:54:16 --> URI Class Initialized
INFO - 2022-06-22 04:54:16 --> Router Class Initialized
INFO - 2022-06-22 04:54:16 --> Output Class Initialized
INFO - 2022-06-22 04:54:16 --> Security Class Initialized
DEBUG - 2022-06-22 04:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 04:54:16 --> Input Class Initialized
INFO - 2022-06-22 04:54:16 --> Language Class Initialized
INFO - 2022-06-22 04:54:16 --> Loader Class Initialized
INFO - 2022-06-22 04:54:16 --> Helper loaded: url_helper
INFO - 2022-06-22 04:54:16 --> Helper loaded: file_helper
INFO - 2022-06-22 04:54:16 --> Database Driver Class Initialized
INFO - 2022-06-22 04:54:16 --> Email Class Initialized
DEBUG - 2022-06-22 04:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 04:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 04:54:16 --> Controller Class Initialized
INFO - 2022-06-22 04:54:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 04:54:16 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 04:54:16 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-22 04:54:16 --> Final output sent to browser
DEBUG - 2022-06-22 04:54:16 --> Total execution time: 0.0271
INFO - 2022-06-22 04:54:17 --> Config Class Initialized
INFO - 2022-06-22 04:54:17 --> Hooks Class Initialized
DEBUG - 2022-06-22 04:54:17 --> UTF-8 Support Enabled
INFO - 2022-06-22 04:54:17 --> Utf8 Class Initialized
INFO - 2022-06-22 04:54:17 --> URI Class Initialized
INFO - 2022-06-22 04:54:17 --> Router Class Initialized
INFO - 2022-06-22 04:54:17 --> Output Class Initialized
INFO - 2022-06-22 04:54:17 --> Security Class Initialized
DEBUG - 2022-06-22 04:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 04:54:17 --> Input Class Initialized
INFO - 2022-06-22 04:54:17 --> Language Class Initialized
INFO - 2022-06-22 04:54:17 --> Loader Class Initialized
INFO - 2022-06-22 04:54:17 --> Helper loaded: url_helper
INFO - 2022-06-22 04:54:17 --> Helper loaded: file_helper
INFO - 2022-06-22 04:54:17 --> Database Driver Class Initialized
INFO - 2022-06-22 04:54:17 --> Email Class Initialized
DEBUG - 2022-06-22 04:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 04:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 04:54:17 --> Controller Class Initialized
INFO - 2022-06-22 04:54:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 04:54:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 04:54:17 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-22 04:54:17 --> Final output sent to browser
DEBUG - 2022-06-22 04:54:17 --> Total execution time: 0.1263
INFO - 2022-06-22 04:54:51 --> Config Class Initialized
INFO - 2022-06-22 04:54:51 --> Hooks Class Initialized
DEBUG - 2022-06-22 04:54:51 --> UTF-8 Support Enabled
INFO - 2022-06-22 04:54:51 --> Utf8 Class Initialized
INFO - 2022-06-22 04:54:51 --> URI Class Initialized
INFO - 2022-06-22 04:54:51 --> Router Class Initialized
INFO - 2022-06-22 04:54:51 --> Output Class Initialized
INFO - 2022-06-22 04:54:51 --> Security Class Initialized
DEBUG - 2022-06-22 04:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 04:54:51 --> Input Class Initialized
INFO - 2022-06-22 04:54:51 --> Language Class Initialized
INFO - 2022-06-22 04:54:51 --> Loader Class Initialized
INFO - 2022-06-22 04:54:51 --> Helper loaded: url_helper
INFO - 2022-06-22 04:54:51 --> Helper loaded: file_helper
INFO - 2022-06-22 04:54:51 --> Database Driver Class Initialized
INFO - 2022-06-22 04:54:51 --> Email Class Initialized
DEBUG - 2022-06-22 04:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 04:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 04:54:51 --> Controller Class Initialized
INFO - 2022-06-22 04:54:51 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 04:54:51 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 04:54:51 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-22 04:54:51 --> Final output sent to browser
DEBUG - 2022-06-22 04:54:51 --> Total execution time: 0.0548
INFO - 2022-06-22 04:54:54 --> Config Class Initialized
INFO - 2022-06-22 04:54:54 --> Hooks Class Initialized
DEBUG - 2022-06-22 04:54:54 --> UTF-8 Support Enabled
INFO - 2022-06-22 04:54:54 --> Utf8 Class Initialized
INFO - 2022-06-22 04:54:54 --> URI Class Initialized
INFO - 2022-06-22 04:54:54 --> Router Class Initialized
INFO - 2022-06-22 04:54:54 --> Output Class Initialized
INFO - 2022-06-22 04:54:54 --> Security Class Initialized
DEBUG - 2022-06-22 04:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 04:54:54 --> Input Class Initialized
INFO - 2022-06-22 04:54:54 --> Language Class Initialized
INFO - 2022-06-22 04:54:54 --> Loader Class Initialized
INFO - 2022-06-22 04:54:54 --> Helper loaded: url_helper
INFO - 2022-06-22 04:54:54 --> Helper loaded: file_helper
INFO - 2022-06-22 04:54:54 --> Database Driver Class Initialized
INFO - 2022-06-22 04:54:54 --> Email Class Initialized
DEBUG - 2022-06-22 04:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 04:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 04:54:54 --> Controller Class Initialized
INFO - 2022-06-22 04:54:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 04:54:54 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 04:54:54 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-22 04:54:54 --> Final output sent to browser
DEBUG - 2022-06-22 04:54:54 --> Total execution time: 0.0746
INFO - 2022-06-22 04:54:55 --> Config Class Initialized
INFO - 2022-06-22 04:54:55 --> Hooks Class Initialized
DEBUG - 2022-06-22 04:54:55 --> UTF-8 Support Enabled
INFO - 2022-06-22 04:54:55 --> Utf8 Class Initialized
INFO - 2022-06-22 04:54:55 --> URI Class Initialized
INFO - 2022-06-22 04:54:55 --> Router Class Initialized
INFO - 2022-06-22 04:54:55 --> Output Class Initialized
INFO - 2022-06-22 04:54:55 --> Security Class Initialized
DEBUG - 2022-06-22 04:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 04:54:55 --> Input Class Initialized
INFO - 2022-06-22 04:54:55 --> Language Class Initialized
INFO - 2022-06-22 04:54:55 --> Loader Class Initialized
INFO - 2022-06-22 04:54:55 --> Helper loaded: url_helper
INFO - 2022-06-22 04:54:55 --> Helper loaded: file_helper
INFO - 2022-06-22 04:54:55 --> Database Driver Class Initialized
INFO - 2022-06-22 04:54:55 --> Email Class Initialized
DEBUG - 2022-06-22 04:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 04:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 04:54:55 --> Controller Class Initialized
INFO - 2022-06-22 04:54:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 04:54:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 04:54:55 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-22 04:54:55 --> Final output sent to browser
DEBUG - 2022-06-22 04:54:55 --> Total execution time: 0.0413
INFO - 2022-06-22 04:54:57 --> Config Class Initialized
INFO - 2022-06-22 04:54:57 --> Hooks Class Initialized
DEBUG - 2022-06-22 04:54:57 --> UTF-8 Support Enabled
INFO - 2022-06-22 04:54:57 --> Utf8 Class Initialized
INFO - 2022-06-22 04:54:57 --> URI Class Initialized
INFO - 2022-06-22 04:54:57 --> Router Class Initialized
INFO - 2022-06-22 04:54:57 --> Output Class Initialized
INFO - 2022-06-22 04:54:57 --> Security Class Initialized
DEBUG - 2022-06-22 04:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 04:54:57 --> Input Class Initialized
INFO - 2022-06-22 04:54:57 --> Language Class Initialized
INFO - 2022-06-22 04:54:57 --> Loader Class Initialized
INFO - 2022-06-22 04:54:57 --> Helper loaded: url_helper
INFO - 2022-06-22 04:54:57 --> Helper loaded: file_helper
INFO - 2022-06-22 04:54:57 --> Database Driver Class Initialized
INFO - 2022-06-22 04:54:57 --> Email Class Initialized
DEBUG - 2022-06-22 04:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 04:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 04:54:57 --> Controller Class Initialized
INFO - 2022-06-22 04:54:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 04:54:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 04:54:57 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-22 04:54:57 --> Final output sent to browser
DEBUG - 2022-06-22 04:54:57 --> Total execution time: 0.0191
INFO - 2022-06-22 04:55:05 --> Config Class Initialized
INFO - 2022-06-22 04:55:05 --> Hooks Class Initialized
DEBUG - 2022-06-22 04:55:05 --> UTF-8 Support Enabled
INFO - 2022-06-22 04:55:05 --> Utf8 Class Initialized
INFO - 2022-06-22 04:55:05 --> URI Class Initialized
INFO - 2022-06-22 04:55:05 --> Router Class Initialized
INFO - 2022-06-22 04:55:05 --> Output Class Initialized
INFO - 2022-06-22 04:55:05 --> Security Class Initialized
DEBUG - 2022-06-22 04:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 04:55:05 --> Input Class Initialized
INFO - 2022-06-22 04:55:05 --> Language Class Initialized
INFO - 2022-06-22 04:55:05 --> Loader Class Initialized
INFO - 2022-06-22 04:55:05 --> Helper loaded: url_helper
INFO - 2022-06-22 04:55:05 --> Helper loaded: file_helper
INFO - 2022-06-22 04:55:05 --> Database Driver Class Initialized
INFO - 2022-06-22 04:55:06 --> Email Class Initialized
DEBUG - 2022-06-22 04:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 04:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 04:55:06 --> Controller Class Initialized
INFO - 2022-06-22 04:55:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 04:55:06 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 04:55:06 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-22 04:55:06 --> Final output sent to browser
DEBUG - 2022-06-22 04:55:06 --> Total execution time: 0.1921
INFO - 2022-06-22 04:55:07 --> Config Class Initialized
INFO - 2022-06-22 04:55:07 --> Hooks Class Initialized
DEBUG - 2022-06-22 04:55:07 --> UTF-8 Support Enabled
INFO - 2022-06-22 04:55:07 --> Utf8 Class Initialized
INFO - 2022-06-22 04:55:07 --> URI Class Initialized
INFO - 2022-06-22 04:55:07 --> Router Class Initialized
INFO - 2022-06-22 04:55:07 --> Output Class Initialized
INFO - 2022-06-22 04:55:07 --> Security Class Initialized
DEBUG - 2022-06-22 04:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 04:55:07 --> Input Class Initialized
INFO - 2022-06-22 04:55:07 --> Language Class Initialized
INFO - 2022-06-22 04:55:07 --> Loader Class Initialized
INFO - 2022-06-22 04:55:07 --> Helper loaded: url_helper
INFO - 2022-06-22 04:55:07 --> Helper loaded: file_helper
INFO - 2022-06-22 04:55:07 --> Database Driver Class Initialized
INFO - 2022-06-22 04:55:07 --> Email Class Initialized
DEBUG - 2022-06-22 04:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 04:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 04:55:07 --> Controller Class Initialized
INFO - 2022-06-22 04:55:07 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 04:55:07 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 04:55:07 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-22 04:55:07 --> Final output sent to browser
DEBUG - 2022-06-22 04:55:07 --> Total execution time: 0.0725
INFO - 2022-06-22 04:55:17 --> Config Class Initialized
INFO - 2022-06-22 04:55:17 --> Hooks Class Initialized
DEBUG - 2022-06-22 04:55:17 --> UTF-8 Support Enabled
INFO - 2022-06-22 04:55:17 --> Utf8 Class Initialized
INFO - 2022-06-22 04:55:17 --> URI Class Initialized
INFO - 2022-06-22 04:55:17 --> Router Class Initialized
INFO - 2022-06-22 04:55:17 --> Output Class Initialized
INFO - 2022-06-22 04:55:17 --> Security Class Initialized
DEBUG - 2022-06-22 04:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 04:55:17 --> Input Class Initialized
INFO - 2022-06-22 04:55:17 --> Language Class Initialized
INFO - 2022-06-22 04:55:17 --> Loader Class Initialized
INFO - 2022-06-22 04:55:17 --> Helper loaded: url_helper
INFO - 2022-06-22 04:55:17 --> Helper loaded: file_helper
INFO - 2022-06-22 04:55:17 --> Database Driver Class Initialized
INFO - 2022-06-22 04:55:17 --> Email Class Initialized
DEBUG - 2022-06-22 04:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 04:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 04:55:17 --> Controller Class Initialized
INFO - 2022-06-22 04:55:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 04:55:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 04:55:17 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-22 04:55:17 --> Final output sent to browser
DEBUG - 2022-06-22 04:55:17 --> Total execution time: 0.1526
INFO - 2022-06-22 04:55:18 --> Config Class Initialized
INFO - 2022-06-22 04:55:18 --> Hooks Class Initialized
DEBUG - 2022-06-22 04:55:18 --> UTF-8 Support Enabled
INFO - 2022-06-22 04:55:18 --> Utf8 Class Initialized
INFO - 2022-06-22 04:55:18 --> URI Class Initialized
INFO - 2022-06-22 04:55:18 --> Router Class Initialized
INFO - 2022-06-22 04:55:18 --> Output Class Initialized
INFO - 2022-06-22 04:55:18 --> Security Class Initialized
DEBUG - 2022-06-22 04:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 04:55:18 --> Input Class Initialized
INFO - 2022-06-22 04:55:18 --> Language Class Initialized
INFO - 2022-06-22 04:55:18 --> Loader Class Initialized
INFO - 2022-06-22 04:55:18 --> Helper loaded: url_helper
INFO - 2022-06-22 04:55:18 --> Helper loaded: file_helper
INFO - 2022-06-22 04:55:18 --> Database Driver Class Initialized
INFO - 2022-06-22 04:55:19 --> Email Class Initialized
DEBUG - 2022-06-22 04:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 04:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 04:55:19 --> Controller Class Initialized
INFO - 2022-06-22 04:55:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 04:55:19 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 04:55:19 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-22 04:55:19 --> Final output sent to browser
DEBUG - 2022-06-22 04:55:19 --> Total execution time: 0.0638
INFO - 2022-06-22 04:55:21 --> Config Class Initialized
INFO - 2022-06-22 04:55:21 --> Hooks Class Initialized
DEBUG - 2022-06-22 04:55:21 --> UTF-8 Support Enabled
INFO - 2022-06-22 04:55:21 --> Utf8 Class Initialized
INFO - 2022-06-22 04:55:21 --> URI Class Initialized
INFO - 2022-06-22 04:55:21 --> Router Class Initialized
INFO - 2022-06-22 04:55:21 --> Output Class Initialized
INFO - 2022-06-22 04:55:21 --> Security Class Initialized
DEBUG - 2022-06-22 04:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 04:55:21 --> Input Class Initialized
INFO - 2022-06-22 04:55:21 --> Language Class Initialized
INFO - 2022-06-22 04:55:21 --> Loader Class Initialized
INFO - 2022-06-22 04:55:21 --> Helper loaded: url_helper
INFO - 2022-06-22 04:55:21 --> Helper loaded: file_helper
INFO - 2022-06-22 04:55:21 --> Database Driver Class Initialized
INFO - 2022-06-22 04:55:21 --> Email Class Initialized
DEBUG - 2022-06-22 04:55:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 04:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 04:55:21 --> Controller Class Initialized
INFO - 2022-06-22 04:55:21 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 04:55:21 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 04:55:21 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-22 04:55:21 --> Final output sent to browser
DEBUG - 2022-06-22 04:55:21 --> Total execution time: 0.0866
INFO - 2022-06-22 04:56:35 --> Config Class Initialized
INFO - 2022-06-22 04:56:35 --> Hooks Class Initialized
DEBUG - 2022-06-22 04:56:35 --> UTF-8 Support Enabled
INFO - 2022-06-22 04:56:35 --> Utf8 Class Initialized
INFO - 2022-06-22 04:56:35 --> URI Class Initialized
INFO - 2022-06-22 04:56:35 --> Router Class Initialized
INFO - 2022-06-22 04:56:35 --> Output Class Initialized
INFO - 2022-06-22 04:56:35 --> Security Class Initialized
DEBUG - 2022-06-22 04:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 04:56:35 --> Input Class Initialized
INFO - 2022-06-22 04:56:35 --> Language Class Initialized
INFO - 2022-06-22 04:56:35 --> Loader Class Initialized
INFO - 2022-06-22 04:56:35 --> Helper loaded: url_helper
INFO - 2022-06-22 04:56:35 --> Helper loaded: file_helper
INFO - 2022-06-22 04:56:35 --> Database Driver Class Initialized
INFO - 2022-06-22 04:56:35 --> Email Class Initialized
DEBUG - 2022-06-22 04:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 04:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 04:56:35 --> Controller Class Initialized
INFO - 2022-06-22 04:56:35 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 04:56:35 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 04:56:35 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-22 04:56:35 --> Final output sent to browser
DEBUG - 2022-06-22 04:56:35 --> Total execution time: 0.1150
INFO - 2022-06-22 04:56:37 --> Config Class Initialized
INFO - 2022-06-22 04:56:37 --> Hooks Class Initialized
DEBUG - 2022-06-22 04:56:37 --> UTF-8 Support Enabled
INFO - 2022-06-22 04:56:37 --> Utf8 Class Initialized
INFO - 2022-06-22 04:56:37 --> URI Class Initialized
INFO - 2022-06-22 04:56:37 --> Router Class Initialized
INFO - 2022-06-22 04:56:37 --> Output Class Initialized
INFO - 2022-06-22 04:56:37 --> Security Class Initialized
DEBUG - 2022-06-22 04:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 04:56:37 --> Input Class Initialized
INFO - 2022-06-22 04:56:37 --> Language Class Initialized
INFO - 2022-06-22 04:56:37 --> Loader Class Initialized
INFO - 2022-06-22 04:56:37 --> Helper loaded: url_helper
INFO - 2022-06-22 04:56:37 --> Helper loaded: file_helper
INFO - 2022-06-22 04:56:37 --> Database Driver Class Initialized
INFO - 2022-06-22 04:56:37 --> Email Class Initialized
DEBUG - 2022-06-22 04:56:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 04:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 04:56:37 --> Controller Class Initialized
INFO - 2022-06-22 04:56:37 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 04:56:37 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 04:56:37 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-22 04:56:37 --> Final output sent to browser
DEBUG - 2022-06-22 04:56:37 --> Total execution time: 0.0158
INFO - 2022-06-22 04:56:38 --> Config Class Initialized
INFO - 2022-06-22 04:56:38 --> Hooks Class Initialized
DEBUG - 2022-06-22 04:56:38 --> UTF-8 Support Enabled
INFO - 2022-06-22 04:56:38 --> Utf8 Class Initialized
INFO - 2022-06-22 04:56:38 --> URI Class Initialized
INFO - 2022-06-22 04:56:38 --> Router Class Initialized
INFO - 2022-06-22 04:56:38 --> Output Class Initialized
INFO - 2022-06-22 04:56:38 --> Security Class Initialized
DEBUG - 2022-06-22 04:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 04:56:38 --> Input Class Initialized
INFO - 2022-06-22 04:56:38 --> Language Class Initialized
INFO - 2022-06-22 04:56:38 --> Loader Class Initialized
INFO - 2022-06-22 04:56:38 --> Helper loaded: url_helper
INFO - 2022-06-22 04:56:38 --> Helper loaded: file_helper
INFO - 2022-06-22 04:56:38 --> Database Driver Class Initialized
INFO - 2022-06-22 04:56:38 --> Email Class Initialized
DEBUG - 2022-06-22 04:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 04:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 04:56:38 --> Controller Class Initialized
INFO - 2022-06-22 04:56:38 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 04:56:38 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 04:56:38 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-22 04:56:38 --> Final output sent to browser
DEBUG - 2022-06-22 04:56:38 --> Total execution time: 0.0172
INFO - 2022-06-22 04:57:06 --> Config Class Initialized
INFO - 2022-06-22 04:57:06 --> Hooks Class Initialized
DEBUG - 2022-06-22 04:57:06 --> UTF-8 Support Enabled
INFO - 2022-06-22 04:57:06 --> Utf8 Class Initialized
INFO - 2022-06-22 04:57:06 --> URI Class Initialized
INFO - 2022-06-22 04:57:06 --> Router Class Initialized
INFO - 2022-06-22 04:57:06 --> Output Class Initialized
INFO - 2022-06-22 04:57:06 --> Security Class Initialized
DEBUG - 2022-06-22 04:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 04:57:06 --> Input Class Initialized
INFO - 2022-06-22 04:57:06 --> Language Class Initialized
INFO - 2022-06-22 04:57:06 --> Loader Class Initialized
INFO - 2022-06-22 04:57:06 --> Helper loaded: url_helper
INFO - 2022-06-22 04:57:06 --> Helper loaded: file_helper
INFO - 2022-06-22 04:57:06 --> Database Driver Class Initialized
INFO - 2022-06-22 04:57:06 --> Email Class Initialized
DEBUG - 2022-06-22 04:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 04:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 04:57:06 --> Controller Class Initialized
INFO - 2022-06-22 04:57:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 04:57:06 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 04:57:06 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-22 04:57:06 --> Final output sent to browser
DEBUG - 2022-06-22 04:57:06 --> Total execution time: 0.0566
INFO - 2022-06-22 04:57:25 --> Config Class Initialized
INFO - 2022-06-22 04:57:25 --> Hooks Class Initialized
INFO - 2022-06-22 04:57:25 --> Config Class Initialized
INFO - 2022-06-22 04:57:25 --> Hooks Class Initialized
DEBUG - 2022-06-22 04:57:25 --> UTF-8 Support Enabled
INFO - 2022-06-22 04:57:25 --> Utf8 Class Initialized
DEBUG - 2022-06-22 04:57:25 --> UTF-8 Support Enabled
INFO - 2022-06-22 04:57:25 --> URI Class Initialized
INFO - 2022-06-22 04:57:25 --> Utf8 Class Initialized
INFO - 2022-06-22 04:57:25 --> URI Class Initialized
INFO - 2022-06-22 04:57:25 --> Router Class Initialized
INFO - 2022-06-22 04:57:25 --> Output Class Initialized
INFO - 2022-06-22 04:57:25 --> Router Class Initialized
INFO - 2022-06-22 04:57:25 --> Security Class Initialized
INFO - 2022-06-22 04:57:25 --> Output Class Initialized
INFO - 2022-06-22 04:57:25 --> Security Class Initialized
DEBUG - 2022-06-22 04:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 04:57:25 --> Input Class Initialized
DEBUG - 2022-06-22 04:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 04:57:25 --> Input Class Initialized
INFO - 2022-06-22 04:57:25 --> Language Class Initialized
INFO - 2022-06-22 04:57:25 --> Language Class Initialized
INFO - 2022-06-22 04:57:25 --> Loader Class Initialized
INFO - 2022-06-22 04:57:25 --> Loader Class Initialized
INFO - 2022-06-22 04:57:25 --> Helper loaded: url_helper
INFO - 2022-06-22 04:57:25 --> Helper loaded: url_helper
INFO - 2022-06-22 04:57:25 --> Helper loaded: file_helper
INFO - 2022-06-22 04:57:25 --> Helper loaded: file_helper
INFO - 2022-06-22 04:57:25 --> Database Driver Class Initialized
INFO - 2022-06-22 04:57:25 --> Database Driver Class Initialized
INFO - 2022-06-22 04:57:25 --> Email Class Initialized
INFO - 2022-06-22 04:57:25 --> Email Class Initialized
DEBUG - 2022-06-22 04:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-22 04:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 04:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 04:57:25 --> Controller Class Initialized
INFO - 2022-06-22 04:57:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 04:57:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-22 04:57:25 --> test
INFO - 2022-06-22 04:57:25 --> Final output sent to browser
DEBUG - 2022-06-22 04:57:25 --> Total execution time: 0.0496
INFO - 2022-06-22 04:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 04:57:25 --> Controller Class Initialized
INFO - 2022-06-22 04:57:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 04:57:25 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 04:57:25 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-22 04:57:25 --> Final output sent to browser
DEBUG - 2022-06-22 04:57:25 --> Total execution time: 0.0530
INFO - 2022-06-22 05:36:44 --> Config Class Initialized
INFO - 2022-06-22 05:36:44 --> Hooks Class Initialized
DEBUG - 2022-06-22 05:36:44 --> UTF-8 Support Enabled
INFO - 2022-06-22 05:36:44 --> Utf8 Class Initialized
INFO - 2022-06-22 05:36:44 --> URI Class Initialized
INFO - 2022-06-22 05:36:44 --> Router Class Initialized
INFO - 2022-06-22 05:36:44 --> Output Class Initialized
INFO - 2022-06-22 05:36:44 --> Security Class Initialized
DEBUG - 2022-06-22 05:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 05:36:44 --> Input Class Initialized
INFO - 2022-06-22 05:36:44 --> Language Class Initialized
INFO - 2022-06-22 05:36:44 --> Loader Class Initialized
INFO - 2022-06-22 05:36:44 --> Helper loaded: url_helper
INFO - 2022-06-22 05:36:44 --> Helper loaded: file_helper
INFO - 2022-06-22 05:36:44 --> Database Driver Class Initialized
INFO - 2022-06-22 05:36:44 --> Email Class Initialized
DEBUG - 2022-06-22 05:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 05:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 05:36:44 --> Controller Class Initialized
INFO - 2022-06-22 05:36:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 05:36:44 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 05:36:44 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-22 05:36:44 --> Final output sent to browser
DEBUG - 2022-06-22 05:36:44 --> Total execution time: 0.0738
INFO - 2022-06-22 05:36:56 --> Config Class Initialized
INFO - 2022-06-22 05:36:56 --> Hooks Class Initialized
DEBUG - 2022-06-22 05:36:56 --> UTF-8 Support Enabled
INFO - 2022-06-22 05:36:56 --> Utf8 Class Initialized
INFO - 2022-06-22 05:36:56 --> URI Class Initialized
INFO - 2022-06-22 05:36:56 --> Config Class Initialized
INFO - 2022-06-22 05:36:56 --> Hooks Class Initialized
INFO - 2022-06-22 05:36:56 --> Router Class Initialized
DEBUG - 2022-06-22 05:36:56 --> UTF-8 Support Enabled
INFO - 2022-06-22 05:36:56 --> Utf8 Class Initialized
INFO - 2022-06-22 05:36:56 --> Output Class Initialized
INFO - 2022-06-22 05:36:56 --> URI Class Initialized
INFO - 2022-06-22 05:36:56 --> Security Class Initialized
INFO - 2022-06-22 05:36:56 --> Router Class Initialized
DEBUG - 2022-06-22 05:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 05:36:56 --> Input Class Initialized
INFO - 2022-06-22 05:36:56 --> Output Class Initialized
INFO - 2022-06-22 05:36:56 --> Language Class Initialized
INFO - 2022-06-22 05:36:56 --> Security Class Initialized
INFO - 2022-06-22 05:36:56 --> Loader Class Initialized
DEBUG - 2022-06-22 05:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 05:36:56 --> Input Class Initialized
INFO - 2022-06-22 05:36:56 --> Helper loaded: url_helper
INFO - 2022-06-22 05:36:56 --> Language Class Initialized
INFO - 2022-06-22 05:36:56 --> Helper loaded: file_helper
INFO - 2022-06-22 05:36:56 --> Loader Class Initialized
INFO - 2022-06-22 05:36:56 --> Database Driver Class Initialized
INFO - 2022-06-22 05:36:56 --> Helper loaded: url_helper
INFO - 2022-06-22 05:36:56 --> Helper loaded: file_helper
INFO - 2022-06-22 05:36:56 --> Database Driver Class Initialized
INFO - 2022-06-22 05:36:56 --> Email Class Initialized
DEBUG - 2022-06-22 05:36:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 05:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 05:36:56 --> Controller Class Initialized
INFO - 2022-06-22 05:36:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 05:36:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 05:36:56 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-22 05:36:56 --> Final output sent to browser
DEBUG - 2022-06-22 05:36:56 --> Total execution time: 0.0336
INFO - 2022-06-22 05:36:56 --> Email Class Initialized
DEBUG - 2022-06-22 05:36:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 05:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 05:36:56 --> Controller Class Initialized
INFO - 2022-06-22 05:36:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 05:36:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-22 05:36:56 --> test
INFO - 2022-06-22 05:36:56 --> Final output sent to browser
DEBUG - 2022-06-22 05:36:56 --> Total execution time: 0.2434
INFO - 2022-06-22 05:40:44 --> Config Class Initialized
INFO - 2022-06-22 05:40:44 --> Hooks Class Initialized
DEBUG - 2022-06-22 05:40:44 --> UTF-8 Support Enabled
INFO - 2022-06-22 05:40:44 --> Utf8 Class Initialized
INFO - 2022-06-22 05:40:44 --> URI Class Initialized
INFO - 2022-06-22 05:40:44 --> Router Class Initialized
INFO - 2022-06-22 05:40:44 --> Output Class Initialized
INFO - 2022-06-22 05:40:44 --> Security Class Initialized
DEBUG - 2022-06-22 05:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 05:40:44 --> Input Class Initialized
INFO - 2022-06-22 05:40:44 --> Language Class Initialized
INFO - 2022-06-22 05:40:44 --> Loader Class Initialized
INFO - 2022-06-22 05:40:44 --> Helper loaded: url_helper
INFO - 2022-06-22 05:40:44 --> Helper loaded: file_helper
INFO - 2022-06-22 05:40:44 --> Database Driver Class Initialized
INFO - 2022-06-22 05:40:45 --> Email Class Initialized
DEBUG - 2022-06-22 05:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 05:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 05:40:45 --> Controller Class Initialized
INFO - 2022-06-22 05:40:45 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 05:40:45 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 05:40:45 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-22 05:40:45 --> Final output sent to browser
DEBUG - 2022-06-22 05:40:45 --> Total execution time: 0.2220
INFO - 2022-06-22 05:40:58 --> Config Class Initialized
INFO - 2022-06-22 05:40:58 --> Hooks Class Initialized
DEBUG - 2022-06-22 05:40:58 --> UTF-8 Support Enabled
INFO - 2022-06-22 05:40:58 --> Utf8 Class Initialized
INFO - 2022-06-22 05:40:58 --> Config Class Initialized
INFO - 2022-06-22 05:40:58 --> URI Class Initialized
INFO - 2022-06-22 05:40:58 --> Hooks Class Initialized
DEBUG - 2022-06-22 05:40:58 --> UTF-8 Support Enabled
INFO - 2022-06-22 05:40:58 --> Router Class Initialized
INFO - 2022-06-22 05:40:58 --> Utf8 Class Initialized
INFO - 2022-06-22 05:40:58 --> URI Class Initialized
INFO - 2022-06-22 05:40:58 --> Output Class Initialized
INFO - 2022-06-22 05:40:58 --> Security Class Initialized
INFO - 2022-06-22 05:40:58 --> Router Class Initialized
DEBUG - 2022-06-22 05:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 05:40:58 --> Output Class Initialized
INFO - 2022-06-22 05:40:58 --> Input Class Initialized
INFO - 2022-06-22 05:40:58 --> Security Class Initialized
INFO - 2022-06-22 05:40:58 --> Language Class Initialized
DEBUG - 2022-06-22 05:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 05:40:58 --> Input Class Initialized
INFO - 2022-06-22 05:40:58 --> Loader Class Initialized
INFO - 2022-06-22 05:40:58 --> Language Class Initialized
INFO - 2022-06-22 05:40:58 --> Helper loaded: url_helper
INFO - 2022-06-22 05:40:58 --> Loader Class Initialized
INFO - 2022-06-22 05:40:58 --> Helper loaded: file_helper
INFO - 2022-06-22 05:40:58 --> Helper loaded: url_helper
INFO - 2022-06-22 05:40:58 --> Database Driver Class Initialized
INFO - 2022-06-22 05:40:58 --> Helper loaded: file_helper
INFO - 2022-06-22 05:40:58 --> Database Driver Class Initialized
INFO - 2022-06-22 05:40:58 --> Email Class Initialized
DEBUG - 2022-06-22 05:40:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 05:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 05:40:58 --> Controller Class Initialized
INFO - 2022-06-22 05:40:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 05:40:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 05:40:58 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-22 05:40:58 --> Final output sent to browser
DEBUG - 2022-06-22 05:40:58 --> Total execution time: 0.0333
INFO - 2022-06-22 05:40:58 --> Email Class Initialized
DEBUG - 2022-06-22 05:40:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 05:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 05:40:58 --> Controller Class Initialized
INFO - 2022-06-22 05:40:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 05:40:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-22 05:40:58 --> test
INFO - 2022-06-22 05:40:58 --> Final output sent to browser
DEBUG - 2022-06-22 05:40:58 --> Total execution time: 0.0781
INFO - 2022-06-22 05:41:45 --> Config Class Initialized
INFO - 2022-06-22 05:41:45 --> Hooks Class Initialized
DEBUG - 2022-06-22 05:41:45 --> UTF-8 Support Enabled
INFO - 2022-06-22 05:41:45 --> Utf8 Class Initialized
INFO - 2022-06-22 05:41:45 --> URI Class Initialized
INFO - 2022-06-22 05:41:45 --> Router Class Initialized
INFO - 2022-06-22 05:41:45 --> Output Class Initialized
INFO - 2022-06-22 05:41:45 --> Security Class Initialized
DEBUG - 2022-06-22 05:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 05:41:45 --> Input Class Initialized
INFO - 2022-06-22 05:41:45 --> Language Class Initialized
INFO - 2022-06-22 05:41:45 --> Loader Class Initialized
INFO - 2022-06-22 05:41:45 --> Helper loaded: url_helper
INFO - 2022-06-22 05:41:45 --> Helper loaded: file_helper
INFO - 2022-06-22 05:41:45 --> Database Driver Class Initialized
INFO - 2022-06-22 05:41:45 --> Config Class Initialized
INFO - 2022-06-22 05:41:45 --> Hooks Class Initialized
DEBUG - 2022-06-22 05:41:45 --> UTF-8 Support Enabled
INFO - 2022-06-22 05:41:45 --> Utf8 Class Initialized
INFO - 2022-06-22 05:41:45 --> URI Class Initialized
INFO - 2022-06-22 05:41:45 --> Router Class Initialized
INFO - 2022-06-22 05:41:45 --> Output Class Initialized
INFO - 2022-06-22 05:41:45 --> Security Class Initialized
DEBUG - 2022-06-22 05:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 05:41:45 --> Input Class Initialized
INFO - 2022-06-22 05:41:45 --> Language Class Initialized
INFO - 2022-06-22 05:41:45 --> Loader Class Initialized
INFO - 2022-06-22 05:41:45 --> Helper loaded: url_helper
INFO - 2022-06-22 05:41:45 --> Helper loaded: file_helper
INFO - 2022-06-22 05:41:45 --> Database Driver Class Initialized
INFO - 2022-06-22 05:41:45 --> Email Class Initialized
INFO - 2022-06-22 05:41:45 --> Email Class Initialized
DEBUG - 2022-06-22 05:41:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-22 05:41:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 05:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 05:41:45 --> Controller Class Initialized
INFO - 2022-06-22 05:41:45 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 05:41:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-22 05:41:45 --> test
INFO - 2022-06-22 05:41:45 --> Final output sent to browser
DEBUG - 2022-06-22 05:41:45 --> Total execution time: 0.0603
INFO - 2022-06-22 05:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 05:41:45 --> Controller Class Initialized
INFO - 2022-06-22 05:41:45 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 05:41:45 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 05:41:45 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-22 05:41:45 --> Final output sent to browser
DEBUG - 2022-06-22 05:41:45 --> Total execution time: 0.0282
INFO - 2022-06-22 06:10:36 --> Config Class Initialized
INFO - 2022-06-22 06:10:36 --> Hooks Class Initialized
DEBUG - 2022-06-22 06:10:36 --> UTF-8 Support Enabled
INFO - 2022-06-22 06:10:36 --> Utf8 Class Initialized
INFO - 2022-06-22 06:10:36 --> URI Class Initialized
INFO - 2022-06-22 06:10:36 --> Router Class Initialized
INFO - 2022-06-22 06:10:36 --> Output Class Initialized
INFO - 2022-06-22 06:10:36 --> Security Class Initialized
DEBUG - 2022-06-22 06:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 06:10:36 --> Input Class Initialized
INFO - 2022-06-22 06:10:36 --> Language Class Initialized
INFO - 2022-06-22 06:10:36 --> Loader Class Initialized
INFO - 2022-06-22 06:10:36 --> Helper loaded: url_helper
INFO - 2022-06-22 06:10:36 --> Helper loaded: file_helper
INFO - 2022-06-22 06:10:36 --> Database Driver Class Initialized
INFO - 2022-06-22 06:10:36 --> Email Class Initialized
DEBUG - 2022-06-22 06:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 06:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 06:10:36 --> Controller Class Initialized
INFO - 2022-06-22 06:10:36 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 06:10:36 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 06:10:36 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-22 06:10:36 --> Final output sent to browser
DEBUG - 2022-06-22 06:10:36 --> Total execution time: 0.1567
INFO - 2022-06-22 06:10:47 --> Config Class Initialized
INFO - 2022-06-22 06:10:47 --> Hooks Class Initialized
DEBUG - 2022-06-22 06:10:47 --> UTF-8 Support Enabled
INFO - 2022-06-22 06:10:47 --> Utf8 Class Initialized
INFO - 2022-06-22 06:10:47 --> Config Class Initialized
INFO - 2022-06-22 06:10:47 --> Hooks Class Initialized
INFO - 2022-06-22 06:10:47 --> URI Class Initialized
DEBUG - 2022-06-22 06:10:47 --> UTF-8 Support Enabled
INFO - 2022-06-22 06:10:47 --> Utf8 Class Initialized
INFO - 2022-06-22 06:10:47 --> Router Class Initialized
INFO - 2022-06-22 06:10:47 --> URI Class Initialized
INFO - 2022-06-22 06:10:47 --> Output Class Initialized
INFO - 2022-06-22 06:10:47 --> Security Class Initialized
INFO - 2022-06-22 06:10:47 --> Router Class Initialized
DEBUG - 2022-06-22 06:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 06:10:47 --> Output Class Initialized
INFO - 2022-06-22 06:10:47 --> Input Class Initialized
INFO - 2022-06-22 06:10:47 --> Language Class Initialized
INFO - 2022-06-22 06:10:47 --> Security Class Initialized
INFO - 2022-06-22 06:10:47 --> Loader Class Initialized
DEBUG - 2022-06-22 06:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 06:10:47 --> Input Class Initialized
INFO - 2022-06-22 06:10:47 --> Helper loaded: url_helper
INFO - 2022-06-22 06:10:47 --> Language Class Initialized
INFO - 2022-06-22 06:10:47 --> Helper loaded: file_helper
INFO - 2022-06-22 06:10:47 --> Loader Class Initialized
INFO - 2022-06-22 06:10:47 --> Database Driver Class Initialized
INFO - 2022-06-22 06:10:47 --> Helper loaded: url_helper
INFO - 2022-06-22 06:10:47 --> Helper loaded: file_helper
INFO - 2022-06-22 06:10:47 --> Database Driver Class Initialized
INFO - 2022-06-22 06:10:47 --> Email Class Initialized
DEBUG - 2022-06-22 06:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 06:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 06:10:47 --> Controller Class Initialized
INFO - 2022-06-22 06:10:47 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 06:10:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 06:10:47 --> Severity: Notice --> Undefined variable: newToken C:\wamp64\www\qr\application\controllers\Tokenctrl.php 68
DEBUG - 2022-06-22 06:10:47 --> test
INFO - 2022-06-22 06:10:47 --> Email Class Initialized
DEBUG - 2022-06-22 06:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-06-22 06:10:47 --> Query error: Column 'ud_token' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_name`, `ud_age`, `ud_gender`, `ud_time`, `ud_token`) VALUES ('gfds', '74', 'other', '2022/6/22 11:40', NULL)
INFO - 2022-06-22 06:10:47 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-22 06:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 06:10:47 --> Controller Class Initialized
INFO - 2022-06-22 06:10:47 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 06:10:47 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 06:10:47 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-22 06:10:47 --> Final output sent to browser
DEBUG - 2022-06-22 06:10:47 --> Total execution time: 0.1583
INFO - 2022-06-22 06:11:19 --> Config Class Initialized
INFO - 2022-06-22 06:11:19 --> Hooks Class Initialized
INFO - 2022-06-22 06:11:19 --> Config Class Initialized
DEBUG - 2022-06-22 06:11:19 --> UTF-8 Support Enabled
INFO - 2022-06-22 06:11:19 --> Hooks Class Initialized
INFO - 2022-06-22 06:11:19 --> Utf8 Class Initialized
DEBUG - 2022-06-22 06:11:19 --> UTF-8 Support Enabled
INFO - 2022-06-22 06:11:19 --> URI Class Initialized
INFO - 2022-06-22 06:11:19 --> Utf8 Class Initialized
INFO - 2022-06-22 06:11:19 --> Router Class Initialized
INFO - 2022-06-22 06:11:19 --> URI Class Initialized
INFO - 2022-06-22 06:11:19 --> Output Class Initialized
INFO - 2022-06-22 06:11:19 --> Router Class Initialized
INFO - 2022-06-22 06:11:19 --> Security Class Initialized
INFO - 2022-06-22 06:11:19 --> Output Class Initialized
DEBUG - 2022-06-22 06:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 06:11:19 --> Security Class Initialized
INFO - 2022-06-22 06:11:19 --> Input Class Initialized
DEBUG - 2022-06-22 06:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 06:11:19 --> Language Class Initialized
INFO - 2022-06-22 06:11:19 --> Input Class Initialized
INFO - 2022-06-22 06:11:19 --> Language Class Initialized
INFO - 2022-06-22 06:11:19 --> Loader Class Initialized
INFO - 2022-06-22 06:11:19 --> Loader Class Initialized
INFO - 2022-06-22 06:11:19 --> Helper loaded: url_helper
INFO - 2022-06-22 06:11:19 --> Helper loaded: file_helper
INFO - 2022-06-22 06:11:19 --> Helper loaded: url_helper
INFO - 2022-06-22 06:11:19 --> Helper loaded: file_helper
INFO - 2022-06-22 06:11:19 --> Database Driver Class Initialized
INFO - 2022-06-22 06:11:19 --> Database Driver Class Initialized
INFO - 2022-06-22 06:11:19 --> Email Class Initialized
DEBUG - 2022-06-22 06:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 06:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 06:11:19 --> Controller Class Initialized
INFO - 2022-06-22 06:11:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 06:11:19 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 06:11:19 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-22 06:11:19 --> Final output sent to browser
DEBUG - 2022-06-22 06:11:19 --> Total execution time: 0.0242
INFO - 2022-06-22 06:11:19 --> Email Class Initialized
DEBUG - 2022-06-22 06:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 06:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 06:11:19 --> Controller Class Initialized
INFO - 2022-06-22 06:11:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 06:11:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 06:11:19 --> Severity: Notice --> Undefined variable: newToken C:\wamp64\www\qr\application\controllers\Tokenctrl.php 68
DEBUG - 2022-06-22 06:11:19 --> test
ERROR - 2022-06-22 06:11:19 --> Query error: Column 'ud_token' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_name`, `ud_age`, `ud_gender`, `ud_time`, `ud_token`) VALUES ('gfdsaz', '85', 'male', '2022/6/22 11:41', NULL)
INFO - 2022-06-22 06:11:19 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-22 06:11:26 --> Config Class Initialized
INFO - 2022-06-22 06:11:26 --> Hooks Class Initialized
DEBUG - 2022-06-22 06:11:26 --> UTF-8 Support Enabled
INFO - 2022-06-22 06:11:26 --> Utf8 Class Initialized
INFO - 2022-06-22 06:11:26 --> URI Class Initialized
INFO - 2022-06-22 06:11:26 --> Router Class Initialized
INFO - 2022-06-22 06:11:26 --> Output Class Initialized
INFO - 2022-06-22 06:11:26 --> Security Class Initialized
DEBUG - 2022-06-22 06:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 06:11:26 --> Input Class Initialized
INFO - 2022-06-22 06:11:26 --> Language Class Initialized
INFO - 2022-06-22 06:11:26 --> Loader Class Initialized
INFO - 2022-06-22 06:11:26 --> Helper loaded: url_helper
INFO - 2022-06-22 06:11:26 --> Helper loaded: file_helper
INFO - 2022-06-22 06:11:26 --> Database Driver Class Initialized
INFO - 2022-06-22 06:11:26 --> Email Class Initialized
DEBUG - 2022-06-22 06:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 06:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 06:11:26 --> Controller Class Initialized
INFO - 2022-06-22 06:11:26 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 06:11:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 06:11:26 --> Severity: Notice --> Undefined variable: newToken C:\wamp64\www\qr\application\controllers\Tokenctrl.php 68
DEBUG - 2022-06-22 06:11:26 --> test
ERROR - 2022-06-22 06:11:26 --> Query error: Column 'ud_name' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_name`, `ud_age`, `ud_gender`, `ud_time`, `ud_token`) VALUES (NULL, NULL, NULL, NULL, NULL)
INFO - 2022-06-22 06:11:26 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-22 06:12:14 --> Config Class Initialized
INFO - 2022-06-22 06:12:14 --> Hooks Class Initialized
DEBUG - 2022-06-22 06:12:14 --> UTF-8 Support Enabled
INFO - 2022-06-22 06:12:14 --> Utf8 Class Initialized
INFO - 2022-06-22 06:12:14 --> URI Class Initialized
INFO - 2022-06-22 06:12:14 --> Router Class Initialized
INFO - 2022-06-22 06:12:14 --> Output Class Initialized
INFO - 2022-06-22 06:12:14 --> Security Class Initialized
DEBUG - 2022-06-22 06:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 06:12:14 --> Input Class Initialized
INFO - 2022-06-22 06:12:14 --> Language Class Initialized
INFO - 2022-06-22 06:12:14 --> Loader Class Initialized
INFO - 2022-06-22 06:12:14 --> Helper loaded: url_helper
INFO - 2022-06-22 06:12:14 --> Helper loaded: file_helper
INFO - 2022-06-22 06:12:14 --> Database Driver Class Initialized
INFO - 2022-06-22 06:12:14 --> Email Class Initialized
DEBUG - 2022-06-22 06:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 06:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 06:12:14 --> Controller Class Initialized
INFO - 2022-06-22 06:12:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 06:12:14 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 06:12:14 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-22 06:12:14 --> Final output sent to browser
DEBUG - 2022-06-22 06:12:14 --> Total execution time: 0.0528
INFO - 2022-06-22 06:12:15 --> Config Class Initialized
INFO - 2022-06-22 06:12:15 --> Hooks Class Initialized
DEBUG - 2022-06-22 06:12:15 --> UTF-8 Support Enabled
INFO - 2022-06-22 06:12:15 --> Utf8 Class Initialized
INFO - 2022-06-22 06:12:15 --> URI Class Initialized
INFO - 2022-06-22 06:12:15 --> Router Class Initialized
INFO - 2022-06-22 06:12:15 --> Output Class Initialized
INFO - 2022-06-22 06:12:15 --> Security Class Initialized
DEBUG - 2022-06-22 06:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 06:12:15 --> Input Class Initialized
INFO - 2022-06-22 06:12:15 --> Language Class Initialized
INFO - 2022-06-22 06:12:15 --> Loader Class Initialized
INFO - 2022-06-22 06:12:15 --> Helper loaded: url_helper
INFO - 2022-06-22 06:12:15 --> Helper loaded: file_helper
INFO - 2022-06-22 06:12:15 --> Database Driver Class Initialized
INFO - 2022-06-22 06:12:15 --> Email Class Initialized
DEBUG - 2022-06-22 06:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 06:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 06:12:15 --> Controller Class Initialized
INFO - 2022-06-22 06:12:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 06:12:15 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 06:12:15 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-22 06:12:15 --> Final output sent to browser
DEBUG - 2022-06-22 06:12:15 --> Total execution time: 0.0199
INFO - 2022-06-22 06:12:17 --> Config Class Initialized
INFO - 2022-06-22 06:12:17 --> Hooks Class Initialized
DEBUG - 2022-06-22 06:12:17 --> UTF-8 Support Enabled
INFO - 2022-06-22 06:12:17 --> Utf8 Class Initialized
INFO - 2022-06-22 06:12:17 --> URI Class Initialized
INFO - 2022-06-22 06:12:17 --> Router Class Initialized
INFO - 2022-06-22 06:12:17 --> Output Class Initialized
INFO - 2022-06-22 06:12:17 --> Security Class Initialized
DEBUG - 2022-06-22 06:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 06:12:17 --> Input Class Initialized
INFO - 2022-06-22 06:12:17 --> Language Class Initialized
INFO - 2022-06-22 06:12:17 --> Loader Class Initialized
INFO - 2022-06-22 06:12:17 --> Helper loaded: url_helper
INFO - 2022-06-22 06:12:17 --> Helper loaded: file_helper
INFO - 2022-06-22 06:12:17 --> Database Driver Class Initialized
INFO - 2022-06-22 06:12:17 --> Email Class Initialized
DEBUG - 2022-06-22 06:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 06:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 06:12:17 --> Controller Class Initialized
INFO - 2022-06-22 06:12:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 06:12:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 06:12:17 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-22 06:12:17 --> Final output sent to browser
DEBUG - 2022-06-22 06:12:17 --> Total execution time: 0.0222
INFO - 2022-06-22 06:12:18 --> Config Class Initialized
INFO - 2022-06-22 06:12:18 --> Hooks Class Initialized
DEBUG - 2022-06-22 06:12:18 --> UTF-8 Support Enabled
INFO - 2022-06-22 06:12:18 --> Utf8 Class Initialized
INFO - 2022-06-22 06:12:18 --> URI Class Initialized
INFO - 2022-06-22 06:12:18 --> Router Class Initialized
INFO - 2022-06-22 06:12:18 --> Output Class Initialized
INFO - 2022-06-22 06:12:18 --> Security Class Initialized
DEBUG - 2022-06-22 06:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 06:12:18 --> Input Class Initialized
INFO - 2022-06-22 06:12:18 --> Language Class Initialized
INFO - 2022-06-22 06:12:18 --> Loader Class Initialized
INFO - 2022-06-22 06:12:18 --> Helper loaded: url_helper
INFO - 2022-06-22 06:12:18 --> Helper loaded: file_helper
INFO - 2022-06-22 06:12:18 --> Database Driver Class Initialized
INFO - 2022-06-22 06:12:18 --> Email Class Initialized
DEBUG - 2022-06-22 06:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 06:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 06:12:18 --> Controller Class Initialized
INFO - 2022-06-22 06:12:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 06:12:18 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 06:12:18 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-22 06:12:18 --> Final output sent to browser
DEBUG - 2022-06-22 06:12:18 --> Total execution time: 0.0380
INFO - 2022-06-22 06:32:07 --> Config Class Initialized
INFO - 2022-06-22 06:32:07 --> Hooks Class Initialized
DEBUG - 2022-06-22 06:32:07 --> UTF-8 Support Enabled
INFO - 2022-06-22 06:32:07 --> Utf8 Class Initialized
INFO - 2022-06-22 06:32:07 --> URI Class Initialized
INFO - 2022-06-22 06:32:07 --> Router Class Initialized
INFO - 2022-06-22 06:32:07 --> Output Class Initialized
INFO - 2022-06-22 06:32:07 --> Security Class Initialized
DEBUG - 2022-06-22 06:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 06:32:07 --> Input Class Initialized
INFO - 2022-06-22 06:32:07 --> Language Class Initialized
INFO - 2022-06-22 06:32:07 --> Loader Class Initialized
INFO - 2022-06-22 06:32:07 --> Config Class Initialized
INFO - 2022-06-22 06:32:07 --> Helper loaded: url_helper
INFO - 2022-06-22 06:32:07 --> Hooks Class Initialized
INFO - 2022-06-22 06:32:07 --> Helper loaded: file_helper
DEBUG - 2022-06-22 06:32:07 --> UTF-8 Support Enabled
INFO - 2022-06-22 06:32:07 --> Database Driver Class Initialized
INFO - 2022-06-22 06:32:07 --> Utf8 Class Initialized
INFO - 2022-06-22 06:32:07 --> URI Class Initialized
INFO - 2022-06-22 06:32:07 --> Router Class Initialized
INFO - 2022-06-22 06:32:07 --> Output Class Initialized
INFO - 2022-06-22 06:32:07 --> Security Class Initialized
DEBUG - 2022-06-22 06:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 06:32:07 --> Input Class Initialized
INFO - 2022-06-22 06:32:07 --> Language Class Initialized
INFO - 2022-06-22 06:32:07 --> Loader Class Initialized
INFO - 2022-06-22 06:32:07 --> Helper loaded: url_helper
INFO - 2022-06-22 06:32:07 --> Helper loaded: file_helper
INFO - 2022-06-22 06:32:07 --> Database Driver Class Initialized
INFO - 2022-06-22 06:32:07 --> Email Class Initialized
INFO - 2022-06-22 06:32:07 --> Email Class Initialized
DEBUG - 2022-06-22 06:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-22 06:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 06:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 06:32:07 --> Controller Class Initialized
INFO - 2022-06-22 06:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 06:32:07 --> Model "Tokenmodel" initialized
INFO - 2022-06-22 06:32:07 --> Controller Class Initialized
DEBUG - 2022-06-22 06:32:07 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 06:32:07 --> Model "Tokenmodel" initialized
ERROR - 2022-06-22 06:32:07 --> Severity: Notice --> Undefined variable: newToken C:\wamp64\www\qr\application\controllers\Tokenctrl.php 68
DEBUG - 2022-06-22 06:32:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-22 06:32:07 --> test
ERROR - 2022-06-22 06:32:07 --> Query error: Column 'ud_token' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_name`, `ud_age`, `ud_gender`, `ud_time`, `ud_token`) VALUES ('', '', '', '2022/6/22 12:2', NULL)
INFO - 2022-06-22 06:32:07 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-22 06:32:08 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-22 06:32:08 --> Final output sent to browser
DEBUG - 2022-06-22 06:32:08 --> Total execution time: 0.4729
INFO - 2022-06-22 06:32:12 --> Config Class Initialized
INFO - 2022-06-22 06:32:12 --> Hooks Class Initialized
DEBUG - 2022-06-22 06:32:12 --> UTF-8 Support Enabled
INFO - 2022-06-22 06:32:12 --> Utf8 Class Initialized
INFO - 2022-06-22 06:32:12 --> URI Class Initialized
INFO - 2022-06-22 06:32:12 --> Router Class Initialized
INFO - 2022-06-22 06:32:12 --> Output Class Initialized
INFO - 2022-06-22 06:32:12 --> Security Class Initialized
DEBUG - 2022-06-22 06:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 06:32:12 --> Input Class Initialized
INFO - 2022-06-22 06:32:12 --> Language Class Initialized
INFO - 2022-06-22 06:32:12 --> Loader Class Initialized
INFO - 2022-06-22 06:32:12 --> Helper loaded: url_helper
INFO - 2022-06-22 06:32:12 --> Helper loaded: file_helper
INFO - 2022-06-22 06:32:12 --> Database Driver Class Initialized
INFO - 2022-06-22 06:32:12 --> Config Class Initialized
INFO - 2022-06-22 06:32:12 --> Hooks Class Initialized
DEBUG - 2022-06-22 06:32:12 --> UTF-8 Support Enabled
INFO - 2022-06-22 06:32:12 --> Utf8 Class Initialized
INFO - 2022-06-22 06:32:12 --> URI Class Initialized
INFO - 2022-06-22 06:32:12 --> Router Class Initialized
INFO - 2022-06-22 06:32:12 --> Output Class Initialized
INFO - 2022-06-22 06:32:12 --> Security Class Initialized
DEBUG - 2022-06-22 06:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 06:32:12 --> Input Class Initialized
INFO - 2022-06-22 06:32:12 --> Language Class Initialized
INFO - 2022-06-22 06:32:12 --> Loader Class Initialized
INFO - 2022-06-22 06:32:12 --> Helper loaded: url_helper
INFO - 2022-06-22 06:32:12 --> Helper loaded: file_helper
INFO - 2022-06-22 06:32:12 --> Database Driver Class Initialized
INFO - 2022-06-22 06:32:12 --> Email Class Initialized
DEBUG - 2022-06-22 06:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 06:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 06:32:12 --> Controller Class Initialized
INFO - 2022-06-22 06:32:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 06:32:12 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 06:32:12 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-22 06:32:12 --> Final output sent to browser
DEBUG - 2022-06-22 06:32:12 --> Total execution time: 0.0330
INFO - 2022-06-22 06:32:12 --> Email Class Initialized
DEBUG - 2022-06-22 06:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 06:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 06:32:12 --> Controller Class Initialized
INFO - 2022-06-22 06:32:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 06:32:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 06:32:12 --> Severity: Notice --> Undefined variable: newToken C:\wamp64\www\qr\application\controllers\Tokenctrl.php 68
DEBUG - 2022-06-22 06:32:12 --> test
ERROR - 2022-06-22 06:32:12 --> Query error: Column 'ud_token' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_name`, `ud_age`, `ud_gender`, `ud_time`, `ud_token`) VALUES ('', '', '', '2022/6/22 12:2', NULL)
INFO - 2022-06-22 06:32:12 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-22 06:32:14 --> Config Class Initialized
INFO - 2022-06-22 06:32:14 --> Hooks Class Initialized
DEBUG - 2022-06-22 06:32:14 --> UTF-8 Support Enabled
INFO - 2022-06-22 06:32:14 --> Utf8 Class Initialized
INFO - 2022-06-22 06:32:14 --> URI Class Initialized
INFO - 2022-06-22 06:32:14 --> Router Class Initialized
INFO - 2022-06-22 06:32:14 --> Output Class Initialized
INFO - 2022-06-22 06:32:14 --> Security Class Initialized
DEBUG - 2022-06-22 06:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 06:32:14 --> Input Class Initialized
INFO - 2022-06-22 06:32:14 --> Language Class Initialized
INFO - 2022-06-22 06:32:14 --> Loader Class Initialized
INFO - 2022-06-22 06:32:14 --> Helper loaded: url_helper
INFO - 2022-06-22 06:32:14 --> Helper loaded: file_helper
INFO - 2022-06-22 06:32:14 --> Database Driver Class Initialized
INFO - 2022-06-22 06:32:14 --> Email Class Initialized
DEBUG - 2022-06-22 06:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 06:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 06:32:14 --> Controller Class Initialized
INFO - 2022-06-22 06:32:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 06:32:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 06:32:14 --> Severity: Notice --> Undefined variable: newToken C:\wamp64\www\qr\application\controllers\Tokenctrl.php 68
DEBUG - 2022-06-22 06:32:14 --> test
INFO - 2022-06-22 06:32:14 --> Config Class Initialized
INFO - 2022-06-22 06:32:14 --> Hooks Class Initialized
DEBUG - 2022-06-22 06:32:14 --> UTF-8 Support Enabled
INFO - 2022-06-22 06:32:14 --> Utf8 Class Initialized
INFO - 2022-06-22 06:32:14 --> URI Class Initialized
INFO - 2022-06-22 06:32:14 --> Router Class Initialized
INFO - 2022-06-22 06:32:14 --> Output Class Initialized
INFO - 2022-06-22 06:32:14 --> Security Class Initialized
DEBUG - 2022-06-22 06:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 06:32:14 --> Input Class Initialized
INFO - 2022-06-22 06:32:14 --> Language Class Initialized
INFO - 2022-06-22 06:32:14 --> Loader Class Initialized
INFO - 2022-06-22 06:32:14 --> Helper loaded: url_helper
INFO - 2022-06-22 06:32:14 --> Helper loaded: file_helper
INFO - 2022-06-22 06:32:14 --> Database Driver Class Initialized
INFO - 2022-06-22 06:32:14 --> Email Class Initialized
DEBUG - 2022-06-22 06:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-06-22 06:32:14 --> Query error: Column 'ud_token' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_name`, `ud_age`, `ud_gender`, `ud_time`, `ud_token`) VALUES ('', '', '', '2022/6/22 12:2', NULL)
INFO - 2022-06-22 06:32:14 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-22 06:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 06:32:14 --> Controller Class Initialized
INFO - 2022-06-22 06:32:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 06:32:14 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 06:32:14 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-22 06:32:14 --> Final output sent to browser
DEBUG - 2022-06-22 06:32:14 --> Total execution time: 0.0547
INFO - 2022-06-22 06:32:42 --> Config Class Initialized
INFO - 2022-06-22 06:32:42 --> Hooks Class Initialized
INFO - 2022-06-22 06:32:42 --> Config Class Initialized
DEBUG - 2022-06-22 06:32:42 --> UTF-8 Support Enabled
INFO - 2022-06-22 06:32:42 --> Utf8 Class Initialized
INFO - 2022-06-22 06:32:42 --> Hooks Class Initialized
INFO - 2022-06-22 06:32:42 --> URI Class Initialized
DEBUG - 2022-06-22 06:32:42 --> UTF-8 Support Enabled
INFO - 2022-06-22 06:32:42 --> Utf8 Class Initialized
INFO - 2022-06-22 06:32:42 --> Router Class Initialized
INFO - 2022-06-22 06:32:42 --> URI Class Initialized
INFO - 2022-06-22 06:32:42 --> Output Class Initialized
INFO - 2022-06-22 06:32:42 --> Security Class Initialized
INFO - 2022-06-22 06:32:42 --> Router Class Initialized
DEBUG - 2022-06-22 06:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 06:32:42 --> Input Class Initialized
INFO - 2022-06-22 06:32:42 --> Output Class Initialized
INFO - 2022-06-22 06:32:42 --> Language Class Initialized
INFO - 2022-06-22 06:32:42 --> Security Class Initialized
DEBUG - 2022-06-22 06:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 06:32:42 --> Loader Class Initialized
INFO - 2022-06-22 06:32:42 --> Input Class Initialized
INFO - 2022-06-22 06:32:42 --> Language Class Initialized
INFO - 2022-06-22 06:32:42 --> Helper loaded: url_helper
INFO - 2022-06-22 06:32:42 --> Loader Class Initialized
INFO - 2022-06-22 06:32:42 --> Helper loaded: file_helper
INFO - 2022-06-22 06:32:42 --> Helper loaded: url_helper
INFO - 2022-06-22 06:32:42 --> Database Driver Class Initialized
INFO - 2022-06-22 06:32:42 --> Helper loaded: file_helper
INFO - 2022-06-22 06:32:42 --> Database Driver Class Initialized
INFO - 2022-06-22 06:32:42 --> Email Class Initialized
DEBUG - 2022-06-22 06:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 06:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 06:32:42 --> Controller Class Initialized
INFO - 2022-06-22 06:32:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 06:32:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 06:32:42 --> Severity: Notice --> Undefined variable: newToken C:\wamp64\www\qr\application\controllers\Tokenctrl.php 68
DEBUG - 2022-06-22 06:32:42 --> test
ERROR - 2022-06-22 06:32:42 --> Query error: Column 'ud_token' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_name`, `ud_age`, `ud_gender`, `ud_time`, `ud_token`) VALUES ('virat kohli', '85', 'male', '2022/6/22 12:2', NULL)
INFO - 2022-06-22 06:32:42 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-22 06:32:42 --> Email Class Initialized
DEBUG - 2022-06-22 06:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 06:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 06:32:42 --> Controller Class Initialized
INFO - 2022-06-22 06:32:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 06:32:42 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 06:32:42 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-22 06:32:42 --> Final output sent to browser
DEBUG - 2022-06-22 06:32:42 --> Total execution time: 0.0459
INFO - 2022-06-22 06:33:11 --> Config Class Initialized
INFO - 2022-06-22 06:33:11 --> Hooks Class Initialized
DEBUG - 2022-06-22 06:33:11 --> UTF-8 Support Enabled
INFO - 2022-06-22 06:33:11 --> Utf8 Class Initialized
INFO - 2022-06-22 06:33:11 --> URI Class Initialized
INFO - 2022-06-22 06:33:11 --> Router Class Initialized
INFO - 2022-06-22 06:33:11 --> Output Class Initialized
INFO - 2022-06-22 06:33:11 --> Security Class Initialized
DEBUG - 2022-06-22 06:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 06:33:11 --> Input Class Initialized
INFO - 2022-06-22 06:33:11 --> Language Class Initialized
INFO - 2022-06-22 06:33:11 --> Loader Class Initialized
INFO - 2022-06-22 06:33:11 --> Helper loaded: url_helper
INFO - 2022-06-22 06:33:11 --> Helper loaded: file_helper
INFO - 2022-06-22 06:33:11 --> Database Driver Class Initialized
INFO - 2022-06-22 06:33:11 --> Email Class Initialized
DEBUG - 2022-06-22 06:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 06:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 06:33:11 --> Controller Class Initialized
INFO - 2022-06-22 06:33:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 06:33:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 06:33:11 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-22 06:33:11 --> Final output sent to browser
DEBUG - 2022-06-22 06:33:11 --> Total execution time: 0.0258
INFO - 2022-06-22 06:33:19 --> Config Class Initialized
INFO - 2022-06-22 06:33:19 --> Hooks Class Initialized
DEBUG - 2022-06-22 06:33:19 --> UTF-8 Support Enabled
INFO - 2022-06-22 06:33:19 --> Utf8 Class Initialized
INFO - 2022-06-22 06:33:19 --> Config Class Initialized
INFO - 2022-06-22 06:33:19 --> URI Class Initialized
INFO - 2022-06-22 06:33:19 --> Hooks Class Initialized
INFO - 2022-06-22 06:33:19 --> Router Class Initialized
DEBUG - 2022-06-22 06:33:19 --> UTF-8 Support Enabled
INFO - 2022-06-22 06:33:19 --> Utf8 Class Initialized
INFO - 2022-06-22 06:33:19 --> Output Class Initialized
INFO - 2022-06-22 06:33:19 --> URI Class Initialized
INFO - 2022-06-22 06:33:19 --> Security Class Initialized
INFO - 2022-06-22 06:33:19 --> Router Class Initialized
DEBUG - 2022-06-22 06:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 06:33:19 --> Input Class Initialized
INFO - 2022-06-22 06:33:19 --> Output Class Initialized
INFO - 2022-06-22 06:33:19 --> Language Class Initialized
INFO - 2022-06-22 06:33:19 --> Security Class Initialized
INFO - 2022-06-22 06:33:19 --> Loader Class Initialized
DEBUG - 2022-06-22 06:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 06:33:19 --> Input Class Initialized
INFO - 2022-06-22 06:33:19 --> Helper loaded: url_helper
INFO - 2022-06-22 06:33:19 --> Language Class Initialized
INFO - 2022-06-22 06:33:19 --> Helper loaded: file_helper
INFO - 2022-06-22 06:33:19 --> Loader Class Initialized
INFO - 2022-06-22 06:33:19 --> Database Driver Class Initialized
INFO - 2022-06-22 06:33:19 --> Helper loaded: url_helper
INFO - 2022-06-22 06:33:19 --> Helper loaded: file_helper
INFO - 2022-06-22 06:33:19 --> Email Class Initialized
INFO - 2022-06-22 06:33:19 --> Database Driver Class Initialized
DEBUG - 2022-06-22 06:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 06:33:19 --> Email Class Initialized
INFO - 2022-06-22 06:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 06:33:19 --> Controller Class Initialized
DEBUG - 2022-06-22 06:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 06:33:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 06:33:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-22 06:33:19 --> test
INFO - 2022-06-22 06:33:19 --> Final output sent to browser
DEBUG - 2022-06-22 06:33:19 --> Total execution time: 0.1674
INFO - 2022-06-22 06:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 06:33:19 --> Controller Class Initialized
INFO - 2022-06-22 06:33:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 06:33:19 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 06:33:19 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-22 06:33:19 --> Final output sent to browser
DEBUG - 2022-06-22 06:33:19 --> Total execution time: 0.1694
INFO - 2022-06-22 06:35:52 --> Config Class Initialized
INFO - 2022-06-22 06:35:52 --> Hooks Class Initialized
DEBUG - 2022-06-22 06:35:52 --> UTF-8 Support Enabled
INFO - 2022-06-22 06:35:52 --> Utf8 Class Initialized
INFO - 2022-06-22 06:35:52 --> URI Class Initialized
INFO - 2022-06-22 06:35:52 --> Router Class Initialized
INFO - 2022-06-22 06:35:52 --> Output Class Initialized
INFO - 2022-06-22 06:35:52 --> Security Class Initialized
DEBUG - 2022-06-22 06:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 06:35:52 --> Input Class Initialized
INFO - 2022-06-22 06:35:52 --> Language Class Initialized
INFO - 2022-06-22 06:35:52 --> Loader Class Initialized
INFO - 2022-06-22 06:35:52 --> Helper loaded: url_helper
INFO - 2022-06-22 06:35:52 --> Helper loaded: file_helper
INFO - 2022-06-22 06:35:52 --> Database Driver Class Initialized
INFO - 2022-06-22 06:35:52 --> Email Class Initialized
DEBUG - 2022-06-22 06:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 06:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 06:35:52 --> Controller Class Initialized
INFO - 2022-06-22 06:35:52 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 06:35:52 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 06:35:52 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-22 06:35:52 --> Final output sent to browser
DEBUG - 2022-06-22 06:35:52 --> Total execution time: 0.0658
INFO - 2022-06-22 06:36:10 --> Config Class Initialized
INFO - 2022-06-22 06:36:10 --> Hooks Class Initialized
DEBUG - 2022-06-22 06:36:10 --> UTF-8 Support Enabled
INFO - 2022-06-22 06:36:10 --> Config Class Initialized
INFO - 2022-06-22 06:36:10 --> Hooks Class Initialized
INFO - 2022-06-22 06:36:10 --> Utf8 Class Initialized
DEBUG - 2022-06-22 06:36:10 --> UTF-8 Support Enabled
INFO - 2022-06-22 06:36:10 --> URI Class Initialized
INFO - 2022-06-22 06:36:10 --> Utf8 Class Initialized
INFO - 2022-06-22 06:36:10 --> URI Class Initialized
INFO - 2022-06-22 06:36:10 --> Router Class Initialized
INFO - 2022-06-22 06:36:10 --> Router Class Initialized
INFO - 2022-06-22 06:36:10 --> Output Class Initialized
INFO - 2022-06-22 06:36:10 --> Security Class Initialized
INFO - 2022-06-22 06:36:10 --> Output Class Initialized
DEBUG - 2022-06-22 06:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 06:36:10 --> Security Class Initialized
INFO - 2022-06-22 06:36:10 --> Input Class Initialized
INFO - 2022-06-22 06:36:10 --> Language Class Initialized
DEBUG - 2022-06-22 06:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 06:36:10 --> Input Class Initialized
INFO - 2022-06-22 06:36:10 --> Loader Class Initialized
INFO - 2022-06-22 06:36:10 --> Language Class Initialized
INFO - 2022-06-22 06:36:10 --> Helper loaded: url_helper
INFO - 2022-06-22 06:36:10 --> Loader Class Initialized
INFO - 2022-06-22 06:36:10 --> Helper loaded: file_helper
INFO - 2022-06-22 06:36:10 --> Helper loaded: url_helper
INFO - 2022-06-22 06:36:10 --> Database Driver Class Initialized
INFO - 2022-06-22 06:36:10 --> Helper loaded: file_helper
INFO - 2022-06-22 06:36:10 --> Database Driver Class Initialized
INFO - 2022-06-22 06:36:11 --> Email Class Initialized
INFO - 2022-06-22 06:36:11 --> Email Class Initialized
DEBUG - 2022-06-22 06:36:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-22 06:36:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 06:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 06:36:11 --> Controller Class Initialized
INFO - 2022-06-22 06:36:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 06:36:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 06:36:11 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-22 06:36:11 --> Final output sent to browser
DEBUG - 2022-06-22 06:36:11 --> Total execution time: 0.3344
INFO - 2022-06-22 06:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 06:36:11 --> Controller Class Initialized
INFO - 2022-06-22 06:36:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 06:36:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-22 06:36:11 --> test
INFO - 2022-06-22 06:36:11 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 06:36:11 --> Final output sent to browser
DEBUG - 2022-06-22 06:36:11 --> Total execution time: 0.5044
INFO - 2022-06-22 06:36:20 --> Config Class Initialized
INFO - 2022-06-22 06:36:20 --> Hooks Class Initialized
DEBUG - 2022-06-22 06:36:20 --> UTF-8 Support Enabled
INFO - 2022-06-22 06:36:20 --> Utf8 Class Initialized
INFO - 2022-06-22 06:36:20 --> URI Class Initialized
INFO - 2022-06-22 06:36:20 --> Router Class Initialized
INFO - 2022-06-22 06:36:20 --> Output Class Initialized
INFO - 2022-06-22 06:36:20 --> Security Class Initialized
DEBUG - 2022-06-22 06:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 06:36:20 --> Input Class Initialized
INFO - 2022-06-22 06:36:20 --> Language Class Initialized
INFO - 2022-06-22 06:36:20 --> Loader Class Initialized
INFO - 2022-06-22 06:36:20 --> Helper loaded: url_helper
INFO - 2022-06-22 06:36:20 --> Helper loaded: file_helper
INFO - 2022-06-22 06:36:20 --> Database Driver Class Initialized
INFO - 2022-06-22 06:36:20 --> Email Class Initialized
DEBUG - 2022-06-22 06:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 06:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 06:36:20 --> Controller Class Initialized
INFO - 2022-06-22 06:36:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 06:36:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-22 06:36:20 --> test
ERROR - 2022-06-22 06:36:20 --> Query error: Column 'ud_name' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_name`, `ud_age`, `ud_gender`, `ud_time`) VALUES (NULL, NULL, NULL, NULL)
INFO - 2022-06-22 06:36:20 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-22 06:36:40 --> Config Class Initialized
INFO - 2022-06-22 06:36:40 --> Hooks Class Initialized
DEBUG - 2022-06-22 06:36:40 --> UTF-8 Support Enabled
INFO - 2022-06-22 06:36:40 --> Utf8 Class Initialized
INFO - 2022-06-22 06:36:40 --> URI Class Initialized
INFO - 2022-06-22 06:36:40 --> Router Class Initialized
INFO - 2022-06-22 06:36:40 --> Output Class Initialized
INFO - 2022-06-22 06:36:40 --> Security Class Initialized
DEBUG - 2022-06-22 06:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 06:36:40 --> Input Class Initialized
INFO - 2022-06-22 06:36:40 --> Language Class Initialized
INFO - 2022-06-22 06:36:40 --> Loader Class Initialized
INFO - 2022-06-22 06:36:40 --> Helper loaded: url_helper
INFO - 2022-06-22 06:36:40 --> Helper loaded: file_helper
INFO - 2022-06-22 06:36:40 --> Database Driver Class Initialized
INFO - 2022-06-22 06:36:40 --> Email Class Initialized
DEBUG - 2022-06-22 06:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 06:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 06:36:40 --> Controller Class Initialized
INFO - 2022-06-22 06:36:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 06:36:40 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 06:36:40 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-22 06:36:40 --> Final output sent to browser
DEBUG - 2022-06-22 06:36:40 --> Total execution time: 0.0391
INFO - 2022-06-22 06:36:53 --> Config Class Initialized
INFO - 2022-06-22 06:36:53 --> Hooks Class Initialized
DEBUG - 2022-06-22 06:36:53 --> UTF-8 Support Enabled
INFO - 2022-06-22 06:36:53 --> Utf8 Class Initialized
INFO - 2022-06-22 06:36:53 --> URI Class Initialized
INFO - 2022-06-22 06:36:53 --> Config Class Initialized
INFO - 2022-06-22 06:36:53 --> Hooks Class Initialized
INFO - 2022-06-22 06:36:53 --> Router Class Initialized
DEBUG - 2022-06-22 06:36:53 --> UTF-8 Support Enabled
INFO - 2022-06-22 06:36:53 --> Utf8 Class Initialized
INFO - 2022-06-22 06:36:53 --> Output Class Initialized
INFO - 2022-06-22 06:36:53 --> URI Class Initialized
INFO - 2022-06-22 06:36:53 --> Security Class Initialized
DEBUG - 2022-06-22 06:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 06:36:53 --> Router Class Initialized
INFO - 2022-06-22 06:36:53 --> Input Class Initialized
INFO - 2022-06-22 06:36:53 --> Output Class Initialized
INFO - 2022-06-22 06:36:53 --> Language Class Initialized
INFO - 2022-06-22 06:36:53 --> Security Class Initialized
DEBUG - 2022-06-22 06:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 06:36:53 --> Loader Class Initialized
INFO - 2022-06-22 06:36:53 --> Input Class Initialized
INFO - 2022-06-22 06:36:53 --> Language Class Initialized
INFO - 2022-06-22 06:36:53 --> Loader Class Initialized
INFO - 2022-06-22 06:36:53 --> Helper loaded: url_helper
INFO - 2022-06-22 06:36:53 --> Helper loaded: file_helper
INFO - 2022-06-22 06:36:53 --> Helper loaded: url_helper
INFO - 2022-06-22 06:36:53 --> Helper loaded: file_helper
INFO - 2022-06-22 06:36:53 --> Database Driver Class Initialized
INFO - 2022-06-22 06:36:53 --> Database Driver Class Initialized
INFO - 2022-06-22 06:36:53 --> Email Class Initialized
DEBUG - 2022-06-22 06:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 06:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 06:36:53 --> Controller Class Initialized
INFO - 2022-06-22 06:36:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 06:36:53 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 06:36:53 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-22 06:36:53 --> Final output sent to browser
DEBUG - 2022-06-22 06:36:53 --> Total execution time: 0.0313
INFO - 2022-06-22 06:36:53 --> Email Class Initialized
DEBUG - 2022-06-22 06:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 06:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 06:36:53 --> Controller Class Initialized
INFO - 2022-06-22 06:36:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 06:36:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-22 06:36:53 --> test
INFO - 2022-06-22 06:36:53 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 06:36:53 --> Final output sent to browser
DEBUG - 2022-06-22 06:36:53 --> Total execution time: 0.1543
INFO - 2022-06-22 06:38:21 --> Config Class Initialized
INFO - 2022-06-22 06:38:21 --> Hooks Class Initialized
DEBUG - 2022-06-22 06:38:21 --> UTF-8 Support Enabled
INFO - 2022-06-22 06:38:21 --> Utf8 Class Initialized
INFO - 2022-06-22 06:38:21 --> URI Class Initialized
INFO - 2022-06-22 06:38:21 --> Router Class Initialized
INFO - 2022-06-22 06:38:21 --> Output Class Initialized
INFO - 2022-06-22 06:38:21 --> Security Class Initialized
DEBUG - 2022-06-22 06:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 06:38:21 --> Input Class Initialized
INFO - 2022-06-22 06:38:21 --> Language Class Initialized
INFO - 2022-06-22 06:38:21 --> Loader Class Initialized
INFO - 2022-06-22 06:38:21 --> Helper loaded: url_helper
INFO - 2022-06-22 06:38:21 --> Helper loaded: file_helper
INFO - 2022-06-22 06:38:21 --> Database Driver Class Initialized
INFO - 2022-06-22 06:38:21 --> Email Class Initialized
DEBUG - 2022-06-22 06:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 06:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 06:38:21 --> Controller Class Initialized
INFO - 2022-06-22 06:38:21 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 06:38:21 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 06:38:21 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-22 06:38:21 --> Final output sent to browser
DEBUG - 2022-06-22 06:38:21 --> Total execution time: 0.0570
INFO - 2022-06-22 06:38:24 --> Config Class Initialized
INFO - 2022-06-22 06:38:24 --> Hooks Class Initialized
DEBUG - 2022-06-22 06:38:24 --> UTF-8 Support Enabled
INFO - 2022-06-22 06:38:24 --> Utf8 Class Initialized
INFO - 2022-06-22 06:38:24 --> URI Class Initialized
INFO - 2022-06-22 06:38:24 --> Router Class Initialized
INFO - 2022-06-22 06:38:24 --> Output Class Initialized
INFO - 2022-06-22 06:38:24 --> Security Class Initialized
DEBUG - 2022-06-22 06:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 06:38:24 --> Input Class Initialized
INFO - 2022-06-22 06:38:24 --> Language Class Initialized
INFO - 2022-06-22 06:38:24 --> Loader Class Initialized
INFO - 2022-06-22 06:38:24 --> Helper loaded: url_helper
INFO - 2022-06-22 06:38:24 --> Helper loaded: file_helper
INFO - 2022-06-22 06:38:24 --> Database Driver Class Initialized
INFO - 2022-06-22 06:38:24 --> Email Class Initialized
DEBUG - 2022-06-22 06:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 06:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 06:38:24 --> Controller Class Initialized
INFO - 2022-06-22 06:38:24 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 06:38:24 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 06:38:24 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-22 06:38:24 --> Final output sent to browser
DEBUG - 2022-06-22 06:38:24 --> Total execution time: 0.1348
INFO - 2022-06-22 06:38:41 --> Config Class Initialized
INFO - 2022-06-22 06:38:41 --> Hooks Class Initialized
INFO - 2022-06-22 06:38:41 --> Config Class Initialized
INFO - 2022-06-22 06:38:41 --> Hooks Class Initialized
DEBUG - 2022-06-22 06:38:41 --> UTF-8 Support Enabled
INFO - 2022-06-22 06:38:41 --> Utf8 Class Initialized
DEBUG - 2022-06-22 06:38:41 --> UTF-8 Support Enabled
INFO - 2022-06-22 06:38:41 --> Utf8 Class Initialized
INFO - 2022-06-22 06:38:41 --> URI Class Initialized
INFO - 2022-06-22 06:38:41 --> URI Class Initialized
INFO - 2022-06-22 06:38:41 --> Router Class Initialized
INFO - 2022-06-22 06:38:41 --> Router Class Initialized
INFO - 2022-06-22 06:38:41 --> Output Class Initialized
INFO - 2022-06-22 06:38:41 --> Output Class Initialized
INFO - 2022-06-22 06:38:41 --> Security Class Initialized
INFO - 2022-06-22 06:38:41 --> Security Class Initialized
DEBUG - 2022-06-22 06:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-22 06:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 06:38:41 --> Input Class Initialized
INFO - 2022-06-22 06:38:41 --> Input Class Initialized
INFO - 2022-06-22 06:38:41 --> Language Class Initialized
INFO - 2022-06-22 06:38:41 --> Language Class Initialized
INFO - 2022-06-22 06:38:41 --> Loader Class Initialized
INFO - 2022-06-22 06:38:41 --> Loader Class Initialized
INFO - 2022-06-22 06:38:41 --> Helper loaded: url_helper
INFO - 2022-06-22 06:38:41 --> Helper loaded: url_helper
INFO - 2022-06-22 06:38:41 --> Helper loaded: file_helper
INFO - 2022-06-22 06:38:41 --> Helper loaded: file_helper
INFO - 2022-06-22 06:38:41 --> Database Driver Class Initialized
INFO - 2022-06-22 06:38:41 --> Database Driver Class Initialized
INFO - 2022-06-22 06:38:41 --> Email Class Initialized
DEBUG - 2022-06-22 06:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 06:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 06:38:41 --> Controller Class Initialized
INFO - 2022-06-22 06:38:41 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 06:38:41 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 06:38:41 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-22 06:38:41 --> Final output sent to browser
DEBUG - 2022-06-22 06:38:41 --> Total execution time: 0.0237
INFO - 2022-06-22 06:38:42 --> Email Class Initialized
DEBUG - 2022-06-22 06:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 06:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 06:38:42 --> Controller Class Initialized
INFO - 2022-06-22 06:38:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 06:38:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-22 06:38:42 --> test
INFO - 2022-06-22 06:38:42 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 06:38:42 --> Final output sent to browser
DEBUG - 2022-06-22 06:38:42 --> Total execution time: 0.1463
INFO - 2022-06-22 06:38:47 --> Config Class Initialized
INFO - 2022-06-22 06:38:47 --> Hooks Class Initialized
DEBUG - 2022-06-22 06:38:47 --> UTF-8 Support Enabled
INFO - 2022-06-22 06:38:47 --> Utf8 Class Initialized
INFO - 2022-06-22 06:38:47 --> URI Class Initialized
INFO - 2022-06-22 06:38:47 --> Router Class Initialized
INFO - 2022-06-22 06:38:47 --> Output Class Initialized
INFO - 2022-06-22 06:38:47 --> Security Class Initialized
DEBUG - 2022-06-22 06:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 06:38:47 --> Input Class Initialized
INFO - 2022-06-22 06:38:47 --> Language Class Initialized
INFO - 2022-06-22 06:38:47 --> Loader Class Initialized
INFO - 2022-06-22 06:38:47 --> Helper loaded: url_helper
INFO - 2022-06-22 06:38:47 --> Helper loaded: file_helper
INFO - 2022-06-22 06:38:47 --> Database Driver Class Initialized
INFO - 2022-06-22 06:38:47 --> Email Class Initialized
DEBUG - 2022-06-22 06:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 06:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 06:38:47 --> Controller Class Initialized
INFO - 2022-06-22 06:38:47 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 06:38:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-22 06:38:47 --> test
ERROR - 2022-06-22 06:38:47 --> Query error: Column 'ud_name' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_name`, `ud_age`, `ud_gender`, `ud_time`) VALUES (NULL, NULL, NULL, NULL)
INFO - 2022-06-22 06:38:47 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-22 06:40:36 --> Config Class Initialized
INFO - 2022-06-22 06:40:36 --> Hooks Class Initialized
DEBUG - 2022-06-22 06:40:36 --> UTF-8 Support Enabled
INFO - 2022-06-22 06:40:36 --> Utf8 Class Initialized
INFO - 2022-06-22 06:40:36 --> URI Class Initialized
INFO - 2022-06-22 06:40:36 --> Router Class Initialized
INFO - 2022-06-22 06:40:36 --> Output Class Initialized
INFO - 2022-06-22 06:40:36 --> Security Class Initialized
DEBUG - 2022-06-22 06:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 06:40:36 --> Input Class Initialized
INFO - 2022-06-22 06:40:36 --> Language Class Initialized
INFO - 2022-06-22 06:40:36 --> Loader Class Initialized
INFO - 2022-06-22 06:40:36 --> Helper loaded: url_helper
INFO - 2022-06-22 06:40:36 --> Helper loaded: file_helper
INFO - 2022-06-22 06:40:36 --> Database Driver Class Initialized
INFO - 2022-06-22 06:40:36 --> Email Class Initialized
DEBUG - 2022-06-22 06:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 06:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 06:40:36 --> Controller Class Initialized
INFO - 2022-06-22 06:40:36 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 06:40:36 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 06:40:36 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-22 06:40:36 --> Final output sent to browser
DEBUG - 2022-06-22 06:40:36 --> Total execution time: 0.1005
INFO - 2022-06-22 06:40:40 --> Config Class Initialized
INFO - 2022-06-22 06:40:40 --> Hooks Class Initialized
DEBUG - 2022-06-22 06:40:40 --> UTF-8 Support Enabled
INFO - 2022-06-22 06:40:40 --> Utf8 Class Initialized
INFO - 2022-06-22 06:40:40 --> URI Class Initialized
INFO - 2022-06-22 06:40:40 --> Router Class Initialized
INFO - 2022-06-22 06:40:40 --> Output Class Initialized
INFO - 2022-06-22 06:40:40 --> Security Class Initialized
DEBUG - 2022-06-22 06:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 06:40:40 --> Input Class Initialized
INFO - 2022-06-22 06:40:40 --> Language Class Initialized
INFO - 2022-06-22 06:40:40 --> Loader Class Initialized
INFO - 2022-06-22 06:40:40 --> Helper loaded: url_helper
INFO - 2022-06-22 06:40:40 --> Helper loaded: file_helper
INFO - 2022-06-22 06:40:40 --> Database Driver Class Initialized
INFO - 2022-06-22 06:40:40 --> Email Class Initialized
DEBUG - 2022-06-22 06:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 06:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 06:40:40 --> Controller Class Initialized
INFO - 2022-06-22 06:40:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 06:40:40 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 06:40:40 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-22 06:40:40 --> Final output sent to browser
DEBUG - 2022-06-22 06:40:40 --> Total execution time: 0.0451
INFO - 2022-06-22 06:40:43 --> Config Class Initialized
INFO - 2022-06-22 06:40:43 --> Hooks Class Initialized
DEBUG - 2022-06-22 06:40:43 --> UTF-8 Support Enabled
INFO - 2022-06-22 06:40:43 --> Utf8 Class Initialized
INFO - 2022-06-22 06:40:43 --> URI Class Initialized
INFO - 2022-06-22 06:40:43 --> Router Class Initialized
INFO - 2022-06-22 06:40:43 --> Output Class Initialized
INFO - 2022-06-22 06:40:43 --> Security Class Initialized
DEBUG - 2022-06-22 06:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 06:40:43 --> Input Class Initialized
INFO - 2022-06-22 06:40:43 --> Language Class Initialized
INFO - 2022-06-22 06:40:43 --> Loader Class Initialized
INFO - 2022-06-22 06:40:43 --> Helper loaded: url_helper
INFO - 2022-06-22 06:40:43 --> Helper loaded: file_helper
INFO - 2022-06-22 06:40:43 --> Database Driver Class Initialized
INFO - 2022-06-22 06:40:43 --> Email Class Initialized
DEBUG - 2022-06-22 06:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 06:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 06:40:43 --> Controller Class Initialized
INFO - 2022-06-22 06:40:43 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 06:40:43 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 06:40:43 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-22 06:40:43 --> Final output sent to browser
DEBUG - 2022-06-22 06:40:43 --> Total execution time: 0.1308
INFO - 2022-06-22 06:40:45 --> Config Class Initialized
INFO - 2022-06-22 06:40:45 --> Hooks Class Initialized
DEBUG - 2022-06-22 06:40:45 --> UTF-8 Support Enabled
INFO - 2022-06-22 06:40:45 --> Utf8 Class Initialized
INFO - 2022-06-22 06:40:45 --> URI Class Initialized
INFO - 2022-06-22 06:40:45 --> Router Class Initialized
INFO - 2022-06-22 06:40:45 --> Output Class Initialized
INFO - 2022-06-22 06:40:45 --> Security Class Initialized
DEBUG - 2022-06-22 06:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 06:40:45 --> Input Class Initialized
INFO - 2022-06-22 06:40:45 --> Language Class Initialized
INFO - 2022-06-22 06:40:45 --> Loader Class Initialized
INFO - 2022-06-22 06:40:45 --> Helper loaded: url_helper
INFO - 2022-06-22 06:40:45 --> Helper loaded: file_helper
INFO - 2022-06-22 06:40:45 --> Database Driver Class Initialized
INFO - 2022-06-22 06:40:45 --> Email Class Initialized
DEBUG - 2022-06-22 06:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 06:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 06:40:45 --> Controller Class Initialized
INFO - 2022-06-22 06:40:45 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 06:40:45 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 06:40:45 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-22 06:40:45 --> Final output sent to browser
DEBUG - 2022-06-22 06:40:45 --> Total execution time: 0.0150
INFO - 2022-06-22 06:41:00 --> Config Class Initialized
INFO - 2022-06-22 06:41:00 --> Hooks Class Initialized
INFO - 2022-06-22 06:41:00 --> Config Class Initialized
INFO - 2022-06-22 06:41:00 --> Hooks Class Initialized
DEBUG - 2022-06-22 06:41:00 --> UTF-8 Support Enabled
INFO - 2022-06-22 06:41:00 --> Utf8 Class Initialized
DEBUG - 2022-06-22 06:41:00 --> UTF-8 Support Enabled
INFO - 2022-06-22 06:41:00 --> Utf8 Class Initialized
INFO - 2022-06-22 06:41:00 --> URI Class Initialized
INFO - 2022-06-22 06:41:00 --> URI Class Initialized
INFO - 2022-06-22 06:41:00 --> Router Class Initialized
INFO - 2022-06-22 06:41:00 --> Router Class Initialized
INFO - 2022-06-22 06:41:00 --> Output Class Initialized
INFO - 2022-06-22 06:41:00 --> Output Class Initialized
INFO - 2022-06-22 06:41:00 --> Security Class Initialized
INFO - 2022-06-22 06:41:00 --> Security Class Initialized
DEBUG - 2022-06-22 06:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 06:41:00 --> Input Class Initialized
DEBUG - 2022-06-22 06:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 06:41:00 --> Input Class Initialized
INFO - 2022-06-22 06:41:00 --> Language Class Initialized
INFO - 2022-06-22 06:41:00 --> Language Class Initialized
INFO - 2022-06-22 06:41:00 --> Loader Class Initialized
INFO - 2022-06-22 06:41:00 --> Loader Class Initialized
INFO - 2022-06-22 06:41:00 --> Helper loaded: url_helper
INFO - 2022-06-22 06:41:00 --> Helper loaded: url_helper
INFO - 2022-06-22 06:41:00 --> Helper loaded: file_helper
INFO - 2022-06-22 06:41:00 --> Helper loaded: file_helper
INFO - 2022-06-22 06:41:00 --> Database Driver Class Initialized
INFO - 2022-06-22 06:41:00 --> Database Driver Class Initialized
INFO - 2022-06-22 06:41:00 --> Email Class Initialized
INFO - 2022-06-22 06:41:00 --> Email Class Initialized
DEBUG - 2022-06-22 06:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-22 06:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 06:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 06:41:00 --> Controller Class Initialized
INFO - 2022-06-22 06:41:00 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 06:41:00 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 06:41:00 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-22 06:41:00 --> Final output sent to browser
DEBUG - 2022-06-22 06:41:00 --> Total execution time: 0.3379
INFO - 2022-06-22 06:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 06:41:00 --> Controller Class Initialized
INFO - 2022-06-22 06:41:00 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 06:41:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-22 06:41:00 --> test
INFO - 2022-06-22 06:41:00 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 06:41:00 --> Final output sent to browser
DEBUG - 2022-06-22 06:41:00 --> Total execution time: 0.3449
INFO - 2022-06-22 06:42:17 --> Config Class Initialized
INFO - 2022-06-22 06:42:17 --> Hooks Class Initialized
DEBUG - 2022-06-22 06:42:17 --> UTF-8 Support Enabled
INFO - 2022-06-22 06:42:17 --> Utf8 Class Initialized
INFO - 2022-06-22 06:42:17 --> URI Class Initialized
INFO - 2022-06-22 06:42:17 --> Router Class Initialized
INFO - 2022-06-22 06:42:17 --> Output Class Initialized
INFO - 2022-06-22 06:42:17 --> Security Class Initialized
DEBUG - 2022-06-22 06:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 06:42:17 --> Input Class Initialized
INFO - 2022-06-22 06:42:17 --> Language Class Initialized
INFO - 2022-06-22 06:42:17 --> Loader Class Initialized
INFO - 2022-06-22 06:42:17 --> Helper loaded: url_helper
INFO - 2022-06-22 06:42:17 --> Helper loaded: file_helper
INFO - 2022-06-22 06:42:17 --> Database Driver Class Initialized
INFO - 2022-06-22 06:42:17 --> Email Class Initialized
DEBUG - 2022-06-22 06:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 06:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 06:42:17 --> Controller Class Initialized
INFO - 2022-06-22 06:42:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 06:42:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 06:42:17 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-22 06:42:17 --> Final output sent to browser
DEBUG - 2022-06-22 06:42:17 --> Total execution time: 0.0235
INFO - 2022-06-22 06:42:28 --> Config Class Initialized
INFO - 2022-06-22 06:42:28 --> Config Class Initialized
INFO - 2022-06-22 06:42:28 --> Hooks Class Initialized
INFO - 2022-06-22 06:42:28 --> Hooks Class Initialized
DEBUG - 2022-06-22 06:42:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-22 06:42:28 --> UTF-8 Support Enabled
INFO - 2022-06-22 06:42:28 --> Utf8 Class Initialized
INFO - 2022-06-22 06:42:28 --> Utf8 Class Initialized
INFO - 2022-06-22 06:42:28 --> URI Class Initialized
INFO - 2022-06-22 06:42:28 --> URI Class Initialized
INFO - 2022-06-22 06:42:28 --> Router Class Initialized
INFO - 2022-06-22 06:42:28 --> Router Class Initialized
INFO - 2022-06-22 06:42:28 --> Output Class Initialized
INFO - 2022-06-22 06:42:28 --> Output Class Initialized
INFO - 2022-06-22 06:42:28 --> Security Class Initialized
INFO - 2022-06-22 06:42:28 --> Security Class Initialized
DEBUG - 2022-06-22 06:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-22 06:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 06:42:28 --> Input Class Initialized
INFO - 2022-06-22 06:42:28 --> Input Class Initialized
INFO - 2022-06-22 06:42:28 --> Language Class Initialized
INFO - 2022-06-22 06:42:28 --> Language Class Initialized
INFO - 2022-06-22 06:42:28 --> Loader Class Initialized
INFO - 2022-06-22 06:42:28 --> Loader Class Initialized
INFO - 2022-06-22 06:42:28 --> Helper loaded: url_helper
INFO - 2022-06-22 06:42:28 --> Helper loaded: url_helper
INFO - 2022-06-22 06:42:28 --> Helper loaded: file_helper
INFO - 2022-06-22 06:42:28 --> Helper loaded: file_helper
INFO - 2022-06-22 06:42:28 --> Database Driver Class Initialized
INFO - 2022-06-22 06:42:28 --> Database Driver Class Initialized
INFO - 2022-06-22 06:42:28 --> Email Class Initialized
DEBUG - 2022-06-22 06:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 06:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 06:42:28 --> Controller Class Initialized
INFO - 2022-06-22 06:42:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 06:42:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 06:42:28 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
DEBUG - 2022-06-22 06:42:28 --> test
INFO - 2022-06-22 06:42:28 --> Final output sent to browser
DEBUG - 2022-06-22 06:42:28 --> Total execution time: 0.0289
INFO - 2022-06-22 06:42:28 --> Email Class Initialized
DEBUG - 2022-06-22 06:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 06:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 06:42:28 --> Controller Class Initialized
INFO - 2022-06-22 06:42:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 06:42:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 06:42:28 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-22 06:42:28 --> Final output sent to browser
DEBUG - 2022-06-22 06:42:28 --> Total execution time: 0.1746
INFO - 2022-06-22 07:28:36 --> Config Class Initialized
INFO - 2022-06-22 07:28:36 --> Hooks Class Initialized
DEBUG - 2022-06-22 07:28:36 --> UTF-8 Support Enabled
INFO - 2022-06-22 07:28:36 --> Utf8 Class Initialized
INFO - 2022-06-22 07:28:36 --> URI Class Initialized
INFO - 2022-06-22 07:28:36 --> Router Class Initialized
INFO - 2022-06-22 07:28:36 --> Output Class Initialized
INFO - 2022-06-22 07:28:36 --> Security Class Initialized
DEBUG - 2022-06-22 07:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 07:28:36 --> Input Class Initialized
INFO - 2022-06-22 07:28:36 --> Language Class Initialized
INFO - 2022-06-22 07:28:36 --> Loader Class Initialized
INFO - 2022-06-22 07:28:36 --> Helper loaded: url_helper
INFO - 2022-06-22 07:28:36 --> Helper loaded: file_helper
INFO - 2022-06-22 07:28:36 --> Database Driver Class Initialized
INFO - 2022-06-22 07:28:36 --> Email Class Initialized
DEBUG - 2022-06-22 07:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 07:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 07:28:36 --> Controller Class Initialized
INFO - 2022-06-22 07:28:36 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 07:28:36 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 07:28:36 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-22 07:28:36 --> Final output sent to browser
DEBUG - 2022-06-22 07:28:36 --> Total execution time: 0.0364
INFO - 2022-06-22 07:28:38 --> Config Class Initialized
INFO - 2022-06-22 07:28:38 --> Hooks Class Initialized
DEBUG - 2022-06-22 07:28:38 --> UTF-8 Support Enabled
INFO - 2022-06-22 07:28:38 --> Utf8 Class Initialized
INFO - 2022-06-22 07:28:38 --> URI Class Initialized
INFO - 2022-06-22 07:28:38 --> Router Class Initialized
INFO - 2022-06-22 07:28:38 --> Output Class Initialized
INFO - 2022-06-22 07:28:38 --> Security Class Initialized
DEBUG - 2022-06-22 07:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 07:28:38 --> Input Class Initialized
INFO - 2022-06-22 07:28:38 --> Language Class Initialized
ERROR - 2022-06-22 07:28:38 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-22 07:28:39 --> Config Class Initialized
INFO - 2022-06-22 07:28:39 --> Hooks Class Initialized
DEBUG - 2022-06-22 07:28:39 --> UTF-8 Support Enabled
INFO - 2022-06-22 07:28:39 --> Utf8 Class Initialized
INFO - 2022-06-22 07:28:39 --> URI Class Initialized
INFO - 2022-06-22 07:28:39 --> Router Class Initialized
INFO - 2022-06-22 07:28:39 --> Output Class Initialized
INFO - 2022-06-22 07:28:39 --> Security Class Initialized
DEBUG - 2022-06-22 07:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 07:28:39 --> Input Class Initialized
INFO - 2022-06-22 07:28:39 --> Language Class Initialized
ERROR - 2022-06-22 07:28:39 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-22 08:49:13 --> Config Class Initialized
INFO - 2022-06-22 08:49:13 --> Hooks Class Initialized
DEBUG - 2022-06-22 08:49:13 --> UTF-8 Support Enabled
INFO - 2022-06-22 08:49:13 --> Utf8 Class Initialized
INFO - 2022-06-22 08:49:13 --> URI Class Initialized
INFO - 2022-06-22 08:49:13 --> Router Class Initialized
INFO - 2022-06-22 08:49:13 --> Output Class Initialized
INFO - 2022-06-22 08:49:13 --> Security Class Initialized
DEBUG - 2022-06-22 08:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 08:49:13 --> Input Class Initialized
INFO - 2022-06-22 08:49:13 --> Language Class Initialized
ERROR - 2022-06-22 08:49:13 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file C:\wamp64\www\qr\application\controllers\Tokenctrl.php 48
INFO - 2022-06-22 08:49:59 --> Config Class Initialized
INFO - 2022-06-22 08:49:59 --> Hooks Class Initialized
DEBUG - 2022-06-22 08:49:59 --> UTF-8 Support Enabled
INFO - 2022-06-22 08:49:59 --> Utf8 Class Initialized
INFO - 2022-06-22 08:49:59 --> URI Class Initialized
INFO - 2022-06-22 08:49:59 --> Router Class Initialized
INFO - 2022-06-22 08:49:59 --> Output Class Initialized
INFO - 2022-06-22 08:49:59 --> Security Class Initialized
DEBUG - 2022-06-22 08:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 08:49:59 --> Input Class Initialized
INFO - 2022-06-22 08:49:59 --> Language Class Initialized
INFO - 2022-06-22 08:49:59 --> Loader Class Initialized
INFO - 2022-06-22 08:49:59 --> Helper loaded: url_helper
INFO - 2022-06-22 08:49:59 --> Helper loaded: file_helper
INFO - 2022-06-22 08:49:59 --> Database Driver Class Initialized
INFO - 2022-06-22 08:50:00 --> Email Class Initialized
DEBUG - 2022-06-22 08:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 08:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 08:50:00 --> Controller Class Initialized
INFO - 2022-06-22 08:50:00 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 08:50:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 08:50:00 --> Severity: Notice --> Undefined property: Tokenctrl::$model C:\wamp64\www\qr\application\controllers\Tokenctrl.php 28
ERROR - 2022-06-22 08:50:00 --> Severity: error --> Exception: Call to a member function current() on null C:\wamp64\www\qr\application\controllers\Tokenctrl.php 28
INFO - 2022-06-22 08:51:39 --> Config Class Initialized
INFO - 2022-06-22 08:51:39 --> Hooks Class Initialized
DEBUG - 2022-06-22 08:51:39 --> UTF-8 Support Enabled
INFO - 2022-06-22 08:51:39 --> Utf8 Class Initialized
INFO - 2022-06-22 08:51:39 --> URI Class Initialized
INFO - 2022-06-22 08:51:39 --> Router Class Initialized
INFO - 2022-06-22 08:51:39 --> Output Class Initialized
INFO - 2022-06-22 08:51:39 --> Security Class Initialized
DEBUG - 2022-06-22 08:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 08:51:39 --> Input Class Initialized
INFO - 2022-06-22 08:51:39 --> Language Class Initialized
INFO - 2022-06-22 08:51:39 --> Loader Class Initialized
INFO - 2022-06-22 08:51:39 --> Helper loaded: url_helper
INFO - 2022-06-22 08:51:39 --> Helper loaded: file_helper
INFO - 2022-06-22 08:51:39 --> Database Driver Class Initialized
INFO - 2022-06-22 08:51:39 --> Email Class Initialized
DEBUG - 2022-06-22 08:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 08:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 08:51:39 --> Controller Class Initialized
INFO - 2022-06-22 08:51:39 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 08:51:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 08:51:39 --> Severity: Notice --> Undefined property: Tokenctrl::$model C:\wamp64\www\qr\application\controllers\Tokenctrl.php 28
ERROR - 2022-06-22 08:51:39 --> Severity: error --> Exception: Call to a member function current() on null C:\wamp64\www\qr\application\controllers\Tokenctrl.php 28
INFO - 2022-06-22 08:51:42 --> Config Class Initialized
INFO - 2022-06-22 08:51:42 --> Hooks Class Initialized
DEBUG - 2022-06-22 08:51:42 --> UTF-8 Support Enabled
INFO - 2022-06-22 08:51:42 --> Utf8 Class Initialized
INFO - 2022-06-22 08:51:42 --> URI Class Initialized
INFO - 2022-06-22 08:51:42 --> Router Class Initialized
INFO - 2022-06-22 08:51:42 --> Output Class Initialized
INFO - 2022-06-22 08:51:42 --> Security Class Initialized
DEBUG - 2022-06-22 08:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 08:51:42 --> Input Class Initialized
INFO - 2022-06-22 08:51:42 --> Language Class Initialized
INFO - 2022-06-22 08:51:42 --> Loader Class Initialized
INFO - 2022-06-22 08:51:42 --> Helper loaded: url_helper
INFO - 2022-06-22 08:51:42 --> Helper loaded: file_helper
INFO - 2022-06-22 08:51:42 --> Database Driver Class Initialized
INFO - 2022-06-22 08:51:42 --> Email Class Initialized
DEBUG - 2022-06-22 08:51:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 08:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 08:51:42 --> Controller Class Initialized
INFO - 2022-06-22 08:51:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 08:51:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 08:51:42 --> Severity: Notice --> Undefined property: Tokenctrl::$model C:\wamp64\www\qr\application\controllers\Tokenctrl.php 28
ERROR - 2022-06-22 08:51:42 --> Severity: error --> Exception: Call to a member function current() on null C:\wamp64\www\qr\application\controllers\Tokenctrl.php 28
INFO - 2022-06-22 08:52:37 --> Config Class Initialized
INFO - 2022-06-22 08:52:37 --> Hooks Class Initialized
DEBUG - 2022-06-22 08:52:37 --> UTF-8 Support Enabled
INFO - 2022-06-22 08:52:37 --> Utf8 Class Initialized
INFO - 2022-06-22 08:52:37 --> URI Class Initialized
INFO - 2022-06-22 08:52:37 --> Router Class Initialized
INFO - 2022-06-22 08:52:37 --> Output Class Initialized
INFO - 2022-06-22 08:52:37 --> Security Class Initialized
DEBUG - 2022-06-22 08:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 08:52:37 --> Input Class Initialized
INFO - 2022-06-22 08:52:37 --> Language Class Initialized
INFO - 2022-06-22 08:52:37 --> Loader Class Initialized
INFO - 2022-06-22 08:52:37 --> Helper loaded: url_helper
INFO - 2022-06-22 08:52:37 --> Helper loaded: file_helper
INFO - 2022-06-22 08:52:37 --> Database Driver Class Initialized
INFO - 2022-06-22 08:52:37 --> Email Class Initialized
DEBUG - 2022-06-22 08:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 08:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 08:52:37 --> Controller Class Initialized
INFO - 2022-06-22 08:52:37 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 08:52:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 08:52:37 --> Severity: Notice --> Undefined property: Tokenctrl::$model C:\wamp64\www\qr\application\controllers\Tokenctrl.php 28
ERROR - 2022-06-22 08:52:37 --> Severity: error --> Exception: Call to a member function current() on null C:\wamp64\www\qr\application\controllers\Tokenctrl.php 28
INFO - 2022-06-22 08:52:40 --> Config Class Initialized
INFO - 2022-06-22 08:52:40 --> Hooks Class Initialized
DEBUG - 2022-06-22 08:52:40 --> UTF-8 Support Enabled
INFO - 2022-06-22 08:52:40 --> Utf8 Class Initialized
INFO - 2022-06-22 08:52:40 --> URI Class Initialized
INFO - 2022-06-22 08:52:40 --> Router Class Initialized
INFO - 2022-06-22 08:52:40 --> Output Class Initialized
INFO - 2022-06-22 08:52:40 --> Security Class Initialized
DEBUG - 2022-06-22 08:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 08:52:40 --> Input Class Initialized
INFO - 2022-06-22 08:52:40 --> Language Class Initialized
INFO - 2022-06-22 08:52:40 --> Loader Class Initialized
INFO - 2022-06-22 08:52:40 --> Helper loaded: url_helper
INFO - 2022-06-22 08:52:40 --> Helper loaded: file_helper
INFO - 2022-06-22 08:52:40 --> Database Driver Class Initialized
INFO - 2022-06-22 08:52:40 --> Email Class Initialized
DEBUG - 2022-06-22 08:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 08:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 08:52:40 --> Controller Class Initialized
INFO - 2022-06-22 08:52:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 08:52:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 08:52:40 --> Severity: Notice --> Undefined property: Tokenctrl::$model C:\wamp64\www\qr\application\controllers\Tokenctrl.php 28
ERROR - 2022-06-22 08:52:40 --> Severity: error --> Exception: Call to a member function current() on null C:\wamp64\www\qr\application\controllers\Tokenctrl.php 28
INFO - 2022-06-22 08:52:41 --> Config Class Initialized
INFO - 2022-06-22 08:52:41 --> Hooks Class Initialized
DEBUG - 2022-06-22 08:52:41 --> UTF-8 Support Enabled
INFO - 2022-06-22 08:52:41 --> Utf8 Class Initialized
INFO - 2022-06-22 08:52:41 --> URI Class Initialized
INFO - 2022-06-22 08:52:41 --> Router Class Initialized
INFO - 2022-06-22 08:52:41 --> Output Class Initialized
INFO - 2022-06-22 08:52:41 --> Security Class Initialized
DEBUG - 2022-06-22 08:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 08:52:41 --> Input Class Initialized
INFO - 2022-06-22 08:52:41 --> Language Class Initialized
INFO - 2022-06-22 08:52:41 --> Loader Class Initialized
INFO - 2022-06-22 08:52:41 --> Helper loaded: url_helper
INFO - 2022-06-22 08:52:41 --> Helper loaded: file_helper
INFO - 2022-06-22 08:52:41 --> Database Driver Class Initialized
INFO - 2022-06-22 08:52:41 --> Email Class Initialized
DEBUG - 2022-06-22 08:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 08:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 08:52:41 --> Controller Class Initialized
INFO - 2022-06-22 08:52:41 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 08:52:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 08:52:41 --> Severity: Notice --> Undefined property: Tokenctrl::$model C:\wamp64\www\qr\application\controllers\Tokenctrl.php 28
ERROR - 2022-06-22 08:52:41 --> Severity: error --> Exception: Call to a member function current() on null C:\wamp64\www\qr\application\controllers\Tokenctrl.php 28
INFO - 2022-06-22 08:52:43 --> Config Class Initialized
INFO - 2022-06-22 08:52:43 --> Hooks Class Initialized
DEBUG - 2022-06-22 08:52:43 --> UTF-8 Support Enabled
INFO - 2022-06-22 08:52:43 --> Utf8 Class Initialized
INFO - 2022-06-22 08:52:43 --> URI Class Initialized
INFO - 2022-06-22 08:52:43 --> Router Class Initialized
INFO - 2022-06-22 08:52:43 --> Output Class Initialized
INFO - 2022-06-22 08:52:43 --> Security Class Initialized
DEBUG - 2022-06-22 08:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 08:52:43 --> Input Class Initialized
INFO - 2022-06-22 08:52:43 --> Language Class Initialized
INFO - 2022-06-22 08:52:43 --> Loader Class Initialized
INFO - 2022-06-22 08:52:43 --> Helper loaded: url_helper
INFO - 2022-06-22 08:52:43 --> Helper loaded: file_helper
INFO - 2022-06-22 08:52:43 --> Database Driver Class Initialized
INFO - 2022-06-22 08:52:43 --> Email Class Initialized
DEBUG - 2022-06-22 08:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 08:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 08:52:43 --> Controller Class Initialized
INFO - 2022-06-22 08:52:43 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 08:52:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 08:52:43 --> Severity: Notice --> Undefined property: Tokenctrl::$model C:\wamp64\www\qr\application\controllers\Tokenctrl.php 28
ERROR - 2022-06-22 08:52:43 --> Severity: error --> Exception: Call to a member function current() on null C:\wamp64\www\qr\application\controllers\Tokenctrl.php 28
INFO - 2022-06-22 08:52:45 --> Config Class Initialized
INFO - 2022-06-22 08:52:45 --> Hooks Class Initialized
DEBUG - 2022-06-22 08:52:45 --> UTF-8 Support Enabled
INFO - 2022-06-22 08:52:45 --> Utf8 Class Initialized
INFO - 2022-06-22 08:52:45 --> URI Class Initialized
INFO - 2022-06-22 08:52:45 --> Router Class Initialized
INFO - 2022-06-22 08:52:45 --> Output Class Initialized
INFO - 2022-06-22 08:52:45 --> Security Class Initialized
DEBUG - 2022-06-22 08:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 08:52:45 --> Input Class Initialized
INFO - 2022-06-22 08:52:45 --> Language Class Initialized
INFO - 2022-06-22 08:52:45 --> Loader Class Initialized
INFO - 2022-06-22 08:52:45 --> Helper loaded: url_helper
INFO - 2022-06-22 08:52:45 --> Helper loaded: file_helper
INFO - 2022-06-22 08:52:45 --> Database Driver Class Initialized
INFO - 2022-06-22 08:52:45 --> Email Class Initialized
DEBUG - 2022-06-22 08:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 08:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 08:52:45 --> Controller Class Initialized
INFO - 2022-06-22 08:52:45 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 08:52:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 08:52:45 --> Severity: Notice --> Undefined property: Tokenctrl::$model C:\wamp64\www\qr\application\controllers\Tokenctrl.php 28
ERROR - 2022-06-22 08:52:45 --> Severity: error --> Exception: Call to a member function current() on null C:\wamp64\www\qr\application\controllers\Tokenctrl.php 28
INFO - 2022-06-22 08:58:55 --> Config Class Initialized
INFO - 2022-06-22 08:58:55 --> Hooks Class Initialized
DEBUG - 2022-06-22 08:58:55 --> UTF-8 Support Enabled
INFO - 2022-06-22 08:58:55 --> Utf8 Class Initialized
INFO - 2022-06-22 08:58:55 --> URI Class Initialized
INFO - 2022-06-22 08:58:55 --> Router Class Initialized
INFO - 2022-06-22 08:58:55 --> Output Class Initialized
INFO - 2022-06-22 08:58:55 --> Security Class Initialized
DEBUG - 2022-06-22 08:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 08:58:55 --> Input Class Initialized
INFO - 2022-06-22 08:58:55 --> Language Class Initialized
INFO - 2022-06-22 08:58:55 --> Loader Class Initialized
INFO - 2022-06-22 08:58:55 --> Helper loaded: url_helper
INFO - 2022-06-22 08:58:55 --> Helper loaded: file_helper
INFO - 2022-06-22 08:58:56 --> Database Driver Class Initialized
INFO - 2022-06-22 08:58:56 --> Email Class Initialized
DEBUG - 2022-06-22 08:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 08:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 08:58:56 --> Controller Class Initialized
INFO - 2022-06-22 08:58:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 08:58:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 08:58:56 --> Severity: Notice --> Undefined property: Tokenctrl::$model C:\wamp64\www\qr\application\controllers\Tokenctrl.php 28
ERROR - 2022-06-22 08:58:56 --> Severity: error --> Exception: Call to a member function current() on null C:\wamp64\www\qr\application\controllers\Tokenctrl.php 28
INFO - 2022-06-22 08:59:42 --> Config Class Initialized
INFO - 2022-06-22 08:59:42 --> Hooks Class Initialized
DEBUG - 2022-06-22 08:59:42 --> UTF-8 Support Enabled
INFO - 2022-06-22 08:59:42 --> Utf8 Class Initialized
INFO - 2022-06-22 08:59:42 --> URI Class Initialized
INFO - 2022-06-22 08:59:42 --> Router Class Initialized
INFO - 2022-06-22 08:59:42 --> Output Class Initialized
INFO - 2022-06-22 08:59:42 --> Security Class Initialized
DEBUG - 2022-06-22 08:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 08:59:42 --> Input Class Initialized
INFO - 2022-06-22 08:59:42 --> Language Class Initialized
INFO - 2022-06-22 08:59:42 --> Loader Class Initialized
INFO - 2022-06-22 08:59:42 --> Helper loaded: url_helper
INFO - 2022-06-22 08:59:42 --> Helper loaded: file_helper
INFO - 2022-06-22 08:59:42 --> Database Driver Class Initialized
INFO - 2022-06-22 08:59:42 --> Email Class Initialized
DEBUG - 2022-06-22 08:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 08:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 08:59:42 --> Controller Class Initialized
INFO - 2022-06-22 08:59:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 08:59:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 08:59:42 --> Severity: error --> Exception: Cannot use object of type CI_DB_mysqli_result as array C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
INFO - 2022-06-22 09:00:12 --> Config Class Initialized
INFO - 2022-06-22 09:00:12 --> Hooks Class Initialized
DEBUG - 2022-06-22 09:00:12 --> UTF-8 Support Enabled
INFO - 2022-06-22 09:00:12 --> Utf8 Class Initialized
INFO - 2022-06-22 09:00:12 --> URI Class Initialized
INFO - 2022-06-22 09:00:12 --> Router Class Initialized
INFO - 2022-06-22 09:00:12 --> Output Class Initialized
INFO - 2022-06-22 09:00:12 --> Security Class Initialized
DEBUG - 2022-06-22 09:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 09:00:12 --> Input Class Initialized
INFO - 2022-06-22 09:00:12 --> Language Class Initialized
INFO - 2022-06-22 09:00:12 --> Loader Class Initialized
INFO - 2022-06-22 09:00:12 --> Helper loaded: url_helper
INFO - 2022-06-22 09:00:12 --> Helper loaded: file_helper
INFO - 2022-06-22 09:00:12 --> Database Driver Class Initialized
INFO - 2022-06-22 09:00:12 --> Email Class Initialized
DEBUG - 2022-06-22 09:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 09:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 09:00:12 --> Controller Class Initialized
INFO - 2022-06-22 09:00:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 09:00:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 09:00:12 --> Severity: error --> Exception: Cannot use object of type CI_DB_mysqli_result as array C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
INFO - 2022-06-22 09:03:08 --> Config Class Initialized
INFO - 2022-06-22 09:03:08 --> Hooks Class Initialized
DEBUG - 2022-06-22 09:03:08 --> UTF-8 Support Enabled
INFO - 2022-06-22 09:03:08 --> Utf8 Class Initialized
INFO - 2022-06-22 09:03:08 --> URI Class Initialized
INFO - 2022-06-22 09:03:08 --> Router Class Initialized
INFO - 2022-06-22 09:03:08 --> Output Class Initialized
INFO - 2022-06-22 09:03:08 --> Security Class Initialized
DEBUG - 2022-06-22 09:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 09:03:08 --> Input Class Initialized
INFO - 2022-06-22 09:03:08 --> Language Class Initialized
INFO - 2022-06-22 09:03:08 --> Loader Class Initialized
INFO - 2022-06-22 09:03:08 --> Helper loaded: url_helper
INFO - 2022-06-22 09:03:08 --> Helper loaded: file_helper
INFO - 2022-06-22 09:03:08 --> Database Driver Class Initialized
INFO - 2022-06-22 09:03:08 --> Email Class Initialized
DEBUG - 2022-06-22 09:03:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 09:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 09:03:08 --> Controller Class Initialized
INFO - 2022-06-22 09:03:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 09:03:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 09:03:09 --> Severity: error --> Exception: Cannot use object of type CI_DB_mysqli_result as array C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
INFO - 2022-06-22 09:03:12 --> Config Class Initialized
INFO - 2022-06-22 09:03:12 --> Hooks Class Initialized
DEBUG - 2022-06-22 09:03:12 --> UTF-8 Support Enabled
INFO - 2022-06-22 09:03:12 --> Utf8 Class Initialized
INFO - 2022-06-22 09:03:12 --> URI Class Initialized
INFO - 2022-06-22 09:03:12 --> Router Class Initialized
INFO - 2022-06-22 09:03:12 --> Output Class Initialized
INFO - 2022-06-22 09:03:12 --> Security Class Initialized
DEBUG - 2022-06-22 09:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 09:03:12 --> Input Class Initialized
INFO - 2022-06-22 09:03:12 --> Language Class Initialized
INFO - 2022-06-22 09:03:12 --> Loader Class Initialized
INFO - 2022-06-22 09:03:12 --> Helper loaded: url_helper
INFO - 2022-06-22 09:03:12 --> Helper loaded: file_helper
INFO - 2022-06-22 09:03:12 --> Database Driver Class Initialized
INFO - 2022-06-22 09:03:12 --> Email Class Initialized
DEBUG - 2022-06-22 09:03:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 09:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 09:03:12 --> Controller Class Initialized
INFO - 2022-06-22 09:03:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 09:03:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 09:03:12 --> Severity: error --> Exception: Cannot use object of type CI_DB_mysqli_result as array C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
INFO - 2022-06-22 09:03:14 --> Config Class Initialized
INFO - 2022-06-22 09:03:14 --> Hooks Class Initialized
DEBUG - 2022-06-22 09:03:14 --> UTF-8 Support Enabled
INFO - 2022-06-22 09:03:14 --> Utf8 Class Initialized
INFO - 2022-06-22 09:03:14 --> URI Class Initialized
INFO - 2022-06-22 09:03:14 --> Router Class Initialized
INFO - 2022-06-22 09:03:14 --> Output Class Initialized
INFO - 2022-06-22 09:03:14 --> Security Class Initialized
DEBUG - 2022-06-22 09:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 09:03:14 --> Input Class Initialized
INFO - 2022-06-22 09:03:14 --> Language Class Initialized
INFO - 2022-06-22 09:03:14 --> Loader Class Initialized
INFO - 2022-06-22 09:03:14 --> Helper loaded: url_helper
INFO - 2022-06-22 09:03:14 --> Helper loaded: file_helper
INFO - 2022-06-22 09:03:14 --> Database Driver Class Initialized
INFO - 2022-06-22 09:03:14 --> Email Class Initialized
DEBUG - 2022-06-22 09:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 09:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 09:03:14 --> Controller Class Initialized
INFO - 2022-06-22 09:03:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 09:03:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 09:03:14 --> Severity: error --> Exception: Cannot use object of type CI_DB_mysqli_result as array C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
INFO - 2022-06-22 09:03:32 --> Config Class Initialized
INFO - 2022-06-22 09:03:32 --> Hooks Class Initialized
DEBUG - 2022-06-22 09:03:32 --> UTF-8 Support Enabled
INFO - 2022-06-22 09:03:32 --> Utf8 Class Initialized
INFO - 2022-06-22 09:03:32 --> URI Class Initialized
INFO - 2022-06-22 09:03:32 --> Router Class Initialized
INFO - 2022-06-22 09:03:32 --> Output Class Initialized
INFO - 2022-06-22 09:03:32 --> Security Class Initialized
DEBUG - 2022-06-22 09:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 09:03:32 --> Input Class Initialized
INFO - 2022-06-22 09:03:32 --> Language Class Initialized
INFO - 2022-06-22 09:03:32 --> Loader Class Initialized
INFO - 2022-06-22 09:03:32 --> Helper loaded: url_helper
INFO - 2022-06-22 09:03:32 --> Helper loaded: file_helper
INFO - 2022-06-22 09:03:32 --> Database Driver Class Initialized
INFO - 2022-06-22 09:03:32 --> Email Class Initialized
DEBUG - 2022-06-22 09:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 09:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 09:03:32 --> Controller Class Initialized
INFO - 2022-06-22 09:03:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 09:03:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 09:03:32 --> Severity: error --> Exception: Cannot use object of type CI_DB_mysqli_result as array C:\wamp64\www\qr\application\controllers\Tokenctrl.php 30
INFO - 2022-06-22 09:15:50 --> Config Class Initialized
INFO - 2022-06-22 09:15:50 --> Hooks Class Initialized
DEBUG - 2022-06-22 09:15:50 --> UTF-8 Support Enabled
INFO - 2022-06-22 09:15:50 --> Utf8 Class Initialized
INFO - 2022-06-22 09:15:50 --> URI Class Initialized
INFO - 2022-06-22 09:15:50 --> Router Class Initialized
INFO - 2022-06-22 09:15:50 --> Output Class Initialized
INFO - 2022-06-22 09:15:50 --> Security Class Initialized
DEBUG - 2022-06-22 09:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 09:15:50 --> Input Class Initialized
INFO - 2022-06-22 09:15:50 --> Language Class Initialized
INFO - 2022-06-22 09:15:50 --> Loader Class Initialized
INFO - 2022-06-22 09:15:50 --> Helper loaded: url_helper
INFO - 2022-06-22 09:15:50 --> Helper loaded: file_helper
INFO - 2022-06-22 09:15:50 --> Database Driver Class Initialized
INFO - 2022-06-22 09:15:50 --> Email Class Initialized
DEBUG - 2022-06-22 09:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 09:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 09:15:50 --> Controller Class Initialized
INFO - 2022-06-22 09:15:50 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 09:15:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 09:15:50 --> Severity: Notice --> Undefined index: td_cs C:\wamp64\www\qr\application\controllers\Tokenctrl.php 30
ERROR - 2022-06-22 09:15:50 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\wamp64\www\qr\application\controllers\Tokenctrl.php 31
INFO - 2022-06-22 09:15:50 --> Final output sent to browser
DEBUG - 2022-06-22 09:15:50 --> Total execution time: 0.1331
INFO - 2022-06-22 09:17:28 --> Config Class Initialized
INFO - 2022-06-22 09:17:28 --> Hooks Class Initialized
DEBUG - 2022-06-22 09:17:28 --> UTF-8 Support Enabled
INFO - 2022-06-22 09:17:28 --> Utf8 Class Initialized
INFO - 2022-06-22 09:17:28 --> URI Class Initialized
INFO - 2022-06-22 09:17:28 --> Router Class Initialized
INFO - 2022-06-22 09:17:28 --> Output Class Initialized
INFO - 2022-06-22 09:17:28 --> Security Class Initialized
DEBUG - 2022-06-22 09:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 09:17:28 --> Input Class Initialized
INFO - 2022-06-22 09:17:28 --> Language Class Initialized
INFO - 2022-06-22 09:17:28 --> Loader Class Initialized
INFO - 2022-06-22 09:17:28 --> Helper loaded: url_helper
INFO - 2022-06-22 09:17:28 --> Helper loaded: file_helper
INFO - 2022-06-22 09:17:28 --> Database Driver Class Initialized
INFO - 2022-06-22 09:17:28 --> Email Class Initialized
DEBUG - 2022-06-22 09:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 09:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 09:17:28 --> Controller Class Initialized
INFO - 2022-06-22 09:17:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 09:17:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 09:17:28 --> Severity: Notice --> Undefined index: td_cs C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
ERROR - 2022-06-22 09:17:28 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
INFO - 2022-06-22 09:17:28 --> Final output sent to browser
DEBUG - 2022-06-22 09:17:28 --> Total execution time: 0.1350
INFO - 2022-06-22 09:19:25 --> Config Class Initialized
INFO - 2022-06-22 09:19:25 --> Hooks Class Initialized
DEBUG - 2022-06-22 09:19:25 --> UTF-8 Support Enabled
INFO - 2022-06-22 09:19:25 --> Utf8 Class Initialized
INFO - 2022-06-22 09:19:25 --> URI Class Initialized
INFO - 2022-06-22 09:19:25 --> Router Class Initialized
INFO - 2022-06-22 09:19:25 --> Output Class Initialized
INFO - 2022-06-22 09:19:25 --> Security Class Initialized
DEBUG - 2022-06-22 09:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 09:19:25 --> Input Class Initialized
INFO - 2022-06-22 09:19:25 --> Language Class Initialized
INFO - 2022-06-22 09:19:25 --> Loader Class Initialized
INFO - 2022-06-22 09:19:25 --> Helper loaded: url_helper
INFO - 2022-06-22 09:19:25 --> Helper loaded: file_helper
INFO - 2022-06-22 09:19:25 --> Database Driver Class Initialized
INFO - 2022-06-22 09:19:25 --> Email Class Initialized
DEBUG - 2022-06-22 09:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 09:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 09:19:25 --> Controller Class Initialized
INFO - 2022-06-22 09:19:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 09:19:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 09:19:25 --> Severity: Notice --> Undefined variable: td_cs C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
ERROR - 2022-06-22 09:19:25 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
INFO - 2022-06-22 09:19:25 --> Final output sent to browser
DEBUG - 2022-06-22 09:19:25 --> Total execution time: 0.1756
INFO - 2022-06-22 09:19:30 --> Config Class Initialized
INFO - 2022-06-22 09:19:30 --> Hooks Class Initialized
DEBUG - 2022-06-22 09:19:30 --> UTF-8 Support Enabled
INFO - 2022-06-22 09:19:30 --> Utf8 Class Initialized
INFO - 2022-06-22 09:19:30 --> URI Class Initialized
INFO - 2022-06-22 09:19:30 --> Router Class Initialized
INFO - 2022-06-22 09:19:30 --> Output Class Initialized
INFO - 2022-06-22 09:19:30 --> Security Class Initialized
DEBUG - 2022-06-22 09:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 09:19:30 --> Input Class Initialized
INFO - 2022-06-22 09:19:30 --> Language Class Initialized
INFO - 2022-06-22 09:19:30 --> Loader Class Initialized
INFO - 2022-06-22 09:19:30 --> Helper loaded: url_helper
INFO - 2022-06-22 09:19:30 --> Helper loaded: file_helper
INFO - 2022-06-22 09:19:30 --> Database Driver Class Initialized
INFO - 2022-06-22 09:19:30 --> Email Class Initialized
DEBUG - 2022-06-22 09:19:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 09:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 09:19:30 --> Controller Class Initialized
INFO - 2022-06-22 09:19:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 09:19:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 09:19:30 --> Severity: Notice --> Undefined variable: td_cs C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
ERROR - 2022-06-22 09:19:30 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
INFO - 2022-06-22 09:19:30 --> Final output sent to browser
DEBUG - 2022-06-22 09:19:30 --> Total execution time: 0.1364
INFO - 2022-06-22 09:19:32 --> Config Class Initialized
INFO - 2022-06-22 09:19:32 --> Hooks Class Initialized
DEBUG - 2022-06-22 09:19:32 --> UTF-8 Support Enabled
INFO - 2022-06-22 09:19:32 --> Utf8 Class Initialized
INFO - 2022-06-22 09:19:32 --> URI Class Initialized
INFO - 2022-06-22 09:19:32 --> Router Class Initialized
INFO - 2022-06-22 09:19:32 --> Output Class Initialized
INFO - 2022-06-22 09:19:32 --> Security Class Initialized
DEBUG - 2022-06-22 09:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 09:19:32 --> Input Class Initialized
INFO - 2022-06-22 09:19:32 --> Language Class Initialized
INFO - 2022-06-22 09:19:32 --> Loader Class Initialized
INFO - 2022-06-22 09:19:32 --> Helper loaded: url_helper
INFO - 2022-06-22 09:19:32 --> Helper loaded: file_helper
INFO - 2022-06-22 09:19:32 --> Database Driver Class Initialized
INFO - 2022-06-22 09:19:32 --> Email Class Initialized
DEBUG - 2022-06-22 09:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 09:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 09:19:32 --> Controller Class Initialized
INFO - 2022-06-22 09:19:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 09:19:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 09:19:32 --> Severity: Notice --> Undefined variable: td_cs C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
ERROR - 2022-06-22 09:19:32 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
INFO - 2022-06-22 09:19:32 --> Final output sent to browser
DEBUG - 2022-06-22 09:19:32 --> Total execution time: 0.2084
INFO - 2022-06-22 09:19:33 --> Config Class Initialized
INFO - 2022-06-22 09:19:33 --> Hooks Class Initialized
DEBUG - 2022-06-22 09:19:33 --> UTF-8 Support Enabled
INFO - 2022-06-22 09:19:33 --> Utf8 Class Initialized
INFO - 2022-06-22 09:19:33 --> URI Class Initialized
INFO - 2022-06-22 09:19:33 --> Router Class Initialized
INFO - 2022-06-22 09:19:33 --> Output Class Initialized
INFO - 2022-06-22 09:19:33 --> Security Class Initialized
DEBUG - 2022-06-22 09:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 09:19:33 --> Input Class Initialized
INFO - 2022-06-22 09:19:33 --> Language Class Initialized
INFO - 2022-06-22 09:19:33 --> Loader Class Initialized
INFO - 2022-06-22 09:19:33 --> Helper loaded: url_helper
INFO - 2022-06-22 09:19:33 --> Helper loaded: file_helper
INFO - 2022-06-22 09:19:33 --> Database Driver Class Initialized
INFO - 2022-06-22 09:19:33 --> Email Class Initialized
DEBUG - 2022-06-22 09:19:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 09:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 09:19:33 --> Controller Class Initialized
INFO - 2022-06-22 09:19:33 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 09:19:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 09:19:33 --> Severity: Notice --> Undefined variable: td_cs C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
ERROR - 2022-06-22 09:19:33 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
INFO - 2022-06-22 09:19:33 --> Final output sent to browser
DEBUG - 2022-06-22 09:19:33 --> Total execution time: 0.1404
INFO - 2022-06-22 09:19:33 --> Config Class Initialized
INFO - 2022-06-22 09:19:33 --> Hooks Class Initialized
DEBUG - 2022-06-22 09:19:33 --> UTF-8 Support Enabled
INFO - 2022-06-22 09:19:33 --> Utf8 Class Initialized
INFO - 2022-06-22 09:19:33 --> URI Class Initialized
INFO - 2022-06-22 09:19:33 --> Router Class Initialized
INFO - 2022-06-22 09:19:33 --> Output Class Initialized
INFO - 2022-06-22 09:19:33 --> Security Class Initialized
DEBUG - 2022-06-22 09:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 09:19:33 --> Input Class Initialized
INFO - 2022-06-22 09:19:33 --> Language Class Initialized
INFO - 2022-06-22 09:19:33 --> Loader Class Initialized
INFO - 2022-06-22 09:19:33 --> Helper loaded: url_helper
INFO - 2022-06-22 09:19:33 --> Helper loaded: file_helper
INFO - 2022-06-22 09:19:33 --> Database Driver Class Initialized
INFO - 2022-06-22 09:19:34 --> Email Class Initialized
DEBUG - 2022-06-22 09:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 09:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 09:19:34 --> Controller Class Initialized
INFO - 2022-06-22 09:19:34 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 09:19:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 09:19:34 --> Severity: Notice --> Undefined variable: td_cs C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
ERROR - 2022-06-22 09:19:34 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
INFO - 2022-06-22 09:19:34 --> Final output sent to browser
DEBUG - 2022-06-22 09:19:34 --> Total execution time: 0.0999
INFO - 2022-06-22 09:19:34 --> Config Class Initialized
INFO - 2022-06-22 09:19:34 --> Hooks Class Initialized
DEBUG - 2022-06-22 09:19:34 --> UTF-8 Support Enabled
INFO - 2022-06-22 09:19:34 --> Utf8 Class Initialized
INFO - 2022-06-22 09:19:34 --> URI Class Initialized
INFO - 2022-06-22 09:19:34 --> Router Class Initialized
INFO - 2022-06-22 09:19:34 --> Output Class Initialized
INFO - 2022-06-22 09:19:34 --> Security Class Initialized
DEBUG - 2022-06-22 09:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 09:19:34 --> Input Class Initialized
INFO - 2022-06-22 09:19:34 --> Language Class Initialized
INFO - 2022-06-22 09:19:34 --> Loader Class Initialized
INFO - 2022-06-22 09:19:34 --> Helper loaded: url_helper
INFO - 2022-06-22 09:19:34 --> Helper loaded: file_helper
INFO - 2022-06-22 09:19:34 --> Database Driver Class Initialized
INFO - 2022-06-22 09:19:34 --> Email Class Initialized
DEBUG - 2022-06-22 09:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 09:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 09:19:34 --> Controller Class Initialized
INFO - 2022-06-22 09:19:34 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 09:19:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 09:19:34 --> Severity: Notice --> Undefined variable: td_cs C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
ERROR - 2022-06-22 09:19:34 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
INFO - 2022-06-22 09:19:34 --> Final output sent to browser
DEBUG - 2022-06-22 09:19:34 --> Total execution time: 0.0395
INFO - 2022-06-22 09:19:34 --> Config Class Initialized
INFO - 2022-06-22 09:19:34 --> Hooks Class Initialized
DEBUG - 2022-06-22 09:19:34 --> UTF-8 Support Enabled
INFO - 2022-06-22 09:19:34 --> Utf8 Class Initialized
INFO - 2022-06-22 09:19:34 --> URI Class Initialized
INFO - 2022-06-22 09:19:34 --> Router Class Initialized
INFO - 2022-06-22 09:19:34 --> Output Class Initialized
INFO - 2022-06-22 09:19:34 --> Security Class Initialized
DEBUG - 2022-06-22 09:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 09:19:34 --> Input Class Initialized
INFO - 2022-06-22 09:19:34 --> Language Class Initialized
INFO - 2022-06-22 09:19:34 --> Loader Class Initialized
INFO - 2022-06-22 09:19:34 --> Helper loaded: url_helper
INFO - 2022-06-22 09:19:34 --> Helper loaded: file_helper
INFO - 2022-06-22 09:19:34 --> Database Driver Class Initialized
INFO - 2022-06-22 09:19:34 --> Email Class Initialized
DEBUG - 2022-06-22 09:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 09:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 09:19:34 --> Controller Class Initialized
INFO - 2022-06-22 09:19:34 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 09:19:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 09:19:34 --> Severity: Notice --> Undefined variable: td_cs C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
ERROR - 2022-06-22 09:19:34 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
INFO - 2022-06-22 09:19:34 --> Final output sent to browser
DEBUG - 2022-06-22 09:19:34 --> Total execution time: 0.0177
INFO - 2022-06-22 09:19:34 --> Config Class Initialized
INFO - 2022-06-22 09:19:34 --> Hooks Class Initialized
DEBUG - 2022-06-22 09:19:34 --> UTF-8 Support Enabled
INFO - 2022-06-22 09:19:34 --> Utf8 Class Initialized
INFO - 2022-06-22 09:19:34 --> URI Class Initialized
INFO - 2022-06-22 09:19:34 --> Router Class Initialized
INFO - 2022-06-22 09:19:34 --> Output Class Initialized
INFO - 2022-06-22 09:19:34 --> Security Class Initialized
DEBUG - 2022-06-22 09:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 09:19:34 --> Input Class Initialized
INFO - 2022-06-22 09:19:34 --> Language Class Initialized
INFO - 2022-06-22 09:19:34 --> Loader Class Initialized
INFO - 2022-06-22 09:19:34 --> Helper loaded: url_helper
INFO - 2022-06-22 09:19:34 --> Helper loaded: file_helper
INFO - 2022-06-22 09:19:34 --> Database Driver Class Initialized
INFO - 2022-06-22 09:19:34 --> Email Class Initialized
DEBUG - 2022-06-22 09:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 09:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 09:19:34 --> Controller Class Initialized
INFO - 2022-06-22 09:19:34 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 09:19:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 09:19:34 --> Severity: Notice --> Undefined variable: td_cs C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
ERROR - 2022-06-22 09:19:34 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
INFO - 2022-06-22 09:19:34 --> Final output sent to browser
DEBUG - 2022-06-22 09:19:34 --> Total execution time: 0.0550
INFO - 2022-06-22 09:19:34 --> Config Class Initialized
INFO - 2022-06-22 09:19:34 --> Hooks Class Initialized
DEBUG - 2022-06-22 09:19:34 --> UTF-8 Support Enabled
INFO - 2022-06-22 09:19:34 --> Utf8 Class Initialized
INFO - 2022-06-22 09:19:34 --> URI Class Initialized
INFO - 2022-06-22 09:19:34 --> Router Class Initialized
INFO - 2022-06-22 09:19:34 --> Output Class Initialized
INFO - 2022-06-22 09:19:34 --> Security Class Initialized
DEBUG - 2022-06-22 09:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 09:19:34 --> Input Class Initialized
INFO - 2022-06-22 09:19:34 --> Language Class Initialized
INFO - 2022-06-22 09:19:34 --> Loader Class Initialized
INFO - 2022-06-22 09:19:34 --> Helper loaded: url_helper
INFO - 2022-06-22 09:19:34 --> Helper loaded: file_helper
INFO - 2022-06-22 09:19:34 --> Database Driver Class Initialized
INFO - 2022-06-22 09:19:34 --> Email Class Initialized
DEBUG - 2022-06-22 09:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 09:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 09:19:34 --> Controller Class Initialized
INFO - 2022-06-22 09:19:34 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 09:19:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 09:19:34 --> Severity: Notice --> Undefined variable: td_cs C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
ERROR - 2022-06-22 09:19:34 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
INFO - 2022-06-22 09:19:34 --> Final output sent to browser
DEBUG - 2022-06-22 09:19:34 --> Total execution time: 0.0543
INFO - 2022-06-22 09:19:34 --> Config Class Initialized
INFO - 2022-06-22 09:19:34 --> Hooks Class Initialized
DEBUG - 2022-06-22 09:19:34 --> UTF-8 Support Enabled
INFO - 2022-06-22 09:19:34 --> Utf8 Class Initialized
INFO - 2022-06-22 09:19:34 --> URI Class Initialized
INFO - 2022-06-22 09:19:34 --> Router Class Initialized
INFO - 2022-06-22 09:19:34 --> Output Class Initialized
INFO - 2022-06-22 09:19:34 --> Security Class Initialized
DEBUG - 2022-06-22 09:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 09:19:34 --> Input Class Initialized
INFO - 2022-06-22 09:19:34 --> Language Class Initialized
INFO - 2022-06-22 09:19:34 --> Loader Class Initialized
INFO - 2022-06-22 09:19:34 --> Helper loaded: url_helper
INFO - 2022-06-22 09:19:34 --> Helper loaded: file_helper
INFO - 2022-06-22 09:19:34 --> Database Driver Class Initialized
INFO - 2022-06-22 09:19:35 --> Email Class Initialized
DEBUG - 2022-06-22 09:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 09:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 09:19:35 --> Controller Class Initialized
INFO - 2022-06-22 09:19:35 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 09:19:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 09:19:35 --> Severity: Notice --> Undefined variable: td_cs C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
ERROR - 2022-06-22 09:19:35 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
INFO - 2022-06-22 09:19:35 --> Final output sent to browser
DEBUG - 2022-06-22 09:19:35 --> Total execution time: 0.0499
INFO - 2022-06-22 09:19:35 --> Config Class Initialized
INFO - 2022-06-22 09:19:35 --> Hooks Class Initialized
DEBUG - 2022-06-22 09:19:35 --> UTF-8 Support Enabled
INFO - 2022-06-22 09:19:35 --> Utf8 Class Initialized
INFO - 2022-06-22 09:19:35 --> URI Class Initialized
INFO - 2022-06-22 09:19:35 --> Router Class Initialized
INFO - 2022-06-22 09:19:35 --> Output Class Initialized
INFO - 2022-06-22 09:19:35 --> Security Class Initialized
DEBUG - 2022-06-22 09:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 09:19:35 --> Input Class Initialized
INFO - 2022-06-22 09:19:35 --> Language Class Initialized
INFO - 2022-06-22 09:19:35 --> Loader Class Initialized
INFO - 2022-06-22 09:19:35 --> Helper loaded: url_helper
INFO - 2022-06-22 09:19:35 --> Helper loaded: file_helper
INFO - 2022-06-22 09:19:35 --> Database Driver Class Initialized
INFO - 2022-06-22 09:19:35 --> Email Class Initialized
DEBUG - 2022-06-22 09:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 09:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 09:19:35 --> Controller Class Initialized
INFO - 2022-06-22 09:19:35 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 09:19:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 09:19:35 --> Severity: Notice --> Undefined variable: td_cs C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
ERROR - 2022-06-22 09:19:35 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
INFO - 2022-06-22 09:19:35 --> Final output sent to browser
DEBUG - 2022-06-22 09:19:35 --> Total execution time: 0.0190
INFO - 2022-06-22 09:21:01 --> Config Class Initialized
INFO - 2022-06-22 09:21:01 --> Hooks Class Initialized
DEBUG - 2022-06-22 09:21:01 --> UTF-8 Support Enabled
INFO - 2022-06-22 09:21:01 --> Utf8 Class Initialized
INFO - 2022-06-22 09:21:01 --> URI Class Initialized
INFO - 2022-06-22 09:21:01 --> Router Class Initialized
INFO - 2022-06-22 09:21:01 --> Output Class Initialized
INFO - 2022-06-22 09:21:01 --> Security Class Initialized
DEBUG - 2022-06-22 09:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 09:21:01 --> Input Class Initialized
INFO - 2022-06-22 09:21:01 --> Language Class Initialized
INFO - 2022-06-22 09:21:01 --> Loader Class Initialized
INFO - 2022-06-22 09:21:01 --> Helper loaded: url_helper
INFO - 2022-06-22 09:21:01 --> Helper loaded: file_helper
INFO - 2022-06-22 09:21:01 --> Database Driver Class Initialized
INFO - 2022-06-22 09:21:01 --> Email Class Initialized
DEBUG - 2022-06-22 09:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 09:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 09:21:01 --> Controller Class Initialized
INFO - 2022-06-22 09:21:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 09:21:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 09:21:01 --> Severity: Notice --> Undefined variable: session C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
ERROR - 2022-06-22 09:21:01 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
INFO - 2022-06-22 09:21:01 --> Final output sent to browser
DEBUG - 2022-06-22 09:21:01 --> Total execution time: 0.0188
INFO - 2022-06-22 09:21:02 --> Config Class Initialized
INFO - 2022-06-22 09:21:02 --> Hooks Class Initialized
DEBUG - 2022-06-22 09:21:02 --> UTF-8 Support Enabled
INFO - 2022-06-22 09:21:02 --> Utf8 Class Initialized
INFO - 2022-06-22 09:21:02 --> URI Class Initialized
INFO - 2022-06-22 09:21:02 --> Router Class Initialized
INFO - 2022-06-22 09:21:02 --> Output Class Initialized
INFO - 2022-06-22 09:21:02 --> Security Class Initialized
DEBUG - 2022-06-22 09:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 09:21:02 --> Input Class Initialized
INFO - 2022-06-22 09:21:02 --> Language Class Initialized
INFO - 2022-06-22 09:21:02 --> Loader Class Initialized
INFO - 2022-06-22 09:21:02 --> Helper loaded: url_helper
INFO - 2022-06-22 09:21:02 --> Helper loaded: file_helper
INFO - 2022-06-22 09:21:02 --> Database Driver Class Initialized
INFO - 2022-06-22 09:21:02 --> Email Class Initialized
DEBUG - 2022-06-22 09:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 09:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 09:21:02 --> Controller Class Initialized
INFO - 2022-06-22 09:21:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 09:21:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 09:21:02 --> Severity: Notice --> Undefined variable: session C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
ERROR - 2022-06-22 09:21:02 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
INFO - 2022-06-22 09:21:02 --> Final output sent to browser
DEBUG - 2022-06-22 09:21:02 --> Total execution time: 0.0188
INFO - 2022-06-22 09:21:03 --> Config Class Initialized
INFO - 2022-06-22 09:21:03 --> Hooks Class Initialized
DEBUG - 2022-06-22 09:21:03 --> UTF-8 Support Enabled
INFO - 2022-06-22 09:21:03 --> Utf8 Class Initialized
INFO - 2022-06-22 09:21:03 --> URI Class Initialized
INFO - 2022-06-22 09:21:03 --> Router Class Initialized
INFO - 2022-06-22 09:21:03 --> Output Class Initialized
INFO - 2022-06-22 09:21:03 --> Security Class Initialized
DEBUG - 2022-06-22 09:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 09:21:03 --> Input Class Initialized
INFO - 2022-06-22 09:21:03 --> Language Class Initialized
INFO - 2022-06-22 09:21:03 --> Loader Class Initialized
INFO - 2022-06-22 09:21:03 --> Helper loaded: url_helper
INFO - 2022-06-22 09:21:03 --> Helper loaded: file_helper
INFO - 2022-06-22 09:21:03 --> Database Driver Class Initialized
INFO - 2022-06-22 09:21:03 --> Email Class Initialized
DEBUG - 2022-06-22 09:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 09:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 09:21:03 --> Controller Class Initialized
INFO - 2022-06-22 09:21:03 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 09:21:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 09:21:03 --> Severity: Notice --> Undefined variable: session C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
ERROR - 2022-06-22 09:21:03 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
INFO - 2022-06-22 09:21:03 --> Final output sent to browser
DEBUG - 2022-06-22 09:21:03 --> Total execution time: 0.0184
INFO - 2022-06-22 09:21:03 --> Config Class Initialized
INFO - 2022-06-22 09:21:03 --> Hooks Class Initialized
DEBUG - 2022-06-22 09:21:03 --> UTF-8 Support Enabled
INFO - 2022-06-22 09:21:03 --> Utf8 Class Initialized
INFO - 2022-06-22 09:21:03 --> URI Class Initialized
INFO - 2022-06-22 09:21:03 --> Router Class Initialized
INFO - 2022-06-22 09:21:03 --> Output Class Initialized
INFO - 2022-06-22 09:21:03 --> Security Class Initialized
DEBUG - 2022-06-22 09:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 09:21:03 --> Input Class Initialized
INFO - 2022-06-22 09:21:03 --> Language Class Initialized
INFO - 2022-06-22 09:21:03 --> Loader Class Initialized
INFO - 2022-06-22 09:21:03 --> Helper loaded: url_helper
INFO - 2022-06-22 09:21:03 --> Helper loaded: file_helper
INFO - 2022-06-22 09:21:03 --> Database Driver Class Initialized
INFO - 2022-06-22 09:21:03 --> Email Class Initialized
DEBUG - 2022-06-22 09:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 09:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 09:21:03 --> Controller Class Initialized
INFO - 2022-06-22 09:21:03 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 09:21:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 09:21:03 --> Severity: Notice --> Undefined variable: session C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
ERROR - 2022-06-22 09:21:03 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
INFO - 2022-06-22 09:21:03 --> Final output sent to browser
DEBUG - 2022-06-22 09:21:03 --> Total execution time: 0.0298
INFO - 2022-06-22 09:21:04 --> Config Class Initialized
INFO - 2022-06-22 09:21:04 --> Hooks Class Initialized
DEBUG - 2022-06-22 09:21:04 --> UTF-8 Support Enabled
INFO - 2022-06-22 09:21:04 --> Utf8 Class Initialized
INFO - 2022-06-22 09:21:04 --> URI Class Initialized
INFO - 2022-06-22 09:21:04 --> Router Class Initialized
INFO - 2022-06-22 09:21:04 --> Output Class Initialized
INFO - 2022-06-22 09:21:04 --> Security Class Initialized
DEBUG - 2022-06-22 09:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 09:21:04 --> Input Class Initialized
INFO - 2022-06-22 09:21:04 --> Language Class Initialized
INFO - 2022-06-22 09:21:04 --> Loader Class Initialized
INFO - 2022-06-22 09:21:04 --> Helper loaded: url_helper
INFO - 2022-06-22 09:21:04 --> Helper loaded: file_helper
INFO - 2022-06-22 09:21:04 --> Database Driver Class Initialized
INFO - 2022-06-22 09:21:04 --> Email Class Initialized
DEBUG - 2022-06-22 09:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 09:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 09:21:04 --> Controller Class Initialized
INFO - 2022-06-22 09:21:04 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 09:21:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 09:21:04 --> Severity: Notice --> Undefined variable: session C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
ERROR - 2022-06-22 09:21:04 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
INFO - 2022-06-22 09:21:04 --> Final output sent to browser
DEBUG - 2022-06-22 09:21:04 --> Total execution time: 0.0192
INFO - 2022-06-22 09:21:05 --> Config Class Initialized
INFO - 2022-06-22 09:21:05 --> Hooks Class Initialized
DEBUG - 2022-06-22 09:21:05 --> UTF-8 Support Enabled
INFO - 2022-06-22 09:21:05 --> Utf8 Class Initialized
INFO - 2022-06-22 09:21:05 --> URI Class Initialized
INFO - 2022-06-22 09:21:05 --> Router Class Initialized
INFO - 2022-06-22 09:21:05 --> Output Class Initialized
INFO - 2022-06-22 09:21:05 --> Security Class Initialized
DEBUG - 2022-06-22 09:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 09:21:05 --> Input Class Initialized
INFO - 2022-06-22 09:21:05 --> Language Class Initialized
INFO - 2022-06-22 09:21:05 --> Loader Class Initialized
INFO - 2022-06-22 09:21:05 --> Helper loaded: url_helper
INFO - 2022-06-22 09:21:05 --> Helper loaded: file_helper
INFO - 2022-06-22 09:21:05 --> Database Driver Class Initialized
INFO - 2022-06-22 09:21:05 --> Email Class Initialized
DEBUG - 2022-06-22 09:21:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 09:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 09:21:05 --> Controller Class Initialized
INFO - 2022-06-22 09:21:05 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 09:21:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 09:21:05 --> Severity: Notice --> Undefined variable: session C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
ERROR - 2022-06-22 09:21:05 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
INFO - 2022-06-22 09:21:05 --> Final output sent to browser
DEBUG - 2022-06-22 09:21:05 --> Total execution time: 0.1326
INFO - 2022-06-22 09:21:05 --> Config Class Initialized
INFO - 2022-06-22 09:21:05 --> Hooks Class Initialized
DEBUG - 2022-06-22 09:21:05 --> UTF-8 Support Enabled
INFO - 2022-06-22 09:21:05 --> Utf8 Class Initialized
INFO - 2022-06-22 09:21:05 --> URI Class Initialized
INFO - 2022-06-22 09:21:05 --> Router Class Initialized
INFO - 2022-06-22 09:21:05 --> Output Class Initialized
INFO - 2022-06-22 09:21:05 --> Security Class Initialized
DEBUG - 2022-06-22 09:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 09:21:05 --> Input Class Initialized
INFO - 2022-06-22 09:21:05 --> Language Class Initialized
INFO - 2022-06-22 09:21:05 --> Loader Class Initialized
INFO - 2022-06-22 09:21:05 --> Helper loaded: url_helper
INFO - 2022-06-22 09:21:05 --> Helper loaded: file_helper
INFO - 2022-06-22 09:21:05 --> Database Driver Class Initialized
INFO - 2022-06-22 09:21:05 --> Email Class Initialized
DEBUG - 2022-06-22 09:21:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 09:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 09:21:05 --> Controller Class Initialized
INFO - 2022-06-22 09:21:05 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 09:21:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 09:21:05 --> Severity: Notice --> Undefined variable: session C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
ERROR - 2022-06-22 09:21:05 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
INFO - 2022-06-22 09:21:05 --> Final output sent to browser
DEBUG - 2022-06-22 09:21:05 --> Total execution time: 0.0332
INFO - 2022-06-22 09:21:30 --> Config Class Initialized
INFO - 2022-06-22 09:21:30 --> Hooks Class Initialized
DEBUG - 2022-06-22 09:21:30 --> UTF-8 Support Enabled
INFO - 2022-06-22 09:21:30 --> Utf8 Class Initialized
INFO - 2022-06-22 09:21:30 --> URI Class Initialized
INFO - 2022-06-22 09:21:30 --> Router Class Initialized
INFO - 2022-06-22 09:21:30 --> Output Class Initialized
INFO - 2022-06-22 09:21:30 --> Security Class Initialized
DEBUG - 2022-06-22 09:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 09:21:30 --> Input Class Initialized
INFO - 2022-06-22 09:21:30 --> Language Class Initialized
INFO - 2022-06-22 09:21:30 --> Loader Class Initialized
INFO - 2022-06-22 09:21:30 --> Helper loaded: url_helper
INFO - 2022-06-22 09:21:30 --> Helper loaded: file_helper
INFO - 2022-06-22 09:21:30 --> Database Driver Class Initialized
INFO - 2022-06-22 09:21:31 --> Email Class Initialized
DEBUG - 2022-06-22 09:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 09:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 09:21:31 --> Controller Class Initialized
INFO - 2022-06-22 09:21:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 09:21:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 09:21:31 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
INFO - 2022-06-22 09:21:31 --> Final output sent to browser
DEBUG - 2022-06-22 09:21:31 --> Total execution time: 0.1155
INFO - 2022-06-22 09:22:21 --> Config Class Initialized
INFO - 2022-06-22 09:22:21 --> Hooks Class Initialized
DEBUG - 2022-06-22 09:22:21 --> UTF-8 Support Enabled
INFO - 2022-06-22 09:22:21 --> Utf8 Class Initialized
INFO - 2022-06-22 09:22:21 --> URI Class Initialized
INFO - 2022-06-22 09:22:21 --> Router Class Initialized
INFO - 2022-06-22 09:22:21 --> Output Class Initialized
INFO - 2022-06-22 09:22:21 --> Security Class Initialized
DEBUG - 2022-06-22 09:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 09:22:21 --> Input Class Initialized
INFO - 2022-06-22 09:22:21 --> Language Class Initialized
ERROR - 2022-06-22 09:22:21 --> Severity: error --> Exception: syntax error, unexpected 'td_cs' (T_STRING), expecting ')' C:\wamp64\www\qr\application\controllers\Tokenctrl.php 29
INFO - 2022-06-22 09:33:13 --> Config Class Initialized
INFO - 2022-06-22 09:33:13 --> Hooks Class Initialized
DEBUG - 2022-06-22 09:33:13 --> UTF-8 Support Enabled
INFO - 2022-06-22 09:33:13 --> Utf8 Class Initialized
INFO - 2022-06-22 09:33:13 --> URI Class Initialized
INFO - 2022-06-22 09:33:13 --> Router Class Initialized
INFO - 2022-06-22 09:33:13 --> Output Class Initialized
INFO - 2022-06-22 09:33:13 --> Security Class Initialized
DEBUG - 2022-06-22 09:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 09:33:13 --> Input Class Initialized
INFO - 2022-06-22 09:33:13 --> Language Class Initialized
INFO - 2022-06-22 09:33:13 --> Loader Class Initialized
INFO - 2022-06-22 09:33:13 --> Helper loaded: url_helper
INFO - 2022-06-22 09:33:13 --> Helper loaded: file_helper
INFO - 2022-06-22 09:33:13 --> Database Driver Class Initialized
INFO - 2022-06-22 09:33:13 --> Email Class Initialized
DEBUG - 2022-06-22 09:33:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 09:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 09:33:13 --> Controller Class Initialized
ERROR - 2022-06-22 09:33:13 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\wamp64\www\qr\application\models\Tokenmodel.php 37
INFO - 2022-06-22 09:33:44 --> Config Class Initialized
INFO - 2022-06-22 09:33:44 --> Hooks Class Initialized
DEBUG - 2022-06-22 09:33:44 --> UTF-8 Support Enabled
INFO - 2022-06-22 09:33:44 --> Utf8 Class Initialized
INFO - 2022-06-22 09:33:44 --> URI Class Initialized
INFO - 2022-06-22 09:33:44 --> Router Class Initialized
INFO - 2022-06-22 09:33:44 --> Output Class Initialized
INFO - 2022-06-22 09:33:44 --> Security Class Initialized
DEBUG - 2022-06-22 09:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 09:33:44 --> Input Class Initialized
INFO - 2022-06-22 09:33:44 --> Language Class Initialized
INFO - 2022-06-22 09:33:44 --> Loader Class Initialized
INFO - 2022-06-22 09:33:44 --> Helper loaded: url_helper
INFO - 2022-06-22 09:33:44 --> Helper loaded: file_helper
INFO - 2022-06-22 09:33:44 --> Database Driver Class Initialized
INFO - 2022-06-22 09:33:44 --> Email Class Initialized
DEBUG - 2022-06-22 09:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 09:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 09:33:44 --> Controller Class Initialized
ERROR - 2022-06-22 09:33:44 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\wamp64\www\qr\application\models\Tokenmodel.php 37
INFO - 2022-06-22 09:33:45 --> Config Class Initialized
INFO - 2022-06-22 09:33:45 --> Hooks Class Initialized
DEBUG - 2022-06-22 09:33:45 --> UTF-8 Support Enabled
INFO - 2022-06-22 09:33:45 --> Utf8 Class Initialized
INFO - 2022-06-22 09:33:45 --> URI Class Initialized
INFO - 2022-06-22 09:33:45 --> Router Class Initialized
INFO - 2022-06-22 09:33:45 --> Output Class Initialized
INFO - 2022-06-22 09:33:45 --> Security Class Initialized
DEBUG - 2022-06-22 09:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 09:33:45 --> Input Class Initialized
INFO - 2022-06-22 09:33:45 --> Language Class Initialized
INFO - 2022-06-22 09:33:45 --> Loader Class Initialized
INFO - 2022-06-22 09:33:45 --> Helper loaded: url_helper
INFO - 2022-06-22 09:33:45 --> Helper loaded: file_helper
INFO - 2022-06-22 09:33:45 --> Database Driver Class Initialized
INFO - 2022-06-22 09:33:46 --> Email Class Initialized
DEBUG - 2022-06-22 09:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 09:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 09:33:46 --> Controller Class Initialized
ERROR - 2022-06-22 09:33:46 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\wamp64\www\qr\application\models\Tokenmodel.php 37
INFO - 2022-06-22 09:33:46 --> Config Class Initialized
INFO - 2022-06-22 09:33:46 --> Hooks Class Initialized
DEBUG - 2022-06-22 09:33:46 --> UTF-8 Support Enabled
INFO - 2022-06-22 09:33:46 --> Utf8 Class Initialized
INFO - 2022-06-22 09:33:46 --> URI Class Initialized
INFO - 2022-06-22 09:33:46 --> Router Class Initialized
INFO - 2022-06-22 09:33:46 --> Output Class Initialized
INFO - 2022-06-22 09:33:46 --> Security Class Initialized
DEBUG - 2022-06-22 09:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 09:33:46 --> Input Class Initialized
INFO - 2022-06-22 09:33:46 --> Language Class Initialized
INFO - 2022-06-22 09:33:46 --> Loader Class Initialized
INFO - 2022-06-22 09:33:46 --> Helper loaded: url_helper
INFO - 2022-06-22 09:33:46 --> Helper loaded: file_helper
INFO - 2022-06-22 09:33:46 --> Database Driver Class Initialized
INFO - 2022-06-22 09:33:46 --> Email Class Initialized
DEBUG - 2022-06-22 09:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 09:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 09:33:46 --> Controller Class Initialized
ERROR - 2022-06-22 09:33:46 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\wamp64\www\qr\application\models\Tokenmodel.php 37
INFO - 2022-06-22 09:34:23 --> Config Class Initialized
INFO - 2022-06-22 09:34:23 --> Hooks Class Initialized
DEBUG - 2022-06-22 09:34:23 --> UTF-8 Support Enabled
INFO - 2022-06-22 09:34:23 --> Utf8 Class Initialized
INFO - 2022-06-22 09:34:23 --> URI Class Initialized
INFO - 2022-06-22 09:34:23 --> Router Class Initialized
INFO - 2022-06-22 09:34:23 --> Output Class Initialized
INFO - 2022-06-22 09:34:23 --> Security Class Initialized
DEBUG - 2022-06-22 09:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 09:34:23 --> Input Class Initialized
INFO - 2022-06-22 09:34:23 --> Language Class Initialized
INFO - 2022-06-22 09:34:23 --> Loader Class Initialized
INFO - 2022-06-22 09:34:23 --> Helper loaded: url_helper
INFO - 2022-06-22 09:34:23 --> Helper loaded: file_helper
INFO - 2022-06-22 09:34:23 --> Database Driver Class Initialized
INFO - 2022-06-22 09:34:23 --> Email Class Initialized
DEBUG - 2022-06-22 09:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 09:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 09:34:23 --> Controller Class Initialized
INFO - 2022-06-22 09:34:23 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 09:34:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 09:34:23 --> Severity: Notice --> Undefined variable: db C:\wamp64\www\qr\application\models\Tokenmodel.php 27
ERROR - 2022-06-22 09:34:23 --> Severity: error --> Exception: Call to a member function getFieldData() on null C:\wamp64\www\qr\application\models\Tokenmodel.php 27
INFO - 2022-06-22 09:34:24 --> Config Class Initialized
INFO - 2022-06-22 09:34:24 --> Hooks Class Initialized
DEBUG - 2022-06-22 09:34:24 --> UTF-8 Support Enabled
INFO - 2022-06-22 09:34:24 --> Utf8 Class Initialized
INFO - 2022-06-22 09:34:24 --> URI Class Initialized
INFO - 2022-06-22 09:34:24 --> Router Class Initialized
INFO - 2022-06-22 09:34:24 --> Output Class Initialized
INFO - 2022-06-22 09:34:24 --> Security Class Initialized
DEBUG - 2022-06-22 09:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 09:34:24 --> Input Class Initialized
INFO - 2022-06-22 09:34:24 --> Language Class Initialized
INFO - 2022-06-22 09:34:24 --> Loader Class Initialized
INFO - 2022-06-22 09:34:24 --> Helper loaded: url_helper
INFO - 2022-06-22 09:34:24 --> Helper loaded: file_helper
INFO - 2022-06-22 09:34:24 --> Database Driver Class Initialized
INFO - 2022-06-22 09:34:24 --> Email Class Initialized
DEBUG - 2022-06-22 09:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 09:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 09:34:24 --> Controller Class Initialized
INFO - 2022-06-22 09:34:24 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 09:34:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 09:34:24 --> Severity: Notice --> Undefined variable: db C:\wamp64\www\qr\application\models\Tokenmodel.php 27
ERROR - 2022-06-22 09:34:24 --> Severity: error --> Exception: Call to a member function getFieldData() on null C:\wamp64\www\qr\application\models\Tokenmodel.php 27
INFO - 2022-06-22 09:35:02 --> Config Class Initialized
INFO - 2022-06-22 09:35:02 --> Hooks Class Initialized
DEBUG - 2022-06-22 09:35:02 --> UTF-8 Support Enabled
INFO - 2022-06-22 09:35:02 --> Utf8 Class Initialized
INFO - 2022-06-22 09:35:02 --> URI Class Initialized
INFO - 2022-06-22 09:35:02 --> Router Class Initialized
INFO - 2022-06-22 09:35:02 --> Output Class Initialized
INFO - 2022-06-22 09:35:02 --> Security Class Initialized
DEBUG - 2022-06-22 09:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 09:35:02 --> Input Class Initialized
INFO - 2022-06-22 09:35:02 --> Language Class Initialized
INFO - 2022-06-22 09:35:02 --> Loader Class Initialized
INFO - 2022-06-22 09:35:02 --> Helper loaded: url_helper
INFO - 2022-06-22 09:35:02 --> Helper loaded: file_helper
INFO - 2022-06-22 09:35:02 --> Database Driver Class Initialized
INFO - 2022-06-22 09:35:02 --> Email Class Initialized
DEBUG - 2022-06-22 09:35:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 09:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 09:35:02 --> Controller Class Initialized
INFO - 2022-06-22 09:35:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 09:35:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 09:35:02 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::getFieldData() C:\wamp64\www\qr\application\models\Tokenmodel.php 27
INFO - 2022-06-22 10:16:38 --> Config Class Initialized
INFO - 2022-06-22 10:16:38 --> Hooks Class Initialized
DEBUG - 2022-06-22 10:16:38 --> UTF-8 Support Enabled
INFO - 2022-06-22 10:16:38 --> Utf8 Class Initialized
INFO - 2022-06-22 10:16:38 --> URI Class Initialized
INFO - 2022-06-22 10:16:38 --> Router Class Initialized
INFO - 2022-06-22 10:16:38 --> Output Class Initialized
INFO - 2022-06-22 10:16:38 --> Security Class Initialized
DEBUG - 2022-06-22 10:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 10:16:38 --> Input Class Initialized
INFO - 2022-06-22 10:16:38 --> Language Class Initialized
ERROR - 2022-06-22 10:16:38 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\wamp64\www\qr\application\controllers\Tokenctrl.php 40
INFO - 2022-06-22 10:17:11 --> Config Class Initialized
INFO - 2022-06-22 10:17:11 --> Hooks Class Initialized
DEBUG - 2022-06-22 10:17:11 --> UTF-8 Support Enabled
INFO - 2022-06-22 10:17:11 --> Utf8 Class Initialized
INFO - 2022-06-22 10:17:11 --> URI Class Initialized
INFO - 2022-06-22 10:17:11 --> Router Class Initialized
INFO - 2022-06-22 10:17:11 --> Output Class Initialized
INFO - 2022-06-22 10:17:11 --> Security Class Initialized
DEBUG - 2022-06-22 10:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 10:17:11 --> Input Class Initialized
INFO - 2022-06-22 10:17:11 --> Language Class Initialized
INFO - 2022-06-22 10:17:11 --> Loader Class Initialized
INFO - 2022-06-22 10:17:11 --> Helper loaded: url_helper
INFO - 2022-06-22 10:17:11 --> Helper loaded: file_helper
INFO - 2022-06-22 10:17:11 --> Database Driver Class Initialized
INFO - 2022-06-22 10:17:12 --> Email Class Initialized
DEBUG - 2022-06-22 10:17:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 10:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 10:17:12 --> Controller Class Initialized
INFO - 2022-06-22 10:17:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 10:17:12 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 10:17:12 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 10:17:12 --> Final output sent to browser
DEBUG - 2022-06-22 10:17:12 --> Total execution time: 0.1937
INFO - 2022-06-22 10:18:22 --> Config Class Initialized
INFO - 2022-06-22 10:18:22 --> Hooks Class Initialized
DEBUG - 2022-06-22 10:18:22 --> UTF-8 Support Enabled
INFO - 2022-06-22 10:18:22 --> Utf8 Class Initialized
INFO - 2022-06-22 10:18:22 --> URI Class Initialized
INFO - 2022-06-22 10:18:22 --> Router Class Initialized
INFO - 2022-06-22 10:18:22 --> Output Class Initialized
INFO - 2022-06-22 10:18:22 --> Security Class Initialized
DEBUG - 2022-06-22 10:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 10:18:22 --> Input Class Initialized
INFO - 2022-06-22 10:18:22 --> Language Class Initialized
INFO - 2022-06-22 10:18:22 --> Loader Class Initialized
INFO - 2022-06-22 10:18:22 --> Helper loaded: url_helper
INFO - 2022-06-22 10:18:22 --> Helper loaded: file_helper
INFO - 2022-06-22 10:18:22 --> Database Driver Class Initialized
INFO - 2022-06-22 10:18:22 --> Email Class Initialized
DEBUG - 2022-06-22 10:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 10:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 10:18:22 --> Controller Class Initialized
INFO - 2022-06-22 10:18:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 10:18:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 10:18:22 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 10:18:22 --> Final output sent to browser
DEBUG - 2022-06-22 10:18:22 --> Total execution time: 0.1529
INFO - 2022-06-22 10:18:46 --> Config Class Initialized
INFO - 2022-06-22 10:18:46 --> Hooks Class Initialized
DEBUG - 2022-06-22 10:18:46 --> UTF-8 Support Enabled
INFO - 2022-06-22 10:18:46 --> Utf8 Class Initialized
INFO - 2022-06-22 10:18:46 --> URI Class Initialized
INFO - 2022-06-22 10:18:46 --> Router Class Initialized
INFO - 2022-06-22 10:18:46 --> Output Class Initialized
INFO - 2022-06-22 10:18:46 --> Security Class Initialized
DEBUG - 2022-06-22 10:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 10:18:46 --> Input Class Initialized
INFO - 2022-06-22 10:18:46 --> Language Class Initialized
INFO - 2022-06-22 10:18:46 --> Loader Class Initialized
INFO - 2022-06-22 10:18:46 --> Helper loaded: url_helper
INFO - 2022-06-22 10:18:46 --> Helper loaded: file_helper
INFO - 2022-06-22 10:18:46 --> Database Driver Class Initialized
INFO - 2022-06-22 10:18:46 --> Email Class Initialized
DEBUG - 2022-06-22 10:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 10:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 10:18:46 --> Controller Class Initialized
INFO - 2022-06-22 10:18:46 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 10:18:46 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 10:18:46 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 10:18:46 --> Final output sent to browser
DEBUG - 2022-06-22 10:18:46 --> Total execution time: 0.2350
INFO - 2022-06-22 10:19:02 --> Config Class Initialized
INFO - 2022-06-22 10:19:02 --> Hooks Class Initialized
DEBUG - 2022-06-22 10:19:02 --> UTF-8 Support Enabled
INFO - 2022-06-22 10:19:02 --> Utf8 Class Initialized
INFO - 2022-06-22 10:19:02 --> URI Class Initialized
INFO - 2022-06-22 10:19:02 --> Router Class Initialized
INFO - 2022-06-22 10:19:02 --> Output Class Initialized
INFO - 2022-06-22 10:19:02 --> Security Class Initialized
DEBUG - 2022-06-22 10:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 10:19:02 --> Input Class Initialized
INFO - 2022-06-22 10:19:02 --> Language Class Initialized
INFO - 2022-06-22 10:19:02 --> Loader Class Initialized
INFO - 2022-06-22 10:19:02 --> Helper loaded: url_helper
INFO - 2022-06-22 10:19:02 --> Helper loaded: file_helper
INFO - 2022-06-22 10:19:02 --> Database Driver Class Initialized
INFO - 2022-06-22 10:19:02 --> Email Class Initialized
DEBUG - 2022-06-22 10:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 10:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 10:19:02 --> Controller Class Initialized
INFO - 2022-06-22 10:19:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 10:19:02 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 10:19:02 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 10:19:02 --> Final output sent to browser
DEBUG - 2022-06-22 10:19:02 --> Total execution time: 0.1209
INFO - 2022-06-22 10:19:20 --> Config Class Initialized
INFO - 2022-06-22 10:19:20 --> Hooks Class Initialized
DEBUG - 2022-06-22 10:19:20 --> UTF-8 Support Enabled
INFO - 2022-06-22 10:19:20 --> Utf8 Class Initialized
INFO - 2022-06-22 10:19:20 --> URI Class Initialized
INFO - 2022-06-22 10:19:20 --> Router Class Initialized
INFO - 2022-06-22 10:19:20 --> Output Class Initialized
INFO - 2022-06-22 10:19:20 --> Security Class Initialized
DEBUG - 2022-06-22 10:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 10:19:20 --> Input Class Initialized
INFO - 2022-06-22 10:19:20 --> Language Class Initialized
INFO - 2022-06-22 10:19:20 --> Loader Class Initialized
INFO - 2022-06-22 10:19:20 --> Helper loaded: url_helper
INFO - 2022-06-22 10:19:20 --> Helper loaded: file_helper
INFO - 2022-06-22 10:19:20 --> Database Driver Class Initialized
INFO - 2022-06-22 10:19:20 --> Email Class Initialized
DEBUG - 2022-06-22 10:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 10:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 10:19:20 --> Controller Class Initialized
INFO - 2022-06-22 10:19:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 10:19:20 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 10:19:20 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 10:19:20 --> Final output sent to browser
DEBUG - 2022-06-22 10:19:20 --> Total execution time: 0.1316
INFO - 2022-06-22 10:19:36 --> Config Class Initialized
INFO - 2022-06-22 10:19:36 --> Hooks Class Initialized
DEBUG - 2022-06-22 10:19:36 --> UTF-8 Support Enabled
INFO - 2022-06-22 10:19:36 --> Utf8 Class Initialized
INFO - 2022-06-22 10:19:36 --> URI Class Initialized
INFO - 2022-06-22 10:19:36 --> Router Class Initialized
INFO - 2022-06-22 10:19:36 --> Output Class Initialized
INFO - 2022-06-22 10:19:36 --> Security Class Initialized
DEBUG - 2022-06-22 10:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 10:19:36 --> Input Class Initialized
INFO - 2022-06-22 10:19:36 --> Language Class Initialized
INFO - 2022-06-22 10:19:36 --> Loader Class Initialized
INFO - 2022-06-22 10:19:36 --> Helper loaded: url_helper
INFO - 2022-06-22 10:19:36 --> Helper loaded: file_helper
INFO - 2022-06-22 10:19:36 --> Database Driver Class Initialized
INFO - 2022-06-22 10:19:36 --> Email Class Initialized
DEBUG - 2022-06-22 10:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 10:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 10:19:36 --> Controller Class Initialized
INFO - 2022-06-22 10:19:36 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 10:19:36 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 10:19:36 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 10:19:36 --> Final output sent to browser
DEBUG - 2022-06-22 10:19:36 --> Total execution time: 0.0214
INFO - 2022-06-22 10:20:08 --> Config Class Initialized
INFO - 2022-06-22 10:20:08 --> Hooks Class Initialized
DEBUG - 2022-06-22 10:20:08 --> UTF-8 Support Enabled
INFO - 2022-06-22 10:20:08 --> Utf8 Class Initialized
INFO - 2022-06-22 10:20:08 --> URI Class Initialized
INFO - 2022-06-22 10:20:08 --> Router Class Initialized
INFO - 2022-06-22 10:20:08 --> Output Class Initialized
INFO - 2022-06-22 10:20:08 --> Security Class Initialized
DEBUG - 2022-06-22 10:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 10:20:08 --> Input Class Initialized
INFO - 2022-06-22 10:20:08 --> Language Class Initialized
INFO - 2022-06-22 10:20:08 --> Loader Class Initialized
INFO - 2022-06-22 10:20:08 --> Helper loaded: url_helper
INFO - 2022-06-22 10:20:08 --> Helper loaded: file_helper
INFO - 2022-06-22 10:20:08 --> Database Driver Class Initialized
INFO - 2022-06-22 10:20:08 --> Email Class Initialized
DEBUG - 2022-06-22 10:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 10:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 10:20:08 --> Controller Class Initialized
INFO - 2022-06-22 10:20:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 10:20:08 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 10:20:08 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 10:20:08 --> Final output sent to browser
DEBUG - 2022-06-22 10:20:08 --> Total execution time: 0.1298
INFO - 2022-06-22 10:20:14 --> Config Class Initialized
INFO - 2022-06-22 10:20:14 --> Hooks Class Initialized
DEBUG - 2022-06-22 10:20:14 --> UTF-8 Support Enabled
INFO - 2022-06-22 10:20:14 --> Utf8 Class Initialized
INFO - 2022-06-22 10:20:14 --> URI Class Initialized
INFO - 2022-06-22 10:20:14 --> Router Class Initialized
INFO - 2022-06-22 10:20:14 --> Output Class Initialized
INFO - 2022-06-22 10:20:14 --> Security Class Initialized
DEBUG - 2022-06-22 10:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 10:20:14 --> Input Class Initialized
INFO - 2022-06-22 10:20:14 --> Language Class Initialized
INFO - 2022-06-22 10:20:14 --> Loader Class Initialized
INFO - 2022-06-22 10:20:14 --> Helper loaded: url_helper
INFO - 2022-06-22 10:20:14 --> Helper loaded: file_helper
INFO - 2022-06-22 10:20:14 --> Database Driver Class Initialized
INFO - 2022-06-22 10:20:15 --> Email Class Initialized
DEBUG - 2022-06-22 10:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 10:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 10:20:15 --> Controller Class Initialized
INFO - 2022-06-22 10:20:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 10:20:15 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 10:20:15 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 10:20:15 --> Final output sent to browser
DEBUG - 2022-06-22 10:20:15 --> Total execution time: 0.1739
INFO - 2022-06-22 10:20:20 --> Config Class Initialized
INFO - 2022-06-22 10:20:20 --> Hooks Class Initialized
DEBUG - 2022-06-22 10:20:20 --> UTF-8 Support Enabled
INFO - 2022-06-22 10:20:20 --> Utf8 Class Initialized
INFO - 2022-06-22 10:20:20 --> URI Class Initialized
INFO - 2022-06-22 10:20:20 --> Router Class Initialized
INFO - 2022-06-22 10:20:20 --> Output Class Initialized
INFO - 2022-06-22 10:20:20 --> Security Class Initialized
DEBUG - 2022-06-22 10:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 10:20:20 --> Input Class Initialized
INFO - 2022-06-22 10:20:20 --> Language Class Initialized
INFO - 2022-06-22 10:20:20 --> Loader Class Initialized
INFO - 2022-06-22 10:20:20 --> Helper loaded: url_helper
INFO - 2022-06-22 10:20:20 --> Helper loaded: file_helper
INFO - 2022-06-22 10:20:20 --> Database Driver Class Initialized
INFO - 2022-06-22 10:20:20 --> Email Class Initialized
DEBUG - 2022-06-22 10:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 10:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 10:20:20 --> Controller Class Initialized
INFO - 2022-06-22 10:20:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 10:20:20 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 10:20:20 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 10:20:20 --> Final output sent to browser
DEBUG - 2022-06-22 10:20:20 --> Total execution time: 0.0178
INFO - 2022-06-22 10:22:11 --> Config Class Initialized
INFO - 2022-06-22 10:22:11 --> Hooks Class Initialized
DEBUG - 2022-06-22 10:22:11 --> UTF-8 Support Enabled
INFO - 2022-06-22 10:22:11 --> Utf8 Class Initialized
INFO - 2022-06-22 10:22:11 --> URI Class Initialized
INFO - 2022-06-22 10:22:11 --> Router Class Initialized
INFO - 2022-06-22 10:22:11 --> Output Class Initialized
INFO - 2022-06-22 10:22:11 --> Security Class Initialized
DEBUG - 2022-06-22 10:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 10:22:11 --> Input Class Initialized
INFO - 2022-06-22 10:22:11 --> Language Class Initialized
INFO - 2022-06-22 10:22:11 --> Loader Class Initialized
INFO - 2022-06-22 10:22:11 --> Helper loaded: url_helper
INFO - 2022-06-22 10:22:11 --> Helper loaded: file_helper
INFO - 2022-06-22 10:22:11 --> Database Driver Class Initialized
INFO - 2022-06-22 10:22:11 --> Email Class Initialized
DEBUG - 2022-06-22 10:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 10:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 10:22:11 --> Controller Class Initialized
INFO - 2022-06-22 10:22:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 10:22:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 10:22:11 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 10:22:11 --> Final output sent to browser
DEBUG - 2022-06-22 10:22:11 --> Total execution time: 0.1210
INFO - 2022-06-22 10:22:17 --> Config Class Initialized
INFO - 2022-06-22 10:22:17 --> Hooks Class Initialized
DEBUG - 2022-06-22 10:22:17 --> UTF-8 Support Enabled
INFO - 2022-06-22 10:22:17 --> Utf8 Class Initialized
INFO - 2022-06-22 10:22:17 --> URI Class Initialized
INFO - 2022-06-22 10:22:17 --> Router Class Initialized
INFO - 2022-06-22 10:22:17 --> Output Class Initialized
INFO - 2022-06-22 10:22:17 --> Security Class Initialized
DEBUG - 2022-06-22 10:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 10:22:17 --> Input Class Initialized
INFO - 2022-06-22 10:22:17 --> Language Class Initialized
INFO - 2022-06-22 10:22:17 --> Loader Class Initialized
INFO - 2022-06-22 10:22:17 --> Helper loaded: url_helper
INFO - 2022-06-22 10:22:17 --> Helper loaded: file_helper
INFO - 2022-06-22 10:22:17 --> Database Driver Class Initialized
INFO - 2022-06-22 10:22:18 --> Email Class Initialized
DEBUG - 2022-06-22 10:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 10:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 10:22:18 --> Controller Class Initialized
INFO - 2022-06-22 10:22:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 10:22:18 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 10:22:18 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 10:22:18 --> Final output sent to browser
DEBUG - 2022-06-22 10:22:18 --> Total execution time: 0.2087
INFO - 2022-06-22 10:22:21 --> Config Class Initialized
INFO - 2022-06-22 10:22:21 --> Hooks Class Initialized
DEBUG - 2022-06-22 10:22:21 --> UTF-8 Support Enabled
INFO - 2022-06-22 10:22:21 --> Utf8 Class Initialized
INFO - 2022-06-22 10:22:21 --> URI Class Initialized
INFO - 2022-06-22 10:22:21 --> Router Class Initialized
INFO - 2022-06-22 10:22:21 --> Output Class Initialized
INFO - 2022-06-22 10:22:21 --> Security Class Initialized
DEBUG - 2022-06-22 10:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 10:22:21 --> Input Class Initialized
INFO - 2022-06-22 10:22:21 --> Language Class Initialized
INFO - 2022-06-22 10:22:21 --> Loader Class Initialized
INFO - 2022-06-22 10:22:21 --> Helper loaded: url_helper
INFO - 2022-06-22 10:22:21 --> Helper loaded: file_helper
INFO - 2022-06-22 10:22:21 --> Database Driver Class Initialized
INFO - 2022-06-22 10:22:21 --> Email Class Initialized
DEBUG - 2022-06-22 10:22:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 10:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 10:22:21 --> Controller Class Initialized
INFO - 2022-06-22 10:22:21 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 10:22:21 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 10:22:21 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 10:22:21 --> Final output sent to browser
DEBUG - 2022-06-22 10:22:21 --> Total execution time: 0.0242
INFO - 2022-06-22 10:22:28 --> Config Class Initialized
INFO - 2022-06-22 10:22:28 --> Hooks Class Initialized
DEBUG - 2022-06-22 10:22:28 --> UTF-8 Support Enabled
INFO - 2022-06-22 10:22:28 --> Utf8 Class Initialized
INFO - 2022-06-22 10:22:28 --> URI Class Initialized
INFO - 2022-06-22 10:22:28 --> Router Class Initialized
INFO - 2022-06-22 10:22:28 --> Output Class Initialized
INFO - 2022-06-22 10:22:28 --> Security Class Initialized
DEBUG - 2022-06-22 10:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 10:22:28 --> Input Class Initialized
INFO - 2022-06-22 10:22:28 --> Language Class Initialized
INFO - 2022-06-22 10:22:28 --> Loader Class Initialized
INFO - 2022-06-22 10:22:28 --> Helper loaded: url_helper
INFO - 2022-06-22 10:22:28 --> Helper loaded: file_helper
INFO - 2022-06-22 10:22:28 --> Database Driver Class Initialized
INFO - 2022-06-22 10:22:28 --> Email Class Initialized
DEBUG - 2022-06-22 10:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 10:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 10:22:28 --> Controller Class Initialized
INFO - 2022-06-22 10:22:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 10:22:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 10:22:28 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 10:22:28 --> Final output sent to browser
DEBUG - 2022-06-22 10:22:28 --> Total execution time: 0.0193
INFO - 2022-06-22 10:22:35 --> Config Class Initialized
INFO - 2022-06-22 10:22:35 --> Hooks Class Initialized
DEBUG - 2022-06-22 10:22:35 --> UTF-8 Support Enabled
INFO - 2022-06-22 10:22:35 --> Utf8 Class Initialized
INFO - 2022-06-22 10:22:35 --> URI Class Initialized
INFO - 2022-06-22 10:22:35 --> Router Class Initialized
INFO - 2022-06-22 10:22:35 --> Output Class Initialized
INFO - 2022-06-22 10:22:35 --> Security Class Initialized
DEBUG - 2022-06-22 10:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 10:22:35 --> Input Class Initialized
INFO - 2022-06-22 10:22:35 --> Language Class Initialized
INFO - 2022-06-22 10:22:35 --> Loader Class Initialized
INFO - 2022-06-22 10:22:35 --> Helper loaded: url_helper
INFO - 2022-06-22 10:22:35 --> Helper loaded: file_helper
INFO - 2022-06-22 10:22:35 --> Database Driver Class Initialized
INFO - 2022-06-22 10:22:35 --> Email Class Initialized
DEBUG - 2022-06-22 10:22:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 10:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 10:22:35 --> Controller Class Initialized
INFO - 2022-06-22 10:22:35 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 10:22:35 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 10:22:35 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 10:22:35 --> Final output sent to browser
DEBUG - 2022-06-22 10:22:35 --> Total execution time: 0.0363
INFO - 2022-06-22 10:24:58 --> Config Class Initialized
INFO - 2022-06-22 10:24:58 --> Hooks Class Initialized
DEBUG - 2022-06-22 10:24:58 --> UTF-8 Support Enabled
INFO - 2022-06-22 10:24:58 --> Utf8 Class Initialized
INFO - 2022-06-22 10:24:58 --> URI Class Initialized
INFO - 2022-06-22 10:24:58 --> Router Class Initialized
INFO - 2022-06-22 10:24:58 --> Output Class Initialized
INFO - 2022-06-22 10:24:58 --> Security Class Initialized
DEBUG - 2022-06-22 10:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 10:24:58 --> Input Class Initialized
INFO - 2022-06-22 10:24:58 --> Language Class Initialized
INFO - 2022-06-22 10:24:58 --> Loader Class Initialized
INFO - 2022-06-22 10:24:58 --> Helper loaded: url_helper
INFO - 2022-06-22 10:24:58 --> Helper loaded: file_helper
INFO - 2022-06-22 10:24:58 --> Database Driver Class Initialized
INFO - 2022-06-22 10:24:58 --> Email Class Initialized
DEBUG - 2022-06-22 10:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 10:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 10:24:58 --> Controller Class Initialized
INFO - 2022-06-22 10:24:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 10:24:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 10:24:58 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 10:24:58 --> Final output sent to browser
DEBUG - 2022-06-22 10:24:58 --> Total execution time: 0.1596
INFO - 2022-06-22 10:25:05 --> Config Class Initialized
INFO - 2022-06-22 10:25:05 --> Hooks Class Initialized
DEBUG - 2022-06-22 10:25:05 --> UTF-8 Support Enabled
INFO - 2022-06-22 10:25:05 --> Utf8 Class Initialized
INFO - 2022-06-22 10:25:05 --> URI Class Initialized
INFO - 2022-06-22 10:25:05 --> Router Class Initialized
INFO - 2022-06-22 10:25:05 --> Output Class Initialized
INFO - 2022-06-22 10:25:05 --> Security Class Initialized
DEBUG - 2022-06-22 10:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 10:25:05 --> Input Class Initialized
INFO - 2022-06-22 10:25:05 --> Language Class Initialized
INFO - 2022-06-22 10:25:05 --> Loader Class Initialized
INFO - 2022-06-22 10:25:05 --> Helper loaded: url_helper
INFO - 2022-06-22 10:25:05 --> Helper loaded: file_helper
INFO - 2022-06-22 10:25:05 --> Database Driver Class Initialized
INFO - 2022-06-22 10:25:05 --> Email Class Initialized
DEBUG - 2022-06-22 10:25:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 10:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 10:25:05 --> Controller Class Initialized
INFO - 2022-06-22 10:25:05 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 10:25:05 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 10:25:05 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 10:25:05 --> Final output sent to browser
DEBUG - 2022-06-22 10:25:05 --> Total execution time: 0.0358
INFO - 2022-06-22 10:27:10 --> Config Class Initialized
INFO - 2022-06-22 10:27:10 --> Hooks Class Initialized
DEBUG - 2022-06-22 10:27:10 --> UTF-8 Support Enabled
INFO - 2022-06-22 10:27:10 --> Utf8 Class Initialized
INFO - 2022-06-22 10:27:10 --> URI Class Initialized
INFO - 2022-06-22 10:27:10 --> Router Class Initialized
INFO - 2022-06-22 10:27:10 --> Output Class Initialized
INFO - 2022-06-22 10:27:10 --> Security Class Initialized
DEBUG - 2022-06-22 10:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 10:27:10 --> Input Class Initialized
INFO - 2022-06-22 10:27:10 --> Language Class Initialized
INFO - 2022-06-22 10:27:10 --> Loader Class Initialized
INFO - 2022-06-22 10:27:10 --> Helper loaded: url_helper
INFO - 2022-06-22 10:27:10 --> Helper loaded: file_helper
INFO - 2022-06-22 10:27:10 --> Database Driver Class Initialized
INFO - 2022-06-22 10:27:10 --> Email Class Initialized
DEBUG - 2022-06-22 10:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 10:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 10:27:10 --> Controller Class Initialized
INFO - 2022-06-22 10:27:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 10:27:10 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 10:27:10 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 10:27:10 --> Final output sent to browser
DEBUG - 2022-06-22 10:27:10 --> Total execution time: 0.1561
INFO - 2022-06-22 10:27:19 --> Config Class Initialized
INFO - 2022-06-22 10:27:19 --> Hooks Class Initialized
DEBUG - 2022-06-22 10:27:19 --> UTF-8 Support Enabled
INFO - 2022-06-22 10:27:19 --> Utf8 Class Initialized
INFO - 2022-06-22 10:27:19 --> URI Class Initialized
INFO - 2022-06-22 10:27:19 --> Router Class Initialized
INFO - 2022-06-22 10:27:20 --> Output Class Initialized
INFO - 2022-06-22 10:27:20 --> Security Class Initialized
DEBUG - 2022-06-22 10:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 10:27:20 --> Input Class Initialized
INFO - 2022-06-22 10:27:20 --> Language Class Initialized
INFO - 2022-06-22 10:27:20 --> Loader Class Initialized
INFO - 2022-06-22 10:27:20 --> Helper loaded: url_helper
INFO - 2022-06-22 10:27:20 --> Helper loaded: file_helper
INFO - 2022-06-22 10:27:20 --> Database Driver Class Initialized
INFO - 2022-06-22 10:27:20 --> Email Class Initialized
DEBUG - 2022-06-22 10:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 10:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 10:27:20 --> Controller Class Initialized
INFO - 2022-06-22 10:27:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 10:27:20 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 10:27:20 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 10:27:20 --> Final output sent to browser
DEBUG - 2022-06-22 10:27:20 --> Total execution time: 0.1566
INFO - 2022-06-22 10:29:53 --> Config Class Initialized
INFO - 2022-06-22 10:29:53 --> Hooks Class Initialized
DEBUG - 2022-06-22 10:29:53 --> UTF-8 Support Enabled
INFO - 2022-06-22 10:29:53 --> Utf8 Class Initialized
INFO - 2022-06-22 10:29:53 --> URI Class Initialized
INFO - 2022-06-22 10:29:53 --> Router Class Initialized
INFO - 2022-06-22 10:29:53 --> Output Class Initialized
INFO - 2022-06-22 10:29:53 --> Security Class Initialized
DEBUG - 2022-06-22 10:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 10:29:53 --> Input Class Initialized
INFO - 2022-06-22 10:29:53 --> Language Class Initialized
INFO - 2022-06-22 10:29:53 --> Loader Class Initialized
INFO - 2022-06-22 10:29:53 --> Helper loaded: url_helper
INFO - 2022-06-22 10:29:53 --> Helper loaded: file_helper
INFO - 2022-06-22 10:29:53 --> Database Driver Class Initialized
INFO - 2022-06-22 10:29:53 --> Email Class Initialized
DEBUG - 2022-06-22 10:29:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 10:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 10:29:53 --> Controller Class Initialized
INFO - 2022-06-22 10:29:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 10:29:53 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 10:29:53 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 10:29:53 --> Final output sent to browser
DEBUG - 2022-06-22 10:29:53 --> Total execution time: 0.1488
INFO - 2022-06-22 10:29:55 --> Config Class Initialized
INFO - 2022-06-22 10:29:55 --> Hooks Class Initialized
DEBUG - 2022-06-22 10:29:55 --> UTF-8 Support Enabled
INFO - 2022-06-22 10:29:55 --> Utf8 Class Initialized
INFO - 2022-06-22 10:29:55 --> URI Class Initialized
INFO - 2022-06-22 10:29:55 --> Router Class Initialized
INFO - 2022-06-22 10:29:55 --> Output Class Initialized
INFO - 2022-06-22 10:29:55 --> Security Class Initialized
DEBUG - 2022-06-22 10:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 10:29:55 --> Input Class Initialized
INFO - 2022-06-22 10:29:55 --> Language Class Initialized
INFO - 2022-06-22 10:29:55 --> Loader Class Initialized
INFO - 2022-06-22 10:29:55 --> Helper loaded: url_helper
INFO - 2022-06-22 10:29:55 --> Helper loaded: file_helper
INFO - 2022-06-22 10:29:55 --> Database Driver Class Initialized
INFO - 2022-06-22 10:29:55 --> Email Class Initialized
DEBUG - 2022-06-22 10:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 10:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 10:29:55 --> Controller Class Initialized
INFO - 2022-06-22 10:29:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 10:29:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 10:29:55 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 10:29:55 --> Final output sent to browser
DEBUG - 2022-06-22 10:29:55 --> Total execution time: 0.0191
INFO - 2022-06-22 10:30:00 --> Config Class Initialized
INFO - 2022-06-22 10:30:00 --> Hooks Class Initialized
DEBUG - 2022-06-22 10:30:00 --> UTF-8 Support Enabled
INFO - 2022-06-22 10:30:00 --> Utf8 Class Initialized
INFO - 2022-06-22 10:30:00 --> URI Class Initialized
INFO - 2022-06-22 10:30:00 --> Router Class Initialized
INFO - 2022-06-22 10:30:00 --> Output Class Initialized
INFO - 2022-06-22 10:30:00 --> Security Class Initialized
DEBUG - 2022-06-22 10:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 10:30:00 --> Input Class Initialized
INFO - 2022-06-22 10:30:00 --> Language Class Initialized
INFO - 2022-06-22 10:30:00 --> Loader Class Initialized
INFO - 2022-06-22 10:30:00 --> Helper loaded: url_helper
INFO - 2022-06-22 10:30:00 --> Helper loaded: file_helper
INFO - 2022-06-22 10:30:00 --> Database Driver Class Initialized
INFO - 2022-06-22 10:30:00 --> Email Class Initialized
DEBUG - 2022-06-22 10:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 10:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 10:30:00 --> Controller Class Initialized
INFO - 2022-06-22 10:30:00 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 10:30:00 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 10:30:00 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 10:30:00 --> Final output sent to browser
DEBUG - 2022-06-22 10:30:00 --> Total execution time: 0.0639
INFO - 2022-06-22 10:31:18 --> Config Class Initialized
INFO - 2022-06-22 10:31:18 --> Hooks Class Initialized
DEBUG - 2022-06-22 10:31:18 --> UTF-8 Support Enabled
INFO - 2022-06-22 10:31:18 --> Utf8 Class Initialized
INFO - 2022-06-22 10:31:18 --> URI Class Initialized
INFO - 2022-06-22 10:31:18 --> Router Class Initialized
INFO - 2022-06-22 10:31:18 --> Output Class Initialized
INFO - 2022-06-22 10:31:18 --> Security Class Initialized
DEBUG - 2022-06-22 10:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 10:31:18 --> Input Class Initialized
INFO - 2022-06-22 10:31:18 --> Language Class Initialized
INFO - 2022-06-22 10:31:18 --> Loader Class Initialized
INFO - 2022-06-22 10:31:18 --> Helper loaded: url_helper
INFO - 2022-06-22 10:31:18 --> Helper loaded: file_helper
INFO - 2022-06-22 10:31:18 --> Database Driver Class Initialized
INFO - 2022-06-22 10:31:18 --> Email Class Initialized
DEBUG - 2022-06-22 10:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 10:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 10:31:18 --> Controller Class Initialized
INFO - 2022-06-22 10:31:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 10:31:18 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 10:31:18 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 10:31:18 --> Final output sent to browser
DEBUG - 2022-06-22 10:31:18 --> Total execution time: 0.1233
INFO - 2022-06-22 10:31:29 --> Config Class Initialized
INFO - 2022-06-22 10:31:29 --> Hooks Class Initialized
DEBUG - 2022-06-22 10:31:29 --> UTF-8 Support Enabled
INFO - 2022-06-22 10:31:29 --> Utf8 Class Initialized
INFO - 2022-06-22 10:31:29 --> URI Class Initialized
INFO - 2022-06-22 10:31:29 --> Router Class Initialized
INFO - 2022-06-22 10:31:29 --> Output Class Initialized
INFO - 2022-06-22 10:31:29 --> Security Class Initialized
DEBUG - 2022-06-22 10:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 10:31:29 --> Input Class Initialized
INFO - 2022-06-22 10:31:29 --> Language Class Initialized
INFO - 2022-06-22 10:31:29 --> Loader Class Initialized
INFO - 2022-06-22 10:31:29 --> Helper loaded: url_helper
INFO - 2022-06-22 10:31:29 --> Helper loaded: file_helper
INFO - 2022-06-22 10:31:29 --> Database Driver Class Initialized
INFO - 2022-06-22 10:31:29 --> Email Class Initialized
DEBUG - 2022-06-22 10:31:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 10:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 10:31:29 --> Controller Class Initialized
INFO - 2022-06-22 10:31:29 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 10:31:29 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 10:31:29 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 10:31:29 --> Final output sent to browser
DEBUG - 2022-06-22 10:31:29 --> Total execution time: 0.1358
INFO - 2022-06-22 10:31:36 --> Config Class Initialized
INFO - 2022-06-22 10:31:36 --> Hooks Class Initialized
DEBUG - 2022-06-22 10:31:36 --> UTF-8 Support Enabled
INFO - 2022-06-22 10:31:36 --> Utf8 Class Initialized
INFO - 2022-06-22 10:31:36 --> URI Class Initialized
INFO - 2022-06-22 10:31:36 --> Router Class Initialized
INFO - 2022-06-22 10:31:36 --> Output Class Initialized
INFO - 2022-06-22 10:31:36 --> Security Class Initialized
DEBUG - 2022-06-22 10:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 10:31:36 --> Input Class Initialized
INFO - 2022-06-22 10:31:36 --> Language Class Initialized
INFO - 2022-06-22 10:31:36 --> Loader Class Initialized
INFO - 2022-06-22 10:31:36 --> Helper loaded: url_helper
INFO - 2022-06-22 10:31:36 --> Helper loaded: file_helper
INFO - 2022-06-22 10:31:36 --> Database Driver Class Initialized
INFO - 2022-06-22 10:31:36 --> Email Class Initialized
DEBUG - 2022-06-22 10:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 10:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 10:31:36 --> Controller Class Initialized
INFO - 2022-06-22 10:31:36 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 10:31:36 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 10:31:36 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 10:31:36 --> Final output sent to browser
DEBUG - 2022-06-22 10:31:36 --> Total execution time: 0.0218
INFO - 2022-06-22 10:32:37 --> Config Class Initialized
INFO - 2022-06-22 10:32:37 --> Hooks Class Initialized
DEBUG - 2022-06-22 10:32:37 --> UTF-8 Support Enabled
INFO - 2022-06-22 10:32:37 --> Utf8 Class Initialized
INFO - 2022-06-22 10:32:37 --> URI Class Initialized
INFO - 2022-06-22 10:32:37 --> Router Class Initialized
INFO - 2022-06-22 10:32:37 --> Output Class Initialized
INFO - 2022-06-22 10:32:37 --> Security Class Initialized
DEBUG - 2022-06-22 10:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 10:32:37 --> Input Class Initialized
INFO - 2022-06-22 10:32:37 --> Language Class Initialized
INFO - 2022-06-22 10:32:37 --> Loader Class Initialized
INFO - 2022-06-22 10:32:37 --> Helper loaded: url_helper
INFO - 2022-06-22 10:32:37 --> Helper loaded: file_helper
INFO - 2022-06-22 10:32:37 --> Database Driver Class Initialized
INFO - 2022-06-22 10:32:38 --> Email Class Initialized
DEBUG - 2022-06-22 10:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 10:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 10:32:38 --> Controller Class Initialized
INFO - 2022-06-22 10:32:38 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 10:32:38 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 10:32:38 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 10:32:38 --> Final output sent to browser
DEBUG - 2022-06-22 10:32:38 --> Total execution time: 0.1470
INFO - 2022-06-22 10:32:43 --> Config Class Initialized
INFO - 2022-06-22 10:32:43 --> Hooks Class Initialized
DEBUG - 2022-06-22 10:32:43 --> UTF-8 Support Enabled
INFO - 2022-06-22 10:32:43 --> Utf8 Class Initialized
INFO - 2022-06-22 10:32:43 --> URI Class Initialized
INFO - 2022-06-22 10:32:43 --> Router Class Initialized
INFO - 2022-06-22 10:32:43 --> Output Class Initialized
INFO - 2022-06-22 10:32:43 --> Security Class Initialized
DEBUG - 2022-06-22 10:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 10:32:43 --> Input Class Initialized
INFO - 2022-06-22 10:32:43 --> Language Class Initialized
INFO - 2022-06-22 10:32:43 --> Loader Class Initialized
INFO - 2022-06-22 10:32:43 --> Helper loaded: url_helper
INFO - 2022-06-22 10:32:43 --> Helper loaded: file_helper
INFO - 2022-06-22 10:32:43 --> Database Driver Class Initialized
INFO - 2022-06-22 10:32:43 --> Email Class Initialized
DEBUG - 2022-06-22 10:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 10:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 10:32:43 --> Controller Class Initialized
INFO - 2022-06-22 10:32:43 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 10:32:43 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 10:32:43 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 10:32:43 --> Final output sent to browser
DEBUG - 2022-06-22 10:32:43 --> Total execution time: 0.0255
INFO - 2022-06-22 10:32:50 --> Config Class Initialized
INFO - 2022-06-22 10:32:50 --> Hooks Class Initialized
DEBUG - 2022-06-22 10:32:50 --> UTF-8 Support Enabled
INFO - 2022-06-22 10:32:50 --> Utf8 Class Initialized
INFO - 2022-06-22 10:32:50 --> URI Class Initialized
INFO - 2022-06-22 10:32:50 --> Router Class Initialized
INFO - 2022-06-22 10:32:50 --> Output Class Initialized
INFO - 2022-06-22 10:32:50 --> Security Class Initialized
DEBUG - 2022-06-22 10:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 10:32:50 --> Input Class Initialized
INFO - 2022-06-22 10:32:50 --> Language Class Initialized
INFO - 2022-06-22 10:32:50 --> Loader Class Initialized
INFO - 2022-06-22 10:32:50 --> Helper loaded: url_helper
INFO - 2022-06-22 10:32:50 --> Helper loaded: file_helper
INFO - 2022-06-22 10:32:50 --> Database Driver Class Initialized
INFO - 2022-06-22 10:32:50 --> Email Class Initialized
DEBUG - 2022-06-22 10:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 10:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 10:32:50 --> Controller Class Initialized
INFO - 2022-06-22 10:32:50 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 10:32:50 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 10:32:50 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 10:32:50 --> Final output sent to browser
DEBUG - 2022-06-22 10:32:50 --> Total execution time: 0.1510
INFO - 2022-06-22 11:10:31 --> Config Class Initialized
INFO - 2022-06-22 11:10:31 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:10:31 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:10:31 --> Utf8 Class Initialized
INFO - 2022-06-22 11:10:31 --> URI Class Initialized
INFO - 2022-06-22 11:10:31 --> Router Class Initialized
INFO - 2022-06-22 11:10:31 --> Output Class Initialized
INFO - 2022-06-22 11:10:31 --> Security Class Initialized
DEBUG - 2022-06-22 11:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:10:31 --> Input Class Initialized
INFO - 2022-06-22 11:10:31 --> Language Class Initialized
INFO - 2022-06-22 11:10:31 --> Loader Class Initialized
INFO - 2022-06-22 11:10:31 --> Helper loaded: url_helper
INFO - 2022-06-22 11:10:31 --> Helper loaded: file_helper
INFO - 2022-06-22 11:10:31 --> Database Driver Class Initialized
INFO - 2022-06-22 11:10:31 --> Email Class Initialized
DEBUG - 2022-06-22 11:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:10:31 --> Controller Class Initialized
INFO - 2022-06-22 11:10:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:10:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 11:10:31 --> Severity: Warning --> Use of undefined constant ud_eotp - assumed 'ud_eotp' (this will throw an Error in a future version of PHP) C:\wamp64\www\qr\application\controllers\Tokenctrl.php 37
ERROR - 2022-06-22 11:10:31 --> Severity: Warning --> Use of undefined constant ud_otp - assumed 'ud_otp' (this will throw an Error in a future version of PHP) C:\wamp64\www\qr\application\controllers\Tokenctrl.php 37
ERROR - 2022-06-22 11:10:31 --> Severity: error --> Exception: Call to undefined function alert() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 43
INFO - 2022-06-22 11:10:37 --> Config Class Initialized
INFO - 2022-06-22 11:10:37 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:10:37 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:10:37 --> Utf8 Class Initialized
INFO - 2022-06-22 11:10:37 --> URI Class Initialized
INFO - 2022-06-22 11:10:37 --> Router Class Initialized
INFO - 2022-06-22 11:10:37 --> Output Class Initialized
INFO - 2022-06-22 11:10:37 --> Security Class Initialized
DEBUG - 2022-06-22 11:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:10:37 --> Input Class Initialized
INFO - 2022-06-22 11:10:37 --> Language Class Initialized
INFO - 2022-06-22 11:10:37 --> Loader Class Initialized
INFO - 2022-06-22 11:10:37 --> Helper loaded: url_helper
INFO - 2022-06-22 11:10:37 --> Helper loaded: file_helper
INFO - 2022-06-22 11:10:37 --> Database Driver Class Initialized
INFO - 2022-06-22 11:10:37 --> Email Class Initialized
DEBUG - 2022-06-22 11:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:10:37 --> Controller Class Initialized
INFO - 2022-06-22 11:10:37 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:10:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-22 11:10:37 --> Severity: Warning --> Use of undefined constant ud_eotp - assumed 'ud_eotp' (this will throw an Error in a future version of PHP) C:\wamp64\www\qr\application\controllers\Tokenctrl.php 37
ERROR - 2022-06-22 11:10:37 --> Severity: Warning --> Use of undefined constant ud_otp - assumed 'ud_otp' (this will throw an Error in a future version of PHP) C:\wamp64\www\qr\application\controllers\Tokenctrl.php 37
ERROR - 2022-06-22 11:10:37 --> Severity: error --> Exception: Call to undefined function alert() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 43
INFO - 2022-06-22 11:11:25 --> Config Class Initialized
INFO - 2022-06-22 11:11:25 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:11:25 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:11:25 --> Utf8 Class Initialized
INFO - 2022-06-22 11:11:25 --> URI Class Initialized
INFO - 2022-06-22 11:11:25 --> Router Class Initialized
INFO - 2022-06-22 11:11:25 --> Output Class Initialized
INFO - 2022-06-22 11:11:25 --> Security Class Initialized
DEBUG - 2022-06-22 11:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:11:25 --> Input Class Initialized
INFO - 2022-06-22 11:11:25 --> Language Class Initialized
INFO - 2022-06-22 11:11:25 --> Loader Class Initialized
INFO - 2022-06-22 11:11:25 --> Helper loaded: url_helper
INFO - 2022-06-22 11:11:25 --> Helper loaded: file_helper
INFO - 2022-06-22 11:11:25 --> Database Driver Class Initialized
INFO - 2022-06-22 11:11:25 --> Email Class Initialized
DEBUG - 2022-06-22 11:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:11:25 --> Controller Class Initialized
INFO - 2022-06-22 11:11:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:11:25 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:11:25 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:11:25 --> Final output sent to browser
DEBUG - 2022-06-22 11:11:25 --> Total execution time: 0.0370
INFO - 2022-06-22 11:11:36 --> Config Class Initialized
INFO - 2022-06-22 11:11:36 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:11:36 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:11:36 --> Utf8 Class Initialized
INFO - 2022-06-22 11:11:36 --> URI Class Initialized
INFO - 2022-06-22 11:11:36 --> Router Class Initialized
INFO - 2022-06-22 11:11:36 --> Output Class Initialized
INFO - 2022-06-22 11:11:36 --> Security Class Initialized
DEBUG - 2022-06-22 11:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:11:36 --> Input Class Initialized
INFO - 2022-06-22 11:11:36 --> Language Class Initialized
INFO - 2022-06-22 11:11:36 --> Loader Class Initialized
INFO - 2022-06-22 11:11:36 --> Helper loaded: url_helper
INFO - 2022-06-22 11:11:36 --> Helper loaded: file_helper
INFO - 2022-06-22 11:11:36 --> Database Driver Class Initialized
INFO - 2022-06-22 11:11:36 --> Email Class Initialized
DEBUG - 2022-06-22 11:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:11:36 --> Controller Class Initialized
INFO - 2022-06-22 11:11:36 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:11:36 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:11:36 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:11:36 --> Final output sent to browser
DEBUG - 2022-06-22 11:11:36 --> Total execution time: 0.1383
INFO - 2022-06-22 11:12:03 --> Config Class Initialized
INFO - 2022-06-22 11:12:03 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:12:03 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:12:03 --> Utf8 Class Initialized
INFO - 2022-06-22 11:12:03 --> URI Class Initialized
INFO - 2022-06-22 11:12:03 --> Router Class Initialized
INFO - 2022-06-22 11:12:03 --> Output Class Initialized
INFO - 2022-06-22 11:12:03 --> Security Class Initialized
DEBUG - 2022-06-22 11:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:12:03 --> Input Class Initialized
INFO - 2022-06-22 11:12:03 --> Language Class Initialized
INFO - 2022-06-22 11:12:03 --> Loader Class Initialized
INFO - 2022-06-22 11:12:03 --> Helper loaded: url_helper
INFO - 2022-06-22 11:12:03 --> Helper loaded: file_helper
INFO - 2022-06-22 11:12:03 --> Database Driver Class Initialized
INFO - 2022-06-22 11:12:03 --> Email Class Initialized
DEBUG - 2022-06-22 11:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:12:03 --> Controller Class Initialized
INFO - 2022-06-22 11:12:03 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:12:03 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:12:03 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:12:03 --> Final output sent to browser
DEBUG - 2022-06-22 11:12:03 --> Total execution time: 0.0323
INFO - 2022-06-22 11:12:08 --> Config Class Initialized
INFO - 2022-06-22 11:12:08 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:12:08 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:12:08 --> Utf8 Class Initialized
INFO - 2022-06-22 11:12:08 --> URI Class Initialized
INFO - 2022-06-22 11:12:08 --> Router Class Initialized
INFO - 2022-06-22 11:12:08 --> Output Class Initialized
INFO - 2022-06-22 11:12:08 --> Security Class Initialized
DEBUG - 2022-06-22 11:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:12:08 --> Input Class Initialized
INFO - 2022-06-22 11:12:08 --> Language Class Initialized
INFO - 2022-06-22 11:12:08 --> Loader Class Initialized
INFO - 2022-06-22 11:12:08 --> Helper loaded: url_helper
INFO - 2022-06-22 11:12:08 --> Helper loaded: file_helper
INFO - 2022-06-22 11:12:08 --> Database Driver Class Initialized
INFO - 2022-06-22 11:12:08 --> Email Class Initialized
DEBUG - 2022-06-22 11:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:12:08 --> Controller Class Initialized
INFO - 2022-06-22 11:12:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:12:08 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:12:08 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:12:08 --> Final output sent to browser
DEBUG - 2022-06-22 11:12:08 --> Total execution time: 0.1234
INFO - 2022-06-22 11:12:15 --> Config Class Initialized
INFO - 2022-06-22 11:12:15 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:12:15 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:12:15 --> Utf8 Class Initialized
INFO - 2022-06-22 11:12:15 --> URI Class Initialized
INFO - 2022-06-22 11:12:15 --> Router Class Initialized
INFO - 2022-06-22 11:12:15 --> Output Class Initialized
INFO - 2022-06-22 11:12:15 --> Security Class Initialized
DEBUG - 2022-06-22 11:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:12:15 --> Input Class Initialized
INFO - 2022-06-22 11:12:15 --> Language Class Initialized
INFO - 2022-06-22 11:12:15 --> Loader Class Initialized
INFO - 2022-06-22 11:12:15 --> Helper loaded: url_helper
INFO - 2022-06-22 11:12:15 --> Helper loaded: file_helper
INFO - 2022-06-22 11:12:15 --> Database Driver Class Initialized
INFO - 2022-06-22 11:12:15 --> Email Class Initialized
DEBUG - 2022-06-22 11:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:12:15 --> Controller Class Initialized
INFO - 2022-06-22 11:12:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:12:15 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:12:15 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:12:15 --> Final output sent to browser
DEBUG - 2022-06-22 11:12:15 --> Total execution time: 0.0167
INFO - 2022-06-22 11:12:45 --> Config Class Initialized
INFO - 2022-06-22 11:12:45 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:12:45 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:12:45 --> Utf8 Class Initialized
INFO - 2022-06-22 11:12:45 --> URI Class Initialized
INFO - 2022-06-22 11:12:45 --> Router Class Initialized
INFO - 2022-06-22 11:12:45 --> Output Class Initialized
INFO - 2022-06-22 11:12:45 --> Security Class Initialized
DEBUG - 2022-06-22 11:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:12:45 --> Input Class Initialized
INFO - 2022-06-22 11:12:45 --> Language Class Initialized
INFO - 2022-06-22 11:12:45 --> Loader Class Initialized
INFO - 2022-06-22 11:12:45 --> Helper loaded: url_helper
INFO - 2022-06-22 11:12:45 --> Helper loaded: file_helper
INFO - 2022-06-22 11:12:45 --> Database Driver Class Initialized
INFO - 2022-06-22 11:12:45 --> Email Class Initialized
DEBUG - 2022-06-22 11:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:12:45 --> Controller Class Initialized
INFO - 2022-06-22 11:12:45 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:12:45 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:12:45 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:12:45 --> Final output sent to browser
DEBUG - 2022-06-22 11:12:45 --> Total execution time: 0.0172
INFO - 2022-06-22 11:12:52 --> Config Class Initialized
INFO - 2022-06-22 11:12:52 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:12:52 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:12:52 --> Utf8 Class Initialized
INFO - 2022-06-22 11:12:52 --> URI Class Initialized
INFO - 2022-06-22 11:12:52 --> Router Class Initialized
INFO - 2022-06-22 11:12:52 --> Output Class Initialized
INFO - 2022-06-22 11:12:52 --> Security Class Initialized
DEBUG - 2022-06-22 11:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:12:52 --> Input Class Initialized
INFO - 2022-06-22 11:12:52 --> Language Class Initialized
INFO - 2022-06-22 11:12:52 --> Loader Class Initialized
INFO - 2022-06-22 11:12:52 --> Helper loaded: url_helper
INFO - 2022-06-22 11:12:52 --> Helper loaded: file_helper
INFO - 2022-06-22 11:12:52 --> Database Driver Class Initialized
INFO - 2022-06-22 11:12:52 --> Email Class Initialized
DEBUG - 2022-06-22 11:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:12:52 --> Controller Class Initialized
INFO - 2022-06-22 11:12:52 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:12:52 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:12:52 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:12:52 --> Final output sent to browser
DEBUG - 2022-06-22 11:12:52 --> Total execution time: 0.1222
INFO - 2022-06-22 11:13:00 --> Config Class Initialized
INFO - 2022-06-22 11:13:00 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:13:00 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:13:00 --> Utf8 Class Initialized
INFO - 2022-06-22 11:13:00 --> URI Class Initialized
INFO - 2022-06-22 11:13:00 --> Router Class Initialized
INFO - 2022-06-22 11:13:00 --> Output Class Initialized
INFO - 2022-06-22 11:13:00 --> Security Class Initialized
DEBUG - 2022-06-22 11:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:13:00 --> Input Class Initialized
INFO - 2022-06-22 11:13:00 --> Language Class Initialized
INFO - 2022-06-22 11:13:00 --> Loader Class Initialized
INFO - 2022-06-22 11:13:00 --> Helper loaded: url_helper
INFO - 2022-06-22 11:13:00 --> Helper loaded: file_helper
INFO - 2022-06-22 11:13:00 --> Database Driver Class Initialized
INFO - 2022-06-22 11:13:00 --> Email Class Initialized
DEBUG - 2022-06-22 11:13:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:13:00 --> Controller Class Initialized
INFO - 2022-06-22 11:13:00 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:13:00 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:13:00 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:13:00 --> Final output sent to browser
DEBUG - 2022-06-22 11:13:00 --> Total execution time: 0.0225
INFO - 2022-06-22 11:13:59 --> Config Class Initialized
INFO - 2022-06-22 11:13:59 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:13:59 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:13:59 --> Utf8 Class Initialized
INFO - 2022-06-22 11:13:59 --> URI Class Initialized
INFO - 2022-06-22 11:13:59 --> Router Class Initialized
INFO - 2022-06-22 11:13:59 --> Output Class Initialized
INFO - 2022-06-22 11:13:59 --> Security Class Initialized
DEBUG - 2022-06-22 11:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:13:59 --> Input Class Initialized
INFO - 2022-06-22 11:13:59 --> Language Class Initialized
INFO - 2022-06-22 11:13:59 --> Loader Class Initialized
INFO - 2022-06-22 11:13:59 --> Helper loaded: url_helper
INFO - 2022-06-22 11:13:59 --> Helper loaded: file_helper
INFO - 2022-06-22 11:13:59 --> Database Driver Class Initialized
INFO - 2022-06-22 11:13:59 --> Email Class Initialized
DEBUG - 2022-06-22 11:13:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:13:59 --> Controller Class Initialized
INFO - 2022-06-22 11:13:59 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:13:59 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:13:59 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:13:59 --> Final output sent to browser
DEBUG - 2022-06-22 11:13:59 --> Total execution time: 0.0307
INFO - 2022-06-22 11:14:04 --> Config Class Initialized
INFO - 2022-06-22 11:14:04 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:14:04 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:14:04 --> Utf8 Class Initialized
INFO - 2022-06-22 11:14:04 --> URI Class Initialized
INFO - 2022-06-22 11:14:04 --> Router Class Initialized
INFO - 2022-06-22 11:14:04 --> Output Class Initialized
INFO - 2022-06-22 11:14:04 --> Security Class Initialized
DEBUG - 2022-06-22 11:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:14:04 --> Input Class Initialized
INFO - 2022-06-22 11:14:04 --> Language Class Initialized
INFO - 2022-06-22 11:14:04 --> Loader Class Initialized
INFO - 2022-06-22 11:14:04 --> Helper loaded: url_helper
INFO - 2022-06-22 11:14:04 --> Helper loaded: file_helper
INFO - 2022-06-22 11:14:04 --> Database Driver Class Initialized
INFO - 2022-06-22 11:14:04 --> Email Class Initialized
DEBUG - 2022-06-22 11:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:14:04 --> Controller Class Initialized
INFO - 2022-06-22 11:14:04 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:14:04 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:14:04 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:14:04 --> Final output sent to browser
DEBUG - 2022-06-22 11:14:04 --> Total execution time: 0.0205
INFO - 2022-06-22 11:14:16 --> Config Class Initialized
INFO - 2022-06-22 11:14:16 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:14:16 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:14:16 --> Utf8 Class Initialized
INFO - 2022-06-22 11:14:16 --> URI Class Initialized
INFO - 2022-06-22 11:14:16 --> Router Class Initialized
INFO - 2022-06-22 11:14:16 --> Output Class Initialized
INFO - 2022-06-22 11:14:16 --> Security Class Initialized
DEBUG - 2022-06-22 11:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:14:16 --> Input Class Initialized
INFO - 2022-06-22 11:14:16 --> Language Class Initialized
INFO - 2022-06-22 11:14:16 --> Loader Class Initialized
INFO - 2022-06-22 11:14:16 --> Helper loaded: url_helper
INFO - 2022-06-22 11:14:16 --> Helper loaded: file_helper
INFO - 2022-06-22 11:14:16 --> Database Driver Class Initialized
INFO - 2022-06-22 11:14:16 --> Email Class Initialized
DEBUG - 2022-06-22 11:14:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:14:16 --> Controller Class Initialized
INFO - 2022-06-22 11:14:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:14:16 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:14:16 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:14:16 --> Final output sent to browser
DEBUG - 2022-06-22 11:14:16 --> Total execution time: 0.0194
INFO - 2022-06-22 11:14:24 --> Config Class Initialized
INFO - 2022-06-22 11:14:24 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:14:24 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:14:24 --> Utf8 Class Initialized
INFO - 2022-06-22 11:14:24 --> URI Class Initialized
INFO - 2022-06-22 11:14:24 --> Router Class Initialized
INFO - 2022-06-22 11:14:24 --> Output Class Initialized
INFO - 2022-06-22 11:14:24 --> Security Class Initialized
DEBUG - 2022-06-22 11:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:14:24 --> Input Class Initialized
INFO - 2022-06-22 11:14:24 --> Language Class Initialized
INFO - 2022-06-22 11:14:24 --> Loader Class Initialized
INFO - 2022-06-22 11:14:24 --> Helper loaded: url_helper
INFO - 2022-06-22 11:14:24 --> Helper loaded: file_helper
INFO - 2022-06-22 11:14:24 --> Database Driver Class Initialized
INFO - 2022-06-22 11:14:24 --> Email Class Initialized
DEBUG - 2022-06-22 11:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:14:24 --> Controller Class Initialized
INFO - 2022-06-22 11:14:24 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:14:24 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:14:24 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:14:24 --> Final output sent to browser
DEBUG - 2022-06-22 11:14:24 --> Total execution time: 0.1783
INFO - 2022-06-22 11:14:29 --> Config Class Initialized
INFO - 2022-06-22 11:14:29 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:14:29 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:14:29 --> Utf8 Class Initialized
INFO - 2022-06-22 11:14:29 --> URI Class Initialized
INFO - 2022-06-22 11:14:29 --> Router Class Initialized
INFO - 2022-06-22 11:14:29 --> Output Class Initialized
INFO - 2022-06-22 11:14:29 --> Security Class Initialized
DEBUG - 2022-06-22 11:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:14:29 --> Input Class Initialized
INFO - 2022-06-22 11:14:29 --> Language Class Initialized
INFO - 2022-06-22 11:14:29 --> Loader Class Initialized
INFO - 2022-06-22 11:14:29 --> Helper loaded: url_helper
INFO - 2022-06-22 11:14:29 --> Helper loaded: file_helper
INFO - 2022-06-22 11:14:29 --> Database Driver Class Initialized
INFO - 2022-06-22 11:14:29 --> Email Class Initialized
DEBUG - 2022-06-22 11:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:14:29 --> Controller Class Initialized
INFO - 2022-06-22 11:14:29 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:14:29 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:14:29 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:14:29 --> Final output sent to browser
DEBUG - 2022-06-22 11:14:29 --> Total execution time: 0.0392
INFO - 2022-06-22 11:14:30 --> Config Class Initialized
INFO - 2022-06-22 11:14:30 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:14:30 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:14:30 --> Utf8 Class Initialized
INFO - 2022-06-22 11:14:30 --> URI Class Initialized
INFO - 2022-06-22 11:14:30 --> Router Class Initialized
INFO - 2022-06-22 11:14:30 --> Output Class Initialized
INFO - 2022-06-22 11:14:30 --> Security Class Initialized
DEBUG - 2022-06-22 11:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:14:30 --> Input Class Initialized
INFO - 2022-06-22 11:14:30 --> Language Class Initialized
INFO - 2022-06-22 11:14:30 --> Loader Class Initialized
INFO - 2022-06-22 11:14:30 --> Helper loaded: url_helper
INFO - 2022-06-22 11:14:30 --> Helper loaded: file_helper
INFO - 2022-06-22 11:14:30 --> Database Driver Class Initialized
INFO - 2022-06-22 11:14:30 --> Email Class Initialized
DEBUG - 2022-06-22 11:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:14:30 --> Controller Class Initialized
INFO - 2022-06-22 11:14:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:14:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:14:30 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:14:30 --> Final output sent to browser
DEBUG - 2022-06-22 11:14:30 --> Total execution time: 0.0218
INFO - 2022-06-22 11:14:30 --> Config Class Initialized
INFO - 2022-06-22 11:14:30 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:14:30 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:14:30 --> Utf8 Class Initialized
INFO - 2022-06-22 11:14:30 --> URI Class Initialized
INFO - 2022-06-22 11:14:30 --> Router Class Initialized
INFO - 2022-06-22 11:14:30 --> Output Class Initialized
INFO - 2022-06-22 11:14:30 --> Security Class Initialized
DEBUG - 2022-06-22 11:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:14:30 --> Input Class Initialized
INFO - 2022-06-22 11:14:30 --> Language Class Initialized
INFO - 2022-06-22 11:14:30 --> Loader Class Initialized
INFO - 2022-06-22 11:14:30 --> Helper loaded: url_helper
INFO - 2022-06-22 11:14:30 --> Helper loaded: file_helper
INFO - 2022-06-22 11:14:30 --> Database Driver Class Initialized
INFO - 2022-06-22 11:14:30 --> Email Class Initialized
DEBUG - 2022-06-22 11:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:14:30 --> Controller Class Initialized
INFO - 2022-06-22 11:14:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:14:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:14:30 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:14:30 --> Final output sent to browser
DEBUG - 2022-06-22 11:14:30 --> Total execution time: 0.0150
INFO - 2022-06-22 11:14:30 --> Config Class Initialized
INFO - 2022-06-22 11:14:30 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:14:30 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:14:30 --> Utf8 Class Initialized
INFO - 2022-06-22 11:14:30 --> URI Class Initialized
INFO - 2022-06-22 11:14:30 --> Router Class Initialized
INFO - 2022-06-22 11:14:30 --> Output Class Initialized
INFO - 2022-06-22 11:14:30 --> Security Class Initialized
DEBUG - 2022-06-22 11:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:14:30 --> Input Class Initialized
INFO - 2022-06-22 11:14:30 --> Language Class Initialized
INFO - 2022-06-22 11:14:30 --> Loader Class Initialized
INFO - 2022-06-22 11:14:30 --> Helper loaded: url_helper
INFO - 2022-06-22 11:14:30 --> Helper loaded: file_helper
INFO - 2022-06-22 11:14:30 --> Database Driver Class Initialized
INFO - 2022-06-22 11:14:30 --> Email Class Initialized
DEBUG - 2022-06-22 11:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:14:30 --> Controller Class Initialized
INFO - 2022-06-22 11:14:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:14:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:14:30 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:14:30 --> Final output sent to browser
DEBUG - 2022-06-22 11:14:30 --> Total execution time: 0.0232
INFO - 2022-06-22 11:14:31 --> Config Class Initialized
INFO - 2022-06-22 11:14:31 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:14:31 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:14:31 --> Utf8 Class Initialized
INFO - 2022-06-22 11:14:31 --> URI Class Initialized
INFO - 2022-06-22 11:14:31 --> Router Class Initialized
INFO - 2022-06-22 11:14:31 --> Output Class Initialized
INFO - 2022-06-22 11:14:31 --> Security Class Initialized
DEBUG - 2022-06-22 11:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:14:31 --> Input Class Initialized
INFO - 2022-06-22 11:14:31 --> Language Class Initialized
INFO - 2022-06-22 11:14:31 --> Loader Class Initialized
INFO - 2022-06-22 11:14:31 --> Helper loaded: url_helper
INFO - 2022-06-22 11:14:31 --> Helper loaded: file_helper
INFO - 2022-06-22 11:14:31 --> Database Driver Class Initialized
INFO - 2022-06-22 11:14:31 --> Email Class Initialized
DEBUG - 2022-06-22 11:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:14:31 --> Controller Class Initialized
INFO - 2022-06-22 11:14:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:14:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:14:31 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:14:31 --> Final output sent to browser
DEBUG - 2022-06-22 11:14:31 --> Total execution time: 0.0163
INFO - 2022-06-22 11:14:31 --> Config Class Initialized
INFO - 2022-06-22 11:14:31 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:14:31 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:14:31 --> Utf8 Class Initialized
INFO - 2022-06-22 11:14:31 --> URI Class Initialized
INFO - 2022-06-22 11:14:31 --> Router Class Initialized
INFO - 2022-06-22 11:14:31 --> Output Class Initialized
INFO - 2022-06-22 11:14:31 --> Security Class Initialized
DEBUG - 2022-06-22 11:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:14:31 --> Input Class Initialized
INFO - 2022-06-22 11:14:31 --> Language Class Initialized
INFO - 2022-06-22 11:14:31 --> Loader Class Initialized
INFO - 2022-06-22 11:14:31 --> Helper loaded: url_helper
INFO - 2022-06-22 11:14:31 --> Helper loaded: file_helper
INFO - 2022-06-22 11:14:31 --> Database Driver Class Initialized
INFO - 2022-06-22 11:14:31 --> Email Class Initialized
DEBUG - 2022-06-22 11:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:14:31 --> Controller Class Initialized
INFO - 2022-06-22 11:14:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:14:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:14:31 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:14:31 --> Final output sent to browser
DEBUG - 2022-06-22 11:14:31 --> Total execution time: 0.0853
INFO - 2022-06-22 11:14:31 --> Config Class Initialized
INFO - 2022-06-22 11:14:31 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:14:31 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:14:31 --> Utf8 Class Initialized
INFO - 2022-06-22 11:14:31 --> URI Class Initialized
INFO - 2022-06-22 11:14:31 --> Router Class Initialized
INFO - 2022-06-22 11:14:31 --> Output Class Initialized
INFO - 2022-06-22 11:14:31 --> Security Class Initialized
DEBUG - 2022-06-22 11:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:14:31 --> Input Class Initialized
INFO - 2022-06-22 11:14:31 --> Language Class Initialized
INFO - 2022-06-22 11:14:31 --> Loader Class Initialized
INFO - 2022-06-22 11:14:31 --> Helper loaded: url_helper
INFO - 2022-06-22 11:14:31 --> Helper loaded: file_helper
INFO - 2022-06-22 11:14:31 --> Database Driver Class Initialized
INFO - 2022-06-22 11:14:31 --> Email Class Initialized
DEBUG - 2022-06-22 11:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:14:31 --> Controller Class Initialized
INFO - 2022-06-22 11:14:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:14:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:14:31 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:14:31 --> Final output sent to browser
DEBUG - 2022-06-22 11:14:31 --> Total execution time: 0.0178
INFO - 2022-06-22 11:14:55 --> Config Class Initialized
INFO - 2022-06-22 11:14:55 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:14:55 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:14:55 --> Utf8 Class Initialized
INFO - 2022-06-22 11:14:55 --> URI Class Initialized
INFO - 2022-06-22 11:14:55 --> Router Class Initialized
INFO - 2022-06-22 11:14:55 --> Output Class Initialized
INFO - 2022-06-22 11:14:55 --> Security Class Initialized
DEBUG - 2022-06-22 11:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:14:55 --> Input Class Initialized
INFO - 2022-06-22 11:14:55 --> Language Class Initialized
INFO - 2022-06-22 11:14:55 --> Loader Class Initialized
INFO - 2022-06-22 11:14:55 --> Helper loaded: url_helper
INFO - 2022-06-22 11:14:55 --> Helper loaded: file_helper
INFO - 2022-06-22 11:14:55 --> Database Driver Class Initialized
INFO - 2022-06-22 11:14:55 --> Email Class Initialized
DEBUG - 2022-06-22 11:14:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:14:55 --> Controller Class Initialized
INFO - 2022-06-22 11:14:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:14:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:14:55 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:14:55 --> Final output sent to browser
DEBUG - 2022-06-22 11:14:55 --> Total execution time: 0.0438
INFO - 2022-06-22 11:15:02 --> Config Class Initialized
INFO - 2022-06-22 11:15:02 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:15:02 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:15:02 --> Utf8 Class Initialized
INFO - 2022-06-22 11:15:02 --> URI Class Initialized
INFO - 2022-06-22 11:15:02 --> Router Class Initialized
INFO - 2022-06-22 11:15:02 --> Output Class Initialized
INFO - 2022-06-22 11:15:02 --> Security Class Initialized
DEBUG - 2022-06-22 11:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:15:02 --> Input Class Initialized
INFO - 2022-06-22 11:15:02 --> Language Class Initialized
INFO - 2022-06-22 11:15:02 --> Loader Class Initialized
INFO - 2022-06-22 11:15:02 --> Helper loaded: url_helper
INFO - 2022-06-22 11:15:02 --> Helper loaded: file_helper
INFO - 2022-06-22 11:15:02 --> Database Driver Class Initialized
INFO - 2022-06-22 11:15:02 --> Email Class Initialized
DEBUG - 2022-06-22 11:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:15:02 --> Controller Class Initialized
INFO - 2022-06-22 11:15:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:15:02 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:15:02 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:15:02 --> Final output sent to browser
DEBUG - 2022-06-22 11:15:02 --> Total execution time: 0.1647
INFO - 2022-06-22 11:24:57 --> Config Class Initialized
INFO - 2022-06-22 11:24:57 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:24:57 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:24:57 --> Utf8 Class Initialized
INFO - 2022-06-22 11:24:57 --> URI Class Initialized
INFO - 2022-06-22 11:24:57 --> Router Class Initialized
INFO - 2022-06-22 11:24:57 --> Output Class Initialized
INFO - 2022-06-22 11:24:57 --> Security Class Initialized
DEBUG - 2022-06-22 11:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:24:57 --> Input Class Initialized
INFO - 2022-06-22 11:24:57 --> Language Class Initialized
INFO - 2022-06-22 11:24:57 --> Loader Class Initialized
INFO - 2022-06-22 11:24:57 --> Helper loaded: url_helper
INFO - 2022-06-22 11:24:57 --> Helper loaded: file_helper
INFO - 2022-06-22 11:24:57 --> Database Driver Class Initialized
INFO - 2022-06-22 11:24:57 --> Email Class Initialized
DEBUG - 2022-06-22 11:24:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:24:57 --> Controller Class Initialized
INFO - 2022-06-22 11:24:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:24:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:24:57 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:24:57 --> Final output sent to browser
DEBUG - 2022-06-22 11:24:57 --> Total execution time: 0.1263
INFO - 2022-06-22 11:25:02 --> Config Class Initialized
INFO - 2022-06-22 11:25:02 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:25:02 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:25:02 --> Utf8 Class Initialized
INFO - 2022-06-22 11:25:02 --> URI Class Initialized
INFO - 2022-06-22 11:25:02 --> Router Class Initialized
INFO - 2022-06-22 11:25:02 --> Output Class Initialized
INFO - 2022-06-22 11:25:02 --> Security Class Initialized
DEBUG - 2022-06-22 11:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:25:02 --> Input Class Initialized
INFO - 2022-06-22 11:25:02 --> Language Class Initialized
INFO - 2022-06-22 11:25:02 --> Loader Class Initialized
INFO - 2022-06-22 11:25:02 --> Helper loaded: url_helper
INFO - 2022-06-22 11:25:02 --> Helper loaded: file_helper
INFO - 2022-06-22 11:25:02 --> Database Driver Class Initialized
INFO - 2022-06-22 11:25:02 --> Email Class Initialized
DEBUG - 2022-06-22 11:25:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:25:02 --> Controller Class Initialized
INFO - 2022-06-22 11:25:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:25:02 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:25:02 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:25:02 --> Final output sent to browser
DEBUG - 2022-06-22 11:25:02 --> Total execution time: 0.0308
INFO - 2022-06-22 11:25:07 --> Config Class Initialized
INFO - 2022-06-22 11:25:07 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:25:07 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:25:07 --> Utf8 Class Initialized
INFO - 2022-06-22 11:25:07 --> URI Class Initialized
INFO - 2022-06-22 11:25:07 --> Router Class Initialized
INFO - 2022-06-22 11:25:07 --> Output Class Initialized
INFO - 2022-06-22 11:25:07 --> Security Class Initialized
DEBUG - 2022-06-22 11:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:25:07 --> Input Class Initialized
INFO - 2022-06-22 11:25:07 --> Language Class Initialized
INFO - 2022-06-22 11:25:07 --> Loader Class Initialized
INFO - 2022-06-22 11:25:07 --> Helper loaded: url_helper
INFO - 2022-06-22 11:25:07 --> Helper loaded: file_helper
INFO - 2022-06-22 11:25:07 --> Database Driver Class Initialized
INFO - 2022-06-22 11:25:07 --> Email Class Initialized
DEBUG - 2022-06-22 11:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:25:07 --> Controller Class Initialized
INFO - 2022-06-22 11:25:07 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:25:07 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:25:07 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:25:07 --> Final output sent to browser
DEBUG - 2022-06-22 11:25:07 --> Total execution time: 0.1272
INFO - 2022-06-22 11:25:33 --> Config Class Initialized
INFO - 2022-06-22 11:25:33 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:25:33 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:25:33 --> Utf8 Class Initialized
INFO - 2022-06-22 11:25:33 --> URI Class Initialized
INFO - 2022-06-22 11:25:33 --> Router Class Initialized
INFO - 2022-06-22 11:25:33 --> Output Class Initialized
INFO - 2022-06-22 11:25:33 --> Security Class Initialized
DEBUG - 2022-06-22 11:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:25:33 --> Input Class Initialized
INFO - 2022-06-22 11:25:33 --> Language Class Initialized
INFO - 2022-06-22 11:25:33 --> Loader Class Initialized
INFO - 2022-06-22 11:25:33 --> Helper loaded: url_helper
INFO - 2022-06-22 11:25:33 --> Helper loaded: file_helper
INFO - 2022-06-22 11:25:33 --> Database Driver Class Initialized
INFO - 2022-06-22 11:25:33 --> Email Class Initialized
DEBUG - 2022-06-22 11:25:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:25:33 --> Controller Class Initialized
INFO - 2022-06-22 11:25:33 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:25:33 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:25:33 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:25:33 --> Final output sent to browser
DEBUG - 2022-06-22 11:25:33 --> Total execution time: 0.0379
INFO - 2022-06-22 11:25:36 --> Config Class Initialized
INFO - 2022-06-22 11:25:36 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:25:36 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:25:36 --> Utf8 Class Initialized
INFO - 2022-06-22 11:25:36 --> URI Class Initialized
INFO - 2022-06-22 11:25:36 --> Router Class Initialized
INFO - 2022-06-22 11:25:36 --> Output Class Initialized
INFO - 2022-06-22 11:25:36 --> Security Class Initialized
DEBUG - 2022-06-22 11:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:25:36 --> Input Class Initialized
INFO - 2022-06-22 11:25:36 --> Language Class Initialized
INFO - 2022-06-22 11:25:36 --> Loader Class Initialized
INFO - 2022-06-22 11:25:36 --> Helper loaded: url_helper
INFO - 2022-06-22 11:25:36 --> Helper loaded: file_helper
INFO - 2022-06-22 11:25:36 --> Database Driver Class Initialized
INFO - 2022-06-22 11:25:36 --> Email Class Initialized
DEBUG - 2022-06-22 11:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:25:36 --> Controller Class Initialized
INFO - 2022-06-22 11:25:36 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:25:36 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:25:36 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:25:36 --> Final output sent to browser
DEBUG - 2022-06-22 11:25:36 --> Total execution time: 0.1254
INFO - 2022-06-22 11:25:44 --> Config Class Initialized
INFO - 2022-06-22 11:25:44 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:25:44 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:25:44 --> Utf8 Class Initialized
INFO - 2022-06-22 11:25:44 --> URI Class Initialized
INFO - 2022-06-22 11:25:44 --> Router Class Initialized
INFO - 2022-06-22 11:25:44 --> Output Class Initialized
INFO - 2022-06-22 11:25:44 --> Security Class Initialized
DEBUG - 2022-06-22 11:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:25:44 --> Input Class Initialized
INFO - 2022-06-22 11:25:44 --> Language Class Initialized
INFO - 2022-06-22 11:25:44 --> Loader Class Initialized
INFO - 2022-06-22 11:25:44 --> Helper loaded: url_helper
INFO - 2022-06-22 11:25:44 --> Helper loaded: file_helper
INFO - 2022-06-22 11:25:44 --> Database Driver Class Initialized
INFO - 2022-06-22 11:25:45 --> Email Class Initialized
DEBUG - 2022-06-22 11:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:25:45 --> Controller Class Initialized
INFO - 2022-06-22 11:25:45 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:25:45 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:25:45 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:25:45 --> Final output sent to browser
DEBUG - 2022-06-22 11:25:45 --> Total execution time: 0.6699
INFO - 2022-06-22 11:28:17 --> Config Class Initialized
INFO - 2022-06-22 11:28:17 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:28:17 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:28:17 --> Utf8 Class Initialized
INFO - 2022-06-22 11:28:17 --> URI Class Initialized
INFO - 2022-06-22 11:28:17 --> Router Class Initialized
INFO - 2022-06-22 11:28:17 --> Output Class Initialized
INFO - 2022-06-22 11:28:17 --> Security Class Initialized
DEBUG - 2022-06-22 11:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:28:17 --> Input Class Initialized
INFO - 2022-06-22 11:28:17 --> Language Class Initialized
INFO - 2022-06-22 11:28:17 --> Loader Class Initialized
INFO - 2022-06-22 11:28:17 --> Helper loaded: url_helper
INFO - 2022-06-22 11:28:17 --> Helper loaded: file_helper
INFO - 2022-06-22 11:28:17 --> Database Driver Class Initialized
INFO - 2022-06-22 11:28:17 --> Email Class Initialized
DEBUG - 2022-06-22 11:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:28:17 --> Controller Class Initialized
INFO - 2022-06-22 11:28:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:28:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:28:17 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:28:17 --> Final output sent to browser
DEBUG - 2022-06-22 11:28:17 --> Total execution time: 0.0532
INFO - 2022-06-22 11:28:18 --> Config Class Initialized
INFO - 2022-06-22 11:28:18 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:28:18 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:28:18 --> Utf8 Class Initialized
INFO - 2022-06-22 11:28:18 --> URI Class Initialized
INFO - 2022-06-22 11:28:18 --> Router Class Initialized
INFO - 2022-06-22 11:28:18 --> Output Class Initialized
INFO - 2022-06-22 11:28:18 --> Security Class Initialized
DEBUG - 2022-06-22 11:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:28:18 --> Input Class Initialized
INFO - 2022-06-22 11:28:18 --> Language Class Initialized
INFO - 2022-06-22 11:28:18 --> Loader Class Initialized
INFO - 2022-06-22 11:28:18 --> Helper loaded: url_helper
INFO - 2022-06-22 11:28:18 --> Helper loaded: file_helper
INFO - 2022-06-22 11:28:18 --> Database Driver Class Initialized
INFO - 2022-06-22 11:28:18 --> Email Class Initialized
DEBUG - 2022-06-22 11:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:28:18 --> Controller Class Initialized
INFO - 2022-06-22 11:28:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:28:18 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:28:18 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:28:18 --> Final output sent to browser
DEBUG - 2022-06-22 11:28:18 --> Total execution time: 0.1191
INFO - 2022-06-22 11:28:25 --> Config Class Initialized
INFO - 2022-06-22 11:28:25 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:28:25 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:28:25 --> Utf8 Class Initialized
INFO - 2022-06-22 11:28:25 --> URI Class Initialized
INFO - 2022-06-22 11:28:25 --> Router Class Initialized
INFO - 2022-06-22 11:28:25 --> Output Class Initialized
INFO - 2022-06-22 11:28:25 --> Security Class Initialized
DEBUG - 2022-06-22 11:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:28:25 --> Input Class Initialized
INFO - 2022-06-22 11:28:25 --> Language Class Initialized
INFO - 2022-06-22 11:28:25 --> Loader Class Initialized
INFO - 2022-06-22 11:28:25 --> Helper loaded: url_helper
INFO - 2022-06-22 11:28:25 --> Helper loaded: file_helper
INFO - 2022-06-22 11:28:25 --> Database Driver Class Initialized
INFO - 2022-06-22 11:28:25 --> Email Class Initialized
DEBUG - 2022-06-22 11:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:28:25 --> Controller Class Initialized
INFO - 2022-06-22 11:28:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:28:25 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:28:25 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:28:25 --> Final output sent to browser
DEBUG - 2022-06-22 11:28:25 --> Total execution time: 0.0221
INFO - 2022-06-22 11:28:31 --> Config Class Initialized
INFO - 2022-06-22 11:28:31 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:28:31 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:28:31 --> Utf8 Class Initialized
INFO - 2022-06-22 11:28:31 --> URI Class Initialized
INFO - 2022-06-22 11:28:31 --> Router Class Initialized
INFO - 2022-06-22 11:28:31 --> Output Class Initialized
INFO - 2022-06-22 11:28:31 --> Security Class Initialized
DEBUG - 2022-06-22 11:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:28:31 --> Input Class Initialized
INFO - 2022-06-22 11:28:31 --> Language Class Initialized
INFO - 2022-06-22 11:28:31 --> Loader Class Initialized
INFO - 2022-06-22 11:28:31 --> Helper loaded: url_helper
INFO - 2022-06-22 11:28:31 --> Helper loaded: file_helper
INFO - 2022-06-22 11:28:31 --> Database Driver Class Initialized
INFO - 2022-06-22 11:28:31 --> Email Class Initialized
DEBUG - 2022-06-22 11:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:28:31 --> Controller Class Initialized
INFO - 2022-06-22 11:28:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:28:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:28:31 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:28:31 --> Final output sent to browser
DEBUG - 2022-06-22 11:28:31 --> Total execution time: 0.1275
INFO - 2022-06-22 11:28:39 --> Config Class Initialized
INFO - 2022-06-22 11:28:39 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:28:39 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:28:39 --> Utf8 Class Initialized
INFO - 2022-06-22 11:28:39 --> URI Class Initialized
INFO - 2022-06-22 11:28:39 --> Router Class Initialized
INFO - 2022-06-22 11:28:39 --> Output Class Initialized
INFO - 2022-06-22 11:28:39 --> Security Class Initialized
DEBUG - 2022-06-22 11:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:28:39 --> Input Class Initialized
INFO - 2022-06-22 11:28:39 --> Language Class Initialized
INFO - 2022-06-22 11:28:39 --> Loader Class Initialized
INFO - 2022-06-22 11:28:39 --> Helper loaded: url_helper
INFO - 2022-06-22 11:28:39 --> Helper loaded: file_helper
INFO - 2022-06-22 11:28:39 --> Database Driver Class Initialized
INFO - 2022-06-22 11:28:39 --> Email Class Initialized
DEBUG - 2022-06-22 11:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:28:39 --> Controller Class Initialized
INFO - 2022-06-22 11:28:39 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:28:39 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:28:39 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:28:39 --> Final output sent to browser
DEBUG - 2022-06-22 11:28:39 --> Total execution time: 0.0176
INFO - 2022-06-22 11:29:20 --> Config Class Initialized
INFO - 2022-06-22 11:29:20 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:29:20 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:29:20 --> Utf8 Class Initialized
INFO - 2022-06-22 11:29:20 --> URI Class Initialized
INFO - 2022-06-22 11:29:20 --> Router Class Initialized
INFO - 2022-06-22 11:29:20 --> Output Class Initialized
INFO - 2022-06-22 11:29:20 --> Security Class Initialized
DEBUG - 2022-06-22 11:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:29:20 --> Input Class Initialized
INFO - 2022-06-22 11:29:20 --> Language Class Initialized
INFO - 2022-06-22 11:29:20 --> Loader Class Initialized
INFO - 2022-06-22 11:29:20 --> Helper loaded: url_helper
INFO - 2022-06-22 11:29:20 --> Helper loaded: file_helper
INFO - 2022-06-22 11:29:20 --> Database Driver Class Initialized
INFO - 2022-06-22 11:29:21 --> Email Class Initialized
DEBUG - 2022-06-22 11:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:29:21 --> Controller Class Initialized
INFO - 2022-06-22 11:29:21 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:29:21 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:29:21 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:29:21 --> Final output sent to browser
DEBUG - 2022-06-22 11:29:21 --> Total execution time: 1.3010
INFO - 2022-06-22 11:29:21 --> Config Class Initialized
INFO - 2022-06-22 11:29:21 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:29:21 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:29:21 --> Utf8 Class Initialized
INFO - 2022-06-22 11:29:21 --> URI Class Initialized
INFO - 2022-06-22 11:29:21 --> Router Class Initialized
INFO - 2022-06-22 11:29:21 --> Output Class Initialized
INFO - 2022-06-22 11:29:21 --> Security Class Initialized
DEBUG - 2022-06-22 11:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:29:21 --> Input Class Initialized
INFO - 2022-06-22 11:29:21 --> Language Class Initialized
INFO - 2022-06-22 11:29:21 --> Loader Class Initialized
INFO - 2022-06-22 11:29:21 --> Helper loaded: url_helper
INFO - 2022-06-22 11:29:21 --> Helper loaded: file_helper
INFO - 2022-06-22 11:29:21 --> Database Driver Class Initialized
INFO - 2022-06-22 11:29:21 --> Config Class Initialized
INFO - 2022-06-22 11:29:21 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:29:21 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:29:21 --> Utf8 Class Initialized
INFO - 2022-06-22 11:29:21 --> URI Class Initialized
INFO - 2022-06-22 11:29:21 --> Config Class Initialized
INFO - 2022-06-22 11:29:21 --> Hooks Class Initialized
INFO - 2022-06-22 11:29:21 --> Router Class Initialized
INFO - 2022-06-22 11:29:21 --> Output Class Initialized
DEBUG - 2022-06-22 11:29:21 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:29:21 --> Email Class Initialized
INFO - 2022-06-22 11:29:21 --> Utf8 Class Initialized
INFO - 2022-06-22 11:29:21 --> Security Class Initialized
INFO - 2022-06-22 11:29:21 --> URI Class Initialized
DEBUG - 2022-06-22 11:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-22 11:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:29:21 --> Input Class Initialized
INFO - 2022-06-22 11:29:21 --> Language Class Initialized
INFO - 2022-06-22 11:29:21 --> Router Class Initialized
INFO - 2022-06-22 11:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:29:21 --> Controller Class Initialized
INFO - 2022-06-22 11:29:21 --> Loader Class Initialized
INFO - 2022-06-22 11:29:21 --> Output Class Initialized
INFO - 2022-06-22 11:29:21 --> Model "Tokenmodel" initialized
INFO - 2022-06-22 11:29:21 --> Security Class Initialized
INFO - 2022-06-22 11:29:21 --> Helper loaded: url_helper
DEBUG - 2022-06-22 11:29:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-22 11:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:29:21 --> Helper loaded: file_helper
INFO - 2022-06-22 11:29:21 --> Input Class Initialized
INFO - 2022-06-22 11:29:21 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:29:21 --> Language Class Initialized
INFO - 2022-06-22 11:29:21 --> Final output sent to browser
INFO - 2022-06-22 11:29:21 --> Database Driver Class Initialized
DEBUG - 2022-06-22 11:29:21 --> Total execution time: 0.1330
INFO - 2022-06-22 11:29:21 --> Loader Class Initialized
INFO - 2022-06-22 11:29:21 --> Helper loaded: url_helper
INFO - 2022-06-22 11:29:21 --> Helper loaded: file_helper
INFO - 2022-06-22 11:29:21 --> Database Driver Class Initialized
INFO - 2022-06-22 11:29:21 --> Email Class Initialized
DEBUG - 2022-06-22 11:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:29:21 --> Controller Class Initialized
INFO - 2022-06-22 11:29:21 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:29:21 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:29:21 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:29:21 --> Final output sent to browser
DEBUG - 2022-06-22 11:29:21 --> Total execution time: 0.1100
INFO - 2022-06-22 11:29:21 --> Email Class Initialized
DEBUG - 2022-06-22 11:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:29:21 --> Controller Class Initialized
INFO - 2022-06-22 11:29:21 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:29:21 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:29:21 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:29:21 --> Final output sent to browser
DEBUG - 2022-06-22 11:29:21 --> Total execution time: 0.1091
INFO - 2022-06-22 11:29:21 --> Config Class Initialized
INFO - 2022-06-22 11:29:21 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:29:21 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:29:21 --> Utf8 Class Initialized
INFO - 2022-06-22 11:29:21 --> URI Class Initialized
INFO - 2022-06-22 11:29:21 --> Router Class Initialized
INFO - 2022-06-22 11:29:21 --> Output Class Initialized
INFO - 2022-06-22 11:29:21 --> Security Class Initialized
DEBUG - 2022-06-22 11:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:29:21 --> Input Class Initialized
INFO - 2022-06-22 11:29:21 --> Language Class Initialized
INFO - 2022-06-22 11:29:21 --> Loader Class Initialized
INFO - 2022-06-22 11:29:21 --> Helper loaded: url_helper
INFO - 2022-06-22 11:29:21 --> Helper loaded: file_helper
INFO - 2022-06-22 11:29:22 --> Database Driver Class Initialized
INFO - 2022-06-22 11:29:22 --> Email Class Initialized
DEBUG - 2022-06-22 11:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:29:22 --> Controller Class Initialized
INFO - 2022-06-22 11:29:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:29:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:29:22 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:29:22 --> Final output sent to browser
DEBUG - 2022-06-22 11:29:22 --> Total execution time: 0.0663
INFO - 2022-06-22 11:29:27 --> Config Class Initialized
INFO - 2022-06-22 11:29:27 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:29:27 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:29:27 --> Utf8 Class Initialized
INFO - 2022-06-22 11:29:27 --> URI Class Initialized
INFO - 2022-06-22 11:29:27 --> Router Class Initialized
INFO - 2022-06-22 11:29:27 --> Output Class Initialized
INFO - 2022-06-22 11:29:27 --> Security Class Initialized
DEBUG - 2022-06-22 11:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:29:27 --> Input Class Initialized
INFO - 2022-06-22 11:29:27 --> Language Class Initialized
INFO - 2022-06-22 11:29:27 --> Loader Class Initialized
INFO - 2022-06-22 11:29:27 --> Helper loaded: url_helper
INFO - 2022-06-22 11:29:27 --> Helper loaded: file_helper
INFO - 2022-06-22 11:29:27 --> Database Driver Class Initialized
INFO - 2022-06-22 11:29:27 --> Email Class Initialized
DEBUG - 2022-06-22 11:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:29:27 --> Controller Class Initialized
INFO - 2022-06-22 11:29:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:29:27 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:29:27 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:29:27 --> Final output sent to browser
DEBUG - 2022-06-22 11:29:27 --> Total execution time: 0.0560
INFO - 2022-06-22 11:29:33 --> Config Class Initialized
INFO - 2022-06-22 11:29:33 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:29:33 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:29:33 --> Utf8 Class Initialized
INFO - 2022-06-22 11:29:33 --> URI Class Initialized
INFO - 2022-06-22 11:29:33 --> Router Class Initialized
INFO - 2022-06-22 11:29:33 --> Output Class Initialized
INFO - 2022-06-22 11:29:33 --> Security Class Initialized
DEBUG - 2022-06-22 11:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:29:33 --> Input Class Initialized
INFO - 2022-06-22 11:29:33 --> Language Class Initialized
INFO - 2022-06-22 11:29:33 --> Loader Class Initialized
INFO - 2022-06-22 11:29:33 --> Helper loaded: url_helper
INFO - 2022-06-22 11:29:33 --> Helper loaded: file_helper
INFO - 2022-06-22 11:29:33 --> Database Driver Class Initialized
INFO - 2022-06-22 11:29:33 --> Email Class Initialized
DEBUG - 2022-06-22 11:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:29:33 --> Controller Class Initialized
INFO - 2022-06-22 11:29:33 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:29:33 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:29:33 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:29:33 --> Final output sent to browser
DEBUG - 2022-06-22 11:29:33 --> Total execution time: 0.0343
INFO - 2022-06-22 11:29:40 --> Config Class Initialized
INFO - 2022-06-22 11:29:40 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:29:40 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:29:40 --> Utf8 Class Initialized
INFO - 2022-06-22 11:29:40 --> URI Class Initialized
INFO - 2022-06-22 11:29:40 --> Router Class Initialized
INFO - 2022-06-22 11:29:40 --> Output Class Initialized
INFO - 2022-06-22 11:29:40 --> Security Class Initialized
DEBUG - 2022-06-22 11:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:29:40 --> Input Class Initialized
INFO - 2022-06-22 11:29:40 --> Language Class Initialized
INFO - 2022-06-22 11:29:40 --> Loader Class Initialized
INFO - 2022-06-22 11:29:40 --> Helper loaded: url_helper
INFO - 2022-06-22 11:29:40 --> Helper loaded: file_helper
INFO - 2022-06-22 11:29:40 --> Database Driver Class Initialized
INFO - 2022-06-22 11:29:40 --> Email Class Initialized
DEBUG - 2022-06-22 11:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:29:40 --> Controller Class Initialized
INFO - 2022-06-22 11:29:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:29:40 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:29:40 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:29:40 --> Final output sent to browser
DEBUG - 2022-06-22 11:29:40 --> Total execution time: 0.0189
INFO - 2022-06-22 11:29:47 --> Config Class Initialized
INFO - 2022-06-22 11:29:47 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:29:47 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:29:47 --> Utf8 Class Initialized
INFO - 2022-06-22 11:29:47 --> URI Class Initialized
INFO - 2022-06-22 11:29:47 --> Router Class Initialized
INFO - 2022-06-22 11:29:47 --> Output Class Initialized
INFO - 2022-06-22 11:29:47 --> Security Class Initialized
DEBUG - 2022-06-22 11:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:29:47 --> Input Class Initialized
INFO - 2022-06-22 11:29:47 --> Language Class Initialized
INFO - 2022-06-22 11:29:47 --> Loader Class Initialized
INFO - 2022-06-22 11:29:47 --> Helper loaded: url_helper
INFO - 2022-06-22 11:29:47 --> Helper loaded: file_helper
INFO - 2022-06-22 11:29:47 --> Database Driver Class Initialized
INFO - 2022-06-22 11:29:47 --> Email Class Initialized
DEBUG - 2022-06-22 11:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:29:47 --> Controller Class Initialized
INFO - 2022-06-22 11:29:47 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:29:47 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:29:47 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:29:47 --> Final output sent to browser
DEBUG - 2022-06-22 11:29:47 --> Total execution time: 0.0318
INFO - 2022-06-22 11:30:30 --> Config Class Initialized
INFO - 2022-06-22 11:30:30 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:30:30 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:30:30 --> Utf8 Class Initialized
INFO - 2022-06-22 11:30:30 --> URI Class Initialized
INFO - 2022-06-22 11:30:30 --> Router Class Initialized
INFO - 2022-06-22 11:30:30 --> Output Class Initialized
INFO - 2022-06-22 11:30:30 --> Security Class Initialized
DEBUG - 2022-06-22 11:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:30:30 --> Input Class Initialized
INFO - 2022-06-22 11:30:30 --> Language Class Initialized
INFO - 2022-06-22 11:30:30 --> Loader Class Initialized
INFO - 2022-06-22 11:30:30 --> Helper loaded: url_helper
INFO - 2022-06-22 11:30:30 --> Helper loaded: file_helper
INFO - 2022-06-22 11:30:30 --> Database Driver Class Initialized
INFO - 2022-06-22 11:30:30 --> Email Class Initialized
DEBUG - 2022-06-22 11:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:30:30 --> Controller Class Initialized
INFO - 2022-06-22 11:30:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:30:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:30:30 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:30:30 --> Final output sent to browser
DEBUG - 2022-06-22 11:30:30 --> Total execution time: 0.1454
INFO - 2022-06-22 11:30:36 --> Config Class Initialized
INFO - 2022-06-22 11:30:36 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:30:36 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:30:36 --> Utf8 Class Initialized
INFO - 2022-06-22 11:30:36 --> URI Class Initialized
INFO - 2022-06-22 11:30:36 --> Router Class Initialized
INFO - 2022-06-22 11:30:36 --> Output Class Initialized
INFO - 2022-06-22 11:30:36 --> Security Class Initialized
DEBUG - 2022-06-22 11:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:30:36 --> Input Class Initialized
INFO - 2022-06-22 11:30:36 --> Language Class Initialized
INFO - 2022-06-22 11:30:36 --> Loader Class Initialized
INFO - 2022-06-22 11:30:36 --> Helper loaded: url_helper
INFO - 2022-06-22 11:30:36 --> Helper loaded: file_helper
INFO - 2022-06-22 11:30:36 --> Database Driver Class Initialized
INFO - 2022-06-22 11:30:36 --> Email Class Initialized
DEBUG - 2022-06-22 11:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:30:36 --> Controller Class Initialized
INFO - 2022-06-22 11:30:36 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:30:36 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:30:36 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:30:36 --> Final output sent to browser
DEBUG - 2022-06-22 11:30:36 --> Total execution time: 0.0182
INFO - 2022-06-22 11:30:39 --> Config Class Initialized
INFO - 2022-06-22 11:30:39 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:30:39 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:30:39 --> Utf8 Class Initialized
INFO - 2022-06-22 11:30:39 --> URI Class Initialized
INFO - 2022-06-22 11:30:39 --> Router Class Initialized
INFO - 2022-06-22 11:30:39 --> Output Class Initialized
INFO - 2022-06-22 11:30:39 --> Security Class Initialized
DEBUG - 2022-06-22 11:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:30:39 --> Input Class Initialized
INFO - 2022-06-22 11:30:39 --> Language Class Initialized
INFO - 2022-06-22 11:30:39 --> Loader Class Initialized
INFO - 2022-06-22 11:30:39 --> Helper loaded: url_helper
INFO - 2022-06-22 11:30:39 --> Helper loaded: file_helper
INFO - 2022-06-22 11:30:39 --> Database Driver Class Initialized
INFO - 2022-06-22 11:30:39 --> Email Class Initialized
DEBUG - 2022-06-22 11:30:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:30:39 --> Controller Class Initialized
INFO - 2022-06-22 11:30:39 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:30:39 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:30:39 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:30:39 --> Final output sent to browser
DEBUG - 2022-06-22 11:30:39 --> Total execution time: 0.0347
INFO - 2022-06-22 11:30:40 --> Config Class Initialized
INFO - 2022-06-22 11:30:40 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:30:40 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:30:40 --> Utf8 Class Initialized
INFO - 2022-06-22 11:30:40 --> URI Class Initialized
INFO - 2022-06-22 11:30:40 --> Router Class Initialized
INFO - 2022-06-22 11:30:40 --> Output Class Initialized
INFO - 2022-06-22 11:30:40 --> Security Class Initialized
DEBUG - 2022-06-22 11:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:30:40 --> Input Class Initialized
INFO - 2022-06-22 11:30:40 --> Language Class Initialized
INFO - 2022-06-22 11:30:40 --> Loader Class Initialized
INFO - 2022-06-22 11:30:40 --> Helper loaded: url_helper
INFO - 2022-06-22 11:30:40 --> Helper loaded: file_helper
INFO - 2022-06-22 11:30:40 --> Database Driver Class Initialized
INFO - 2022-06-22 11:30:40 --> Email Class Initialized
DEBUG - 2022-06-22 11:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:30:40 --> Controller Class Initialized
INFO - 2022-06-22 11:30:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:30:40 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:30:40 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:30:40 --> Final output sent to browser
DEBUG - 2022-06-22 11:30:40 --> Total execution time: 0.1451
INFO - 2022-06-22 11:30:40 --> Config Class Initialized
INFO - 2022-06-22 11:30:40 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:30:40 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:30:40 --> Utf8 Class Initialized
INFO - 2022-06-22 11:30:40 --> URI Class Initialized
INFO - 2022-06-22 11:30:40 --> Router Class Initialized
INFO - 2022-06-22 11:30:40 --> Output Class Initialized
INFO - 2022-06-22 11:30:40 --> Security Class Initialized
DEBUG - 2022-06-22 11:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:30:40 --> Input Class Initialized
INFO - 2022-06-22 11:30:40 --> Language Class Initialized
INFO - 2022-06-22 11:30:40 --> Loader Class Initialized
INFO - 2022-06-22 11:30:40 --> Helper loaded: url_helper
INFO - 2022-06-22 11:30:40 --> Helper loaded: file_helper
INFO - 2022-06-22 11:30:40 --> Database Driver Class Initialized
INFO - 2022-06-22 11:30:40 --> Email Class Initialized
DEBUG - 2022-06-22 11:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:30:40 --> Controller Class Initialized
INFO - 2022-06-22 11:30:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:30:40 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:30:40 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:30:40 --> Final output sent to browser
DEBUG - 2022-06-22 11:30:40 --> Total execution time: 0.0743
INFO - 2022-06-22 11:30:40 --> Config Class Initialized
INFO - 2022-06-22 11:30:40 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:30:40 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:30:40 --> Utf8 Class Initialized
INFO - 2022-06-22 11:30:40 --> URI Class Initialized
INFO - 2022-06-22 11:30:40 --> Router Class Initialized
INFO - 2022-06-22 11:30:40 --> Output Class Initialized
INFO - 2022-06-22 11:30:40 --> Security Class Initialized
DEBUG - 2022-06-22 11:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:30:40 --> Input Class Initialized
INFO - 2022-06-22 11:30:40 --> Language Class Initialized
INFO - 2022-06-22 11:30:40 --> Loader Class Initialized
INFO - 2022-06-22 11:30:40 --> Helper loaded: url_helper
INFO - 2022-06-22 11:30:40 --> Helper loaded: file_helper
INFO - 2022-06-22 11:30:40 --> Database Driver Class Initialized
INFO - 2022-06-22 11:30:40 --> Email Class Initialized
DEBUG - 2022-06-22 11:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:30:40 --> Controller Class Initialized
INFO - 2022-06-22 11:30:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:30:40 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:30:40 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:30:40 --> Final output sent to browser
DEBUG - 2022-06-22 11:30:40 --> Total execution time: 0.0182
INFO - 2022-06-22 11:30:40 --> Config Class Initialized
INFO - 2022-06-22 11:30:40 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:30:40 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:30:40 --> Utf8 Class Initialized
INFO - 2022-06-22 11:30:40 --> URI Class Initialized
INFO - 2022-06-22 11:30:40 --> Router Class Initialized
INFO - 2022-06-22 11:30:40 --> Output Class Initialized
INFO - 2022-06-22 11:30:40 --> Security Class Initialized
DEBUG - 2022-06-22 11:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:30:40 --> Input Class Initialized
INFO - 2022-06-22 11:30:40 --> Language Class Initialized
INFO - 2022-06-22 11:30:40 --> Loader Class Initialized
INFO - 2022-06-22 11:30:40 --> Helper loaded: url_helper
INFO - 2022-06-22 11:30:40 --> Helper loaded: file_helper
INFO - 2022-06-22 11:30:40 --> Database Driver Class Initialized
INFO - 2022-06-22 11:30:40 --> Email Class Initialized
DEBUG - 2022-06-22 11:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:30:40 --> Controller Class Initialized
INFO - 2022-06-22 11:30:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:30:40 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:30:40 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:30:40 --> Final output sent to browser
DEBUG - 2022-06-22 11:30:40 --> Total execution time: 0.0234
INFO - 2022-06-22 11:30:41 --> Config Class Initialized
INFO - 2022-06-22 11:30:41 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:30:41 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:30:41 --> Utf8 Class Initialized
INFO - 2022-06-22 11:30:41 --> URI Class Initialized
INFO - 2022-06-22 11:30:41 --> Router Class Initialized
INFO - 2022-06-22 11:30:41 --> Output Class Initialized
INFO - 2022-06-22 11:30:41 --> Security Class Initialized
DEBUG - 2022-06-22 11:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:30:41 --> Input Class Initialized
INFO - 2022-06-22 11:30:41 --> Language Class Initialized
INFO - 2022-06-22 11:30:41 --> Loader Class Initialized
INFO - 2022-06-22 11:30:41 --> Helper loaded: url_helper
INFO - 2022-06-22 11:30:41 --> Helper loaded: file_helper
INFO - 2022-06-22 11:30:41 --> Database Driver Class Initialized
INFO - 2022-06-22 11:30:41 --> Email Class Initialized
DEBUG - 2022-06-22 11:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:30:41 --> Controller Class Initialized
INFO - 2022-06-22 11:30:41 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:30:41 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:30:41 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:30:41 --> Final output sent to browser
DEBUG - 2022-06-22 11:30:41 --> Total execution time: 0.0208
INFO - 2022-06-22 11:31:33 --> Config Class Initialized
INFO - 2022-06-22 11:31:33 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:31:33 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:31:33 --> Utf8 Class Initialized
INFO - 2022-06-22 11:31:33 --> URI Class Initialized
INFO - 2022-06-22 11:31:33 --> Router Class Initialized
INFO - 2022-06-22 11:31:33 --> Output Class Initialized
INFO - 2022-06-22 11:31:33 --> Security Class Initialized
DEBUG - 2022-06-22 11:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:31:33 --> Input Class Initialized
INFO - 2022-06-22 11:31:33 --> Language Class Initialized
INFO - 2022-06-22 11:31:33 --> Loader Class Initialized
INFO - 2022-06-22 11:31:33 --> Helper loaded: url_helper
INFO - 2022-06-22 11:31:33 --> Helper loaded: file_helper
INFO - 2022-06-22 11:31:33 --> Database Driver Class Initialized
INFO - 2022-06-22 11:31:33 --> Email Class Initialized
DEBUG - 2022-06-22 11:31:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:31:33 --> Controller Class Initialized
INFO - 2022-06-22 11:31:33 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:31:33 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:31:33 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:31:33 --> Final output sent to browser
DEBUG - 2022-06-22 11:31:33 --> Total execution time: 0.0293
INFO - 2022-06-22 11:31:44 --> Config Class Initialized
INFO - 2022-06-22 11:31:44 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:31:44 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:31:44 --> Utf8 Class Initialized
INFO - 2022-06-22 11:31:44 --> URI Class Initialized
INFO - 2022-06-22 11:31:44 --> Router Class Initialized
INFO - 2022-06-22 11:31:44 --> Output Class Initialized
INFO - 2022-06-22 11:31:44 --> Security Class Initialized
DEBUG - 2022-06-22 11:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:31:44 --> Input Class Initialized
INFO - 2022-06-22 11:31:44 --> Language Class Initialized
INFO - 2022-06-22 11:31:44 --> Loader Class Initialized
INFO - 2022-06-22 11:31:44 --> Helper loaded: url_helper
INFO - 2022-06-22 11:31:44 --> Helper loaded: file_helper
INFO - 2022-06-22 11:31:44 --> Database Driver Class Initialized
INFO - 2022-06-22 11:31:44 --> Email Class Initialized
DEBUG - 2022-06-22 11:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:31:44 --> Controller Class Initialized
INFO - 2022-06-22 11:31:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:31:44 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:31:44 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:31:44 --> Final output sent to browser
DEBUG - 2022-06-22 11:31:44 --> Total execution time: 0.0352
INFO - 2022-06-22 11:32:25 --> Config Class Initialized
INFO - 2022-06-22 11:32:25 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:32:25 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:32:25 --> Utf8 Class Initialized
INFO - 2022-06-22 11:32:25 --> URI Class Initialized
INFO - 2022-06-22 11:32:25 --> Router Class Initialized
INFO - 2022-06-22 11:32:25 --> Output Class Initialized
INFO - 2022-06-22 11:32:25 --> Security Class Initialized
DEBUG - 2022-06-22 11:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:32:25 --> Input Class Initialized
INFO - 2022-06-22 11:32:25 --> Language Class Initialized
INFO - 2022-06-22 11:32:25 --> Loader Class Initialized
INFO - 2022-06-22 11:32:25 --> Helper loaded: url_helper
INFO - 2022-06-22 11:32:25 --> Helper loaded: file_helper
INFO - 2022-06-22 11:32:25 --> Database Driver Class Initialized
INFO - 2022-06-22 11:32:25 --> Email Class Initialized
DEBUG - 2022-06-22 11:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:32:25 --> Controller Class Initialized
INFO - 2022-06-22 11:32:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:32:25 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:32:25 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:32:25 --> Final output sent to browser
DEBUG - 2022-06-22 11:32:25 --> Total execution time: 0.0517
INFO - 2022-06-22 11:32:31 --> Config Class Initialized
INFO - 2022-06-22 11:32:31 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:32:31 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:32:31 --> Utf8 Class Initialized
INFO - 2022-06-22 11:32:31 --> URI Class Initialized
INFO - 2022-06-22 11:32:31 --> Router Class Initialized
INFO - 2022-06-22 11:32:31 --> Output Class Initialized
INFO - 2022-06-22 11:32:31 --> Security Class Initialized
DEBUG - 2022-06-22 11:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:32:31 --> Input Class Initialized
INFO - 2022-06-22 11:32:31 --> Language Class Initialized
INFO - 2022-06-22 11:32:31 --> Loader Class Initialized
INFO - 2022-06-22 11:32:31 --> Helper loaded: url_helper
INFO - 2022-06-22 11:32:31 --> Helper loaded: file_helper
INFO - 2022-06-22 11:32:31 --> Database Driver Class Initialized
INFO - 2022-06-22 11:32:31 --> Email Class Initialized
DEBUG - 2022-06-22 11:32:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:32:31 --> Controller Class Initialized
INFO - 2022-06-22 11:32:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:32:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:32:31 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:32:31 --> Final output sent to browser
DEBUG - 2022-06-22 11:32:31 --> Total execution time: 0.0168
INFO - 2022-06-22 11:32:39 --> Config Class Initialized
INFO - 2022-06-22 11:32:39 --> Hooks Class Initialized
DEBUG - 2022-06-22 11:32:39 --> UTF-8 Support Enabled
INFO - 2022-06-22 11:32:39 --> Utf8 Class Initialized
INFO - 2022-06-22 11:32:39 --> URI Class Initialized
INFO - 2022-06-22 11:32:39 --> Router Class Initialized
INFO - 2022-06-22 11:32:39 --> Output Class Initialized
INFO - 2022-06-22 11:32:39 --> Security Class Initialized
DEBUG - 2022-06-22 11:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 11:32:39 --> Input Class Initialized
INFO - 2022-06-22 11:32:39 --> Language Class Initialized
INFO - 2022-06-22 11:32:39 --> Loader Class Initialized
INFO - 2022-06-22 11:32:39 --> Helper loaded: url_helper
INFO - 2022-06-22 11:32:39 --> Helper loaded: file_helper
INFO - 2022-06-22 11:32:39 --> Database Driver Class Initialized
INFO - 2022-06-22 11:32:39 --> Email Class Initialized
DEBUG - 2022-06-22 11:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 11:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 11:32:39 --> Controller Class Initialized
INFO - 2022-06-22 11:32:39 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 11:32:39 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 11:32:39 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 11:32:39 --> Final output sent to browser
DEBUG - 2022-06-22 11:32:39 --> Total execution time: 0.0191
INFO - 2022-06-22 12:03:02 --> Config Class Initialized
INFO - 2022-06-22 12:03:02 --> Hooks Class Initialized
DEBUG - 2022-06-22 12:03:02 --> UTF-8 Support Enabled
INFO - 2022-06-22 12:03:02 --> Utf8 Class Initialized
INFO - 2022-06-22 12:03:02 --> URI Class Initialized
INFO - 2022-06-22 12:03:02 --> Router Class Initialized
INFO - 2022-06-22 12:03:02 --> Output Class Initialized
INFO - 2022-06-22 12:03:02 --> Security Class Initialized
DEBUG - 2022-06-22 12:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 12:03:02 --> Input Class Initialized
INFO - 2022-06-22 12:03:02 --> Language Class Initialized
INFO - 2022-06-22 12:03:02 --> Loader Class Initialized
INFO - 2022-06-22 12:03:02 --> Helper loaded: url_helper
INFO - 2022-06-22 12:03:02 --> Helper loaded: file_helper
INFO - 2022-06-22 12:03:02 --> Database Driver Class Initialized
INFO - 2022-06-22 12:03:02 --> Email Class Initialized
DEBUG - 2022-06-22 12:03:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 12:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 12:03:02 --> Controller Class Initialized
INFO - 2022-06-22 12:03:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 12:03:02 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 12:03:02 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 12:03:02 --> Final output sent to browser
DEBUG - 2022-06-22 12:03:02 --> Total execution time: 0.0282
INFO - 2022-06-22 12:03:09 --> Config Class Initialized
INFO - 2022-06-22 12:03:09 --> Hooks Class Initialized
DEBUG - 2022-06-22 12:03:09 --> UTF-8 Support Enabled
INFO - 2022-06-22 12:03:09 --> Utf8 Class Initialized
INFO - 2022-06-22 12:03:09 --> URI Class Initialized
INFO - 2022-06-22 12:03:09 --> Router Class Initialized
INFO - 2022-06-22 12:03:09 --> Output Class Initialized
INFO - 2022-06-22 12:03:09 --> Security Class Initialized
DEBUG - 2022-06-22 12:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 12:03:09 --> Input Class Initialized
INFO - 2022-06-22 12:03:09 --> Language Class Initialized
INFO - 2022-06-22 12:03:09 --> Loader Class Initialized
INFO - 2022-06-22 12:03:09 --> Helper loaded: url_helper
INFO - 2022-06-22 12:03:09 --> Helper loaded: file_helper
INFO - 2022-06-22 12:03:09 --> Database Driver Class Initialized
INFO - 2022-06-22 12:03:09 --> Email Class Initialized
DEBUG - 2022-06-22 12:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 12:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 12:03:09 --> Controller Class Initialized
INFO - 2022-06-22 12:03:09 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 12:03:09 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 12:03:09 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 12:03:09 --> Final output sent to browser
DEBUG - 2022-06-22 12:03:09 --> Total execution time: 0.0288
INFO - 2022-06-22 12:06:44 --> Config Class Initialized
INFO - 2022-06-22 12:06:44 --> Hooks Class Initialized
DEBUG - 2022-06-22 12:06:44 --> UTF-8 Support Enabled
INFO - 2022-06-22 12:06:44 --> Utf8 Class Initialized
INFO - 2022-06-22 12:06:44 --> URI Class Initialized
INFO - 2022-06-22 12:06:44 --> Router Class Initialized
INFO - 2022-06-22 12:06:44 --> Output Class Initialized
INFO - 2022-06-22 12:06:44 --> Security Class Initialized
DEBUG - 2022-06-22 12:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 12:06:44 --> Input Class Initialized
INFO - 2022-06-22 12:06:44 --> Language Class Initialized
INFO - 2022-06-22 12:06:44 --> Loader Class Initialized
INFO - 2022-06-22 12:06:44 --> Helper loaded: url_helper
INFO - 2022-06-22 12:06:44 --> Helper loaded: file_helper
INFO - 2022-06-22 12:06:44 --> Database Driver Class Initialized
INFO - 2022-06-22 12:06:44 --> Email Class Initialized
DEBUG - 2022-06-22 12:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 12:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 12:06:44 --> Controller Class Initialized
INFO - 2022-06-22 12:06:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 12:06:44 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 12:06:44 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 12:06:44 --> Final output sent to browser
DEBUG - 2022-06-22 12:06:44 --> Total execution time: 0.0283
INFO - 2022-06-22 12:06:51 --> Config Class Initialized
INFO - 2022-06-22 12:06:51 --> Hooks Class Initialized
DEBUG - 2022-06-22 12:06:51 --> UTF-8 Support Enabled
INFO - 2022-06-22 12:06:51 --> Utf8 Class Initialized
INFO - 2022-06-22 12:06:51 --> URI Class Initialized
INFO - 2022-06-22 12:06:51 --> Router Class Initialized
INFO - 2022-06-22 12:06:51 --> Output Class Initialized
INFO - 2022-06-22 12:06:51 --> Security Class Initialized
DEBUG - 2022-06-22 12:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 12:06:51 --> Input Class Initialized
INFO - 2022-06-22 12:06:51 --> Language Class Initialized
INFO - 2022-06-22 12:06:51 --> Loader Class Initialized
INFO - 2022-06-22 12:06:51 --> Helper loaded: url_helper
INFO - 2022-06-22 12:06:51 --> Helper loaded: file_helper
INFO - 2022-06-22 12:06:51 --> Database Driver Class Initialized
INFO - 2022-06-22 12:06:51 --> Email Class Initialized
DEBUG - 2022-06-22 12:06:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 12:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 12:06:51 --> Controller Class Initialized
INFO - 2022-06-22 12:06:51 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 12:06:51 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 12:06:51 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 12:06:51 --> Final output sent to browser
DEBUG - 2022-06-22 12:06:51 --> Total execution time: 0.0467
INFO - 2022-06-22 12:07:00 --> Config Class Initialized
INFO - 2022-06-22 12:07:00 --> Hooks Class Initialized
DEBUG - 2022-06-22 12:07:00 --> UTF-8 Support Enabled
INFO - 2022-06-22 12:07:00 --> Utf8 Class Initialized
INFO - 2022-06-22 12:07:00 --> URI Class Initialized
INFO - 2022-06-22 12:07:00 --> Router Class Initialized
INFO - 2022-06-22 12:07:00 --> Output Class Initialized
INFO - 2022-06-22 12:07:00 --> Security Class Initialized
DEBUG - 2022-06-22 12:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 12:07:00 --> Input Class Initialized
INFO - 2022-06-22 12:07:00 --> Language Class Initialized
INFO - 2022-06-22 12:07:00 --> Loader Class Initialized
INFO - 2022-06-22 12:07:00 --> Helper loaded: url_helper
INFO - 2022-06-22 12:07:00 --> Helper loaded: file_helper
INFO - 2022-06-22 12:07:00 --> Database Driver Class Initialized
INFO - 2022-06-22 12:07:00 --> Email Class Initialized
DEBUG - 2022-06-22 12:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 12:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 12:07:00 --> Controller Class Initialized
INFO - 2022-06-22 12:07:00 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 12:07:00 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 12:07:00 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 12:07:00 --> Final output sent to browser
DEBUG - 2022-06-22 12:07:00 --> Total execution time: 0.0218
INFO - 2022-06-22 12:07:27 --> Config Class Initialized
INFO - 2022-06-22 12:07:27 --> Hooks Class Initialized
DEBUG - 2022-06-22 12:07:27 --> UTF-8 Support Enabled
INFO - 2022-06-22 12:07:27 --> Utf8 Class Initialized
INFO - 2022-06-22 12:07:27 --> URI Class Initialized
INFO - 2022-06-22 12:07:27 --> Router Class Initialized
INFO - 2022-06-22 12:07:27 --> Output Class Initialized
INFO - 2022-06-22 12:07:27 --> Security Class Initialized
DEBUG - 2022-06-22 12:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 12:07:27 --> Input Class Initialized
INFO - 2022-06-22 12:07:27 --> Language Class Initialized
INFO - 2022-06-22 12:07:27 --> Loader Class Initialized
INFO - 2022-06-22 12:07:27 --> Helper loaded: url_helper
INFO - 2022-06-22 12:07:27 --> Helper loaded: file_helper
INFO - 2022-06-22 12:07:27 --> Database Driver Class Initialized
INFO - 2022-06-22 12:07:27 --> Email Class Initialized
DEBUG - 2022-06-22 12:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 12:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 12:07:27 --> Controller Class Initialized
INFO - 2022-06-22 12:07:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 12:07:27 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 12:07:27 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 12:07:27 --> Final output sent to browser
DEBUG - 2022-06-22 12:07:27 --> Total execution time: 0.0326
INFO - 2022-06-22 12:07:40 --> Config Class Initialized
INFO - 2022-06-22 12:07:40 --> Hooks Class Initialized
DEBUG - 2022-06-22 12:07:40 --> UTF-8 Support Enabled
INFO - 2022-06-22 12:07:40 --> Utf8 Class Initialized
INFO - 2022-06-22 12:07:40 --> URI Class Initialized
INFO - 2022-06-22 12:07:40 --> Router Class Initialized
INFO - 2022-06-22 12:07:40 --> Output Class Initialized
INFO - 2022-06-22 12:07:40 --> Security Class Initialized
DEBUG - 2022-06-22 12:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 12:07:40 --> Input Class Initialized
INFO - 2022-06-22 12:07:40 --> Language Class Initialized
INFO - 2022-06-22 12:07:40 --> Loader Class Initialized
INFO - 2022-06-22 12:07:40 --> Helper loaded: url_helper
INFO - 2022-06-22 12:07:40 --> Helper loaded: file_helper
INFO - 2022-06-22 12:07:40 --> Database Driver Class Initialized
INFO - 2022-06-22 12:07:40 --> Email Class Initialized
DEBUG - 2022-06-22 12:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 12:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 12:07:40 --> Controller Class Initialized
INFO - 2022-06-22 12:07:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 12:07:40 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 12:07:40 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 12:07:40 --> Final output sent to browser
DEBUG - 2022-06-22 12:07:40 --> Total execution time: 0.0310
INFO - 2022-06-22 12:07:46 --> Config Class Initialized
INFO - 2022-06-22 12:07:46 --> Hooks Class Initialized
DEBUG - 2022-06-22 12:07:46 --> UTF-8 Support Enabled
INFO - 2022-06-22 12:07:46 --> Utf8 Class Initialized
INFO - 2022-06-22 12:07:46 --> URI Class Initialized
INFO - 2022-06-22 12:07:46 --> Router Class Initialized
INFO - 2022-06-22 12:07:46 --> Output Class Initialized
INFO - 2022-06-22 12:07:46 --> Security Class Initialized
DEBUG - 2022-06-22 12:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 12:07:46 --> Input Class Initialized
INFO - 2022-06-22 12:07:46 --> Language Class Initialized
INFO - 2022-06-22 12:07:46 --> Loader Class Initialized
INFO - 2022-06-22 12:07:46 --> Helper loaded: url_helper
INFO - 2022-06-22 12:07:46 --> Helper loaded: file_helper
INFO - 2022-06-22 12:07:46 --> Database Driver Class Initialized
INFO - 2022-06-22 12:07:46 --> Email Class Initialized
DEBUG - 2022-06-22 12:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 12:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 12:07:46 --> Controller Class Initialized
INFO - 2022-06-22 12:07:46 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 12:07:46 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 12:07:46 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 12:07:46 --> Final output sent to browser
DEBUG - 2022-06-22 12:07:46 --> Total execution time: 0.0169
INFO - 2022-06-22 12:08:34 --> Config Class Initialized
INFO - 2022-06-22 12:08:34 --> Hooks Class Initialized
DEBUG - 2022-06-22 12:08:34 --> UTF-8 Support Enabled
INFO - 2022-06-22 12:08:34 --> Utf8 Class Initialized
INFO - 2022-06-22 12:08:34 --> URI Class Initialized
INFO - 2022-06-22 12:08:34 --> Router Class Initialized
INFO - 2022-06-22 12:08:34 --> Output Class Initialized
INFO - 2022-06-22 12:08:34 --> Security Class Initialized
DEBUG - 2022-06-22 12:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 12:08:34 --> Input Class Initialized
INFO - 2022-06-22 12:08:34 --> Language Class Initialized
INFO - 2022-06-22 12:08:34 --> Loader Class Initialized
INFO - 2022-06-22 12:08:34 --> Helper loaded: url_helper
INFO - 2022-06-22 12:08:34 --> Helper loaded: file_helper
INFO - 2022-06-22 12:08:34 --> Database Driver Class Initialized
INFO - 2022-06-22 12:08:34 --> Email Class Initialized
DEBUG - 2022-06-22 12:08:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 12:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 12:08:34 --> Controller Class Initialized
INFO - 2022-06-22 12:08:34 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 12:08:34 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 12:08:34 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 12:08:34 --> Final output sent to browser
DEBUG - 2022-06-22 12:08:34 --> Total execution time: 0.0454
INFO - 2022-06-22 12:08:48 --> Config Class Initialized
INFO - 2022-06-22 12:08:48 --> Hooks Class Initialized
DEBUG - 2022-06-22 12:08:48 --> UTF-8 Support Enabled
INFO - 2022-06-22 12:08:48 --> Utf8 Class Initialized
INFO - 2022-06-22 12:08:48 --> URI Class Initialized
INFO - 2022-06-22 12:08:48 --> Router Class Initialized
INFO - 2022-06-22 12:08:48 --> Output Class Initialized
INFO - 2022-06-22 12:08:48 --> Security Class Initialized
DEBUG - 2022-06-22 12:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 12:08:48 --> Input Class Initialized
INFO - 2022-06-22 12:08:48 --> Language Class Initialized
INFO - 2022-06-22 12:08:48 --> Loader Class Initialized
INFO - 2022-06-22 12:08:48 --> Helper loaded: url_helper
INFO - 2022-06-22 12:08:48 --> Helper loaded: file_helper
INFO - 2022-06-22 12:08:48 --> Database Driver Class Initialized
INFO - 2022-06-22 12:08:48 --> Email Class Initialized
DEBUG - 2022-06-22 12:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 12:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 12:08:48 --> Controller Class Initialized
INFO - 2022-06-22 12:08:48 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 12:08:48 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 12:08:48 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 12:08:48 --> Final output sent to browser
DEBUG - 2022-06-22 12:08:48 --> Total execution time: 0.0342
INFO - 2022-06-22 12:08:59 --> Config Class Initialized
INFO - 2022-06-22 12:08:59 --> Hooks Class Initialized
DEBUG - 2022-06-22 12:08:59 --> UTF-8 Support Enabled
INFO - 2022-06-22 12:08:59 --> Utf8 Class Initialized
INFO - 2022-06-22 12:08:59 --> URI Class Initialized
INFO - 2022-06-22 12:08:59 --> Router Class Initialized
INFO - 2022-06-22 12:08:59 --> Output Class Initialized
INFO - 2022-06-22 12:08:59 --> Security Class Initialized
DEBUG - 2022-06-22 12:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 12:08:59 --> Input Class Initialized
INFO - 2022-06-22 12:08:59 --> Language Class Initialized
INFO - 2022-06-22 12:08:59 --> Loader Class Initialized
INFO - 2022-06-22 12:08:59 --> Helper loaded: url_helper
INFO - 2022-06-22 12:08:59 --> Helper loaded: file_helper
INFO - 2022-06-22 12:08:59 --> Database Driver Class Initialized
INFO - 2022-06-22 12:09:00 --> Email Class Initialized
DEBUG - 2022-06-22 12:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 12:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 12:09:00 --> Controller Class Initialized
INFO - 2022-06-22 12:09:00 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 12:09:00 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 12:09:00 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 12:09:00 --> Final output sent to browser
DEBUG - 2022-06-22 12:09:00 --> Total execution time: 1.6755
INFO - 2022-06-22 12:09:07 --> Config Class Initialized
INFO - 2022-06-22 12:09:07 --> Hooks Class Initialized
DEBUG - 2022-06-22 12:09:07 --> UTF-8 Support Enabled
INFO - 2022-06-22 12:09:07 --> Utf8 Class Initialized
INFO - 2022-06-22 12:09:07 --> URI Class Initialized
INFO - 2022-06-22 12:09:07 --> Router Class Initialized
INFO - 2022-06-22 12:09:07 --> Output Class Initialized
INFO - 2022-06-22 12:09:07 --> Security Class Initialized
DEBUG - 2022-06-22 12:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 12:09:07 --> Input Class Initialized
INFO - 2022-06-22 12:09:07 --> Language Class Initialized
INFO - 2022-06-22 12:09:07 --> Loader Class Initialized
INFO - 2022-06-22 12:09:07 --> Helper loaded: url_helper
INFO - 2022-06-22 12:09:07 --> Helper loaded: file_helper
INFO - 2022-06-22 12:09:07 --> Database Driver Class Initialized
INFO - 2022-06-22 12:09:07 --> Email Class Initialized
DEBUG - 2022-06-22 12:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 12:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 12:09:07 --> Controller Class Initialized
INFO - 2022-06-22 12:09:07 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 12:09:07 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 12:09:07 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 12:09:07 --> Final output sent to browser
DEBUG - 2022-06-22 12:09:07 --> Total execution time: 0.1202
INFO - 2022-06-22 12:12:46 --> Config Class Initialized
INFO - 2022-06-22 12:12:46 --> Hooks Class Initialized
DEBUG - 2022-06-22 12:12:46 --> UTF-8 Support Enabled
INFO - 2022-06-22 12:12:46 --> Utf8 Class Initialized
INFO - 2022-06-22 12:12:46 --> URI Class Initialized
INFO - 2022-06-22 12:12:46 --> Router Class Initialized
INFO - 2022-06-22 12:12:46 --> Output Class Initialized
INFO - 2022-06-22 12:12:46 --> Security Class Initialized
DEBUG - 2022-06-22 12:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 12:12:46 --> Input Class Initialized
INFO - 2022-06-22 12:12:46 --> Language Class Initialized
INFO - 2022-06-22 12:12:47 --> Loader Class Initialized
INFO - 2022-06-22 12:12:47 --> Helper loaded: url_helper
INFO - 2022-06-22 12:12:47 --> Helper loaded: file_helper
INFO - 2022-06-22 12:12:47 --> Database Driver Class Initialized
INFO - 2022-06-22 12:12:47 --> Email Class Initialized
DEBUG - 2022-06-22 12:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 12:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 12:12:47 --> Controller Class Initialized
INFO - 2022-06-22 12:12:47 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 12:12:47 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 12:12:47 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 12:12:47 --> Final output sent to browser
DEBUG - 2022-06-22 12:12:47 --> Total execution time: 0.3569
INFO - 2022-06-22 12:12:54 --> Config Class Initialized
INFO - 2022-06-22 12:12:54 --> Hooks Class Initialized
DEBUG - 2022-06-22 12:12:54 --> UTF-8 Support Enabled
INFO - 2022-06-22 12:12:54 --> Utf8 Class Initialized
INFO - 2022-06-22 12:12:54 --> URI Class Initialized
INFO - 2022-06-22 12:12:54 --> Router Class Initialized
INFO - 2022-06-22 12:12:54 --> Output Class Initialized
INFO - 2022-06-22 12:12:54 --> Security Class Initialized
DEBUG - 2022-06-22 12:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 12:12:54 --> Input Class Initialized
INFO - 2022-06-22 12:12:54 --> Language Class Initialized
INFO - 2022-06-22 12:12:54 --> Loader Class Initialized
INFO - 2022-06-22 12:12:54 --> Helper loaded: url_helper
INFO - 2022-06-22 12:12:54 --> Helper loaded: file_helper
INFO - 2022-06-22 12:12:54 --> Database Driver Class Initialized
INFO - 2022-06-22 12:12:54 --> Email Class Initialized
DEBUG - 2022-06-22 12:12:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 12:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 12:12:54 --> Controller Class Initialized
INFO - 2022-06-22 12:12:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 12:12:54 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 12:12:54 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 12:12:54 --> Final output sent to browser
DEBUG - 2022-06-22 12:12:54 --> Total execution time: 0.0454
INFO - 2022-06-22 12:13:05 --> Config Class Initialized
INFO - 2022-06-22 12:13:05 --> Hooks Class Initialized
DEBUG - 2022-06-22 12:13:05 --> UTF-8 Support Enabled
INFO - 2022-06-22 12:13:05 --> Utf8 Class Initialized
INFO - 2022-06-22 12:13:05 --> URI Class Initialized
INFO - 2022-06-22 12:13:05 --> Router Class Initialized
INFO - 2022-06-22 12:13:05 --> Output Class Initialized
INFO - 2022-06-22 12:13:05 --> Security Class Initialized
DEBUG - 2022-06-22 12:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 12:13:05 --> Input Class Initialized
INFO - 2022-06-22 12:13:05 --> Language Class Initialized
INFO - 2022-06-22 12:13:05 --> Loader Class Initialized
INFO - 2022-06-22 12:13:05 --> Helper loaded: url_helper
INFO - 2022-06-22 12:13:05 --> Helper loaded: file_helper
INFO - 2022-06-22 12:13:05 --> Database Driver Class Initialized
INFO - 2022-06-22 12:13:06 --> Email Class Initialized
DEBUG - 2022-06-22 12:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 12:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 12:13:06 --> Controller Class Initialized
INFO - 2022-06-22 12:13:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 12:13:06 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 12:13:06 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 12:13:06 --> Final output sent to browser
DEBUG - 2022-06-22 12:13:06 --> Total execution time: 0.3651
INFO - 2022-06-22 12:13:11 --> Config Class Initialized
INFO - 2022-06-22 12:13:11 --> Hooks Class Initialized
DEBUG - 2022-06-22 12:13:11 --> UTF-8 Support Enabled
INFO - 2022-06-22 12:13:11 --> Utf8 Class Initialized
INFO - 2022-06-22 12:13:11 --> URI Class Initialized
INFO - 2022-06-22 12:13:11 --> Router Class Initialized
INFO - 2022-06-22 12:13:11 --> Output Class Initialized
INFO - 2022-06-22 12:13:11 --> Security Class Initialized
DEBUG - 2022-06-22 12:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 12:13:11 --> Input Class Initialized
INFO - 2022-06-22 12:13:11 --> Language Class Initialized
INFO - 2022-06-22 12:13:11 --> Loader Class Initialized
INFO - 2022-06-22 12:13:11 --> Helper loaded: url_helper
INFO - 2022-06-22 12:13:11 --> Helper loaded: file_helper
INFO - 2022-06-22 12:13:11 --> Database Driver Class Initialized
INFO - 2022-06-22 12:13:11 --> Email Class Initialized
DEBUG - 2022-06-22 12:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 12:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 12:13:11 --> Controller Class Initialized
INFO - 2022-06-22 12:13:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 12:13:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 12:13:11 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 12:13:11 --> Final output sent to browser
DEBUG - 2022-06-22 12:13:11 --> Total execution time: 0.1435
INFO - 2022-06-22 12:15:10 --> Config Class Initialized
INFO - 2022-06-22 12:15:10 --> Hooks Class Initialized
DEBUG - 2022-06-22 12:15:10 --> UTF-8 Support Enabled
INFO - 2022-06-22 12:15:10 --> Utf8 Class Initialized
INFO - 2022-06-22 12:15:10 --> URI Class Initialized
INFO - 2022-06-22 12:15:10 --> Router Class Initialized
INFO - 2022-06-22 12:15:10 --> Output Class Initialized
INFO - 2022-06-22 12:15:10 --> Security Class Initialized
DEBUG - 2022-06-22 12:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 12:15:10 --> Input Class Initialized
INFO - 2022-06-22 12:15:10 --> Language Class Initialized
INFO - 2022-06-22 12:15:10 --> Loader Class Initialized
INFO - 2022-06-22 12:15:10 --> Helper loaded: url_helper
INFO - 2022-06-22 12:15:10 --> Helper loaded: file_helper
INFO - 2022-06-22 12:15:10 --> Database Driver Class Initialized
INFO - 2022-06-22 12:15:10 --> Email Class Initialized
DEBUG - 2022-06-22 12:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 12:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 12:15:10 --> Controller Class Initialized
INFO - 2022-06-22 12:15:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 12:15:10 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 12:15:10 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 12:15:10 --> Final output sent to browser
DEBUG - 2022-06-22 12:15:10 --> Total execution time: 0.1314
INFO - 2022-06-22 12:15:13 --> Config Class Initialized
INFO - 2022-06-22 12:15:13 --> Hooks Class Initialized
DEBUG - 2022-06-22 12:15:13 --> UTF-8 Support Enabled
INFO - 2022-06-22 12:15:13 --> Utf8 Class Initialized
INFO - 2022-06-22 12:15:13 --> URI Class Initialized
INFO - 2022-06-22 12:15:13 --> Router Class Initialized
INFO - 2022-06-22 12:15:13 --> Output Class Initialized
INFO - 2022-06-22 12:15:13 --> Security Class Initialized
DEBUG - 2022-06-22 12:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 12:15:13 --> Input Class Initialized
INFO - 2022-06-22 12:15:13 --> Language Class Initialized
INFO - 2022-06-22 12:15:13 --> Loader Class Initialized
INFO - 2022-06-22 12:15:13 --> Helper loaded: url_helper
INFO - 2022-06-22 12:15:13 --> Helper loaded: file_helper
INFO - 2022-06-22 12:15:13 --> Database Driver Class Initialized
INFO - 2022-06-22 12:15:13 --> Email Class Initialized
DEBUG - 2022-06-22 12:15:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 12:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 12:15:13 --> Controller Class Initialized
INFO - 2022-06-22 12:15:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 12:15:13 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 12:15:13 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 12:15:13 --> Final output sent to browser
DEBUG - 2022-06-22 12:15:13 --> Total execution time: 0.1463
INFO - 2022-06-22 12:15:29 --> Config Class Initialized
INFO - 2022-06-22 12:15:29 --> Hooks Class Initialized
DEBUG - 2022-06-22 12:15:29 --> UTF-8 Support Enabled
INFO - 2022-06-22 12:15:29 --> Utf8 Class Initialized
INFO - 2022-06-22 12:15:29 --> URI Class Initialized
INFO - 2022-06-22 12:15:29 --> Router Class Initialized
INFO - 2022-06-22 12:15:29 --> Output Class Initialized
INFO - 2022-06-22 12:15:29 --> Security Class Initialized
DEBUG - 2022-06-22 12:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 12:15:29 --> Input Class Initialized
INFO - 2022-06-22 12:15:29 --> Language Class Initialized
INFO - 2022-06-22 12:15:29 --> Loader Class Initialized
INFO - 2022-06-22 12:15:29 --> Helper loaded: url_helper
INFO - 2022-06-22 12:15:29 --> Helper loaded: file_helper
INFO - 2022-06-22 12:15:29 --> Database Driver Class Initialized
INFO - 2022-06-22 12:15:29 --> Email Class Initialized
DEBUG - 2022-06-22 12:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 12:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 12:15:29 --> Controller Class Initialized
INFO - 2022-06-22 12:15:29 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 12:15:29 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 12:15:29 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 12:15:29 --> Final output sent to browser
DEBUG - 2022-06-22 12:15:29 --> Total execution time: 0.0243
INFO - 2022-06-22 12:19:40 --> Config Class Initialized
INFO - 2022-06-22 12:19:40 --> Hooks Class Initialized
DEBUG - 2022-06-22 12:19:40 --> UTF-8 Support Enabled
INFO - 2022-06-22 12:19:40 --> Utf8 Class Initialized
INFO - 2022-06-22 12:19:40 --> URI Class Initialized
INFO - 2022-06-22 12:19:40 --> Router Class Initialized
INFO - 2022-06-22 12:19:40 --> Output Class Initialized
INFO - 2022-06-22 12:19:40 --> Security Class Initialized
DEBUG - 2022-06-22 12:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 12:19:40 --> Input Class Initialized
INFO - 2022-06-22 12:19:40 --> Language Class Initialized
INFO - 2022-06-22 12:19:40 --> Loader Class Initialized
INFO - 2022-06-22 12:19:40 --> Helper loaded: url_helper
INFO - 2022-06-22 12:19:40 --> Helper loaded: file_helper
INFO - 2022-06-22 12:19:40 --> Database Driver Class Initialized
INFO - 2022-06-22 12:19:40 --> Email Class Initialized
DEBUG - 2022-06-22 12:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 12:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 12:19:40 --> Controller Class Initialized
INFO - 2022-06-22 12:19:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 12:19:40 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 12:19:40 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 12:19:40 --> Final output sent to browser
DEBUG - 2022-06-22 12:19:40 --> Total execution time: 0.1169
INFO - 2022-06-22 12:20:54 --> Config Class Initialized
INFO - 2022-06-22 12:20:54 --> Hooks Class Initialized
DEBUG - 2022-06-22 12:20:54 --> UTF-8 Support Enabled
INFO - 2022-06-22 12:20:54 --> Utf8 Class Initialized
INFO - 2022-06-22 12:20:54 --> URI Class Initialized
INFO - 2022-06-22 12:20:54 --> Router Class Initialized
INFO - 2022-06-22 12:20:54 --> Output Class Initialized
INFO - 2022-06-22 12:20:54 --> Security Class Initialized
DEBUG - 2022-06-22 12:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 12:20:54 --> Input Class Initialized
INFO - 2022-06-22 12:20:54 --> Language Class Initialized
INFO - 2022-06-22 12:20:54 --> Loader Class Initialized
INFO - 2022-06-22 12:20:54 --> Helper loaded: url_helper
INFO - 2022-06-22 12:20:54 --> Helper loaded: file_helper
INFO - 2022-06-22 12:20:54 --> Database Driver Class Initialized
INFO - 2022-06-22 12:20:54 --> Email Class Initialized
DEBUG - 2022-06-22 12:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 12:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 12:20:54 --> Controller Class Initialized
INFO - 2022-06-22 12:20:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 12:20:54 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 12:20:54 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 12:20:54 --> Final output sent to browser
DEBUG - 2022-06-22 12:20:54 --> Total execution time: 0.0311
INFO - 2022-06-22 12:21:24 --> Config Class Initialized
INFO - 2022-06-22 12:21:24 --> Hooks Class Initialized
DEBUG - 2022-06-22 12:21:24 --> UTF-8 Support Enabled
INFO - 2022-06-22 12:21:24 --> Utf8 Class Initialized
INFO - 2022-06-22 12:21:24 --> URI Class Initialized
INFO - 2022-06-22 12:21:24 --> Router Class Initialized
INFO - 2022-06-22 12:21:24 --> Output Class Initialized
INFO - 2022-06-22 12:21:24 --> Security Class Initialized
DEBUG - 2022-06-22 12:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 12:21:24 --> Input Class Initialized
INFO - 2022-06-22 12:21:24 --> Language Class Initialized
INFO - 2022-06-22 12:21:24 --> Loader Class Initialized
INFO - 2022-06-22 12:21:24 --> Helper loaded: url_helper
INFO - 2022-06-22 12:21:24 --> Helper loaded: file_helper
INFO - 2022-06-22 12:21:24 --> Database Driver Class Initialized
INFO - 2022-06-22 12:21:26 --> Email Class Initialized
DEBUG - 2022-06-22 12:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 12:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 12:21:26 --> Controller Class Initialized
INFO - 2022-06-22 12:21:26 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 12:21:26 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 12:21:26 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 12:21:26 --> Final output sent to browser
DEBUG - 2022-06-22 12:21:26 --> Total execution time: 1.4030
INFO - 2022-06-22 12:22:06 --> Config Class Initialized
INFO - 2022-06-22 12:22:06 --> Hooks Class Initialized
DEBUG - 2022-06-22 12:22:06 --> UTF-8 Support Enabled
INFO - 2022-06-22 12:22:06 --> Utf8 Class Initialized
INFO - 2022-06-22 12:22:06 --> URI Class Initialized
INFO - 2022-06-22 12:22:06 --> Router Class Initialized
INFO - 2022-06-22 12:22:06 --> Output Class Initialized
INFO - 2022-06-22 12:22:06 --> Security Class Initialized
DEBUG - 2022-06-22 12:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-22 12:22:06 --> Input Class Initialized
INFO - 2022-06-22 12:22:06 --> Language Class Initialized
INFO - 2022-06-22 12:22:06 --> Loader Class Initialized
INFO - 2022-06-22 12:22:06 --> Helper loaded: url_helper
INFO - 2022-06-22 12:22:06 --> Helper loaded: file_helper
INFO - 2022-06-22 12:22:06 --> Database Driver Class Initialized
INFO - 2022-06-22 12:22:06 --> Email Class Initialized
DEBUG - 2022-06-22 12:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-22 12:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-22 12:22:06 --> Controller Class Initialized
INFO - 2022-06-22 12:22:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-22 12:22:06 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-22 12:22:06 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-22 12:22:06 --> Final output sent to browser
DEBUG - 2022-06-22 12:22:06 --> Total execution time: 0.0415
