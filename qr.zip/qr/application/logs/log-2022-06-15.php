<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-06-15 09:49:21 --> Config Class Initialized
INFO - 2022-06-15 09:49:21 --> Hooks Class Initialized
DEBUG - 2022-06-15 09:49:21 --> UTF-8 Support Enabled
INFO - 2022-06-15 09:49:21 --> Utf8 Class Initialized
INFO - 2022-06-15 09:49:21 --> URI Class Initialized
INFO - 2022-06-15 09:49:21 --> Router Class Initialized
INFO - 2022-06-15 09:49:21 --> Output Class Initialized
INFO - 2022-06-15 09:49:21 --> Security Class Initialized
DEBUG - 2022-06-15 09:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-15 09:49:21 --> Input Class Initialized
INFO - 2022-06-15 09:49:21 --> Language Class Initialized
INFO - 2022-06-15 09:49:21 --> Loader Class Initialized
INFO - 2022-06-15 09:49:21 --> Controller Class Initialized
INFO - 2022-06-15 09:49:21 --> Model "Tokenmodel" initialized
ERROR - 2022-06-15 09:49:21 --> Severity: Notice --> Undefined property: Tokenctrl::$db C:\wamp64\www\qr\system\core\Model.php 74
ERROR - 2022-06-15 09:49:21 --> Severity: error --> Exception: Call to a member function select_max() on null C:\wamp64\www\qr\application\models\Tokenmodel.php 8
