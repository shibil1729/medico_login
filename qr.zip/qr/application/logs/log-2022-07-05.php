<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-07-05 04:20:47 --> Config Class Initialized
INFO - 2022-07-05 04:20:47 --> Hooks Class Initialized
DEBUG - 2022-07-05 04:20:47 --> UTF-8 Support Enabled
INFO - 2022-07-05 04:20:47 --> Utf8 Class Initialized
INFO - 2022-07-05 04:20:47 --> URI Class Initialized
INFO - 2022-07-05 04:20:47 --> Router Class Initialized
INFO - 2022-07-05 04:20:47 --> Output Class Initialized
INFO - 2022-07-05 04:20:47 --> Security Class Initialized
DEBUG - 2022-07-05 04:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 04:20:47 --> Input Class Initialized
INFO - 2022-07-05 04:20:47 --> Language Class Initialized
INFO - 2022-07-05 04:20:47 --> Loader Class Initialized
INFO - 2022-07-05 04:20:47 --> Helper loaded: url_helper
INFO - 2022-07-05 04:20:47 --> Helper loaded: file_helper
INFO - 2022-07-05 04:20:47 --> Database Driver Class Initialized
INFO - 2022-07-05 04:20:47 --> Email Class Initialized
DEBUG - 2022-07-05 04:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 04:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 04:20:47 --> Controller Class Initialized
INFO - 2022-07-05 04:20:47 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 04:20:47 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 04:20:47 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 04:20:47 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 04:20:47 --> Final output sent to browser
DEBUG - 2022-07-05 04:20:47 --> Total execution time: 0.3645
INFO - 2022-07-05 04:20:53 --> Config Class Initialized
INFO - 2022-07-05 04:20:53 --> Hooks Class Initialized
DEBUG - 2022-07-05 04:20:53 --> UTF-8 Support Enabled
INFO - 2022-07-05 04:20:53 --> Utf8 Class Initialized
INFO - 2022-07-05 04:20:53 --> URI Class Initialized
INFO - 2022-07-05 04:20:53 --> Router Class Initialized
INFO - 2022-07-05 04:20:53 --> Output Class Initialized
INFO - 2022-07-05 04:20:53 --> Security Class Initialized
DEBUG - 2022-07-05 04:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 04:20:53 --> Input Class Initialized
INFO - 2022-07-05 04:20:53 --> Language Class Initialized
INFO - 2022-07-05 04:20:53 --> Loader Class Initialized
INFO - 2022-07-05 04:20:53 --> Helper loaded: url_helper
INFO - 2022-07-05 04:20:53 --> Helper loaded: file_helper
INFO - 2022-07-05 04:20:53 --> Database Driver Class Initialized
INFO - 2022-07-05 04:20:53 --> Email Class Initialized
DEBUG - 2022-07-05 04:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 04:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 04:20:53 --> Controller Class Initialized
INFO - 2022-07-05 04:20:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 04:20:53 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 04:20:53 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 04:20:53 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 04:20:53 --> Final output sent to browser
DEBUG - 2022-07-05 04:20:53 --> Total execution time: 0.0522
INFO - 2022-07-05 04:20:54 --> Config Class Initialized
INFO - 2022-07-05 04:20:54 --> Hooks Class Initialized
DEBUG - 2022-07-05 04:20:54 --> UTF-8 Support Enabled
INFO - 2022-07-05 04:20:54 --> Utf8 Class Initialized
INFO - 2022-07-05 04:20:54 --> URI Class Initialized
INFO - 2022-07-05 04:20:54 --> Router Class Initialized
INFO - 2022-07-05 04:20:54 --> Output Class Initialized
INFO - 2022-07-05 04:20:54 --> Security Class Initialized
DEBUG - 2022-07-05 04:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 04:20:54 --> Input Class Initialized
INFO - 2022-07-05 04:20:54 --> Language Class Initialized
INFO - 2022-07-05 04:20:54 --> Loader Class Initialized
INFO - 2022-07-05 04:20:54 --> Helper loaded: url_helper
INFO - 2022-07-05 04:20:54 --> Helper loaded: file_helper
INFO - 2022-07-05 04:20:54 --> Database Driver Class Initialized
INFO - 2022-07-05 04:20:54 --> Email Class Initialized
DEBUG - 2022-07-05 04:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 04:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 04:20:54 --> Controller Class Initialized
INFO - 2022-07-05 04:20:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 04:20:54 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 04:20:54 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 04:20:54 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 04:20:54 --> Final output sent to browser
DEBUG - 2022-07-05 04:20:54 --> Total execution time: 0.0241
INFO - 2022-07-05 04:31:32 --> Config Class Initialized
INFO - 2022-07-05 04:31:32 --> Hooks Class Initialized
DEBUG - 2022-07-05 04:31:32 --> UTF-8 Support Enabled
INFO - 2022-07-05 04:31:32 --> Utf8 Class Initialized
INFO - 2022-07-05 04:31:32 --> URI Class Initialized
INFO - 2022-07-05 04:31:32 --> Router Class Initialized
INFO - 2022-07-05 04:31:32 --> Output Class Initialized
INFO - 2022-07-05 04:31:32 --> Security Class Initialized
DEBUG - 2022-07-05 04:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 04:31:32 --> Input Class Initialized
INFO - 2022-07-05 04:31:32 --> Language Class Initialized
INFO - 2022-07-05 04:31:32 --> Loader Class Initialized
INFO - 2022-07-05 04:31:32 --> Helper loaded: url_helper
INFO - 2022-07-05 04:31:32 --> Helper loaded: file_helper
INFO - 2022-07-05 04:31:32 --> Database Driver Class Initialized
INFO - 2022-07-05 04:31:33 --> Email Class Initialized
DEBUG - 2022-07-05 04:31:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 04:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 04:31:33 --> Controller Class Initialized
INFO - 2022-07-05 04:31:33 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 04:31:33 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 04:31:33 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 04:31:33 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 04:31:33 --> Final output sent to browser
DEBUG - 2022-07-05 04:31:33 --> Total execution time: 0.4614
INFO - 2022-07-05 04:35:26 --> Config Class Initialized
INFO - 2022-07-05 04:35:26 --> Hooks Class Initialized
DEBUG - 2022-07-05 04:35:26 --> UTF-8 Support Enabled
INFO - 2022-07-05 04:35:26 --> Utf8 Class Initialized
INFO - 2022-07-05 04:35:26 --> URI Class Initialized
INFO - 2022-07-05 04:35:26 --> Router Class Initialized
INFO - 2022-07-05 04:35:26 --> Output Class Initialized
INFO - 2022-07-05 04:35:26 --> Security Class Initialized
DEBUG - 2022-07-05 04:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 04:35:26 --> Input Class Initialized
INFO - 2022-07-05 04:35:26 --> Language Class Initialized
INFO - 2022-07-05 04:35:26 --> Loader Class Initialized
INFO - 2022-07-05 04:35:26 --> Helper loaded: url_helper
INFO - 2022-07-05 04:35:26 --> Helper loaded: file_helper
INFO - 2022-07-05 04:35:26 --> Database Driver Class Initialized
INFO - 2022-07-05 04:35:26 --> Email Class Initialized
DEBUG - 2022-07-05 04:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 04:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 04:35:26 --> Controller Class Initialized
INFO - 2022-07-05 04:35:26 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 04:35:26 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 04:35:26 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 04:35:26 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 04:35:26 --> Final output sent to browser
DEBUG - 2022-07-05 04:35:26 --> Total execution time: 0.1945
INFO - 2022-07-05 04:35:42 --> Config Class Initialized
INFO - 2022-07-05 04:35:42 --> Hooks Class Initialized
DEBUG - 2022-07-05 04:35:42 --> UTF-8 Support Enabled
INFO - 2022-07-05 04:35:42 --> Utf8 Class Initialized
INFO - 2022-07-05 04:35:42 --> URI Class Initialized
INFO - 2022-07-05 04:35:42 --> Router Class Initialized
INFO - 2022-07-05 04:35:42 --> Output Class Initialized
INFO - 2022-07-05 04:35:42 --> Security Class Initialized
DEBUG - 2022-07-05 04:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 04:35:42 --> Input Class Initialized
INFO - 2022-07-05 04:35:42 --> Language Class Initialized
INFO - 2022-07-05 04:35:42 --> Loader Class Initialized
INFO - 2022-07-05 04:35:42 --> Helper loaded: url_helper
INFO - 2022-07-05 04:35:42 --> Helper loaded: file_helper
INFO - 2022-07-05 04:35:42 --> Database Driver Class Initialized
INFO - 2022-07-05 04:35:42 --> Email Class Initialized
DEBUG - 2022-07-05 04:35:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 04:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 04:35:42 --> Controller Class Initialized
INFO - 2022-07-05 04:35:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 04:35:42 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 04:35:42 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 04:35:42 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 04:35:42 --> Final output sent to browser
DEBUG - 2022-07-05 04:35:42 --> Total execution time: 0.0688
INFO - 2022-07-05 04:36:11 --> Config Class Initialized
INFO - 2022-07-05 04:36:11 --> Hooks Class Initialized
DEBUG - 2022-07-05 04:36:11 --> UTF-8 Support Enabled
INFO - 2022-07-05 04:36:11 --> Utf8 Class Initialized
INFO - 2022-07-05 04:36:11 --> URI Class Initialized
INFO - 2022-07-05 04:36:11 --> Router Class Initialized
INFO - 2022-07-05 04:36:11 --> Output Class Initialized
INFO - 2022-07-05 04:36:11 --> Security Class Initialized
DEBUG - 2022-07-05 04:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 04:36:11 --> Input Class Initialized
INFO - 2022-07-05 04:36:11 --> Language Class Initialized
INFO - 2022-07-05 04:36:11 --> Loader Class Initialized
INFO - 2022-07-05 04:36:11 --> Helper loaded: url_helper
INFO - 2022-07-05 04:36:11 --> Helper loaded: file_helper
INFO - 2022-07-05 04:36:11 --> Database Driver Class Initialized
INFO - 2022-07-05 04:36:11 --> Email Class Initialized
DEBUG - 2022-07-05 04:36:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 04:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 04:36:11 --> Controller Class Initialized
INFO - 2022-07-05 04:36:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 04:36:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 04:36:11 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 04:36:11 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 04:36:11 --> Final output sent to browser
DEBUG - 2022-07-05 04:36:11 --> Total execution time: 0.0524
INFO - 2022-07-05 04:38:23 --> Config Class Initialized
INFO - 2022-07-05 04:38:23 --> Hooks Class Initialized
DEBUG - 2022-07-05 04:38:23 --> UTF-8 Support Enabled
INFO - 2022-07-05 04:38:23 --> Utf8 Class Initialized
INFO - 2022-07-05 04:38:23 --> URI Class Initialized
INFO - 2022-07-05 04:38:23 --> Router Class Initialized
INFO - 2022-07-05 04:38:23 --> Output Class Initialized
INFO - 2022-07-05 04:38:23 --> Security Class Initialized
DEBUG - 2022-07-05 04:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 04:38:23 --> Input Class Initialized
INFO - 2022-07-05 04:38:23 --> Language Class Initialized
INFO - 2022-07-05 04:38:23 --> Loader Class Initialized
INFO - 2022-07-05 04:38:23 --> Helper loaded: url_helper
INFO - 2022-07-05 04:38:23 --> Helper loaded: file_helper
INFO - 2022-07-05 04:38:23 --> Database Driver Class Initialized
INFO - 2022-07-05 04:38:23 --> Email Class Initialized
DEBUG - 2022-07-05 04:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 04:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 04:38:23 --> Controller Class Initialized
INFO - 2022-07-05 04:38:23 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 04:38:23 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 04:38:23 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 04:38:23 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 04:38:23 --> Final output sent to browser
DEBUG - 2022-07-05 04:38:23 --> Total execution time: 0.1088
INFO - 2022-07-05 04:49:48 --> Config Class Initialized
INFO - 2022-07-05 04:49:48 --> Hooks Class Initialized
DEBUG - 2022-07-05 04:49:48 --> UTF-8 Support Enabled
INFO - 2022-07-05 04:49:48 --> Utf8 Class Initialized
INFO - 2022-07-05 04:49:48 --> URI Class Initialized
INFO - 2022-07-05 04:49:48 --> Router Class Initialized
INFO - 2022-07-05 04:49:48 --> Output Class Initialized
INFO - 2022-07-05 04:49:48 --> Security Class Initialized
DEBUG - 2022-07-05 04:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 04:49:48 --> Input Class Initialized
INFO - 2022-07-05 04:49:48 --> Language Class Initialized
INFO - 2022-07-05 04:49:48 --> Loader Class Initialized
INFO - 2022-07-05 04:49:48 --> Helper loaded: url_helper
INFO - 2022-07-05 04:49:48 --> Helper loaded: file_helper
INFO - 2022-07-05 04:49:48 --> Database Driver Class Initialized
INFO - 2022-07-05 04:49:48 --> Email Class Initialized
DEBUG - 2022-07-05 04:49:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 04:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 04:49:49 --> Controller Class Initialized
INFO - 2022-07-05 04:49:49 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 04:49:49 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 04:49:49 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 04:49:49 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 04:49:49 --> Final output sent to browser
DEBUG - 2022-07-05 04:49:49 --> Total execution time: 0.3212
INFO - 2022-07-05 04:50:28 --> Config Class Initialized
INFO - 2022-07-05 04:50:28 --> Hooks Class Initialized
DEBUG - 2022-07-05 04:50:28 --> UTF-8 Support Enabled
INFO - 2022-07-05 04:50:28 --> Utf8 Class Initialized
INFO - 2022-07-05 04:50:28 --> URI Class Initialized
INFO - 2022-07-05 04:50:28 --> Router Class Initialized
INFO - 2022-07-05 04:50:28 --> Output Class Initialized
INFO - 2022-07-05 04:50:28 --> Security Class Initialized
DEBUG - 2022-07-05 04:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 04:50:28 --> Input Class Initialized
INFO - 2022-07-05 04:50:28 --> Language Class Initialized
INFO - 2022-07-05 04:50:28 --> Loader Class Initialized
INFO - 2022-07-05 04:50:28 --> Helper loaded: url_helper
INFO - 2022-07-05 04:50:28 --> Helper loaded: file_helper
INFO - 2022-07-05 04:50:28 --> Database Driver Class Initialized
INFO - 2022-07-05 04:50:28 --> Email Class Initialized
DEBUG - 2022-07-05 04:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 04:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 04:50:28 --> Controller Class Initialized
INFO - 2022-07-05 04:50:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 04:50:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 04:50:28 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 04:50:28 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 04:50:28 --> Final output sent to browser
DEBUG - 2022-07-05 04:50:28 --> Total execution time: 0.1273
INFO - 2022-07-05 04:51:28 --> Config Class Initialized
INFO - 2022-07-05 04:51:28 --> Hooks Class Initialized
DEBUG - 2022-07-05 04:51:28 --> UTF-8 Support Enabled
INFO - 2022-07-05 04:51:28 --> Utf8 Class Initialized
INFO - 2022-07-05 04:51:28 --> URI Class Initialized
INFO - 2022-07-05 04:51:28 --> Router Class Initialized
INFO - 2022-07-05 04:51:28 --> Output Class Initialized
INFO - 2022-07-05 04:51:28 --> Security Class Initialized
DEBUG - 2022-07-05 04:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 04:51:28 --> Input Class Initialized
INFO - 2022-07-05 04:51:28 --> Language Class Initialized
INFO - 2022-07-05 04:51:28 --> Loader Class Initialized
INFO - 2022-07-05 04:51:28 --> Helper loaded: url_helper
INFO - 2022-07-05 04:51:28 --> Helper loaded: file_helper
INFO - 2022-07-05 04:51:28 --> Database Driver Class Initialized
INFO - 2022-07-05 04:51:28 --> Email Class Initialized
DEBUG - 2022-07-05 04:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 04:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 04:51:28 --> Controller Class Initialized
INFO - 2022-07-05 04:51:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 04:51:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 04:51:28 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 04:51:28 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 04:51:28 --> Final output sent to browser
DEBUG - 2022-07-05 04:51:28 --> Total execution time: 0.1581
INFO - 2022-07-05 04:53:13 --> Config Class Initialized
INFO - 2022-07-05 04:53:13 --> Hooks Class Initialized
DEBUG - 2022-07-05 04:53:13 --> UTF-8 Support Enabled
INFO - 2022-07-05 04:53:13 --> Utf8 Class Initialized
INFO - 2022-07-05 04:53:13 --> URI Class Initialized
INFO - 2022-07-05 04:53:13 --> Router Class Initialized
INFO - 2022-07-05 04:53:13 --> Output Class Initialized
INFO - 2022-07-05 04:53:13 --> Security Class Initialized
DEBUG - 2022-07-05 04:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 04:53:13 --> Input Class Initialized
INFO - 2022-07-05 04:53:13 --> Language Class Initialized
INFO - 2022-07-05 04:53:13 --> Loader Class Initialized
INFO - 2022-07-05 04:53:13 --> Helper loaded: url_helper
INFO - 2022-07-05 04:53:13 --> Helper loaded: file_helper
INFO - 2022-07-05 04:53:13 --> Database Driver Class Initialized
INFO - 2022-07-05 04:53:13 --> Email Class Initialized
DEBUG - 2022-07-05 04:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 04:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 04:53:13 --> Controller Class Initialized
INFO - 2022-07-05 04:53:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 04:53:13 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 04:53:13 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 04:53:13 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 04:53:13 --> Final output sent to browser
DEBUG - 2022-07-05 04:53:13 --> Total execution time: 0.0824
INFO - 2022-07-05 04:53:27 --> Config Class Initialized
INFO - 2022-07-05 04:53:27 --> Hooks Class Initialized
DEBUG - 2022-07-05 04:53:27 --> UTF-8 Support Enabled
INFO - 2022-07-05 04:53:27 --> Utf8 Class Initialized
INFO - 2022-07-05 04:53:27 --> URI Class Initialized
INFO - 2022-07-05 04:53:27 --> Router Class Initialized
INFO - 2022-07-05 04:53:27 --> Output Class Initialized
INFO - 2022-07-05 04:53:27 --> Security Class Initialized
DEBUG - 2022-07-05 04:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 04:53:27 --> Input Class Initialized
INFO - 2022-07-05 04:53:27 --> Language Class Initialized
INFO - 2022-07-05 04:53:27 --> Loader Class Initialized
INFO - 2022-07-05 04:53:27 --> Helper loaded: url_helper
INFO - 2022-07-05 04:53:27 --> Helper loaded: file_helper
INFO - 2022-07-05 04:53:27 --> Database Driver Class Initialized
INFO - 2022-07-05 04:53:27 --> Email Class Initialized
DEBUG - 2022-07-05 04:53:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 04:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 04:53:27 --> Controller Class Initialized
INFO - 2022-07-05 04:53:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 04:53:27 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 04:53:27 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 04:53:27 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 04:53:27 --> Final output sent to browser
DEBUG - 2022-07-05 04:53:27 --> Total execution time: 0.1575
INFO - 2022-07-05 04:55:18 --> Config Class Initialized
INFO - 2022-07-05 04:55:18 --> Hooks Class Initialized
DEBUG - 2022-07-05 04:55:18 --> UTF-8 Support Enabled
INFO - 2022-07-05 04:55:18 --> Utf8 Class Initialized
INFO - 2022-07-05 04:55:18 --> URI Class Initialized
INFO - 2022-07-05 04:55:18 --> Router Class Initialized
INFO - 2022-07-05 04:55:18 --> Output Class Initialized
INFO - 2022-07-05 04:55:18 --> Security Class Initialized
DEBUG - 2022-07-05 04:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 04:55:18 --> Input Class Initialized
INFO - 2022-07-05 04:55:18 --> Language Class Initialized
INFO - 2022-07-05 04:55:18 --> Loader Class Initialized
INFO - 2022-07-05 04:55:18 --> Helper loaded: url_helper
INFO - 2022-07-05 04:55:18 --> Helper loaded: file_helper
INFO - 2022-07-05 04:55:18 --> Database Driver Class Initialized
INFO - 2022-07-05 04:55:18 --> Email Class Initialized
DEBUG - 2022-07-05 04:55:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 04:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 04:55:18 --> Controller Class Initialized
INFO - 2022-07-05 04:55:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 04:55:18 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 04:55:18 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 04:55:18 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 04:55:18 --> Final output sent to browser
DEBUG - 2022-07-05 04:55:18 --> Total execution time: 0.1867
INFO - 2022-07-05 04:56:24 --> Config Class Initialized
INFO - 2022-07-05 04:56:24 --> Hooks Class Initialized
DEBUG - 2022-07-05 04:56:24 --> UTF-8 Support Enabled
INFO - 2022-07-05 04:56:24 --> Utf8 Class Initialized
INFO - 2022-07-05 04:56:24 --> URI Class Initialized
INFO - 2022-07-05 04:56:24 --> Router Class Initialized
INFO - 2022-07-05 04:56:24 --> Output Class Initialized
INFO - 2022-07-05 04:56:24 --> Security Class Initialized
DEBUG - 2022-07-05 04:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 04:56:24 --> Input Class Initialized
INFO - 2022-07-05 04:56:24 --> Language Class Initialized
INFO - 2022-07-05 04:56:24 --> Loader Class Initialized
INFO - 2022-07-05 04:56:24 --> Helper loaded: url_helper
INFO - 2022-07-05 04:56:24 --> Helper loaded: file_helper
INFO - 2022-07-05 04:56:24 --> Database Driver Class Initialized
INFO - 2022-07-05 04:56:24 --> Email Class Initialized
DEBUG - 2022-07-05 04:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 04:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 04:56:24 --> Controller Class Initialized
INFO - 2022-07-05 04:56:24 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 04:56:24 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 04:56:24 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 04:56:24 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 04:56:24 --> Final output sent to browser
DEBUG - 2022-07-05 04:56:24 --> Total execution time: 0.0277
INFO - 2022-07-05 05:14:07 --> Config Class Initialized
INFO - 2022-07-05 05:14:07 --> Hooks Class Initialized
DEBUG - 2022-07-05 05:14:07 --> UTF-8 Support Enabled
INFO - 2022-07-05 05:14:07 --> Utf8 Class Initialized
INFO - 2022-07-05 05:14:07 --> URI Class Initialized
INFO - 2022-07-05 05:14:07 --> Router Class Initialized
INFO - 2022-07-05 05:14:07 --> Output Class Initialized
INFO - 2022-07-05 05:14:07 --> Security Class Initialized
DEBUG - 2022-07-05 05:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 05:14:07 --> Input Class Initialized
INFO - 2022-07-05 05:14:07 --> Language Class Initialized
INFO - 2022-07-05 05:14:07 --> Loader Class Initialized
INFO - 2022-07-05 05:14:07 --> Helper loaded: url_helper
INFO - 2022-07-05 05:14:07 --> Helper loaded: file_helper
INFO - 2022-07-05 05:14:07 --> Database Driver Class Initialized
INFO - 2022-07-05 05:14:07 --> Email Class Initialized
DEBUG - 2022-07-05 05:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 05:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 05:14:07 --> Controller Class Initialized
INFO - 2022-07-05 05:14:07 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 05:14:07 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 05:14:07 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 05:14:07 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 05:14:07 --> Final output sent to browser
DEBUG - 2022-07-05 05:14:07 --> Total execution time: 0.1285
INFO - 2022-07-05 05:14:14 --> Config Class Initialized
INFO - 2022-07-05 05:14:14 --> Hooks Class Initialized
DEBUG - 2022-07-05 05:14:14 --> UTF-8 Support Enabled
INFO - 2022-07-05 05:14:14 --> Utf8 Class Initialized
INFO - 2022-07-05 05:14:14 --> URI Class Initialized
INFO - 2022-07-05 05:14:14 --> Router Class Initialized
INFO - 2022-07-05 05:14:14 --> Output Class Initialized
INFO - 2022-07-05 05:14:14 --> Security Class Initialized
DEBUG - 2022-07-05 05:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 05:14:14 --> Input Class Initialized
INFO - 2022-07-05 05:14:14 --> Language Class Initialized
INFO - 2022-07-05 05:14:14 --> Loader Class Initialized
INFO - 2022-07-05 05:14:14 --> Helper loaded: url_helper
INFO - 2022-07-05 05:14:14 --> Helper loaded: file_helper
INFO - 2022-07-05 05:14:14 --> Database Driver Class Initialized
INFO - 2022-07-05 05:14:14 --> Email Class Initialized
DEBUG - 2022-07-05 05:14:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 05:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 05:14:14 --> Controller Class Initialized
INFO - 2022-07-05 05:14:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 05:14:14 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 05:14:14 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 05:14:14 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 05:14:14 --> Final output sent to browser
DEBUG - 2022-07-05 05:14:14 --> Total execution time: 0.1327
INFO - 2022-07-05 05:15:07 --> Config Class Initialized
INFO - 2022-07-05 05:15:07 --> Hooks Class Initialized
DEBUG - 2022-07-05 05:15:07 --> UTF-8 Support Enabled
INFO - 2022-07-05 05:15:07 --> Utf8 Class Initialized
INFO - 2022-07-05 05:15:07 --> URI Class Initialized
INFO - 2022-07-05 05:15:07 --> Router Class Initialized
INFO - 2022-07-05 05:15:07 --> Output Class Initialized
INFO - 2022-07-05 05:15:07 --> Security Class Initialized
DEBUG - 2022-07-05 05:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 05:15:07 --> Input Class Initialized
INFO - 2022-07-05 05:15:07 --> Language Class Initialized
INFO - 2022-07-05 05:15:07 --> Loader Class Initialized
INFO - 2022-07-05 05:15:07 --> Helper loaded: url_helper
INFO - 2022-07-05 05:15:07 --> Helper loaded: file_helper
INFO - 2022-07-05 05:15:07 --> Database Driver Class Initialized
INFO - 2022-07-05 05:15:07 --> Email Class Initialized
DEBUG - 2022-07-05 05:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 05:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 05:15:07 --> Controller Class Initialized
INFO - 2022-07-05 05:15:07 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 05:15:07 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 05:15:07 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 05:15:07 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 05:15:07 --> Final output sent to browser
DEBUG - 2022-07-05 05:15:07 --> Total execution time: 0.0754
INFO - 2022-07-05 05:21:56 --> Config Class Initialized
INFO - 2022-07-05 05:21:56 --> Hooks Class Initialized
DEBUG - 2022-07-05 05:21:56 --> UTF-8 Support Enabled
INFO - 2022-07-05 05:21:56 --> Utf8 Class Initialized
INFO - 2022-07-05 05:21:56 --> URI Class Initialized
INFO - 2022-07-05 05:21:56 --> Router Class Initialized
INFO - 2022-07-05 05:21:56 --> Output Class Initialized
INFO - 2022-07-05 05:21:56 --> Security Class Initialized
DEBUG - 2022-07-05 05:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 05:21:56 --> Input Class Initialized
INFO - 2022-07-05 05:21:56 --> Language Class Initialized
INFO - 2022-07-05 05:21:56 --> Loader Class Initialized
INFO - 2022-07-05 05:21:56 --> Helper loaded: url_helper
INFO - 2022-07-05 05:21:56 --> Helper loaded: file_helper
INFO - 2022-07-05 05:21:56 --> Database Driver Class Initialized
INFO - 2022-07-05 05:21:56 --> Email Class Initialized
DEBUG - 2022-07-05 05:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 05:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 05:21:56 --> Controller Class Initialized
INFO - 2022-07-05 05:21:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 05:21:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 05:21:56 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 05:21:56 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 05:21:56 --> Final output sent to browser
DEBUG - 2022-07-05 05:21:56 --> Total execution time: 0.1667
INFO - 2022-07-05 05:26:35 --> Config Class Initialized
INFO - 2022-07-05 05:26:35 --> Hooks Class Initialized
DEBUG - 2022-07-05 05:26:35 --> UTF-8 Support Enabled
INFO - 2022-07-05 05:26:35 --> Utf8 Class Initialized
INFO - 2022-07-05 05:26:35 --> URI Class Initialized
INFO - 2022-07-05 05:26:35 --> Router Class Initialized
INFO - 2022-07-05 05:26:35 --> Output Class Initialized
INFO - 2022-07-05 05:26:35 --> Security Class Initialized
DEBUG - 2022-07-05 05:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 05:26:35 --> Input Class Initialized
INFO - 2022-07-05 05:26:35 --> Language Class Initialized
INFO - 2022-07-05 05:26:35 --> Loader Class Initialized
INFO - 2022-07-05 05:26:35 --> Helper loaded: url_helper
INFO - 2022-07-05 05:26:35 --> Helper loaded: file_helper
INFO - 2022-07-05 05:26:35 --> Database Driver Class Initialized
INFO - 2022-07-05 05:26:35 --> Email Class Initialized
DEBUG - 2022-07-05 05:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 05:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 05:26:35 --> Controller Class Initialized
INFO - 2022-07-05 05:26:35 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 05:26:35 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 05:26:35 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 05:26:35 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 05:26:35 --> Final output sent to browser
DEBUG - 2022-07-05 05:26:35 --> Total execution time: 0.1412
INFO - 2022-07-05 05:33:46 --> Config Class Initialized
INFO - 2022-07-05 05:33:46 --> Hooks Class Initialized
DEBUG - 2022-07-05 05:33:46 --> UTF-8 Support Enabled
INFO - 2022-07-05 05:33:46 --> Utf8 Class Initialized
INFO - 2022-07-05 05:33:46 --> URI Class Initialized
INFO - 2022-07-05 05:33:46 --> Router Class Initialized
INFO - 2022-07-05 05:33:46 --> Output Class Initialized
INFO - 2022-07-05 05:33:46 --> Security Class Initialized
DEBUG - 2022-07-05 05:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 05:33:46 --> Input Class Initialized
INFO - 2022-07-05 05:33:46 --> Language Class Initialized
INFO - 2022-07-05 05:33:46 --> Loader Class Initialized
INFO - 2022-07-05 05:33:46 --> Helper loaded: url_helper
INFO - 2022-07-05 05:33:46 --> Helper loaded: file_helper
INFO - 2022-07-05 05:33:46 --> Database Driver Class Initialized
INFO - 2022-07-05 05:33:46 --> Email Class Initialized
DEBUG - 2022-07-05 05:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 05:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 05:33:46 --> Controller Class Initialized
INFO - 2022-07-05 05:33:46 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 05:33:46 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 05:33:46 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 05:33:46 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 05:33:46 --> Final output sent to browser
DEBUG - 2022-07-05 05:33:46 --> Total execution time: 0.1133
INFO - 2022-07-05 05:35:50 --> Config Class Initialized
INFO - 2022-07-05 05:35:50 --> Hooks Class Initialized
DEBUG - 2022-07-05 05:35:50 --> UTF-8 Support Enabled
INFO - 2022-07-05 05:35:50 --> Utf8 Class Initialized
INFO - 2022-07-05 05:35:50 --> URI Class Initialized
INFO - 2022-07-05 05:35:50 --> Router Class Initialized
INFO - 2022-07-05 05:35:50 --> Output Class Initialized
INFO - 2022-07-05 05:35:50 --> Security Class Initialized
DEBUG - 2022-07-05 05:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 05:35:50 --> Input Class Initialized
INFO - 2022-07-05 05:35:50 --> Language Class Initialized
INFO - 2022-07-05 05:35:50 --> Loader Class Initialized
INFO - 2022-07-05 05:35:50 --> Helper loaded: url_helper
INFO - 2022-07-05 05:35:50 --> Helper loaded: file_helper
INFO - 2022-07-05 05:35:50 --> Database Driver Class Initialized
INFO - 2022-07-05 05:35:50 --> Email Class Initialized
DEBUG - 2022-07-05 05:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 05:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 05:35:50 --> Controller Class Initialized
INFO - 2022-07-05 05:35:50 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 05:35:50 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 05:35:50 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 05:35:50 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 05:35:50 --> Final output sent to browser
DEBUG - 2022-07-05 05:35:50 --> Total execution time: 0.1407
INFO - 2022-07-05 05:36:05 --> Config Class Initialized
INFO - 2022-07-05 05:36:05 --> Hooks Class Initialized
DEBUG - 2022-07-05 05:36:05 --> UTF-8 Support Enabled
INFO - 2022-07-05 05:36:05 --> Utf8 Class Initialized
INFO - 2022-07-05 05:36:05 --> URI Class Initialized
INFO - 2022-07-05 05:36:05 --> Router Class Initialized
INFO - 2022-07-05 05:36:05 --> Output Class Initialized
INFO - 2022-07-05 05:36:05 --> Security Class Initialized
DEBUG - 2022-07-05 05:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 05:36:05 --> Input Class Initialized
INFO - 2022-07-05 05:36:05 --> Language Class Initialized
INFO - 2022-07-05 05:36:05 --> Loader Class Initialized
INFO - 2022-07-05 05:36:05 --> Helper loaded: url_helper
INFO - 2022-07-05 05:36:05 --> Helper loaded: file_helper
INFO - 2022-07-05 05:36:05 --> Database Driver Class Initialized
INFO - 2022-07-05 05:36:05 --> Email Class Initialized
DEBUG - 2022-07-05 05:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 05:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 05:36:05 --> Controller Class Initialized
INFO - 2022-07-05 05:36:05 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 05:36:05 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 05:36:05 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 05:36:05 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 05:36:05 --> Final output sent to browser
DEBUG - 2022-07-05 05:36:05 --> Total execution time: 0.0664
INFO - 2022-07-05 05:36:21 --> Config Class Initialized
INFO - 2022-07-05 05:36:21 --> Hooks Class Initialized
DEBUG - 2022-07-05 05:36:21 --> UTF-8 Support Enabled
INFO - 2022-07-05 05:36:21 --> Utf8 Class Initialized
INFO - 2022-07-05 05:36:21 --> URI Class Initialized
INFO - 2022-07-05 05:36:21 --> Router Class Initialized
INFO - 2022-07-05 05:36:21 --> Output Class Initialized
INFO - 2022-07-05 05:36:21 --> Security Class Initialized
DEBUG - 2022-07-05 05:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 05:36:21 --> Input Class Initialized
INFO - 2022-07-05 05:36:21 --> Language Class Initialized
INFO - 2022-07-05 05:36:21 --> Loader Class Initialized
INFO - 2022-07-05 05:36:21 --> Helper loaded: url_helper
INFO - 2022-07-05 05:36:21 --> Helper loaded: file_helper
INFO - 2022-07-05 05:36:21 --> Database Driver Class Initialized
INFO - 2022-07-05 05:36:21 --> Email Class Initialized
DEBUG - 2022-07-05 05:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 05:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 05:36:21 --> Controller Class Initialized
INFO - 2022-07-05 05:36:21 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 05:36:21 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 05:36:21 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 05:36:21 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 05:36:21 --> Final output sent to browser
DEBUG - 2022-07-05 05:36:21 --> Total execution time: 0.0243
INFO - 2022-07-05 05:36:43 --> Config Class Initialized
INFO - 2022-07-05 05:36:43 --> Hooks Class Initialized
DEBUG - 2022-07-05 05:36:43 --> UTF-8 Support Enabled
INFO - 2022-07-05 05:36:43 --> Utf8 Class Initialized
INFO - 2022-07-05 05:36:43 --> URI Class Initialized
INFO - 2022-07-05 05:36:43 --> Router Class Initialized
INFO - 2022-07-05 05:36:43 --> Output Class Initialized
INFO - 2022-07-05 05:36:43 --> Security Class Initialized
DEBUG - 2022-07-05 05:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 05:36:43 --> Input Class Initialized
INFO - 2022-07-05 05:36:43 --> Language Class Initialized
INFO - 2022-07-05 05:36:43 --> Loader Class Initialized
INFO - 2022-07-05 05:36:43 --> Helper loaded: url_helper
INFO - 2022-07-05 05:36:43 --> Helper loaded: file_helper
INFO - 2022-07-05 05:36:43 --> Database Driver Class Initialized
INFO - 2022-07-05 05:36:43 --> Email Class Initialized
DEBUG - 2022-07-05 05:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 05:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 05:36:43 --> Controller Class Initialized
INFO - 2022-07-05 05:36:43 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 05:36:43 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 05:36:43 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 05:36:43 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 05:36:43 --> Final output sent to browser
DEBUG - 2022-07-05 05:36:43 --> Total execution time: 0.1573
INFO - 2022-07-05 05:37:01 --> Config Class Initialized
INFO - 2022-07-05 05:37:01 --> Hooks Class Initialized
DEBUG - 2022-07-05 05:37:01 --> UTF-8 Support Enabled
INFO - 2022-07-05 05:37:01 --> Utf8 Class Initialized
INFO - 2022-07-05 05:37:01 --> URI Class Initialized
INFO - 2022-07-05 05:37:01 --> Router Class Initialized
INFO - 2022-07-05 05:37:01 --> Output Class Initialized
INFO - 2022-07-05 05:37:01 --> Security Class Initialized
DEBUG - 2022-07-05 05:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 05:37:01 --> Input Class Initialized
INFO - 2022-07-05 05:37:01 --> Language Class Initialized
INFO - 2022-07-05 05:37:01 --> Loader Class Initialized
INFO - 2022-07-05 05:37:01 --> Helper loaded: url_helper
INFO - 2022-07-05 05:37:01 --> Helper loaded: file_helper
INFO - 2022-07-05 05:37:01 --> Database Driver Class Initialized
INFO - 2022-07-05 05:37:01 --> Email Class Initialized
DEBUG - 2022-07-05 05:37:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 05:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 05:37:01 --> Controller Class Initialized
INFO - 2022-07-05 05:37:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 05:37:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 05:37:01 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 05:37:01 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 05:37:01 --> Final output sent to browser
DEBUG - 2022-07-05 05:37:01 --> Total execution time: 0.0506
INFO - 2022-07-05 05:37:08 --> Config Class Initialized
INFO - 2022-07-05 05:37:08 --> Hooks Class Initialized
DEBUG - 2022-07-05 05:37:08 --> UTF-8 Support Enabled
INFO - 2022-07-05 05:37:08 --> Utf8 Class Initialized
INFO - 2022-07-05 05:37:08 --> URI Class Initialized
INFO - 2022-07-05 05:37:08 --> Router Class Initialized
INFO - 2022-07-05 05:37:08 --> Output Class Initialized
INFO - 2022-07-05 05:37:08 --> Security Class Initialized
DEBUG - 2022-07-05 05:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 05:37:08 --> Input Class Initialized
INFO - 2022-07-05 05:37:08 --> Language Class Initialized
INFO - 2022-07-05 05:37:08 --> Loader Class Initialized
INFO - 2022-07-05 05:37:08 --> Helper loaded: url_helper
INFO - 2022-07-05 05:37:08 --> Helper loaded: file_helper
INFO - 2022-07-05 05:37:08 --> Database Driver Class Initialized
INFO - 2022-07-05 05:37:08 --> Email Class Initialized
DEBUG - 2022-07-05 05:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 05:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 05:37:08 --> Controller Class Initialized
INFO - 2022-07-05 05:37:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 05:37:08 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 05:37:08 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 05:37:08 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 05:37:08 --> Final output sent to browser
DEBUG - 2022-07-05 05:37:08 --> Total execution time: 0.1484
INFO - 2022-07-05 05:37:30 --> Config Class Initialized
INFO - 2022-07-05 05:37:30 --> Hooks Class Initialized
DEBUG - 2022-07-05 05:37:30 --> UTF-8 Support Enabled
INFO - 2022-07-05 05:37:30 --> Utf8 Class Initialized
INFO - 2022-07-05 05:37:30 --> URI Class Initialized
INFO - 2022-07-05 05:37:30 --> Router Class Initialized
INFO - 2022-07-05 05:37:30 --> Output Class Initialized
INFO - 2022-07-05 05:37:30 --> Security Class Initialized
DEBUG - 2022-07-05 05:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 05:37:30 --> Input Class Initialized
INFO - 2022-07-05 05:37:30 --> Language Class Initialized
INFO - 2022-07-05 05:37:30 --> Loader Class Initialized
INFO - 2022-07-05 05:37:30 --> Helper loaded: url_helper
INFO - 2022-07-05 05:37:30 --> Helper loaded: file_helper
INFO - 2022-07-05 05:37:30 --> Database Driver Class Initialized
INFO - 2022-07-05 05:37:30 --> Email Class Initialized
DEBUG - 2022-07-05 05:37:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 05:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 05:37:30 --> Controller Class Initialized
INFO - 2022-07-05 05:37:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 05:37:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 05:37:30 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 05:37:30 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 05:37:30 --> Final output sent to browser
DEBUG - 2022-07-05 05:37:30 --> Total execution time: 0.0254
INFO - 2022-07-05 05:38:01 --> Config Class Initialized
INFO - 2022-07-05 05:38:01 --> Hooks Class Initialized
DEBUG - 2022-07-05 05:38:01 --> UTF-8 Support Enabled
INFO - 2022-07-05 05:38:01 --> Utf8 Class Initialized
INFO - 2022-07-05 05:38:01 --> URI Class Initialized
INFO - 2022-07-05 05:38:01 --> Router Class Initialized
INFO - 2022-07-05 05:38:01 --> Output Class Initialized
INFO - 2022-07-05 05:38:01 --> Security Class Initialized
DEBUG - 2022-07-05 05:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 05:38:01 --> Input Class Initialized
INFO - 2022-07-05 05:38:01 --> Language Class Initialized
INFO - 2022-07-05 05:38:01 --> Loader Class Initialized
INFO - 2022-07-05 05:38:01 --> Helper loaded: url_helper
INFO - 2022-07-05 05:38:01 --> Helper loaded: file_helper
INFO - 2022-07-05 05:38:01 --> Database Driver Class Initialized
INFO - 2022-07-05 05:38:01 --> Email Class Initialized
DEBUG - 2022-07-05 05:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 05:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 05:38:01 --> Controller Class Initialized
INFO - 2022-07-05 05:38:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 05:38:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 05:38:01 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 05:38:01 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 05:38:01 --> Final output sent to browser
DEBUG - 2022-07-05 05:38:01 --> Total execution time: 0.1318
INFO - 2022-07-05 05:38:20 --> Config Class Initialized
INFO - 2022-07-05 05:38:20 --> Hooks Class Initialized
DEBUG - 2022-07-05 05:38:20 --> UTF-8 Support Enabled
INFO - 2022-07-05 05:38:20 --> Utf8 Class Initialized
INFO - 2022-07-05 05:38:20 --> URI Class Initialized
INFO - 2022-07-05 05:38:20 --> Router Class Initialized
INFO - 2022-07-05 05:38:20 --> Output Class Initialized
INFO - 2022-07-05 05:38:20 --> Security Class Initialized
DEBUG - 2022-07-05 05:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 05:38:20 --> Input Class Initialized
INFO - 2022-07-05 05:38:20 --> Language Class Initialized
INFO - 2022-07-05 05:38:20 --> Loader Class Initialized
INFO - 2022-07-05 05:38:20 --> Helper loaded: url_helper
INFO - 2022-07-05 05:38:20 --> Helper loaded: file_helper
INFO - 2022-07-05 05:38:20 --> Database Driver Class Initialized
INFO - 2022-07-05 05:38:20 --> Email Class Initialized
DEBUG - 2022-07-05 05:38:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 05:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 05:38:20 --> Controller Class Initialized
INFO - 2022-07-05 05:38:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 05:38:20 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 05:38:20 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 05:38:20 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 05:38:20 --> Final output sent to browser
DEBUG - 2022-07-05 05:38:20 --> Total execution time: 0.1319
INFO - 2022-07-05 05:39:20 --> Config Class Initialized
INFO - 2022-07-05 05:39:20 --> Hooks Class Initialized
DEBUG - 2022-07-05 05:39:20 --> UTF-8 Support Enabled
INFO - 2022-07-05 05:39:20 --> Utf8 Class Initialized
INFO - 2022-07-05 05:39:20 --> URI Class Initialized
INFO - 2022-07-05 05:39:20 --> Router Class Initialized
INFO - 2022-07-05 05:39:20 --> Output Class Initialized
INFO - 2022-07-05 05:39:20 --> Security Class Initialized
DEBUG - 2022-07-05 05:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 05:39:20 --> Input Class Initialized
INFO - 2022-07-05 05:39:20 --> Language Class Initialized
INFO - 2022-07-05 05:39:20 --> Loader Class Initialized
INFO - 2022-07-05 05:39:20 --> Helper loaded: url_helper
INFO - 2022-07-05 05:39:20 --> Helper loaded: file_helper
INFO - 2022-07-05 05:39:20 --> Database Driver Class Initialized
INFO - 2022-07-05 05:39:20 --> Email Class Initialized
DEBUG - 2022-07-05 05:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 05:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 05:39:20 --> Controller Class Initialized
INFO - 2022-07-05 05:39:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 05:39:20 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 05:39:20 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 05:39:20 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 05:39:20 --> Final output sent to browser
DEBUG - 2022-07-05 05:39:20 --> Total execution time: 0.0244
INFO - 2022-07-05 06:29:12 --> Config Class Initialized
INFO - 2022-07-05 06:29:12 --> Hooks Class Initialized
DEBUG - 2022-07-05 06:29:12 --> UTF-8 Support Enabled
INFO - 2022-07-05 06:29:12 --> Utf8 Class Initialized
INFO - 2022-07-05 06:29:12 --> URI Class Initialized
INFO - 2022-07-05 06:29:12 --> Router Class Initialized
INFO - 2022-07-05 06:29:12 --> Output Class Initialized
INFO - 2022-07-05 06:29:12 --> Security Class Initialized
DEBUG - 2022-07-05 06:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 06:29:12 --> Input Class Initialized
INFO - 2022-07-05 06:29:12 --> Language Class Initialized
INFO - 2022-07-05 06:29:12 --> Loader Class Initialized
INFO - 2022-07-05 06:29:12 --> Helper loaded: url_helper
INFO - 2022-07-05 06:29:12 --> Helper loaded: file_helper
INFO - 2022-07-05 06:29:12 --> Database Driver Class Initialized
INFO - 2022-07-05 06:29:12 --> Email Class Initialized
DEBUG - 2022-07-05 06:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 06:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 06:29:12 --> Controller Class Initialized
INFO - 2022-07-05 06:29:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 06:29:12 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 06:29:12 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 06:29:12 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 06:29:12 --> Final output sent to browser
DEBUG - 2022-07-05 06:29:12 --> Total execution time: 0.3636
INFO - 2022-07-05 06:29:22 --> Config Class Initialized
INFO - 2022-07-05 06:29:22 --> Hooks Class Initialized
DEBUG - 2022-07-05 06:29:22 --> UTF-8 Support Enabled
INFO - 2022-07-05 06:29:22 --> Utf8 Class Initialized
INFO - 2022-07-05 06:29:22 --> URI Class Initialized
INFO - 2022-07-05 06:29:22 --> Router Class Initialized
INFO - 2022-07-05 06:29:22 --> Output Class Initialized
INFO - 2022-07-05 06:29:22 --> Security Class Initialized
DEBUG - 2022-07-05 06:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 06:29:22 --> Input Class Initialized
INFO - 2022-07-05 06:29:22 --> Language Class Initialized
INFO - 2022-07-05 06:29:22 --> Loader Class Initialized
INFO - 2022-07-05 06:29:22 --> Helper loaded: url_helper
INFO - 2022-07-05 06:29:22 --> Helper loaded: file_helper
INFO - 2022-07-05 06:29:22 --> Database Driver Class Initialized
INFO - 2022-07-05 06:29:22 --> Email Class Initialized
DEBUG - 2022-07-05 06:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 06:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 06:29:22 --> Controller Class Initialized
INFO - 2022-07-05 06:29:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 06:29:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 06:29:22 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 06:29:22 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 06:29:22 --> Final output sent to browser
DEBUG - 2022-07-05 06:29:22 --> Total execution time: 0.0255
INFO - 2022-07-05 06:29:22 --> Config Class Initialized
INFO - 2022-07-05 06:29:22 --> Hooks Class Initialized
DEBUG - 2022-07-05 06:29:22 --> UTF-8 Support Enabled
INFO - 2022-07-05 06:29:22 --> Utf8 Class Initialized
INFO - 2022-07-05 06:29:22 --> URI Class Initialized
INFO - 2022-07-05 06:29:22 --> Router Class Initialized
INFO - 2022-07-05 06:29:22 --> Output Class Initialized
INFO - 2022-07-05 06:29:22 --> Security Class Initialized
DEBUG - 2022-07-05 06:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 06:29:22 --> Input Class Initialized
INFO - 2022-07-05 06:29:22 --> Language Class Initialized
INFO - 2022-07-05 06:29:22 --> Loader Class Initialized
INFO - 2022-07-05 06:29:22 --> Helper loaded: url_helper
INFO - 2022-07-05 06:29:22 --> Helper loaded: file_helper
INFO - 2022-07-05 06:29:22 --> Database Driver Class Initialized
INFO - 2022-07-05 06:29:22 --> Email Class Initialized
DEBUG - 2022-07-05 06:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 06:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 06:29:22 --> Controller Class Initialized
INFO - 2022-07-05 06:29:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 06:29:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 06:29:22 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 06:29:22 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 06:29:22 --> Final output sent to browser
DEBUG - 2022-07-05 06:29:22 --> Total execution time: 0.0411
INFO - 2022-07-05 06:29:41 --> Config Class Initialized
INFO - 2022-07-05 06:29:41 --> Hooks Class Initialized
DEBUG - 2022-07-05 06:29:41 --> UTF-8 Support Enabled
INFO - 2022-07-05 06:29:41 --> Utf8 Class Initialized
INFO - 2022-07-05 06:29:41 --> URI Class Initialized
INFO - 2022-07-05 06:29:41 --> Router Class Initialized
INFO - 2022-07-05 06:29:41 --> Output Class Initialized
INFO - 2022-07-05 06:29:41 --> Security Class Initialized
DEBUG - 2022-07-05 06:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 06:29:41 --> Input Class Initialized
INFO - 2022-07-05 06:29:41 --> Language Class Initialized
INFO - 2022-07-05 06:29:41 --> Loader Class Initialized
INFO - 2022-07-05 06:29:41 --> Helper loaded: url_helper
INFO - 2022-07-05 06:29:41 --> Helper loaded: file_helper
INFO - 2022-07-05 06:29:41 --> Database Driver Class Initialized
INFO - 2022-07-05 06:29:41 --> Email Class Initialized
DEBUG - 2022-07-05 06:29:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 06:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 06:29:41 --> Controller Class Initialized
INFO - 2022-07-05 06:29:41 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 06:29:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-05 06:29:41 --> Severity: Notice --> Undefined variable: total C:\wamp64\www\qr\application\views\doc_screen\doctor.php 359
INFO - 2022-07-05 06:29:41 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-07-05 06:29:41 --> Final output sent to browser
DEBUG - 2022-07-05 06:29:41 --> Total execution time: 0.3171
INFO - 2022-07-05 06:31:43 --> Config Class Initialized
INFO - 2022-07-05 06:31:43 --> Hooks Class Initialized
DEBUG - 2022-07-05 06:31:43 --> UTF-8 Support Enabled
INFO - 2022-07-05 06:31:43 --> Utf8 Class Initialized
INFO - 2022-07-05 06:31:43 --> URI Class Initialized
INFO - 2022-07-05 06:31:43 --> Router Class Initialized
INFO - 2022-07-05 06:31:43 --> Output Class Initialized
INFO - 2022-07-05 06:31:43 --> Security Class Initialized
DEBUG - 2022-07-05 06:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 06:31:43 --> Input Class Initialized
INFO - 2022-07-05 06:31:43 --> Language Class Initialized
INFO - 2022-07-05 06:31:43 --> Loader Class Initialized
INFO - 2022-07-05 06:31:43 --> Helper loaded: url_helper
INFO - 2022-07-05 06:31:43 --> Helper loaded: file_helper
INFO - 2022-07-05 06:31:43 --> Database Driver Class Initialized
INFO - 2022-07-05 06:31:43 --> Email Class Initialized
DEBUG - 2022-07-05 06:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 06:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 06:31:43 --> Controller Class Initialized
INFO - 2022-07-05 06:31:43 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 06:31:43 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 06:31:43 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 06:31:43 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 06:31:43 --> Final output sent to browser
DEBUG - 2022-07-05 06:31:43 --> Total execution time: 0.0598
INFO - 2022-07-05 06:34:10 --> Config Class Initialized
INFO - 2022-07-05 06:34:10 --> Hooks Class Initialized
DEBUG - 2022-07-05 06:34:10 --> UTF-8 Support Enabled
INFO - 2022-07-05 06:34:10 --> Utf8 Class Initialized
INFO - 2022-07-05 06:34:10 --> URI Class Initialized
INFO - 2022-07-05 06:34:10 --> Router Class Initialized
INFO - 2022-07-05 06:34:10 --> Output Class Initialized
INFO - 2022-07-05 06:34:10 --> Security Class Initialized
DEBUG - 2022-07-05 06:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 06:34:10 --> Input Class Initialized
INFO - 2022-07-05 06:34:10 --> Language Class Initialized
INFO - 2022-07-05 06:34:10 --> Loader Class Initialized
INFO - 2022-07-05 06:34:10 --> Helper loaded: url_helper
INFO - 2022-07-05 06:34:10 --> Helper loaded: file_helper
INFO - 2022-07-05 06:34:10 --> Database Driver Class Initialized
INFO - 2022-07-05 06:34:10 --> Email Class Initialized
DEBUG - 2022-07-05 06:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 06:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 06:34:10 --> Controller Class Initialized
INFO - 2022-07-05 06:34:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 06:34:10 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 06:34:10 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 06:34:10 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 06:34:10 --> Final output sent to browser
DEBUG - 2022-07-05 06:34:10 --> Total execution time: 0.1701
INFO - 2022-07-05 06:40:09 --> Config Class Initialized
INFO - 2022-07-05 06:40:09 --> Hooks Class Initialized
DEBUG - 2022-07-05 06:40:09 --> UTF-8 Support Enabled
INFO - 2022-07-05 06:40:09 --> Utf8 Class Initialized
INFO - 2022-07-05 06:40:09 --> URI Class Initialized
INFO - 2022-07-05 06:40:09 --> Router Class Initialized
INFO - 2022-07-05 06:40:09 --> Output Class Initialized
INFO - 2022-07-05 06:40:09 --> Security Class Initialized
DEBUG - 2022-07-05 06:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 06:40:09 --> Input Class Initialized
INFO - 2022-07-05 06:40:09 --> Language Class Initialized
INFO - 2022-07-05 06:40:09 --> Loader Class Initialized
INFO - 2022-07-05 06:40:09 --> Helper loaded: url_helper
INFO - 2022-07-05 06:40:09 --> Helper loaded: file_helper
INFO - 2022-07-05 06:40:09 --> Database Driver Class Initialized
INFO - 2022-07-05 06:40:09 --> Email Class Initialized
DEBUG - 2022-07-05 06:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 06:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 06:40:09 --> Controller Class Initialized
INFO - 2022-07-05 06:40:09 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 06:40:09 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 06:40:09 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 06:40:09 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 06:40:09 --> Final output sent to browser
DEBUG - 2022-07-05 06:40:09 --> Total execution time: 0.1369
INFO - 2022-07-05 06:57:11 --> Config Class Initialized
INFO - 2022-07-05 06:57:11 --> Hooks Class Initialized
DEBUG - 2022-07-05 06:57:11 --> UTF-8 Support Enabled
INFO - 2022-07-05 06:57:11 --> Utf8 Class Initialized
INFO - 2022-07-05 06:57:11 --> URI Class Initialized
INFO - 2022-07-05 06:57:11 --> Router Class Initialized
INFO - 2022-07-05 06:57:11 --> Output Class Initialized
INFO - 2022-07-05 06:57:11 --> Security Class Initialized
DEBUG - 2022-07-05 06:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 06:57:11 --> Input Class Initialized
INFO - 2022-07-05 06:57:11 --> Language Class Initialized
INFO - 2022-07-05 06:57:11 --> Loader Class Initialized
INFO - 2022-07-05 06:57:11 --> Helper loaded: url_helper
INFO - 2022-07-05 06:57:11 --> Helper loaded: file_helper
INFO - 2022-07-05 06:57:11 --> Database Driver Class Initialized
INFO - 2022-07-05 06:57:11 --> Email Class Initialized
DEBUG - 2022-07-05 06:57:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 06:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 06:57:11 --> Controller Class Initialized
INFO - 2022-07-05 06:57:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 06:57:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 06:57:11 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 06:57:11 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 06:57:11 --> Final output sent to browser
DEBUG - 2022-07-05 06:57:11 --> Total execution time: 0.1310
INFO - 2022-07-05 06:57:15 --> Config Class Initialized
INFO - 2022-07-05 06:57:15 --> Hooks Class Initialized
DEBUG - 2022-07-05 06:57:15 --> UTF-8 Support Enabled
INFO - 2022-07-05 06:57:15 --> Utf8 Class Initialized
INFO - 2022-07-05 06:57:15 --> URI Class Initialized
INFO - 2022-07-05 06:57:15 --> Router Class Initialized
INFO - 2022-07-05 06:57:15 --> Output Class Initialized
INFO - 2022-07-05 06:57:15 --> Security Class Initialized
DEBUG - 2022-07-05 06:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 06:57:15 --> Input Class Initialized
INFO - 2022-07-05 06:57:15 --> Language Class Initialized
INFO - 2022-07-05 06:57:15 --> Loader Class Initialized
INFO - 2022-07-05 06:57:15 --> Helper loaded: url_helper
INFO - 2022-07-05 06:57:15 --> Helper loaded: file_helper
INFO - 2022-07-05 06:57:15 --> Database Driver Class Initialized
INFO - 2022-07-05 06:57:15 --> Email Class Initialized
DEBUG - 2022-07-05 06:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 06:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 06:57:15 --> Controller Class Initialized
INFO - 2022-07-05 06:57:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 06:57:15 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 06:57:15 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 06:57:15 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 06:57:15 --> Final output sent to browser
DEBUG - 2022-07-05 06:57:15 --> Total execution time: 0.0679
INFO - 2022-07-05 06:57:23 --> Config Class Initialized
INFO - 2022-07-05 06:57:23 --> Hooks Class Initialized
DEBUG - 2022-07-05 06:57:23 --> UTF-8 Support Enabled
INFO - 2022-07-05 06:57:23 --> Utf8 Class Initialized
INFO - 2022-07-05 06:57:23 --> URI Class Initialized
INFO - 2022-07-05 06:57:23 --> Router Class Initialized
INFO - 2022-07-05 06:57:23 --> Output Class Initialized
INFO - 2022-07-05 06:57:23 --> Security Class Initialized
DEBUG - 2022-07-05 06:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 06:57:23 --> Input Class Initialized
INFO - 2022-07-05 06:57:23 --> Language Class Initialized
INFO - 2022-07-05 06:57:23 --> Loader Class Initialized
INFO - 2022-07-05 06:57:23 --> Helper loaded: url_helper
INFO - 2022-07-05 06:57:23 --> Helper loaded: file_helper
INFO - 2022-07-05 06:57:23 --> Database Driver Class Initialized
INFO - 2022-07-05 06:57:23 --> Email Class Initialized
DEBUG - 2022-07-05 06:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 06:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 06:57:23 --> Controller Class Initialized
INFO - 2022-07-05 06:57:23 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 06:57:23 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 06:57:23 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 06:57:23 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 06:57:23 --> Final output sent to browser
DEBUG - 2022-07-05 06:57:23 --> Total execution time: 0.0380
INFO - 2022-07-05 06:57:35 --> Config Class Initialized
INFO - 2022-07-05 06:57:35 --> Hooks Class Initialized
DEBUG - 2022-07-05 06:57:35 --> UTF-8 Support Enabled
INFO - 2022-07-05 06:57:35 --> Utf8 Class Initialized
INFO - 2022-07-05 06:57:35 --> URI Class Initialized
INFO - 2022-07-05 06:57:35 --> Router Class Initialized
INFO - 2022-07-05 06:57:35 --> Output Class Initialized
INFO - 2022-07-05 06:57:35 --> Security Class Initialized
DEBUG - 2022-07-05 06:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 06:57:35 --> Input Class Initialized
INFO - 2022-07-05 06:57:35 --> Language Class Initialized
INFO - 2022-07-05 06:57:35 --> Loader Class Initialized
INFO - 2022-07-05 06:57:35 --> Helper loaded: url_helper
INFO - 2022-07-05 06:57:35 --> Helper loaded: file_helper
INFO - 2022-07-05 06:57:35 --> Database Driver Class Initialized
INFO - 2022-07-05 06:57:35 --> Email Class Initialized
DEBUG - 2022-07-05 06:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 06:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 06:57:35 --> Controller Class Initialized
INFO - 2022-07-05 06:57:35 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 06:57:35 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 06:57:35 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 06:57:35 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 06:57:35 --> Final output sent to browser
DEBUG - 2022-07-05 06:57:35 --> Total execution time: 0.1439
INFO - 2022-07-05 06:58:39 --> Config Class Initialized
INFO - 2022-07-05 06:58:39 --> Hooks Class Initialized
DEBUG - 2022-07-05 06:58:39 --> UTF-8 Support Enabled
INFO - 2022-07-05 06:58:39 --> Utf8 Class Initialized
INFO - 2022-07-05 06:58:39 --> URI Class Initialized
INFO - 2022-07-05 06:58:39 --> Router Class Initialized
INFO - 2022-07-05 06:58:39 --> Output Class Initialized
INFO - 2022-07-05 06:58:39 --> Security Class Initialized
DEBUG - 2022-07-05 06:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 06:58:39 --> Input Class Initialized
INFO - 2022-07-05 06:58:39 --> Language Class Initialized
INFO - 2022-07-05 06:58:39 --> Loader Class Initialized
INFO - 2022-07-05 06:58:39 --> Helper loaded: url_helper
INFO - 2022-07-05 06:58:39 --> Helper loaded: file_helper
INFO - 2022-07-05 06:58:40 --> Database Driver Class Initialized
INFO - 2022-07-05 06:58:40 --> Email Class Initialized
DEBUG - 2022-07-05 06:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 06:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 06:58:40 --> Controller Class Initialized
INFO - 2022-07-05 06:58:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 06:58:40 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 06:58:40 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 06:58:40 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 06:58:40 --> Final output sent to browser
DEBUG - 2022-07-05 06:58:40 --> Total execution time: 0.0506
INFO - 2022-07-05 06:58:43 --> Config Class Initialized
INFO - 2022-07-05 06:58:43 --> Hooks Class Initialized
DEBUG - 2022-07-05 06:58:43 --> UTF-8 Support Enabled
INFO - 2022-07-05 06:58:43 --> Utf8 Class Initialized
INFO - 2022-07-05 06:58:43 --> URI Class Initialized
INFO - 2022-07-05 06:58:43 --> Router Class Initialized
INFO - 2022-07-05 06:58:43 --> Output Class Initialized
INFO - 2022-07-05 06:58:43 --> Security Class Initialized
DEBUG - 2022-07-05 06:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 06:58:43 --> Input Class Initialized
INFO - 2022-07-05 06:58:43 --> Language Class Initialized
INFO - 2022-07-05 06:58:43 --> Loader Class Initialized
INFO - 2022-07-05 06:58:43 --> Helper loaded: url_helper
INFO - 2022-07-05 06:58:43 --> Helper loaded: file_helper
INFO - 2022-07-05 06:58:43 --> Database Driver Class Initialized
INFO - 2022-07-05 06:58:43 --> Email Class Initialized
DEBUG - 2022-07-05 06:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 06:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 06:58:43 --> Controller Class Initialized
INFO - 2022-07-05 06:58:43 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 06:58:43 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 06:58:43 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 06:58:43 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 06:58:43 --> Final output sent to browser
DEBUG - 2022-07-05 06:58:43 --> Total execution time: 0.1455
INFO - 2022-07-05 07:02:15 --> Config Class Initialized
INFO - 2022-07-05 07:02:15 --> Hooks Class Initialized
DEBUG - 2022-07-05 07:02:15 --> UTF-8 Support Enabled
INFO - 2022-07-05 07:02:15 --> Utf8 Class Initialized
INFO - 2022-07-05 07:02:15 --> URI Class Initialized
INFO - 2022-07-05 07:02:15 --> Router Class Initialized
INFO - 2022-07-05 07:02:15 --> Output Class Initialized
INFO - 2022-07-05 07:02:15 --> Security Class Initialized
DEBUG - 2022-07-05 07:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 07:02:15 --> Input Class Initialized
INFO - 2022-07-05 07:02:15 --> Language Class Initialized
INFO - 2022-07-05 07:02:15 --> Loader Class Initialized
INFO - 2022-07-05 07:02:15 --> Helper loaded: url_helper
INFO - 2022-07-05 07:02:15 --> Helper loaded: file_helper
INFO - 2022-07-05 07:02:15 --> Database Driver Class Initialized
INFO - 2022-07-05 07:02:15 --> Email Class Initialized
DEBUG - 2022-07-05 07:02:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 07:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 07:02:15 --> Controller Class Initialized
INFO - 2022-07-05 07:02:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 07:02:15 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 07:02:15 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 07:02:15 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 07:02:15 --> Final output sent to browser
DEBUG - 2022-07-05 07:02:15 --> Total execution time: 0.0334
INFO - 2022-07-05 07:02:16 --> Config Class Initialized
INFO - 2022-07-05 07:02:16 --> Hooks Class Initialized
DEBUG - 2022-07-05 07:02:16 --> UTF-8 Support Enabled
INFO - 2022-07-05 07:02:16 --> Utf8 Class Initialized
INFO - 2022-07-05 07:02:16 --> URI Class Initialized
INFO - 2022-07-05 07:02:16 --> Router Class Initialized
INFO - 2022-07-05 07:02:16 --> Output Class Initialized
INFO - 2022-07-05 07:02:16 --> Security Class Initialized
DEBUG - 2022-07-05 07:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 07:02:16 --> Input Class Initialized
INFO - 2022-07-05 07:02:16 --> Language Class Initialized
INFO - 2022-07-05 07:02:16 --> Loader Class Initialized
INFO - 2022-07-05 07:02:16 --> Helper loaded: url_helper
INFO - 2022-07-05 07:02:16 --> Helper loaded: file_helper
INFO - 2022-07-05 07:02:16 --> Database Driver Class Initialized
INFO - 2022-07-05 07:02:16 --> Email Class Initialized
DEBUG - 2022-07-05 07:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 07:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 07:02:16 --> Controller Class Initialized
INFO - 2022-07-05 07:02:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 07:02:16 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 07:02:16 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 07:02:16 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 07:02:16 --> Final output sent to browser
DEBUG - 2022-07-05 07:02:16 --> Total execution time: 0.1170
INFO - 2022-07-05 07:02:36 --> Config Class Initialized
INFO - 2022-07-05 07:02:36 --> Hooks Class Initialized
DEBUG - 2022-07-05 07:02:36 --> UTF-8 Support Enabled
INFO - 2022-07-05 07:02:36 --> Utf8 Class Initialized
INFO - 2022-07-05 07:02:36 --> URI Class Initialized
INFO - 2022-07-05 07:02:36 --> Router Class Initialized
INFO - 2022-07-05 07:02:36 --> Output Class Initialized
INFO - 2022-07-05 07:02:36 --> Security Class Initialized
DEBUG - 2022-07-05 07:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 07:02:36 --> Input Class Initialized
INFO - 2022-07-05 07:02:36 --> Language Class Initialized
INFO - 2022-07-05 07:02:36 --> Loader Class Initialized
INFO - 2022-07-05 07:02:36 --> Helper loaded: url_helper
INFO - 2022-07-05 07:02:36 --> Helper loaded: file_helper
INFO - 2022-07-05 07:02:36 --> Database Driver Class Initialized
INFO - 2022-07-05 07:02:36 --> Email Class Initialized
DEBUG - 2022-07-05 07:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 07:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 07:02:36 --> Controller Class Initialized
INFO - 2022-07-05 07:02:36 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 07:02:36 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 07:02:36 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 07:02:36 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 07:02:36 --> Final output sent to browser
DEBUG - 2022-07-05 07:02:36 --> Total execution time: 0.0306
INFO - 2022-07-05 07:02:37 --> Config Class Initialized
INFO - 2022-07-05 07:02:37 --> Hooks Class Initialized
DEBUG - 2022-07-05 07:02:37 --> UTF-8 Support Enabled
INFO - 2022-07-05 07:02:37 --> Utf8 Class Initialized
INFO - 2022-07-05 07:02:37 --> URI Class Initialized
INFO - 2022-07-05 07:02:37 --> Router Class Initialized
INFO - 2022-07-05 07:02:37 --> Output Class Initialized
INFO - 2022-07-05 07:02:37 --> Security Class Initialized
DEBUG - 2022-07-05 07:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 07:02:37 --> Input Class Initialized
INFO - 2022-07-05 07:02:37 --> Language Class Initialized
INFO - 2022-07-05 07:02:37 --> Loader Class Initialized
INFO - 2022-07-05 07:02:37 --> Helper loaded: url_helper
INFO - 2022-07-05 07:02:37 --> Helper loaded: file_helper
INFO - 2022-07-05 07:02:37 --> Database Driver Class Initialized
INFO - 2022-07-05 07:02:37 --> Email Class Initialized
DEBUG - 2022-07-05 07:02:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 07:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 07:02:37 --> Controller Class Initialized
INFO - 2022-07-05 07:02:37 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 07:02:37 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 07:02:37 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 07:02:37 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 07:02:37 --> Final output sent to browser
DEBUG - 2022-07-05 07:02:37 --> Total execution time: 0.0289
INFO - 2022-07-05 07:02:38 --> Config Class Initialized
INFO - 2022-07-05 07:02:38 --> Hooks Class Initialized
DEBUG - 2022-07-05 07:02:38 --> UTF-8 Support Enabled
INFO - 2022-07-05 07:02:38 --> Utf8 Class Initialized
INFO - 2022-07-05 07:02:38 --> URI Class Initialized
INFO - 2022-07-05 07:02:38 --> Router Class Initialized
INFO - 2022-07-05 07:02:38 --> Output Class Initialized
INFO - 2022-07-05 07:02:38 --> Security Class Initialized
DEBUG - 2022-07-05 07:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 07:02:38 --> Input Class Initialized
INFO - 2022-07-05 07:02:38 --> Language Class Initialized
INFO - 2022-07-05 07:02:38 --> Loader Class Initialized
INFO - 2022-07-05 07:02:38 --> Helper loaded: url_helper
INFO - 2022-07-05 07:02:38 --> Helper loaded: file_helper
INFO - 2022-07-05 07:02:38 --> Database Driver Class Initialized
INFO - 2022-07-05 07:02:38 --> Email Class Initialized
DEBUG - 2022-07-05 07:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 07:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 07:02:38 --> Controller Class Initialized
INFO - 2022-07-05 07:02:38 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 07:02:38 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 07:02:38 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 07:02:38 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-07-05 07:02:38 --> Final output sent to browser
DEBUG - 2022-07-05 07:02:38 --> Total execution time: 0.0519
INFO - 2022-07-05 07:03:30 --> Config Class Initialized
INFO - 2022-07-05 07:03:30 --> Hooks Class Initialized
DEBUG - 2022-07-05 07:03:30 --> UTF-8 Support Enabled
INFO - 2022-07-05 07:03:30 --> Utf8 Class Initialized
INFO - 2022-07-05 07:03:30 --> URI Class Initialized
INFO - 2022-07-05 07:03:30 --> Router Class Initialized
INFO - 2022-07-05 07:03:30 --> Output Class Initialized
INFO - 2022-07-05 07:03:30 --> Security Class Initialized
DEBUG - 2022-07-05 07:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 07:03:30 --> Input Class Initialized
INFO - 2022-07-05 07:03:30 --> Language Class Initialized
INFO - 2022-07-05 07:03:30 --> Loader Class Initialized
INFO - 2022-07-05 07:03:30 --> Helper loaded: url_helper
INFO - 2022-07-05 07:03:30 --> Helper loaded: file_helper
INFO - 2022-07-05 07:03:30 --> Database Driver Class Initialized
INFO - 2022-07-05 07:03:30 --> Email Class Initialized
DEBUG - 2022-07-05 07:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 07:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 07:03:30 --> Controller Class Initialized
INFO - 2022-07-05 07:03:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 07:03:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 07:03:30 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 07:03:30 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 07:03:30 --> Final output sent to browser
DEBUG - 2022-07-05 07:03:30 --> Total execution time: 0.0468
INFO - 2022-07-05 07:04:27 --> Config Class Initialized
INFO - 2022-07-05 07:04:27 --> Hooks Class Initialized
DEBUG - 2022-07-05 07:04:27 --> UTF-8 Support Enabled
INFO - 2022-07-05 07:04:27 --> Utf8 Class Initialized
INFO - 2022-07-05 07:04:27 --> URI Class Initialized
INFO - 2022-07-05 07:04:27 --> Router Class Initialized
INFO - 2022-07-05 07:04:27 --> Output Class Initialized
INFO - 2022-07-05 07:04:27 --> Security Class Initialized
DEBUG - 2022-07-05 07:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 07:04:27 --> Input Class Initialized
INFO - 2022-07-05 07:04:27 --> Language Class Initialized
INFO - 2022-07-05 07:04:27 --> Loader Class Initialized
INFO - 2022-07-05 07:04:27 --> Helper loaded: url_helper
INFO - 2022-07-05 07:04:27 --> Helper loaded: file_helper
INFO - 2022-07-05 07:04:27 --> Database Driver Class Initialized
INFO - 2022-07-05 07:04:27 --> Email Class Initialized
DEBUG - 2022-07-05 07:04:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 07:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 07:04:27 --> Controller Class Initialized
INFO - 2022-07-05 07:04:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 07:04:27 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 07:04:27 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 07:04:27 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 07:04:27 --> Final output sent to browser
DEBUG - 2022-07-05 07:04:27 --> Total execution time: 0.0456
INFO - 2022-07-05 07:06:19 --> Config Class Initialized
INFO - 2022-07-05 07:06:19 --> Hooks Class Initialized
DEBUG - 2022-07-05 07:06:19 --> UTF-8 Support Enabled
INFO - 2022-07-05 07:06:19 --> Utf8 Class Initialized
INFO - 2022-07-05 07:06:19 --> URI Class Initialized
INFO - 2022-07-05 07:06:19 --> Router Class Initialized
INFO - 2022-07-05 07:06:19 --> Output Class Initialized
INFO - 2022-07-05 07:06:19 --> Security Class Initialized
DEBUG - 2022-07-05 07:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 07:06:19 --> Input Class Initialized
INFO - 2022-07-05 07:06:19 --> Language Class Initialized
INFO - 2022-07-05 07:06:19 --> Loader Class Initialized
INFO - 2022-07-05 07:06:19 --> Helper loaded: url_helper
INFO - 2022-07-05 07:06:19 --> Helper loaded: file_helper
INFO - 2022-07-05 07:06:19 --> Database Driver Class Initialized
INFO - 2022-07-05 07:06:19 --> Email Class Initialized
DEBUG - 2022-07-05 07:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 07:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 07:06:19 --> Controller Class Initialized
INFO - 2022-07-05 07:06:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 07:06:19 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 07:06:19 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 07:06:19 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 07:06:19 --> Final output sent to browser
DEBUG - 2022-07-05 07:06:19 --> Total execution time: 0.0362
INFO - 2022-07-05 07:07:23 --> Config Class Initialized
INFO - 2022-07-05 07:07:23 --> Hooks Class Initialized
DEBUG - 2022-07-05 07:07:23 --> UTF-8 Support Enabled
INFO - 2022-07-05 07:07:23 --> Utf8 Class Initialized
INFO - 2022-07-05 07:07:23 --> URI Class Initialized
INFO - 2022-07-05 07:07:23 --> Router Class Initialized
INFO - 2022-07-05 07:07:23 --> Output Class Initialized
INFO - 2022-07-05 07:07:23 --> Security Class Initialized
DEBUG - 2022-07-05 07:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 07:07:23 --> Input Class Initialized
INFO - 2022-07-05 07:07:23 --> Language Class Initialized
INFO - 2022-07-05 07:07:23 --> Loader Class Initialized
INFO - 2022-07-05 07:07:23 --> Helper loaded: url_helper
INFO - 2022-07-05 07:07:23 --> Helper loaded: file_helper
INFO - 2022-07-05 07:07:23 --> Database Driver Class Initialized
INFO - 2022-07-05 07:07:23 --> Email Class Initialized
DEBUG - 2022-07-05 07:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 07:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 07:07:23 --> Controller Class Initialized
INFO - 2022-07-05 07:07:23 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 07:07:23 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 07:07:23 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 07:07:23 --> Final output sent to browser
DEBUG - 2022-07-05 07:07:23 --> Total execution time: 0.0344
INFO - 2022-07-05 07:07:25 --> Config Class Initialized
INFO - 2022-07-05 07:07:25 --> Hooks Class Initialized
DEBUG - 2022-07-05 07:07:25 --> UTF-8 Support Enabled
INFO - 2022-07-05 07:07:25 --> Utf8 Class Initialized
INFO - 2022-07-05 07:07:25 --> URI Class Initialized
INFO - 2022-07-05 07:07:25 --> Router Class Initialized
INFO - 2022-07-05 07:07:25 --> Output Class Initialized
INFO - 2022-07-05 07:07:25 --> Security Class Initialized
DEBUG - 2022-07-05 07:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 07:07:25 --> Input Class Initialized
INFO - 2022-07-05 07:07:25 --> Language Class Initialized
INFO - 2022-07-05 07:07:25 --> Loader Class Initialized
INFO - 2022-07-05 07:07:25 --> Helper loaded: url_helper
INFO - 2022-07-05 07:07:25 --> Helper loaded: file_helper
INFO - 2022-07-05 07:07:25 --> Database Driver Class Initialized
INFO - 2022-07-05 07:07:25 --> Email Class Initialized
DEBUG - 2022-07-05 07:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 07:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 07:07:25 --> Controller Class Initialized
INFO - 2022-07-05 07:07:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 07:07:25 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 07:07:25 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 07:07:25 --> Final output sent to browser
DEBUG - 2022-07-05 07:07:25 --> Total execution time: 0.0353
INFO - 2022-07-05 07:07:25 --> Config Class Initialized
INFO - 2022-07-05 07:07:25 --> Hooks Class Initialized
DEBUG - 2022-07-05 07:07:25 --> UTF-8 Support Enabled
INFO - 2022-07-05 07:07:25 --> Utf8 Class Initialized
INFO - 2022-07-05 07:07:25 --> URI Class Initialized
INFO - 2022-07-05 07:07:25 --> Router Class Initialized
INFO - 2022-07-05 07:07:25 --> Output Class Initialized
INFO - 2022-07-05 07:07:25 --> Security Class Initialized
DEBUG - 2022-07-05 07:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 07:07:25 --> Input Class Initialized
INFO - 2022-07-05 07:07:25 --> Language Class Initialized
INFO - 2022-07-05 07:07:25 --> Loader Class Initialized
INFO - 2022-07-05 07:07:25 --> Helper loaded: url_helper
INFO - 2022-07-05 07:07:25 --> Helper loaded: file_helper
INFO - 2022-07-05 07:07:25 --> Database Driver Class Initialized
INFO - 2022-07-05 07:07:25 --> Email Class Initialized
DEBUG - 2022-07-05 07:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 07:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 07:07:25 --> Controller Class Initialized
INFO - 2022-07-05 07:07:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 07:07:25 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 07:07:26 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 07:07:26 --> Final output sent to browser
DEBUG - 2022-07-05 07:07:26 --> Total execution time: 0.0227
INFO - 2022-07-05 07:07:26 --> Config Class Initialized
INFO - 2022-07-05 07:07:26 --> Hooks Class Initialized
DEBUG - 2022-07-05 07:07:26 --> UTF-8 Support Enabled
INFO - 2022-07-05 07:07:26 --> Utf8 Class Initialized
INFO - 2022-07-05 07:07:26 --> URI Class Initialized
INFO - 2022-07-05 07:07:26 --> Router Class Initialized
INFO - 2022-07-05 07:07:26 --> Output Class Initialized
INFO - 2022-07-05 07:07:26 --> Security Class Initialized
DEBUG - 2022-07-05 07:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 07:07:26 --> Input Class Initialized
INFO - 2022-07-05 07:07:26 --> Language Class Initialized
INFO - 2022-07-05 07:07:26 --> Loader Class Initialized
INFO - 2022-07-05 07:07:26 --> Helper loaded: url_helper
INFO - 2022-07-05 07:07:26 --> Helper loaded: file_helper
INFO - 2022-07-05 07:07:26 --> Database Driver Class Initialized
INFO - 2022-07-05 07:07:26 --> Email Class Initialized
DEBUG - 2022-07-05 07:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 07:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 07:07:26 --> Controller Class Initialized
INFO - 2022-07-05 07:07:26 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 07:07:26 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 07:07:26 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 07:07:26 --> Final output sent to browser
DEBUG - 2022-07-05 07:07:26 --> Total execution time: 0.0251
INFO - 2022-07-05 07:07:26 --> Config Class Initialized
INFO - 2022-07-05 07:07:26 --> Hooks Class Initialized
DEBUG - 2022-07-05 07:07:26 --> UTF-8 Support Enabled
INFO - 2022-07-05 07:07:26 --> Utf8 Class Initialized
INFO - 2022-07-05 07:07:26 --> URI Class Initialized
INFO - 2022-07-05 07:07:26 --> Router Class Initialized
INFO - 2022-07-05 07:07:26 --> Output Class Initialized
INFO - 2022-07-05 07:07:26 --> Security Class Initialized
DEBUG - 2022-07-05 07:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 07:07:26 --> Input Class Initialized
INFO - 2022-07-05 07:07:26 --> Language Class Initialized
INFO - 2022-07-05 07:07:26 --> Loader Class Initialized
INFO - 2022-07-05 07:07:26 --> Helper loaded: url_helper
INFO - 2022-07-05 07:07:26 --> Helper loaded: file_helper
INFO - 2022-07-05 07:07:26 --> Database Driver Class Initialized
INFO - 2022-07-05 07:07:26 --> Email Class Initialized
DEBUG - 2022-07-05 07:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 07:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 07:07:26 --> Controller Class Initialized
INFO - 2022-07-05 07:07:26 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 07:07:26 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 07:07:26 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 07:07:26 --> Final output sent to browser
DEBUG - 2022-07-05 07:07:26 --> Total execution time: 0.0325
INFO - 2022-07-05 07:07:26 --> Config Class Initialized
INFO - 2022-07-05 07:07:26 --> Hooks Class Initialized
DEBUG - 2022-07-05 07:07:26 --> UTF-8 Support Enabled
INFO - 2022-07-05 07:07:26 --> Utf8 Class Initialized
INFO - 2022-07-05 07:07:26 --> URI Class Initialized
INFO - 2022-07-05 07:07:26 --> Router Class Initialized
INFO - 2022-07-05 07:07:26 --> Output Class Initialized
INFO - 2022-07-05 07:07:26 --> Security Class Initialized
DEBUG - 2022-07-05 07:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 07:07:26 --> Input Class Initialized
INFO - 2022-07-05 07:07:26 --> Language Class Initialized
INFO - 2022-07-05 07:07:26 --> Loader Class Initialized
INFO - 2022-07-05 07:07:26 --> Helper loaded: url_helper
INFO - 2022-07-05 07:07:26 --> Helper loaded: file_helper
INFO - 2022-07-05 07:07:26 --> Database Driver Class Initialized
INFO - 2022-07-05 07:07:26 --> Email Class Initialized
DEBUG - 2022-07-05 07:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 07:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 07:07:26 --> Controller Class Initialized
INFO - 2022-07-05 07:07:26 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 07:07:26 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 07:07:26 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 07:07:26 --> Final output sent to browser
DEBUG - 2022-07-05 07:07:26 --> Total execution time: 0.0363
INFO - 2022-07-05 07:07:26 --> Config Class Initialized
INFO - 2022-07-05 07:07:26 --> Hooks Class Initialized
DEBUG - 2022-07-05 07:07:26 --> UTF-8 Support Enabled
INFO - 2022-07-05 07:07:26 --> Utf8 Class Initialized
INFO - 2022-07-05 07:07:26 --> URI Class Initialized
INFO - 2022-07-05 07:07:26 --> Router Class Initialized
INFO - 2022-07-05 07:07:26 --> Output Class Initialized
INFO - 2022-07-05 07:07:26 --> Security Class Initialized
DEBUG - 2022-07-05 07:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 07:07:26 --> Input Class Initialized
INFO - 2022-07-05 07:07:26 --> Language Class Initialized
INFO - 2022-07-05 07:07:26 --> Loader Class Initialized
INFO - 2022-07-05 07:07:26 --> Helper loaded: url_helper
INFO - 2022-07-05 07:07:26 --> Helper loaded: file_helper
INFO - 2022-07-05 07:07:26 --> Database Driver Class Initialized
INFO - 2022-07-05 07:07:26 --> Email Class Initialized
DEBUG - 2022-07-05 07:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 07:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 07:07:26 --> Controller Class Initialized
INFO - 2022-07-05 07:07:26 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 07:07:26 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 07:07:26 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 07:07:26 --> Final output sent to browser
DEBUG - 2022-07-05 07:07:26 --> Total execution time: 0.0228
INFO - 2022-07-05 07:07:31 --> Config Class Initialized
INFO - 2022-07-05 07:07:31 --> Hooks Class Initialized
DEBUG - 2022-07-05 07:07:31 --> UTF-8 Support Enabled
INFO - 2022-07-05 07:07:31 --> Utf8 Class Initialized
INFO - 2022-07-05 07:07:31 --> URI Class Initialized
INFO - 2022-07-05 07:07:31 --> Router Class Initialized
INFO - 2022-07-05 07:07:31 --> Output Class Initialized
INFO - 2022-07-05 07:07:31 --> Security Class Initialized
DEBUG - 2022-07-05 07:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 07:07:31 --> Input Class Initialized
INFO - 2022-07-05 07:07:31 --> Language Class Initialized
INFO - 2022-07-05 07:07:31 --> Loader Class Initialized
INFO - 2022-07-05 07:07:31 --> Helper loaded: url_helper
INFO - 2022-07-05 07:07:31 --> Helper loaded: file_helper
INFO - 2022-07-05 07:07:31 --> Database Driver Class Initialized
INFO - 2022-07-05 07:07:31 --> Email Class Initialized
DEBUG - 2022-07-05 07:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 07:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 07:07:31 --> Controller Class Initialized
INFO - 2022-07-05 07:07:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 07:07:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 07:07:31 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 07:07:31 --> Final output sent to browser
DEBUG - 2022-07-05 07:07:31 --> Total execution time: 0.1306
INFO - 2022-07-05 07:09:02 --> Config Class Initialized
INFO - 2022-07-05 07:09:02 --> Hooks Class Initialized
DEBUG - 2022-07-05 07:09:02 --> UTF-8 Support Enabled
INFO - 2022-07-05 07:09:02 --> Utf8 Class Initialized
INFO - 2022-07-05 07:09:02 --> URI Class Initialized
INFO - 2022-07-05 07:09:02 --> Router Class Initialized
INFO - 2022-07-05 07:09:02 --> Output Class Initialized
INFO - 2022-07-05 07:09:02 --> Security Class Initialized
DEBUG - 2022-07-05 07:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 07:09:02 --> Input Class Initialized
INFO - 2022-07-05 07:09:02 --> Language Class Initialized
INFO - 2022-07-05 07:09:02 --> Loader Class Initialized
INFO - 2022-07-05 07:09:02 --> Helper loaded: url_helper
INFO - 2022-07-05 07:09:02 --> Helper loaded: file_helper
INFO - 2022-07-05 07:09:02 --> Database Driver Class Initialized
INFO - 2022-07-05 07:09:02 --> Email Class Initialized
DEBUG - 2022-07-05 07:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 07:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 07:09:02 --> Controller Class Initialized
INFO - 2022-07-05 07:09:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 07:09:02 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 07:09:02 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 07:09:02 --> Final output sent to browser
DEBUG - 2022-07-05 07:09:02 --> Total execution time: 0.1309
INFO - 2022-07-05 07:10:14 --> Config Class Initialized
INFO - 2022-07-05 07:10:14 --> Hooks Class Initialized
DEBUG - 2022-07-05 07:10:14 --> UTF-8 Support Enabled
INFO - 2022-07-05 07:10:14 --> Utf8 Class Initialized
INFO - 2022-07-05 07:10:14 --> URI Class Initialized
INFO - 2022-07-05 07:10:14 --> Router Class Initialized
INFO - 2022-07-05 07:10:14 --> Output Class Initialized
INFO - 2022-07-05 07:10:14 --> Security Class Initialized
DEBUG - 2022-07-05 07:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 07:10:14 --> Input Class Initialized
INFO - 2022-07-05 07:10:14 --> Language Class Initialized
INFO - 2022-07-05 07:10:14 --> Loader Class Initialized
INFO - 2022-07-05 07:10:14 --> Helper loaded: url_helper
INFO - 2022-07-05 07:10:14 --> Helper loaded: file_helper
INFO - 2022-07-05 07:10:14 --> Database Driver Class Initialized
INFO - 2022-07-05 07:10:14 --> Email Class Initialized
DEBUG - 2022-07-05 07:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 07:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 07:10:14 --> Controller Class Initialized
INFO - 2022-07-05 07:10:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 07:10:14 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 07:10:14 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 07:10:14 --> Final output sent to browser
DEBUG - 2022-07-05 07:10:14 --> Total execution time: 0.0233
INFO - 2022-07-05 07:11:17 --> Config Class Initialized
INFO - 2022-07-05 07:11:17 --> Hooks Class Initialized
DEBUG - 2022-07-05 07:11:17 --> UTF-8 Support Enabled
INFO - 2022-07-05 07:11:17 --> Utf8 Class Initialized
INFO - 2022-07-05 07:11:17 --> URI Class Initialized
INFO - 2022-07-05 07:11:17 --> Router Class Initialized
INFO - 2022-07-05 07:11:17 --> Output Class Initialized
INFO - 2022-07-05 07:11:17 --> Security Class Initialized
DEBUG - 2022-07-05 07:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 07:11:17 --> Input Class Initialized
INFO - 2022-07-05 07:11:17 --> Language Class Initialized
INFO - 2022-07-05 07:11:17 --> Loader Class Initialized
INFO - 2022-07-05 07:11:17 --> Helper loaded: url_helper
INFO - 2022-07-05 07:11:17 --> Helper loaded: file_helper
INFO - 2022-07-05 07:11:17 --> Database Driver Class Initialized
INFO - 2022-07-05 07:11:17 --> Email Class Initialized
DEBUG - 2022-07-05 07:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 07:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 07:11:17 --> Controller Class Initialized
INFO - 2022-07-05 07:11:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 07:11:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 07:11:17 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 07:11:17 --> Final output sent to browser
DEBUG - 2022-07-05 07:11:17 --> Total execution time: 0.0263
INFO - 2022-07-05 07:12:30 --> Config Class Initialized
INFO - 2022-07-05 07:12:30 --> Hooks Class Initialized
DEBUG - 2022-07-05 07:12:30 --> UTF-8 Support Enabled
INFO - 2022-07-05 07:12:30 --> Utf8 Class Initialized
INFO - 2022-07-05 07:12:30 --> URI Class Initialized
INFO - 2022-07-05 07:12:30 --> Router Class Initialized
INFO - 2022-07-05 07:12:30 --> Output Class Initialized
INFO - 2022-07-05 07:12:30 --> Security Class Initialized
DEBUG - 2022-07-05 07:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 07:12:30 --> Input Class Initialized
INFO - 2022-07-05 07:12:30 --> Language Class Initialized
INFO - 2022-07-05 07:12:30 --> Loader Class Initialized
INFO - 2022-07-05 07:12:30 --> Helper loaded: url_helper
INFO - 2022-07-05 07:12:30 --> Helper loaded: file_helper
INFO - 2022-07-05 07:12:30 --> Database Driver Class Initialized
INFO - 2022-07-05 07:12:30 --> Email Class Initialized
DEBUG - 2022-07-05 07:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 07:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 07:12:30 --> Controller Class Initialized
INFO - 2022-07-05 07:12:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 07:12:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 07:12:30 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 07:12:30 --> Final output sent to browser
DEBUG - 2022-07-05 07:12:30 --> Total execution time: 0.0246
INFO - 2022-07-05 07:13:18 --> Config Class Initialized
INFO - 2022-07-05 07:13:18 --> Hooks Class Initialized
DEBUG - 2022-07-05 07:13:18 --> UTF-8 Support Enabled
INFO - 2022-07-05 07:13:18 --> Utf8 Class Initialized
INFO - 2022-07-05 07:13:18 --> URI Class Initialized
INFO - 2022-07-05 07:13:18 --> Router Class Initialized
INFO - 2022-07-05 07:13:18 --> Output Class Initialized
INFO - 2022-07-05 07:13:18 --> Security Class Initialized
DEBUG - 2022-07-05 07:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 07:13:18 --> Input Class Initialized
INFO - 2022-07-05 07:13:18 --> Language Class Initialized
INFO - 2022-07-05 07:13:18 --> Loader Class Initialized
INFO - 2022-07-05 07:13:18 --> Helper loaded: url_helper
INFO - 2022-07-05 07:13:18 --> Helper loaded: file_helper
INFO - 2022-07-05 07:13:18 --> Database Driver Class Initialized
INFO - 2022-07-05 07:13:18 --> Email Class Initialized
DEBUG - 2022-07-05 07:13:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 07:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 07:13:18 --> Controller Class Initialized
INFO - 2022-07-05 07:13:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 07:13:18 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 07:13:18 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 07:13:18 --> Final output sent to browser
DEBUG - 2022-07-05 07:13:18 --> Total execution time: 0.0351
INFO - 2022-07-05 07:14:03 --> Config Class Initialized
INFO - 2022-07-05 07:14:03 --> Hooks Class Initialized
DEBUG - 2022-07-05 07:14:03 --> UTF-8 Support Enabled
INFO - 2022-07-05 07:14:03 --> Utf8 Class Initialized
INFO - 2022-07-05 07:14:03 --> URI Class Initialized
INFO - 2022-07-05 07:14:03 --> Router Class Initialized
INFO - 2022-07-05 07:14:03 --> Output Class Initialized
INFO - 2022-07-05 07:14:03 --> Security Class Initialized
DEBUG - 2022-07-05 07:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 07:14:03 --> Input Class Initialized
INFO - 2022-07-05 07:14:03 --> Language Class Initialized
INFO - 2022-07-05 07:14:03 --> Loader Class Initialized
INFO - 2022-07-05 07:14:03 --> Helper loaded: url_helper
INFO - 2022-07-05 07:14:03 --> Helper loaded: file_helper
INFO - 2022-07-05 07:14:03 --> Database Driver Class Initialized
INFO - 2022-07-05 07:14:03 --> Email Class Initialized
DEBUG - 2022-07-05 07:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 07:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 07:14:03 --> Controller Class Initialized
INFO - 2022-07-05 07:14:03 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 07:14:03 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 07:14:03 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 07:14:03 --> Final output sent to browser
DEBUG - 2022-07-05 07:14:03 --> Total execution time: 0.0248
INFO - 2022-07-05 07:14:18 --> Config Class Initialized
INFO - 2022-07-05 07:14:18 --> Hooks Class Initialized
DEBUG - 2022-07-05 07:14:18 --> UTF-8 Support Enabled
INFO - 2022-07-05 07:14:18 --> Utf8 Class Initialized
INFO - 2022-07-05 07:14:18 --> URI Class Initialized
INFO - 2022-07-05 07:14:18 --> Router Class Initialized
INFO - 2022-07-05 07:14:18 --> Output Class Initialized
INFO - 2022-07-05 07:14:18 --> Security Class Initialized
DEBUG - 2022-07-05 07:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 07:14:18 --> Input Class Initialized
INFO - 2022-07-05 07:14:18 --> Language Class Initialized
INFO - 2022-07-05 07:14:18 --> Loader Class Initialized
INFO - 2022-07-05 07:14:18 --> Helper loaded: url_helper
INFO - 2022-07-05 07:14:18 --> Helper loaded: file_helper
INFO - 2022-07-05 07:14:18 --> Database Driver Class Initialized
INFO - 2022-07-05 07:14:18 --> Email Class Initialized
DEBUG - 2022-07-05 07:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 07:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 07:14:18 --> Controller Class Initialized
INFO - 2022-07-05 07:14:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 07:14:18 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 07:14:18 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 07:14:18 --> Final output sent to browser
DEBUG - 2022-07-05 07:14:18 --> Total execution time: 0.0244
INFO - 2022-07-05 07:14:20 --> Config Class Initialized
INFO - 2022-07-05 07:14:20 --> Hooks Class Initialized
DEBUG - 2022-07-05 07:14:20 --> UTF-8 Support Enabled
INFO - 2022-07-05 07:14:20 --> Utf8 Class Initialized
INFO - 2022-07-05 07:14:20 --> URI Class Initialized
INFO - 2022-07-05 07:14:20 --> Router Class Initialized
INFO - 2022-07-05 07:14:20 --> Output Class Initialized
INFO - 2022-07-05 07:14:20 --> Security Class Initialized
DEBUG - 2022-07-05 07:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 07:14:20 --> Input Class Initialized
INFO - 2022-07-05 07:14:20 --> Language Class Initialized
INFO - 2022-07-05 07:14:20 --> Loader Class Initialized
INFO - 2022-07-05 07:14:20 --> Helper loaded: url_helper
INFO - 2022-07-05 07:14:20 --> Helper loaded: file_helper
INFO - 2022-07-05 07:14:20 --> Database Driver Class Initialized
INFO - 2022-07-05 07:14:20 --> Email Class Initialized
DEBUG - 2022-07-05 07:14:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 07:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 07:14:20 --> Controller Class Initialized
INFO - 2022-07-05 07:14:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 07:14:20 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 07:14:20 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 07:14:20 --> Final output sent to browser
DEBUG - 2022-07-05 07:14:20 --> Total execution time: 0.0201
INFO - 2022-07-05 07:15:04 --> Config Class Initialized
INFO - 2022-07-05 07:15:04 --> Hooks Class Initialized
DEBUG - 2022-07-05 07:15:04 --> UTF-8 Support Enabled
INFO - 2022-07-05 07:15:04 --> Utf8 Class Initialized
INFO - 2022-07-05 07:15:04 --> URI Class Initialized
INFO - 2022-07-05 07:15:04 --> Router Class Initialized
INFO - 2022-07-05 07:15:04 --> Output Class Initialized
INFO - 2022-07-05 07:15:04 --> Security Class Initialized
DEBUG - 2022-07-05 07:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 07:15:04 --> Input Class Initialized
INFO - 2022-07-05 07:15:04 --> Language Class Initialized
INFO - 2022-07-05 07:15:04 --> Loader Class Initialized
INFO - 2022-07-05 07:15:04 --> Helper loaded: url_helper
INFO - 2022-07-05 07:15:04 --> Helper loaded: file_helper
INFO - 2022-07-05 07:15:04 --> Database Driver Class Initialized
INFO - 2022-07-05 07:15:04 --> Email Class Initialized
DEBUG - 2022-07-05 07:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 07:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 07:15:04 --> Controller Class Initialized
INFO - 2022-07-05 07:15:04 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 07:15:04 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 07:15:04 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 07:15:04 --> Final output sent to browser
DEBUG - 2022-07-05 07:15:04 --> Total execution time: 0.0386
INFO - 2022-07-05 07:18:41 --> Config Class Initialized
INFO - 2022-07-05 07:18:41 --> Hooks Class Initialized
DEBUG - 2022-07-05 07:18:41 --> UTF-8 Support Enabled
INFO - 2022-07-05 07:18:41 --> Utf8 Class Initialized
INFO - 2022-07-05 07:18:41 --> URI Class Initialized
INFO - 2022-07-05 07:18:41 --> Router Class Initialized
INFO - 2022-07-05 07:18:41 --> Output Class Initialized
INFO - 2022-07-05 07:18:41 --> Security Class Initialized
DEBUG - 2022-07-05 07:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 07:18:41 --> Input Class Initialized
INFO - 2022-07-05 07:18:41 --> Language Class Initialized
INFO - 2022-07-05 07:18:41 --> Loader Class Initialized
INFO - 2022-07-05 07:18:41 --> Helper loaded: url_helper
INFO - 2022-07-05 07:18:41 --> Helper loaded: file_helper
INFO - 2022-07-05 07:18:41 --> Database Driver Class Initialized
INFO - 2022-07-05 07:18:41 --> Email Class Initialized
DEBUG - 2022-07-05 07:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 07:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 07:18:41 --> Controller Class Initialized
INFO - 2022-07-05 07:18:41 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 07:18:41 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 07:18:41 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 07:18:41 --> Final output sent to browser
DEBUG - 2022-07-05 07:18:41 --> Total execution time: 0.0312
INFO - 2022-07-05 07:20:10 --> Config Class Initialized
INFO - 2022-07-05 07:20:10 --> Hooks Class Initialized
DEBUG - 2022-07-05 07:20:10 --> UTF-8 Support Enabled
INFO - 2022-07-05 07:20:10 --> Utf8 Class Initialized
INFO - 2022-07-05 07:20:10 --> URI Class Initialized
INFO - 2022-07-05 07:20:10 --> Router Class Initialized
INFO - 2022-07-05 07:20:10 --> Output Class Initialized
INFO - 2022-07-05 07:20:10 --> Security Class Initialized
DEBUG - 2022-07-05 07:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 07:20:10 --> Input Class Initialized
INFO - 2022-07-05 07:20:10 --> Language Class Initialized
INFO - 2022-07-05 07:20:10 --> Loader Class Initialized
INFO - 2022-07-05 07:20:10 --> Helper loaded: url_helper
INFO - 2022-07-05 07:20:10 --> Helper loaded: file_helper
INFO - 2022-07-05 07:20:10 --> Database Driver Class Initialized
INFO - 2022-07-05 07:20:10 --> Email Class Initialized
DEBUG - 2022-07-05 07:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 07:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 07:20:10 --> Controller Class Initialized
INFO - 2022-07-05 07:20:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 07:20:10 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 07:20:10 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 07:20:10 --> Final output sent to browser
DEBUG - 2022-07-05 07:20:10 --> Total execution time: 0.0241
INFO - 2022-07-05 07:20:41 --> Config Class Initialized
INFO - 2022-07-05 07:20:41 --> Hooks Class Initialized
DEBUG - 2022-07-05 07:20:41 --> UTF-8 Support Enabled
INFO - 2022-07-05 07:20:41 --> Utf8 Class Initialized
INFO - 2022-07-05 07:20:41 --> URI Class Initialized
INFO - 2022-07-05 07:20:41 --> Router Class Initialized
INFO - 2022-07-05 07:20:41 --> Output Class Initialized
INFO - 2022-07-05 07:20:41 --> Security Class Initialized
DEBUG - 2022-07-05 07:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 07:20:41 --> Input Class Initialized
INFO - 2022-07-05 07:20:41 --> Language Class Initialized
INFO - 2022-07-05 07:20:41 --> Loader Class Initialized
INFO - 2022-07-05 07:20:41 --> Helper loaded: url_helper
INFO - 2022-07-05 07:20:41 --> Helper loaded: file_helper
INFO - 2022-07-05 07:20:41 --> Database Driver Class Initialized
INFO - 2022-07-05 07:20:41 --> Email Class Initialized
DEBUG - 2022-07-05 07:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 07:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 07:20:41 --> Controller Class Initialized
INFO - 2022-07-05 07:20:41 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 07:20:41 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 07:20:41 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 07:20:41 --> Final output sent to browser
DEBUG - 2022-07-05 07:20:41 --> Total execution time: 0.0863
INFO - 2022-07-05 07:21:17 --> Config Class Initialized
INFO - 2022-07-05 07:21:17 --> Hooks Class Initialized
DEBUG - 2022-07-05 07:21:17 --> UTF-8 Support Enabled
INFO - 2022-07-05 07:21:17 --> Utf8 Class Initialized
INFO - 2022-07-05 07:21:17 --> URI Class Initialized
INFO - 2022-07-05 07:21:17 --> Router Class Initialized
INFO - 2022-07-05 07:21:17 --> Output Class Initialized
INFO - 2022-07-05 07:21:17 --> Security Class Initialized
DEBUG - 2022-07-05 07:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 07:21:17 --> Input Class Initialized
INFO - 2022-07-05 07:21:17 --> Language Class Initialized
INFO - 2022-07-05 07:21:17 --> Loader Class Initialized
INFO - 2022-07-05 07:21:17 --> Helper loaded: url_helper
INFO - 2022-07-05 07:21:17 --> Helper loaded: file_helper
INFO - 2022-07-05 07:21:17 --> Database Driver Class Initialized
INFO - 2022-07-05 07:21:17 --> Email Class Initialized
DEBUG - 2022-07-05 07:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 07:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 07:21:17 --> Controller Class Initialized
INFO - 2022-07-05 07:21:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 07:21:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 07:21:17 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 07:21:17 --> Final output sent to browser
DEBUG - 2022-07-05 07:21:17 --> Total execution time: 0.0347
INFO - 2022-07-05 07:21:34 --> Config Class Initialized
INFO - 2022-07-05 07:21:34 --> Hooks Class Initialized
DEBUG - 2022-07-05 07:21:34 --> UTF-8 Support Enabled
INFO - 2022-07-05 07:21:34 --> Utf8 Class Initialized
INFO - 2022-07-05 07:21:34 --> URI Class Initialized
INFO - 2022-07-05 07:21:34 --> Router Class Initialized
INFO - 2022-07-05 07:21:34 --> Output Class Initialized
INFO - 2022-07-05 07:21:34 --> Security Class Initialized
DEBUG - 2022-07-05 07:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 07:21:34 --> Input Class Initialized
INFO - 2022-07-05 07:21:34 --> Language Class Initialized
INFO - 2022-07-05 07:21:34 --> Loader Class Initialized
INFO - 2022-07-05 07:21:34 --> Helper loaded: url_helper
INFO - 2022-07-05 07:21:34 --> Helper loaded: file_helper
INFO - 2022-07-05 07:21:34 --> Database Driver Class Initialized
INFO - 2022-07-05 07:21:34 --> Email Class Initialized
DEBUG - 2022-07-05 07:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 07:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 07:21:34 --> Controller Class Initialized
INFO - 2022-07-05 07:21:34 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 07:21:34 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 07:21:34 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 07:21:34 --> Final output sent to browser
DEBUG - 2022-07-05 07:21:34 --> Total execution time: 0.1303
INFO - 2022-07-05 07:21:39 --> Config Class Initialized
INFO - 2022-07-05 07:21:39 --> Hooks Class Initialized
DEBUG - 2022-07-05 07:21:39 --> UTF-8 Support Enabled
INFO - 2022-07-05 07:21:39 --> Utf8 Class Initialized
INFO - 2022-07-05 07:21:39 --> URI Class Initialized
INFO - 2022-07-05 07:21:39 --> Router Class Initialized
INFO - 2022-07-05 07:21:39 --> Output Class Initialized
INFO - 2022-07-05 07:21:39 --> Security Class Initialized
DEBUG - 2022-07-05 07:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 07:21:39 --> Input Class Initialized
INFO - 2022-07-05 07:21:39 --> Language Class Initialized
INFO - 2022-07-05 07:21:39 --> Loader Class Initialized
INFO - 2022-07-05 07:21:39 --> Helper loaded: url_helper
INFO - 2022-07-05 07:21:39 --> Helper loaded: file_helper
INFO - 2022-07-05 07:21:39 --> Database Driver Class Initialized
INFO - 2022-07-05 07:21:39 --> Email Class Initialized
DEBUG - 2022-07-05 07:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 07:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 07:21:39 --> Controller Class Initialized
INFO - 2022-07-05 07:21:39 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 07:21:39 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 07:21:39 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 07:21:39 --> Final output sent to browser
DEBUG - 2022-07-05 07:21:39 --> Total execution time: 0.1855
INFO - 2022-07-05 07:21:40 --> Config Class Initialized
INFO - 2022-07-05 07:21:40 --> Hooks Class Initialized
DEBUG - 2022-07-05 07:21:40 --> UTF-8 Support Enabled
INFO - 2022-07-05 07:21:40 --> Utf8 Class Initialized
INFO - 2022-07-05 07:21:40 --> URI Class Initialized
INFO - 2022-07-05 07:21:40 --> Router Class Initialized
INFO - 2022-07-05 07:21:40 --> Output Class Initialized
INFO - 2022-07-05 07:21:40 --> Security Class Initialized
DEBUG - 2022-07-05 07:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 07:21:40 --> Input Class Initialized
INFO - 2022-07-05 07:21:40 --> Language Class Initialized
INFO - 2022-07-05 07:21:40 --> Loader Class Initialized
INFO - 2022-07-05 07:21:40 --> Helper loaded: url_helper
INFO - 2022-07-05 07:21:40 --> Helper loaded: file_helper
INFO - 2022-07-05 07:21:40 --> Database Driver Class Initialized
INFO - 2022-07-05 07:21:40 --> Email Class Initialized
DEBUG - 2022-07-05 07:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 07:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 07:21:40 --> Controller Class Initialized
INFO - 2022-07-05 07:21:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 07:21:40 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 07:21:40 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 07:21:40 --> Final output sent to browser
DEBUG - 2022-07-05 07:21:40 --> Total execution time: 0.1170
INFO - 2022-07-05 08:29:19 --> Config Class Initialized
INFO - 2022-07-05 08:29:19 --> Hooks Class Initialized
DEBUG - 2022-07-05 08:29:19 --> UTF-8 Support Enabled
INFO - 2022-07-05 08:29:19 --> Utf8 Class Initialized
INFO - 2022-07-05 08:29:19 --> URI Class Initialized
INFO - 2022-07-05 08:29:19 --> Router Class Initialized
INFO - 2022-07-05 08:29:19 --> Output Class Initialized
INFO - 2022-07-05 08:29:19 --> Security Class Initialized
DEBUG - 2022-07-05 08:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 08:29:19 --> Input Class Initialized
INFO - 2022-07-05 08:29:19 --> Language Class Initialized
INFO - 2022-07-05 08:29:19 --> Loader Class Initialized
INFO - 2022-07-05 08:29:19 --> Helper loaded: url_helper
INFO - 2022-07-05 08:29:19 --> Helper loaded: file_helper
INFO - 2022-07-05 08:29:19 --> Database Driver Class Initialized
INFO - 2022-07-05 08:29:19 --> Email Class Initialized
DEBUG - 2022-07-05 08:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 08:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 08:29:19 --> Controller Class Initialized
INFO - 2022-07-05 08:29:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 08:29:19 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 08:29:19 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 08:29:19 --> Final output sent to browser
DEBUG - 2022-07-05 08:29:19 --> Total execution time: 0.4361
INFO - 2022-07-05 08:29:20 --> Config Class Initialized
INFO - 2022-07-05 08:29:20 --> Hooks Class Initialized
DEBUG - 2022-07-05 08:29:20 --> UTF-8 Support Enabled
INFO - 2022-07-05 08:29:20 --> Utf8 Class Initialized
INFO - 2022-07-05 08:29:20 --> URI Class Initialized
INFO - 2022-07-05 08:29:20 --> Router Class Initialized
INFO - 2022-07-05 08:29:20 --> Output Class Initialized
INFO - 2022-07-05 08:29:20 --> Security Class Initialized
DEBUG - 2022-07-05 08:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 08:29:20 --> Input Class Initialized
INFO - 2022-07-05 08:29:20 --> Language Class Initialized
INFO - 2022-07-05 08:29:20 --> Loader Class Initialized
INFO - 2022-07-05 08:29:20 --> Helper loaded: url_helper
INFO - 2022-07-05 08:29:20 --> Helper loaded: file_helper
INFO - 2022-07-05 08:29:20 --> Database Driver Class Initialized
INFO - 2022-07-05 08:29:20 --> Email Class Initialized
DEBUG - 2022-07-05 08:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 08:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 08:29:20 --> Controller Class Initialized
INFO - 2022-07-05 08:29:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 08:29:20 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 08:29:20 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 08:29:20 --> Final output sent to browser
DEBUG - 2022-07-05 08:29:20 --> Total execution time: 0.2182
INFO - 2022-07-05 08:30:21 --> Config Class Initialized
INFO - 2022-07-05 08:30:21 --> Hooks Class Initialized
DEBUG - 2022-07-05 08:30:21 --> UTF-8 Support Enabled
INFO - 2022-07-05 08:30:21 --> Utf8 Class Initialized
INFO - 2022-07-05 08:30:21 --> URI Class Initialized
INFO - 2022-07-05 08:30:21 --> Router Class Initialized
INFO - 2022-07-05 08:30:21 --> Output Class Initialized
INFO - 2022-07-05 08:30:21 --> Security Class Initialized
DEBUG - 2022-07-05 08:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 08:30:21 --> Input Class Initialized
INFO - 2022-07-05 08:30:21 --> Language Class Initialized
INFO - 2022-07-05 08:30:21 --> Loader Class Initialized
INFO - 2022-07-05 08:30:21 --> Helper loaded: url_helper
INFO - 2022-07-05 08:30:21 --> Helper loaded: file_helper
INFO - 2022-07-05 08:30:21 --> Database Driver Class Initialized
INFO - 2022-07-05 08:30:21 --> Email Class Initialized
DEBUG - 2022-07-05 08:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 08:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 08:30:21 --> Controller Class Initialized
INFO - 2022-07-05 08:30:21 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 08:30:21 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 08:30:21 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 08:30:21 --> Final output sent to browser
DEBUG - 2022-07-05 08:30:21 --> Total execution time: 0.1838
INFO - 2022-07-05 08:31:47 --> Config Class Initialized
INFO - 2022-07-05 08:31:47 --> Hooks Class Initialized
DEBUG - 2022-07-05 08:31:47 --> UTF-8 Support Enabled
INFO - 2022-07-05 08:31:47 --> Utf8 Class Initialized
INFO - 2022-07-05 08:31:47 --> URI Class Initialized
INFO - 2022-07-05 08:31:47 --> Router Class Initialized
INFO - 2022-07-05 08:31:47 --> Output Class Initialized
INFO - 2022-07-05 08:31:47 --> Security Class Initialized
DEBUG - 2022-07-05 08:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 08:31:47 --> Input Class Initialized
INFO - 2022-07-05 08:31:47 --> Language Class Initialized
INFO - 2022-07-05 08:31:47 --> Loader Class Initialized
INFO - 2022-07-05 08:31:47 --> Helper loaded: url_helper
INFO - 2022-07-05 08:31:47 --> Helper loaded: file_helper
INFO - 2022-07-05 08:31:47 --> Database Driver Class Initialized
INFO - 2022-07-05 08:31:48 --> Email Class Initialized
DEBUG - 2022-07-05 08:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 08:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 08:31:48 --> Controller Class Initialized
INFO - 2022-07-05 08:31:48 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 08:31:48 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 08:31:48 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 08:31:48 --> Final output sent to browser
DEBUG - 2022-07-05 08:31:48 --> Total execution time: 0.1514
INFO - 2022-07-05 08:33:55 --> Config Class Initialized
INFO - 2022-07-05 08:33:55 --> Hooks Class Initialized
DEBUG - 2022-07-05 08:33:55 --> UTF-8 Support Enabled
INFO - 2022-07-05 08:33:55 --> Utf8 Class Initialized
INFO - 2022-07-05 08:33:55 --> URI Class Initialized
INFO - 2022-07-05 08:33:55 --> Router Class Initialized
INFO - 2022-07-05 08:33:55 --> Output Class Initialized
INFO - 2022-07-05 08:33:55 --> Security Class Initialized
DEBUG - 2022-07-05 08:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 08:33:55 --> Input Class Initialized
INFO - 2022-07-05 08:33:55 --> Language Class Initialized
INFO - 2022-07-05 08:33:55 --> Loader Class Initialized
INFO - 2022-07-05 08:33:55 --> Helper loaded: url_helper
INFO - 2022-07-05 08:33:55 --> Helper loaded: file_helper
INFO - 2022-07-05 08:33:55 --> Database Driver Class Initialized
INFO - 2022-07-05 08:33:56 --> Email Class Initialized
DEBUG - 2022-07-05 08:33:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 08:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 08:33:56 --> Controller Class Initialized
INFO - 2022-07-05 08:33:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 08:33:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 08:33:56 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 08:33:56 --> Final output sent to browser
DEBUG - 2022-07-05 08:33:56 --> Total execution time: 0.1418
INFO - 2022-07-05 08:33:56 --> Config Class Initialized
INFO - 2022-07-05 08:33:56 --> Hooks Class Initialized
DEBUG - 2022-07-05 08:33:56 --> UTF-8 Support Enabled
INFO - 2022-07-05 08:33:56 --> Utf8 Class Initialized
INFO - 2022-07-05 08:33:56 --> URI Class Initialized
INFO - 2022-07-05 08:33:56 --> Router Class Initialized
INFO - 2022-07-05 08:33:56 --> Output Class Initialized
INFO - 2022-07-05 08:33:56 --> Security Class Initialized
DEBUG - 2022-07-05 08:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 08:33:56 --> Input Class Initialized
INFO - 2022-07-05 08:33:56 --> Language Class Initialized
INFO - 2022-07-05 08:33:56 --> Loader Class Initialized
INFO - 2022-07-05 08:33:56 --> Helper loaded: url_helper
INFO - 2022-07-05 08:33:56 --> Helper loaded: file_helper
INFO - 2022-07-05 08:33:56 --> Database Driver Class Initialized
INFO - 2022-07-05 08:33:56 --> Email Class Initialized
DEBUG - 2022-07-05 08:33:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 08:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 08:33:56 --> Controller Class Initialized
INFO - 2022-07-05 08:33:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 08:33:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 08:33:56 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 08:33:56 --> Final output sent to browser
DEBUG - 2022-07-05 08:33:56 --> Total execution time: 0.0225
INFO - 2022-07-05 08:34:57 --> Config Class Initialized
INFO - 2022-07-05 08:34:57 --> Hooks Class Initialized
DEBUG - 2022-07-05 08:34:57 --> UTF-8 Support Enabled
INFO - 2022-07-05 08:34:57 --> Utf8 Class Initialized
INFO - 2022-07-05 08:34:57 --> URI Class Initialized
INFO - 2022-07-05 08:34:57 --> Router Class Initialized
INFO - 2022-07-05 08:34:57 --> Output Class Initialized
INFO - 2022-07-05 08:34:57 --> Security Class Initialized
DEBUG - 2022-07-05 08:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 08:34:57 --> Input Class Initialized
INFO - 2022-07-05 08:34:57 --> Language Class Initialized
INFO - 2022-07-05 08:34:57 --> Loader Class Initialized
INFO - 2022-07-05 08:34:57 --> Helper loaded: url_helper
INFO - 2022-07-05 08:34:57 --> Helper loaded: file_helper
INFO - 2022-07-05 08:34:57 --> Database Driver Class Initialized
INFO - 2022-07-05 08:34:57 --> Email Class Initialized
DEBUG - 2022-07-05 08:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 08:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 08:34:57 --> Controller Class Initialized
INFO - 2022-07-05 08:34:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 08:34:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 08:34:57 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 08:34:57 --> Final output sent to browser
DEBUG - 2022-07-05 08:34:57 --> Total execution time: 0.0384
INFO - 2022-07-05 08:36:27 --> Config Class Initialized
INFO - 2022-07-05 08:36:27 --> Hooks Class Initialized
DEBUG - 2022-07-05 08:36:27 --> UTF-8 Support Enabled
INFO - 2022-07-05 08:36:27 --> Utf8 Class Initialized
INFO - 2022-07-05 08:36:27 --> URI Class Initialized
INFO - 2022-07-05 08:36:27 --> Router Class Initialized
INFO - 2022-07-05 08:36:27 --> Output Class Initialized
INFO - 2022-07-05 08:36:27 --> Security Class Initialized
DEBUG - 2022-07-05 08:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 08:36:27 --> Input Class Initialized
INFO - 2022-07-05 08:36:27 --> Language Class Initialized
INFO - 2022-07-05 08:36:27 --> Loader Class Initialized
INFO - 2022-07-05 08:36:27 --> Helper loaded: url_helper
INFO - 2022-07-05 08:36:27 --> Helper loaded: file_helper
INFO - 2022-07-05 08:36:27 --> Database Driver Class Initialized
INFO - 2022-07-05 08:36:27 --> Email Class Initialized
DEBUG - 2022-07-05 08:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 08:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 08:36:27 --> Controller Class Initialized
INFO - 2022-07-05 08:36:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 08:36:27 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 08:36:27 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 08:36:27 --> Final output sent to browser
DEBUG - 2022-07-05 08:36:27 --> Total execution time: 0.0231
INFO - 2022-07-05 08:56:43 --> Config Class Initialized
INFO - 2022-07-05 08:56:43 --> Hooks Class Initialized
DEBUG - 2022-07-05 08:56:43 --> UTF-8 Support Enabled
INFO - 2022-07-05 08:56:43 --> Utf8 Class Initialized
INFO - 2022-07-05 08:56:43 --> URI Class Initialized
INFO - 2022-07-05 08:56:43 --> Router Class Initialized
INFO - 2022-07-05 08:56:43 --> Output Class Initialized
INFO - 2022-07-05 08:56:43 --> Security Class Initialized
DEBUG - 2022-07-05 08:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 08:56:43 --> Input Class Initialized
INFO - 2022-07-05 08:56:43 --> Language Class Initialized
INFO - 2022-07-05 08:56:43 --> Loader Class Initialized
INFO - 2022-07-05 08:56:43 --> Helper loaded: url_helper
INFO - 2022-07-05 08:56:43 --> Helper loaded: file_helper
INFO - 2022-07-05 08:56:43 --> Database Driver Class Initialized
INFO - 2022-07-05 08:56:43 --> Email Class Initialized
DEBUG - 2022-07-05 08:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 08:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 08:56:43 --> Controller Class Initialized
INFO - 2022-07-05 08:56:43 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 08:56:43 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 08:56:43 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 08:56:43 --> Final output sent to browser
DEBUG - 2022-07-05 08:56:43 --> Total execution time: 0.2754
INFO - 2022-07-05 08:56:46 --> Config Class Initialized
INFO - 2022-07-05 08:56:46 --> Hooks Class Initialized
DEBUG - 2022-07-05 08:56:46 --> UTF-8 Support Enabled
INFO - 2022-07-05 08:56:46 --> Utf8 Class Initialized
INFO - 2022-07-05 08:56:46 --> URI Class Initialized
INFO - 2022-07-05 08:56:46 --> Router Class Initialized
INFO - 2022-07-05 08:56:46 --> Output Class Initialized
INFO - 2022-07-05 08:56:46 --> Security Class Initialized
DEBUG - 2022-07-05 08:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 08:56:46 --> Input Class Initialized
INFO - 2022-07-05 08:56:46 --> Language Class Initialized
INFO - 2022-07-05 08:56:46 --> Loader Class Initialized
INFO - 2022-07-05 08:56:46 --> Helper loaded: url_helper
INFO - 2022-07-05 08:56:46 --> Helper loaded: file_helper
INFO - 2022-07-05 08:56:46 --> Database Driver Class Initialized
INFO - 2022-07-05 08:56:46 --> Email Class Initialized
DEBUG - 2022-07-05 08:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 08:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 08:56:46 --> Controller Class Initialized
INFO - 2022-07-05 08:56:46 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 08:56:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-05 08:56:46 --> Severity: Notice --> Undefined variable: total C:\wamp64\www\qr\application\views\doc_screen\doctor.php 359
INFO - 2022-07-05 08:56:46 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-07-05 08:56:46 --> Final output sent to browser
DEBUG - 2022-07-05 08:56:46 --> Total execution time: 0.2807
INFO - 2022-07-05 08:56:49 --> Config Class Initialized
INFO - 2022-07-05 08:56:49 --> Hooks Class Initialized
DEBUG - 2022-07-05 08:56:49 --> UTF-8 Support Enabled
INFO - 2022-07-05 08:56:49 --> Utf8 Class Initialized
INFO - 2022-07-05 08:56:49 --> URI Class Initialized
INFO - 2022-07-05 08:56:49 --> Router Class Initialized
INFO - 2022-07-05 08:56:49 --> Output Class Initialized
INFO - 2022-07-05 08:56:49 --> Security Class Initialized
DEBUG - 2022-07-05 08:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 08:56:49 --> Input Class Initialized
INFO - 2022-07-05 08:56:49 --> Language Class Initialized
INFO - 2022-07-05 08:56:49 --> Loader Class Initialized
INFO - 2022-07-05 08:56:49 --> Helper loaded: url_helper
INFO - 2022-07-05 08:56:49 --> Helper loaded: file_helper
INFO - 2022-07-05 08:56:49 --> Database Driver Class Initialized
INFO - 2022-07-05 08:56:49 --> Email Class Initialized
DEBUG - 2022-07-05 08:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 08:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 08:56:49 --> Controller Class Initialized
INFO - 2022-07-05 08:56:49 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 08:56:49 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 08:56:49 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 08:56:49 --> Final output sent to browser
DEBUG - 2022-07-05 08:56:49 --> Total execution time: 0.1365
INFO - 2022-07-05 08:58:58 --> Config Class Initialized
INFO - 2022-07-05 08:58:58 --> Hooks Class Initialized
DEBUG - 2022-07-05 08:58:58 --> UTF-8 Support Enabled
INFO - 2022-07-05 08:58:58 --> Utf8 Class Initialized
INFO - 2022-07-05 08:58:58 --> URI Class Initialized
INFO - 2022-07-05 08:58:58 --> Router Class Initialized
INFO - 2022-07-05 08:58:58 --> Output Class Initialized
INFO - 2022-07-05 08:58:58 --> Security Class Initialized
DEBUG - 2022-07-05 08:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 08:58:58 --> Input Class Initialized
INFO - 2022-07-05 08:58:58 --> Language Class Initialized
INFO - 2022-07-05 08:58:58 --> Loader Class Initialized
INFO - 2022-07-05 08:58:58 --> Helper loaded: url_helper
INFO - 2022-07-05 08:58:58 --> Helper loaded: file_helper
INFO - 2022-07-05 08:58:58 --> Database Driver Class Initialized
INFO - 2022-07-05 08:58:58 --> Email Class Initialized
DEBUG - 2022-07-05 08:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 08:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 08:58:58 --> Controller Class Initialized
INFO - 2022-07-05 08:58:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 08:58:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 08:58:59 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 08:58:59 --> Final output sent to browser
DEBUG - 2022-07-05 08:58:59 --> Total execution time: 0.1236
INFO - 2022-07-05 09:19:04 --> Config Class Initialized
INFO - 2022-07-05 09:19:04 --> Hooks Class Initialized
DEBUG - 2022-07-05 09:19:04 --> UTF-8 Support Enabled
INFO - 2022-07-05 09:19:04 --> Utf8 Class Initialized
INFO - 2022-07-05 09:19:04 --> URI Class Initialized
INFO - 2022-07-05 09:19:04 --> Router Class Initialized
INFO - 2022-07-05 09:19:04 --> Output Class Initialized
INFO - 2022-07-05 09:19:04 --> Security Class Initialized
DEBUG - 2022-07-05 09:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 09:19:04 --> Input Class Initialized
INFO - 2022-07-05 09:19:04 --> Language Class Initialized
INFO - 2022-07-05 09:19:04 --> Loader Class Initialized
INFO - 2022-07-05 09:19:04 --> Helper loaded: url_helper
INFO - 2022-07-05 09:19:04 --> Helper loaded: file_helper
INFO - 2022-07-05 09:19:04 --> Database Driver Class Initialized
INFO - 2022-07-05 09:19:05 --> Email Class Initialized
DEBUG - 2022-07-05 09:19:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 09:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 09:19:05 --> Controller Class Initialized
INFO - 2022-07-05 09:19:05 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 09:19:05 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 09:19:05 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 09:19:05 --> Final output sent to browser
DEBUG - 2022-07-05 09:19:05 --> Total execution time: 0.5482
INFO - 2022-07-05 09:24:05 --> Config Class Initialized
INFO - 2022-07-05 09:24:05 --> Hooks Class Initialized
DEBUG - 2022-07-05 09:24:05 --> UTF-8 Support Enabled
INFO - 2022-07-05 09:24:05 --> Utf8 Class Initialized
INFO - 2022-07-05 09:24:05 --> URI Class Initialized
INFO - 2022-07-05 09:24:05 --> Router Class Initialized
INFO - 2022-07-05 09:24:05 --> Output Class Initialized
INFO - 2022-07-05 09:24:05 --> Security Class Initialized
DEBUG - 2022-07-05 09:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 09:24:05 --> Input Class Initialized
INFO - 2022-07-05 09:24:05 --> Language Class Initialized
INFO - 2022-07-05 09:24:05 --> Loader Class Initialized
INFO - 2022-07-05 09:24:05 --> Helper loaded: url_helper
INFO - 2022-07-05 09:24:05 --> Helper loaded: file_helper
INFO - 2022-07-05 09:24:05 --> Database Driver Class Initialized
INFO - 2022-07-05 09:24:05 --> Email Class Initialized
DEBUG - 2022-07-05 09:24:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 09:24:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 09:24:05 --> Controller Class Initialized
INFO - 2022-07-05 09:24:05 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 09:24:05 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 09:24:05 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 09:24:05 --> Final output sent to browser
DEBUG - 2022-07-05 09:24:05 --> Total execution time: 0.2189
INFO - 2022-07-05 09:25:59 --> Config Class Initialized
INFO - 2022-07-05 09:25:59 --> Hooks Class Initialized
DEBUG - 2022-07-05 09:25:59 --> UTF-8 Support Enabled
INFO - 2022-07-05 09:25:59 --> Utf8 Class Initialized
INFO - 2022-07-05 09:25:59 --> URI Class Initialized
INFO - 2022-07-05 09:25:59 --> Router Class Initialized
INFO - 2022-07-05 09:25:59 --> Output Class Initialized
INFO - 2022-07-05 09:25:59 --> Security Class Initialized
DEBUG - 2022-07-05 09:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 09:25:59 --> Input Class Initialized
INFO - 2022-07-05 09:25:59 --> Language Class Initialized
INFO - 2022-07-05 09:25:59 --> Loader Class Initialized
INFO - 2022-07-05 09:25:59 --> Helper loaded: url_helper
INFO - 2022-07-05 09:25:59 --> Helper loaded: file_helper
INFO - 2022-07-05 09:25:59 --> Database Driver Class Initialized
INFO - 2022-07-05 09:25:59 --> Email Class Initialized
DEBUG - 2022-07-05 09:25:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 09:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 09:25:59 --> Controller Class Initialized
INFO - 2022-07-05 09:25:59 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 09:25:59 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 09:25:59 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 09:25:59 --> Final output sent to browser
DEBUG - 2022-07-05 09:25:59 --> Total execution time: 0.1305
INFO - 2022-07-05 09:30:30 --> Config Class Initialized
INFO - 2022-07-05 09:30:30 --> Hooks Class Initialized
DEBUG - 2022-07-05 09:30:30 --> UTF-8 Support Enabled
INFO - 2022-07-05 09:30:30 --> Utf8 Class Initialized
INFO - 2022-07-05 09:30:30 --> URI Class Initialized
INFO - 2022-07-05 09:30:30 --> Router Class Initialized
INFO - 2022-07-05 09:30:30 --> Output Class Initialized
INFO - 2022-07-05 09:30:30 --> Security Class Initialized
DEBUG - 2022-07-05 09:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 09:30:30 --> Input Class Initialized
INFO - 2022-07-05 09:30:30 --> Language Class Initialized
INFO - 2022-07-05 09:30:30 --> Loader Class Initialized
INFO - 2022-07-05 09:30:30 --> Helper loaded: url_helper
INFO - 2022-07-05 09:30:30 --> Helper loaded: file_helper
INFO - 2022-07-05 09:30:30 --> Database Driver Class Initialized
INFO - 2022-07-05 09:30:30 --> Email Class Initialized
DEBUG - 2022-07-05 09:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 09:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 09:30:30 --> Controller Class Initialized
INFO - 2022-07-05 09:30:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 09:30:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 09:30:30 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 09:30:30 --> Final output sent to browser
DEBUG - 2022-07-05 09:30:30 --> Total execution time: 0.1304
INFO - 2022-07-05 09:32:41 --> Config Class Initialized
INFO - 2022-07-05 09:32:41 --> Hooks Class Initialized
DEBUG - 2022-07-05 09:32:41 --> UTF-8 Support Enabled
INFO - 2022-07-05 09:32:41 --> Utf8 Class Initialized
INFO - 2022-07-05 09:32:41 --> URI Class Initialized
INFO - 2022-07-05 09:32:41 --> Router Class Initialized
INFO - 2022-07-05 09:32:41 --> Output Class Initialized
INFO - 2022-07-05 09:32:41 --> Security Class Initialized
DEBUG - 2022-07-05 09:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 09:32:41 --> Input Class Initialized
INFO - 2022-07-05 09:32:41 --> Language Class Initialized
INFO - 2022-07-05 09:32:41 --> Loader Class Initialized
INFO - 2022-07-05 09:32:41 --> Helper loaded: url_helper
INFO - 2022-07-05 09:32:41 --> Helper loaded: file_helper
INFO - 2022-07-05 09:32:41 --> Database Driver Class Initialized
INFO - 2022-07-05 09:32:41 --> Email Class Initialized
DEBUG - 2022-07-05 09:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 09:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 09:32:41 --> Controller Class Initialized
INFO - 2022-07-05 09:32:41 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 09:32:41 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 09:32:41 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 09:32:41 --> Final output sent to browser
DEBUG - 2022-07-05 09:32:41 --> Total execution time: 0.0687
INFO - 2022-07-05 09:34:23 --> Config Class Initialized
INFO - 2022-07-05 09:34:23 --> Hooks Class Initialized
DEBUG - 2022-07-05 09:34:23 --> UTF-8 Support Enabled
INFO - 2022-07-05 09:34:23 --> Utf8 Class Initialized
INFO - 2022-07-05 09:34:24 --> URI Class Initialized
INFO - 2022-07-05 09:34:24 --> Router Class Initialized
INFO - 2022-07-05 09:34:24 --> Output Class Initialized
INFO - 2022-07-05 09:34:24 --> Security Class Initialized
DEBUG - 2022-07-05 09:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 09:34:24 --> Input Class Initialized
INFO - 2022-07-05 09:34:24 --> Language Class Initialized
INFO - 2022-07-05 09:34:24 --> Loader Class Initialized
INFO - 2022-07-05 09:34:24 --> Helper loaded: url_helper
INFO - 2022-07-05 09:34:24 --> Helper loaded: file_helper
INFO - 2022-07-05 09:34:24 --> Database Driver Class Initialized
INFO - 2022-07-05 09:34:24 --> Email Class Initialized
DEBUG - 2022-07-05 09:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 09:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 09:34:24 --> Controller Class Initialized
INFO - 2022-07-05 09:34:24 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 09:34:24 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 09:34:24 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 09:34:24 --> Final output sent to browser
DEBUG - 2022-07-05 09:34:24 --> Total execution time: 0.1996
INFO - 2022-07-05 09:37:41 --> Config Class Initialized
INFO - 2022-07-05 09:37:41 --> Hooks Class Initialized
DEBUG - 2022-07-05 09:37:41 --> UTF-8 Support Enabled
INFO - 2022-07-05 09:37:41 --> Utf8 Class Initialized
INFO - 2022-07-05 09:37:41 --> URI Class Initialized
INFO - 2022-07-05 09:37:41 --> Router Class Initialized
INFO - 2022-07-05 09:37:41 --> Output Class Initialized
INFO - 2022-07-05 09:37:41 --> Security Class Initialized
DEBUG - 2022-07-05 09:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 09:37:41 --> Input Class Initialized
INFO - 2022-07-05 09:37:41 --> Language Class Initialized
INFO - 2022-07-05 09:37:41 --> Loader Class Initialized
INFO - 2022-07-05 09:37:41 --> Helper loaded: url_helper
INFO - 2022-07-05 09:37:41 --> Helper loaded: file_helper
INFO - 2022-07-05 09:37:41 --> Database Driver Class Initialized
INFO - 2022-07-05 09:37:42 --> Email Class Initialized
DEBUG - 2022-07-05 09:37:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 09:37:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 09:37:42 --> Controller Class Initialized
INFO - 2022-07-05 09:37:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 09:37:42 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 09:37:42 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 09:37:42 --> Final output sent to browser
DEBUG - 2022-07-05 09:37:42 --> Total execution time: 0.1375
INFO - 2022-07-05 09:40:08 --> Config Class Initialized
INFO - 2022-07-05 09:40:08 --> Hooks Class Initialized
DEBUG - 2022-07-05 09:40:08 --> UTF-8 Support Enabled
INFO - 2022-07-05 09:40:08 --> Utf8 Class Initialized
INFO - 2022-07-05 09:40:08 --> URI Class Initialized
INFO - 2022-07-05 09:40:08 --> Router Class Initialized
INFO - 2022-07-05 09:40:08 --> Output Class Initialized
INFO - 2022-07-05 09:40:08 --> Security Class Initialized
DEBUG - 2022-07-05 09:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 09:40:08 --> Input Class Initialized
INFO - 2022-07-05 09:40:08 --> Language Class Initialized
INFO - 2022-07-05 09:40:08 --> Loader Class Initialized
INFO - 2022-07-05 09:40:08 --> Helper loaded: url_helper
INFO - 2022-07-05 09:40:08 --> Helper loaded: file_helper
INFO - 2022-07-05 09:40:08 --> Database Driver Class Initialized
INFO - 2022-07-05 09:40:08 --> Email Class Initialized
DEBUG - 2022-07-05 09:40:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 09:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 09:40:08 --> Controller Class Initialized
INFO - 2022-07-05 09:40:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 09:40:08 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 09:40:08 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 09:40:08 --> Final output sent to browser
DEBUG - 2022-07-05 09:40:08 --> Total execution time: 0.0787
INFO - 2022-07-05 09:42:50 --> Config Class Initialized
INFO - 2022-07-05 09:42:50 --> Hooks Class Initialized
DEBUG - 2022-07-05 09:42:50 --> UTF-8 Support Enabled
INFO - 2022-07-05 09:42:50 --> Utf8 Class Initialized
INFO - 2022-07-05 09:42:50 --> URI Class Initialized
INFO - 2022-07-05 09:42:50 --> Router Class Initialized
INFO - 2022-07-05 09:42:50 --> Output Class Initialized
INFO - 2022-07-05 09:42:50 --> Security Class Initialized
DEBUG - 2022-07-05 09:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 09:42:50 --> Input Class Initialized
INFO - 2022-07-05 09:42:50 --> Language Class Initialized
INFO - 2022-07-05 09:42:50 --> Loader Class Initialized
INFO - 2022-07-05 09:42:50 --> Helper loaded: url_helper
INFO - 2022-07-05 09:42:50 --> Helper loaded: file_helper
INFO - 2022-07-05 09:42:50 --> Database Driver Class Initialized
INFO - 2022-07-05 09:42:50 --> Email Class Initialized
DEBUG - 2022-07-05 09:42:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 09:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 09:42:50 --> Controller Class Initialized
INFO - 2022-07-05 09:42:50 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 09:42:50 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 09:42:50 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 09:42:50 --> Final output sent to browser
DEBUG - 2022-07-05 09:42:50 --> Total execution time: 0.0500
INFO - 2022-07-05 09:44:52 --> Config Class Initialized
INFO - 2022-07-05 09:44:52 --> Hooks Class Initialized
DEBUG - 2022-07-05 09:44:52 --> UTF-8 Support Enabled
INFO - 2022-07-05 09:44:52 --> Utf8 Class Initialized
INFO - 2022-07-05 09:44:52 --> URI Class Initialized
INFO - 2022-07-05 09:44:52 --> Router Class Initialized
INFO - 2022-07-05 09:44:52 --> Output Class Initialized
INFO - 2022-07-05 09:44:52 --> Security Class Initialized
DEBUG - 2022-07-05 09:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 09:44:52 --> Input Class Initialized
INFO - 2022-07-05 09:44:52 --> Language Class Initialized
INFO - 2022-07-05 09:44:52 --> Loader Class Initialized
INFO - 2022-07-05 09:44:52 --> Helper loaded: url_helper
INFO - 2022-07-05 09:44:52 --> Helper loaded: file_helper
INFO - 2022-07-05 09:44:52 --> Database Driver Class Initialized
INFO - 2022-07-05 09:44:52 --> Email Class Initialized
DEBUG - 2022-07-05 09:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 09:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 09:44:52 --> Controller Class Initialized
INFO - 2022-07-05 09:44:52 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 09:44:52 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 09:44:52 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 09:44:52 --> Final output sent to browser
DEBUG - 2022-07-05 09:44:52 --> Total execution time: 0.0412
INFO - 2022-07-05 09:45:29 --> Config Class Initialized
INFO - 2022-07-05 09:45:29 --> Hooks Class Initialized
DEBUG - 2022-07-05 09:45:29 --> UTF-8 Support Enabled
INFO - 2022-07-05 09:45:29 --> Utf8 Class Initialized
INFO - 2022-07-05 09:45:29 --> URI Class Initialized
INFO - 2022-07-05 09:45:29 --> Router Class Initialized
INFO - 2022-07-05 09:45:29 --> Output Class Initialized
INFO - 2022-07-05 09:45:29 --> Security Class Initialized
DEBUG - 2022-07-05 09:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 09:45:29 --> Input Class Initialized
INFO - 2022-07-05 09:45:29 --> Language Class Initialized
INFO - 2022-07-05 09:45:29 --> Loader Class Initialized
INFO - 2022-07-05 09:45:29 --> Helper loaded: url_helper
INFO - 2022-07-05 09:45:29 --> Helper loaded: file_helper
INFO - 2022-07-05 09:45:29 --> Database Driver Class Initialized
INFO - 2022-07-05 09:45:29 --> Email Class Initialized
DEBUG - 2022-07-05 09:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 09:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 09:45:29 --> Controller Class Initialized
INFO - 2022-07-05 09:45:29 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 09:45:29 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 09:45:29 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 09:45:29 --> Final output sent to browser
DEBUG - 2022-07-05 09:45:29 --> Total execution time: 0.1921
INFO - 2022-07-05 09:47:19 --> Config Class Initialized
INFO - 2022-07-05 09:47:19 --> Hooks Class Initialized
DEBUG - 2022-07-05 09:47:19 --> UTF-8 Support Enabled
INFO - 2022-07-05 09:47:19 --> Utf8 Class Initialized
INFO - 2022-07-05 09:47:19 --> URI Class Initialized
INFO - 2022-07-05 09:47:19 --> Router Class Initialized
INFO - 2022-07-05 09:47:19 --> Output Class Initialized
INFO - 2022-07-05 09:47:19 --> Security Class Initialized
DEBUG - 2022-07-05 09:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 09:47:19 --> Input Class Initialized
INFO - 2022-07-05 09:47:19 --> Language Class Initialized
INFO - 2022-07-05 09:47:19 --> Loader Class Initialized
INFO - 2022-07-05 09:47:19 --> Helper loaded: url_helper
INFO - 2022-07-05 09:47:19 --> Helper loaded: file_helper
INFO - 2022-07-05 09:47:19 --> Database Driver Class Initialized
INFO - 2022-07-05 09:47:19 --> Email Class Initialized
DEBUG - 2022-07-05 09:47:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 09:47:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 09:47:19 --> Controller Class Initialized
INFO - 2022-07-05 09:47:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 09:47:19 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 09:47:19 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 09:47:19 --> Final output sent to browser
DEBUG - 2022-07-05 09:47:19 --> Total execution time: 0.1443
INFO - 2022-07-05 09:52:41 --> Config Class Initialized
INFO - 2022-07-05 09:52:41 --> Hooks Class Initialized
DEBUG - 2022-07-05 09:52:41 --> UTF-8 Support Enabled
INFO - 2022-07-05 09:52:41 --> Utf8 Class Initialized
INFO - 2022-07-05 09:52:41 --> URI Class Initialized
INFO - 2022-07-05 09:52:41 --> Router Class Initialized
INFO - 2022-07-05 09:52:41 --> Output Class Initialized
INFO - 2022-07-05 09:52:41 --> Security Class Initialized
DEBUG - 2022-07-05 09:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 09:52:41 --> Input Class Initialized
INFO - 2022-07-05 09:52:41 --> Language Class Initialized
INFO - 2022-07-05 09:52:41 --> Loader Class Initialized
INFO - 2022-07-05 09:52:41 --> Helper loaded: url_helper
INFO - 2022-07-05 09:52:41 --> Helper loaded: file_helper
INFO - 2022-07-05 09:52:41 --> Database Driver Class Initialized
INFO - 2022-07-05 09:52:41 --> Email Class Initialized
DEBUG - 2022-07-05 09:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 09:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 09:52:41 --> Controller Class Initialized
INFO - 2022-07-05 09:52:41 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 09:52:41 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 09:52:41 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 09:52:41 --> Final output sent to browser
DEBUG - 2022-07-05 09:52:41 --> Total execution time: 0.1478
INFO - 2022-07-05 09:54:53 --> Config Class Initialized
INFO - 2022-07-05 09:54:53 --> Hooks Class Initialized
DEBUG - 2022-07-05 09:54:53 --> UTF-8 Support Enabled
INFO - 2022-07-05 09:54:53 --> Utf8 Class Initialized
INFO - 2022-07-05 09:54:53 --> URI Class Initialized
INFO - 2022-07-05 09:54:53 --> Router Class Initialized
INFO - 2022-07-05 09:54:53 --> Output Class Initialized
INFO - 2022-07-05 09:54:53 --> Security Class Initialized
DEBUG - 2022-07-05 09:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 09:54:53 --> Input Class Initialized
INFO - 2022-07-05 09:54:53 --> Language Class Initialized
INFO - 2022-07-05 09:54:53 --> Loader Class Initialized
INFO - 2022-07-05 09:54:53 --> Helper loaded: url_helper
INFO - 2022-07-05 09:54:53 --> Helper loaded: file_helper
INFO - 2022-07-05 09:54:53 --> Database Driver Class Initialized
INFO - 2022-07-05 09:54:53 --> Email Class Initialized
DEBUG - 2022-07-05 09:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 09:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 09:54:53 --> Controller Class Initialized
INFO - 2022-07-05 09:54:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 09:54:53 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 09:54:54 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 09:54:54 --> Final output sent to browser
DEBUG - 2022-07-05 09:54:54 --> Total execution time: 0.2441
INFO - 2022-07-05 09:56:28 --> Config Class Initialized
INFO - 2022-07-05 09:56:28 --> Hooks Class Initialized
DEBUG - 2022-07-05 09:56:28 --> UTF-8 Support Enabled
INFO - 2022-07-05 09:56:28 --> Utf8 Class Initialized
INFO - 2022-07-05 09:56:28 --> URI Class Initialized
INFO - 2022-07-05 09:56:28 --> Router Class Initialized
INFO - 2022-07-05 09:56:28 --> Output Class Initialized
INFO - 2022-07-05 09:56:28 --> Security Class Initialized
DEBUG - 2022-07-05 09:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 09:56:28 --> Input Class Initialized
INFO - 2022-07-05 09:56:28 --> Language Class Initialized
INFO - 2022-07-05 09:56:28 --> Loader Class Initialized
INFO - 2022-07-05 09:56:28 --> Helper loaded: url_helper
INFO - 2022-07-05 09:56:28 --> Helper loaded: file_helper
INFO - 2022-07-05 09:56:28 --> Database Driver Class Initialized
INFO - 2022-07-05 09:56:28 --> Email Class Initialized
DEBUG - 2022-07-05 09:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 09:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 09:56:28 --> Controller Class Initialized
INFO - 2022-07-05 09:56:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 09:56:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 09:56:28 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 09:56:28 --> Final output sent to browser
DEBUG - 2022-07-05 09:56:28 --> Total execution time: 0.1459
INFO - 2022-07-05 09:59:35 --> Config Class Initialized
INFO - 2022-07-05 09:59:35 --> Hooks Class Initialized
DEBUG - 2022-07-05 09:59:35 --> UTF-8 Support Enabled
INFO - 2022-07-05 09:59:35 --> Utf8 Class Initialized
INFO - 2022-07-05 09:59:35 --> URI Class Initialized
INFO - 2022-07-05 09:59:35 --> Router Class Initialized
INFO - 2022-07-05 09:59:35 --> Output Class Initialized
INFO - 2022-07-05 09:59:35 --> Security Class Initialized
DEBUG - 2022-07-05 09:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 09:59:35 --> Input Class Initialized
INFO - 2022-07-05 09:59:35 --> Language Class Initialized
INFO - 2022-07-05 09:59:35 --> Loader Class Initialized
INFO - 2022-07-05 09:59:35 --> Helper loaded: url_helper
INFO - 2022-07-05 09:59:35 --> Helper loaded: file_helper
INFO - 2022-07-05 09:59:35 --> Database Driver Class Initialized
INFO - 2022-07-05 09:59:35 --> Email Class Initialized
DEBUG - 2022-07-05 09:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 09:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 09:59:35 --> Controller Class Initialized
INFO - 2022-07-05 09:59:35 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 09:59:35 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 09:59:35 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 09:59:35 --> Final output sent to browser
DEBUG - 2022-07-05 09:59:35 --> Total execution time: 0.0388
INFO - 2022-07-05 10:00:21 --> Config Class Initialized
INFO - 2022-07-05 10:00:21 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:00:21 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:00:21 --> Utf8 Class Initialized
INFO - 2022-07-05 10:00:21 --> URI Class Initialized
INFO - 2022-07-05 10:00:21 --> Router Class Initialized
INFO - 2022-07-05 10:00:21 --> Output Class Initialized
INFO - 2022-07-05 10:00:21 --> Security Class Initialized
DEBUG - 2022-07-05 10:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:00:21 --> Input Class Initialized
INFO - 2022-07-05 10:00:21 --> Language Class Initialized
INFO - 2022-07-05 10:00:21 --> Loader Class Initialized
INFO - 2022-07-05 10:00:21 --> Helper loaded: url_helper
INFO - 2022-07-05 10:00:21 --> Helper loaded: file_helper
INFO - 2022-07-05 10:00:21 --> Database Driver Class Initialized
INFO - 2022-07-05 10:00:22 --> Email Class Initialized
DEBUG - 2022-07-05 10:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:00:22 --> Controller Class Initialized
INFO - 2022-07-05 10:00:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:00:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:00:22 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:00:22 --> Final output sent to browser
DEBUG - 2022-07-05 10:00:22 --> Total execution time: 0.1171
INFO - 2022-07-05 10:04:18 --> Config Class Initialized
INFO - 2022-07-05 10:04:18 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:04:18 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:04:18 --> Utf8 Class Initialized
INFO - 2022-07-05 10:04:18 --> URI Class Initialized
INFO - 2022-07-05 10:04:18 --> Router Class Initialized
INFO - 2022-07-05 10:04:18 --> Output Class Initialized
INFO - 2022-07-05 10:04:18 --> Security Class Initialized
DEBUG - 2022-07-05 10:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:04:18 --> Input Class Initialized
INFO - 2022-07-05 10:04:18 --> Language Class Initialized
INFO - 2022-07-05 10:04:18 --> Loader Class Initialized
INFO - 2022-07-05 10:04:18 --> Helper loaded: url_helper
INFO - 2022-07-05 10:04:18 --> Helper loaded: file_helper
INFO - 2022-07-05 10:04:18 --> Database Driver Class Initialized
INFO - 2022-07-05 10:04:18 --> Email Class Initialized
DEBUG - 2022-07-05 10:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:04:18 --> Controller Class Initialized
INFO - 2022-07-05 10:04:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:04:18 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:04:18 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:04:18 --> Final output sent to browser
DEBUG - 2022-07-05 10:04:18 --> Total execution time: 0.3531
INFO - 2022-07-05 10:04:23 --> Config Class Initialized
INFO - 2022-07-05 10:04:23 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:04:23 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:04:23 --> Utf8 Class Initialized
INFO - 2022-07-05 10:04:23 --> URI Class Initialized
INFO - 2022-07-05 10:04:23 --> Router Class Initialized
INFO - 2022-07-05 10:04:23 --> Output Class Initialized
INFO - 2022-07-05 10:04:23 --> Security Class Initialized
DEBUG - 2022-07-05 10:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:04:23 --> Input Class Initialized
INFO - 2022-07-05 10:04:23 --> Language Class Initialized
INFO - 2022-07-05 10:04:23 --> Loader Class Initialized
INFO - 2022-07-05 10:04:23 --> Helper loaded: url_helper
INFO - 2022-07-05 10:04:23 --> Helper loaded: file_helper
INFO - 2022-07-05 10:04:23 --> Database Driver Class Initialized
INFO - 2022-07-05 10:04:23 --> Email Class Initialized
DEBUG - 2022-07-05 10:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:04:23 --> Controller Class Initialized
INFO - 2022-07-05 10:04:23 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:04:23 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:04:23 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:04:23 --> Final output sent to browser
DEBUG - 2022-07-05 10:04:23 --> Total execution time: 0.2001
INFO - 2022-07-05 10:12:10 --> Config Class Initialized
INFO - 2022-07-05 10:12:10 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:12:10 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:12:10 --> Utf8 Class Initialized
INFO - 2022-07-05 10:12:10 --> URI Class Initialized
INFO - 2022-07-05 10:12:10 --> Router Class Initialized
INFO - 2022-07-05 10:12:10 --> Output Class Initialized
INFO - 2022-07-05 10:12:10 --> Security Class Initialized
DEBUG - 2022-07-05 10:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:12:10 --> Input Class Initialized
INFO - 2022-07-05 10:12:10 --> Language Class Initialized
INFO - 2022-07-05 10:12:10 --> Loader Class Initialized
INFO - 2022-07-05 10:12:10 --> Helper loaded: url_helper
INFO - 2022-07-05 10:12:10 --> Helper loaded: file_helper
INFO - 2022-07-05 10:12:10 --> Database Driver Class Initialized
INFO - 2022-07-05 10:12:10 --> Email Class Initialized
DEBUG - 2022-07-05 10:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:12:10 --> Controller Class Initialized
INFO - 2022-07-05 10:12:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:12:10 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:12:10 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:12:10 --> Final output sent to browser
DEBUG - 2022-07-05 10:12:10 --> Total execution time: 0.2449
INFO - 2022-07-05 10:12:38 --> Config Class Initialized
INFO - 2022-07-05 10:12:38 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:12:38 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:12:38 --> Utf8 Class Initialized
INFO - 2022-07-05 10:12:38 --> URI Class Initialized
INFO - 2022-07-05 10:12:38 --> Router Class Initialized
INFO - 2022-07-05 10:12:38 --> Output Class Initialized
INFO - 2022-07-05 10:12:38 --> Security Class Initialized
DEBUG - 2022-07-05 10:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:12:38 --> Input Class Initialized
INFO - 2022-07-05 10:12:38 --> Language Class Initialized
INFO - 2022-07-05 10:12:38 --> Loader Class Initialized
INFO - 2022-07-05 10:12:38 --> Helper loaded: url_helper
INFO - 2022-07-05 10:12:38 --> Helper loaded: file_helper
INFO - 2022-07-05 10:12:38 --> Database Driver Class Initialized
INFO - 2022-07-05 10:12:38 --> Email Class Initialized
DEBUG - 2022-07-05 10:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:12:38 --> Controller Class Initialized
INFO - 2022-07-05 10:12:38 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:12:38 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:12:38 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:12:38 --> Final output sent to browser
DEBUG - 2022-07-05 10:12:38 --> Total execution time: 0.0186
INFO - 2022-07-05 10:13:48 --> Config Class Initialized
INFO - 2022-07-05 10:13:48 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:13:48 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:13:48 --> Utf8 Class Initialized
INFO - 2022-07-05 10:13:48 --> URI Class Initialized
INFO - 2022-07-05 10:13:48 --> Router Class Initialized
INFO - 2022-07-05 10:13:48 --> Output Class Initialized
INFO - 2022-07-05 10:13:48 --> Security Class Initialized
DEBUG - 2022-07-05 10:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:13:48 --> Input Class Initialized
INFO - 2022-07-05 10:13:48 --> Language Class Initialized
INFO - 2022-07-05 10:13:48 --> Loader Class Initialized
INFO - 2022-07-05 10:13:48 --> Helper loaded: url_helper
INFO - 2022-07-05 10:13:48 --> Helper loaded: file_helper
INFO - 2022-07-05 10:13:48 --> Database Driver Class Initialized
INFO - 2022-07-05 10:13:49 --> Email Class Initialized
DEBUG - 2022-07-05 10:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:13:49 --> Controller Class Initialized
INFO - 2022-07-05 10:13:49 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:13:49 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:13:49 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:13:49 --> Final output sent to browser
DEBUG - 2022-07-05 10:13:49 --> Total execution time: 0.3447
INFO - 2022-07-05 10:13:50 --> Config Class Initialized
INFO - 2022-07-05 10:13:50 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:13:50 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:13:50 --> Utf8 Class Initialized
INFO - 2022-07-05 10:13:50 --> URI Class Initialized
INFO - 2022-07-05 10:13:50 --> Router Class Initialized
INFO - 2022-07-05 10:13:50 --> Output Class Initialized
INFO - 2022-07-05 10:13:50 --> Security Class Initialized
DEBUG - 2022-07-05 10:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:13:50 --> Input Class Initialized
INFO - 2022-07-05 10:13:50 --> Language Class Initialized
INFO - 2022-07-05 10:13:50 --> Loader Class Initialized
INFO - 2022-07-05 10:13:50 --> Helper loaded: url_helper
INFO - 2022-07-05 10:13:50 --> Helper loaded: file_helper
INFO - 2022-07-05 10:13:50 --> Database Driver Class Initialized
INFO - 2022-07-05 10:13:50 --> Email Class Initialized
DEBUG - 2022-07-05 10:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:13:50 --> Controller Class Initialized
INFO - 2022-07-05 10:13:50 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:13:50 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:13:50 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:13:50 --> Final output sent to browser
DEBUG - 2022-07-05 10:13:50 --> Total execution time: 0.0182
INFO - 2022-07-05 10:14:01 --> Config Class Initialized
INFO - 2022-07-05 10:14:01 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:14:01 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:14:01 --> Utf8 Class Initialized
INFO - 2022-07-05 10:14:01 --> URI Class Initialized
INFO - 2022-07-05 10:14:01 --> Router Class Initialized
INFO - 2022-07-05 10:14:01 --> Output Class Initialized
INFO - 2022-07-05 10:14:01 --> Security Class Initialized
DEBUG - 2022-07-05 10:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:14:01 --> Input Class Initialized
INFO - 2022-07-05 10:14:01 --> Language Class Initialized
INFO - 2022-07-05 10:14:01 --> Loader Class Initialized
INFO - 2022-07-05 10:14:01 --> Helper loaded: url_helper
INFO - 2022-07-05 10:14:01 --> Helper loaded: file_helper
INFO - 2022-07-05 10:14:01 --> Database Driver Class Initialized
INFO - 2022-07-05 10:14:01 --> Email Class Initialized
DEBUG - 2022-07-05 10:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:14:01 --> Controller Class Initialized
INFO - 2022-07-05 10:14:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:14:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:14:01 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:14:01 --> Final output sent to browser
DEBUG - 2022-07-05 10:14:01 --> Total execution time: 0.0274
INFO - 2022-07-05 10:15:07 --> Config Class Initialized
INFO - 2022-07-05 10:15:07 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:15:07 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:15:07 --> Utf8 Class Initialized
INFO - 2022-07-05 10:15:07 --> URI Class Initialized
INFO - 2022-07-05 10:15:07 --> Router Class Initialized
INFO - 2022-07-05 10:15:07 --> Output Class Initialized
INFO - 2022-07-05 10:15:07 --> Security Class Initialized
DEBUG - 2022-07-05 10:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:15:07 --> Input Class Initialized
INFO - 2022-07-05 10:15:07 --> Language Class Initialized
INFO - 2022-07-05 10:15:07 --> Loader Class Initialized
INFO - 2022-07-05 10:15:07 --> Helper loaded: url_helper
INFO - 2022-07-05 10:15:07 --> Helper loaded: file_helper
INFO - 2022-07-05 10:15:07 --> Database Driver Class Initialized
INFO - 2022-07-05 10:15:07 --> Email Class Initialized
DEBUG - 2022-07-05 10:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:15:07 --> Controller Class Initialized
INFO - 2022-07-05 10:15:07 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:15:07 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:15:07 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:15:07 --> Final output sent to browser
DEBUG - 2022-07-05 10:15:07 --> Total execution time: 0.0189
INFO - 2022-07-05 10:16:18 --> Config Class Initialized
INFO - 2022-07-05 10:16:18 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:16:18 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:16:18 --> Utf8 Class Initialized
INFO - 2022-07-05 10:16:18 --> URI Class Initialized
INFO - 2022-07-05 10:16:18 --> Router Class Initialized
INFO - 2022-07-05 10:16:18 --> Output Class Initialized
INFO - 2022-07-05 10:16:18 --> Security Class Initialized
DEBUG - 2022-07-05 10:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:16:18 --> Input Class Initialized
INFO - 2022-07-05 10:16:18 --> Language Class Initialized
INFO - 2022-07-05 10:16:18 --> Loader Class Initialized
INFO - 2022-07-05 10:16:18 --> Helper loaded: url_helper
INFO - 2022-07-05 10:16:18 --> Helper loaded: file_helper
INFO - 2022-07-05 10:16:18 --> Database Driver Class Initialized
INFO - 2022-07-05 10:16:18 --> Email Class Initialized
DEBUG - 2022-07-05 10:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:16:18 --> Controller Class Initialized
INFO - 2022-07-05 10:16:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:16:18 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:16:18 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:16:18 --> Final output sent to browser
DEBUG - 2022-07-05 10:16:18 --> Total execution time: 0.1632
INFO - 2022-07-05 10:16:20 --> Config Class Initialized
INFO - 2022-07-05 10:16:20 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:16:20 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:16:20 --> Utf8 Class Initialized
INFO - 2022-07-05 10:16:20 --> URI Class Initialized
INFO - 2022-07-05 10:16:20 --> Router Class Initialized
INFO - 2022-07-05 10:16:20 --> Output Class Initialized
INFO - 2022-07-05 10:16:20 --> Security Class Initialized
DEBUG - 2022-07-05 10:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:16:20 --> Input Class Initialized
INFO - 2022-07-05 10:16:20 --> Language Class Initialized
INFO - 2022-07-05 10:16:20 --> Loader Class Initialized
INFO - 2022-07-05 10:16:20 --> Helper loaded: url_helper
INFO - 2022-07-05 10:16:20 --> Helper loaded: file_helper
INFO - 2022-07-05 10:16:20 --> Database Driver Class Initialized
INFO - 2022-07-05 10:16:20 --> Email Class Initialized
DEBUG - 2022-07-05 10:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:16:20 --> Controller Class Initialized
INFO - 2022-07-05 10:16:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:16:20 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:16:20 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:16:20 --> Final output sent to browser
DEBUG - 2022-07-05 10:16:20 --> Total execution time: 0.0680
INFO - 2022-07-05 10:18:01 --> Config Class Initialized
INFO - 2022-07-05 10:18:01 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:18:01 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:18:01 --> Utf8 Class Initialized
INFO - 2022-07-05 10:18:01 --> URI Class Initialized
INFO - 2022-07-05 10:18:01 --> Router Class Initialized
INFO - 2022-07-05 10:18:01 --> Output Class Initialized
INFO - 2022-07-05 10:18:01 --> Security Class Initialized
DEBUG - 2022-07-05 10:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:18:01 --> Input Class Initialized
INFO - 2022-07-05 10:18:01 --> Language Class Initialized
INFO - 2022-07-05 10:18:01 --> Loader Class Initialized
INFO - 2022-07-05 10:18:01 --> Helper loaded: url_helper
INFO - 2022-07-05 10:18:01 --> Helper loaded: file_helper
INFO - 2022-07-05 10:18:01 --> Database Driver Class Initialized
INFO - 2022-07-05 10:18:01 --> Email Class Initialized
DEBUG - 2022-07-05 10:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:18:01 --> Controller Class Initialized
INFO - 2022-07-05 10:18:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:18:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:18:01 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:18:01 --> Final output sent to browser
DEBUG - 2022-07-05 10:18:01 --> Total execution time: 0.0405
INFO - 2022-07-05 10:20:07 --> Config Class Initialized
INFO - 2022-07-05 10:20:07 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:20:07 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:20:07 --> Utf8 Class Initialized
INFO - 2022-07-05 10:20:07 --> URI Class Initialized
INFO - 2022-07-05 10:20:07 --> Router Class Initialized
INFO - 2022-07-05 10:20:07 --> Output Class Initialized
INFO - 2022-07-05 10:20:07 --> Security Class Initialized
DEBUG - 2022-07-05 10:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:20:07 --> Input Class Initialized
INFO - 2022-07-05 10:20:07 --> Language Class Initialized
INFO - 2022-07-05 10:20:07 --> Loader Class Initialized
INFO - 2022-07-05 10:20:07 --> Helper loaded: url_helper
INFO - 2022-07-05 10:20:07 --> Helper loaded: file_helper
INFO - 2022-07-05 10:20:07 --> Database Driver Class Initialized
INFO - 2022-07-05 10:20:07 --> Email Class Initialized
DEBUG - 2022-07-05 10:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:20:07 --> Controller Class Initialized
INFO - 2022-07-05 10:20:07 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:20:07 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:20:07 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:20:07 --> Final output sent to browser
DEBUG - 2022-07-05 10:20:07 --> Total execution time: 0.0186
INFO - 2022-07-05 10:21:43 --> Config Class Initialized
INFO - 2022-07-05 10:21:43 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:21:43 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:21:43 --> Utf8 Class Initialized
INFO - 2022-07-05 10:21:43 --> URI Class Initialized
INFO - 2022-07-05 10:21:43 --> Router Class Initialized
INFO - 2022-07-05 10:21:43 --> Output Class Initialized
INFO - 2022-07-05 10:21:43 --> Security Class Initialized
DEBUG - 2022-07-05 10:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:21:43 --> Input Class Initialized
INFO - 2022-07-05 10:21:43 --> Language Class Initialized
INFO - 2022-07-05 10:21:43 --> Loader Class Initialized
INFO - 2022-07-05 10:21:43 --> Helper loaded: url_helper
INFO - 2022-07-05 10:21:43 --> Helper loaded: file_helper
INFO - 2022-07-05 10:21:43 --> Database Driver Class Initialized
INFO - 2022-07-05 10:21:43 --> Email Class Initialized
DEBUG - 2022-07-05 10:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:21:43 --> Controller Class Initialized
INFO - 2022-07-05 10:21:43 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:21:43 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:21:43 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:21:43 --> Final output sent to browser
DEBUG - 2022-07-05 10:21:43 --> Total execution time: 0.0523
INFO - 2022-07-05 10:23:52 --> Config Class Initialized
INFO - 2022-07-05 10:23:52 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:23:52 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:23:52 --> Utf8 Class Initialized
INFO - 2022-07-05 10:23:52 --> URI Class Initialized
INFO - 2022-07-05 10:23:52 --> Router Class Initialized
INFO - 2022-07-05 10:23:52 --> Output Class Initialized
INFO - 2022-07-05 10:23:52 --> Security Class Initialized
DEBUG - 2022-07-05 10:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:23:52 --> Input Class Initialized
INFO - 2022-07-05 10:23:52 --> Language Class Initialized
INFO - 2022-07-05 10:23:52 --> Loader Class Initialized
INFO - 2022-07-05 10:23:52 --> Helper loaded: url_helper
INFO - 2022-07-05 10:23:52 --> Helper loaded: file_helper
INFO - 2022-07-05 10:23:52 --> Database Driver Class Initialized
INFO - 2022-07-05 10:23:52 --> Email Class Initialized
DEBUG - 2022-07-05 10:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:23:52 --> Controller Class Initialized
INFO - 2022-07-05 10:23:52 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:23:52 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:23:52 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:23:52 --> Final output sent to browser
DEBUG - 2022-07-05 10:23:52 --> Total execution time: 0.1639
INFO - 2022-07-05 10:26:16 --> Config Class Initialized
INFO - 2022-07-05 10:26:16 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:26:16 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:26:16 --> Utf8 Class Initialized
INFO - 2022-07-05 10:26:16 --> URI Class Initialized
INFO - 2022-07-05 10:26:16 --> Router Class Initialized
INFO - 2022-07-05 10:26:16 --> Output Class Initialized
INFO - 2022-07-05 10:26:16 --> Security Class Initialized
DEBUG - 2022-07-05 10:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:26:16 --> Input Class Initialized
INFO - 2022-07-05 10:26:16 --> Language Class Initialized
INFO - 2022-07-05 10:26:16 --> Loader Class Initialized
INFO - 2022-07-05 10:26:16 --> Helper loaded: url_helper
INFO - 2022-07-05 10:26:16 --> Helper loaded: file_helper
INFO - 2022-07-05 10:26:16 --> Database Driver Class Initialized
INFO - 2022-07-05 10:26:16 --> Email Class Initialized
DEBUG - 2022-07-05 10:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:26:16 --> Controller Class Initialized
INFO - 2022-07-05 10:26:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:26:16 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:26:16 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:26:16 --> Final output sent to browser
DEBUG - 2022-07-05 10:26:16 --> Total execution time: 0.1353
INFO - 2022-07-05 10:27:23 --> Config Class Initialized
INFO - 2022-07-05 10:27:23 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:27:23 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:27:23 --> Utf8 Class Initialized
INFO - 2022-07-05 10:27:23 --> URI Class Initialized
INFO - 2022-07-05 10:27:23 --> Router Class Initialized
INFO - 2022-07-05 10:27:23 --> Output Class Initialized
INFO - 2022-07-05 10:27:23 --> Security Class Initialized
DEBUG - 2022-07-05 10:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:27:23 --> Input Class Initialized
INFO - 2022-07-05 10:27:23 --> Language Class Initialized
INFO - 2022-07-05 10:27:23 --> Loader Class Initialized
INFO - 2022-07-05 10:27:23 --> Helper loaded: url_helper
INFO - 2022-07-05 10:27:23 --> Helper loaded: file_helper
INFO - 2022-07-05 10:27:23 --> Database Driver Class Initialized
INFO - 2022-07-05 10:27:23 --> Email Class Initialized
DEBUG - 2022-07-05 10:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:27:23 --> Controller Class Initialized
INFO - 2022-07-05 10:27:23 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:27:23 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:27:23 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:27:23 --> Final output sent to browser
DEBUG - 2022-07-05 10:27:23 --> Total execution time: 0.0461
INFO - 2022-07-05 10:33:51 --> Config Class Initialized
INFO - 2022-07-05 10:33:51 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:33:51 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:33:51 --> Utf8 Class Initialized
INFO - 2022-07-05 10:33:51 --> URI Class Initialized
INFO - 2022-07-05 10:33:51 --> Router Class Initialized
INFO - 2022-07-05 10:33:51 --> Output Class Initialized
INFO - 2022-07-05 10:33:51 --> Security Class Initialized
DEBUG - 2022-07-05 10:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:33:51 --> Input Class Initialized
INFO - 2022-07-05 10:33:51 --> Language Class Initialized
INFO - 2022-07-05 10:33:51 --> Loader Class Initialized
INFO - 2022-07-05 10:33:51 --> Helper loaded: url_helper
INFO - 2022-07-05 10:33:51 --> Helper loaded: file_helper
INFO - 2022-07-05 10:33:51 --> Database Driver Class Initialized
INFO - 2022-07-05 10:33:51 --> Email Class Initialized
DEBUG - 2022-07-05 10:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:33:51 --> Controller Class Initialized
INFO - 2022-07-05 10:33:51 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:33:51 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:33:51 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:33:51 --> Final output sent to browser
DEBUG - 2022-07-05 10:33:51 --> Total execution time: 0.1358
INFO - 2022-07-05 10:33:55 --> Config Class Initialized
INFO - 2022-07-05 10:33:55 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:33:55 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:33:55 --> Utf8 Class Initialized
INFO - 2022-07-05 10:33:55 --> URI Class Initialized
INFO - 2022-07-05 10:33:55 --> Router Class Initialized
INFO - 2022-07-05 10:33:55 --> Output Class Initialized
INFO - 2022-07-05 10:33:55 --> Security Class Initialized
DEBUG - 2022-07-05 10:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:33:55 --> Input Class Initialized
INFO - 2022-07-05 10:33:55 --> Language Class Initialized
INFO - 2022-07-05 10:33:55 --> Loader Class Initialized
INFO - 2022-07-05 10:33:55 --> Helper loaded: url_helper
INFO - 2022-07-05 10:33:55 --> Helper loaded: file_helper
INFO - 2022-07-05 10:33:55 --> Database Driver Class Initialized
INFO - 2022-07-05 10:33:55 --> Email Class Initialized
DEBUG - 2022-07-05 10:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:33:55 --> Controller Class Initialized
INFO - 2022-07-05 10:33:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:33:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:33:55 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:33:55 --> Final output sent to browser
DEBUG - 2022-07-05 10:33:55 --> Total execution time: 0.0644
INFO - 2022-07-05 10:34:08 --> Config Class Initialized
INFO - 2022-07-05 10:34:08 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:34:08 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:34:08 --> Utf8 Class Initialized
INFO - 2022-07-05 10:34:08 --> URI Class Initialized
INFO - 2022-07-05 10:34:08 --> Router Class Initialized
INFO - 2022-07-05 10:34:08 --> Output Class Initialized
INFO - 2022-07-05 10:34:08 --> Security Class Initialized
DEBUG - 2022-07-05 10:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:34:08 --> Input Class Initialized
INFO - 2022-07-05 10:34:08 --> Language Class Initialized
INFO - 2022-07-05 10:34:08 --> Loader Class Initialized
INFO - 2022-07-05 10:34:08 --> Helper loaded: url_helper
INFO - 2022-07-05 10:34:08 --> Helper loaded: file_helper
INFO - 2022-07-05 10:34:08 --> Database Driver Class Initialized
INFO - 2022-07-05 10:34:08 --> Email Class Initialized
DEBUG - 2022-07-05 10:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:34:08 --> Controller Class Initialized
INFO - 2022-07-05 10:34:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:34:08 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:34:08 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:34:08 --> Final output sent to browser
DEBUG - 2022-07-05 10:34:08 --> Total execution time: 0.0435
INFO - 2022-07-05 10:35:33 --> Config Class Initialized
INFO - 2022-07-05 10:35:33 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:35:33 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:35:33 --> Utf8 Class Initialized
INFO - 2022-07-05 10:35:33 --> URI Class Initialized
INFO - 2022-07-05 10:35:33 --> Router Class Initialized
INFO - 2022-07-05 10:35:33 --> Output Class Initialized
INFO - 2022-07-05 10:35:33 --> Security Class Initialized
DEBUG - 2022-07-05 10:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:35:33 --> Input Class Initialized
INFO - 2022-07-05 10:35:33 --> Language Class Initialized
INFO - 2022-07-05 10:35:33 --> Loader Class Initialized
INFO - 2022-07-05 10:35:33 --> Helper loaded: url_helper
INFO - 2022-07-05 10:35:33 --> Helper loaded: file_helper
INFO - 2022-07-05 10:35:33 --> Database Driver Class Initialized
INFO - 2022-07-05 10:35:33 --> Email Class Initialized
DEBUG - 2022-07-05 10:35:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:35:33 --> Controller Class Initialized
INFO - 2022-07-05 10:35:33 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:35:33 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:35:33 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:35:33 --> Final output sent to browser
DEBUG - 2022-07-05 10:35:33 --> Total execution time: 0.1260
INFO - 2022-07-05 10:38:49 --> Config Class Initialized
INFO - 2022-07-05 10:38:49 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:38:49 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:38:49 --> Utf8 Class Initialized
INFO - 2022-07-05 10:38:49 --> URI Class Initialized
INFO - 2022-07-05 10:38:49 --> Router Class Initialized
INFO - 2022-07-05 10:38:49 --> Output Class Initialized
INFO - 2022-07-05 10:38:49 --> Security Class Initialized
DEBUG - 2022-07-05 10:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:38:49 --> Input Class Initialized
INFO - 2022-07-05 10:38:49 --> Language Class Initialized
INFO - 2022-07-05 10:38:49 --> Loader Class Initialized
INFO - 2022-07-05 10:38:49 --> Helper loaded: url_helper
INFO - 2022-07-05 10:38:49 --> Helper loaded: file_helper
INFO - 2022-07-05 10:38:49 --> Database Driver Class Initialized
INFO - 2022-07-05 10:38:49 --> Email Class Initialized
DEBUG - 2022-07-05 10:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:38:49 --> Controller Class Initialized
INFO - 2022-07-05 10:38:49 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:38:49 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:38:50 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:38:50 --> Final output sent to browser
DEBUG - 2022-07-05 10:38:50 --> Total execution time: 0.1382
INFO - 2022-07-05 10:41:12 --> Config Class Initialized
INFO - 2022-07-05 10:41:12 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:41:12 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:41:12 --> Utf8 Class Initialized
INFO - 2022-07-05 10:41:12 --> URI Class Initialized
INFO - 2022-07-05 10:41:12 --> Router Class Initialized
INFO - 2022-07-05 10:41:12 --> Output Class Initialized
INFO - 2022-07-05 10:41:12 --> Security Class Initialized
DEBUG - 2022-07-05 10:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:41:12 --> Input Class Initialized
INFO - 2022-07-05 10:41:12 --> Language Class Initialized
INFO - 2022-07-05 10:41:12 --> Loader Class Initialized
INFO - 2022-07-05 10:41:12 --> Helper loaded: url_helper
INFO - 2022-07-05 10:41:12 --> Helper loaded: file_helper
INFO - 2022-07-05 10:41:12 --> Database Driver Class Initialized
INFO - 2022-07-05 10:41:12 --> Email Class Initialized
DEBUG - 2022-07-05 10:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:41:12 --> Controller Class Initialized
INFO - 2022-07-05 10:41:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:41:12 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:41:12 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:41:12 --> Final output sent to browser
DEBUG - 2022-07-05 10:41:12 --> Total execution time: 0.0213
INFO - 2022-07-05 10:41:42 --> Config Class Initialized
INFO - 2022-07-05 10:41:42 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:41:42 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:41:42 --> Utf8 Class Initialized
INFO - 2022-07-05 10:41:42 --> URI Class Initialized
INFO - 2022-07-05 10:41:42 --> Router Class Initialized
INFO - 2022-07-05 10:41:42 --> Output Class Initialized
INFO - 2022-07-05 10:41:42 --> Security Class Initialized
DEBUG - 2022-07-05 10:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:41:42 --> Input Class Initialized
INFO - 2022-07-05 10:41:42 --> Language Class Initialized
INFO - 2022-07-05 10:41:42 --> Loader Class Initialized
INFO - 2022-07-05 10:41:42 --> Helper loaded: url_helper
INFO - 2022-07-05 10:41:42 --> Helper loaded: file_helper
INFO - 2022-07-05 10:41:42 --> Database Driver Class Initialized
INFO - 2022-07-05 10:41:42 --> Email Class Initialized
DEBUG - 2022-07-05 10:41:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:41:42 --> Controller Class Initialized
INFO - 2022-07-05 10:41:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:41:42 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:41:42 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:41:42 --> Final output sent to browser
DEBUG - 2022-07-05 10:41:42 --> Total execution time: 0.1434
INFO - 2022-07-05 10:41:55 --> Config Class Initialized
INFO - 2022-07-05 10:41:55 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:41:55 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:41:55 --> Utf8 Class Initialized
INFO - 2022-07-05 10:41:55 --> URI Class Initialized
INFO - 2022-07-05 10:41:55 --> Router Class Initialized
INFO - 2022-07-05 10:41:55 --> Output Class Initialized
INFO - 2022-07-05 10:41:55 --> Security Class Initialized
DEBUG - 2022-07-05 10:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:41:55 --> Input Class Initialized
INFO - 2022-07-05 10:41:55 --> Language Class Initialized
INFO - 2022-07-05 10:41:55 --> Loader Class Initialized
INFO - 2022-07-05 10:41:55 --> Helper loaded: url_helper
INFO - 2022-07-05 10:41:55 --> Helper loaded: file_helper
INFO - 2022-07-05 10:41:55 --> Database Driver Class Initialized
INFO - 2022-07-05 10:41:55 --> Email Class Initialized
DEBUG - 2022-07-05 10:41:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:41:55 --> Controller Class Initialized
INFO - 2022-07-05 10:41:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:41:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:41:55 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:41:55 --> Final output sent to browser
DEBUG - 2022-07-05 10:41:55 --> Total execution time: 0.0337
INFO - 2022-07-05 10:42:25 --> Config Class Initialized
INFO - 2022-07-05 10:42:25 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:42:25 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:42:25 --> Utf8 Class Initialized
INFO - 2022-07-05 10:42:25 --> URI Class Initialized
INFO - 2022-07-05 10:42:25 --> Router Class Initialized
INFO - 2022-07-05 10:42:25 --> Output Class Initialized
INFO - 2022-07-05 10:42:25 --> Security Class Initialized
DEBUG - 2022-07-05 10:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:42:25 --> Input Class Initialized
INFO - 2022-07-05 10:42:25 --> Language Class Initialized
INFO - 2022-07-05 10:42:25 --> Loader Class Initialized
INFO - 2022-07-05 10:42:25 --> Helper loaded: url_helper
INFO - 2022-07-05 10:42:25 --> Helper loaded: file_helper
INFO - 2022-07-05 10:42:25 --> Database Driver Class Initialized
INFO - 2022-07-05 10:42:25 --> Email Class Initialized
DEBUG - 2022-07-05 10:42:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:42:25 --> Controller Class Initialized
INFO - 2022-07-05 10:42:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:42:25 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:42:25 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:42:25 --> Final output sent to browser
DEBUG - 2022-07-05 10:42:25 --> Total execution time: 0.0447
INFO - 2022-07-05 10:43:16 --> Config Class Initialized
INFO - 2022-07-05 10:43:16 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:43:16 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:43:16 --> Utf8 Class Initialized
INFO - 2022-07-05 10:43:16 --> URI Class Initialized
INFO - 2022-07-05 10:43:16 --> Router Class Initialized
INFO - 2022-07-05 10:43:16 --> Output Class Initialized
INFO - 2022-07-05 10:43:16 --> Security Class Initialized
DEBUG - 2022-07-05 10:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:43:16 --> Input Class Initialized
INFO - 2022-07-05 10:43:16 --> Language Class Initialized
INFO - 2022-07-05 10:43:16 --> Loader Class Initialized
INFO - 2022-07-05 10:43:16 --> Helper loaded: url_helper
INFO - 2022-07-05 10:43:16 --> Helper loaded: file_helper
INFO - 2022-07-05 10:43:16 --> Database Driver Class Initialized
INFO - 2022-07-05 10:43:16 --> Email Class Initialized
DEBUG - 2022-07-05 10:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:43:16 --> Controller Class Initialized
INFO - 2022-07-05 10:43:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:43:16 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:43:16 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:43:16 --> Final output sent to browser
DEBUG - 2022-07-05 10:43:16 --> Total execution time: 0.0210
INFO - 2022-07-05 10:43:40 --> Config Class Initialized
INFO - 2022-07-05 10:43:40 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:43:40 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:43:40 --> Utf8 Class Initialized
INFO - 2022-07-05 10:43:40 --> URI Class Initialized
INFO - 2022-07-05 10:43:40 --> Router Class Initialized
INFO - 2022-07-05 10:43:40 --> Output Class Initialized
INFO - 2022-07-05 10:43:40 --> Security Class Initialized
DEBUG - 2022-07-05 10:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:43:40 --> Input Class Initialized
INFO - 2022-07-05 10:43:40 --> Language Class Initialized
INFO - 2022-07-05 10:43:40 --> Loader Class Initialized
INFO - 2022-07-05 10:43:40 --> Helper loaded: url_helper
INFO - 2022-07-05 10:43:40 --> Helper loaded: file_helper
INFO - 2022-07-05 10:43:40 --> Database Driver Class Initialized
INFO - 2022-07-05 10:43:40 --> Email Class Initialized
DEBUG - 2022-07-05 10:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:43:40 --> Controller Class Initialized
INFO - 2022-07-05 10:43:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:43:40 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:43:40 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:43:40 --> Final output sent to browser
DEBUG - 2022-07-05 10:43:40 --> Total execution time: 0.0630
INFO - 2022-07-05 10:43:45 --> Config Class Initialized
INFO - 2022-07-05 10:43:45 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:43:45 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:43:45 --> Utf8 Class Initialized
INFO - 2022-07-05 10:43:45 --> URI Class Initialized
INFO - 2022-07-05 10:43:45 --> Router Class Initialized
INFO - 2022-07-05 10:43:45 --> Output Class Initialized
INFO - 2022-07-05 10:43:45 --> Security Class Initialized
DEBUG - 2022-07-05 10:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:43:45 --> Input Class Initialized
INFO - 2022-07-05 10:43:45 --> Language Class Initialized
INFO - 2022-07-05 10:43:45 --> Loader Class Initialized
INFO - 2022-07-05 10:43:45 --> Helper loaded: url_helper
INFO - 2022-07-05 10:43:45 --> Helper loaded: file_helper
INFO - 2022-07-05 10:43:45 --> Database Driver Class Initialized
INFO - 2022-07-05 10:43:45 --> Email Class Initialized
DEBUG - 2022-07-05 10:43:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:43:45 --> Controller Class Initialized
INFO - 2022-07-05 10:43:45 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:43:45 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:43:45 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:43:45 --> Final output sent to browser
DEBUG - 2022-07-05 10:43:45 --> Total execution time: 0.0377
INFO - 2022-07-05 10:44:05 --> Config Class Initialized
INFO - 2022-07-05 10:44:05 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:44:05 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:44:05 --> Utf8 Class Initialized
INFO - 2022-07-05 10:44:05 --> URI Class Initialized
INFO - 2022-07-05 10:44:05 --> Router Class Initialized
INFO - 2022-07-05 10:44:05 --> Output Class Initialized
INFO - 2022-07-05 10:44:05 --> Security Class Initialized
DEBUG - 2022-07-05 10:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:44:05 --> Input Class Initialized
INFO - 2022-07-05 10:44:05 --> Language Class Initialized
INFO - 2022-07-05 10:44:05 --> Loader Class Initialized
INFO - 2022-07-05 10:44:05 --> Helper loaded: url_helper
INFO - 2022-07-05 10:44:05 --> Helper loaded: file_helper
INFO - 2022-07-05 10:44:05 --> Database Driver Class Initialized
INFO - 2022-07-05 10:44:05 --> Email Class Initialized
DEBUG - 2022-07-05 10:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:44:05 --> Controller Class Initialized
INFO - 2022-07-05 10:44:05 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:44:05 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:44:05 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:44:05 --> Final output sent to browser
DEBUG - 2022-07-05 10:44:05 --> Total execution time: 0.1230
INFO - 2022-07-05 10:44:55 --> Config Class Initialized
INFO - 2022-07-05 10:44:55 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:44:55 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:44:55 --> Utf8 Class Initialized
INFO - 2022-07-05 10:44:55 --> URI Class Initialized
INFO - 2022-07-05 10:44:55 --> Router Class Initialized
INFO - 2022-07-05 10:44:55 --> Output Class Initialized
INFO - 2022-07-05 10:44:55 --> Security Class Initialized
DEBUG - 2022-07-05 10:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:44:55 --> Input Class Initialized
INFO - 2022-07-05 10:44:55 --> Language Class Initialized
INFO - 2022-07-05 10:44:55 --> Loader Class Initialized
INFO - 2022-07-05 10:44:55 --> Helper loaded: url_helper
INFO - 2022-07-05 10:44:55 --> Helper loaded: file_helper
INFO - 2022-07-05 10:44:55 --> Database Driver Class Initialized
INFO - 2022-07-05 10:44:55 --> Email Class Initialized
DEBUG - 2022-07-05 10:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:44:55 --> Controller Class Initialized
INFO - 2022-07-05 10:44:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:44:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:44:55 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:44:55 --> Final output sent to browser
DEBUG - 2022-07-05 10:44:55 --> Total execution time: 0.1303
INFO - 2022-07-05 10:45:08 --> Config Class Initialized
INFO - 2022-07-05 10:45:08 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:45:08 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:45:08 --> Utf8 Class Initialized
INFO - 2022-07-05 10:45:08 --> URI Class Initialized
INFO - 2022-07-05 10:45:08 --> Router Class Initialized
INFO - 2022-07-05 10:45:08 --> Output Class Initialized
INFO - 2022-07-05 10:45:08 --> Security Class Initialized
DEBUG - 2022-07-05 10:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:45:08 --> Input Class Initialized
INFO - 2022-07-05 10:45:08 --> Language Class Initialized
INFO - 2022-07-05 10:45:08 --> Loader Class Initialized
INFO - 2022-07-05 10:45:08 --> Helper loaded: url_helper
INFO - 2022-07-05 10:45:08 --> Helper loaded: file_helper
INFO - 2022-07-05 10:45:08 --> Database Driver Class Initialized
INFO - 2022-07-05 10:45:08 --> Email Class Initialized
DEBUG - 2022-07-05 10:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:45:08 --> Controller Class Initialized
INFO - 2022-07-05 10:45:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:45:08 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:45:08 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:45:08 --> Final output sent to browser
DEBUG - 2022-07-05 10:45:08 --> Total execution time: 0.0199
INFO - 2022-07-05 10:46:48 --> Config Class Initialized
INFO - 2022-07-05 10:46:48 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:46:48 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:46:48 --> Utf8 Class Initialized
INFO - 2022-07-05 10:46:48 --> URI Class Initialized
INFO - 2022-07-05 10:46:48 --> Router Class Initialized
INFO - 2022-07-05 10:46:48 --> Output Class Initialized
INFO - 2022-07-05 10:46:48 --> Security Class Initialized
DEBUG - 2022-07-05 10:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:46:48 --> Input Class Initialized
INFO - 2022-07-05 10:46:48 --> Language Class Initialized
INFO - 2022-07-05 10:46:48 --> Loader Class Initialized
INFO - 2022-07-05 10:46:48 --> Helper loaded: url_helper
INFO - 2022-07-05 10:46:48 --> Helper loaded: file_helper
INFO - 2022-07-05 10:46:48 --> Database Driver Class Initialized
INFO - 2022-07-05 10:46:48 --> Email Class Initialized
DEBUG - 2022-07-05 10:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:46:48 --> Controller Class Initialized
INFO - 2022-07-05 10:46:48 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:46:48 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:46:48 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:46:48 --> Final output sent to browser
DEBUG - 2022-07-05 10:46:48 --> Total execution time: 0.1249
INFO - 2022-07-05 10:46:56 --> Config Class Initialized
INFO - 2022-07-05 10:46:56 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:46:56 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:46:56 --> Utf8 Class Initialized
INFO - 2022-07-05 10:46:56 --> URI Class Initialized
INFO - 2022-07-05 10:46:56 --> Router Class Initialized
INFO - 2022-07-05 10:46:56 --> Output Class Initialized
INFO - 2022-07-05 10:46:56 --> Security Class Initialized
DEBUG - 2022-07-05 10:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:46:56 --> Input Class Initialized
INFO - 2022-07-05 10:46:56 --> Language Class Initialized
INFO - 2022-07-05 10:46:56 --> Loader Class Initialized
INFO - 2022-07-05 10:46:56 --> Helper loaded: url_helper
INFO - 2022-07-05 10:46:56 --> Helper loaded: file_helper
INFO - 2022-07-05 10:46:56 --> Database Driver Class Initialized
INFO - 2022-07-05 10:46:56 --> Email Class Initialized
DEBUG - 2022-07-05 10:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:46:56 --> Controller Class Initialized
INFO - 2022-07-05 10:46:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:46:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:46:56 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:46:56 --> Final output sent to browser
DEBUG - 2022-07-05 10:46:56 --> Total execution time: 0.0402
INFO - 2022-07-05 10:47:14 --> Config Class Initialized
INFO - 2022-07-05 10:47:14 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:47:14 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:47:14 --> Utf8 Class Initialized
INFO - 2022-07-05 10:47:14 --> URI Class Initialized
INFO - 2022-07-05 10:47:14 --> Router Class Initialized
INFO - 2022-07-05 10:47:14 --> Output Class Initialized
INFO - 2022-07-05 10:47:14 --> Security Class Initialized
DEBUG - 2022-07-05 10:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:47:14 --> Input Class Initialized
INFO - 2022-07-05 10:47:14 --> Language Class Initialized
INFO - 2022-07-05 10:47:14 --> Loader Class Initialized
INFO - 2022-07-05 10:47:14 --> Helper loaded: url_helper
INFO - 2022-07-05 10:47:14 --> Helper loaded: file_helper
INFO - 2022-07-05 10:47:14 --> Database Driver Class Initialized
INFO - 2022-07-05 10:47:14 --> Email Class Initialized
DEBUG - 2022-07-05 10:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:47:14 --> Controller Class Initialized
INFO - 2022-07-05 10:47:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:47:14 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:47:14 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:47:14 --> Final output sent to browser
DEBUG - 2022-07-05 10:47:14 --> Total execution time: 0.0465
INFO - 2022-07-05 10:47:29 --> Config Class Initialized
INFO - 2022-07-05 10:47:29 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:47:29 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:47:29 --> Utf8 Class Initialized
INFO - 2022-07-05 10:47:29 --> URI Class Initialized
INFO - 2022-07-05 10:47:29 --> Router Class Initialized
INFO - 2022-07-05 10:47:29 --> Output Class Initialized
INFO - 2022-07-05 10:47:29 --> Security Class Initialized
DEBUG - 2022-07-05 10:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:47:29 --> Input Class Initialized
INFO - 2022-07-05 10:47:29 --> Language Class Initialized
INFO - 2022-07-05 10:47:29 --> Loader Class Initialized
INFO - 2022-07-05 10:47:29 --> Helper loaded: url_helper
INFO - 2022-07-05 10:47:29 --> Helper loaded: file_helper
INFO - 2022-07-05 10:47:29 --> Database Driver Class Initialized
INFO - 2022-07-05 10:47:29 --> Email Class Initialized
DEBUG - 2022-07-05 10:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:47:29 --> Controller Class Initialized
INFO - 2022-07-05 10:47:29 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:47:29 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:47:29 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:47:29 --> Final output sent to browser
DEBUG - 2022-07-05 10:47:29 --> Total execution time: 0.0199
INFO - 2022-07-05 10:48:54 --> Config Class Initialized
INFO - 2022-07-05 10:48:54 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:48:54 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:48:54 --> Utf8 Class Initialized
INFO - 2022-07-05 10:48:54 --> URI Class Initialized
INFO - 2022-07-05 10:48:54 --> Router Class Initialized
INFO - 2022-07-05 10:48:54 --> Output Class Initialized
INFO - 2022-07-05 10:48:54 --> Security Class Initialized
DEBUG - 2022-07-05 10:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:48:54 --> Input Class Initialized
INFO - 2022-07-05 10:48:54 --> Language Class Initialized
INFO - 2022-07-05 10:48:54 --> Loader Class Initialized
INFO - 2022-07-05 10:48:54 --> Helper loaded: url_helper
INFO - 2022-07-05 10:48:54 --> Helper loaded: file_helper
INFO - 2022-07-05 10:48:54 --> Database Driver Class Initialized
INFO - 2022-07-05 10:48:54 --> Email Class Initialized
DEBUG - 2022-07-05 10:48:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:48:54 --> Controller Class Initialized
INFO - 2022-07-05 10:48:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:48:54 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:48:54 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:48:54 --> Final output sent to browser
DEBUG - 2022-07-05 10:48:54 --> Total execution time: 0.0647
INFO - 2022-07-05 10:50:05 --> Config Class Initialized
INFO - 2022-07-05 10:50:05 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:50:05 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:50:05 --> Utf8 Class Initialized
INFO - 2022-07-05 10:50:05 --> URI Class Initialized
INFO - 2022-07-05 10:50:05 --> Router Class Initialized
INFO - 2022-07-05 10:50:05 --> Output Class Initialized
INFO - 2022-07-05 10:50:05 --> Security Class Initialized
DEBUG - 2022-07-05 10:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:50:05 --> Input Class Initialized
INFO - 2022-07-05 10:50:05 --> Language Class Initialized
INFO - 2022-07-05 10:50:05 --> Loader Class Initialized
INFO - 2022-07-05 10:50:05 --> Helper loaded: url_helper
INFO - 2022-07-05 10:50:05 --> Helper loaded: file_helper
INFO - 2022-07-05 10:50:05 --> Database Driver Class Initialized
INFO - 2022-07-05 10:50:05 --> Email Class Initialized
DEBUG - 2022-07-05 10:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:50:05 --> Controller Class Initialized
INFO - 2022-07-05 10:50:05 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:50:05 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:50:05 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:50:05 --> Final output sent to browser
DEBUG - 2022-07-05 10:50:05 --> Total execution time: 0.0250
INFO - 2022-07-05 10:50:58 --> Config Class Initialized
INFO - 2022-07-05 10:50:58 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:50:58 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:50:58 --> Utf8 Class Initialized
INFO - 2022-07-05 10:50:58 --> URI Class Initialized
INFO - 2022-07-05 10:50:58 --> Router Class Initialized
INFO - 2022-07-05 10:50:58 --> Output Class Initialized
INFO - 2022-07-05 10:50:58 --> Security Class Initialized
DEBUG - 2022-07-05 10:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:50:58 --> Input Class Initialized
INFO - 2022-07-05 10:50:58 --> Language Class Initialized
INFO - 2022-07-05 10:50:58 --> Loader Class Initialized
INFO - 2022-07-05 10:50:58 --> Helper loaded: url_helper
INFO - 2022-07-05 10:50:58 --> Helper loaded: file_helper
INFO - 2022-07-05 10:50:58 --> Database Driver Class Initialized
INFO - 2022-07-05 10:50:58 --> Email Class Initialized
DEBUG - 2022-07-05 10:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:50:58 --> Controller Class Initialized
INFO - 2022-07-05 10:50:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:50:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:50:58 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:50:58 --> Final output sent to browser
DEBUG - 2022-07-05 10:50:58 --> Total execution time: 0.0202
INFO - 2022-07-05 10:51:55 --> Config Class Initialized
INFO - 2022-07-05 10:51:55 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:51:55 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:51:55 --> Utf8 Class Initialized
INFO - 2022-07-05 10:51:55 --> URI Class Initialized
INFO - 2022-07-05 10:51:55 --> Router Class Initialized
INFO - 2022-07-05 10:51:55 --> Output Class Initialized
INFO - 2022-07-05 10:51:55 --> Security Class Initialized
DEBUG - 2022-07-05 10:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:51:55 --> Input Class Initialized
INFO - 2022-07-05 10:51:55 --> Language Class Initialized
INFO - 2022-07-05 10:51:55 --> Loader Class Initialized
INFO - 2022-07-05 10:51:55 --> Helper loaded: url_helper
INFO - 2022-07-05 10:51:55 --> Helper loaded: file_helper
INFO - 2022-07-05 10:51:55 --> Database Driver Class Initialized
INFO - 2022-07-05 10:51:55 --> Email Class Initialized
DEBUG - 2022-07-05 10:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:51:55 --> Controller Class Initialized
INFO - 2022-07-05 10:51:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:51:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:51:55 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:51:55 --> Final output sent to browser
DEBUG - 2022-07-05 10:51:55 --> Total execution time: 0.0236
INFO - 2022-07-05 10:53:44 --> Config Class Initialized
INFO - 2022-07-05 10:53:44 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:53:44 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:53:44 --> Utf8 Class Initialized
INFO - 2022-07-05 10:53:44 --> URI Class Initialized
INFO - 2022-07-05 10:53:44 --> Router Class Initialized
INFO - 2022-07-05 10:53:44 --> Output Class Initialized
INFO - 2022-07-05 10:53:44 --> Security Class Initialized
DEBUG - 2022-07-05 10:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:53:44 --> Input Class Initialized
INFO - 2022-07-05 10:53:44 --> Language Class Initialized
INFO - 2022-07-05 10:53:44 --> Loader Class Initialized
INFO - 2022-07-05 10:53:44 --> Helper loaded: url_helper
INFO - 2022-07-05 10:53:44 --> Helper loaded: file_helper
INFO - 2022-07-05 10:53:44 --> Database Driver Class Initialized
INFO - 2022-07-05 10:53:44 --> Email Class Initialized
DEBUG - 2022-07-05 10:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:53:44 --> Controller Class Initialized
INFO - 2022-07-05 10:53:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:53:44 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:53:44 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:53:44 --> Final output sent to browser
DEBUG - 2022-07-05 10:53:44 --> Total execution time: 0.0277
INFO - 2022-07-05 10:53:54 --> Config Class Initialized
INFO - 2022-07-05 10:53:54 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:53:54 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:53:54 --> Utf8 Class Initialized
INFO - 2022-07-05 10:53:54 --> URI Class Initialized
INFO - 2022-07-05 10:53:54 --> Router Class Initialized
INFO - 2022-07-05 10:53:54 --> Output Class Initialized
INFO - 2022-07-05 10:53:54 --> Security Class Initialized
DEBUG - 2022-07-05 10:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:53:54 --> Input Class Initialized
INFO - 2022-07-05 10:53:54 --> Language Class Initialized
INFO - 2022-07-05 10:53:54 --> Loader Class Initialized
INFO - 2022-07-05 10:53:54 --> Helper loaded: url_helper
INFO - 2022-07-05 10:53:54 --> Helper loaded: file_helper
INFO - 2022-07-05 10:53:54 --> Database Driver Class Initialized
INFO - 2022-07-05 10:53:54 --> Email Class Initialized
DEBUG - 2022-07-05 10:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:53:54 --> Controller Class Initialized
INFO - 2022-07-05 10:53:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:53:54 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:53:54 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:53:54 --> Final output sent to browser
DEBUG - 2022-07-05 10:53:54 --> Total execution time: 0.0214
INFO - 2022-07-05 10:54:28 --> Config Class Initialized
INFO - 2022-07-05 10:54:28 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:54:28 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:54:28 --> Utf8 Class Initialized
INFO - 2022-07-05 10:54:28 --> URI Class Initialized
INFO - 2022-07-05 10:54:28 --> Router Class Initialized
INFO - 2022-07-05 10:54:28 --> Output Class Initialized
INFO - 2022-07-05 10:54:28 --> Security Class Initialized
DEBUG - 2022-07-05 10:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:54:28 --> Input Class Initialized
INFO - 2022-07-05 10:54:28 --> Language Class Initialized
INFO - 2022-07-05 10:54:28 --> Loader Class Initialized
INFO - 2022-07-05 10:54:28 --> Helper loaded: url_helper
INFO - 2022-07-05 10:54:28 --> Helper loaded: file_helper
INFO - 2022-07-05 10:54:28 --> Database Driver Class Initialized
INFO - 2022-07-05 10:54:28 --> Email Class Initialized
DEBUG - 2022-07-05 10:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:54:28 --> Controller Class Initialized
INFO - 2022-07-05 10:54:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:54:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:54:28 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:54:28 --> Final output sent to browser
DEBUG - 2022-07-05 10:54:28 --> Total execution time: 0.0208
INFO - 2022-07-05 10:55:46 --> Config Class Initialized
INFO - 2022-07-05 10:55:46 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:55:46 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:55:46 --> Utf8 Class Initialized
INFO - 2022-07-05 10:55:46 --> URI Class Initialized
INFO - 2022-07-05 10:55:46 --> Router Class Initialized
INFO - 2022-07-05 10:55:46 --> Output Class Initialized
INFO - 2022-07-05 10:55:46 --> Security Class Initialized
DEBUG - 2022-07-05 10:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:55:46 --> Input Class Initialized
INFO - 2022-07-05 10:55:46 --> Language Class Initialized
INFO - 2022-07-05 10:55:46 --> Loader Class Initialized
INFO - 2022-07-05 10:55:46 --> Helper loaded: url_helper
INFO - 2022-07-05 10:55:46 --> Helper loaded: file_helper
INFO - 2022-07-05 10:55:46 --> Database Driver Class Initialized
INFO - 2022-07-05 10:55:46 --> Email Class Initialized
DEBUG - 2022-07-05 10:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:55:46 --> Controller Class Initialized
INFO - 2022-07-05 10:55:46 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:55:46 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:55:46 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:55:46 --> Final output sent to browser
DEBUG - 2022-07-05 10:55:46 --> Total execution time: 0.0204
INFO - 2022-07-05 10:56:16 --> Config Class Initialized
INFO - 2022-07-05 10:56:16 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:56:16 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:56:16 --> Utf8 Class Initialized
INFO - 2022-07-05 10:56:16 --> URI Class Initialized
INFO - 2022-07-05 10:56:16 --> Router Class Initialized
INFO - 2022-07-05 10:56:16 --> Output Class Initialized
INFO - 2022-07-05 10:56:16 --> Security Class Initialized
DEBUG - 2022-07-05 10:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:56:16 --> Input Class Initialized
INFO - 2022-07-05 10:56:16 --> Language Class Initialized
INFO - 2022-07-05 10:56:16 --> Loader Class Initialized
INFO - 2022-07-05 10:56:16 --> Helper loaded: url_helper
INFO - 2022-07-05 10:56:16 --> Helper loaded: file_helper
INFO - 2022-07-05 10:56:16 --> Database Driver Class Initialized
INFO - 2022-07-05 10:56:16 --> Email Class Initialized
DEBUG - 2022-07-05 10:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:56:16 --> Controller Class Initialized
INFO - 2022-07-05 10:56:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:56:16 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:56:16 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:56:16 --> Final output sent to browser
DEBUG - 2022-07-05 10:56:16 --> Total execution time: 0.0558
INFO - 2022-07-05 10:56:46 --> Config Class Initialized
INFO - 2022-07-05 10:56:46 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:56:46 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:56:46 --> Utf8 Class Initialized
INFO - 2022-07-05 10:56:46 --> URI Class Initialized
INFO - 2022-07-05 10:56:46 --> Router Class Initialized
INFO - 2022-07-05 10:56:46 --> Output Class Initialized
INFO - 2022-07-05 10:56:46 --> Security Class Initialized
DEBUG - 2022-07-05 10:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:56:46 --> Input Class Initialized
INFO - 2022-07-05 10:56:46 --> Language Class Initialized
INFO - 2022-07-05 10:56:46 --> Loader Class Initialized
INFO - 2022-07-05 10:56:46 --> Helper loaded: url_helper
INFO - 2022-07-05 10:56:46 --> Helper loaded: file_helper
INFO - 2022-07-05 10:56:46 --> Database Driver Class Initialized
INFO - 2022-07-05 10:56:46 --> Email Class Initialized
DEBUG - 2022-07-05 10:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:56:46 --> Controller Class Initialized
INFO - 2022-07-05 10:56:46 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:56:46 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:56:46 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:56:46 --> Final output sent to browser
DEBUG - 2022-07-05 10:56:46 --> Total execution time: 0.0461
INFO - 2022-07-05 10:56:56 --> Config Class Initialized
INFO - 2022-07-05 10:56:56 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:56:56 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:56:56 --> Utf8 Class Initialized
INFO - 2022-07-05 10:56:56 --> URI Class Initialized
INFO - 2022-07-05 10:56:56 --> Router Class Initialized
INFO - 2022-07-05 10:56:56 --> Output Class Initialized
INFO - 2022-07-05 10:56:56 --> Security Class Initialized
DEBUG - 2022-07-05 10:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:56:56 --> Input Class Initialized
INFO - 2022-07-05 10:56:56 --> Language Class Initialized
INFO - 2022-07-05 10:56:56 --> Loader Class Initialized
INFO - 2022-07-05 10:56:56 --> Helper loaded: url_helper
INFO - 2022-07-05 10:56:56 --> Helper loaded: file_helper
INFO - 2022-07-05 10:56:56 --> Database Driver Class Initialized
INFO - 2022-07-05 10:56:56 --> Email Class Initialized
DEBUG - 2022-07-05 10:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:56:56 --> Controller Class Initialized
INFO - 2022-07-05 10:56:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:56:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:56:56 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:56:56 --> Final output sent to browser
DEBUG - 2022-07-05 10:56:56 --> Total execution time: 0.1466
INFO - 2022-07-05 10:57:08 --> Config Class Initialized
INFO - 2022-07-05 10:57:08 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:57:08 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:57:08 --> Utf8 Class Initialized
INFO - 2022-07-05 10:57:08 --> URI Class Initialized
INFO - 2022-07-05 10:57:08 --> Router Class Initialized
INFO - 2022-07-05 10:57:08 --> Output Class Initialized
INFO - 2022-07-05 10:57:08 --> Security Class Initialized
DEBUG - 2022-07-05 10:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:57:08 --> Input Class Initialized
INFO - 2022-07-05 10:57:08 --> Language Class Initialized
INFO - 2022-07-05 10:57:08 --> Loader Class Initialized
INFO - 2022-07-05 10:57:08 --> Helper loaded: url_helper
INFO - 2022-07-05 10:57:08 --> Helper loaded: file_helper
INFO - 2022-07-05 10:57:08 --> Database Driver Class Initialized
INFO - 2022-07-05 10:57:08 --> Email Class Initialized
DEBUG - 2022-07-05 10:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:57:08 --> Controller Class Initialized
INFO - 2022-07-05 10:57:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:57:08 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:57:08 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:57:08 --> Final output sent to browser
DEBUG - 2022-07-05 10:57:08 --> Total execution time: 0.0206
INFO - 2022-07-05 10:58:01 --> Config Class Initialized
INFO - 2022-07-05 10:58:01 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:58:01 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:58:01 --> Utf8 Class Initialized
INFO - 2022-07-05 10:58:01 --> URI Class Initialized
INFO - 2022-07-05 10:58:01 --> Router Class Initialized
INFO - 2022-07-05 10:58:01 --> Output Class Initialized
INFO - 2022-07-05 10:58:01 --> Security Class Initialized
DEBUG - 2022-07-05 10:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:58:01 --> Input Class Initialized
INFO - 2022-07-05 10:58:01 --> Language Class Initialized
INFO - 2022-07-05 10:58:01 --> Loader Class Initialized
INFO - 2022-07-05 10:58:01 --> Helper loaded: url_helper
INFO - 2022-07-05 10:58:01 --> Helper loaded: file_helper
INFO - 2022-07-05 10:58:01 --> Database Driver Class Initialized
INFO - 2022-07-05 10:58:01 --> Email Class Initialized
DEBUG - 2022-07-05 10:58:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:58:01 --> Controller Class Initialized
INFO - 2022-07-05 10:58:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:58:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:58:01 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:58:01 --> Final output sent to browser
DEBUG - 2022-07-05 10:58:01 --> Total execution time: 0.0210
INFO - 2022-07-05 10:58:07 --> Config Class Initialized
INFO - 2022-07-05 10:58:07 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:58:07 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:58:07 --> Utf8 Class Initialized
INFO - 2022-07-05 10:58:07 --> URI Class Initialized
INFO - 2022-07-05 10:58:07 --> Router Class Initialized
INFO - 2022-07-05 10:58:07 --> Output Class Initialized
INFO - 2022-07-05 10:58:07 --> Security Class Initialized
DEBUG - 2022-07-05 10:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:58:07 --> Input Class Initialized
INFO - 2022-07-05 10:58:07 --> Language Class Initialized
INFO - 2022-07-05 10:58:07 --> Loader Class Initialized
INFO - 2022-07-05 10:58:07 --> Helper loaded: url_helper
INFO - 2022-07-05 10:58:07 --> Helper loaded: file_helper
INFO - 2022-07-05 10:58:07 --> Database Driver Class Initialized
INFO - 2022-07-05 10:58:07 --> Email Class Initialized
DEBUG - 2022-07-05 10:58:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:58:07 --> Controller Class Initialized
INFO - 2022-07-05 10:58:07 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:58:07 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:58:07 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:58:07 --> Final output sent to browser
DEBUG - 2022-07-05 10:58:07 --> Total execution time: 0.0174
INFO - 2022-07-05 10:58:08 --> Config Class Initialized
INFO - 2022-07-05 10:58:08 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:58:08 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:58:08 --> Utf8 Class Initialized
INFO - 2022-07-05 10:58:08 --> URI Class Initialized
INFO - 2022-07-05 10:58:08 --> Router Class Initialized
INFO - 2022-07-05 10:58:08 --> Output Class Initialized
INFO - 2022-07-05 10:58:08 --> Security Class Initialized
DEBUG - 2022-07-05 10:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:58:08 --> Input Class Initialized
INFO - 2022-07-05 10:58:08 --> Language Class Initialized
INFO - 2022-07-05 10:58:08 --> Loader Class Initialized
INFO - 2022-07-05 10:58:08 --> Helper loaded: url_helper
INFO - 2022-07-05 10:58:08 --> Helper loaded: file_helper
INFO - 2022-07-05 10:58:08 --> Database Driver Class Initialized
INFO - 2022-07-05 10:58:08 --> Email Class Initialized
DEBUG - 2022-07-05 10:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:58:08 --> Controller Class Initialized
INFO - 2022-07-05 10:58:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:58:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-05 10:58:08 --> Severity: Notice --> Undefined variable: td_id_fk C:\wamp64\www\qr\application\views\filldetails\filldetails.php 278
INFO - 2022-07-05 10:58:08 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-07-05 10:58:08 --> Final output sent to browser
DEBUG - 2022-07-05 10:58:08 --> Total execution time: 0.0585
INFO - 2022-07-05 10:58:08 --> Config Class Initialized
INFO - 2022-07-05 10:58:08 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:58:08 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:58:08 --> Utf8 Class Initialized
INFO - 2022-07-05 10:58:08 --> URI Class Initialized
INFO - 2022-07-05 10:58:08 --> Router Class Initialized
INFO - 2022-07-05 10:58:08 --> Output Class Initialized
INFO - 2022-07-05 10:58:08 --> Security Class Initialized
DEBUG - 2022-07-05 10:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:58:08 --> Input Class Initialized
INFO - 2022-07-05 10:58:08 --> Language Class Initialized
INFO - 2022-07-05 10:58:08 --> Loader Class Initialized
INFO - 2022-07-05 10:58:08 --> Helper loaded: url_helper
INFO - 2022-07-05 10:58:08 --> Helper loaded: file_helper
INFO - 2022-07-05 10:58:08 --> Database Driver Class Initialized
INFO - 2022-07-05 10:58:08 --> Email Class Initialized
DEBUG - 2022-07-05 10:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:58:08 --> Controller Class Initialized
INFO - 2022-07-05 10:58:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:58:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-05 10:58:08 --> Severity: Notice --> Undefined variable: td_id_fk C:\wamp64\www\qr\application\views\filldetails\filldetails.php 278
INFO - 2022-07-05 10:58:08 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-07-05 10:58:08 --> Final output sent to browser
DEBUG - 2022-07-05 10:58:08 --> Total execution time: 0.0398
INFO - 2022-07-05 10:58:11 --> Config Class Initialized
INFO - 2022-07-05 10:58:11 --> Hooks Class Initialized
DEBUG - 2022-07-05 10:58:11 --> UTF-8 Support Enabled
INFO - 2022-07-05 10:58:11 --> Utf8 Class Initialized
INFO - 2022-07-05 10:58:11 --> URI Class Initialized
INFO - 2022-07-05 10:58:11 --> Router Class Initialized
INFO - 2022-07-05 10:58:11 --> Output Class Initialized
INFO - 2022-07-05 10:58:11 --> Security Class Initialized
DEBUG - 2022-07-05 10:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 10:58:11 --> Input Class Initialized
INFO - 2022-07-05 10:58:11 --> Language Class Initialized
INFO - 2022-07-05 10:58:11 --> Loader Class Initialized
INFO - 2022-07-05 10:58:11 --> Helper loaded: url_helper
INFO - 2022-07-05 10:58:11 --> Helper loaded: file_helper
INFO - 2022-07-05 10:58:11 --> Database Driver Class Initialized
INFO - 2022-07-05 10:58:11 --> Email Class Initialized
DEBUG - 2022-07-05 10:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 10:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 10:58:11 --> Controller Class Initialized
INFO - 2022-07-05 10:58:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 10:58:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 10:58:11 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 10:58:11 --> Final output sent to browser
DEBUG - 2022-07-05 10:58:11 --> Total execution time: 0.0397
INFO - 2022-07-05 11:10:14 --> Config Class Initialized
INFO - 2022-07-05 11:10:14 --> Hooks Class Initialized
DEBUG - 2022-07-05 11:10:14 --> UTF-8 Support Enabled
INFO - 2022-07-05 11:10:14 --> Utf8 Class Initialized
INFO - 2022-07-05 11:10:14 --> URI Class Initialized
INFO - 2022-07-05 11:10:14 --> Router Class Initialized
INFO - 2022-07-05 11:10:14 --> Output Class Initialized
INFO - 2022-07-05 11:10:14 --> Security Class Initialized
DEBUG - 2022-07-05 11:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 11:10:14 --> Input Class Initialized
INFO - 2022-07-05 11:10:14 --> Language Class Initialized
INFO - 2022-07-05 11:10:14 --> Loader Class Initialized
INFO - 2022-07-05 11:10:14 --> Helper loaded: url_helper
INFO - 2022-07-05 11:10:14 --> Helper loaded: file_helper
INFO - 2022-07-05 11:10:14 --> Database Driver Class Initialized
INFO - 2022-07-05 11:10:14 --> Email Class Initialized
DEBUG - 2022-07-05 11:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 11:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 11:10:14 --> Controller Class Initialized
INFO - 2022-07-05 11:10:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 11:10:14 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 11:10:14 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 11:10:14 --> Final output sent to browser
DEBUG - 2022-07-05 11:10:14 --> Total execution time: 0.5840
INFO - 2022-07-05 11:10:16 --> Config Class Initialized
INFO - 2022-07-05 11:10:16 --> Hooks Class Initialized
DEBUG - 2022-07-05 11:10:16 --> UTF-8 Support Enabled
INFO - 2022-07-05 11:10:16 --> Utf8 Class Initialized
INFO - 2022-07-05 11:10:16 --> URI Class Initialized
INFO - 2022-07-05 11:10:16 --> Router Class Initialized
INFO - 2022-07-05 11:10:16 --> Output Class Initialized
INFO - 2022-07-05 11:10:16 --> Security Class Initialized
DEBUG - 2022-07-05 11:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 11:10:16 --> Input Class Initialized
INFO - 2022-07-05 11:10:16 --> Language Class Initialized
INFO - 2022-07-05 11:10:16 --> Loader Class Initialized
INFO - 2022-07-05 11:10:16 --> Helper loaded: url_helper
INFO - 2022-07-05 11:10:16 --> Helper loaded: file_helper
INFO - 2022-07-05 11:10:16 --> Database Driver Class Initialized
INFO - 2022-07-05 11:10:17 --> Email Class Initialized
DEBUG - 2022-07-05 11:10:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 11:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 11:10:17 --> Controller Class Initialized
INFO - 2022-07-05 11:10:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 11:10:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 11:10:17 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 11:10:17 --> Final output sent to browser
DEBUG - 2022-07-05 11:10:17 --> Total execution time: 0.1110
INFO - 2022-07-05 11:10:18 --> Config Class Initialized
INFO - 2022-07-05 11:10:18 --> Hooks Class Initialized
DEBUG - 2022-07-05 11:10:18 --> UTF-8 Support Enabled
INFO - 2022-07-05 11:10:18 --> Utf8 Class Initialized
INFO - 2022-07-05 11:10:18 --> URI Class Initialized
INFO - 2022-07-05 11:10:18 --> Router Class Initialized
INFO - 2022-07-05 11:10:18 --> Output Class Initialized
INFO - 2022-07-05 11:10:18 --> Security Class Initialized
DEBUG - 2022-07-05 11:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 11:10:18 --> Input Class Initialized
INFO - 2022-07-05 11:10:18 --> Language Class Initialized
INFO - 2022-07-05 11:10:18 --> Loader Class Initialized
INFO - 2022-07-05 11:10:18 --> Helper loaded: url_helper
INFO - 2022-07-05 11:10:18 --> Helper loaded: file_helper
INFO - 2022-07-05 11:10:18 --> Database Driver Class Initialized
INFO - 2022-07-05 11:10:18 --> Email Class Initialized
DEBUG - 2022-07-05 11:10:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 11:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 11:10:18 --> Controller Class Initialized
INFO - 2022-07-05 11:10:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 11:10:18 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 11:10:18 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 11:10:18 --> Final output sent to browser
DEBUG - 2022-07-05 11:10:18 --> Total execution time: 0.0191
INFO - 2022-07-05 11:10:19 --> Config Class Initialized
INFO - 2022-07-05 11:10:19 --> Hooks Class Initialized
DEBUG - 2022-07-05 11:10:19 --> UTF-8 Support Enabled
INFO - 2022-07-05 11:10:19 --> Utf8 Class Initialized
INFO - 2022-07-05 11:10:19 --> URI Class Initialized
INFO - 2022-07-05 11:10:19 --> Router Class Initialized
INFO - 2022-07-05 11:10:19 --> Output Class Initialized
INFO - 2022-07-05 11:10:19 --> Security Class Initialized
DEBUG - 2022-07-05 11:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 11:10:19 --> Input Class Initialized
INFO - 2022-07-05 11:10:19 --> Language Class Initialized
INFO - 2022-07-05 11:10:19 --> Loader Class Initialized
INFO - 2022-07-05 11:10:19 --> Helper loaded: url_helper
INFO - 2022-07-05 11:10:19 --> Helper loaded: file_helper
INFO - 2022-07-05 11:10:20 --> Database Driver Class Initialized
INFO - 2022-07-05 11:10:20 --> Email Class Initialized
DEBUG - 2022-07-05 11:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 11:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 11:10:20 --> Controller Class Initialized
INFO - 2022-07-05 11:10:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 11:10:20 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 11:10:20 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 11:10:20 --> Final output sent to browser
DEBUG - 2022-07-05 11:10:20 --> Total execution time: 0.1181
INFO - 2022-07-05 11:12:18 --> Config Class Initialized
INFO - 2022-07-05 11:12:18 --> Hooks Class Initialized
DEBUG - 2022-07-05 11:12:18 --> UTF-8 Support Enabled
INFO - 2022-07-05 11:12:18 --> Utf8 Class Initialized
INFO - 2022-07-05 11:12:18 --> URI Class Initialized
INFO - 2022-07-05 11:12:18 --> Router Class Initialized
INFO - 2022-07-05 11:12:18 --> Output Class Initialized
INFO - 2022-07-05 11:12:18 --> Security Class Initialized
DEBUG - 2022-07-05 11:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 11:12:18 --> Input Class Initialized
INFO - 2022-07-05 11:12:18 --> Language Class Initialized
INFO - 2022-07-05 11:12:18 --> Loader Class Initialized
INFO - 2022-07-05 11:12:18 --> Helper loaded: url_helper
INFO - 2022-07-05 11:12:18 --> Helper loaded: file_helper
INFO - 2022-07-05 11:12:18 --> Database Driver Class Initialized
INFO - 2022-07-05 11:12:18 --> Email Class Initialized
DEBUG - 2022-07-05 11:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 11:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 11:12:18 --> Controller Class Initialized
INFO - 2022-07-05 11:12:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 11:12:18 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 11:12:18 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 11:12:18 --> Final output sent to browser
DEBUG - 2022-07-05 11:12:18 --> Total execution time: 0.3694
INFO - 2022-07-05 11:21:09 --> Config Class Initialized
INFO - 2022-07-05 11:21:09 --> Hooks Class Initialized
DEBUG - 2022-07-05 11:21:09 --> UTF-8 Support Enabled
INFO - 2022-07-05 11:21:09 --> Utf8 Class Initialized
INFO - 2022-07-05 11:21:09 --> URI Class Initialized
INFO - 2022-07-05 11:21:09 --> Router Class Initialized
INFO - 2022-07-05 11:21:09 --> Output Class Initialized
INFO - 2022-07-05 11:21:09 --> Security Class Initialized
DEBUG - 2022-07-05 11:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 11:21:09 --> Input Class Initialized
INFO - 2022-07-05 11:21:09 --> Language Class Initialized
INFO - 2022-07-05 11:21:09 --> Loader Class Initialized
INFO - 2022-07-05 11:21:09 --> Helper loaded: url_helper
INFO - 2022-07-05 11:21:09 --> Helper loaded: file_helper
INFO - 2022-07-05 11:21:09 --> Database Driver Class Initialized
INFO - 2022-07-05 11:21:09 --> Email Class Initialized
DEBUG - 2022-07-05 11:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 11:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 11:21:09 --> Controller Class Initialized
INFO - 2022-07-05 11:21:09 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 11:21:09 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 11:21:09 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 11:21:09 --> Final output sent to browser
DEBUG - 2022-07-05 11:21:09 --> Total execution time: 0.3432
INFO - 2022-07-05 11:24:21 --> Config Class Initialized
INFO - 2022-07-05 11:24:21 --> Hooks Class Initialized
DEBUG - 2022-07-05 11:24:21 --> UTF-8 Support Enabled
INFO - 2022-07-05 11:24:21 --> Utf8 Class Initialized
INFO - 2022-07-05 11:24:21 --> URI Class Initialized
INFO - 2022-07-05 11:24:21 --> Router Class Initialized
INFO - 2022-07-05 11:24:21 --> Output Class Initialized
INFO - 2022-07-05 11:24:21 --> Security Class Initialized
DEBUG - 2022-07-05 11:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 11:24:21 --> Input Class Initialized
INFO - 2022-07-05 11:24:21 --> Language Class Initialized
ERROR - 2022-07-05 11:24:21 --> Severity: error --> Exception: syntax error, unexpected '=' C:\wamp64\www\qr\application\controllers\Tokenctrl.php 270
INFO - 2022-07-05 11:24:47 --> Config Class Initialized
INFO - 2022-07-05 11:24:47 --> Hooks Class Initialized
DEBUG - 2022-07-05 11:24:47 --> UTF-8 Support Enabled
INFO - 2022-07-05 11:24:47 --> Utf8 Class Initialized
INFO - 2022-07-05 11:24:47 --> URI Class Initialized
INFO - 2022-07-05 11:24:47 --> Router Class Initialized
INFO - 2022-07-05 11:24:47 --> Output Class Initialized
INFO - 2022-07-05 11:24:47 --> Security Class Initialized
DEBUG - 2022-07-05 11:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 11:24:47 --> Input Class Initialized
INFO - 2022-07-05 11:24:47 --> Language Class Initialized
INFO - 2022-07-05 11:24:47 --> Loader Class Initialized
INFO - 2022-07-05 11:24:47 --> Helper loaded: url_helper
INFO - 2022-07-05 11:24:47 --> Helper loaded: file_helper
INFO - 2022-07-05 11:24:47 --> Database Driver Class Initialized
INFO - 2022-07-05 11:24:48 --> Email Class Initialized
DEBUG - 2022-07-05 11:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 11:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 11:24:48 --> Controller Class Initialized
INFO - 2022-07-05 11:24:48 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 11:24:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-05 11:24:48 --> Severity: Notice --> Undefined variable: token C:\wamp64\www\qr\application\controllers\Tokenctrl.php 271
INFO - 2022-07-05 11:25:08 --> Config Class Initialized
INFO - 2022-07-05 11:25:08 --> Hooks Class Initialized
DEBUG - 2022-07-05 11:25:08 --> UTF-8 Support Enabled
INFO - 2022-07-05 11:25:08 --> Utf8 Class Initialized
INFO - 2022-07-05 11:25:08 --> URI Class Initialized
INFO - 2022-07-05 11:25:08 --> Router Class Initialized
INFO - 2022-07-05 11:25:08 --> Output Class Initialized
INFO - 2022-07-05 11:25:08 --> Security Class Initialized
DEBUG - 2022-07-05 11:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 11:25:08 --> Input Class Initialized
INFO - 2022-07-05 11:25:08 --> Language Class Initialized
INFO - 2022-07-05 11:25:08 --> Loader Class Initialized
INFO - 2022-07-05 11:25:08 --> Helper loaded: url_helper
INFO - 2022-07-05 11:25:08 --> Helper loaded: file_helper
INFO - 2022-07-05 11:25:08 --> Database Driver Class Initialized
INFO - 2022-07-05 11:25:08 --> Email Class Initialized
DEBUG - 2022-07-05 11:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 11:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 11:25:08 --> Controller Class Initialized
INFO - 2022-07-05 11:25:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 11:25:08 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 11:26:01 --> Config Class Initialized
INFO - 2022-07-05 11:26:01 --> Hooks Class Initialized
DEBUG - 2022-07-05 11:26:01 --> UTF-8 Support Enabled
INFO - 2022-07-05 11:26:01 --> Utf8 Class Initialized
INFO - 2022-07-05 11:26:01 --> URI Class Initialized
INFO - 2022-07-05 11:26:01 --> Router Class Initialized
INFO - 2022-07-05 11:26:01 --> Output Class Initialized
INFO - 2022-07-05 11:26:01 --> Security Class Initialized
DEBUG - 2022-07-05 11:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 11:26:01 --> Input Class Initialized
INFO - 2022-07-05 11:26:01 --> Language Class Initialized
INFO - 2022-07-05 11:26:01 --> Loader Class Initialized
INFO - 2022-07-05 11:26:01 --> Helper loaded: url_helper
INFO - 2022-07-05 11:26:01 --> Helper loaded: file_helper
INFO - 2022-07-05 11:26:01 --> Database Driver Class Initialized
INFO - 2022-07-05 11:26:01 --> Email Class Initialized
DEBUG - 2022-07-05 11:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 11:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 11:26:01 --> Controller Class Initialized
INFO - 2022-07-05 11:26:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 11:26:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-05 11:26:01 --> Severity: Notice --> Undefined variable: token C:\wamp64\www\qr\application\controllers\Tokenctrl.php 276
INFO - 2022-07-05 11:26:01 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 11:26:01 --> Final output sent to browser
DEBUG - 2022-07-05 11:26:01 --> Total execution time: 0.1857
INFO - 2022-07-05 11:26:06 --> Config Class Initialized
INFO - 2022-07-05 11:26:06 --> Hooks Class Initialized
DEBUG - 2022-07-05 11:26:06 --> UTF-8 Support Enabled
INFO - 2022-07-05 11:26:06 --> Utf8 Class Initialized
INFO - 2022-07-05 11:26:06 --> URI Class Initialized
INFO - 2022-07-05 11:26:06 --> Router Class Initialized
INFO - 2022-07-05 11:26:06 --> Output Class Initialized
INFO - 2022-07-05 11:26:06 --> Security Class Initialized
DEBUG - 2022-07-05 11:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 11:26:06 --> Input Class Initialized
INFO - 2022-07-05 11:26:06 --> Language Class Initialized
INFO - 2022-07-05 11:26:06 --> Loader Class Initialized
INFO - 2022-07-05 11:26:06 --> Helper loaded: url_helper
INFO - 2022-07-05 11:26:06 --> Helper loaded: file_helper
INFO - 2022-07-05 11:26:06 --> Database Driver Class Initialized
INFO - 2022-07-05 11:26:06 --> Email Class Initialized
DEBUG - 2022-07-05 11:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 11:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 11:26:06 --> Controller Class Initialized
INFO - 2022-07-05 11:26:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 11:26:06 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 11:26:06 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 11:26:06 --> Final output sent to browser
DEBUG - 2022-07-05 11:26:06 --> Total execution time: 0.0319
INFO - 2022-07-05 11:26:06 --> Config Class Initialized
INFO - 2022-07-05 11:26:06 --> Hooks Class Initialized
DEBUG - 2022-07-05 11:26:06 --> UTF-8 Support Enabled
INFO - 2022-07-05 11:26:06 --> Utf8 Class Initialized
INFO - 2022-07-05 11:26:06 --> URI Class Initialized
INFO - 2022-07-05 11:26:06 --> Router Class Initialized
INFO - 2022-07-05 11:26:06 --> Output Class Initialized
INFO - 2022-07-05 11:26:06 --> Security Class Initialized
DEBUG - 2022-07-05 11:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 11:26:06 --> Input Class Initialized
INFO - 2022-07-05 11:26:06 --> Language Class Initialized
INFO - 2022-07-05 11:26:06 --> Loader Class Initialized
INFO - 2022-07-05 11:26:06 --> Helper loaded: url_helper
INFO - 2022-07-05 11:26:06 --> Helper loaded: file_helper
INFO - 2022-07-05 11:26:06 --> Database Driver Class Initialized
INFO - 2022-07-05 11:26:06 --> Email Class Initialized
DEBUG - 2022-07-05 11:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 11:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 11:26:06 --> Controller Class Initialized
INFO - 2022-07-05 11:26:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 11:26:06 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 11:26:06 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 11:26:06 --> Final output sent to browser
DEBUG - 2022-07-05 11:26:06 --> Total execution time: 0.0474
INFO - 2022-07-05 11:26:07 --> Config Class Initialized
INFO - 2022-07-05 11:26:07 --> Hooks Class Initialized
DEBUG - 2022-07-05 11:26:07 --> UTF-8 Support Enabled
INFO - 2022-07-05 11:26:07 --> Utf8 Class Initialized
INFO - 2022-07-05 11:26:07 --> URI Class Initialized
INFO - 2022-07-05 11:26:07 --> Router Class Initialized
INFO - 2022-07-05 11:26:07 --> Output Class Initialized
INFO - 2022-07-05 11:26:07 --> Security Class Initialized
DEBUG - 2022-07-05 11:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 11:26:07 --> Input Class Initialized
INFO - 2022-07-05 11:26:07 --> Language Class Initialized
INFO - 2022-07-05 11:26:07 --> Loader Class Initialized
INFO - 2022-07-05 11:26:07 --> Helper loaded: url_helper
INFO - 2022-07-05 11:26:07 --> Helper loaded: file_helper
INFO - 2022-07-05 11:26:07 --> Database Driver Class Initialized
INFO - 2022-07-05 11:26:07 --> Email Class Initialized
DEBUG - 2022-07-05 11:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 11:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 11:26:07 --> Controller Class Initialized
INFO - 2022-07-05 11:26:07 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 11:26:07 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 11:26:07 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 11:26:07 --> Final output sent to browser
DEBUG - 2022-07-05 11:26:07 --> Total execution time: 0.0301
INFO - 2022-07-05 11:26:32 --> Config Class Initialized
INFO - 2022-07-05 11:26:32 --> Hooks Class Initialized
DEBUG - 2022-07-05 11:26:32 --> UTF-8 Support Enabled
INFO - 2022-07-05 11:26:32 --> Utf8 Class Initialized
INFO - 2022-07-05 11:26:32 --> URI Class Initialized
INFO - 2022-07-05 11:26:32 --> Router Class Initialized
INFO - 2022-07-05 11:26:32 --> Output Class Initialized
INFO - 2022-07-05 11:26:32 --> Security Class Initialized
DEBUG - 2022-07-05 11:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 11:26:32 --> Input Class Initialized
INFO - 2022-07-05 11:26:32 --> Language Class Initialized
INFO - 2022-07-05 11:26:32 --> Loader Class Initialized
INFO - 2022-07-05 11:26:32 --> Helper loaded: url_helper
INFO - 2022-07-05 11:26:32 --> Helper loaded: file_helper
INFO - 2022-07-05 11:26:32 --> Database Driver Class Initialized
INFO - 2022-07-05 11:26:32 --> Email Class Initialized
DEBUG - 2022-07-05 11:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 11:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 11:26:32 --> Controller Class Initialized
INFO - 2022-07-05 11:26:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 11:26:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-05 11:26:32 --> Severity: Notice --> Undefined variable: token C:\wamp64\www\qr\application\controllers\Tokenctrl.php 276
INFO - 2022-07-05 11:26:32 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 11:26:32 --> Final output sent to browser
DEBUG - 2022-07-05 11:26:32 --> Total execution time: 0.0744
INFO - 2022-07-05 11:27:10 --> Config Class Initialized
INFO - 2022-07-05 11:27:10 --> Hooks Class Initialized
DEBUG - 2022-07-05 11:27:10 --> UTF-8 Support Enabled
INFO - 2022-07-05 11:27:10 --> Utf8 Class Initialized
INFO - 2022-07-05 11:27:10 --> URI Class Initialized
INFO - 2022-07-05 11:27:10 --> Router Class Initialized
INFO - 2022-07-05 11:27:10 --> Output Class Initialized
INFO - 2022-07-05 11:27:10 --> Security Class Initialized
DEBUG - 2022-07-05 11:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 11:27:10 --> Input Class Initialized
INFO - 2022-07-05 11:27:10 --> Language Class Initialized
INFO - 2022-07-05 11:27:10 --> Loader Class Initialized
INFO - 2022-07-05 11:27:10 --> Helper loaded: url_helper
INFO - 2022-07-05 11:27:10 --> Helper loaded: file_helper
INFO - 2022-07-05 11:27:10 --> Database Driver Class Initialized
INFO - 2022-07-05 11:27:10 --> Email Class Initialized
DEBUG - 2022-07-05 11:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 11:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 11:27:10 --> Controller Class Initialized
INFO - 2022-07-05 11:27:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 11:27:10 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 11:27:10 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 11:27:10 --> Final output sent to browser
DEBUG - 2022-07-05 11:27:10 --> Total execution time: 0.0220
INFO - 2022-07-05 11:27:11 --> Config Class Initialized
INFO - 2022-07-05 11:27:11 --> Hooks Class Initialized
DEBUG - 2022-07-05 11:27:11 --> UTF-8 Support Enabled
INFO - 2022-07-05 11:27:11 --> Utf8 Class Initialized
INFO - 2022-07-05 11:27:11 --> URI Class Initialized
INFO - 2022-07-05 11:27:11 --> Router Class Initialized
INFO - 2022-07-05 11:27:11 --> Output Class Initialized
INFO - 2022-07-05 11:27:11 --> Security Class Initialized
DEBUG - 2022-07-05 11:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 11:27:11 --> Input Class Initialized
INFO - 2022-07-05 11:27:11 --> Language Class Initialized
INFO - 2022-07-05 11:27:11 --> Loader Class Initialized
INFO - 2022-07-05 11:27:11 --> Helper loaded: url_helper
INFO - 2022-07-05 11:27:11 --> Helper loaded: file_helper
INFO - 2022-07-05 11:27:11 --> Database Driver Class Initialized
INFO - 2022-07-05 11:27:11 --> Email Class Initialized
DEBUG - 2022-07-05 11:27:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 11:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 11:27:11 --> Controller Class Initialized
INFO - 2022-07-05 11:27:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 11:27:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 11:27:11 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 11:27:11 --> Final output sent to browser
DEBUG - 2022-07-05 11:27:11 --> Total execution time: 0.1473
INFO - 2022-07-05 11:28:15 --> Config Class Initialized
INFO - 2022-07-05 11:28:15 --> Hooks Class Initialized
DEBUG - 2022-07-05 11:28:15 --> UTF-8 Support Enabled
INFO - 2022-07-05 11:28:15 --> Utf8 Class Initialized
INFO - 2022-07-05 11:28:15 --> URI Class Initialized
INFO - 2022-07-05 11:28:15 --> Router Class Initialized
INFO - 2022-07-05 11:28:15 --> Output Class Initialized
INFO - 2022-07-05 11:28:15 --> Security Class Initialized
DEBUG - 2022-07-05 11:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 11:28:15 --> Input Class Initialized
INFO - 2022-07-05 11:28:15 --> Language Class Initialized
INFO - 2022-07-05 11:28:15 --> Loader Class Initialized
INFO - 2022-07-05 11:28:15 --> Helper loaded: url_helper
INFO - 2022-07-05 11:28:15 --> Helper loaded: file_helper
INFO - 2022-07-05 11:28:15 --> Database Driver Class Initialized
INFO - 2022-07-05 11:28:15 --> Email Class Initialized
DEBUG - 2022-07-05 11:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 11:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 11:28:15 --> Controller Class Initialized
INFO - 2022-07-05 11:28:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 11:28:15 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 11:28:15 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 11:28:15 --> Final output sent to browser
DEBUG - 2022-07-05 11:28:15 --> Total execution time: 0.2098
INFO - 2022-07-05 11:28:16 --> Config Class Initialized
INFO - 2022-07-05 11:28:16 --> Hooks Class Initialized
DEBUG - 2022-07-05 11:28:16 --> UTF-8 Support Enabled
INFO - 2022-07-05 11:28:16 --> Utf8 Class Initialized
INFO - 2022-07-05 11:28:16 --> URI Class Initialized
INFO - 2022-07-05 11:28:16 --> Router Class Initialized
INFO - 2022-07-05 11:28:16 --> Output Class Initialized
INFO - 2022-07-05 11:28:16 --> Security Class Initialized
DEBUG - 2022-07-05 11:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 11:28:16 --> Input Class Initialized
INFO - 2022-07-05 11:28:16 --> Language Class Initialized
INFO - 2022-07-05 11:28:16 --> Loader Class Initialized
INFO - 2022-07-05 11:28:16 --> Helper loaded: url_helper
INFO - 2022-07-05 11:28:16 --> Helper loaded: file_helper
INFO - 2022-07-05 11:28:16 --> Database Driver Class Initialized
INFO - 2022-07-05 11:28:16 --> Email Class Initialized
DEBUG - 2022-07-05 11:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 11:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 11:28:16 --> Controller Class Initialized
INFO - 2022-07-05 11:28:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 11:28:16 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 11:28:16 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 11:28:16 --> Final output sent to browser
DEBUG - 2022-07-05 11:28:16 --> Total execution time: 0.0255
INFO - 2022-07-05 11:31:43 --> Config Class Initialized
INFO - 2022-07-05 11:31:43 --> Hooks Class Initialized
DEBUG - 2022-07-05 11:31:43 --> UTF-8 Support Enabled
INFO - 2022-07-05 11:31:43 --> Utf8 Class Initialized
INFO - 2022-07-05 11:31:43 --> URI Class Initialized
INFO - 2022-07-05 11:31:43 --> Router Class Initialized
INFO - 2022-07-05 11:31:43 --> Output Class Initialized
INFO - 2022-07-05 11:31:43 --> Security Class Initialized
DEBUG - 2022-07-05 11:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 11:31:43 --> Input Class Initialized
INFO - 2022-07-05 11:31:43 --> Language Class Initialized
INFO - 2022-07-05 11:31:43 --> Loader Class Initialized
INFO - 2022-07-05 11:31:43 --> Helper loaded: url_helper
INFO - 2022-07-05 11:31:43 --> Helper loaded: file_helper
INFO - 2022-07-05 11:31:43 --> Database Driver Class Initialized
INFO - 2022-07-05 11:31:43 --> Email Class Initialized
DEBUG - 2022-07-05 11:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 11:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 11:31:43 --> Controller Class Initialized
INFO - 2022-07-05 11:31:43 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 11:31:43 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 11:31:43 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 11:31:43 --> Final output sent to browser
DEBUG - 2022-07-05 11:31:43 --> Total execution time: 0.0460
INFO - 2022-07-05 11:31:49 --> Config Class Initialized
INFO - 2022-07-05 11:31:49 --> Hooks Class Initialized
DEBUG - 2022-07-05 11:31:49 --> UTF-8 Support Enabled
INFO - 2022-07-05 11:31:49 --> Utf8 Class Initialized
INFO - 2022-07-05 11:31:49 --> URI Class Initialized
INFO - 2022-07-05 11:31:49 --> Router Class Initialized
INFO - 2022-07-05 11:31:49 --> Output Class Initialized
INFO - 2022-07-05 11:31:49 --> Security Class Initialized
DEBUG - 2022-07-05 11:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 11:31:49 --> Input Class Initialized
INFO - 2022-07-05 11:31:49 --> Language Class Initialized
INFO - 2022-07-05 11:31:49 --> Loader Class Initialized
INFO - 2022-07-05 11:31:49 --> Helper loaded: url_helper
INFO - 2022-07-05 11:31:49 --> Helper loaded: file_helper
INFO - 2022-07-05 11:31:49 --> Database Driver Class Initialized
INFO - 2022-07-05 11:31:49 --> Email Class Initialized
DEBUG - 2022-07-05 11:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 11:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 11:31:49 --> Controller Class Initialized
INFO - 2022-07-05 11:31:49 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 11:31:49 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 11:31:49 --> Final output sent to browser
DEBUG - 2022-07-05 11:31:49 --> Total execution time: 0.0652
INFO - 2022-07-05 11:32:12 --> Config Class Initialized
INFO - 2022-07-05 11:32:12 --> Hooks Class Initialized
DEBUG - 2022-07-05 11:32:12 --> UTF-8 Support Enabled
INFO - 2022-07-05 11:32:12 --> Utf8 Class Initialized
INFO - 2022-07-05 11:32:12 --> URI Class Initialized
INFO - 2022-07-05 11:32:12 --> Router Class Initialized
INFO - 2022-07-05 11:32:12 --> Output Class Initialized
INFO - 2022-07-05 11:32:12 --> Security Class Initialized
DEBUG - 2022-07-05 11:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 11:32:12 --> Input Class Initialized
INFO - 2022-07-05 11:32:12 --> Language Class Initialized
INFO - 2022-07-05 11:32:12 --> Loader Class Initialized
INFO - 2022-07-05 11:32:12 --> Helper loaded: url_helper
INFO - 2022-07-05 11:32:12 --> Helper loaded: file_helper
INFO - 2022-07-05 11:32:12 --> Database Driver Class Initialized
INFO - 2022-07-05 11:32:12 --> Email Class Initialized
DEBUG - 2022-07-05 11:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 11:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 11:32:12 --> Controller Class Initialized
INFO - 2022-07-05 11:32:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 11:32:12 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 11:32:12 --> Final output sent to browser
DEBUG - 2022-07-05 11:32:12 --> Total execution time: 0.0341
INFO - 2022-07-05 11:45:27 --> Config Class Initialized
INFO - 2022-07-05 11:45:27 --> Hooks Class Initialized
DEBUG - 2022-07-05 11:45:27 --> UTF-8 Support Enabled
INFO - 2022-07-05 11:45:27 --> Utf8 Class Initialized
INFO - 2022-07-05 11:45:28 --> URI Class Initialized
INFO - 2022-07-05 11:45:28 --> Router Class Initialized
INFO - 2022-07-05 11:45:28 --> Output Class Initialized
INFO - 2022-07-05 11:45:28 --> Security Class Initialized
DEBUG - 2022-07-05 11:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 11:45:28 --> Input Class Initialized
INFO - 2022-07-05 11:45:28 --> Language Class Initialized
INFO - 2022-07-05 11:45:28 --> Loader Class Initialized
INFO - 2022-07-05 11:45:28 --> Helper loaded: url_helper
INFO - 2022-07-05 11:45:28 --> Helper loaded: file_helper
INFO - 2022-07-05 11:45:28 --> Database Driver Class Initialized
INFO - 2022-07-05 11:45:28 --> Email Class Initialized
DEBUG - 2022-07-05 11:45:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 11:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 11:45:28 --> Controller Class Initialized
INFO - 2022-07-05 11:45:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 11:45:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 11:45:28 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 11:45:28 --> Final output sent to browser
DEBUG - 2022-07-05 11:45:28 --> Total execution time: 0.2426
INFO - 2022-07-05 11:45:30 --> Config Class Initialized
INFO - 2022-07-05 11:45:30 --> Hooks Class Initialized
DEBUG - 2022-07-05 11:45:30 --> UTF-8 Support Enabled
INFO - 2022-07-05 11:45:30 --> Utf8 Class Initialized
INFO - 2022-07-05 11:45:30 --> URI Class Initialized
INFO - 2022-07-05 11:45:30 --> Router Class Initialized
INFO - 2022-07-05 11:45:30 --> Output Class Initialized
INFO - 2022-07-05 11:45:30 --> Security Class Initialized
DEBUG - 2022-07-05 11:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 11:45:30 --> Input Class Initialized
INFO - 2022-07-05 11:45:30 --> Language Class Initialized
INFO - 2022-07-05 11:45:30 --> Loader Class Initialized
INFO - 2022-07-05 11:45:30 --> Helper loaded: url_helper
INFO - 2022-07-05 11:45:30 --> Helper loaded: file_helper
INFO - 2022-07-05 11:45:30 --> Database Driver Class Initialized
INFO - 2022-07-05 11:45:30 --> Email Class Initialized
DEBUG - 2022-07-05 11:45:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 11:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 11:45:30 --> Controller Class Initialized
INFO - 2022-07-05 11:45:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 11:45:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 11:45:30 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 11:45:30 --> Final output sent to browser
DEBUG - 2022-07-05 11:45:30 --> Total execution time: 0.2083
INFO - 2022-07-05 11:45:33 --> Config Class Initialized
INFO - 2022-07-05 11:45:33 --> Hooks Class Initialized
DEBUG - 2022-07-05 11:45:33 --> UTF-8 Support Enabled
INFO - 2022-07-05 11:45:33 --> Utf8 Class Initialized
INFO - 2022-07-05 11:45:33 --> URI Class Initialized
INFO - 2022-07-05 11:45:33 --> Router Class Initialized
INFO - 2022-07-05 11:45:33 --> Output Class Initialized
INFO - 2022-07-05 11:45:33 --> Security Class Initialized
DEBUG - 2022-07-05 11:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 11:45:33 --> Input Class Initialized
INFO - 2022-07-05 11:45:33 --> Language Class Initialized
INFO - 2022-07-05 11:45:33 --> Loader Class Initialized
INFO - 2022-07-05 11:45:33 --> Helper loaded: url_helper
INFO - 2022-07-05 11:45:33 --> Helper loaded: file_helper
INFO - 2022-07-05 11:45:33 --> Database Driver Class Initialized
INFO - 2022-07-05 11:45:33 --> Email Class Initialized
DEBUG - 2022-07-05 11:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 11:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 11:45:33 --> Controller Class Initialized
INFO - 2022-07-05 11:45:33 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 11:45:33 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 11:45:33 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 11:45:33 --> Final output sent to browser
DEBUG - 2022-07-05 11:45:33 --> Total execution time: 0.2480
INFO - 2022-07-05 11:45:37 --> Config Class Initialized
INFO - 2022-07-05 11:45:37 --> Hooks Class Initialized
DEBUG - 2022-07-05 11:45:37 --> UTF-8 Support Enabled
INFO - 2022-07-05 11:45:37 --> Utf8 Class Initialized
INFO - 2022-07-05 11:45:37 --> URI Class Initialized
INFO - 2022-07-05 11:45:37 --> Router Class Initialized
INFO - 2022-07-05 11:45:37 --> Output Class Initialized
INFO - 2022-07-05 11:45:37 --> Security Class Initialized
DEBUG - 2022-07-05 11:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 11:45:37 --> Input Class Initialized
INFO - 2022-07-05 11:45:37 --> Language Class Initialized
INFO - 2022-07-05 11:45:37 --> Loader Class Initialized
INFO - 2022-07-05 11:45:37 --> Helper loaded: url_helper
INFO - 2022-07-05 11:45:37 --> Helper loaded: file_helper
INFO - 2022-07-05 11:45:37 --> Database Driver Class Initialized
INFO - 2022-07-05 11:45:37 --> Email Class Initialized
DEBUG - 2022-07-05 11:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 11:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 11:45:37 --> Controller Class Initialized
INFO - 2022-07-05 11:45:37 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 11:45:37 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 11:45:37 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 11:45:37 --> Final output sent to browser
DEBUG - 2022-07-05 11:45:37 --> Total execution time: 0.2145
INFO - 2022-07-05 11:45:42 --> Config Class Initialized
INFO - 2022-07-05 11:45:42 --> Hooks Class Initialized
DEBUG - 2022-07-05 11:45:42 --> UTF-8 Support Enabled
INFO - 2022-07-05 11:45:42 --> Utf8 Class Initialized
INFO - 2022-07-05 11:45:42 --> URI Class Initialized
INFO - 2022-07-05 11:45:42 --> Router Class Initialized
INFO - 2022-07-05 11:45:42 --> Output Class Initialized
INFO - 2022-07-05 11:45:42 --> Security Class Initialized
DEBUG - 2022-07-05 11:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 11:45:42 --> Input Class Initialized
INFO - 2022-07-05 11:45:42 --> Language Class Initialized
INFO - 2022-07-05 11:45:42 --> Loader Class Initialized
INFO - 2022-07-05 11:45:42 --> Helper loaded: url_helper
INFO - 2022-07-05 11:45:42 --> Helper loaded: file_helper
INFO - 2022-07-05 11:45:42 --> Database Driver Class Initialized
INFO - 2022-07-05 11:45:42 --> Email Class Initialized
DEBUG - 2022-07-05 11:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 11:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 11:45:42 --> Controller Class Initialized
INFO - 2022-07-05 11:45:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 11:45:42 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 11:45:42 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 11:45:42 --> Final output sent to browser
DEBUG - 2022-07-05 11:45:42 --> Total execution time: 0.0813
INFO - 2022-07-05 11:47:17 --> Config Class Initialized
INFO - 2022-07-05 11:47:17 --> Hooks Class Initialized
DEBUG - 2022-07-05 11:47:17 --> UTF-8 Support Enabled
INFO - 2022-07-05 11:47:17 --> Utf8 Class Initialized
INFO - 2022-07-05 11:47:17 --> URI Class Initialized
INFO - 2022-07-05 11:47:17 --> Router Class Initialized
INFO - 2022-07-05 11:47:17 --> Output Class Initialized
INFO - 2022-07-05 11:47:17 --> Security Class Initialized
DEBUG - 2022-07-05 11:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 11:47:17 --> Input Class Initialized
INFO - 2022-07-05 11:47:17 --> Language Class Initialized
INFO - 2022-07-05 11:47:17 --> Loader Class Initialized
INFO - 2022-07-05 11:47:17 --> Helper loaded: url_helper
INFO - 2022-07-05 11:47:17 --> Helper loaded: file_helper
INFO - 2022-07-05 11:47:17 --> Database Driver Class Initialized
INFO - 2022-07-05 11:47:17 --> Email Class Initialized
DEBUG - 2022-07-05 11:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 11:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 11:47:17 --> Controller Class Initialized
INFO - 2022-07-05 11:47:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 11:47:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 11:47:17 --> Final output sent to browser
DEBUG - 2022-07-05 11:47:17 --> Total execution time: 0.0822
INFO - 2022-07-05 12:04:50 --> Config Class Initialized
INFO - 2022-07-05 12:04:50 --> Hooks Class Initialized
DEBUG - 2022-07-05 12:04:50 --> UTF-8 Support Enabled
INFO - 2022-07-05 12:04:50 --> Utf8 Class Initialized
INFO - 2022-07-05 12:04:50 --> URI Class Initialized
INFO - 2022-07-05 12:04:50 --> Router Class Initialized
INFO - 2022-07-05 12:04:50 --> Output Class Initialized
INFO - 2022-07-05 12:04:50 --> Security Class Initialized
DEBUG - 2022-07-05 12:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 12:04:50 --> Input Class Initialized
INFO - 2022-07-05 12:04:50 --> Language Class Initialized
INFO - 2022-07-05 12:04:50 --> Loader Class Initialized
INFO - 2022-07-05 12:04:50 --> Helper loaded: url_helper
INFO - 2022-07-05 12:04:50 --> Helper loaded: file_helper
INFO - 2022-07-05 12:04:50 --> Database Driver Class Initialized
INFO - 2022-07-05 12:04:50 --> Email Class Initialized
DEBUG - 2022-07-05 12:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 12:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 12:04:50 --> Controller Class Initialized
INFO - 2022-07-05 12:04:50 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 12:04:50 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 12:04:50 --> Final output sent to browser
DEBUG - 2022-07-05 12:04:50 --> Total execution time: 0.0246
INFO - 2022-07-05 12:04:51 --> Config Class Initialized
INFO - 2022-07-05 12:04:51 --> Hooks Class Initialized
DEBUG - 2022-07-05 12:04:51 --> UTF-8 Support Enabled
INFO - 2022-07-05 12:04:51 --> Utf8 Class Initialized
INFO - 2022-07-05 12:04:51 --> URI Class Initialized
INFO - 2022-07-05 12:04:51 --> Router Class Initialized
INFO - 2022-07-05 12:04:51 --> Output Class Initialized
INFO - 2022-07-05 12:04:51 --> Security Class Initialized
DEBUG - 2022-07-05 12:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 12:04:51 --> Input Class Initialized
INFO - 2022-07-05 12:04:51 --> Language Class Initialized
INFO - 2022-07-05 12:04:51 --> Loader Class Initialized
INFO - 2022-07-05 12:04:51 --> Helper loaded: url_helper
INFO - 2022-07-05 12:04:51 --> Helper loaded: file_helper
INFO - 2022-07-05 12:04:51 --> Database Driver Class Initialized
INFO - 2022-07-05 12:04:51 --> Email Class Initialized
DEBUG - 2022-07-05 12:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 12:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 12:04:51 --> Controller Class Initialized
INFO - 2022-07-05 12:04:51 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 12:04:51 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 12:04:51 --> Final output sent to browser
DEBUG - 2022-07-05 12:04:51 --> Total execution time: 0.0800
INFO - 2022-07-05 12:04:52 --> Config Class Initialized
INFO - 2022-07-05 12:04:52 --> Hooks Class Initialized
DEBUG - 2022-07-05 12:04:52 --> UTF-8 Support Enabled
INFO - 2022-07-05 12:04:52 --> Utf8 Class Initialized
INFO - 2022-07-05 12:04:52 --> URI Class Initialized
INFO - 2022-07-05 12:04:52 --> Router Class Initialized
INFO - 2022-07-05 12:04:52 --> Output Class Initialized
INFO - 2022-07-05 12:04:52 --> Security Class Initialized
DEBUG - 2022-07-05 12:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 12:04:52 --> Input Class Initialized
INFO - 2022-07-05 12:04:52 --> Language Class Initialized
INFO - 2022-07-05 12:04:52 --> Loader Class Initialized
INFO - 2022-07-05 12:04:52 --> Helper loaded: url_helper
INFO - 2022-07-05 12:04:52 --> Helper loaded: file_helper
INFO - 2022-07-05 12:04:52 --> Database Driver Class Initialized
INFO - 2022-07-05 12:04:52 --> Email Class Initialized
DEBUG - 2022-07-05 12:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 12:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 12:04:52 --> Controller Class Initialized
INFO - 2022-07-05 12:04:52 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 12:04:52 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 12:04:52 --> Final output sent to browser
DEBUG - 2022-07-05 12:04:52 --> Total execution time: 0.1640
INFO - 2022-07-05 12:06:37 --> Config Class Initialized
INFO - 2022-07-05 12:06:37 --> Hooks Class Initialized
DEBUG - 2022-07-05 12:06:37 --> UTF-8 Support Enabled
INFO - 2022-07-05 12:06:37 --> Utf8 Class Initialized
INFO - 2022-07-05 12:06:37 --> URI Class Initialized
INFO - 2022-07-05 12:06:37 --> Router Class Initialized
INFO - 2022-07-05 12:06:37 --> Output Class Initialized
INFO - 2022-07-05 12:06:37 --> Security Class Initialized
DEBUG - 2022-07-05 12:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 12:06:37 --> Input Class Initialized
INFO - 2022-07-05 12:06:37 --> Language Class Initialized
INFO - 2022-07-05 12:06:37 --> Loader Class Initialized
INFO - 2022-07-05 12:06:37 --> Helper loaded: url_helper
INFO - 2022-07-05 12:06:37 --> Helper loaded: file_helper
INFO - 2022-07-05 12:06:37 --> Database Driver Class Initialized
INFO - 2022-07-05 12:06:37 --> Email Class Initialized
DEBUG - 2022-07-05 12:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 12:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 12:06:37 --> Controller Class Initialized
INFO - 2022-07-05 12:06:37 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 12:06:37 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 12:06:37 --> Final output sent to browser
DEBUG - 2022-07-05 12:06:37 --> Total execution time: 0.1806
INFO - 2022-07-05 12:10:07 --> Config Class Initialized
INFO - 2022-07-05 12:10:07 --> Hooks Class Initialized
DEBUG - 2022-07-05 12:10:07 --> UTF-8 Support Enabled
INFO - 2022-07-05 12:10:07 --> Utf8 Class Initialized
INFO - 2022-07-05 12:10:07 --> URI Class Initialized
INFO - 2022-07-05 12:10:07 --> Router Class Initialized
INFO - 2022-07-05 12:10:07 --> Output Class Initialized
INFO - 2022-07-05 12:10:07 --> Security Class Initialized
DEBUG - 2022-07-05 12:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 12:10:07 --> Input Class Initialized
INFO - 2022-07-05 12:10:07 --> Language Class Initialized
INFO - 2022-07-05 12:10:07 --> Loader Class Initialized
INFO - 2022-07-05 12:10:07 --> Helper loaded: url_helper
INFO - 2022-07-05 12:10:07 --> Helper loaded: file_helper
INFO - 2022-07-05 12:10:07 --> Database Driver Class Initialized
INFO - 2022-07-05 12:10:07 --> Email Class Initialized
DEBUG - 2022-07-05 12:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 12:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 12:10:07 --> Controller Class Initialized
INFO - 2022-07-05 12:10:07 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 12:10:07 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 12:10:07 --> Final output sent to browser
DEBUG - 2022-07-05 12:10:07 --> Total execution time: 0.3173
INFO - 2022-07-05 12:15:42 --> Config Class Initialized
INFO - 2022-07-05 12:15:42 --> Hooks Class Initialized
DEBUG - 2022-07-05 12:15:42 --> UTF-8 Support Enabled
INFO - 2022-07-05 12:15:42 --> Utf8 Class Initialized
INFO - 2022-07-05 12:15:42 --> URI Class Initialized
INFO - 2022-07-05 12:15:42 --> Router Class Initialized
INFO - 2022-07-05 12:15:42 --> Output Class Initialized
INFO - 2022-07-05 12:15:42 --> Security Class Initialized
DEBUG - 2022-07-05 12:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 12:15:42 --> Input Class Initialized
INFO - 2022-07-05 12:15:42 --> Language Class Initialized
INFO - 2022-07-05 12:15:42 --> Loader Class Initialized
INFO - 2022-07-05 12:15:42 --> Helper loaded: url_helper
INFO - 2022-07-05 12:15:42 --> Helper loaded: file_helper
INFO - 2022-07-05 12:15:42 --> Database Driver Class Initialized
INFO - 2022-07-05 12:15:42 --> Email Class Initialized
DEBUG - 2022-07-05 12:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 12:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 12:15:42 --> Controller Class Initialized
INFO - 2022-07-05 12:15:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 12:15:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-05 12:15:42 --> Severity: error --> Exception: Call to undefined method Tokenmodel::max() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 243
INFO - 2022-07-05 12:15:56 --> Config Class Initialized
INFO - 2022-07-05 12:15:56 --> Hooks Class Initialized
DEBUG - 2022-07-05 12:15:56 --> UTF-8 Support Enabled
INFO - 2022-07-05 12:15:56 --> Utf8 Class Initialized
INFO - 2022-07-05 12:15:56 --> URI Class Initialized
INFO - 2022-07-05 12:15:56 --> Router Class Initialized
INFO - 2022-07-05 12:15:56 --> Output Class Initialized
INFO - 2022-07-05 12:15:56 --> Security Class Initialized
DEBUG - 2022-07-05 12:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 12:15:56 --> Input Class Initialized
INFO - 2022-07-05 12:15:56 --> Language Class Initialized
INFO - 2022-07-05 12:15:56 --> Loader Class Initialized
INFO - 2022-07-05 12:15:56 --> Helper loaded: url_helper
INFO - 2022-07-05 12:15:56 --> Helper loaded: file_helper
INFO - 2022-07-05 12:15:56 --> Database Driver Class Initialized
INFO - 2022-07-05 12:15:57 --> Email Class Initialized
DEBUG - 2022-07-05 12:15:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 12:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 12:15:57 --> Controller Class Initialized
INFO - 2022-07-05 12:15:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 12:15:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 12:15:57 --> Final output sent to browser
DEBUG - 2022-07-05 12:15:57 --> Total execution time: 0.1796
INFO - 2022-07-05 12:16:08 --> Config Class Initialized
INFO - 2022-07-05 12:16:08 --> Hooks Class Initialized
DEBUG - 2022-07-05 12:16:08 --> UTF-8 Support Enabled
INFO - 2022-07-05 12:16:08 --> Utf8 Class Initialized
INFO - 2022-07-05 12:16:08 --> URI Class Initialized
INFO - 2022-07-05 12:16:08 --> Router Class Initialized
INFO - 2022-07-05 12:16:08 --> Output Class Initialized
INFO - 2022-07-05 12:16:08 --> Security Class Initialized
DEBUG - 2022-07-05 12:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 12:16:08 --> Input Class Initialized
INFO - 2022-07-05 12:16:08 --> Language Class Initialized
INFO - 2022-07-05 12:16:08 --> Loader Class Initialized
INFO - 2022-07-05 12:16:08 --> Helper loaded: url_helper
INFO - 2022-07-05 12:16:08 --> Helper loaded: file_helper
INFO - 2022-07-05 12:16:08 --> Database Driver Class Initialized
INFO - 2022-07-05 12:16:08 --> Email Class Initialized
DEBUG - 2022-07-05 12:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 12:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 12:16:08 --> Controller Class Initialized
INFO - 2022-07-05 12:16:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 12:16:08 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 12:16:08 --> Final output sent to browser
DEBUG - 2022-07-05 12:16:08 --> Total execution time: 0.0936
INFO - 2022-07-05 12:17:50 --> Config Class Initialized
INFO - 2022-07-05 12:17:50 --> Hooks Class Initialized
DEBUG - 2022-07-05 12:17:50 --> UTF-8 Support Enabled
INFO - 2022-07-05 12:17:50 --> Utf8 Class Initialized
INFO - 2022-07-05 12:17:50 --> URI Class Initialized
INFO - 2022-07-05 12:17:50 --> Router Class Initialized
INFO - 2022-07-05 12:17:50 --> Output Class Initialized
INFO - 2022-07-05 12:17:50 --> Security Class Initialized
DEBUG - 2022-07-05 12:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 12:17:50 --> Input Class Initialized
INFO - 2022-07-05 12:17:50 --> Language Class Initialized
INFO - 2022-07-05 12:17:50 --> Loader Class Initialized
INFO - 2022-07-05 12:17:50 --> Helper loaded: url_helper
INFO - 2022-07-05 12:17:50 --> Helper loaded: file_helper
INFO - 2022-07-05 12:17:50 --> Database Driver Class Initialized
INFO - 2022-07-05 12:17:50 --> Email Class Initialized
DEBUG - 2022-07-05 12:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 12:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 12:17:50 --> Controller Class Initialized
INFO - 2022-07-05 12:17:50 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 12:17:50 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 12:17:50 --> Final output sent to browser
DEBUG - 2022-07-05 12:17:50 --> Total execution time: 0.0446
INFO - 2022-07-05 12:17:53 --> Config Class Initialized
INFO - 2022-07-05 12:17:53 --> Hooks Class Initialized
DEBUG - 2022-07-05 12:17:53 --> UTF-8 Support Enabled
INFO - 2022-07-05 12:17:53 --> Utf8 Class Initialized
INFO - 2022-07-05 12:17:53 --> URI Class Initialized
INFO - 2022-07-05 12:17:53 --> Router Class Initialized
INFO - 2022-07-05 12:17:53 --> Output Class Initialized
INFO - 2022-07-05 12:17:53 --> Security Class Initialized
DEBUG - 2022-07-05 12:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 12:17:53 --> Input Class Initialized
INFO - 2022-07-05 12:17:53 --> Language Class Initialized
INFO - 2022-07-05 12:17:53 --> Loader Class Initialized
INFO - 2022-07-05 12:17:53 --> Helper loaded: url_helper
INFO - 2022-07-05 12:17:53 --> Helper loaded: file_helper
INFO - 2022-07-05 12:17:53 --> Database Driver Class Initialized
INFO - 2022-07-05 12:17:53 --> Email Class Initialized
DEBUG - 2022-07-05 12:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 12:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 12:17:53 --> Controller Class Initialized
INFO - 2022-07-05 12:17:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 12:17:53 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 12:17:53 --> Final output sent to browser
DEBUG - 2022-07-05 12:17:53 --> Total execution time: 0.0621
INFO - 2022-07-05 12:18:38 --> Config Class Initialized
INFO - 2022-07-05 12:18:38 --> Hooks Class Initialized
DEBUG - 2022-07-05 12:18:38 --> UTF-8 Support Enabled
INFO - 2022-07-05 12:18:38 --> Utf8 Class Initialized
INFO - 2022-07-05 12:18:38 --> URI Class Initialized
INFO - 2022-07-05 12:18:38 --> Router Class Initialized
INFO - 2022-07-05 12:18:38 --> Output Class Initialized
INFO - 2022-07-05 12:18:38 --> Security Class Initialized
DEBUG - 2022-07-05 12:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 12:18:38 --> Input Class Initialized
INFO - 2022-07-05 12:18:38 --> Language Class Initialized
INFO - 2022-07-05 12:18:38 --> Loader Class Initialized
INFO - 2022-07-05 12:18:38 --> Helper loaded: url_helper
INFO - 2022-07-05 12:18:38 --> Helper loaded: file_helper
INFO - 2022-07-05 12:18:38 --> Database Driver Class Initialized
INFO - 2022-07-05 12:18:38 --> Email Class Initialized
DEBUG - 2022-07-05 12:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 12:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 12:18:38 --> Controller Class Initialized
INFO - 2022-07-05 12:18:38 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 12:18:38 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 12:18:38 --> Final output sent to browser
DEBUG - 2022-07-05 12:18:38 --> Total execution time: 0.1665
INFO - 2022-07-05 12:21:59 --> Config Class Initialized
INFO - 2022-07-05 12:21:59 --> Hooks Class Initialized
DEBUG - 2022-07-05 12:21:59 --> UTF-8 Support Enabled
INFO - 2022-07-05 12:21:59 --> Utf8 Class Initialized
INFO - 2022-07-05 12:21:59 --> URI Class Initialized
INFO - 2022-07-05 12:21:59 --> Router Class Initialized
INFO - 2022-07-05 12:21:59 --> Output Class Initialized
INFO - 2022-07-05 12:21:59 --> Security Class Initialized
DEBUG - 2022-07-05 12:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 12:21:59 --> Input Class Initialized
INFO - 2022-07-05 12:21:59 --> Language Class Initialized
INFO - 2022-07-05 12:21:59 --> Loader Class Initialized
INFO - 2022-07-05 12:21:59 --> Helper loaded: url_helper
INFO - 2022-07-05 12:21:59 --> Helper loaded: file_helper
INFO - 2022-07-05 12:21:59 --> Database Driver Class Initialized
INFO - 2022-07-05 12:21:59 --> Email Class Initialized
DEBUG - 2022-07-05 12:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 12:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 12:21:59 --> Controller Class Initialized
INFO - 2022-07-05 12:21:59 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 12:21:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-05 12:21:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: select (cast(td_visited_date as char))td_visited_date from tokendetails where td_tk=
INFO - 2022-07-05 12:21:59 --> Language file loaded: language/english/db_lang.php
INFO - 2022-07-05 12:23:14 --> Config Class Initialized
INFO - 2022-07-05 12:23:14 --> Hooks Class Initialized
DEBUG - 2022-07-05 12:23:14 --> UTF-8 Support Enabled
INFO - 2022-07-05 12:23:14 --> Utf8 Class Initialized
INFO - 2022-07-05 12:23:14 --> URI Class Initialized
INFO - 2022-07-05 12:23:14 --> Router Class Initialized
INFO - 2022-07-05 12:23:14 --> Output Class Initialized
INFO - 2022-07-05 12:23:14 --> Security Class Initialized
DEBUG - 2022-07-05 12:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 12:23:14 --> Input Class Initialized
INFO - 2022-07-05 12:23:14 --> Language Class Initialized
INFO - 2022-07-05 12:23:14 --> Loader Class Initialized
INFO - 2022-07-05 12:23:14 --> Helper loaded: url_helper
INFO - 2022-07-05 12:23:14 --> Helper loaded: file_helper
INFO - 2022-07-05 12:23:14 --> Database Driver Class Initialized
INFO - 2022-07-05 12:23:14 --> Email Class Initialized
DEBUG - 2022-07-05 12:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 12:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 12:23:14 --> Controller Class Initialized
INFO - 2022-07-05 12:23:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 12:23:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-07-05 12:23:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: select (cast(td_visited_date as char))td_visited_date from tokendetails where td_tk=
INFO - 2022-07-05 12:23:14 --> Language file loaded: language/english/db_lang.php
INFO - 2022-07-05 12:23:31 --> Config Class Initialized
INFO - 2022-07-05 12:23:31 --> Hooks Class Initialized
DEBUG - 2022-07-05 12:23:31 --> UTF-8 Support Enabled
INFO - 2022-07-05 12:23:31 --> Utf8 Class Initialized
INFO - 2022-07-05 12:23:31 --> URI Class Initialized
INFO - 2022-07-05 12:23:31 --> Router Class Initialized
INFO - 2022-07-05 12:23:31 --> Output Class Initialized
INFO - 2022-07-05 12:23:31 --> Security Class Initialized
DEBUG - 2022-07-05 12:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 12:23:31 --> Input Class Initialized
INFO - 2022-07-05 12:23:31 --> Language Class Initialized
INFO - 2022-07-05 12:23:31 --> Loader Class Initialized
INFO - 2022-07-05 12:23:31 --> Helper loaded: url_helper
INFO - 2022-07-05 12:23:31 --> Helper loaded: file_helper
INFO - 2022-07-05 12:23:31 --> Database Driver Class Initialized
INFO - 2022-07-05 12:23:31 --> Email Class Initialized
DEBUG - 2022-07-05 12:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 12:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 12:23:31 --> Controller Class Initialized
INFO - 2022-07-05 12:23:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 12:23:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 12:23:31 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 12:23:31 --> Final output sent to browser
DEBUG - 2022-07-05 12:23:31 --> Total execution time: 0.1400
INFO - 2022-07-05 12:23:37 --> Config Class Initialized
INFO - 2022-07-05 12:23:37 --> Hooks Class Initialized
DEBUG - 2022-07-05 12:23:37 --> UTF-8 Support Enabled
INFO - 2022-07-05 12:23:37 --> Utf8 Class Initialized
INFO - 2022-07-05 12:23:37 --> URI Class Initialized
INFO - 2022-07-05 12:23:37 --> Router Class Initialized
INFO - 2022-07-05 12:23:37 --> Output Class Initialized
INFO - 2022-07-05 12:23:37 --> Security Class Initialized
DEBUG - 2022-07-05 12:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 12:23:37 --> Input Class Initialized
INFO - 2022-07-05 12:23:37 --> Language Class Initialized
INFO - 2022-07-05 12:23:37 --> Loader Class Initialized
INFO - 2022-07-05 12:23:37 --> Helper loaded: url_helper
INFO - 2022-07-05 12:23:37 --> Helper loaded: file_helper
INFO - 2022-07-05 12:23:37 --> Database Driver Class Initialized
INFO - 2022-07-05 12:23:37 --> Email Class Initialized
DEBUG - 2022-07-05 12:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 12:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 12:23:37 --> Controller Class Initialized
INFO - 2022-07-05 12:23:37 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 12:23:37 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 12:23:37 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 12:23:37 --> Final output sent to browser
DEBUG - 2022-07-05 12:23:37 --> Total execution time: 0.1495
INFO - 2022-07-05 12:23:38 --> Config Class Initialized
INFO - 2022-07-05 12:23:38 --> Hooks Class Initialized
DEBUG - 2022-07-05 12:23:38 --> UTF-8 Support Enabled
INFO - 2022-07-05 12:23:38 --> Utf8 Class Initialized
INFO - 2022-07-05 12:23:38 --> URI Class Initialized
INFO - 2022-07-05 12:23:38 --> Router Class Initialized
INFO - 2022-07-05 12:23:38 --> Output Class Initialized
INFO - 2022-07-05 12:23:38 --> Security Class Initialized
DEBUG - 2022-07-05 12:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 12:23:38 --> Input Class Initialized
INFO - 2022-07-05 12:23:38 --> Language Class Initialized
INFO - 2022-07-05 12:23:38 --> Loader Class Initialized
INFO - 2022-07-05 12:23:38 --> Helper loaded: url_helper
INFO - 2022-07-05 12:23:38 --> Helper loaded: file_helper
INFO - 2022-07-05 12:23:38 --> Database Driver Class Initialized
INFO - 2022-07-05 12:23:38 --> Email Class Initialized
DEBUG - 2022-07-05 12:23:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 12:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 12:23:38 --> Controller Class Initialized
INFO - 2022-07-05 12:23:38 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 12:23:38 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 12:23:38 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 12:23:38 --> Final output sent to browser
DEBUG - 2022-07-05 12:23:38 --> Total execution time: 0.1070
INFO - 2022-07-05 12:23:39 --> Config Class Initialized
INFO - 2022-07-05 12:23:39 --> Hooks Class Initialized
DEBUG - 2022-07-05 12:23:39 --> UTF-8 Support Enabled
INFO - 2022-07-05 12:23:39 --> Utf8 Class Initialized
INFO - 2022-07-05 12:23:39 --> URI Class Initialized
INFO - 2022-07-05 12:23:39 --> Router Class Initialized
INFO - 2022-07-05 12:23:39 --> Output Class Initialized
INFO - 2022-07-05 12:23:39 --> Security Class Initialized
DEBUG - 2022-07-05 12:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 12:23:39 --> Input Class Initialized
INFO - 2022-07-05 12:23:39 --> Language Class Initialized
INFO - 2022-07-05 12:23:39 --> Loader Class Initialized
INFO - 2022-07-05 12:23:39 --> Helper loaded: url_helper
INFO - 2022-07-05 12:23:39 --> Helper loaded: file_helper
INFO - 2022-07-05 12:23:39 --> Database Driver Class Initialized
INFO - 2022-07-05 12:23:39 --> Email Class Initialized
DEBUG - 2022-07-05 12:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 12:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 12:23:39 --> Controller Class Initialized
INFO - 2022-07-05 12:23:39 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 12:23:39 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 12:23:39 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 12:23:39 --> Final output sent to browser
DEBUG - 2022-07-05 12:23:39 --> Total execution time: 0.0541
INFO - 2022-07-05 12:23:40 --> Config Class Initialized
INFO - 2022-07-05 12:23:40 --> Hooks Class Initialized
DEBUG - 2022-07-05 12:23:40 --> UTF-8 Support Enabled
INFO - 2022-07-05 12:23:40 --> Utf8 Class Initialized
INFO - 2022-07-05 12:23:40 --> URI Class Initialized
INFO - 2022-07-05 12:23:40 --> Router Class Initialized
INFO - 2022-07-05 12:23:40 --> Output Class Initialized
INFO - 2022-07-05 12:23:40 --> Security Class Initialized
DEBUG - 2022-07-05 12:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 12:23:40 --> Input Class Initialized
INFO - 2022-07-05 12:23:40 --> Language Class Initialized
INFO - 2022-07-05 12:23:40 --> Loader Class Initialized
INFO - 2022-07-05 12:23:40 --> Helper loaded: url_helper
INFO - 2022-07-05 12:23:40 --> Helper loaded: file_helper
INFO - 2022-07-05 12:23:40 --> Database Driver Class Initialized
INFO - 2022-07-05 12:23:40 --> Email Class Initialized
DEBUG - 2022-07-05 12:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 12:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 12:23:40 --> Controller Class Initialized
INFO - 2022-07-05 12:23:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 12:23:40 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 12:23:40 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 12:23:40 --> Final output sent to browser
DEBUG - 2022-07-05 12:23:40 --> Total execution time: 0.1374
INFO - 2022-07-05 12:23:45 --> Config Class Initialized
INFO - 2022-07-05 12:23:45 --> Hooks Class Initialized
DEBUG - 2022-07-05 12:23:45 --> UTF-8 Support Enabled
INFO - 2022-07-05 12:23:45 --> Utf8 Class Initialized
INFO - 2022-07-05 12:23:45 --> URI Class Initialized
INFO - 2022-07-05 12:23:45 --> Router Class Initialized
INFO - 2022-07-05 12:23:45 --> Output Class Initialized
INFO - 2022-07-05 12:23:45 --> Security Class Initialized
DEBUG - 2022-07-05 12:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 12:23:45 --> Input Class Initialized
INFO - 2022-07-05 12:23:45 --> Language Class Initialized
INFO - 2022-07-05 12:23:45 --> Loader Class Initialized
INFO - 2022-07-05 12:23:45 --> Helper loaded: url_helper
INFO - 2022-07-05 12:23:45 --> Helper loaded: file_helper
INFO - 2022-07-05 12:23:45 --> Database Driver Class Initialized
INFO - 2022-07-05 12:23:45 --> Email Class Initialized
DEBUG - 2022-07-05 12:23:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 12:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 12:23:45 --> Controller Class Initialized
INFO - 2022-07-05 12:23:45 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 12:23:45 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 12:23:45 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 12:23:45 --> Final output sent to browser
DEBUG - 2022-07-05 12:23:45 --> Total execution time: 0.0420
INFO - 2022-07-05 12:23:46 --> Config Class Initialized
INFO - 2022-07-05 12:23:46 --> Hooks Class Initialized
DEBUG - 2022-07-05 12:23:46 --> UTF-8 Support Enabled
INFO - 2022-07-05 12:23:46 --> Utf8 Class Initialized
INFO - 2022-07-05 12:23:46 --> URI Class Initialized
INFO - 2022-07-05 12:23:46 --> Router Class Initialized
INFO - 2022-07-05 12:23:46 --> Output Class Initialized
INFO - 2022-07-05 12:23:46 --> Security Class Initialized
DEBUG - 2022-07-05 12:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 12:23:46 --> Input Class Initialized
INFO - 2022-07-05 12:23:46 --> Language Class Initialized
INFO - 2022-07-05 12:23:46 --> Loader Class Initialized
INFO - 2022-07-05 12:23:46 --> Helper loaded: url_helper
INFO - 2022-07-05 12:23:46 --> Helper loaded: file_helper
INFO - 2022-07-05 12:23:46 --> Database Driver Class Initialized
INFO - 2022-07-05 12:23:47 --> Email Class Initialized
DEBUG - 2022-07-05 12:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 12:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 12:23:47 --> Controller Class Initialized
INFO - 2022-07-05 12:23:47 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 12:23:47 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 12:23:47 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 12:23:47 --> Final output sent to browser
DEBUG - 2022-07-05 12:23:47 --> Total execution time: 0.1677
INFO - 2022-07-05 12:23:47 --> Config Class Initialized
INFO - 2022-07-05 12:23:47 --> Hooks Class Initialized
DEBUG - 2022-07-05 12:23:47 --> UTF-8 Support Enabled
INFO - 2022-07-05 12:23:47 --> Utf8 Class Initialized
INFO - 2022-07-05 12:23:47 --> URI Class Initialized
INFO - 2022-07-05 12:23:47 --> Router Class Initialized
INFO - 2022-07-05 12:23:47 --> Output Class Initialized
INFO - 2022-07-05 12:23:47 --> Security Class Initialized
DEBUG - 2022-07-05 12:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 12:23:47 --> Input Class Initialized
INFO - 2022-07-05 12:23:47 --> Language Class Initialized
INFO - 2022-07-05 12:23:47 --> Loader Class Initialized
INFO - 2022-07-05 12:23:47 --> Helper loaded: url_helper
INFO - 2022-07-05 12:23:47 --> Helper loaded: file_helper
INFO - 2022-07-05 12:23:47 --> Database Driver Class Initialized
INFO - 2022-07-05 12:23:47 --> Email Class Initialized
DEBUG - 2022-07-05 12:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 12:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 12:23:47 --> Controller Class Initialized
INFO - 2022-07-05 12:23:47 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 12:23:47 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 12:23:47 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 12:23:47 --> Final output sent to browser
DEBUG - 2022-07-05 12:23:47 --> Total execution time: 0.0833
INFO - 2022-07-05 12:24:32 --> Config Class Initialized
INFO - 2022-07-05 12:24:32 --> Hooks Class Initialized
DEBUG - 2022-07-05 12:24:32 --> UTF-8 Support Enabled
INFO - 2022-07-05 12:24:32 --> Utf8 Class Initialized
INFO - 2022-07-05 12:24:32 --> URI Class Initialized
INFO - 2022-07-05 12:24:32 --> Router Class Initialized
INFO - 2022-07-05 12:24:32 --> Output Class Initialized
INFO - 2022-07-05 12:24:32 --> Security Class Initialized
DEBUG - 2022-07-05 12:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 12:24:32 --> Input Class Initialized
INFO - 2022-07-05 12:24:32 --> Language Class Initialized
INFO - 2022-07-05 12:24:32 --> Loader Class Initialized
INFO - 2022-07-05 12:24:32 --> Helper loaded: url_helper
INFO - 2022-07-05 12:24:32 --> Helper loaded: file_helper
INFO - 2022-07-05 12:24:32 --> Database Driver Class Initialized
INFO - 2022-07-05 12:24:32 --> Email Class Initialized
DEBUG - 2022-07-05 12:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 12:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 12:24:32 --> Controller Class Initialized
INFO - 2022-07-05 12:24:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 12:24:32 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 12:24:32 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 12:24:32 --> Final output sent to browser
DEBUG - 2022-07-05 12:24:32 --> Total execution time: 0.1267
INFO - 2022-07-05 12:24:33 --> Config Class Initialized
INFO - 2022-07-05 12:24:33 --> Hooks Class Initialized
DEBUG - 2022-07-05 12:24:33 --> UTF-8 Support Enabled
INFO - 2022-07-05 12:24:33 --> Utf8 Class Initialized
INFO - 2022-07-05 12:24:33 --> URI Class Initialized
INFO - 2022-07-05 12:24:33 --> Router Class Initialized
INFO - 2022-07-05 12:24:33 --> Output Class Initialized
INFO - 2022-07-05 12:24:33 --> Security Class Initialized
DEBUG - 2022-07-05 12:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 12:24:33 --> Input Class Initialized
INFO - 2022-07-05 12:24:33 --> Language Class Initialized
INFO - 2022-07-05 12:24:33 --> Loader Class Initialized
INFO - 2022-07-05 12:24:33 --> Helper loaded: url_helper
INFO - 2022-07-05 12:24:33 --> Helper loaded: file_helper
INFO - 2022-07-05 12:24:33 --> Database Driver Class Initialized
INFO - 2022-07-05 12:24:33 --> Email Class Initialized
DEBUG - 2022-07-05 12:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 12:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 12:24:33 --> Controller Class Initialized
INFO - 2022-07-05 12:24:33 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 12:24:33 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 12:24:33 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 12:24:33 --> Final output sent to browser
DEBUG - 2022-07-05 12:24:33 --> Total execution time: 0.0869
INFO - 2022-07-05 12:25:56 --> Config Class Initialized
INFO - 2022-07-05 12:25:56 --> Hooks Class Initialized
DEBUG - 2022-07-05 12:25:56 --> UTF-8 Support Enabled
INFO - 2022-07-05 12:25:56 --> Utf8 Class Initialized
INFO - 2022-07-05 12:25:56 --> URI Class Initialized
INFO - 2022-07-05 12:25:56 --> Router Class Initialized
INFO - 2022-07-05 12:25:56 --> Output Class Initialized
INFO - 2022-07-05 12:25:56 --> Security Class Initialized
DEBUG - 2022-07-05 12:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 12:25:56 --> Input Class Initialized
INFO - 2022-07-05 12:25:56 --> Language Class Initialized
INFO - 2022-07-05 12:25:56 --> Loader Class Initialized
INFO - 2022-07-05 12:25:56 --> Helper loaded: url_helper
INFO - 2022-07-05 12:25:56 --> Helper loaded: file_helper
INFO - 2022-07-05 12:25:56 --> Database Driver Class Initialized
INFO - 2022-07-05 12:25:56 --> Email Class Initialized
DEBUG - 2022-07-05 12:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 12:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 12:25:56 --> Controller Class Initialized
INFO - 2022-07-05 12:25:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 12:25:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 12:25:56 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 12:25:56 --> Final output sent to browser
DEBUG - 2022-07-05 12:25:56 --> Total execution time: 0.0641
INFO - 2022-07-05 12:25:57 --> Config Class Initialized
INFO - 2022-07-05 12:25:57 --> Hooks Class Initialized
DEBUG - 2022-07-05 12:25:57 --> UTF-8 Support Enabled
INFO - 2022-07-05 12:25:57 --> Utf8 Class Initialized
INFO - 2022-07-05 12:25:57 --> URI Class Initialized
INFO - 2022-07-05 12:25:57 --> Router Class Initialized
INFO - 2022-07-05 12:25:57 --> Output Class Initialized
INFO - 2022-07-05 12:25:57 --> Security Class Initialized
DEBUG - 2022-07-05 12:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 12:25:57 --> Input Class Initialized
INFO - 2022-07-05 12:25:57 --> Language Class Initialized
INFO - 2022-07-05 12:25:57 --> Loader Class Initialized
INFO - 2022-07-05 12:25:57 --> Helper loaded: url_helper
INFO - 2022-07-05 12:25:57 --> Helper loaded: file_helper
INFO - 2022-07-05 12:25:57 --> Database Driver Class Initialized
INFO - 2022-07-05 12:25:57 --> Email Class Initialized
DEBUG - 2022-07-05 12:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 12:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 12:25:57 --> Controller Class Initialized
INFO - 2022-07-05 12:25:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 12:25:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 12:25:57 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 12:25:57 --> Final output sent to browser
DEBUG - 2022-07-05 12:25:57 --> Total execution time: 0.1837
INFO - 2022-07-05 12:25:59 --> Config Class Initialized
INFO - 2022-07-05 12:25:59 --> Hooks Class Initialized
DEBUG - 2022-07-05 12:25:59 --> UTF-8 Support Enabled
INFO - 2022-07-05 12:25:59 --> Utf8 Class Initialized
INFO - 2022-07-05 12:25:59 --> URI Class Initialized
INFO - 2022-07-05 12:25:59 --> Router Class Initialized
INFO - 2022-07-05 12:25:59 --> Output Class Initialized
INFO - 2022-07-05 12:25:59 --> Security Class Initialized
DEBUG - 2022-07-05 12:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 12:25:59 --> Input Class Initialized
INFO - 2022-07-05 12:25:59 --> Language Class Initialized
INFO - 2022-07-05 12:25:59 --> Loader Class Initialized
INFO - 2022-07-05 12:25:59 --> Helper loaded: url_helper
INFO - 2022-07-05 12:25:59 --> Helper loaded: file_helper
INFO - 2022-07-05 12:25:59 --> Database Driver Class Initialized
INFO - 2022-07-05 12:25:59 --> Email Class Initialized
DEBUG - 2022-07-05 12:25:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 12:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 12:25:59 --> Controller Class Initialized
INFO - 2022-07-05 12:25:59 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 12:25:59 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 12:25:59 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 12:25:59 --> Final output sent to browser
DEBUG - 2022-07-05 12:25:59 --> Total execution time: 0.2244
INFO - 2022-07-05 12:26:00 --> Config Class Initialized
INFO - 2022-07-05 12:26:00 --> Hooks Class Initialized
DEBUG - 2022-07-05 12:26:00 --> UTF-8 Support Enabled
INFO - 2022-07-05 12:26:00 --> Utf8 Class Initialized
INFO - 2022-07-05 12:26:00 --> URI Class Initialized
INFO - 2022-07-05 12:26:00 --> Router Class Initialized
INFO - 2022-07-05 12:26:00 --> Output Class Initialized
INFO - 2022-07-05 12:26:00 --> Security Class Initialized
DEBUG - 2022-07-05 12:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 12:26:00 --> Input Class Initialized
INFO - 2022-07-05 12:26:00 --> Language Class Initialized
INFO - 2022-07-05 12:26:00 --> Loader Class Initialized
INFO - 2022-07-05 12:26:00 --> Helper loaded: url_helper
INFO - 2022-07-05 12:26:00 --> Helper loaded: file_helper
INFO - 2022-07-05 12:26:00 --> Database Driver Class Initialized
INFO - 2022-07-05 12:26:00 --> Email Class Initialized
DEBUG - 2022-07-05 12:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 12:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 12:26:00 --> Controller Class Initialized
INFO - 2022-07-05 12:26:00 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 12:26:00 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 12:26:00 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 12:26:00 --> Final output sent to browser
DEBUG - 2022-07-05 12:26:00 --> Total execution time: 0.1699
INFO - 2022-07-05 12:26:11 --> Config Class Initialized
INFO - 2022-07-05 12:26:11 --> Hooks Class Initialized
DEBUG - 2022-07-05 12:26:11 --> UTF-8 Support Enabled
INFO - 2022-07-05 12:26:11 --> Utf8 Class Initialized
INFO - 2022-07-05 12:26:11 --> URI Class Initialized
INFO - 2022-07-05 12:26:11 --> Router Class Initialized
INFO - 2022-07-05 12:26:11 --> Output Class Initialized
INFO - 2022-07-05 12:26:11 --> Security Class Initialized
DEBUG - 2022-07-05 12:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 12:26:11 --> Input Class Initialized
INFO - 2022-07-05 12:26:11 --> Language Class Initialized
INFO - 2022-07-05 12:26:11 --> Loader Class Initialized
INFO - 2022-07-05 12:26:11 --> Helper loaded: url_helper
INFO - 2022-07-05 12:26:11 --> Helper loaded: file_helper
INFO - 2022-07-05 12:26:11 --> Database Driver Class Initialized
INFO - 2022-07-05 12:26:11 --> Email Class Initialized
DEBUG - 2022-07-05 12:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 12:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 12:26:11 --> Controller Class Initialized
INFO - 2022-07-05 12:26:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 12:26:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 12:26:11 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 12:26:11 --> Final output sent to browser
DEBUG - 2022-07-05 12:26:11 --> Total execution time: 0.1509
INFO - 2022-07-05 12:35:46 --> Config Class Initialized
INFO - 2022-07-05 12:35:46 --> Hooks Class Initialized
DEBUG - 2022-07-05 12:35:46 --> UTF-8 Support Enabled
INFO - 2022-07-05 12:35:46 --> Utf8 Class Initialized
INFO - 2022-07-05 12:35:46 --> URI Class Initialized
INFO - 2022-07-05 12:35:46 --> Router Class Initialized
INFO - 2022-07-05 12:35:46 --> Output Class Initialized
INFO - 2022-07-05 12:35:46 --> Security Class Initialized
DEBUG - 2022-07-05 12:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 12:35:46 --> Input Class Initialized
INFO - 2022-07-05 12:35:46 --> Language Class Initialized
INFO - 2022-07-05 12:35:46 --> Loader Class Initialized
INFO - 2022-07-05 12:35:46 --> Helper loaded: url_helper
INFO - 2022-07-05 12:35:46 --> Helper loaded: file_helper
INFO - 2022-07-05 12:35:46 --> Database Driver Class Initialized
INFO - 2022-07-05 12:35:47 --> Email Class Initialized
DEBUG - 2022-07-05 12:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 12:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 12:35:47 --> Controller Class Initialized
INFO - 2022-07-05 12:35:47 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 12:35:47 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 12:35:47 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 12:35:47 --> Final output sent to browser
DEBUG - 2022-07-05 12:35:47 --> Total execution time: 0.3189
INFO - 2022-07-05 12:38:00 --> Config Class Initialized
INFO - 2022-07-05 12:38:00 --> Hooks Class Initialized
DEBUG - 2022-07-05 12:38:00 --> UTF-8 Support Enabled
INFO - 2022-07-05 12:38:00 --> Utf8 Class Initialized
INFO - 2022-07-05 12:38:00 --> URI Class Initialized
INFO - 2022-07-05 12:38:00 --> Router Class Initialized
INFO - 2022-07-05 12:38:00 --> Output Class Initialized
INFO - 2022-07-05 12:38:00 --> Security Class Initialized
DEBUG - 2022-07-05 12:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 12:38:00 --> Input Class Initialized
INFO - 2022-07-05 12:38:00 --> Language Class Initialized
INFO - 2022-07-05 12:38:00 --> Loader Class Initialized
INFO - 2022-07-05 12:38:00 --> Helper loaded: url_helper
INFO - 2022-07-05 12:38:00 --> Helper loaded: file_helper
INFO - 2022-07-05 12:38:00 --> Database Driver Class Initialized
INFO - 2022-07-05 12:38:00 --> Email Class Initialized
DEBUG - 2022-07-05 12:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 12:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 12:38:00 --> Controller Class Initialized
INFO - 2022-07-05 12:38:00 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 12:38:00 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 12:38:00 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 12:38:00 --> Final output sent to browser
DEBUG - 2022-07-05 12:38:00 --> Total execution time: 0.0737
INFO - 2022-07-05 12:38:37 --> Config Class Initialized
INFO - 2022-07-05 12:38:37 --> Hooks Class Initialized
DEBUG - 2022-07-05 12:38:37 --> UTF-8 Support Enabled
INFO - 2022-07-05 12:38:37 --> Utf8 Class Initialized
INFO - 2022-07-05 12:38:37 --> URI Class Initialized
INFO - 2022-07-05 12:38:37 --> Router Class Initialized
INFO - 2022-07-05 12:38:37 --> Output Class Initialized
INFO - 2022-07-05 12:38:37 --> Security Class Initialized
DEBUG - 2022-07-05 12:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 12:38:37 --> Input Class Initialized
INFO - 2022-07-05 12:38:37 --> Language Class Initialized
INFO - 2022-07-05 12:38:37 --> Loader Class Initialized
INFO - 2022-07-05 12:38:37 --> Helper loaded: url_helper
INFO - 2022-07-05 12:38:37 --> Helper loaded: file_helper
INFO - 2022-07-05 12:38:37 --> Database Driver Class Initialized
INFO - 2022-07-05 12:38:37 --> Email Class Initialized
DEBUG - 2022-07-05 12:38:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 12:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 12:38:37 --> Controller Class Initialized
INFO - 2022-07-05 12:38:37 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 12:38:37 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 12:38:37 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 12:38:37 --> Final output sent to browser
DEBUG - 2022-07-05 12:38:37 --> Total execution time: 0.1182
INFO - 2022-07-05 12:38:40 --> Config Class Initialized
INFO - 2022-07-05 12:38:40 --> Hooks Class Initialized
DEBUG - 2022-07-05 12:38:40 --> UTF-8 Support Enabled
INFO - 2022-07-05 12:38:40 --> Utf8 Class Initialized
INFO - 2022-07-05 12:38:40 --> URI Class Initialized
INFO - 2022-07-05 12:38:40 --> Router Class Initialized
INFO - 2022-07-05 12:38:40 --> Output Class Initialized
INFO - 2022-07-05 12:38:40 --> Security Class Initialized
DEBUG - 2022-07-05 12:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 12:38:40 --> Input Class Initialized
INFO - 2022-07-05 12:38:40 --> Language Class Initialized
INFO - 2022-07-05 12:38:40 --> Loader Class Initialized
INFO - 2022-07-05 12:38:40 --> Helper loaded: url_helper
INFO - 2022-07-05 12:38:40 --> Helper loaded: file_helper
INFO - 2022-07-05 12:38:40 --> Database Driver Class Initialized
INFO - 2022-07-05 12:38:40 --> Email Class Initialized
DEBUG - 2022-07-05 12:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 12:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 12:38:40 --> Controller Class Initialized
INFO - 2022-07-05 12:38:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 12:38:40 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 12:38:40 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 12:38:40 --> Final output sent to browser
DEBUG - 2022-07-05 12:38:40 --> Total execution time: 0.0558
INFO - 2022-07-05 12:38:41 --> Config Class Initialized
INFO - 2022-07-05 12:38:41 --> Hooks Class Initialized
DEBUG - 2022-07-05 12:38:41 --> UTF-8 Support Enabled
INFO - 2022-07-05 12:38:41 --> Utf8 Class Initialized
INFO - 2022-07-05 12:38:41 --> URI Class Initialized
INFO - 2022-07-05 12:38:41 --> Router Class Initialized
INFO - 2022-07-05 12:38:41 --> Output Class Initialized
INFO - 2022-07-05 12:38:41 --> Security Class Initialized
DEBUG - 2022-07-05 12:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 12:38:41 --> Input Class Initialized
INFO - 2022-07-05 12:38:41 --> Language Class Initialized
INFO - 2022-07-05 12:38:41 --> Loader Class Initialized
INFO - 2022-07-05 12:38:41 --> Helper loaded: url_helper
INFO - 2022-07-05 12:38:41 --> Helper loaded: file_helper
INFO - 2022-07-05 12:38:41 --> Database Driver Class Initialized
INFO - 2022-07-05 12:38:41 --> Email Class Initialized
DEBUG - 2022-07-05 12:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 12:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 12:38:41 --> Controller Class Initialized
INFO - 2022-07-05 12:38:41 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 12:38:41 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 12:38:41 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 12:38:41 --> Final output sent to browser
DEBUG - 2022-07-05 12:38:41 --> Total execution time: 0.2055
INFO - 2022-07-05 12:39:09 --> Config Class Initialized
INFO - 2022-07-05 12:39:09 --> Hooks Class Initialized
DEBUG - 2022-07-05 12:39:09 --> UTF-8 Support Enabled
INFO - 2022-07-05 12:39:09 --> Utf8 Class Initialized
INFO - 2022-07-05 12:39:09 --> URI Class Initialized
INFO - 2022-07-05 12:39:09 --> Router Class Initialized
INFO - 2022-07-05 12:39:09 --> Output Class Initialized
INFO - 2022-07-05 12:39:09 --> Security Class Initialized
DEBUG - 2022-07-05 12:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 12:39:09 --> Input Class Initialized
INFO - 2022-07-05 12:39:09 --> Language Class Initialized
INFO - 2022-07-05 12:39:09 --> Loader Class Initialized
INFO - 2022-07-05 12:39:09 --> Helper loaded: url_helper
INFO - 2022-07-05 12:39:09 --> Helper loaded: file_helper
INFO - 2022-07-05 12:39:09 --> Database Driver Class Initialized
INFO - 2022-07-05 12:39:09 --> Email Class Initialized
DEBUG - 2022-07-05 12:39:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 12:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 12:39:09 --> Controller Class Initialized
INFO - 2022-07-05 12:39:09 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 12:39:09 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 12:39:09 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 12:39:09 --> Final output sent to browser
DEBUG - 2022-07-05 12:39:09 --> Total execution time: 0.0388
INFO - 2022-07-05 12:39:17 --> Config Class Initialized
INFO - 2022-07-05 12:39:17 --> Hooks Class Initialized
DEBUG - 2022-07-05 12:39:17 --> UTF-8 Support Enabled
INFO - 2022-07-05 12:39:17 --> Utf8 Class Initialized
INFO - 2022-07-05 12:39:17 --> URI Class Initialized
INFO - 2022-07-05 12:39:17 --> Router Class Initialized
INFO - 2022-07-05 12:39:17 --> Output Class Initialized
INFO - 2022-07-05 12:39:17 --> Security Class Initialized
DEBUG - 2022-07-05 12:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 12:39:17 --> Input Class Initialized
INFO - 2022-07-05 12:39:17 --> Language Class Initialized
INFO - 2022-07-05 12:39:17 --> Loader Class Initialized
INFO - 2022-07-05 12:39:17 --> Helper loaded: url_helper
INFO - 2022-07-05 12:39:17 --> Helper loaded: file_helper
INFO - 2022-07-05 12:39:17 --> Database Driver Class Initialized
INFO - 2022-07-05 12:39:17 --> Email Class Initialized
DEBUG - 2022-07-05 12:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 12:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 12:39:17 --> Controller Class Initialized
INFO - 2022-07-05 12:39:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 12:39:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 12:39:17 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 12:39:17 --> Final output sent to browser
DEBUG - 2022-07-05 12:39:17 --> Total execution time: 0.0965
INFO - 2022-07-05 12:57:34 --> Config Class Initialized
INFO - 2022-07-05 12:57:34 --> Hooks Class Initialized
DEBUG - 2022-07-05 12:57:34 --> UTF-8 Support Enabled
INFO - 2022-07-05 12:57:34 --> Utf8 Class Initialized
INFO - 2022-07-05 12:57:34 --> URI Class Initialized
INFO - 2022-07-05 12:57:34 --> Router Class Initialized
INFO - 2022-07-05 12:57:34 --> Output Class Initialized
INFO - 2022-07-05 12:57:34 --> Security Class Initialized
DEBUG - 2022-07-05 12:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 12:57:34 --> Input Class Initialized
INFO - 2022-07-05 12:57:34 --> Language Class Initialized
INFO - 2022-07-05 12:57:34 --> Loader Class Initialized
INFO - 2022-07-05 12:57:34 --> Helper loaded: url_helper
INFO - 2022-07-05 12:57:34 --> Helper loaded: file_helper
INFO - 2022-07-05 12:57:34 --> Database Driver Class Initialized
INFO - 2022-07-05 12:57:34 --> Email Class Initialized
DEBUG - 2022-07-05 12:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 12:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 12:57:34 --> Controller Class Initialized
INFO - 2022-07-05 12:57:34 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 12:57:34 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 12:57:34 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 12:57:34 --> Final output sent to browser
DEBUG - 2022-07-05 12:57:34 --> Total execution time: 0.1124
INFO - 2022-07-05 12:57:36 --> Config Class Initialized
INFO - 2022-07-05 12:57:36 --> Hooks Class Initialized
DEBUG - 2022-07-05 12:57:36 --> UTF-8 Support Enabled
INFO - 2022-07-05 12:57:36 --> Utf8 Class Initialized
INFO - 2022-07-05 12:57:36 --> URI Class Initialized
INFO - 2022-07-05 12:57:36 --> Router Class Initialized
INFO - 2022-07-05 12:57:36 --> Output Class Initialized
INFO - 2022-07-05 12:57:36 --> Security Class Initialized
DEBUG - 2022-07-05 12:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 12:57:36 --> Input Class Initialized
INFO - 2022-07-05 12:57:36 --> Language Class Initialized
INFO - 2022-07-05 12:57:36 --> Loader Class Initialized
INFO - 2022-07-05 12:57:36 --> Helper loaded: url_helper
INFO - 2022-07-05 12:57:36 --> Helper loaded: file_helper
INFO - 2022-07-05 12:57:36 --> Database Driver Class Initialized
INFO - 2022-07-05 12:57:36 --> Email Class Initialized
DEBUG - 2022-07-05 12:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 12:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 12:57:36 --> Controller Class Initialized
INFO - 2022-07-05 12:57:36 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 12:57:36 --> Session class already loaded. Second attempt ignored.
INFO - 2022-07-05 12:57:36 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 12:57:36 --> Final output sent to browser
DEBUG - 2022-07-05 12:57:36 --> Total execution time: 0.1621
INFO - 2022-07-05 12:58:21 --> Config Class Initialized
INFO - 2022-07-05 12:58:21 --> Hooks Class Initialized
DEBUG - 2022-07-05 12:58:21 --> UTF-8 Support Enabled
INFO - 2022-07-05 12:58:21 --> Utf8 Class Initialized
INFO - 2022-07-05 12:58:21 --> URI Class Initialized
INFO - 2022-07-05 12:58:21 --> Router Class Initialized
INFO - 2022-07-05 12:58:21 --> Output Class Initialized
INFO - 2022-07-05 12:58:21 --> Security Class Initialized
DEBUG - 2022-07-05 12:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 12:58:21 --> Input Class Initialized
INFO - 2022-07-05 12:58:21 --> Language Class Initialized
ERROR - 2022-07-05 12:58:21 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE), expecting function (T_FUNCTION) or const (T_CONST) C:\wamp64\www\qr\application\controllers\Tokenctrl.php 287
INFO - 2022-07-05 12:58:40 --> Config Class Initialized
INFO - 2022-07-05 12:58:40 --> Hooks Class Initialized
DEBUG - 2022-07-05 12:58:40 --> UTF-8 Support Enabled
INFO - 2022-07-05 12:58:40 --> Utf8 Class Initialized
INFO - 2022-07-05 12:58:40 --> URI Class Initialized
INFO - 2022-07-05 12:58:40 --> Router Class Initialized
INFO - 2022-07-05 12:58:40 --> Output Class Initialized
INFO - 2022-07-05 12:58:40 --> Security Class Initialized
DEBUG - 2022-07-05 12:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 12:58:40 --> Input Class Initialized
INFO - 2022-07-05 12:58:40 --> Language Class Initialized
INFO - 2022-07-05 12:58:40 --> Loader Class Initialized
INFO - 2022-07-05 12:58:40 --> Helper loaded: url_helper
INFO - 2022-07-05 12:58:40 --> Helper loaded: file_helper
INFO - 2022-07-05 12:58:40 --> Database Driver Class Initialized
INFO - 2022-07-05 12:58:40 --> Email Class Initialized
DEBUG - 2022-07-05 12:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 12:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 12:58:40 --> Controller Class Initialized
INFO - 2022-07-05 12:58:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 12:58:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 12:58:40 --> insertedINSERT INTO `tokendetails` (`td_tk`, `td_cs`, `td_visited_date`) VALUES (5, 0, '2022-07-05')
INFO - 2022-07-05 12:58:40 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 12:58:40 --> Final output sent to browser
DEBUG - 2022-07-05 12:58:40 --> Total execution time: 0.2401
INFO - 2022-07-05 12:58:42 --> Config Class Initialized
INFO - 2022-07-05 12:58:42 --> Hooks Class Initialized
DEBUG - 2022-07-05 12:58:42 --> UTF-8 Support Enabled
INFO - 2022-07-05 12:58:42 --> Utf8 Class Initialized
INFO - 2022-07-05 12:58:42 --> URI Class Initialized
INFO - 2022-07-05 12:58:42 --> Router Class Initialized
INFO - 2022-07-05 12:58:42 --> Output Class Initialized
INFO - 2022-07-05 12:58:42 --> Security Class Initialized
DEBUG - 2022-07-05 12:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 12:58:42 --> Input Class Initialized
INFO - 2022-07-05 12:58:42 --> Language Class Initialized
INFO - 2022-07-05 12:58:42 --> Loader Class Initialized
INFO - 2022-07-05 12:58:42 --> Helper loaded: url_helper
INFO - 2022-07-05 12:58:42 --> Helper loaded: file_helper
INFO - 2022-07-05 12:58:42 --> Database Driver Class Initialized
INFO - 2022-07-05 12:58:42 --> Email Class Initialized
DEBUG - 2022-07-05 12:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 12:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 12:58:42 --> Controller Class Initialized
INFO - 2022-07-05 12:58:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 12:58:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 12:58:42 --> insertedINSERT INTO `tokendetails` (`td_tk`, `td_cs`, `td_visited_date`) VALUES (6, 0, '2022-07-05')
INFO - 2022-07-05 12:58:42 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 12:58:42 --> Final output sent to browser
DEBUG - 2022-07-05 12:58:42 --> Total execution time: 0.0525
INFO - 2022-07-05 12:58:43 --> Config Class Initialized
INFO - 2022-07-05 12:58:43 --> Hooks Class Initialized
DEBUG - 2022-07-05 12:58:43 --> UTF-8 Support Enabled
INFO - 2022-07-05 12:58:43 --> Utf8 Class Initialized
INFO - 2022-07-05 12:58:43 --> URI Class Initialized
INFO - 2022-07-05 12:58:43 --> Router Class Initialized
INFO - 2022-07-05 12:58:43 --> Output Class Initialized
INFO - 2022-07-05 12:58:43 --> Security Class Initialized
DEBUG - 2022-07-05 12:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 12:58:43 --> Input Class Initialized
INFO - 2022-07-05 12:58:43 --> Language Class Initialized
INFO - 2022-07-05 12:58:43 --> Loader Class Initialized
INFO - 2022-07-05 12:58:43 --> Helper loaded: url_helper
INFO - 2022-07-05 12:58:43 --> Helper loaded: file_helper
INFO - 2022-07-05 12:58:43 --> Database Driver Class Initialized
INFO - 2022-07-05 12:58:43 --> Email Class Initialized
DEBUG - 2022-07-05 12:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 12:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 12:58:43 --> Controller Class Initialized
INFO - 2022-07-05 12:58:43 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 12:58:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 12:58:43 --> insertedINSERT INTO `tokendetails` (`td_tk`, `td_cs`, `td_visited_date`) VALUES (7, 0, '2022-07-05')
INFO - 2022-07-05 12:58:43 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 12:58:43 --> Final output sent to browser
DEBUG - 2022-07-05 12:58:43 --> Total execution time: 0.1524
INFO - 2022-07-05 13:18:08 --> Config Class Initialized
INFO - 2022-07-05 13:18:08 --> Hooks Class Initialized
DEBUG - 2022-07-05 13:18:08 --> UTF-8 Support Enabled
INFO - 2022-07-05 13:18:08 --> Utf8 Class Initialized
INFO - 2022-07-05 13:18:08 --> URI Class Initialized
INFO - 2022-07-05 13:18:08 --> Router Class Initialized
INFO - 2022-07-05 13:18:08 --> Output Class Initialized
INFO - 2022-07-05 13:18:08 --> Security Class Initialized
DEBUG - 2022-07-05 13:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 13:18:08 --> Input Class Initialized
INFO - 2022-07-05 13:18:08 --> Language Class Initialized
INFO - 2022-07-05 13:18:08 --> Loader Class Initialized
INFO - 2022-07-05 13:18:08 --> Helper loaded: url_helper
INFO - 2022-07-05 13:18:08 --> Helper loaded: file_helper
INFO - 2022-07-05 13:18:08 --> Database Driver Class Initialized
INFO - 2022-07-05 13:18:08 --> Email Class Initialized
DEBUG - 2022-07-05 13:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 13:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 13:18:08 --> Controller Class Initialized
INFO - 2022-07-05 13:18:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 13:18:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 13:18:08 --> insertedINSERT INTO `tokendetails` (`td_tk`, `td_cs`, `td_visited_date`) VALUES (8, 0, '2022-07-05')
INFO - 2022-07-05 13:18:08 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 13:18:08 --> Final output sent to browser
DEBUG - 2022-07-05 13:18:08 --> Total execution time: 0.0402
INFO - 2022-07-05 13:18:12 --> Config Class Initialized
INFO - 2022-07-05 13:18:12 --> Hooks Class Initialized
DEBUG - 2022-07-05 13:18:12 --> UTF-8 Support Enabled
INFO - 2022-07-05 13:18:12 --> Utf8 Class Initialized
INFO - 2022-07-05 13:18:12 --> URI Class Initialized
INFO - 2022-07-05 13:18:12 --> Router Class Initialized
INFO - 2022-07-05 13:18:12 --> Output Class Initialized
INFO - 2022-07-05 13:18:12 --> Security Class Initialized
DEBUG - 2022-07-05 13:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 13:18:12 --> Input Class Initialized
INFO - 2022-07-05 13:18:12 --> Language Class Initialized
INFO - 2022-07-05 13:18:12 --> Loader Class Initialized
INFO - 2022-07-05 13:18:12 --> Helper loaded: url_helper
INFO - 2022-07-05 13:18:12 --> Helper loaded: file_helper
INFO - 2022-07-05 13:18:12 --> Database Driver Class Initialized
INFO - 2022-07-05 13:18:12 --> Email Class Initialized
DEBUG - 2022-07-05 13:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 13:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 13:18:12 --> Controller Class Initialized
INFO - 2022-07-05 13:18:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 13:18:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 13:18:12 --> insertedINSERT INTO `tokendetails` (`td_tk`, `td_cs`, `td_visited_date`) VALUES (9, 0, '2022-07-05')
INFO - 2022-07-05 13:18:12 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 13:18:12 --> Final output sent to browser
DEBUG - 2022-07-05 13:18:12 --> Total execution time: 0.0536
INFO - 2022-07-05 13:27:14 --> Config Class Initialized
INFO - 2022-07-05 13:27:14 --> Hooks Class Initialized
DEBUG - 2022-07-05 13:27:14 --> UTF-8 Support Enabled
INFO - 2022-07-05 13:27:14 --> Utf8 Class Initialized
INFO - 2022-07-05 13:27:14 --> URI Class Initialized
INFO - 2022-07-05 13:27:14 --> Router Class Initialized
INFO - 2022-07-05 13:27:14 --> Output Class Initialized
INFO - 2022-07-05 13:27:14 --> Security Class Initialized
DEBUG - 2022-07-05 13:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 13:27:14 --> Input Class Initialized
INFO - 2022-07-05 13:27:14 --> Language Class Initialized
INFO - 2022-07-05 13:27:14 --> Loader Class Initialized
INFO - 2022-07-05 13:27:14 --> Helper loaded: url_helper
INFO - 2022-07-05 13:27:14 --> Helper loaded: file_helper
INFO - 2022-07-05 13:27:14 --> Database Driver Class Initialized
INFO - 2022-07-05 13:27:14 --> Email Class Initialized
DEBUG - 2022-07-05 13:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 13:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 13:27:14 --> Controller Class Initialized
INFO - 2022-07-05 13:27:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 13:27:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 13:27:14 --> insertedINSERT INTO `tokendetails` (`td_tk`, `td_cs`, `td_visited_date`) VALUES (10, 0, '2022-07-05')
INFO - 2022-07-05 13:27:14 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 13:27:14 --> Final output sent to browser
DEBUG - 2022-07-05 13:27:14 --> Total execution time: 0.2556
INFO - 2022-07-05 13:28:28 --> Config Class Initialized
INFO - 2022-07-05 13:28:28 --> Hooks Class Initialized
DEBUG - 2022-07-05 13:28:28 --> UTF-8 Support Enabled
INFO - 2022-07-05 13:28:28 --> Utf8 Class Initialized
INFO - 2022-07-05 13:28:28 --> URI Class Initialized
INFO - 2022-07-05 13:28:28 --> Router Class Initialized
INFO - 2022-07-05 13:28:28 --> Output Class Initialized
INFO - 2022-07-05 13:28:28 --> Security Class Initialized
DEBUG - 2022-07-05 13:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-05 13:28:28 --> Input Class Initialized
INFO - 2022-07-05 13:28:28 --> Language Class Initialized
INFO - 2022-07-05 13:28:28 --> Loader Class Initialized
INFO - 2022-07-05 13:28:28 --> Helper loaded: url_helper
INFO - 2022-07-05 13:28:28 --> Helper loaded: file_helper
INFO - 2022-07-05 13:28:28 --> Database Driver Class Initialized
INFO - 2022-07-05 13:28:28 --> Email Class Initialized
DEBUG - 2022-07-05 13:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-05 13:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-05 13:28:28 --> Controller Class Initialized
INFO - 2022-07-05 13:28:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-07-05 13:28:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 13:28:29 --> insertedINSERT INTO `tokendetails` (`td_tk`, `td_cs`, `td_visited_date`) VALUES (11, 0, '2022-07-05')
INFO - 2022-07-05 13:28:29 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen_1.php
INFO - 2022-07-05 13:28:29 --> Final output sent to browser
DEBUG - 2022-07-05 13:28:29 --> Total execution time: 0.1534
