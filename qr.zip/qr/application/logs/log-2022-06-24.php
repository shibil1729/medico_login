<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-06-24 06:02:41 --> Config Class Initialized
INFO - 2022-06-24 06:02:41 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:02:41 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:02:41 --> Utf8 Class Initialized
INFO - 2022-06-24 06:02:41 --> URI Class Initialized
INFO - 2022-06-24 06:02:41 --> Router Class Initialized
INFO - 2022-06-24 06:02:41 --> Output Class Initialized
INFO - 2022-06-24 06:02:41 --> Security Class Initialized
DEBUG - 2022-06-24 06:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:02:41 --> Input Class Initialized
INFO - 2022-06-24 06:02:41 --> Language Class Initialized
INFO - 2022-06-24 06:02:41 --> Loader Class Initialized
INFO - 2022-06-24 06:02:41 --> Helper loaded: url_helper
INFO - 2022-06-24 06:02:41 --> Helper loaded: file_helper
INFO - 2022-06-24 06:02:41 --> Database Driver Class Initialized
ERROR - 2022-06-24 06:02:41 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'tokensys' C:\wamp64\www\qr\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2022-06-24 06:02:41 --> Unable to connect to the database
INFO - 2022-06-24 06:02:41 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-24 06:09:28 --> Config Class Initialized
INFO - 2022-06-24 06:09:28 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:09:28 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:09:28 --> Utf8 Class Initialized
INFO - 2022-06-24 06:09:28 --> URI Class Initialized
INFO - 2022-06-24 06:09:28 --> Router Class Initialized
INFO - 2022-06-24 06:09:28 --> Output Class Initialized
INFO - 2022-06-24 06:09:28 --> Security Class Initialized
DEBUG - 2022-06-24 06:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:09:28 --> Input Class Initialized
INFO - 2022-06-24 06:09:28 --> Language Class Initialized
INFO - 2022-06-24 06:09:28 --> Loader Class Initialized
INFO - 2022-06-24 06:09:28 --> Helper loaded: url_helper
INFO - 2022-06-24 06:09:28 --> Helper loaded: file_helper
INFO - 2022-06-24 06:09:28 --> Database Driver Class Initialized
INFO - 2022-06-24 06:09:28 --> Email Class Initialized
DEBUG - 2022-06-24 06:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:09:29 --> Controller Class Initialized
INFO - 2022-06-24 06:09:29 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:09:29 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:09:29 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 06:09:29 --> Final output sent to browser
DEBUG - 2022-06-24 06:09:29 --> Total execution time: 0.1755
INFO - 2022-06-24 06:09:42 --> Config Class Initialized
INFO - 2022-06-24 06:09:42 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:09:42 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:09:42 --> Utf8 Class Initialized
INFO - 2022-06-24 06:09:42 --> URI Class Initialized
INFO - 2022-06-24 06:09:42 --> Router Class Initialized
INFO - 2022-06-24 06:09:42 --> Output Class Initialized
INFO - 2022-06-24 06:09:42 --> Security Class Initialized
DEBUG - 2022-06-24 06:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:09:42 --> Input Class Initialized
INFO - 2022-06-24 06:09:42 --> Language Class Initialized
INFO - 2022-06-24 06:09:42 --> Loader Class Initialized
INFO - 2022-06-24 06:09:42 --> Helper loaded: url_helper
INFO - 2022-06-24 06:09:42 --> Helper loaded: file_helper
INFO - 2022-06-24 06:09:42 --> Database Driver Class Initialized
INFO - 2022-06-24 06:09:42 --> Email Class Initialized
DEBUG - 2022-06-24 06:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:09:42 --> Controller Class Initialized
INFO - 2022-06-24 06:09:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:09:42 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:09:42 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-24 06:09:42 --> Final output sent to browser
DEBUG - 2022-06-24 06:09:42 --> Total execution time: 0.1048
INFO - 2022-06-24 06:09:46 --> Config Class Initialized
INFO - 2022-06-24 06:09:46 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:09:46 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:09:46 --> Utf8 Class Initialized
INFO - 2022-06-24 06:09:46 --> URI Class Initialized
INFO - 2022-06-24 06:09:46 --> Router Class Initialized
INFO - 2022-06-24 06:09:46 --> Output Class Initialized
INFO - 2022-06-24 06:09:46 --> Security Class Initialized
DEBUG - 2022-06-24 06:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:09:46 --> Input Class Initialized
INFO - 2022-06-24 06:09:46 --> Language Class Initialized
INFO - 2022-06-24 06:09:46 --> Loader Class Initialized
INFO - 2022-06-24 06:09:46 --> Helper loaded: url_helper
INFO - 2022-06-24 06:09:46 --> Helper loaded: file_helper
INFO - 2022-06-24 06:09:46 --> Database Driver Class Initialized
INFO - 2022-06-24 06:09:46 --> Email Class Initialized
DEBUG - 2022-06-24 06:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:09:46 --> Controller Class Initialized
INFO - 2022-06-24 06:09:46 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:09:46 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:09:46 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-24 06:09:46 --> Final output sent to browser
DEBUG - 2022-06-24 06:09:46 --> Total execution time: 0.0316
INFO - 2022-06-24 06:09:48 --> Config Class Initialized
INFO - 2022-06-24 06:09:48 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:09:48 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:09:48 --> Utf8 Class Initialized
INFO - 2022-06-24 06:09:48 --> URI Class Initialized
INFO - 2022-06-24 06:09:48 --> Router Class Initialized
INFO - 2022-06-24 06:09:48 --> Output Class Initialized
INFO - 2022-06-24 06:09:48 --> Security Class Initialized
DEBUG - 2022-06-24 06:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:09:48 --> Input Class Initialized
INFO - 2022-06-24 06:09:48 --> Language Class Initialized
INFO - 2022-06-24 06:09:48 --> Loader Class Initialized
INFO - 2022-06-24 06:09:48 --> Helper loaded: url_helper
INFO - 2022-06-24 06:09:48 --> Helper loaded: file_helper
INFO - 2022-06-24 06:09:48 --> Database Driver Class Initialized
INFO - 2022-06-24 06:09:48 --> Email Class Initialized
DEBUG - 2022-06-24 06:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:09:48 --> Controller Class Initialized
INFO - 2022-06-24 06:09:48 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:09:48 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:09:48 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-24 06:09:48 --> Final output sent to browser
DEBUG - 2022-06-24 06:09:48 --> Total execution time: 0.0310
INFO - 2022-06-24 06:15:46 --> Config Class Initialized
INFO - 2022-06-24 06:15:46 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:15:46 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:15:46 --> Utf8 Class Initialized
INFO - 2022-06-24 06:15:46 --> URI Class Initialized
INFO - 2022-06-24 06:15:46 --> Router Class Initialized
INFO - 2022-06-24 06:15:46 --> Output Class Initialized
INFO - 2022-06-24 06:15:46 --> Security Class Initialized
DEBUG - 2022-06-24 06:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:15:46 --> Input Class Initialized
INFO - 2022-06-24 06:15:46 --> Language Class Initialized
INFO - 2022-06-24 06:15:46 --> Loader Class Initialized
INFO - 2022-06-24 06:15:46 --> Helper loaded: url_helper
INFO - 2022-06-24 06:15:46 --> Helper loaded: file_helper
INFO - 2022-06-24 06:15:46 --> Database Driver Class Initialized
INFO - 2022-06-24 06:15:46 --> Email Class Initialized
DEBUG - 2022-06-24 06:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:15:46 --> Controller Class Initialized
INFO - 2022-06-24 06:15:46 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:15:46 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:15:46 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-24 06:15:46 --> Final output sent to browser
DEBUG - 2022-06-24 06:15:46 --> Total execution time: 0.0564
INFO - 2022-06-24 06:15:55 --> Config Class Initialized
INFO - 2022-06-24 06:15:55 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:15:55 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:15:55 --> Utf8 Class Initialized
INFO - 2022-06-24 06:15:55 --> URI Class Initialized
INFO - 2022-06-24 06:15:55 --> Router Class Initialized
INFO - 2022-06-24 06:15:55 --> Output Class Initialized
INFO - 2022-06-24 06:15:55 --> Security Class Initialized
DEBUG - 2022-06-24 06:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:15:55 --> Input Class Initialized
INFO - 2022-06-24 06:15:55 --> Language Class Initialized
INFO - 2022-06-24 06:15:55 --> Loader Class Initialized
INFO - 2022-06-24 06:15:55 --> Helper loaded: url_helper
INFO - 2022-06-24 06:15:55 --> Helper loaded: file_helper
INFO - 2022-06-24 06:15:55 --> Database Driver Class Initialized
INFO - 2022-06-24 06:15:55 --> Email Class Initialized
DEBUG - 2022-06-24 06:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:15:55 --> Controller Class Initialized
INFO - 2022-06-24 06:15:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:15:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 06:15:55 --> test
INFO - 2022-06-24 06:15:55 --> Final output sent to browser
DEBUG - 2022-06-24 06:15:55 --> Total execution time: 0.0335
INFO - 2022-06-24 06:15:55 --> Config Class Initialized
INFO - 2022-06-24 06:15:55 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:15:55 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:15:55 --> Utf8 Class Initialized
INFO - 2022-06-24 06:15:55 --> URI Class Initialized
INFO - 2022-06-24 06:15:55 --> Router Class Initialized
INFO - 2022-06-24 06:15:55 --> Output Class Initialized
INFO - 2022-06-24 06:15:55 --> Security Class Initialized
DEBUG - 2022-06-24 06:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:15:55 --> Input Class Initialized
INFO - 2022-06-24 06:15:55 --> Language Class Initialized
INFO - 2022-06-24 06:15:55 --> Loader Class Initialized
INFO - 2022-06-24 06:15:55 --> Helper loaded: url_helper
INFO - 2022-06-24 06:15:55 --> Helper loaded: file_helper
INFO - 2022-06-24 06:15:55 --> Database Driver Class Initialized
INFO - 2022-06-24 06:15:55 --> Email Class Initialized
DEBUG - 2022-06-24 06:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:15:55 --> Controller Class Initialized
INFO - 2022-06-24 06:15:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:15:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:15:55 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-24 06:15:55 --> Final output sent to browser
DEBUG - 2022-06-24 06:15:55 --> Total execution time: 0.0359
INFO - 2022-06-24 06:15:55 --> Config Class Initialized
INFO - 2022-06-24 06:15:55 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:15:55 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:15:55 --> Utf8 Class Initialized
INFO - 2022-06-24 06:15:55 --> URI Class Initialized
INFO - 2022-06-24 06:15:55 --> Router Class Initialized
INFO - 2022-06-24 06:15:55 --> Output Class Initialized
INFO - 2022-06-24 06:15:55 --> Security Class Initialized
DEBUG - 2022-06-24 06:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:15:55 --> Input Class Initialized
INFO - 2022-06-24 06:15:55 --> Language Class Initialized
INFO - 2022-06-24 06:15:55 --> Loader Class Initialized
INFO - 2022-06-24 06:15:55 --> Helper loaded: url_helper
INFO - 2022-06-24 06:15:55 --> Helper loaded: file_helper
INFO - 2022-06-24 06:15:55 --> Database Driver Class Initialized
INFO - 2022-06-24 06:15:55 --> Email Class Initialized
DEBUG - 2022-06-24 06:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:15:55 --> Controller Class Initialized
INFO - 2022-06-24 06:15:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:15:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:15:55 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 06:15:55 --> Final output sent to browser
DEBUG - 2022-06-24 06:15:55 --> Total execution time: 0.0285
INFO - 2022-06-24 06:21:03 --> Config Class Initialized
INFO - 2022-06-24 06:21:03 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:21:03 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:21:03 --> Utf8 Class Initialized
INFO - 2022-06-24 06:21:03 --> URI Class Initialized
INFO - 2022-06-24 06:21:03 --> Router Class Initialized
INFO - 2022-06-24 06:21:03 --> Output Class Initialized
INFO - 2022-06-24 06:21:03 --> Security Class Initialized
DEBUG - 2022-06-24 06:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:21:03 --> Input Class Initialized
INFO - 2022-06-24 06:21:03 --> Language Class Initialized
INFO - 2022-06-24 06:21:03 --> Loader Class Initialized
INFO - 2022-06-24 06:21:03 --> Helper loaded: url_helper
INFO - 2022-06-24 06:21:03 --> Helper loaded: file_helper
INFO - 2022-06-24 06:21:03 --> Database Driver Class Initialized
INFO - 2022-06-24 06:21:03 --> Email Class Initialized
DEBUG - 2022-06-24 06:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:21:03 --> Controller Class Initialized
INFO - 2022-06-24 06:21:03 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:21:03 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:21:03 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 06:21:03 --> Final output sent to browser
DEBUG - 2022-06-24 06:21:03 --> Total execution time: 0.0385
INFO - 2022-06-24 06:21:48 --> Config Class Initialized
INFO - 2022-06-24 06:21:48 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:21:48 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:21:48 --> Utf8 Class Initialized
INFO - 2022-06-24 06:21:48 --> URI Class Initialized
INFO - 2022-06-24 06:21:48 --> Config Class Initialized
INFO - 2022-06-24 06:21:48 --> Router Class Initialized
INFO - 2022-06-24 06:21:48 --> Hooks Class Initialized
INFO - 2022-06-24 06:21:48 --> Output Class Initialized
DEBUG - 2022-06-24 06:21:48 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:21:48 --> Utf8 Class Initialized
INFO - 2022-06-24 06:21:48 --> Security Class Initialized
INFO - 2022-06-24 06:21:48 --> URI Class Initialized
DEBUG - 2022-06-24 06:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:21:48 --> Input Class Initialized
INFO - 2022-06-24 06:21:48 --> Router Class Initialized
INFO - 2022-06-24 06:21:48 --> Language Class Initialized
INFO - 2022-06-24 06:21:48 --> Output Class Initialized
INFO - 2022-06-24 06:21:48 --> Security Class Initialized
INFO - 2022-06-24 06:21:48 --> Loader Class Initialized
DEBUG - 2022-06-24 06:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:21:48 --> Helper loaded: url_helper
INFO - 2022-06-24 06:21:48 --> Input Class Initialized
INFO - 2022-06-24 06:21:48 --> Helper loaded: file_helper
INFO - 2022-06-24 06:21:48 --> Language Class Initialized
INFO - 2022-06-24 06:21:48 --> Loader Class Initialized
INFO - 2022-06-24 06:21:48 --> Database Driver Class Initialized
INFO - 2022-06-24 06:21:48 --> Helper loaded: url_helper
INFO - 2022-06-24 06:21:48 --> Helper loaded: file_helper
INFO - 2022-06-24 06:21:48 --> Database Driver Class Initialized
INFO - 2022-06-24 06:21:48 --> Email Class Initialized
DEBUG - 2022-06-24 06:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:21:48 --> Email Class Initialized
INFO - 2022-06-24 06:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:21:48 --> Controller Class Initialized
DEBUG - 2022-06-24 06:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:21:48 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:21:48 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:21:48 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 06:21:48 --> Final output sent to browser
DEBUG - 2022-06-24 06:21:48 --> Total execution time: 0.0657
INFO - 2022-06-24 06:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:21:48 --> Controller Class Initialized
INFO - 2022-06-24 06:21:48 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:21:48 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:21:48 --> Final output sent to browser
DEBUG - 2022-06-24 06:21:48 --> Total execution time: 0.0708
INFO - 2022-06-24 06:23:17 --> Config Class Initialized
INFO - 2022-06-24 06:23:17 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:23:17 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:23:17 --> Utf8 Class Initialized
INFO - 2022-06-24 06:23:17 --> URI Class Initialized
INFO - 2022-06-24 06:23:17 --> Router Class Initialized
INFO - 2022-06-24 06:23:17 --> Output Class Initialized
INFO - 2022-06-24 06:23:17 --> Security Class Initialized
DEBUG - 2022-06-24 06:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:23:17 --> Input Class Initialized
INFO - 2022-06-24 06:23:17 --> Language Class Initialized
INFO - 2022-06-24 06:23:17 --> Loader Class Initialized
INFO - 2022-06-24 06:23:17 --> Config Class Initialized
INFO - 2022-06-24 06:23:17 --> Helper loaded: url_helper
INFO - 2022-06-24 06:23:17 --> Hooks Class Initialized
INFO - 2022-06-24 06:23:17 --> Helper loaded: file_helper
DEBUG - 2022-06-24 06:23:17 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:23:17 --> Utf8 Class Initialized
INFO - 2022-06-24 06:23:17 --> Database Driver Class Initialized
INFO - 2022-06-24 06:23:17 --> URI Class Initialized
INFO - 2022-06-24 06:23:17 --> Router Class Initialized
INFO - 2022-06-24 06:23:17 --> Email Class Initialized
INFO - 2022-06-24 06:23:17 --> Output Class Initialized
INFO - 2022-06-24 06:23:17 --> Security Class Initialized
DEBUG - 2022-06-24 06:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-24 06:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:23:17 --> Input Class Initialized
INFO - 2022-06-24 06:23:17 --> Language Class Initialized
INFO - 2022-06-24 06:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:23:17 --> Controller Class Initialized
INFO - 2022-06-24 06:23:17 --> Loader Class Initialized
INFO - 2022-06-24 06:23:17 --> Model "Tokenmodel" initialized
INFO - 2022-06-24 06:23:17 --> Helper loaded: url_helper
DEBUG - 2022-06-24 06:23:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:23:17 --> Helper loaded: file_helper
INFO - 2022-06-24 06:23:17 --> Database Driver Class Initialized
INFO - 2022-06-24 06:23:17 --> Email Class Initialized
DEBUG - 2022-06-24 06:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-06-24 06:23:17 --> Severity: error --> Exception: Call to undefined function alert() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 35
INFO - 2022-06-24 06:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:23:17 --> Controller Class Initialized
INFO - 2022-06-24 06:23:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:23:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:23:17 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 06:23:17 --> Final output sent to browser
DEBUG - 2022-06-24 06:23:17 --> Total execution time: 0.0492
INFO - 2022-06-24 06:24:22 --> Config Class Initialized
INFO - 2022-06-24 06:24:22 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:24:22 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:24:22 --> Utf8 Class Initialized
INFO - 2022-06-24 06:24:22 --> URI Class Initialized
INFO - 2022-06-24 06:24:22 --> Router Class Initialized
INFO - 2022-06-24 06:24:22 --> Output Class Initialized
INFO - 2022-06-24 06:24:22 --> Security Class Initialized
DEBUG - 2022-06-24 06:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:24:22 --> Input Class Initialized
INFO - 2022-06-24 06:24:22 --> Language Class Initialized
INFO - 2022-06-24 06:24:22 --> Loader Class Initialized
INFO - 2022-06-24 06:24:22 --> Helper loaded: url_helper
INFO - 2022-06-24 06:24:22 --> Helper loaded: file_helper
INFO - 2022-06-24 06:24:22 --> Database Driver Class Initialized
INFO - 2022-06-24 06:24:22 --> Email Class Initialized
DEBUG - 2022-06-24 06:24:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:24:22 --> Controller Class Initialized
INFO - 2022-06-24 06:24:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:24:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:24:22 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 06:24:22 --> Final output sent to browser
DEBUG - 2022-06-24 06:24:22 --> Total execution time: 0.0319
INFO - 2022-06-24 06:24:32 --> Config Class Initialized
INFO - 2022-06-24 06:24:32 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:24:32 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:24:32 --> Utf8 Class Initialized
INFO - 2022-06-24 06:24:32 --> URI Class Initialized
INFO - 2022-06-24 06:24:32 --> Router Class Initialized
INFO - 2022-06-24 06:24:32 --> Output Class Initialized
INFO - 2022-06-24 06:24:32 --> Security Class Initialized
DEBUG - 2022-06-24 06:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:24:32 --> Input Class Initialized
INFO - 2022-06-24 06:24:32 --> Language Class Initialized
INFO - 2022-06-24 06:24:32 --> Loader Class Initialized
INFO - 2022-06-24 06:24:32 --> Helper loaded: url_helper
INFO - 2022-06-24 06:24:32 --> Helper loaded: file_helper
INFO - 2022-06-24 06:24:32 --> Config Class Initialized
INFO - 2022-06-24 06:24:32 --> Hooks Class Initialized
INFO - 2022-06-24 06:24:32 --> Database Driver Class Initialized
DEBUG - 2022-06-24 06:24:32 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:24:32 --> Utf8 Class Initialized
INFO - 2022-06-24 06:24:32 --> Email Class Initialized
INFO - 2022-06-24 06:24:32 --> URI Class Initialized
DEBUG - 2022-06-24 06:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:24:32 --> Router Class Initialized
INFO - 2022-06-24 06:24:32 --> Output Class Initialized
INFO - 2022-06-24 06:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:24:32 --> Controller Class Initialized
INFO - 2022-06-24 06:24:32 --> Security Class Initialized
DEBUG - 2022-06-24 06:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:24:32 --> Model "Tokenmodel" initialized
INFO - 2022-06-24 06:24:32 --> Input Class Initialized
DEBUG - 2022-06-24 06:24:32 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:24:32 --> Language Class Initialized
ERROR - 2022-06-24 06:24:32 --> Severity: error --> Exception: Call to undefined function alert() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 39
INFO - 2022-06-24 06:24:32 --> Loader Class Initialized
INFO - 2022-06-24 06:24:32 --> Helper loaded: url_helper
INFO - 2022-06-24 06:24:32 --> Helper loaded: file_helper
INFO - 2022-06-24 06:24:32 --> Database Driver Class Initialized
INFO - 2022-06-24 06:24:32 --> Email Class Initialized
DEBUG - 2022-06-24 06:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:24:32 --> Controller Class Initialized
INFO - 2022-06-24 06:24:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:24:32 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:24:32 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 06:24:32 --> Final output sent to browser
DEBUG - 2022-06-24 06:24:32 --> Total execution time: 0.0383
INFO - 2022-06-24 06:25:20 --> Config Class Initialized
INFO - 2022-06-24 06:25:20 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:25:20 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:25:20 --> Utf8 Class Initialized
INFO - 2022-06-24 06:25:20 --> URI Class Initialized
INFO - 2022-06-24 06:25:20 --> Router Class Initialized
INFO - 2022-06-24 06:25:20 --> Output Class Initialized
INFO - 2022-06-24 06:25:20 --> Security Class Initialized
DEBUG - 2022-06-24 06:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:25:20 --> Input Class Initialized
INFO - 2022-06-24 06:25:20 --> Language Class Initialized
INFO - 2022-06-24 06:25:20 --> Loader Class Initialized
INFO - 2022-06-24 06:25:20 --> Helper loaded: url_helper
INFO - 2022-06-24 06:25:20 --> Helper loaded: file_helper
INFO - 2022-06-24 06:25:20 --> Database Driver Class Initialized
INFO - 2022-06-24 06:25:20 --> Email Class Initialized
DEBUG - 2022-06-24 06:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:25:20 --> Controller Class Initialized
INFO - 2022-06-24 06:25:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:25:20 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:25:20 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 06:25:20 --> Final output sent to browser
DEBUG - 2022-06-24 06:25:20 --> Total execution time: 0.0885
INFO - 2022-06-24 06:25:32 --> Config Class Initialized
INFO - 2022-06-24 06:25:32 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:25:32 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:25:32 --> Config Class Initialized
INFO - 2022-06-24 06:25:32 --> Utf8 Class Initialized
INFO - 2022-06-24 06:25:32 --> Hooks Class Initialized
INFO - 2022-06-24 06:25:32 --> URI Class Initialized
DEBUG - 2022-06-24 06:25:32 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:25:32 --> Utf8 Class Initialized
INFO - 2022-06-24 06:25:32 --> Router Class Initialized
INFO - 2022-06-24 06:25:32 --> URI Class Initialized
INFO - 2022-06-24 06:25:32 --> Router Class Initialized
INFO - 2022-06-24 06:25:32 --> Output Class Initialized
INFO - 2022-06-24 06:25:32 --> Output Class Initialized
INFO - 2022-06-24 06:25:32 --> Security Class Initialized
INFO - 2022-06-24 06:25:32 --> Security Class Initialized
DEBUG - 2022-06-24 06:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:25:32 --> Input Class Initialized
INFO - 2022-06-24 06:25:32 --> Input Class Initialized
INFO - 2022-06-24 06:25:32 --> Language Class Initialized
INFO - 2022-06-24 06:25:32 --> Language Class Initialized
INFO - 2022-06-24 06:25:32 --> Loader Class Initialized
INFO - 2022-06-24 06:25:32 --> Loader Class Initialized
INFO - 2022-06-24 06:25:32 --> Helper loaded: url_helper
INFO - 2022-06-24 06:25:32 --> Helper loaded: url_helper
INFO - 2022-06-24 06:25:32 --> Helper loaded: file_helper
INFO - 2022-06-24 06:25:32 --> Helper loaded: file_helper
INFO - 2022-06-24 06:25:32 --> Database Driver Class Initialized
INFO - 2022-06-24 06:25:32 --> Database Driver Class Initialized
INFO - 2022-06-24 06:25:32 --> Email Class Initialized
INFO - 2022-06-24 06:25:32 --> Email Class Initialized
DEBUG - 2022-06-24 06:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-24 06:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:25:32 --> Controller Class Initialized
INFO - 2022-06-24 06:25:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:25:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-24 06:25:32 --> Severity: error --> Exception: Call to undefined function alert() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 39
INFO - 2022-06-24 06:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:25:32 --> Controller Class Initialized
INFO - 2022-06-24 06:25:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:25:32 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:25:32 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 06:25:32 --> Final output sent to browser
DEBUG - 2022-06-24 06:25:32 --> Total execution time: 0.0412
INFO - 2022-06-24 06:25:43 --> Config Class Initialized
INFO - 2022-06-24 06:25:43 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:25:43 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:25:43 --> Utf8 Class Initialized
INFO - 2022-06-24 06:25:43 --> URI Class Initialized
INFO - 2022-06-24 06:25:43 --> Router Class Initialized
INFO - 2022-06-24 06:25:43 --> Output Class Initialized
INFO - 2022-06-24 06:25:43 --> Security Class Initialized
DEBUG - 2022-06-24 06:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:25:43 --> Input Class Initialized
INFO - 2022-06-24 06:25:43 --> Language Class Initialized
INFO - 2022-06-24 06:25:43 --> Loader Class Initialized
INFO - 2022-06-24 06:25:43 --> Helper loaded: url_helper
INFO - 2022-06-24 06:25:43 --> Helper loaded: file_helper
INFO - 2022-06-24 06:25:43 --> Database Driver Class Initialized
INFO - 2022-06-24 06:25:43 --> Email Class Initialized
DEBUG - 2022-06-24 06:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:25:43 --> Controller Class Initialized
INFO - 2022-06-24 06:25:43 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:25:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-24 06:25:43 --> Severity: error --> Exception: Call to undefined function alert() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 39
INFO - 2022-06-24 06:26:22 --> Config Class Initialized
INFO - 2022-06-24 06:26:22 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:26:22 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:26:22 --> Utf8 Class Initialized
INFO - 2022-06-24 06:26:22 --> URI Class Initialized
INFO - 2022-06-24 06:26:22 --> Router Class Initialized
INFO - 2022-06-24 06:26:22 --> Output Class Initialized
INFO - 2022-06-24 06:26:22 --> Security Class Initialized
DEBUG - 2022-06-24 06:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:26:22 --> Input Class Initialized
INFO - 2022-06-24 06:26:22 --> Language Class Initialized
INFO - 2022-06-24 06:26:22 --> Loader Class Initialized
INFO - 2022-06-24 06:26:22 --> Helper loaded: url_helper
INFO - 2022-06-24 06:26:22 --> Helper loaded: file_helper
INFO - 2022-06-24 06:26:22 --> Database Driver Class Initialized
INFO - 2022-06-24 06:26:22 --> Email Class Initialized
DEBUG - 2022-06-24 06:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:26:22 --> Controller Class Initialized
INFO - 2022-06-24 06:26:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:26:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:26:22 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 06:26:22 --> Final output sent to browser
DEBUG - 2022-06-24 06:26:22 --> Total execution time: 0.0334
INFO - 2022-06-24 06:26:38 --> Config Class Initialized
INFO - 2022-06-24 06:26:38 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:26:38 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:26:38 --> Utf8 Class Initialized
INFO - 2022-06-24 06:26:38 --> URI Class Initialized
INFO - 2022-06-24 06:26:38 --> Router Class Initialized
INFO - 2022-06-24 06:26:38 --> Output Class Initialized
INFO - 2022-06-24 06:26:38 --> Security Class Initialized
DEBUG - 2022-06-24 06:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:26:38 --> Input Class Initialized
INFO - 2022-06-24 06:26:38 --> Language Class Initialized
INFO - 2022-06-24 06:26:38 --> Loader Class Initialized
INFO - 2022-06-24 06:26:38 --> Config Class Initialized
INFO - 2022-06-24 06:26:38 --> Helper loaded: url_helper
INFO - 2022-06-24 06:26:38 --> Hooks Class Initialized
INFO - 2022-06-24 06:26:38 --> Helper loaded: file_helper
DEBUG - 2022-06-24 06:26:38 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:26:38 --> Utf8 Class Initialized
INFO - 2022-06-24 06:26:38 --> Database Driver Class Initialized
INFO - 2022-06-24 06:26:38 --> URI Class Initialized
INFO - 2022-06-24 06:26:38 --> Router Class Initialized
INFO - 2022-06-24 06:26:38 --> Email Class Initialized
INFO - 2022-06-24 06:26:38 --> Output Class Initialized
INFO - 2022-06-24 06:26:38 --> Security Class Initialized
DEBUG - 2022-06-24 06:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:26:38 --> Input Class Initialized
DEBUG - 2022-06-24 06:26:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:26:38 --> Language Class Initialized
INFO - 2022-06-24 06:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:26:38 --> Loader Class Initialized
INFO - 2022-06-24 06:26:38 --> Controller Class Initialized
INFO - 2022-06-24 06:26:38 --> Model "Tokenmodel" initialized
INFO - 2022-06-24 06:26:38 --> Helper loaded: url_helper
DEBUG - 2022-06-24 06:26:38 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:26:38 --> Helper loaded: file_helper
INFO - 2022-06-24 06:26:38 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 06:26:38 --> Final output sent to browser
INFO - 2022-06-24 06:26:38 --> Database Driver Class Initialized
DEBUG - 2022-06-24 06:26:38 --> Total execution time: 0.0363
INFO - 2022-06-24 06:26:38 --> Email Class Initialized
DEBUG - 2022-06-24 06:26:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:26:38 --> Controller Class Initialized
INFO - 2022-06-24 06:26:38 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:26:38 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:26:38 --> Final output sent to browser
DEBUG - 2022-06-24 06:26:38 --> Total execution time: 0.0473
INFO - 2022-06-24 06:26:44 --> Config Class Initialized
INFO - 2022-06-24 06:26:44 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:26:44 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:26:44 --> Utf8 Class Initialized
INFO - 2022-06-24 06:26:44 --> URI Class Initialized
INFO - 2022-06-24 06:26:44 --> Router Class Initialized
INFO - 2022-06-24 06:26:44 --> Output Class Initialized
INFO - 2022-06-24 06:26:44 --> Security Class Initialized
DEBUG - 2022-06-24 06:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:26:44 --> Input Class Initialized
INFO - 2022-06-24 06:26:44 --> Language Class Initialized
INFO - 2022-06-24 06:26:44 --> Loader Class Initialized
INFO - 2022-06-24 06:26:44 --> Helper loaded: url_helper
INFO - 2022-06-24 06:26:44 --> Helper loaded: file_helper
INFO - 2022-06-24 06:26:44 --> Database Driver Class Initialized
INFO - 2022-06-24 06:26:44 --> Email Class Initialized
DEBUG - 2022-06-24 06:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:26:44 --> Controller Class Initialized
INFO - 2022-06-24 06:26:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:26:44 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:26:44 --> Final output sent to browser
DEBUG - 2022-06-24 06:26:44 --> Total execution time: 0.0315
INFO - 2022-06-24 06:29:44 --> Config Class Initialized
INFO - 2022-06-24 06:29:44 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:29:44 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:29:44 --> Utf8 Class Initialized
INFO - 2022-06-24 06:29:44 --> URI Class Initialized
INFO - 2022-06-24 06:29:44 --> Router Class Initialized
INFO - 2022-06-24 06:29:44 --> Output Class Initialized
INFO - 2022-06-24 06:29:44 --> Security Class Initialized
DEBUG - 2022-06-24 06:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:29:44 --> Input Class Initialized
INFO - 2022-06-24 06:29:44 --> Language Class Initialized
INFO - 2022-06-24 06:29:44 --> Loader Class Initialized
INFO - 2022-06-24 06:29:44 --> Helper loaded: url_helper
INFO - 2022-06-24 06:29:44 --> Helper loaded: file_helper
INFO - 2022-06-24 06:29:44 --> Database Driver Class Initialized
INFO - 2022-06-24 06:29:44 --> Email Class Initialized
DEBUG - 2022-06-24 06:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:29:44 --> Controller Class Initialized
INFO - 2022-06-24 06:29:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:29:44 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:29:45 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 06:29:45 --> Final output sent to browser
DEBUG - 2022-06-24 06:29:45 --> Total execution time: 0.0649
INFO - 2022-06-24 06:29:57 --> Config Class Initialized
INFO - 2022-06-24 06:29:57 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:29:57 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:29:57 --> Utf8 Class Initialized
INFO - 2022-06-24 06:29:57 --> Config Class Initialized
INFO - 2022-06-24 06:29:57 --> URI Class Initialized
INFO - 2022-06-24 06:29:57 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:29:57 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:29:57 --> Router Class Initialized
INFO - 2022-06-24 06:29:57 --> Utf8 Class Initialized
INFO - 2022-06-24 06:29:57 --> Output Class Initialized
INFO - 2022-06-24 06:29:57 --> URI Class Initialized
INFO - 2022-06-24 06:29:57 --> Security Class Initialized
INFO - 2022-06-24 06:29:57 --> Router Class Initialized
DEBUG - 2022-06-24 06:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:29:57 --> Input Class Initialized
INFO - 2022-06-24 06:29:57 --> Output Class Initialized
INFO - 2022-06-24 06:29:57 --> Language Class Initialized
INFO - 2022-06-24 06:29:57 --> Security Class Initialized
DEBUG - 2022-06-24 06:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:29:57 --> Loader Class Initialized
INFO - 2022-06-24 06:29:57 --> Input Class Initialized
INFO - 2022-06-24 06:29:57 --> Language Class Initialized
INFO - 2022-06-24 06:29:57 --> Helper loaded: url_helper
INFO - 2022-06-24 06:29:57 --> Helper loaded: file_helper
INFO - 2022-06-24 06:29:57 --> Loader Class Initialized
INFO - 2022-06-24 06:29:57 --> Helper loaded: url_helper
INFO - 2022-06-24 06:29:57 --> Database Driver Class Initialized
INFO - 2022-06-24 06:29:57 --> Helper loaded: file_helper
INFO - 2022-06-24 06:29:57 --> Database Driver Class Initialized
INFO - 2022-06-24 06:29:57 --> Email Class Initialized
INFO - 2022-06-24 06:29:57 --> Email Class Initialized
DEBUG - 2022-06-24 06:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:29:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2022-06-24 06:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:29:57 --> Controller Class Initialized
INFO - 2022-06-24 06:29:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:29:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:29:57 --> Final output sent to browser
DEBUG - 2022-06-24 06:29:57 --> Total execution time: 0.0332
INFO - 2022-06-24 06:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:29:57 --> Controller Class Initialized
INFO - 2022-06-24 06:29:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:29:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:29:57 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 06:29:57 --> Final output sent to browser
DEBUG - 2022-06-24 06:29:57 --> Total execution time: 0.0371
INFO - 2022-06-24 06:44:01 --> Config Class Initialized
INFO - 2022-06-24 06:44:01 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:44:01 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:44:01 --> Utf8 Class Initialized
INFO - 2022-06-24 06:44:01 --> URI Class Initialized
INFO - 2022-06-24 06:44:01 --> Router Class Initialized
INFO - 2022-06-24 06:44:01 --> Output Class Initialized
INFO - 2022-06-24 06:44:01 --> Security Class Initialized
DEBUG - 2022-06-24 06:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:44:01 --> Input Class Initialized
INFO - 2022-06-24 06:44:01 --> Language Class Initialized
INFO - 2022-06-24 06:44:01 --> Loader Class Initialized
INFO - 2022-06-24 06:44:01 --> Helper loaded: url_helper
INFO - 2022-06-24 06:44:01 --> Helper loaded: file_helper
INFO - 2022-06-24 06:44:01 --> Database Driver Class Initialized
INFO - 2022-06-24 06:44:01 --> Email Class Initialized
DEBUG - 2022-06-24 06:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:44:01 --> Controller Class Initialized
INFO - 2022-06-24 06:44:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:44:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:44:01 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 06:44:01 --> Final output sent to browser
DEBUG - 2022-06-24 06:44:01 --> Total execution time: 0.0358
INFO - 2022-06-24 06:44:04 --> Config Class Initialized
INFO - 2022-06-24 06:44:04 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:44:04 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:44:04 --> Utf8 Class Initialized
INFO - 2022-06-24 06:44:04 --> URI Class Initialized
INFO - 2022-06-24 06:44:04 --> Router Class Initialized
INFO - 2022-06-24 06:44:04 --> Output Class Initialized
INFO - 2022-06-24 06:44:04 --> Security Class Initialized
DEBUG - 2022-06-24 06:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:44:04 --> Input Class Initialized
INFO - 2022-06-24 06:44:04 --> Language Class Initialized
INFO - 2022-06-24 06:44:04 --> Loader Class Initialized
INFO - 2022-06-24 06:44:04 --> Helper loaded: url_helper
INFO - 2022-06-24 06:44:04 --> Helper loaded: file_helper
INFO - 2022-06-24 06:44:04 --> Database Driver Class Initialized
INFO - 2022-06-24 06:44:04 --> Email Class Initialized
DEBUG - 2022-06-24 06:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:44:04 --> Controller Class Initialized
INFO - 2022-06-24 06:44:04 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:44:04 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:44:04 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 06:44:04 --> Final output sent to browser
DEBUG - 2022-06-24 06:44:04 --> Total execution time: 0.0301
INFO - 2022-06-24 06:45:49 --> Config Class Initialized
INFO - 2022-06-24 06:45:49 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:45:49 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:45:49 --> Utf8 Class Initialized
INFO - 2022-06-24 06:45:49 --> URI Class Initialized
INFO - 2022-06-24 06:45:49 --> Router Class Initialized
INFO - 2022-06-24 06:45:49 --> Output Class Initialized
INFO - 2022-06-24 06:45:49 --> Config Class Initialized
INFO - 2022-06-24 06:45:49 --> Security Class Initialized
INFO - 2022-06-24 06:45:49 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:45:49 --> Input Class Initialized
DEBUG - 2022-06-24 06:45:49 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:45:49 --> Utf8 Class Initialized
INFO - 2022-06-24 06:45:49 --> Language Class Initialized
INFO - 2022-06-24 06:45:49 --> URI Class Initialized
INFO - 2022-06-24 06:45:49 --> Loader Class Initialized
INFO - 2022-06-24 06:45:49 --> Router Class Initialized
INFO - 2022-06-24 06:45:49 --> Helper loaded: url_helper
INFO - 2022-06-24 06:45:49 --> Output Class Initialized
INFO - 2022-06-24 06:45:49 --> Helper loaded: file_helper
INFO - 2022-06-24 06:45:49 --> Security Class Initialized
INFO - 2022-06-24 06:45:49 --> Database Driver Class Initialized
DEBUG - 2022-06-24 06:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:45:49 --> Input Class Initialized
INFO - 2022-06-24 06:45:49 --> Language Class Initialized
INFO - 2022-06-24 06:45:49 --> Loader Class Initialized
INFO - 2022-06-24 06:45:49 --> Email Class Initialized
INFO - 2022-06-24 06:45:49 --> Helper loaded: url_helper
INFO - 2022-06-24 06:45:49 --> Helper loaded: file_helper
DEBUG - 2022-06-24 06:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:45:49 --> Database Driver Class Initialized
INFO - 2022-06-24 06:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:45:49 --> Controller Class Initialized
INFO - 2022-06-24 06:45:49 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:45:49 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:45:49 --> Email Class Initialized
INFO - 2022-06-24 06:45:49 --> Final output sent to browser
DEBUG - 2022-06-24 06:45:49 --> Total execution time: 0.0339
DEBUG - 2022-06-24 06:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:45:49 --> Controller Class Initialized
INFO - 2022-06-24 06:45:49 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:45:49 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:45:49 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 06:45:49 --> Final output sent to browser
DEBUG - 2022-06-24 06:45:49 --> Total execution time: 0.0320
INFO - 2022-06-24 06:46:29 --> Config Class Initialized
INFO - 2022-06-24 06:46:29 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:46:29 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:46:29 --> Utf8 Class Initialized
INFO - 2022-06-24 06:46:29 --> URI Class Initialized
INFO - 2022-06-24 06:46:29 --> Router Class Initialized
INFO - 2022-06-24 06:46:29 --> Output Class Initialized
INFO - 2022-06-24 06:46:29 --> Security Class Initialized
DEBUG - 2022-06-24 06:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:46:29 --> Input Class Initialized
INFO - 2022-06-24 06:46:29 --> Language Class Initialized
INFO - 2022-06-24 06:46:29 --> Loader Class Initialized
INFO - 2022-06-24 06:46:29 --> Helper loaded: url_helper
INFO - 2022-06-24 06:46:29 --> Helper loaded: file_helper
INFO - 2022-06-24 06:46:29 --> Database Driver Class Initialized
INFO - 2022-06-24 06:46:29 --> Email Class Initialized
DEBUG - 2022-06-24 06:46:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:46:29 --> Controller Class Initialized
INFO - 2022-06-24 06:46:29 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:46:29 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:46:29 --> Final output sent to browser
DEBUG - 2022-06-24 06:46:29 --> Total execution time: 0.0247
INFO - 2022-06-24 06:48:30 --> Config Class Initialized
INFO - 2022-06-24 06:48:30 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:48:30 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:48:30 --> Utf8 Class Initialized
INFO - 2022-06-24 06:48:30 --> URI Class Initialized
INFO - 2022-06-24 06:48:30 --> Router Class Initialized
INFO - 2022-06-24 06:48:30 --> Output Class Initialized
INFO - 2022-06-24 06:48:30 --> Security Class Initialized
DEBUG - 2022-06-24 06:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:48:30 --> Input Class Initialized
INFO - 2022-06-24 06:48:30 --> Language Class Initialized
INFO - 2022-06-24 06:48:30 --> Loader Class Initialized
INFO - 2022-06-24 06:48:30 --> Helper loaded: url_helper
INFO - 2022-06-24 06:48:30 --> Helper loaded: file_helper
INFO - 2022-06-24 06:48:30 --> Database Driver Class Initialized
INFO - 2022-06-24 06:48:30 --> Email Class Initialized
DEBUG - 2022-06-24 06:48:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:48:30 --> Controller Class Initialized
INFO - 2022-06-24 06:48:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:48:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:48:30 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 06:48:30 --> Final output sent to browser
DEBUG - 2022-06-24 06:48:30 --> Total execution time: 0.0301
INFO - 2022-06-24 06:48:39 --> Config Class Initialized
INFO - 2022-06-24 06:48:39 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:48:39 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:48:39 --> Utf8 Class Initialized
INFO - 2022-06-24 06:48:39 --> URI Class Initialized
INFO - 2022-06-24 06:48:39 --> Router Class Initialized
INFO - 2022-06-24 06:48:39 --> Output Class Initialized
INFO - 2022-06-24 06:48:39 --> Security Class Initialized
DEBUG - 2022-06-24 06:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:48:39 --> Input Class Initialized
INFO - 2022-06-24 06:48:39 --> Language Class Initialized
INFO - 2022-06-24 06:48:39 --> Loader Class Initialized
INFO - 2022-06-24 06:48:39 --> Config Class Initialized
INFO - 2022-06-24 06:48:39 --> Hooks Class Initialized
INFO - 2022-06-24 06:48:39 --> Helper loaded: url_helper
DEBUG - 2022-06-24 06:48:39 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:48:39 --> Helper loaded: file_helper
INFO - 2022-06-24 06:48:39 --> Utf8 Class Initialized
INFO - 2022-06-24 06:48:39 --> URI Class Initialized
INFO - 2022-06-24 06:48:39 --> Database Driver Class Initialized
INFO - 2022-06-24 06:48:39 --> Router Class Initialized
INFO - 2022-06-24 06:48:39 --> Output Class Initialized
INFO - 2022-06-24 06:48:39 --> Email Class Initialized
INFO - 2022-06-24 06:48:39 --> Security Class Initialized
DEBUG - 2022-06-24 06:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:48:39 --> Input Class Initialized
INFO - 2022-06-24 06:48:39 --> Language Class Initialized
DEBUG - 2022-06-24 06:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:48:39 --> Loader Class Initialized
INFO - 2022-06-24 06:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:48:39 --> Controller Class Initialized
INFO - 2022-06-24 06:48:39 --> Helper loaded: url_helper
INFO - 2022-06-24 06:48:39 --> Model "Tokenmodel" initialized
INFO - 2022-06-24 06:48:39 --> Helper loaded: file_helper
DEBUG - 2022-06-24 06:48:39 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:48:39 --> Database Driver Class Initialized
INFO - 2022-06-24 06:48:39 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 06:48:39 --> Final output sent to browser
DEBUG - 2022-06-24 06:48:39 --> Total execution time: 0.0345
INFO - 2022-06-24 06:48:39 --> Email Class Initialized
DEBUG - 2022-06-24 06:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:48:39 --> Controller Class Initialized
INFO - 2022-06-24 06:48:39 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:48:39 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:48:39 --> Final output sent to browser
DEBUG - 2022-06-24 06:48:39 --> Total execution time: 0.0389
INFO - 2022-06-24 06:48:51 --> Config Class Initialized
INFO - 2022-06-24 06:48:51 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:48:51 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:48:51 --> Utf8 Class Initialized
INFO - 2022-06-24 06:48:51 --> URI Class Initialized
INFO - 2022-06-24 06:48:51 --> Router Class Initialized
INFO - 2022-06-24 06:48:52 --> Output Class Initialized
INFO - 2022-06-24 06:48:52 --> Security Class Initialized
DEBUG - 2022-06-24 06:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:48:52 --> Input Class Initialized
INFO - 2022-06-24 06:48:52 --> Language Class Initialized
INFO - 2022-06-24 06:48:52 --> Loader Class Initialized
INFO - 2022-06-24 06:48:52 --> Helper loaded: url_helper
INFO - 2022-06-24 06:48:52 --> Helper loaded: file_helper
INFO - 2022-06-24 06:48:52 --> Database Driver Class Initialized
INFO - 2022-06-24 06:48:52 --> Email Class Initialized
DEBUG - 2022-06-24 06:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:48:52 --> Controller Class Initialized
INFO - 2022-06-24 06:48:52 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:48:52 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:48:52 --> Final output sent to browser
DEBUG - 2022-06-24 06:48:52 --> Total execution time: 0.0232
INFO - 2022-06-24 06:49:22 --> Config Class Initialized
INFO - 2022-06-24 06:49:22 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:49:22 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:49:22 --> Utf8 Class Initialized
INFO - 2022-06-24 06:49:22 --> URI Class Initialized
INFO - 2022-06-24 06:49:22 --> Router Class Initialized
INFO - 2022-06-24 06:49:22 --> Output Class Initialized
INFO - 2022-06-24 06:49:22 --> Security Class Initialized
DEBUG - 2022-06-24 06:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:49:22 --> Input Class Initialized
INFO - 2022-06-24 06:49:22 --> Language Class Initialized
INFO - 2022-06-24 06:49:22 --> Loader Class Initialized
INFO - 2022-06-24 06:49:22 --> Helper loaded: url_helper
INFO - 2022-06-24 06:49:22 --> Helper loaded: file_helper
INFO - 2022-06-24 06:49:22 --> Database Driver Class Initialized
INFO - 2022-06-24 06:49:22 --> Email Class Initialized
DEBUG - 2022-06-24 06:49:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:49:22 --> Controller Class Initialized
INFO - 2022-06-24 06:49:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:49:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:49:22 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 06:49:22 --> Final output sent to browser
DEBUG - 2022-06-24 06:49:22 --> Total execution time: 0.0537
INFO - 2022-06-24 06:49:31 --> Config Class Initialized
INFO - 2022-06-24 06:49:31 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:49:31 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:49:31 --> Utf8 Class Initialized
INFO - 2022-06-24 06:49:31 --> URI Class Initialized
INFO - 2022-06-24 06:49:31 --> Config Class Initialized
INFO - 2022-06-24 06:49:31 --> Router Class Initialized
INFO - 2022-06-24 06:49:31 --> Hooks Class Initialized
INFO - 2022-06-24 06:49:31 --> Output Class Initialized
DEBUG - 2022-06-24 06:49:31 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:49:31 --> Utf8 Class Initialized
INFO - 2022-06-24 06:49:31 --> Security Class Initialized
DEBUG - 2022-06-24 06:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:49:31 --> URI Class Initialized
INFO - 2022-06-24 06:49:31 --> Input Class Initialized
INFO - 2022-06-24 06:49:31 --> Language Class Initialized
INFO - 2022-06-24 06:49:31 --> Router Class Initialized
INFO - 2022-06-24 06:49:31 --> Loader Class Initialized
INFO - 2022-06-24 06:49:31 --> Output Class Initialized
INFO - 2022-06-24 06:49:31 --> Security Class Initialized
INFO - 2022-06-24 06:49:31 --> Helper loaded: url_helper
DEBUG - 2022-06-24 06:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:49:31 --> Helper loaded: file_helper
INFO - 2022-06-24 06:49:31 --> Input Class Initialized
INFO - 2022-06-24 06:49:31 --> Language Class Initialized
INFO - 2022-06-24 06:49:31 --> Database Driver Class Initialized
INFO - 2022-06-24 06:49:31 --> Loader Class Initialized
INFO - 2022-06-24 06:49:31 --> Helper loaded: url_helper
INFO - 2022-06-24 06:49:31 --> Email Class Initialized
INFO - 2022-06-24 06:49:31 --> Helper loaded: file_helper
INFO - 2022-06-24 06:49:31 --> Database Driver Class Initialized
DEBUG - 2022-06-24 06:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:49:31 --> Controller Class Initialized
INFO - 2022-06-24 06:49:31 --> Email Class Initialized
INFO - 2022-06-24 06:49:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:49:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-24 06:49:31 --> Query error: Column 'ud_mob' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_mob`, `ud_otp`) VALUES (NULL, NULL)
DEBUG - 2022-06-24 06:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:49:31 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-24 06:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:49:31 --> Controller Class Initialized
INFO - 2022-06-24 06:49:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:49:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:49:31 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 06:49:31 --> Final output sent to browser
DEBUG - 2022-06-24 06:49:31 --> Total execution time: 0.0343
INFO - 2022-06-24 06:49:46 --> Config Class Initialized
INFO - 2022-06-24 06:49:46 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:49:46 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:49:46 --> Utf8 Class Initialized
INFO - 2022-06-24 06:49:46 --> URI Class Initialized
INFO - 2022-06-24 06:49:46 --> Router Class Initialized
INFO - 2022-06-24 06:49:46 --> Output Class Initialized
INFO - 2022-06-24 06:49:46 --> Security Class Initialized
DEBUG - 2022-06-24 06:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:49:46 --> Input Class Initialized
INFO - 2022-06-24 06:49:46 --> Language Class Initialized
INFO - 2022-06-24 06:49:46 --> Loader Class Initialized
INFO - 2022-06-24 06:49:46 --> Helper loaded: url_helper
INFO - 2022-06-24 06:49:46 --> Helper loaded: file_helper
INFO - 2022-06-24 06:49:46 --> Database Driver Class Initialized
INFO - 2022-06-24 06:49:46 --> Email Class Initialized
DEBUG - 2022-06-24 06:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:49:46 --> Controller Class Initialized
INFO - 2022-06-24 06:49:46 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:49:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-24 06:49:46 --> Query error: Column 'ud_mob' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_mob`, `ud_otp`) VALUES (NULL, NULL)
INFO - 2022-06-24 06:49:46 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-24 06:50:32 --> Config Class Initialized
INFO - 2022-06-24 06:50:32 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:50:32 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:50:32 --> Utf8 Class Initialized
INFO - 2022-06-24 06:50:32 --> URI Class Initialized
INFO - 2022-06-24 06:50:32 --> Router Class Initialized
INFO - 2022-06-24 06:50:32 --> Output Class Initialized
INFO - 2022-06-24 06:50:32 --> Security Class Initialized
DEBUG - 2022-06-24 06:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:50:32 --> Input Class Initialized
INFO - 2022-06-24 06:50:32 --> Language Class Initialized
INFO - 2022-06-24 06:50:32 --> Loader Class Initialized
INFO - 2022-06-24 06:50:32 --> Helper loaded: url_helper
INFO - 2022-06-24 06:50:32 --> Helper loaded: file_helper
INFO - 2022-06-24 06:50:32 --> Database Driver Class Initialized
INFO - 2022-06-24 06:50:32 --> Email Class Initialized
DEBUG - 2022-06-24 06:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:50:32 --> Controller Class Initialized
INFO - 2022-06-24 06:50:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:50:32 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:50:32 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 06:50:32 --> Final output sent to browser
DEBUG - 2022-06-24 06:50:32 --> Total execution time: 0.0302
INFO - 2022-06-24 06:50:44 --> Config Class Initialized
INFO - 2022-06-24 06:50:44 --> Hooks Class Initialized
INFO - 2022-06-24 06:50:44 --> Config Class Initialized
INFO - 2022-06-24 06:50:44 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 06:50:44 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:50:44 --> Utf8 Class Initialized
INFO - 2022-06-24 06:50:44 --> Utf8 Class Initialized
INFO - 2022-06-24 06:50:44 --> URI Class Initialized
INFO - 2022-06-24 06:50:44 --> URI Class Initialized
INFO - 2022-06-24 06:50:44 --> Router Class Initialized
INFO - 2022-06-24 06:50:44 --> Router Class Initialized
INFO - 2022-06-24 06:50:44 --> Output Class Initialized
INFO - 2022-06-24 06:50:44 --> Output Class Initialized
INFO - 2022-06-24 06:50:44 --> Security Class Initialized
INFO - 2022-06-24 06:50:44 --> Security Class Initialized
DEBUG - 2022-06-24 06:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:50:44 --> Input Class Initialized
INFO - 2022-06-24 06:50:44 --> Input Class Initialized
INFO - 2022-06-24 06:50:44 --> Language Class Initialized
INFO - 2022-06-24 06:50:44 --> Language Class Initialized
INFO - 2022-06-24 06:50:44 --> Loader Class Initialized
INFO - 2022-06-24 06:50:44 --> Loader Class Initialized
INFO - 2022-06-24 06:50:44 --> Helper loaded: url_helper
INFO - 2022-06-24 06:50:44 --> Helper loaded: file_helper
INFO - 2022-06-24 06:50:44 --> Helper loaded: url_helper
INFO - 2022-06-24 06:50:44 --> Helper loaded: file_helper
INFO - 2022-06-24 06:50:44 --> Database Driver Class Initialized
INFO - 2022-06-24 06:50:44 --> Database Driver Class Initialized
INFO - 2022-06-24 06:50:44 --> Email Class Initialized
INFO - 2022-06-24 06:50:44 --> Email Class Initialized
DEBUG - 2022-06-24 06:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-24 06:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:50:44 --> Controller Class Initialized
INFO - 2022-06-24 06:50:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:50:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-24 06:50:44 --> Query error: Column 'ud_otp' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_mob`, `ud_otp`) VALUES (NULL, NULL)
INFO - 2022-06-24 06:50:44 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-24 06:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:50:44 --> Controller Class Initialized
INFO - 2022-06-24 06:50:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:50:44 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:50:44 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 06:50:44 --> Final output sent to browser
DEBUG - 2022-06-24 06:50:44 --> Total execution time: 0.0444
INFO - 2022-06-24 06:50:49 --> Config Class Initialized
INFO - 2022-06-24 06:50:49 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:50:49 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:50:49 --> Utf8 Class Initialized
INFO - 2022-06-24 06:50:49 --> URI Class Initialized
INFO - 2022-06-24 06:50:49 --> Router Class Initialized
INFO - 2022-06-24 06:50:49 --> Output Class Initialized
INFO - 2022-06-24 06:50:49 --> Security Class Initialized
DEBUG - 2022-06-24 06:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:50:49 --> Input Class Initialized
INFO - 2022-06-24 06:50:49 --> Language Class Initialized
INFO - 2022-06-24 06:50:49 --> Loader Class Initialized
INFO - 2022-06-24 06:50:49 --> Helper loaded: url_helper
INFO - 2022-06-24 06:50:49 --> Helper loaded: file_helper
INFO - 2022-06-24 06:50:49 --> Database Driver Class Initialized
INFO - 2022-06-24 06:50:49 --> Email Class Initialized
DEBUG - 2022-06-24 06:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:50:49 --> Controller Class Initialized
INFO - 2022-06-24 06:50:49 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:50:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-24 06:50:49 --> Query error: Column 'ud_otp' cannot be null - Invalid query: INSERT INTO `userdetails` (`ud_mob`, `ud_otp`) VALUES (NULL, NULL)
INFO - 2022-06-24 06:50:49 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-24 06:51:12 --> Config Class Initialized
INFO - 2022-06-24 06:51:12 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:51:12 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:51:12 --> Utf8 Class Initialized
INFO - 2022-06-24 06:51:12 --> URI Class Initialized
INFO - 2022-06-24 06:51:12 --> Router Class Initialized
INFO - 2022-06-24 06:51:12 --> Output Class Initialized
INFO - 2022-06-24 06:51:12 --> Security Class Initialized
DEBUG - 2022-06-24 06:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:51:12 --> Input Class Initialized
INFO - 2022-06-24 06:51:12 --> Language Class Initialized
INFO - 2022-06-24 06:51:12 --> Loader Class Initialized
INFO - 2022-06-24 06:51:12 --> Helper loaded: url_helper
INFO - 2022-06-24 06:51:12 --> Helper loaded: file_helper
INFO - 2022-06-24 06:51:12 --> Database Driver Class Initialized
INFO - 2022-06-24 06:51:12 --> Email Class Initialized
DEBUG - 2022-06-24 06:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:51:12 --> Controller Class Initialized
INFO - 2022-06-24 06:51:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:51:12 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:51:12 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 06:51:12 --> Final output sent to browser
DEBUG - 2022-06-24 06:51:12 --> Total execution time: 0.0342
INFO - 2022-06-24 06:51:21 --> Config Class Initialized
INFO - 2022-06-24 06:51:21 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:51:21 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:51:21 --> Utf8 Class Initialized
INFO - 2022-06-24 06:51:21 --> URI Class Initialized
INFO - 2022-06-24 06:51:21 --> Router Class Initialized
INFO - 2022-06-24 06:51:21 --> Output Class Initialized
INFO - 2022-06-24 06:51:21 --> Security Class Initialized
DEBUG - 2022-06-24 06:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:51:21 --> Input Class Initialized
INFO - 2022-06-24 06:51:21 --> Language Class Initialized
INFO - 2022-06-24 06:51:21 --> Loader Class Initialized
INFO - 2022-06-24 06:51:21 --> Helper loaded: url_helper
INFO - 2022-06-24 06:51:21 --> Helper loaded: file_helper
INFO - 2022-06-24 06:51:21 --> Database Driver Class Initialized
INFO - 2022-06-24 06:51:21 --> Config Class Initialized
INFO - 2022-06-24 06:51:21 --> Hooks Class Initialized
INFO - 2022-06-24 06:51:21 --> Email Class Initialized
DEBUG - 2022-06-24 06:51:21 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:51:21 --> Utf8 Class Initialized
INFO - 2022-06-24 06:51:21 --> URI Class Initialized
DEBUG - 2022-06-24 06:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:51:21 --> Router Class Initialized
INFO - 2022-06-24 06:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:51:21 --> Controller Class Initialized
INFO - 2022-06-24 06:51:21 --> Output Class Initialized
INFO - 2022-06-24 06:51:21 --> Security Class Initialized
INFO - 2022-06-24 06:51:21 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:51:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 06:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:51:21 --> Input Class Initialized
INFO - 2022-06-24 06:51:21 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 06:51:21 --> Language Class Initialized
INFO - 2022-06-24 06:51:21 --> Final output sent to browser
DEBUG - 2022-06-24 06:51:21 --> Total execution time: 0.0330
INFO - 2022-06-24 06:51:21 --> Loader Class Initialized
INFO - 2022-06-24 06:51:21 --> Helper loaded: url_helper
INFO - 2022-06-24 06:51:21 --> Helper loaded: file_helper
INFO - 2022-06-24 06:51:21 --> Database Driver Class Initialized
INFO - 2022-06-24 06:51:21 --> Email Class Initialized
DEBUG - 2022-06-24 06:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:51:21 --> Controller Class Initialized
INFO - 2022-06-24 06:51:21 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:51:21 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:51:21 --> Final output sent to browser
DEBUG - 2022-06-24 06:51:21 --> Total execution time: 0.0327
INFO - 2022-06-24 06:51:26 --> Config Class Initialized
INFO - 2022-06-24 06:51:26 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:51:26 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:51:26 --> Utf8 Class Initialized
INFO - 2022-06-24 06:51:26 --> URI Class Initialized
INFO - 2022-06-24 06:51:26 --> Router Class Initialized
INFO - 2022-06-24 06:51:26 --> Output Class Initialized
INFO - 2022-06-24 06:51:26 --> Security Class Initialized
DEBUG - 2022-06-24 06:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:51:26 --> Input Class Initialized
INFO - 2022-06-24 06:51:26 --> Language Class Initialized
INFO - 2022-06-24 06:51:26 --> Loader Class Initialized
INFO - 2022-06-24 06:51:26 --> Helper loaded: url_helper
INFO - 2022-06-24 06:51:26 --> Helper loaded: file_helper
INFO - 2022-06-24 06:51:26 --> Database Driver Class Initialized
INFO - 2022-06-24 06:51:26 --> Email Class Initialized
DEBUG - 2022-06-24 06:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:51:26 --> Controller Class Initialized
INFO - 2022-06-24 06:51:26 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:51:26 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:51:26 --> Final output sent to browser
DEBUG - 2022-06-24 06:51:26 --> Total execution time: 0.0421
INFO - 2022-06-24 06:52:37 --> Config Class Initialized
INFO - 2022-06-24 06:52:37 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:52:37 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:52:37 --> Utf8 Class Initialized
INFO - 2022-06-24 06:52:37 --> URI Class Initialized
INFO - 2022-06-24 06:52:37 --> Router Class Initialized
INFO - 2022-06-24 06:52:37 --> Output Class Initialized
INFO - 2022-06-24 06:52:37 --> Security Class Initialized
DEBUG - 2022-06-24 06:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:52:37 --> Input Class Initialized
INFO - 2022-06-24 06:52:37 --> Language Class Initialized
INFO - 2022-06-24 06:52:37 --> Loader Class Initialized
INFO - 2022-06-24 06:52:37 --> Helper loaded: url_helper
INFO - 2022-06-24 06:52:37 --> Helper loaded: file_helper
INFO - 2022-06-24 06:52:37 --> Database Driver Class Initialized
INFO - 2022-06-24 06:52:37 --> Email Class Initialized
DEBUG - 2022-06-24 06:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:52:37 --> Controller Class Initialized
INFO - 2022-06-24 06:52:37 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:52:37 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:52:37 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 06:52:37 --> Final output sent to browser
DEBUG - 2022-06-24 06:52:37 --> Total execution time: 0.0259
INFO - 2022-06-24 06:52:48 --> Config Class Initialized
INFO - 2022-06-24 06:52:48 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:52:48 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:52:48 --> Utf8 Class Initialized
INFO - 2022-06-24 06:52:48 --> URI Class Initialized
INFO - 2022-06-24 06:52:48 --> Router Class Initialized
INFO - 2022-06-24 06:52:48 --> Output Class Initialized
INFO - 2022-06-24 06:52:48 --> Security Class Initialized
DEBUG - 2022-06-24 06:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:52:48 --> Input Class Initialized
INFO - 2022-06-24 06:52:48 --> Language Class Initialized
INFO - 2022-06-24 06:52:48 --> Config Class Initialized
INFO - 2022-06-24 06:52:48 --> Loader Class Initialized
INFO - 2022-06-24 06:52:48 --> Hooks Class Initialized
INFO - 2022-06-24 06:52:48 --> Helper loaded: url_helper
DEBUG - 2022-06-24 06:52:48 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:52:48 --> Utf8 Class Initialized
INFO - 2022-06-24 06:52:48 --> Helper loaded: file_helper
INFO - 2022-06-24 06:52:48 --> URI Class Initialized
INFO - 2022-06-24 06:52:48 --> Database Driver Class Initialized
INFO - 2022-06-24 06:52:48 --> Router Class Initialized
INFO - 2022-06-24 06:52:48 --> Output Class Initialized
INFO - 2022-06-24 06:52:48 --> Security Class Initialized
INFO - 2022-06-24 06:52:48 --> Email Class Initialized
DEBUG - 2022-06-24 06:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:52:48 --> Input Class Initialized
INFO - 2022-06-24 06:52:48 --> Language Class Initialized
DEBUG - 2022-06-24 06:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:52:48 --> Loader Class Initialized
INFO - 2022-06-24 06:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:52:48 --> Helper loaded: url_helper
INFO - 2022-06-24 06:52:48 --> Controller Class Initialized
INFO - 2022-06-24 06:52:48 --> Helper loaded: file_helper
INFO - 2022-06-24 06:52:48 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:52:48 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:52:48 --> Database Driver Class Initialized
ERROR - 2022-06-24 06:52:48 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::upadate() C:\wamp64\www\qr\application\models\Tokenmodel.php 42
INFO - 2022-06-24 06:52:48 --> Email Class Initialized
DEBUG - 2022-06-24 06:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:52:48 --> Controller Class Initialized
INFO - 2022-06-24 06:52:48 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:52:48 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:52:48 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 06:52:48 --> Final output sent to browser
DEBUG - 2022-06-24 06:52:48 --> Total execution time: 0.0336
INFO - 2022-06-24 06:52:52 --> Config Class Initialized
INFO - 2022-06-24 06:52:52 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:52:52 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:52:52 --> Utf8 Class Initialized
INFO - 2022-06-24 06:52:52 --> URI Class Initialized
INFO - 2022-06-24 06:52:52 --> Router Class Initialized
INFO - 2022-06-24 06:52:52 --> Output Class Initialized
INFO - 2022-06-24 06:52:52 --> Security Class Initialized
DEBUG - 2022-06-24 06:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:52:52 --> Input Class Initialized
INFO - 2022-06-24 06:52:52 --> Language Class Initialized
INFO - 2022-06-24 06:52:52 --> Loader Class Initialized
INFO - 2022-06-24 06:52:52 --> Helper loaded: url_helper
INFO - 2022-06-24 06:52:52 --> Helper loaded: file_helper
INFO - 2022-06-24 06:52:52 --> Database Driver Class Initialized
INFO - 2022-06-24 06:52:52 --> Email Class Initialized
DEBUG - 2022-06-24 06:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:52:52 --> Controller Class Initialized
INFO - 2022-06-24 06:52:52 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:52:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-24 06:52:52 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::upadate() C:\wamp64\www\qr\application\models\Tokenmodel.php 42
INFO - 2022-06-24 06:53:27 --> Config Class Initialized
INFO - 2022-06-24 06:53:27 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:53:27 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:53:27 --> Utf8 Class Initialized
INFO - 2022-06-24 06:53:27 --> URI Class Initialized
INFO - 2022-06-24 06:53:27 --> Router Class Initialized
INFO - 2022-06-24 06:53:27 --> Output Class Initialized
INFO - 2022-06-24 06:53:27 --> Security Class Initialized
DEBUG - 2022-06-24 06:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:53:27 --> Input Class Initialized
INFO - 2022-06-24 06:53:27 --> Language Class Initialized
INFO - 2022-06-24 06:53:27 --> Loader Class Initialized
INFO - 2022-06-24 06:53:27 --> Helper loaded: url_helper
INFO - 2022-06-24 06:53:27 --> Helper loaded: file_helper
INFO - 2022-06-24 06:53:27 --> Database Driver Class Initialized
INFO - 2022-06-24 06:53:27 --> Email Class Initialized
DEBUG - 2022-06-24 06:53:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:53:27 --> Controller Class Initialized
INFO - 2022-06-24 06:53:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:53:27 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:53:27 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 06:53:27 --> Final output sent to browser
DEBUG - 2022-06-24 06:53:27 --> Total execution time: 0.0300
INFO - 2022-06-24 06:53:37 --> Config Class Initialized
INFO - 2022-06-24 06:53:37 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:53:37 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:53:37 --> Utf8 Class Initialized
INFO - 2022-06-24 06:53:37 --> Config Class Initialized
INFO - 2022-06-24 06:53:37 --> URI Class Initialized
INFO - 2022-06-24 06:53:37 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:53:37 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:53:37 --> Router Class Initialized
INFO - 2022-06-24 06:53:37 --> Utf8 Class Initialized
INFO - 2022-06-24 06:53:37 --> Output Class Initialized
INFO - 2022-06-24 06:53:37 --> URI Class Initialized
INFO - 2022-06-24 06:53:37 --> Security Class Initialized
INFO - 2022-06-24 06:53:37 --> Router Class Initialized
DEBUG - 2022-06-24 06:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:53:37 --> Output Class Initialized
INFO - 2022-06-24 06:53:37 --> Input Class Initialized
INFO - 2022-06-24 06:53:37 --> Security Class Initialized
INFO - 2022-06-24 06:53:37 --> Language Class Initialized
DEBUG - 2022-06-24 06:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:53:37 --> Input Class Initialized
INFO - 2022-06-24 06:53:37 --> Loader Class Initialized
INFO - 2022-06-24 06:53:37 --> Language Class Initialized
INFO - 2022-06-24 06:53:37 --> Helper loaded: url_helper
INFO - 2022-06-24 06:53:37 --> Loader Class Initialized
INFO - 2022-06-24 06:53:37 --> Helper loaded: file_helper
INFO - 2022-06-24 06:53:37 --> Helper loaded: url_helper
INFO - 2022-06-24 06:53:37 --> Helper loaded: file_helper
INFO - 2022-06-24 06:53:37 --> Database Driver Class Initialized
INFO - 2022-06-24 06:53:37 --> Database Driver Class Initialized
INFO - 2022-06-24 06:53:37 --> Email Class Initialized
INFO - 2022-06-24 06:53:37 --> Email Class Initialized
DEBUG - 2022-06-24 06:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:53:37 --> Controller Class Initialized
DEBUG - 2022-06-24 06:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:53:37 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:53:37 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:53:37 --> Final output sent to browser
DEBUG - 2022-06-24 06:53:37 --> Total execution time: 0.0362
INFO - 2022-06-24 06:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:53:37 --> Controller Class Initialized
INFO - 2022-06-24 06:53:37 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:53:37 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:53:37 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 06:53:37 --> Final output sent to browser
DEBUG - 2022-06-24 06:53:37 --> Total execution time: 0.0375
INFO - 2022-06-24 06:56:42 --> Config Class Initialized
INFO - 2022-06-24 06:56:42 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:56:42 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:56:42 --> Utf8 Class Initialized
INFO - 2022-06-24 06:56:42 --> URI Class Initialized
INFO - 2022-06-24 06:56:42 --> Router Class Initialized
INFO - 2022-06-24 06:56:42 --> Output Class Initialized
INFO - 2022-06-24 06:56:42 --> Security Class Initialized
DEBUG - 2022-06-24 06:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:56:42 --> Input Class Initialized
INFO - 2022-06-24 06:56:42 --> Language Class Initialized
INFO - 2022-06-24 06:56:42 --> Loader Class Initialized
INFO - 2022-06-24 06:56:42 --> Helper loaded: url_helper
INFO - 2022-06-24 06:56:42 --> Helper loaded: file_helper
INFO - 2022-06-24 06:56:43 --> Database Driver Class Initialized
INFO - 2022-06-24 06:56:43 --> Email Class Initialized
DEBUG - 2022-06-24 06:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:56:43 --> Controller Class Initialized
INFO - 2022-06-24 06:56:43 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:56:43 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:56:43 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 06:56:43 --> Final output sent to browser
DEBUG - 2022-06-24 06:56:43 --> Total execution time: 0.0368
INFO - 2022-06-24 06:56:54 --> Config Class Initialized
INFO - 2022-06-24 06:56:54 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:56:54 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:56:54 --> Utf8 Class Initialized
INFO - 2022-06-24 06:56:54 --> URI Class Initialized
INFO - 2022-06-24 06:56:54 --> Router Class Initialized
INFO - 2022-06-24 06:56:54 --> Output Class Initialized
INFO - 2022-06-24 06:56:54 --> Security Class Initialized
INFO - 2022-06-24 06:56:54 --> Config Class Initialized
DEBUG - 2022-06-24 06:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:56:54 --> Hooks Class Initialized
INFO - 2022-06-24 06:56:54 --> Input Class Initialized
INFO - 2022-06-24 06:56:54 --> Language Class Initialized
DEBUG - 2022-06-24 06:56:54 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:56:54 --> Utf8 Class Initialized
INFO - 2022-06-24 06:56:54 --> Loader Class Initialized
INFO - 2022-06-24 06:56:54 --> URI Class Initialized
INFO - 2022-06-24 06:56:54 --> Helper loaded: url_helper
INFO - 2022-06-24 06:56:54 --> Router Class Initialized
INFO - 2022-06-24 06:56:54 --> Helper loaded: file_helper
INFO - 2022-06-24 06:56:54 --> Output Class Initialized
INFO - 2022-06-24 06:56:54 --> Database Driver Class Initialized
INFO - 2022-06-24 06:56:54 --> Security Class Initialized
DEBUG - 2022-06-24 06:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:56:54 --> Input Class Initialized
INFO - 2022-06-24 06:56:54 --> Email Class Initialized
INFO - 2022-06-24 06:56:54 --> Language Class Initialized
INFO - 2022-06-24 06:56:54 --> Loader Class Initialized
DEBUG - 2022-06-24 06:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:56:54 --> Helper loaded: url_helper
INFO - 2022-06-24 06:56:54 --> Helper loaded: file_helper
INFO - 2022-06-24 06:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:56:54 --> Database Driver Class Initialized
INFO - 2022-06-24 06:56:54 --> Controller Class Initialized
INFO - 2022-06-24 06:56:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:56:54 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:56:54 --> Email Class Initialized
INFO - 2022-06-24 06:56:54 --> Final output sent to browser
DEBUG - 2022-06-24 06:56:54 --> Total execution time: 0.0375
DEBUG - 2022-06-24 06:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:56:54 --> Controller Class Initialized
INFO - 2022-06-24 06:56:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:56:54 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:56:54 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 06:56:54 --> Final output sent to browser
DEBUG - 2022-06-24 06:56:54 --> Total execution time: 0.0417
INFO - 2022-06-24 06:58:25 --> Config Class Initialized
INFO - 2022-06-24 06:58:25 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:58:25 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:58:25 --> Utf8 Class Initialized
INFO - 2022-06-24 06:58:25 --> URI Class Initialized
INFO - 2022-06-24 06:58:25 --> Router Class Initialized
INFO - 2022-06-24 06:58:25 --> Output Class Initialized
INFO - 2022-06-24 06:58:25 --> Security Class Initialized
DEBUG - 2022-06-24 06:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:58:25 --> Input Class Initialized
INFO - 2022-06-24 06:58:25 --> Language Class Initialized
INFO - 2022-06-24 06:58:25 --> Loader Class Initialized
INFO - 2022-06-24 06:58:25 --> Helper loaded: url_helper
INFO - 2022-06-24 06:58:25 --> Helper loaded: file_helper
INFO - 2022-06-24 06:58:25 --> Database Driver Class Initialized
INFO - 2022-06-24 06:58:25 --> Email Class Initialized
DEBUG - 2022-06-24 06:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:58:25 --> Controller Class Initialized
INFO - 2022-06-24 06:58:25 --> Config Class Initialized
INFO - 2022-06-24 06:58:25 --> Hooks Class Initialized
INFO - 2022-06-24 06:58:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:58:25 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:58:25 --> Final output sent to browser
DEBUG - 2022-06-24 06:58:25 --> Total execution time: 0.0325
DEBUG - 2022-06-24 06:58:25 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:58:25 --> Utf8 Class Initialized
INFO - 2022-06-24 06:58:25 --> URI Class Initialized
INFO - 2022-06-24 06:58:25 --> Router Class Initialized
INFO - 2022-06-24 06:58:25 --> Output Class Initialized
INFO - 2022-06-24 06:58:25 --> Security Class Initialized
DEBUG - 2022-06-24 06:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:58:25 --> Input Class Initialized
INFO - 2022-06-24 06:58:25 --> Language Class Initialized
INFO - 2022-06-24 06:58:25 --> Loader Class Initialized
INFO - 2022-06-24 06:58:25 --> Helper loaded: url_helper
INFO - 2022-06-24 06:58:25 --> Helper loaded: file_helper
INFO - 2022-06-24 06:58:25 --> Database Driver Class Initialized
INFO - 2022-06-24 06:58:25 --> Email Class Initialized
DEBUG - 2022-06-24 06:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:58:25 --> Controller Class Initialized
INFO - 2022-06-24 06:58:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:58:25 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:58:25 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 06:58:25 --> Final output sent to browser
DEBUG - 2022-06-24 06:58:25 --> Total execution time: 0.0334
INFO - 2022-06-24 06:59:02 --> Config Class Initialized
INFO - 2022-06-24 06:59:02 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:59:02 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:59:02 --> Utf8 Class Initialized
INFO - 2022-06-24 06:59:02 --> URI Class Initialized
INFO - 2022-06-24 06:59:02 --> Router Class Initialized
INFO - 2022-06-24 06:59:02 --> Output Class Initialized
INFO - 2022-06-24 06:59:02 --> Security Class Initialized
DEBUG - 2022-06-24 06:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:59:02 --> Input Class Initialized
INFO - 2022-06-24 06:59:02 --> Language Class Initialized
INFO - 2022-06-24 06:59:02 --> Loader Class Initialized
INFO - 2022-06-24 06:59:02 --> Helper loaded: url_helper
INFO - 2022-06-24 06:59:02 --> Helper loaded: file_helper
INFO - 2022-06-24 06:59:02 --> Database Driver Class Initialized
INFO - 2022-06-24 06:59:02 --> Email Class Initialized
DEBUG - 2022-06-24 06:59:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:59:02 --> Controller Class Initialized
INFO - 2022-06-24 06:59:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:59:02 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:59:02 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-24 06:59:02 --> Final output sent to browser
DEBUG - 2022-06-24 06:59:02 --> Total execution time: 0.0313
INFO - 2022-06-24 06:59:04 --> Config Class Initialized
INFO - 2022-06-24 06:59:04 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:59:04 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:59:04 --> Utf8 Class Initialized
INFO - 2022-06-24 06:59:04 --> URI Class Initialized
INFO - 2022-06-24 06:59:04 --> Router Class Initialized
INFO - 2022-06-24 06:59:04 --> Output Class Initialized
INFO - 2022-06-24 06:59:04 --> Security Class Initialized
DEBUG - 2022-06-24 06:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:59:04 --> Input Class Initialized
INFO - 2022-06-24 06:59:04 --> Language Class Initialized
INFO - 2022-06-24 06:59:04 --> Loader Class Initialized
INFO - 2022-06-24 06:59:04 --> Helper loaded: url_helper
INFO - 2022-06-24 06:59:04 --> Helper loaded: file_helper
INFO - 2022-06-24 06:59:04 --> Database Driver Class Initialized
INFO - 2022-06-24 06:59:04 --> Email Class Initialized
DEBUG - 2022-06-24 06:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:59:04 --> Controller Class Initialized
INFO - 2022-06-24 06:59:04 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:59:04 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:59:04 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-24 06:59:04 --> Final output sent to browser
DEBUG - 2022-06-24 06:59:04 --> Total execution time: 0.0262
INFO - 2022-06-24 06:59:12 --> Config Class Initialized
INFO - 2022-06-24 06:59:12 --> Hooks Class Initialized
INFO - 2022-06-24 06:59:12 --> Config Class Initialized
INFO - 2022-06-24 06:59:12 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:59:12 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:59:12 --> Utf8 Class Initialized
DEBUG - 2022-06-24 06:59:12 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:59:12 --> URI Class Initialized
INFO - 2022-06-24 06:59:12 --> Utf8 Class Initialized
INFO - 2022-06-24 06:59:12 --> URI Class Initialized
INFO - 2022-06-24 06:59:12 --> Router Class Initialized
INFO - 2022-06-24 06:59:12 --> Router Class Initialized
INFO - 2022-06-24 06:59:12 --> Output Class Initialized
INFO - 2022-06-24 06:59:12 --> Output Class Initialized
INFO - 2022-06-24 06:59:12 --> Security Class Initialized
INFO - 2022-06-24 06:59:12 --> Security Class Initialized
DEBUG - 2022-06-24 06:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 06:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:59:12 --> Input Class Initialized
INFO - 2022-06-24 06:59:12 --> Input Class Initialized
INFO - 2022-06-24 06:59:12 --> Language Class Initialized
INFO - 2022-06-24 06:59:12 --> Language Class Initialized
INFO - 2022-06-24 06:59:12 --> Loader Class Initialized
INFO - 2022-06-24 06:59:12 --> Loader Class Initialized
INFO - 2022-06-24 06:59:12 --> Helper loaded: url_helper
INFO - 2022-06-24 06:59:12 --> Helper loaded: url_helper
INFO - 2022-06-24 06:59:12 --> Helper loaded: file_helper
INFO - 2022-06-24 06:59:12 --> Helper loaded: file_helper
INFO - 2022-06-24 06:59:12 --> Database Driver Class Initialized
INFO - 2022-06-24 06:59:12 --> Database Driver Class Initialized
INFO - 2022-06-24 06:59:12 --> Email Class Initialized
INFO - 2022-06-24 06:59:12 --> Email Class Initialized
DEBUG - 2022-06-24 06:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-24 06:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:59:12 --> Controller Class Initialized
INFO - 2022-06-24 06:59:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:59:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 06:59:12 --> test
INFO - 2022-06-24 06:59:12 --> Final output sent to browser
DEBUG - 2022-06-24 06:59:12 --> Total execution time: 0.0476
INFO - 2022-06-24 06:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:59:12 --> Controller Class Initialized
INFO - 2022-06-24 06:59:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:59:12 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:59:12 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-24 06:59:12 --> Final output sent to browser
DEBUG - 2022-06-24 06:59:12 --> Total execution time: 0.0547
INFO - 2022-06-24 06:59:12 --> Config Class Initialized
INFO - 2022-06-24 06:59:12 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:59:12 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:59:12 --> Utf8 Class Initialized
INFO - 2022-06-24 06:59:12 --> URI Class Initialized
INFO - 2022-06-24 06:59:12 --> Router Class Initialized
INFO - 2022-06-24 06:59:12 --> Output Class Initialized
INFO - 2022-06-24 06:59:12 --> Security Class Initialized
DEBUG - 2022-06-24 06:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:59:12 --> Input Class Initialized
INFO - 2022-06-24 06:59:12 --> Language Class Initialized
INFO - 2022-06-24 06:59:12 --> Loader Class Initialized
INFO - 2022-06-24 06:59:12 --> Helper loaded: url_helper
INFO - 2022-06-24 06:59:12 --> Helper loaded: file_helper
INFO - 2022-06-24 06:59:12 --> Database Driver Class Initialized
INFO - 2022-06-24 06:59:12 --> Email Class Initialized
DEBUG - 2022-06-24 06:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:59:12 --> Controller Class Initialized
INFO - 2022-06-24 06:59:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:59:12 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:59:12 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 06:59:12 --> Final output sent to browser
DEBUG - 2022-06-24 06:59:12 --> Total execution time: 0.0280
INFO - 2022-06-24 06:59:32 --> Config Class Initialized
INFO - 2022-06-24 06:59:32 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:59:32 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:59:32 --> Utf8 Class Initialized
INFO - 2022-06-24 06:59:32 --> URI Class Initialized
INFO - 2022-06-24 06:59:32 --> Router Class Initialized
INFO - 2022-06-24 06:59:32 --> Output Class Initialized
INFO - 2022-06-24 06:59:32 --> Security Class Initialized
DEBUG - 2022-06-24 06:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:59:32 --> Input Class Initialized
INFO - 2022-06-24 06:59:32 --> Language Class Initialized
INFO - 2022-06-24 06:59:32 --> Loader Class Initialized
INFO - 2022-06-24 06:59:32 --> Helper loaded: url_helper
INFO - 2022-06-24 06:59:32 --> Helper loaded: file_helper
INFO - 2022-06-24 06:59:32 --> Database Driver Class Initialized
INFO - 2022-06-24 06:59:32 --> Config Class Initialized
INFO - 2022-06-24 06:59:32 --> Hooks Class Initialized
DEBUG - 2022-06-24 06:59:32 --> UTF-8 Support Enabled
INFO - 2022-06-24 06:59:32 --> Utf8 Class Initialized
INFO - 2022-06-24 06:59:32 --> Email Class Initialized
INFO - 2022-06-24 06:59:32 --> URI Class Initialized
INFO - 2022-06-24 06:59:32 --> Router Class Initialized
DEBUG - 2022-06-24 06:59:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:59:32 --> Output Class Initialized
INFO - 2022-06-24 06:59:32 --> Security Class Initialized
INFO - 2022-06-24 06:59:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2022-06-24 06:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 06:59:32 --> Controller Class Initialized
INFO - 2022-06-24 06:59:32 --> Input Class Initialized
INFO - 2022-06-24 06:59:32 --> Model "Tokenmodel" initialized
INFO - 2022-06-24 06:59:32 --> Language Class Initialized
DEBUG - 2022-06-24 06:59:32 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:59:32 --> Loader Class Initialized
INFO - 2022-06-24 06:59:32 --> Final output sent to browser
DEBUG - 2022-06-24 06:59:32 --> Total execution time: 0.0354
INFO - 2022-06-24 06:59:32 --> Helper loaded: url_helper
INFO - 2022-06-24 06:59:32 --> Helper loaded: file_helper
INFO - 2022-06-24 06:59:32 --> Database Driver Class Initialized
INFO - 2022-06-24 06:59:32 --> Email Class Initialized
DEBUG - 2022-06-24 06:59:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 06:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 06:59:32 --> Controller Class Initialized
INFO - 2022-06-24 06:59:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 06:59:32 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 06:59:32 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 06:59:32 --> Final output sent to browser
DEBUG - 2022-06-24 06:59:32 --> Total execution time: 0.0287
INFO - 2022-06-24 07:00:42 --> Config Class Initialized
INFO - 2022-06-24 07:00:42 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:00:42 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:00:42 --> Utf8 Class Initialized
INFO - 2022-06-24 07:00:42 --> URI Class Initialized
INFO - 2022-06-24 07:00:42 --> Router Class Initialized
INFO - 2022-06-24 07:00:42 --> Output Class Initialized
INFO - 2022-06-24 07:00:42 --> Security Class Initialized
DEBUG - 2022-06-24 07:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:00:42 --> Input Class Initialized
INFO - 2022-06-24 07:00:42 --> Language Class Initialized
INFO - 2022-06-24 07:00:42 --> Loader Class Initialized
INFO - 2022-06-24 07:00:42 --> Helper loaded: url_helper
INFO - 2022-06-24 07:00:42 --> Helper loaded: file_helper
INFO - 2022-06-24 07:00:42 --> Database Driver Class Initialized
INFO - 2022-06-24 07:00:42 --> Email Class Initialized
DEBUG - 2022-06-24 07:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:00:43 --> Controller Class Initialized
INFO - 2022-06-24 07:00:43 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:00:43 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:00:43 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-24 07:00:43 --> Final output sent to browser
DEBUG - 2022-06-24 07:00:43 --> Total execution time: 0.0330
INFO - 2022-06-24 07:00:45 --> Config Class Initialized
INFO - 2022-06-24 07:00:45 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:00:45 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:00:45 --> Utf8 Class Initialized
INFO - 2022-06-24 07:00:45 --> URI Class Initialized
INFO - 2022-06-24 07:00:45 --> Router Class Initialized
INFO - 2022-06-24 07:00:45 --> Output Class Initialized
INFO - 2022-06-24 07:00:45 --> Security Class Initialized
DEBUG - 2022-06-24 07:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:00:45 --> Input Class Initialized
INFO - 2022-06-24 07:00:45 --> Language Class Initialized
INFO - 2022-06-24 07:00:45 --> Loader Class Initialized
INFO - 2022-06-24 07:00:45 --> Helper loaded: url_helper
INFO - 2022-06-24 07:00:45 --> Helper loaded: file_helper
INFO - 2022-06-24 07:00:45 --> Database Driver Class Initialized
INFO - 2022-06-24 07:00:45 --> Email Class Initialized
DEBUG - 2022-06-24 07:00:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:00:45 --> Controller Class Initialized
INFO - 2022-06-24 07:00:45 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:00:45 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:00:45 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-24 07:00:45 --> Final output sent to browser
DEBUG - 2022-06-24 07:00:45 --> Total execution time: 0.0354
INFO - 2022-06-24 07:00:54 --> Config Class Initialized
INFO - 2022-06-24 07:00:54 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:00:54 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:00:54 --> Utf8 Class Initialized
INFO - 2022-06-24 07:00:54 --> Config Class Initialized
INFO - 2022-06-24 07:00:54 --> Hooks Class Initialized
INFO - 2022-06-24 07:00:54 --> URI Class Initialized
DEBUG - 2022-06-24 07:00:54 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:00:54 --> Utf8 Class Initialized
INFO - 2022-06-24 07:00:54 --> Router Class Initialized
INFO - 2022-06-24 07:00:54 --> URI Class Initialized
INFO - 2022-06-24 07:00:54 --> Output Class Initialized
INFO - 2022-06-24 07:00:54 --> Router Class Initialized
INFO - 2022-06-24 07:00:54 --> Security Class Initialized
INFO - 2022-06-24 07:00:54 --> Output Class Initialized
DEBUG - 2022-06-24 07:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:00:54 --> Input Class Initialized
INFO - 2022-06-24 07:00:54 --> Security Class Initialized
DEBUG - 2022-06-24 07:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:00:54 --> Language Class Initialized
INFO - 2022-06-24 07:00:54 --> Input Class Initialized
INFO - 2022-06-24 07:00:54 --> Loader Class Initialized
INFO - 2022-06-24 07:00:54 --> Language Class Initialized
INFO - 2022-06-24 07:00:54 --> Helper loaded: url_helper
INFO - 2022-06-24 07:00:54 --> Loader Class Initialized
INFO - 2022-06-24 07:00:54 --> Helper loaded: file_helper
INFO - 2022-06-24 07:00:54 --> Helper loaded: url_helper
INFO - 2022-06-24 07:00:54 --> Helper loaded: file_helper
INFO - 2022-06-24 07:00:54 --> Database Driver Class Initialized
INFO - 2022-06-24 07:00:54 --> Database Driver Class Initialized
INFO - 2022-06-24 07:00:54 --> Email Class Initialized
INFO - 2022-06-24 07:00:54 --> Email Class Initialized
DEBUG - 2022-06-24 07:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-24 07:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:00:54 --> Controller Class Initialized
INFO - 2022-06-24 07:00:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:00:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 07:00:54 --> test
INFO - 2022-06-24 07:00:54 --> Final output sent to browser
DEBUG - 2022-06-24 07:00:54 --> Total execution time: 0.0338
INFO - 2022-06-24 07:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:00:54 --> Controller Class Initialized
INFO - 2022-06-24 07:00:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:00:54 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:00:54 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-24 07:00:54 --> Final output sent to browser
DEBUG - 2022-06-24 07:00:54 --> Total execution time: 0.0381
INFO - 2022-06-24 07:00:54 --> Config Class Initialized
INFO - 2022-06-24 07:00:54 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:00:54 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:00:54 --> Utf8 Class Initialized
INFO - 2022-06-24 07:00:54 --> URI Class Initialized
INFO - 2022-06-24 07:00:54 --> Router Class Initialized
INFO - 2022-06-24 07:00:54 --> Output Class Initialized
INFO - 2022-06-24 07:00:54 --> Security Class Initialized
DEBUG - 2022-06-24 07:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:00:54 --> Input Class Initialized
INFO - 2022-06-24 07:00:54 --> Language Class Initialized
INFO - 2022-06-24 07:00:54 --> Loader Class Initialized
INFO - 2022-06-24 07:00:54 --> Helper loaded: url_helper
INFO - 2022-06-24 07:00:54 --> Helper loaded: file_helper
INFO - 2022-06-24 07:00:54 --> Database Driver Class Initialized
INFO - 2022-06-24 07:00:54 --> Email Class Initialized
DEBUG - 2022-06-24 07:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:00:54 --> Controller Class Initialized
INFO - 2022-06-24 07:00:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:00:54 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:00:54 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 07:00:54 --> Final output sent to browser
DEBUG - 2022-06-24 07:00:54 --> Total execution time: 0.0423
INFO - 2022-06-24 07:01:11 --> Config Class Initialized
INFO - 2022-06-24 07:01:11 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:01:11 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:01:11 --> Utf8 Class Initialized
INFO - 2022-06-24 07:01:11 --> URI Class Initialized
INFO - 2022-06-24 07:01:11 --> Router Class Initialized
INFO - 2022-06-24 07:01:11 --> Output Class Initialized
INFO - 2022-06-24 07:01:11 --> Config Class Initialized
INFO - 2022-06-24 07:01:11 --> Hooks Class Initialized
INFO - 2022-06-24 07:01:11 --> Security Class Initialized
DEBUG - 2022-06-24 07:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 07:01:11 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:01:11 --> Input Class Initialized
INFO - 2022-06-24 07:01:11 --> Utf8 Class Initialized
INFO - 2022-06-24 07:01:11 --> Language Class Initialized
INFO - 2022-06-24 07:01:11 --> URI Class Initialized
INFO - 2022-06-24 07:01:11 --> Loader Class Initialized
INFO - 2022-06-24 07:01:11 --> Router Class Initialized
INFO - 2022-06-24 07:01:11 --> Output Class Initialized
INFO - 2022-06-24 07:01:11 --> Helper loaded: url_helper
INFO - 2022-06-24 07:01:11 --> Security Class Initialized
INFO - 2022-06-24 07:01:11 --> Helper loaded: file_helper
DEBUG - 2022-06-24 07:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:01:11 --> Input Class Initialized
INFO - 2022-06-24 07:01:11 --> Database Driver Class Initialized
INFO - 2022-06-24 07:01:11 --> Language Class Initialized
INFO - 2022-06-24 07:01:11 --> Loader Class Initialized
INFO - 2022-06-24 07:01:11 --> Helper loaded: url_helper
INFO - 2022-06-24 07:01:11 --> Email Class Initialized
INFO - 2022-06-24 07:01:11 --> Helper loaded: file_helper
INFO - 2022-06-24 07:01:11 --> Database Driver Class Initialized
DEBUG - 2022-06-24 07:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:01:11 --> Controller Class Initialized
INFO - 2022-06-24 07:01:11 --> Email Class Initialized
INFO - 2022-06-24 07:01:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:01:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 07:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:01:11 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 07:01:11 --> Final output sent to browser
DEBUG - 2022-06-24 07:01:11 --> Total execution time: 0.0357
INFO - 2022-06-24 07:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:01:11 --> Controller Class Initialized
INFO - 2022-06-24 07:01:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:01:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:01:11 --> Final output sent to browser
DEBUG - 2022-06-24 07:01:11 --> Total execution time: 0.0345
INFO - 2022-06-24 07:03:43 --> Config Class Initialized
INFO - 2022-06-24 07:03:43 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:03:43 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:03:43 --> Utf8 Class Initialized
INFO - 2022-06-24 07:03:43 --> URI Class Initialized
INFO - 2022-06-24 07:03:43 --> Router Class Initialized
INFO - 2022-06-24 07:03:43 --> Output Class Initialized
INFO - 2022-06-24 07:03:43 --> Security Class Initialized
DEBUG - 2022-06-24 07:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:03:43 --> Input Class Initialized
INFO - 2022-06-24 07:03:43 --> Language Class Initialized
INFO - 2022-06-24 07:03:43 --> Loader Class Initialized
INFO - 2022-06-24 07:03:43 --> Helper loaded: url_helper
INFO - 2022-06-24 07:03:43 --> Helper loaded: file_helper
INFO - 2022-06-24 07:03:43 --> Database Driver Class Initialized
INFO - 2022-06-24 07:03:43 --> Email Class Initialized
DEBUG - 2022-06-24 07:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:03:43 --> Controller Class Initialized
INFO - 2022-06-24 07:03:43 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:03:43 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:03:43 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 07:03:43 --> Final output sent to browser
DEBUG - 2022-06-24 07:03:43 --> Total execution time: 0.0372
INFO - 2022-06-24 07:04:04 --> Config Class Initialized
INFO - 2022-06-24 07:04:04 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:04:04 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:04:04 --> Utf8 Class Initialized
INFO - 2022-06-24 07:04:04 --> URI Class Initialized
INFO - 2022-06-24 07:04:04 --> Router Class Initialized
INFO - 2022-06-24 07:04:04 --> Config Class Initialized
INFO - 2022-06-24 07:04:04 --> Hooks Class Initialized
INFO - 2022-06-24 07:04:04 --> Output Class Initialized
DEBUG - 2022-06-24 07:04:04 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:04:04 --> Security Class Initialized
INFO - 2022-06-24 07:04:04 --> Utf8 Class Initialized
DEBUG - 2022-06-24 07:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:04:04 --> URI Class Initialized
INFO - 2022-06-24 07:04:04 --> Input Class Initialized
INFO - 2022-06-24 07:04:04 --> Language Class Initialized
INFO - 2022-06-24 07:04:04 --> Router Class Initialized
INFO - 2022-06-24 07:04:04 --> Loader Class Initialized
INFO - 2022-06-24 07:04:04 --> Output Class Initialized
INFO - 2022-06-24 07:04:04 --> Security Class Initialized
INFO - 2022-06-24 07:04:04 --> Helper loaded: url_helper
DEBUG - 2022-06-24 07:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:04:04 --> Helper loaded: file_helper
INFO - 2022-06-24 07:04:04 --> Input Class Initialized
INFO - 2022-06-24 07:04:04 --> Language Class Initialized
INFO - 2022-06-24 07:04:04 --> Database Driver Class Initialized
INFO - 2022-06-24 07:04:04 --> Loader Class Initialized
INFO - 2022-06-24 07:04:04 --> Helper loaded: url_helper
INFO - 2022-06-24 07:04:04 --> Helper loaded: file_helper
INFO - 2022-06-24 07:04:04 --> Email Class Initialized
INFO - 2022-06-24 07:04:04 --> Database Driver Class Initialized
DEBUG - 2022-06-24 07:04:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:04:04 --> Email Class Initialized
INFO - 2022-06-24 07:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:04:04 --> Controller Class Initialized
DEBUG - 2022-06-24 07:04:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:04:04 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:04:04 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:04:04 --> Final output sent to browser
DEBUG - 2022-06-24 07:04:04 --> Total execution time: 0.0392
INFO - 2022-06-24 07:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:04:04 --> Controller Class Initialized
INFO - 2022-06-24 07:04:04 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:04:04 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:04:04 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 07:04:04 --> Final output sent to browser
DEBUG - 2022-06-24 07:04:04 --> Total execution time: 0.0360
INFO - 2022-06-24 07:05:00 --> Config Class Initialized
INFO - 2022-06-24 07:05:00 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:05:00 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:05:00 --> Utf8 Class Initialized
INFO - 2022-06-24 07:05:00 --> URI Class Initialized
INFO - 2022-06-24 07:05:00 --> Router Class Initialized
INFO - 2022-06-24 07:05:00 --> Output Class Initialized
INFO - 2022-06-24 07:05:00 --> Security Class Initialized
DEBUG - 2022-06-24 07:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:05:00 --> Input Class Initialized
INFO - 2022-06-24 07:05:00 --> Language Class Initialized
INFO - 2022-06-24 07:05:00 --> Loader Class Initialized
INFO - 2022-06-24 07:05:00 --> Helper loaded: url_helper
INFO - 2022-06-24 07:05:00 --> Helper loaded: file_helper
INFO - 2022-06-24 07:05:00 --> Database Driver Class Initialized
INFO - 2022-06-24 07:05:00 --> Email Class Initialized
DEBUG - 2022-06-24 07:05:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:05:00 --> Controller Class Initialized
INFO - 2022-06-24 07:05:00 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:05:00 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:05:00 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 07:05:00 --> Final output sent to browser
DEBUG - 2022-06-24 07:05:00 --> Total execution time: 0.0395
INFO - 2022-06-24 07:05:11 --> Config Class Initialized
INFO - 2022-06-24 07:05:11 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:05:11 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:05:11 --> Utf8 Class Initialized
INFO - 2022-06-24 07:05:11 --> Config Class Initialized
INFO - 2022-06-24 07:05:11 --> Hooks Class Initialized
INFO - 2022-06-24 07:05:11 --> URI Class Initialized
DEBUG - 2022-06-24 07:05:11 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:05:11 --> Utf8 Class Initialized
INFO - 2022-06-24 07:05:11 --> Router Class Initialized
INFO - 2022-06-24 07:05:11 --> URI Class Initialized
INFO - 2022-06-24 07:05:11 --> Output Class Initialized
INFO - 2022-06-24 07:05:11 --> Security Class Initialized
INFO - 2022-06-24 07:05:11 --> Router Class Initialized
DEBUG - 2022-06-24 07:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:05:11 --> Output Class Initialized
INFO - 2022-06-24 07:05:11 --> Input Class Initialized
INFO - 2022-06-24 07:05:11 --> Security Class Initialized
INFO - 2022-06-24 07:05:11 --> Language Class Initialized
DEBUG - 2022-06-24 07:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:05:11 --> Input Class Initialized
INFO - 2022-06-24 07:05:11 --> Loader Class Initialized
INFO - 2022-06-24 07:05:11 --> Language Class Initialized
INFO - 2022-06-24 07:05:11 --> Helper loaded: url_helper
INFO - 2022-06-24 07:05:11 --> Loader Class Initialized
INFO - 2022-06-24 07:05:11 --> Helper loaded: file_helper
INFO - 2022-06-24 07:05:11 --> Helper loaded: url_helper
INFO - 2022-06-24 07:05:11 --> Database Driver Class Initialized
INFO - 2022-06-24 07:05:11 --> Helper loaded: file_helper
INFO - 2022-06-24 07:05:11 --> Database Driver Class Initialized
INFO - 2022-06-24 07:05:11 --> Email Class Initialized
INFO - 2022-06-24 07:05:11 --> Email Class Initialized
DEBUG - 2022-06-24 07:05:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:05:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2022-06-24 07:05:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:05:11 --> Controller Class Initialized
INFO - 2022-06-24 07:05:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:05:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-24 07:05:11 --> Severity: error --> Exception: Call to undefined function alert() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 42
INFO - 2022-06-24 07:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:05:11 --> Controller Class Initialized
INFO - 2022-06-24 07:05:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:05:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:05:11 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 07:05:11 --> Final output sent to browser
DEBUG - 2022-06-24 07:05:11 --> Total execution time: 0.0372
INFO - 2022-06-24 07:05:17 --> Config Class Initialized
INFO - 2022-06-24 07:05:17 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:05:17 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:05:17 --> Utf8 Class Initialized
INFO - 2022-06-24 07:05:17 --> URI Class Initialized
INFO - 2022-06-24 07:05:17 --> Router Class Initialized
INFO - 2022-06-24 07:05:17 --> Output Class Initialized
INFO - 2022-06-24 07:05:17 --> Security Class Initialized
DEBUG - 2022-06-24 07:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:05:17 --> Input Class Initialized
INFO - 2022-06-24 07:05:17 --> Language Class Initialized
INFO - 2022-06-24 07:05:17 --> Loader Class Initialized
INFO - 2022-06-24 07:05:17 --> Helper loaded: url_helper
INFO - 2022-06-24 07:05:17 --> Helper loaded: file_helper
INFO - 2022-06-24 07:05:17 --> Database Driver Class Initialized
INFO - 2022-06-24 07:05:17 --> Email Class Initialized
DEBUG - 2022-06-24 07:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:05:17 --> Controller Class Initialized
INFO - 2022-06-24 07:05:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:05:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-24 07:05:17 --> Severity: error --> Exception: Call to undefined function alert() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 42
INFO - 2022-06-24 07:05:59 --> Config Class Initialized
INFO - 2022-06-24 07:05:59 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:05:59 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:05:59 --> Utf8 Class Initialized
INFO - 2022-06-24 07:05:59 --> URI Class Initialized
INFO - 2022-06-24 07:05:59 --> Router Class Initialized
INFO - 2022-06-24 07:05:59 --> Output Class Initialized
INFO - 2022-06-24 07:05:59 --> Security Class Initialized
DEBUG - 2022-06-24 07:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:05:59 --> Input Class Initialized
INFO - 2022-06-24 07:05:59 --> Language Class Initialized
INFO - 2022-06-24 07:05:59 --> Loader Class Initialized
INFO - 2022-06-24 07:05:59 --> Helper loaded: url_helper
INFO - 2022-06-24 07:05:59 --> Helper loaded: file_helper
INFO - 2022-06-24 07:05:59 --> Database Driver Class Initialized
INFO - 2022-06-24 07:05:59 --> Email Class Initialized
DEBUG - 2022-06-24 07:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:05:59 --> Controller Class Initialized
INFO - 2022-06-24 07:05:59 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:05:59 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:05:59 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 07:05:59 --> Final output sent to browser
DEBUG - 2022-06-24 07:05:59 --> Total execution time: 0.0312
INFO - 2022-06-24 07:06:10 --> Config Class Initialized
INFO - 2022-06-24 07:06:10 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:06:10 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:06:10 --> Utf8 Class Initialized
INFO - 2022-06-24 07:06:10 --> Config Class Initialized
INFO - 2022-06-24 07:06:10 --> URI Class Initialized
INFO - 2022-06-24 07:06:10 --> Hooks Class Initialized
INFO - 2022-06-24 07:06:10 --> Router Class Initialized
DEBUG - 2022-06-24 07:06:10 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:06:10 --> Output Class Initialized
INFO - 2022-06-24 07:06:10 --> Utf8 Class Initialized
INFO - 2022-06-24 07:06:10 --> Security Class Initialized
INFO - 2022-06-24 07:06:10 --> URI Class Initialized
DEBUG - 2022-06-24 07:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:06:10 --> Input Class Initialized
INFO - 2022-06-24 07:06:10 --> Router Class Initialized
INFO - 2022-06-24 07:06:10 --> Language Class Initialized
INFO - 2022-06-24 07:06:10 --> Output Class Initialized
INFO - 2022-06-24 07:06:10 --> Loader Class Initialized
INFO - 2022-06-24 07:06:10 --> Security Class Initialized
DEBUG - 2022-06-24 07:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:06:10 --> Helper loaded: url_helper
INFO - 2022-06-24 07:06:10 --> Input Class Initialized
INFO - 2022-06-24 07:06:10 --> Helper loaded: file_helper
INFO - 2022-06-24 07:06:10 --> Language Class Initialized
INFO - 2022-06-24 07:06:10 --> Loader Class Initialized
INFO - 2022-06-24 07:06:10 --> Database Driver Class Initialized
INFO - 2022-06-24 07:06:10 --> Helper loaded: url_helper
INFO - 2022-06-24 07:06:10 --> Helper loaded: file_helper
INFO - 2022-06-24 07:06:10 --> Database Driver Class Initialized
INFO - 2022-06-24 07:06:10 --> Email Class Initialized
DEBUG - 2022-06-24 07:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:06:10 --> Email Class Initialized
INFO - 2022-06-24 07:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:06:10 --> Controller Class Initialized
DEBUG - 2022-06-24 07:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:06:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:06:10 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:06:10 --> Final output sent to browser
DEBUG - 2022-06-24 07:06:10 --> Total execution time: 0.0333
INFO - 2022-06-24 07:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:06:10 --> Controller Class Initialized
INFO - 2022-06-24 07:06:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:06:10 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:06:10 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 07:06:10 --> Final output sent to browser
DEBUG - 2022-06-24 07:06:10 --> Total execution time: 0.0357
INFO - 2022-06-24 07:07:54 --> Config Class Initialized
INFO - 2022-06-24 07:07:54 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:07:54 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:07:54 --> Utf8 Class Initialized
INFO - 2022-06-24 07:07:54 --> URI Class Initialized
INFO - 2022-06-24 07:07:54 --> Router Class Initialized
INFO - 2022-06-24 07:07:54 --> Output Class Initialized
INFO - 2022-06-24 07:07:54 --> Security Class Initialized
DEBUG - 2022-06-24 07:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:07:54 --> Input Class Initialized
INFO - 2022-06-24 07:07:54 --> Language Class Initialized
INFO - 2022-06-24 07:07:54 --> Loader Class Initialized
INFO - 2022-06-24 07:07:54 --> Helper loaded: url_helper
INFO - 2022-06-24 07:07:54 --> Helper loaded: file_helper
INFO - 2022-06-24 07:07:54 --> Database Driver Class Initialized
INFO - 2022-06-24 07:07:54 --> Email Class Initialized
DEBUG - 2022-06-24 07:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:07:54 --> Controller Class Initialized
INFO - 2022-06-24 07:07:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:07:54 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:07:54 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 07:07:54 --> Final output sent to browser
DEBUG - 2022-06-24 07:07:54 --> Total execution time: 0.0265
INFO - 2022-06-24 07:08:08 --> Config Class Initialized
INFO - 2022-06-24 07:08:08 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:08:08 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:08:08 --> Utf8 Class Initialized
INFO - 2022-06-24 07:08:08 --> URI Class Initialized
INFO - 2022-06-24 07:08:08 --> Router Class Initialized
INFO - 2022-06-24 07:08:08 --> Output Class Initialized
INFO - 2022-06-24 07:08:08 --> Security Class Initialized
DEBUG - 2022-06-24 07:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:08:08 --> Input Class Initialized
INFO - 2022-06-24 07:08:08 --> Language Class Initialized
INFO - 2022-06-24 07:08:08 --> Config Class Initialized
INFO - 2022-06-24 07:08:08 --> Loader Class Initialized
INFO - 2022-06-24 07:08:08 --> Hooks Class Initialized
INFO - 2022-06-24 07:08:08 --> Helper loaded: url_helper
DEBUG - 2022-06-24 07:08:08 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:08:08 --> Helper loaded: file_helper
INFO - 2022-06-24 07:08:08 --> Utf8 Class Initialized
INFO - 2022-06-24 07:08:08 --> URI Class Initialized
INFO - 2022-06-24 07:08:08 --> Database Driver Class Initialized
INFO - 2022-06-24 07:08:08 --> Router Class Initialized
INFO - 2022-06-24 07:08:08 --> Output Class Initialized
INFO - 2022-06-24 07:08:08 --> Security Class Initialized
DEBUG - 2022-06-24 07:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:08:08 --> Input Class Initialized
INFO - 2022-06-24 07:08:08 --> Language Class Initialized
INFO - 2022-06-24 07:08:08 --> Loader Class Initialized
INFO - 2022-06-24 07:08:08 --> Helper loaded: url_helper
INFO - 2022-06-24 07:08:08 --> Helper loaded: file_helper
INFO - 2022-06-24 07:08:08 --> Database Driver Class Initialized
INFO - 2022-06-24 07:08:08 --> Email Class Initialized
DEBUG - 2022-06-24 07:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:08:08 --> Controller Class Initialized
INFO - 2022-06-24 07:08:08 --> Email Class Initialized
INFO - 2022-06-24 07:08:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:08:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 07:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:08:08 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 07:08:08 --> Final output sent to browser
DEBUG - 2022-06-24 07:08:08 --> Total execution time: 0.0349
INFO - 2022-06-24 07:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:08:08 --> Controller Class Initialized
INFO - 2022-06-24 07:08:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:08:08 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:08:08 --> Final output sent to browser
DEBUG - 2022-06-24 07:08:08 --> Total execution time: 0.0591
INFO - 2022-06-24 07:08:11 --> Config Class Initialized
INFO - 2022-06-24 07:08:11 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:08:11 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:08:11 --> Utf8 Class Initialized
INFO - 2022-06-24 07:08:11 --> URI Class Initialized
INFO - 2022-06-24 07:08:11 --> Router Class Initialized
INFO - 2022-06-24 07:08:11 --> Output Class Initialized
INFO - 2022-06-24 07:08:11 --> Security Class Initialized
DEBUG - 2022-06-24 07:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:08:11 --> Input Class Initialized
INFO - 2022-06-24 07:08:11 --> Language Class Initialized
INFO - 2022-06-24 07:08:11 --> Loader Class Initialized
INFO - 2022-06-24 07:08:11 --> Helper loaded: url_helper
INFO - 2022-06-24 07:08:11 --> Helper loaded: file_helper
INFO - 2022-06-24 07:08:11 --> Database Driver Class Initialized
INFO - 2022-06-24 07:08:11 --> Email Class Initialized
DEBUG - 2022-06-24 07:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:08:11 --> Controller Class Initialized
INFO - 2022-06-24 07:08:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:08:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:08:11 --> Final output sent to browser
DEBUG - 2022-06-24 07:08:11 --> Total execution time: 0.0301
INFO - 2022-06-24 07:10:36 --> Config Class Initialized
INFO - 2022-06-24 07:10:36 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:10:36 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:10:36 --> Utf8 Class Initialized
INFO - 2022-06-24 07:10:36 --> URI Class Initialized
INFO - 2022-06-24 07:10:36 --> Router Class Initialized
INFO - 2022-06-24 07:10:36 --> Output Class Initialized
INFO - 2022-06-24 07:10:36 --> Security Class Initialized
DEBUG - 2022-06-24 07:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:10:36 --> Input Class Initialized
INFO - 2022-06-24 07:10:36 --> Language Class Initialized
INFO - 2022-06-24 07:10:36 --> Loader Class Initialized
INFO - 2022-06-24 07:10:36 --> Helper loaded: url_helper
INFO - 2022-06-24 07:10:36 --> Helper loaded: file_helper
INFO - 2022-06-24 07:10:36 --> Database Driver Class Initialized
INFO - 2022-06-24 07:10:36 --> Email Class Initialized
DEBUG - 2022-06-24 07:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:10:36 --> Controller Class Initialized
INFO - 2022-06-24 07:10:36 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:10:36 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:10:36 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 07:10:36 --> Final output sent to browser
DEBUG - 2022-06-24 07:10:36 --> Total execution time: 0.0466
INFO - 2022-06-24 07:10:47 --> Config Class Initialized
INFO - 2022-06-24 07:10:47 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:10:47 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:10:47 --> Utf8 Class Initialized
INFO - 2022-06-24 07:10:47 --> URI Class Initialized
INFO - 2022-06-24 07:10:47 --> Router Class Initialized
INFO - 2022-06-24 07:10:47 --> Output Class Initialized
INFO - 2022-06-24 07:10:47 --> Security Class Initialized
DEBUG - 2022-06-24 07:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:10:47 --> Input Class Initialized
INFO - 2022-06-24 07:10:47 --> Language Class Initialized
INFO - 2022-06-24 07:10:47 --> Loader Class Initialized
INFO - 2022-06-24 07:10:47 --> Helper loaded: url_helper
INFO - 2022-06-24 07:10:47 --> Helper loaded: file_helper
INFO - 2022-06-24 07:10:47 --> Config Class Initialized
INFO - 2022-06-24 07:10:47 --> Hooks Class Initialized
INFO - 2022-06-24 07:10:47 --> Database Driver Class Initialized
DEBUG - 2022-06-24 07:10:47 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:10:47 --> Utf8 Class Initialized
INFO - 2022-06-24 07:10:47 --> URI Class Initialized
INFO - 2022-06-24 07:10:47 --> Router Class Initialized
INFO - 2022-06-24 07:10:47 --> Output Class Initialized
INFO - 2022-06-24 07:10:47 --> Security Class Initialized
DEBUG - 2022-06-24 07:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:10:47 --> Input Class Initialized
INFO - 2022-06-24 07:10:47 --> Language Class Initialized
INFO - 2022-06-24 07:10:47 --> Loader Class Initialized
INFO - 2022-06-24 07:10:47 --> Helper loaded: url_helper
INFO - 2022-06-24 07:10:47 --> Helper loaded: file_helper
INFO - 2022-06-24 07:10:47 --> Database Driver Class Initialized
INFO - 2022-06-24 07:10:47 --> Email Class Initialized
DEBUG - 2022-06-24 07:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:10:47 --> Controller Class Initialized
INFO - 2022-06-24 07:10:47 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:10:47 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:10:47 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 07:10:47 --> Email Class Initialized
INFO - 2022-06-24 07:10:47 --> Final output sent to browser
DEBUG - 2022-06-24 07:10:47 --> Total execution time: 0.0285
DEBUG - 2022-06-24 07:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:10:47 --> Controller Class Initialized
INFO - 2022-06-24 07:10:47 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:10:47 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:10:47 --> Final output sent to browser
DEBUG - 2022-06-24 07:10:47 --> Total execution time: 0.0574
INFO - 2022-06-24 07:10:52 --> Config Class Initialized
INFO - 2022-06-24 07:10:52 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:10:52 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:10:52 --> Utf8 Class Initialized
INFO - 2022-06-24 07:10:52 --> URI Class Initialized
INFO - 2022-06-24 07:10:52 --> Router Class Initialized
INFO - 2022-06-24 07:10:52 --> Output Class Initialized
INFO - 2022-06-24 07:10:52 --> Security Class Initialized
DEBUG - 2022-06-24 07:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:10:52 --> Input Class Initialized
INFO - 2022-06-24 07:10:52 --> Language Class Initialized
INFO - 2022-06-24 07:10:52 --> Loader Class Initialized
INFO - 2022-06-24 07:10:52 --> Helper loaded: url_helper
INFO - 2022-06-24 07:10:52 --> Helper loaded: file_helper
INFO - 2022-06-24 07:10:52 --> Database Driver Class Initialized
INFO - 2022-06-24 07:10:52 --> Email Class Initialized
DEBUG - 2022-06-24 07:10:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:10:52 --> Controller Class Initialized
INFO - 2022-06-24 07:10:52 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:10:52 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:10:52 --> Final output sent to browser
DEBUG - 2022-06-24 07:10:52 --> Total execution time: 0.0346
INFO - 2022-06-24 07:14:24 --> Config Class Initialized
INFO - 2022-06-24 07:14:24 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:14:24 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:14:24 --> Utf8 Class Initialized
INFO - 2022-06-24 07:14:24 --> URI Class Initialized
INFO - 2022-06-24 07:14:24 --> Router Class Initialized
INFO - 2022-06-24 07:14:24 --> Output Class Initialized
INFO - 2022-06-24 07:14:24 --> Security Class Initialized
DEBUG - 2022-06-24 07:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:14:24 --> Input Class Initialized
INFO - 2022-06-24 07:14:24 --> Language Class Initialized
INFO - 2022-06-24 07:14:24 --> Loader Class Initialized
INFO - 2022-06-24 07:14:24 --> Helper loaded: url_helper
INFO - 2022-06-24 07:14:24 --> Helper loaded: file_helper
INFO - 2022-06-24 07:14:24 --> Database Driver Class Initialized
INFO - 2022-06-24 07:14:24 --> Email Class Initialized
DEBUG - 2022-06-24 07:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:14:24 --> Controller Class Initialized
INFO - 2022-06-24 07:14:24 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:14:24 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:14:24 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 07:14:24 --> Final output sent to browser
DEBUG - 2022-06-24 07:14:24 --> Total execution time: 0.0314
INFO - 2022-06-24 07:14:34 --> Config Class Initialized
INFO - 2022-06-24 07:14:34 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:14:34 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:14:34 --> Utf8 Class Initialized
INFO - 2022-06-24 07:14:34 --> URI Class Initialized
INFO - 2022-06-24 07:14:34 --> Router Class Initialized
INFO - 2022-06-24 07:14:34 --> Output Class Initialized
INFO - 2022-06-24 07:14:34 --> Security Class Initialized
DEBUG - 2022-06-24 07:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:14:34 --> Input Class Initialized
INFO - 2022-06-24 07:14:34 --> Language Class Initialized
INFO - 2022-06-24 07:14:34 --> Loader Class Initialized
INFO - 2022-06-24 07:14:34 --> Config Class Initialized
INFO - 2022-06-24 07:14:34 --> Helper loaded: url_helper
INFO - 2022-06-24 07:14:34 --> Hooks Class Initialized
INFO - 2022-06-24 07:14:34 --> Helper loaded: file_helper
DEBUG - 2022-06-24 07:14:34 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:14:34 --> Utf8 Class Initialized
INFO - 2022-06-24 07:14:34 --> Database Driver Class Initialized
INFO - 2022-06-24 07:14:34 --> URI Class Initialized
INFO - 2022-06-24 07:14:34 --> Router Class Initialized
INFO - 2022-06-24 07:14:34 --> Email Class Initialized
INFO - 2022-06-24 07:14:34 --> Output Class Initialized
INFO - 2022-06-24 07:14:34 --> Security Class Initialized
DEBUG - 2022-06-24 07:14:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-24 07:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:14:34 --> Input Class Initialized
INFO - 2022-06-24 07:14:34 --> Language Class Initialized
INFO - 2022-06-24 07:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:14:34 --> Controller Class Initialized
INFO - 2022-06-24 07:14:34 --> Loader Class Initialized
INFO - 2022-06-24 07:14:34 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:14:34 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:14:34 --> Helper loaded: url_helper
INFO - 2022-06-24 07:14:34 --> Helper loaded: file_helper
INFO - 2022-06-24 07:14:34 --> Database Driver Class Initialized
INFO - 2022-06-24 07:14:34 --> Email Class Initialized
DEBUG - 2022-06-24 07:14:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:14:34 --> Controller Class Initialized
INFO - 2022-06-24 07:14:34 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:14:34 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:14:34 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 07:14:35 --> Final output sent to browser
DEBUG - 2022-06-24 07:14:35 --> Total execution time: 0.0325
INFO - 2022-06-24 07:15:56 --> Config Class Initialized
INFO - 2022-06-24 07:15:56 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:15:56 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:15:56 --> Utf8 Class Initialized
INFO - 2022-06-24 07:15:56 --> URI Class Initialized
INFO - 2022-06-24 07:15:56 --> Router Class Initialized
INFO - 2022-06-24 07:15:56 --> Output Class Initialized
INFO - 2022-06-24 07:15:56 --> Security Class Initialized
DEBUG - 2022-06-24 07:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:15:56 --> Input Class Initialized
INFO - 2022-06-24 07:15:56 --> Language Class Initialized
INFO - 2022-06-24 07:15:56 --> Loader Class Initialized
INFO - 2022-06-24 07:15:56 --> Helper loaded: url_helper
INFO - 2022-06-24 07:15:56 --> Helper loaded: file_helper
INFO - 2022-06-24 07:15:56 --> Database Driver Class Initialized
INFO - 2022-06-24 07:15:56 --> Email Class Initialized
DEBUG - 2022-06-24 07:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:15:56 --> Controller Class Initialized
INFO - 2022-06-24 07:15:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:15:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:15:56 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 07:15:56 --> Final output sent to browser
DEBUG - 2022-06-24 07:15:56 --> Total execution time: 0.0336
INFO - 2022-06-24 07:16:13 --> Config Class Initialized
INFO - 2022-06-24 07:16:13 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:16:13 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:16:13 --> Utf8 Class Initialized
INFO - 2022-06-24 07:16:13 --> URI Class Initialized
INFO - 2022-06-24 07:16:13 --> Router Class Initialized
INFO - 2022-06-24 07:16:13 --> Output Class Initialized
INFO - 2022-06-24 07:16:13 --> Security Class Initialized
DEBUG - 2022-06-24 07:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:16:13 --> Input Class Initialized
INFO - 2022-06-24 07:16:13 --> Language Class Initialized
INFO - 2022-06-24 07:16:13 --> Loader Class Initialized
INFO - 2022-06-24 07:16:13 --> Helper loaded: url_helper
INFO - 2022-06-24 07:16:13 --> Helper loaded: file_helper
INFO - 2022-06-24 07:16:13 --> Database Driver Class Initialized
INFO - 2022-06-24 07:16:13 --> Email Class Initialized
DEBUG - 2022-06-24 07:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:16:13 --> Controller Class Initialized
INFO - 2022-06-24 07:16:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:16:13 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:16:13 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 07:16:13 --> Final output sent to browser
DEBUG - 2022-06-24 07:16:13 --> Total execution time: 0.0328
INFO - 2022-06-24 07:16:28 --> Config Class Initialized
INFO - 2022-06-24 07:16:28 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:16:28 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:16:28 --> Utf8 Class Initialized
INFO - 2022-06-24 07:16:28 --> URI Class Initialized
INFO - 2022-06-24 07:16:28 --> Router Class Initialized
INFO - 2022-06-24 07:16:28 --> Output Class Initialized
INFO - 2022-06-24 07:16:28 --> Config Class Initialized
INFO - 2022-06-24 07:16:28 --> Security Class Initialized
INFO - 2022-06-24 07:16:28 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:16:28 --> Input Class Initialized
DEBUG - 2022-06-24 07:16:28 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:16:28 --> Utf8 Class Initialized
INFO - 2022-06-24 07:16:28 --> Language Class Initialized
INFO - 2022-06-24 07:16:28 --> URI Class Initialized
INFO - 2022-06-24 07:16:28 --> Loader Class Initialized
INFO - 2022-06-24 07:16:28 --> Router Class Initialized
INFO - 2022-06-24 07:16:28 --> Helper loaded: url_helper
INFO - 2022-06-24 07:16:28 --> Output Class Initialized
INFO - 2022-06-24 07:16:28 --> Security Class Initialized
INFO - 2022-06-24 07:16:28 --> Helper loaded: file_helper
DEBUG - 2022-06-24 07:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:16:28 --> Input Class Initialized
INFO - 2022-06-24 07:16:28 --> Database Driver Class Initialized
INFO - 2022-06-24 07:16:28 --> Language Class Initialized
INFO - 2022-06-24 07:16:28 --> Loader Class Initialized
INFO - 2022-06-24 07:16:28 --> Email Class Initialized
INFO - 2022-06-24 07:16:28 --> Helper loaded: url_helper
INFO - 2022-06-24 07:16:28 --> Helper loaded: file_helper
DEBUG - 2022-06-24 07:16:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:16:28 --> Database Driver Class Initialized
INFO - 2022-06-24 07:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:16:28 --> Controller Class Initialized
INFO - 2022-06-24 07:16:28 --> Model "Tokenmodel" initialized
INFO - 2022-06-24 07:16:28 --> Email Class Initialized
DEBUG - 2022-06-24 07:16:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 07:16:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:16:28 --> Controller Class Initialized
INFO - 2022-06-24 07:16:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:16:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:16:28 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 07:16:28 --> Final output sent to browser
DEBUG - 2022-06-24 07:16:28 --> Total execution time: 0.0424
INFO - 2022-06-24 07:17:12 --> Config Class Initialized
INFO - 2022-06-24 07:17:12 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:17:12 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:17:12 --> Utf8 Class Initialized
INFO - 2022-06-24 07:17:12 --> URI Class Initialized
INFO - 2022-06-24 07:17:12 --> Router Class Initialized
INFO - 2022-06-24 07:17:12 --> Output Class Initialized
INFO - 2022-06-24 07:17:12 --> Security Class Initialized
DEBUG - 2022-06-24 07:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:17:12 --> Input Class Initialized
INFO - 2022-06-24 07:17:12 --> Language Class Initialized
INFO - 2022-06-24 07:17:12 --> Loader Class Initialized
INFO - 2022-06-24 07:17:12 --> Helper loaded: url_helper
INFO - 2022-06-24 07:17:12 --> Helper loaded: file_helper
INFO - 2022-06-24 07:17:12 --> Database Driver Class Initialized
INFO - 2022-06-24 07:17:12 --> Email Class Initialized
DEBUG - 2022-06-24 07:17:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:17:12 --> Controller Class Initialized
INFO - 2022-06-24 07:17:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:17:12 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:17:12 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-24 07:17:12 --> Final output sent to browser
DEBUG - 2022-06-24 07:17:12 --> Total execution time: 0.0330
INFO - 2022-06-24 07:17:17 --> Config Class Initialized
INFO - 2022-06-24 07:17:17 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:17:17 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:17:17 --> Utf8 Class Initialized
INFO - 2022-06-24 07:17:17 --> URI Class Initialized
INFO - 2022-06-24 07:17:17 --> Router Class Initialized
INFO - 2022-06-24 07:17:17 --> Output Class Initialized
INFO - 2022-06-24 07:17:17 --> Security Class Initialized
DEBUG - 2022-06-24 07:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:17:17 --> Input Class Initialized
INFO - 2022-06-24 07:17:17 --> Language Class Initialized
INFO - 2022-06-24 07:17:17 --> Loader Class Initialized
INFO - 2022-06-24 07:17:17 --> Helper loaded: url_helper
INFO - 2022-06-24 07:17:17 --> Helper loaded: file_helper
INFO - 2022-06-24 07:17:17 --> Database Driver Class Initialized
INFO - 2022-06-24 07:17:17 --> Email Class Initialized
DEBUG - 2022-06-24 07:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:17:17 --> Controller Class Initialized
INFO - 2022-06-24 07:17:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:17:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:17:17 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-24 07:17:17 --> Final output sent to browser
DEBUG - 2022-06-24 07:17:17 --> Total execution time: 0.0432
INFO - 2022-06-24 07:17:20 --> Config Class Initialized
INFO - 2022-06-24 07:17:20 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:17:20 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:17:20 --> Utf8 Class Initialized
INFO - 2022-06-24 07:17:20 --> URI Class Initialized
INFO - 2022-06-24 07:17:20 --> Router Class Initialized
INFO - 2022-06-24 07:17:20 --> Output Class Initialized
INFO - 2022-06-24 07:17:20 --> Security Class Initialized
DEBUG - 2022-06-24 07:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:17:20 --> Input Class Initialized
INFO - 2022-06-24 07:17:20 --> Language Class Initialized
INFO - 2022-06-24 07:17:20 --> Loader Class Initialized
INFO - 2022-06-24 07:17:20 --> Helper loaded: url_helper
INFO - 2022-06-24 07:17:20 --> Helper loaded: file_helper
INFO - 2022-06-24 07:17:20 --> Database Driver Class Initialized
INFO - 2022-06-24 07:17:20 --> Email Class Initialized
DEBUG - 2022-06-24 07:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:17:20 --> Controller Class Initialized
INFO - 2022-06-24 07:17:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:17:20 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:17:20 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-24 07:17:20 --> Final output sent to browser
DEBUG - 2022-06-24 07:17:20 --> Total execution time: 0.0288
INFO - 2022-06-24 07:19:02 --> Config Class Initialized
INFO - 2022-06-24 07:19:02 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:19:02 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:19:02 --> Utf8 Class Initialized
INFO - 2022-06-24 07:19:02 --> Config Class Initialized
INFO - 2022-06-24 07:19:02 --> URI Class Initialized
INFO - 2022-06-24 07:19:02 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:19:02 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:19:02 --> Router Class Initialized
INFO - 2022-06-24 07:19:02 --> Utf8 Class Initialized
INFO - 2022-06-24 07:19:02 --> Output Class Initialized
INFO - 2022-06-24 07:19:02 --> URI Class Initialized
INFO - 2022-06-24 07:19:02 --> Security Class Initialized
INFO - 2022-06-24 07:19:02 --> Router Class Initialized
DEBUG - 2022-06-24 07:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:19:02 --> Output Class Initialized
INFO - 2022-06-24 07:19:02 --> Input Class Initialized
INFO - 2022-06-24 07:19:02 --> Security Class Initialized
INFO - 2022-06-24 07:19:02 --> Language Class Initialized
DEBUG - 2022-06-24 07:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:19:02 --> Input Class Initialized
INFO - 2022-06-24 07:19:02 --> Loader Class Initialized
INFO - 2022-06-24 07:19:02 --> Language Class Initialized
INFO - 2022-06-24 07:19:02 --> Loader Class Initialized
INFO - 2022-06-24 07:19:02 --> Helper loaded: url_helper
INFO - 2022-06-24 07:19:02 --> Helper loaded: file_helper
INFO - 2022-06-24 07:19:02 --> Helper loaded: url_helper
INFO - 2022-06-24 07:19:02 --> Helper loaded: file_helper
INFO - 2022-06-24 07:19:02 --> Database Driver Class Initialized
INFO - 2022-06-24 07:19:02 --> Database Driver Class Initialized
INFO - 2022-06-24 07:19:02 --> Email Class Initialized
INFO - 2022-06-24 07:19:02 --> Email Class Initialized
DEBUG - 2022-06-24 07:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-24 07:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:19:02 --> Controller Class Initialized
INFO - 2022-06-24 07:19:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:19:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 07:19:02 --> test
INFO - 2022-06-24 07:19:02 --> Final output sent to browser
DEBUG - 2022-06-24 07:19:02 --> Total execution time: 0.0287
INFO - 2022-06-24 07:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:19:02 --> Controller Class Initialized
INFO - 2022-06-24 07:19:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:19:02 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:19:02 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-24 07:19:02 --> Final output sent to browser
DEBUG - 2022-06-24 07:19:02 --> Total execution time: 0.0324
INFO - 2022-06-24 07:19:02 --> Config Class Initialized
INFO - 2022-06-24 07:19:02 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:19:02 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:19:02 --> Utf8 Class Initialized
INFO - 2022-06-24 07:19:02 --> URI Class Initialized
INFO - 2022-06-24 07:19:02 --> Router Class Initialized
INFO - 2022-06-24 07:19:02 --> Output Class Initialized
INFO - 2022-06-24 07:19:02 --> Security Class Initialized
DEBUG - 2022-06-24 07:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:19:02 --> Input Class Initialized
INFO - 2022-06-24 07:19:02 --> Language Class Initialized
INFO - 2022-06-24 07:19:02 --> Loader Class Initialized
INFO - 2022-06-24 07:19:02 --> Helper loaded: url_helper
INFO - 2022-06-24 07:19:02 --> Helper loaded: file_helper
INFO - 2022-06-24 07:19:02 --> Database Driver Class Initialized
INFO - 2022-06-24 07:19:02 --> Email Class Initialized
DEBUG - 2022-06-24 07:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:19:02 --> Controller Class Initialized
INFO - 2022-06-24 07:19:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:19:02 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:19:02 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 07:19:02 --> Final output sent to browser
DEBUG - 2022-06-24 07:19:02 --> Total execution time: 0.0283
INFO - 2022-06-24 07:19:11 --> Config Class Initialized
INFO - 2022-06-24 07:19:11 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:19:11 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:19:11 --> Utf8 Class Initialized
INFO - 2022-06-24 07:19:11 --> URI Class Initialized
INFO - 2022-06-24 07:19:11 --> Router Class Initialized
INFO - 2022-06-24 07:19:11 --> Output Class Initialized
INFO - 2022-06-24 07:19:11 --> Security Class Initialized
DEBUG - 2022-06-24 07:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:19:11 --> Input Class Initialized
INFO - 2022-06-24 07:19:11 --> Language Class Initialized
INFO - 2022-06-24 07:19:11 --> Config Class Initialized
INFO - 2022-06-24 07:19:11 --> Loader Class Initialized
INFO - 2022-06-24 07:19:11 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:19:11 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:19:11 --> Helper loaded: url_helper
INFO - 2022-06-24 07:19:11 --> Utf8 Class Initialized
INFO - 2022-06-24 07:19:11 --> Helper loaded: file_helper
INFO - 2022-06-24 07:19:11 --> URI Class Initialized
INFO - 2022-06-24 07:19:11 --> Database Driver Class Initialized
INFO - 2022-06-24 07:19:11 --> Router Class Initialized
INFO - 2022-06-24 07:19:11 --> Output Class Initialized
INFO - 2022-06-24 07:19:11 --> Security Class Initialized
DEBUG - 2022-06-24 07:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:19:11 --> Email Class Initialized
INFO - 2022-06-24 07:19:11 --> Input Class Initialized
INFO - 2022-06-24 07:19:11 --> Language Class Initialized
DEBUG - 2022-06-24 07:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:19:11 --> Loader Class Initialized
INFO - 2022-06-24 07:19:11 --> Helper loaded: url_helper
INFO - 2022-06-24 07:19:11 --> Helper loaded: file_helper
INFO - 2022-06-24 07:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:19:11 --> Controller Class Initialized
INFO - 2022-06-24 07:19:11 --> Database Driver Class Initialized
INFO - 2022-06-24 07:19:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:19:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:19:11 --> Email Class Initialized
DEBUG - 2022-06-24 07:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:19:11 --> Controller Class Initialized
INFO - 2022-06-24 07:19:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:19:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:19:11 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 07:19:11 --> Final output sent to browser
DEBUG - 2022-06-24 07:19:11 --> Total execution time: 0.0326
INFO - 2022-06-24 07:21:22 --> Config Class Initialized
INFO - 2022-06-24 07:21:22 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:21:22 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:21:22 --> Utf8 Class Initialized
INFO - 2022-06-24 07:21:22 --> URI Class Initialized
INFO - 2022-06-24 07:21:22 --> Router Class Initialized
INFO - 2022-06-24 07:21:22 --> Output Class Initialized
INFO - 2022-06-24 07:21:22 --> Security Class Initialized
DEBUG - 2022-06-24 07:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:21:22 --> Input Class Initialized
INFO - 2022-06-24 07:21:22 --> Language Class Initialized
INFO - 2022-06-24 07:21:22 --> Loader Class Initialized
INFO - 2022-06-24 07:21:22 --> Helper loaded: url_helper
INFO - 2022-06-24 07:21:22 --> Helper loaded: file_helper
INFO - 2022-06-24 07:21:22 --> Database Driver Class Initialized
INFO - 2022-06-24 07:21:22 --> Email Class Initialized
DEBUG - 2022-06-24 07:21:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:21:22 --> Controller Class Initialized
INFO - 2022-06-24 07:21:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:21:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:21:22 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-24 07:21:22 --> Final output sent to browser
DEBUG - 2022-06-24 07:21:22 --> Total execution time: 0.2670
INFO - 2022-06-24 07:21:33 --> Config Class Initialized
INFO - 2022-06-24 07:21:33 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:21:33 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:21:33 --> Utf8 Class Initialized
INFO - 2022-06-24 07:21:33 --> URI Class Initialized
INFO - 2022-06-24 07:21:33 --> Router Class Initialized
INFO - 2022-06-24 07:21:33 --> Output Class Initialized
INFO - 2022-06-24 07:21:33 --> Security Class Initialized
DEBUG - 2022-06-24 07:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:21:33 --> Input Class Initialized
INFO - 2022-06-24 07:21:33 --> Language Class Initialized
INFO - 2022-06-24 07:21:33 --> Loader Class Initialized
INFO - 2022-06-24 07:21:33 --> Helper loaded: url_helper
INFO - 2022-06-24 07:21:33 --> Helper loaded: file_helper
INFO - 2022-06-24 07:21:33 --> Database Driver Class Initialized
INFO - 2022-06-24 07:21:33 --> Email Class Initialized
DEBUG - 2022-06-24 07:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:21:33 --> Controller Class Initialized
INFO - 2022-06-24 07:21:33 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:21:33 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:21:33 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-24 07:21:33 --> Final output sent to browser
DEBUG - 2022-06-24 07:21:33 --> Total execution time: 0.0378
INFO - 2022-06-24 07:21:35 --> Config Class Initialized
INFO - 2022-06-24 07:21:35 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:21:35 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:21:35 --> Utf8 Class Initialized
INFO - 2022-06-24 07:21:35 --> URI Class Initialized
INFO - 2022-06-24 07:21:35 --> Router Class Initialized
INFO - 2022-06-24 07:21:35 --> Output Class Initialized
INFO - 2022-06-24 07:21:35 --> Security Class Initialized
DEBUG - 2022-06-24 07:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:21:35 --> Input Class Initialized
INFO - 2022-06-24 07:21:35 --> Language Class Initialized
INFO - 2022-06-24 07:21:35 --> Loader Class Initialized
INFO - 2022-06-24 07:21:35 --> Helper loaded: url_helper
INFO - 2022-06-24 07:21:35 --> Helper loaded: file_helper
INFO - 2022-06-24 07:21:35 --> Database Driver Class Initialized
INFO - 2022-06-24 07:21:35 --> Email Class Initialized
DEBUG - 2022-06-24 07:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:21:35 --> Controller Class Initialized
INFO - 2022-06-24 07:21:35 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:21:35 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:21:35 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-24 07:21:35 --> Final output sent to browser
DEBUG - 2022-06-24 07:21:35 --> Total execution time: 0.0327
INFO - 2022-06-24 07:21:37 --> Config Class Initialized
INFO - 2022-06-24 07:21:37 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:21:37 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:21:37 --> Utf8 Class Initialized
INFO - 2022-06-24 07:21:37 --> URI Class Initialized
INFO - 2022-06-24 07:21:37 --> Router Class Initialized
INFO - 2022-06-24 07:21:37 --> Output Class Initialized
INFO - 2022-06-24 07:21:37 --> Security Class Initialized
DEBUG - 2022-06-24 07:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:21:37 --> Input Class Initialized
INFO - 2022-06-24 07:21:37 --> Language Class Initialized
INFO - 2022-06-24 07:21:37 --> Loader Class Initialized
INFO - 2022-06-24 07:21:37 --> Helper loaded: url_helper
INFO - 2022-06-24 07:21:37 --> Helper loaded: file_helper
INFO - 2022-06-24 07:21:37 --> Database Driver Class Initialized
INFO - 2022-06-24 07:21:37 --> Email Class Initialized
DEBUG - 2022-06-24 07:21:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:21:37 --> Controller Class Initialized
INFO - 2022-06-24 07:21:37 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:21:37 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:21:37 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-24 07:21:37 --> Final output sent to browser
DEBUG - 2022-06-24 07:21:37 --> Total execution time: 0.0374
INFO - 2022-06-24 07:21:58 --> Config Class Initialized
INFO - 2022-06-24 07:21:58 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:21:58 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:21:58 --> Utf8 Class Initialized
INFO - 2022-06-24 07:21:58 --> URI Class Initialized
INFO - 2022-06-24 07:21:58 --> Router Class Initialized
INFO - 2022-06-24 07:21:58 --> Output Class Initialized
INFO - 2022-06-24 07:21:58 --> Security Class Initialized
DEBUG - 2022-06-24 07:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:21:58 --> Input Class Initialized
INFO - 2022-06-24 07:21:58 --> Language Class Initialized
INFO - 2022-06-24 07:21:58 --> Loader Class Initialized
INFO - 2022-06-24 07:21:58 --> Helper loaded: url_helper
INFO - 2022-06-24 07:21:58 --> Helper loaded: file_helper
INFO - 2022-06-24 07:21:58 --> Database Driver Class Initialized
INFO - 2022-06-24 07:21:58 --> Email Class Initialized
DEBUG - 2022-06-24 07:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:21:58 --> Controller Class Initialized
INFO - 2022-06-24 07:21:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:21:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:21:58 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-24 07:21:58 --> Final output sent to browser
DEBUG - 2022-06-24 07:21:58 --> Total execution time: 0.0484
INFO - 2022-06-24 07:22:01 --> Config Class Initialized
INFO - 2022-06-24 07:22:01 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:22:01 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:22:01 --> Utf8 Class Initialized
INFO - 2022-06-24 07:22:01 --> URI Class Initialized
INFO - 2022-06-24 07:22:01 --> Router Class Initialized
INFO - 2022-06-24 07:22:01 --> Output Class Initialized
INFO - 2022-06-24 07:22:01 --> Security Class Initialized
DEBUG - 2022-06-24 07:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:22:01 --> Input Class Initialized
INFO - 2022-06-24 07:22:01 --> Language Class Initialized
INFO - 2022-06-24 07:22:01 --> Loader Class Initialized
INFO - 2022-06-24 07:22:01 --> Helper loaded: url_helper
INFO - 2022-06-24 07:22:01 --> Helper loaded: file_helper
INFO - 2022-06-24 07:22:01 --> Database Driver Class Initialized
INFO - 2022-06-24 07:22:01 --> Email Class Initialized
DEBUG - 2022-06-24 07:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:22:01 --> Controller Class Initialized
INFO - 2022-06-24 07:22:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:22:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:22:01 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-24 07:22:01 --> Final output sent to browser
DEBUG - 2022-06-24 07:22:01 --> Total execution time: 0.0321
INFO - 2022-06-24 07:25:56 --> Config Class Initialized
INFO - 2022-06-24 07:25:56 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:25:56 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:25:56 --> Utf8 Class Initialized
INFO - 2022-06-24 07:25:56 --> URI Class Initialized
INFO - 2022-06-24 07:25:56 --> Router Class Initialized
INFO - 2022-06-24 07:25:56 --> Output Class Initialized
INFO - 2022-06-24 07:25:56 --> Security Class Initialized
DEBUG - 2022-06-24 07:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:25:56 --> Input Class Initialized
INFO - 2022-06-24 07:25:56 --> Language Class Initialized
INFO - 2022-06-24 07:25:56 --> Loader Class Initialized
INFO - 2022-06-24 07:25:56 --> Helper loaded: url_helper
INFO - 2022-06-24 07:25:56 --> Helper loaded: file_helper
INFO - 2022-06-24 07:25:56 --> Database Driver Class Initialized
INFO - 2022-06-24 07:25:56 --> Email Class Initialized
DEBUG - 2022-06-24 07:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:25:56 --> Controller Class Initialized
INFO - 2022-06-24 07:25:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:25:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:25:56 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-24 07:25:56 --> Final output sent to browser
DEBUG - 2022-06-24 07:25:56 --> Total execution time: 0.0395
INFO - 2022-06-24 07:26:08 --> Config Class Initialized
INFO - 2022-06-24 07:26:08 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:26:08 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:26:08 --> Utf8 Class Initialized
INFO - 2022-06-24 07:26:08 --> URI Class Initialized
INFO - 2022-06-24 07:26:08 --> Router Class Initialized
INFO - 2022-06-24 07:26:08 --> Output Class Initialized
INFO - 2022-06-24 07:26:08 --> Security Class Initialized
DEBUG - 2022-06-24 07:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:26:08 --> Input Class Initialized
INFO - 2022-06-24 07:26:08 --> Language Class Initialized
INFO - 2022-06-24 07:26:09 --> Loader Class Initialized
INFO - 2022-06-24 07:26:09 --> Helper loaded: url_helper
INFO - 2022-06-24 07:26:09 --> Helper loaded: file_helper
INFO - 2022-06-24 07:26:09 --> Database Driver Class Initialized
INFO - 2022-06-24 07:26:09 --> Email Class Initialized
DEBUG - 2022-06-24 07:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:26:09 --> Controller Class Initialized
INFO - 2022-06-24 07:26:09 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:26:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 07:26:09 --> test
INFO - 2022-06-24 07:26:09 --> Final output sent to browser
DEBUG - 2022-06-24 07:26:09 --> Total execution time: 0.0424
INFO - 2022-06-24 07:26:09 --> Config Class Initialized
INFO - 2022-06-24 07:26:09 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:26:09 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:26:09 --> Utf8 Class Initialized
INFO - 2022-06-24 07:26:09 --> URI Class Initialized
INFO - 2022-06-24 07:26:09 --> Router Class Initialized
INFO - 2022-06-24 07:26:09 --> Output Class Initialized
INFO - 2022-06-24 07:26:09 --> Security Class Initialized
DEBUG - 2022-06-24 07:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:26:09 --> Input Class Initialized
INFO - 2022-06-24 07:26:09 --> Language Class Initialized
INFO - 2022-06-24 07:26:09 --> Loader Class Initialized
INFO - 2022-06-24 07:26:09 --> Helper loaded: url_helper
INFO - 2022-06-24 07:26:09 --> Helper loaded: file_helper
INFO - 2022-06-24 07:26:09 --> Database Driver Class Initialized
INFO - 2022-06-24 07:26:09 --> Config Class Initialized
INFO - 2022-06-24 07:26:09 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:26:09 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:26:09 --> Utf8 Class Initialized
INFO - 2022-06-24 07:26:09 --> URI Class Initialized
INFO - 2022-06-24 07:26:09 --> Router Class Initialized
INFO - 2022-06-24 07:26:09 --> Output Class Initialized
INFO - 2022-06-24 07:26:09 --> Email Class Initialized
INFO - 2022-06-24 07:26:09 --> Security Class Initialized
DEBUG - 2022-06-24 07:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:26:09 --> Input Class Initialized
DEBUG - 2022-06-24 07:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:26:09 --> Language Class Initialized
INFO - 2022-06-24 07:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:26:09 --> Loader Class Initialized
INFO - 2022-06-24 07:26:09 --> Controller Class Initialized
INFO - 2022-06-24 07:26:09 --> Helper loaded: url_helper
INFO - 2022-06-24 07:26:09 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:26:09 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:26:09 --> Helper loaded: file_helper
INFO - 2022-06-24 07:26:09 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-24 07:26:09 --> Database Driver Class Initialized
INFO - 2022-06-24 07:26:09 --> Final output sent to browser
DEBUG - 2022-06-24 07:26:09 --> Total execution time: 0.0406
INFO - 2022-06-24 07:26:09 --> Email Class Initialized
DEBUG - 2022-06-24 07:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:26:09 --> Controller Class Initialized
INFO - 2022-06-24 07:26:09 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:26:09 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:26:09 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 07:26:09 --> Final output sent to browser
DEBUG - 2022-06-24 07:26:09 --> Total execution time: 0.0309
INFO - 2022-06-24 07:26:19 --> Config Class Initialized
INFO - 2022-06-24 07:26:19 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:26:19 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:26:19 --> Utf8 Class Initialized
INFO - 2022-06-24 07:26:19 --> URI Class Initialized
INFO - 2022-06-24 07:26:19 --> Router Class Initialized
INFO - 2022-06-24 07:26:19 --> Output Class Initialized
INFO - 2022-06-24 07:26:19 --> Security Class Initialized
DEBUG - 2022-06-24 07:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:26:19 --> Input Class Initialized
INFO - 2022-06-24 07:26:19 --> Language Class Initialized
INFO - 2022-06-24 07:26:19 --> Loader Class Initialized
INFO - 2022-06-24 07:26:19 --> Helper loaded: url_helper
INFO - 2022-06-24 07:26:19 --> Helper loaded: file_helper
INFO - 2022-06-24 07:26:19 --> Database Driver Class Initialized
INFO - 2022-06-24 07:26:19 --> Email Class Initialized
DEBUG - 2022-06-24 07:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:26:19 --> Config Class Initialized
INFO - 2022-06-24 07:26:19 --> Controller Class Initialized
INFO - 2022-06-24 07:26:19 --> Hooks Class Initialized
INFO - 2022-06-24 07:26:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:26:19 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:26:19 --> Utf8 Class Initialized
DEBUG - 2022-06-24 07:26:19 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:26:19 --> URI Class Initialized
INFO - 2022-06-24 07:26:19 --> Router Class Initialized
INFO - 2022-06-24 07:26:19 --> Output Class Initialized
INFO - 2022-06-24 07:26:19 --> Security Class Initialized
DEBUG - 2022-06-24 07:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:26:19 --> Input Class Initialized
INFO - 2022-06-24 07:26:19 --> Language Class Initialized
INFO - 2022-06-24 07:26:19 --> Loader Class Initialized
INFO - 2022-06-24 07:26:19 --> Helper loaded: url_helper
INFO - 2022-06-24 07:26:19 --> Helper loaded: file_helper
INFO - 2022-06-24 07:26:19 --> Database Driver Class Initialized
INFO - 2022-06-24 07:26:19 --> Email Class Initialized
DEBUG - 2022-06-24 07:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:26:19 --> Controller Class Initialized
INFO - 2022-06-24 07:26:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:26:19 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:26:19 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 07:26:19 --> Final output sent to browser
DEBUG - 2022-06-24 07:26:19 --> Total execution time: 0.0365
INFO - 2022-06-24 07:26:30 --> Config Class Initialized
INFO - 2022-06-24 07:26:30 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:26:30 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:26:30 --> Utf8 Class Initialized
INFO - 2022-06-24 07:26:30 --> URI Class Initialized
INFO - 2022-06-24 07:26:30 --> Router Class Initialized
INFO - 2022-06-24 07:26:30 --> Output Class Initialized
INFO - 2022-06-24 07:26:30 --> Security Class Initialized
DEBUG - 2022-06-24 07:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:26:30 --> Input Class Initialized
INFO - 2022-06-24 07:26:30 --> Language Class Initialized
INFO - 2022-06-24 07:26:30 --> Loader Class Initialized
INFO - 2022-06-24 07:26:30 --> Helper loaded: url_helper
INFO - 2022-06-24 07:26:30 --> Helper loaded: file_helper
INFO - 2022-06-24 07:26:30 --> Database Driver Class Initialized
INFO - 2022-06-24 07:26:30 --> Email Class Initialized
DEBUG - 2022-06-24 07:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:26:30 --> Controller Class Initialized
INFO - 2022-06-24 07:26:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:26:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:26:30 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-24 07:26:30 --> Final output sent to browser
DEBUG - 2022-06-24 07:26:30 --> Total execution time: 0.0320
INFO - 2022-06-24 07:26:48 --> Config Class Initialized
INFO - 2022-06-24 07:26:48 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:26:48 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:26:48 --> Utf8 Class Initialized
INFO - 2022-06-24 07:26:48 --> URI Class Initialized
INFO - 2022-06-24 07:26:48 --> Config Class Initialized
INFO - 2022-06-24 07:26:48 --> Router Class Initialized
INFO - 2022-06-24 07:26:48 --> Output Class Initialized
INFO - 2022-06-24 07:26:48 --> Security Class Initialized
DEBUG - 2022-06-24 07:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:26:48 --> Input Class Initialized
INFO - 2022-06-24 07:26:48 --> Language Class Initialized
INFO - 2022-06-24 07:26:48 --> Loader Class Initialized
INFO - 2022-06-24 07:26:48 --> Helper loaded: url_helper
INFO - 2022-06-24 07:26:48 --> Helper loaded: file_helper
INFO - 2022-06-24 07:26:48 --> Database Driver Class Initialized
INFO - 2022-06-24 07:26:48 --> Email Class Initialized
DEBUG - 2022-06-24 07:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:26:48 --> Controller Class Initialized
INFO - 2022-06-24 07:26:48 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:26:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 07:26:48 --> test
INFO - 2022-06-24 07:26:48 --> Hooks Class Initialized
INFO - 2022-06-24 07:26:48 --> Final output sent to browser
DEBUG - 2022-06-24 07:26:48 --> Total execution time: 0.0340
DEBUG - 2022-06-24 07:26:48 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:26:48 --> Utf8 Class Initialized
INFO - 2022-06-24 07:26:48 --> URI Class Initialized
INFO - 2022-06-24 07:26:48 --> Router Class Initialized
INFO - 2022-06-24 07:26:48 --> Output Class Initialized
INFO - 2022-06-24 07:26:48 --> Security Class Initialized
DEBUG - 2022-06-24 07:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:26:48 --> Input Class Initialized
INFO - 2022-06-24 07:26:48 --> Language Class Initialized
INFO - 2022-06-24 07:26:48 --> Loader Class Initialized
INFO - 2022-06-24 07:26:48 --> Helper loaded: url_helper
INFO - 2022-06-24 07:26:48 --> Helper loaded: file_helper
INFO - 2022-06-24 07:26:48 --> Database Driver Class Initialized
INFO - 2022-06-24 07:26:48 --> Email Class Initialized
DEBUG - 2022-06-24 07:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:26:48 --> Config Class Initialized
INFO - 2022-06-24 07:26:48 --> Hooks Class Initialized
INFO - 2022-06-24 07:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:26:48 --> Controller Class Initialized
DEBUG - 2022-06-24 07:26:48 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:26:48 --> Model "Tokenmodel" initialized
INFO - 2022-06-24 07:26:48 --> Utf8 Class Initialized
DEBUG - 2022-06-24 07:26:48 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:26:48 --> URI Class Initialized
INFO - 2022-06-24 07:26:48 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-24 07:26:48 --> Router Class Initialized
INFO - 2022-06-24 07:26:48 --> Final output sent to browser
DEBUG - 2022-06-24 07:26:48 --> Total execution time: 0.0574
INFO - 2022-06-24 07:26:48 --> Output Class Initialized
INFO - 2022-06-24 07:26:48 --> Security Class Initialized
DEBUG - 2022-06-24 07:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:26:48 --> Input Class Initialized
INFO - 2022-06-24 07:26:48 --> Language Class Initialized
INFO - 2022-06-24 07:26:48 --> Loader Class Initialized
INFO - 2022-06-24 07:26:48 --> Helper loaded: url_helper
INFO - 2022-06-24 07:26:48 --> Helper loaded: file_helper
INFO - 2022-06-24 07:26:48 --> Database Driver Class Initialized
INFO - 2022-06-24 07:26:48 --> Email Class Initialized
DEBUG - 2022-06-24 07:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:26:48 --> Controller Class Initialized
INFO - 2022-06-24 07:26:48 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:26:48 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:26:48 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 07:26:48 --> Final output sent to browser
DEBUG - 2022-06-24 07:26:48 --> Total execution time: 0.0276
INFO - 2022-06-24 07:26:56 --> Config Class Initialized
INFO - 2022-06-24 07:26:56 --> Hooks Class Initialized
DEBUG - 2022-06-24 07:26:56 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:26:56 --> Utf8 Class Initialized
INFO - 2022-06-24 07:26:56 --> URI Class Initialized
INFO - 2022-06-24 07:26:56 --> Router Class Initialized
INFO - 2022-06-24 07:26:56 --> Output Class Initialized
INFO - 2022-06-24 07:26:56 --> Security Class Initialized
DEBUG - 2022-06-24 07:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:26:56 --> Input Class Initialized
INFO - 2022-06-24 07:26:56 --> Config Class Initialized
INFO - 2022-06-24 07:26:56 --> Hooks Class Initialized
INFO - 2022-06-24 07:26:56 --> Language Class Initialized
DEBUG - 2022-06-24 07:26:56 --> UTF-8 Support Enabled
INFO - 2022-06-24 07:26:56 --> Loader Class Initialized
INFO - 2022-06-24 07:26:56 --> Utf8 Class Initialized
INFO - 2022-06-24 07:26:56 --> URI Class Initialized
INFO - 2022-06-24 07:26:56 --> Helper loaded: url_helper
INFO - 2022-06-24 07:26:56 --> Helper loaded: file_helper
INFO - 2022-06-24 07:26:56 --> Router Class Initialized
INFO - 2022-06-24 07:26:56 --> Output Class Initialized
INFO - 2022-06-24 07:26:56 --> Database Driver Class Initialized
INFO - 2022-06-24 07:26:56 --> Security Class Initialized
DEBUG - 2022-06-24 07:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 07:26:56 --> Input Class Initialized
INFO - 2022-06-24 07:26:56 --> Email Class Initialized
INFO - 2022-06-24 07:26:56 --> Language Class Initialized
INFO - 2022-06-24 07:26:56 --> Loader Class Initialized
DEBUG - 2022-06-24 07:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:26:56 --> Helper loaded: url_helper
INFO - 2022-06-24 07:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:26:56 --> Helper loaded: file_helper
INFO - 2022-06-24 07:26:56 --> Controller Class Initialized
INFO - 2022-06-24 07:26:56 --> Database Driver Class Initialized
INFO - 2022-06-24 07:26:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:26:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:26:56 --> Email Class Initialized
DEBUG - 2022-06-24 07:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 07:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 07:26:56 --> Controller Class Initialized
INFO - 2022-06-24 07:26:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 07:26:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 07:26:56 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 07:26:56 --> Final output sent to browser
DEBUG - 2022-06-24 07:26:56 --> Total execution time: 0.0414
INFO - 2022-06-24 09:47:08 --> Config Class Initialized
INFO - 2022-06-24 09:47:08 --> Hooks Class Initialized
DEBUG - 2022-06-24 09:47:08 --> UTF-8 Support Enabled
INFO - 2022-06-24 09:47:08 --> Utf8 Class Initialized
INFO - 2022-06-24 09:47:08 --> URI Class Initialized
INFO - 2022-06-24 09:47:08 --> Router Class Initialized
INFO - 2022-06-24 09:47:08 --> Output Class Initialized
INFO - 2022-06-24 09:47:08 --> Security Class Initialized
DEBUG - 2022-06-24 09:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 09:47:08 --> Input Class Initialized
INFO - 2022-06-24 09:47:08 --> Language Class Initialized
INFO - 2022-06-24 09:47:08 --> Loader Class Initialized
INFO - 2022-06-24 09:47:08 --> Helper loaded: url_helper
INFO - 2022-06-24 09:47:08 --> Helper loaded: file_helper
INFO - 2022-06-24 09:47:08 --> Database Driver Class Initialized
INFO - 2022-06-24 09:47:08 --> Email Class Initialized
DEBUG - 2022-06-24 09:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 09:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 09:47:08 --> Controller Class Initialized
INFO - 2022-06-24 09:47:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 09:47:08 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 09:47:08 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 09:47:08 --> Final output sent to browser
DEBUG - 2022-06-24 09:47:08 --> Total execution time: 0.1820
INFO - 2022-06-24 09:47:28 --> Config Class Initialized
INFO - 2022-06-24 09:47:28 --> Hooks Class Initialized
DEBUG - 2022-06-24 09:47:28 --> UTF-8 Support Enabled
INFO - 2022-06-24 09:47:28 --> Utf8 Class Initialized
INFO - 2022-06-24 09:47:28 --> URI Class Initialized
INFO - 2022-06-24 09:47:28 --> Router Class Initialized
INFO - 2022-06-24 09:47:28 --> Output Class Initialized
INFO - 2022-06-24 09:47:28 --> Security Class Initialized
DEBUG - 2022-06-24 09:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 09:47:28 --> Input Class Initialized
INFO - 2022-06-24 09:47:28 --> Language Class Initialized
INFO - 2022-06-24 09:47:28 --> Loader Class Initialized
INFO - 2022-06-24 09:47:28 --> Helper loaded: url_helper
INFO - 2022-06-24 09:47:28 --> Helper loaded: file_helper
INFO - 2022-06-24 09:47:28 --> Database Driver Class Initialized
INFO - 2022-06-24 09:47:28 --> Email Class Initialized
DEBUG - 2022-06-24 09:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 09:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 09:47:28 --> Controller Class Initialized
INFO - 2022-06-24 09:47:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 09:47:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-24 09:47:28 --> Severity: Notice --> Undefined variable: tetch C:\wamp64\www\qr\application\controllers\Tokenctrl.php 34
ERROR - 2022-06-24 09:47:28 --> Severity: error --> Exception: Call to undefined function alert() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 36
INFO - 2022-06-24 09:47:28 --> Config Class Initialized
INFO - 2022-06-24 09:47:28 --> Hooks Class Initialized
DEBUG - 2022-06-24 09:47:28 --> UTF-8 Support Enabled
INFO - 2022-06-24 09:47:28 --> Utf8 Class Initialized
INFO - 2022-06-24 09:47:28 --> URI Class Initialized
INFO - 2022-06-24 09:47:28 --> Router Class Initialized
INFO - 2022-06-24 09:47:28 --> Output Class Initialized
INFO - 2022-06-24 09:47:28 --> Security Class Initialized
DEBUG - 2022-06-24 09:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 09:47:28 --> Input Class Initialized
INFO - 2022-06-24 09:47:28 --> Language Class Initialized
INFO - 2022-06-24 09:47:28 --> Loader Class Initialized
INFO - 2022-06-24 09:47:28 --> Helper loaded: url_helper
INFO - 2022-06-24 09:47:28 --> Helper loaded: file_helper
INFO - 2022-06-24 09:47:28 --> Database Driver Class Initialized
INFO - 2022-06-24 09:47:28 --> Email Class Initialized
DEBUG - 2022-06-24 09:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 09:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 09:47:28 --> Controller Class Initialized
INFO - 2022-06-24 09:47:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 09:47:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 09:47:28 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 09:47:28 --> Final output sent to browser
DEBUG - 2022-06-24 09:47:28 --> Total execution time: 0.1116
INFO - 2022-06-24 09:47:36 --> Config Class Initialized
INFO - 2022-06-24 09:47:36 --> Hooks Class Initialized
DEBUG - 2022-06-24 09:47:36 --> UTF-8 Support Enabled
INFO - 2022-06-24 09:47:36 --> Utf8 Class Initialized
INFO - 2022-06-24 09:47:36 --> URI Class Initialized
INFO - 2022-06-24 09:47:36 --> Router Class Initialized
INFO - 2022-06-24 09:47:36 --> Output Class Initialized
INFO - 2022-06-24 09:47:36 --> Security Class Initialized
DEBUG - 2022-06-24 09:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 09:47:36 --> Input Class Initialized
INFO - 2022-06-24 09:47:36 --> Language Class Initialized
INFO - 2022-06-24 09:47:36 --> Loader Class Initialized
INFO - 2022-06-24 09:47:36 --> Helper loaded: url_helper
INFO - 2022-06-24 09:47:36 --> Helper loaded: file_helper
INFO - 2022-06-24 09:47:36 --> Database Driver Class Initialized
INFO - 2022-06-24 09:47:36 --> Email Class Initialized
DEBUG - 2022-06-24 09:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 09:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 09:47:36 --> Controller Class Initialized
INFO - 2022-06-24 09:47:36 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 09:47:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-24 09:47:37 --> Severity: Notice --> Undefined variable: tetch C:\wamp64\www\qr\application\controllers\Tokenctrl.php 34
ERROR - 2022-06-24 09:47:37 --> Severity: error --> Exception: Call to undefined function alert() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 36
INFO - 2022-06-24 09:48:26 --> Config Class Initialized
INFO - 2022-06-24 09:48:26 --> Hooks Class Initialized
DEBUG - 2022-06-24 09:48:26 --> UTF-8 Support Enabled
INFO - 2022-06-24 09:48:26 --> Utf8 Class Initialized
INFO - 2022-06-24 09:48:26 --> URI Class Initialized
INFO - 2022-06-24 09:48:26 --> Router Class Initialized
INFO - 2022-06-24 09:48:26 --> Output Class Initialized
INFO - 2022-06-24 09:48:26 --> Security Class Initialized
DEBUG - 2022-06-24 09:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 09:48:26 --> Input Class Initialized
INFO - 2022-06-24 09:48:26 --> Language Class Initialized
INFO - 2022-06-24 09:48:26 --> Loader Class Initialized
INFO - 2022-06-24 09:48:26 --> Helper loaded: url_helper
INFO - 2022-06-24 09:48:26 --> Helper loaded: file_helper
INFO - 2022-06-24 09:48:26 --> Database Driver Class Initialized
INFO - 2022-06-24 09:48:26 --> Email Class Initialized
DEBUG - 2022-06-24 09:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 09:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 09:48:26 --> Controller Class Initialized
INFO - 2022-06-24 09:48:26 --> Config Class Initialized
INFO - 2022-06-24 09:48:26 --> Model "Tokenmodel" initialized
INFO - 2022-06-24 09:48:26 --> Hooks Class Initialized
DEBUG - 2022-06-24 09:48:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 09:48:26 --> UTF-8 Support Enabled
ERROR - 2022-06-24 09:48:26 --> Severity: error --> Exception: Call to undefined function alert() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 41
INFO - 2022-06-24 09:48:26 --> Utf8 Class Initialized
INFO - 2022-06-24 09:48:26 --> URI Class Initialized
INFO - 2022-06-24 09:48:26 --> Router Class Initialized
INFO - 2022-06-24 09:48:26 --> Output Class Initialized
INFO - 2022-06-24 09:48:26 --> Security Class Initialized
DEBUG - 2022-06-24 09:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 09:48:26 --> Input Class Initialized
INFO - 2022-06-24 09:48:26 --> Language Class Initialized
INFO - 2022-06-24 09:48:26 --> Loader Class Initialized
INFO - 2022-06-24 09:48:26 --> Helper loaded: url_helper
INFO - 2022-06-24 09:48:26 --> Helper loaded: file_helper
INFO - 2022-06-24 09:48:26 --> Database Driver Class Initialized
INFO - 2022-06-24 09:48:26 --> Email Class Initialized
DEBUG - 2022-06-24 09:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 09:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 09:48:26 --> Controller Class Initialized
INFO - 2022-06-24 09:48:26 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 09:48:26 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 09:48:26 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 09:48:26 --> Final output sent to browser
DEBUG - 2022-06-24 09:48:26 --> Total execution time: 0.0522
INFO - 2022-06-24 09:48:29 --> Config Class Initialized
INFO - 2022-06-24 09:48:29 --> Hooks Class Initialized
DEBUG - 2022-06-24 09:48:29 --> UTF-8 Support Enabled
INFO - 2022-06-24 09:48:29 --> Utf8 Class Initialized
INFO - 2022-06-24 09:48:29 --> URI Class Initialized
INFO - 2022-06-24 09:48:29 --> Router Class Initialized
INFO - 2022-06-24 09:48:29 --> Output Class Initialized
INFO - 2022-06-24 09:48:29 --> Security Class Initialized
DEBUG - 2022-06-24 09:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 09:48:29 --> Input Class Initialized
INFO - 2022-06-24 09:48:29 --> Language Class Initialized
INFO - 2022-06-24 09:48:29 --> Loader Class Initialized
INFO - 2022-06-24 09:48:29 --> Helper loaded: url_helper
INFO - 2022-06-24 09:48:29 --> Helper loaded: file_helper
INFO - 2022-06-24 09:48:29 --> Database Driver Class Initialized
INFO - 2022-06-24 09:48:30 --> Email Class Initialized
DEBUG - 2022-06-24 09:48:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 09:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 09:48:30 --> Controller Class Initialized
INFO - 2022-06-24 09:48:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 09:48:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-24 09:48:30 --> Severity: error --> Exception: Call to undefined function alert() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 41
INFO - 2022-06-24 09:51:45 --> Config Class Initialized
INFO - 2022-06-24 09:51:45 --> Hooks Class Initialized
DEBUG - 2022-06-24 09:51:45 --> UTF-8 Support Enabled
INFO - 2022-06-24 09:51:45 --> Utf8 Class Initialized
INFO - 2022-06-24 09:51:45 --> URI Class Initialized
INFO - 2022-06-24 09:51:45 --> Router Class Initialized
INFO - 2022-06-24 09:51:45 --> Output Class Initialized
INFO - 2022-06-24 09:51:45 --> Security Class Initialized
DEBUG - 2022-06-24 09:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 09:51:45 --> Input Class Initialized
INFO - 2022-06-24 09:51:45 --> Language Class Initialized
INFO - 2022-06-24 09:51:45 --> Loader Class Initialized
INFO - 2022-06-24 09:51:45 --> Helper loaded: url_helper
INFO - 2022-06-24 09:51:45 --> Helper loaded: file_helper
INFO - 2022-06-24 09:51:45 --> Database Driver Class Initialized
INFO - 2022-06-24 09:51:45 --> Email Class Initialized
DEBUG - 2022-06-24 09:51:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 09:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 09:51:45 --> Controller Class Initialized
INFO - 2022-06-24 09:51:45 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 09:51:45 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 09:51:45 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 09:51:45 --> Final output sent to browser
DEBUG - 2022-06-24 09:51:45 --> Total execution time: 0.1281
INFO - 2022-06-24 09:51:54 --> Config Class Initialized
INFO - 2022-06-24 09:51:54 --> Hooks Class Initialized
DEBUG - 2022-06-24 09:51:54 --> UTF-8 Support Enabled
INFO - 2022-06-24 09:51:54 --> Utf8 Class Initialized
INFO - 2022-06-24 09:51:54 --> URI Class Initialized
INFO - 2022-06-24 09:51:54 --> Router Class Initialized
INFO - 2022-06-24 09:51:54 --> Output Class Initialized
INFO - 2022-06-24 09:51:54 --> Security Class Initialized
DEBUG - 2022-06-24 09:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 09:51:54 --> Input Class Initialized
INFO - 2022-06-24 09:51:54 --> Language Class Initialized
INFO - 2022-06-24 09:51:54 --> Loader Class Initialized
INFO - 2022-06-24 09:51:54 --> Helper loaded: url_helper
INFO - 2022-06-24 09:51:54 --> Helper loaded: file_helper
INFO - 2022-06-24 09:51:54 --> Database Driver Class Initialized
INFO - 2022-06-24 09:51:54 --> Email Class Initialized
DEBUG - 2022-06-24 09:51:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 09:51:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 09:51:54 --> Controller Class Initialized
INFO - 2022-06-24 09:51:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 09:51:54 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 09:51:54 --> Final output sent to browser
DEBUG - 2022-06-24 09:51:54 --> Total execution time: 0.0545
INFO - 2022-06-24 09:51:55 --> Config Class Initialized
INFO - 2022-06-24 09:51:55 --> Hooks Class Initialized
DEBUG - 2022-06-24 09:51:55 --> UTF-8 Support Enabled
INFO - 2022-06-24 09:51:55 --> Utf8 Class Initialized
INFO - 2022-06-24 09:51:55 --> URI Class Initialized
INFO - 2022-06-24 09:51:55 --> Router Class Initialized
INFO - 2022-06-24 09:51:55 --> Output Class Initialized
INFO - 2022-06-24 09:51:55 --> Security Class Initialized
DEBUG - 2022-06-24 09:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 09:51:55 --> Input Class Initialized
INFO - 2022-06-24 09:51:55 --> Language Class Initialized
INFO - 2022-06-24 09:51:55 --> Loader Class Initialized
INFO - 2022-06-24 09:51:55 --> Helper loaded: url_helper
INFO - 2022-06-24 09:51:55 --> Helper loaded: file_helper
INFO - 2022-06-24 09:51:55 --> Database Driver Class Initialized
INFO - 2022-06-24 09:51:55 --> Email Class Initialized
DEBUG - 2022-06-24 09:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 09:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 09:51:55 --> Controller Class Initialized
INFO - 2022-06-24 09:51:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 09:51:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 09:51:55 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 09:51:55 --> Final output sent to browser
DEBUG - 2022-06-24 09:51:55 --> Total execution time: 0.0291
INFO - 2022-06-24 09:57:48 --> Config Class Initialized
INFO - 2022-06-24 09:57:48 --> Hooks Class Initialized
DEBUG - 2022-06-24 09:57:48 --> UTF-8 Support Enabled
INFO - 2022-06-24 09:57:48 --> Utf8 Class Initialized
INFO - 2022-06-24 09:57:48 --> URI Class Initialized
INFO - 2022-06-24 09:57:48 --> Router Class Initialized
INFO - 2022-06-24 09:57:48 --> Output Class Initialized
INFO - 2022-06-24 09:57:48 --> Security Class Initialized
DEBUG - 2022-06-24 09:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 09:57:48 --> Input Class Initialized
INFO - 2022-06-24 09:57:48 --> Language Class Initialized
INFO - 2022-06-24 09:57:48 --> Loader Class Initialized
INFO - 2022-06-24 09:57:48 --> Helper loaded: url_helper
INFO - 2022-06-24 09:57:48 --> Helper loaded: file_helper
INFO - 2022-06-24 09:57:48 --> Database Driver Class Initialized
INFO - 2022-06-24 09:57:48 --> Email Class Initialized
DEBUG - 2022-06-24 09:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 09:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 09:57:48 --> Controller Class Initialized
INFO - 2022-06-24 09:57:48 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 09:57:48 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 09:57:48 --> Final output sent to browser
DEBUG - 2022-06-24 09:57:48 --> Total execution time: 0.0323
INFO - 2022-06-24 09:58:13 --> Config Class Initialized
INFO - 2022-06-24 09:58:13 --> Hooks Class Initialized
DEBUG - 2022-06-24 09:58:13 --> UTF-8 Support Enabled
INFO - 2022-06-24 09:58:13 --> Utf8 Class Initialized
INFO - 2022-06-24 09:58:13 --> URI Class Initialized
INFO - 2022-06-24 09:58:13 --> Router Class Initialized
INFO - 2022-06-24 09:58:13 --> Output Class Initialized
INFO - 2022-06-24 09:58:13 --> Security Class Initialized
DEBUG - 2022-06-24 09:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 09:58:13 --> Input Class Initialized
INFO - 2022-06-24 09:58:13 --> Language Class Initialized
INFO - 2022-06-24 09:58:13 --> Loader Class Initialized
INFO - 2022-06-24 09:58:13 --> Helper loaded: url_helper
INFO - 2022-06-24 09:58:13 --> Helper loaded: file_helper
INFO - 2022-06-24 09:58:13 --> Database Driver Class Initialized
INFO - 2022-06-24 09:58:13 --> Email Class Initialized
DEBUG - 2022-06-24 09:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 09:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 09:58:13 --> Controller Class Initialized
INFO - 2022-06-24 09:58:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 09:58:13 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 09:58:13 --> Final output sent to browser
DEBUG - 2022-06-24 09:58:13 --> Total execution time: 0.0344
INFO - 2022-06-24 09:58:14 --> Config Class Initialized
INFO - 2022-06-24 09:58:14 --> Hooks Class Initialized
DEBUG - 2022-06-24 09:58:14 --> UTF-8 Support Enabled
INFO - 2022-06-24 09:58:14 --> Utf8 Class Initialized
INFO - 2022-06-24 09:58:14 --> URI Class Initialized
INFO - 2022-06-24 09:58:14 --> Router Class Initialized
INFO - 2022-06-24 09:58:14 --> Output Class Initialized
INFO - 2022-06-24 09:58:14 --> Security Class Initialized
DEBUG - 2022-06-24 09:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 09:58:14 --> Input Class Initialized
INFO - 2022-06-24 09:58:14 --> Language Class Initialized
INFO - 2022-06-24 09:58:14 --> Loader Class Initialized
INFO - 2022-06-24 09:58:14 --> Helper loaded: url_helper
INFO - 2022-06-24 09:58:14 --> Helper loaded: file_helper
INFO - 2022-06-24 09:58:14 --> Database Driver Class Initialized
INFO - 2022-06-24 09:58:14 --> Email Class Initialized
DEBUG - 2022-06-24 09:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 09:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 09:58:14 --> Controller Class Initialized
INFO - 2022-06-24 09:58:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 09:58:14 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 09:58:14 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 09:58:14 --> Final output sent to browser
DEBUG - 2022-06-24 09:58:14 --> Total execution time: 0.3228
INFO - 2022-06-24 09:58:19 --> Config Class Initialized
INFO - 2022-06-24 09:58:19 --> Hooks Class Initialized
DEBUG - 2022-06-24 09:58:19 --> UTF-8 Support Enabled
INFO - 2022-06-24 09:58:19 --> Utf8 Class Initialized
INFO - 2022-06-24 09:58:19 --> URI Class Initialized
INFO - 2022-06-24 09:58:19 --> Router Class Initialized
INFO - 2022-06-24 09:58:19 --> Output Class Initialized
INFO - 2022-06-24 09:58:19 --> Security Class Initialized
DEBUG - 2022-06-24 09:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 09:58:19 --> Input Class Initialized
INFO - 2022-06-24 09:58:19 --> Language Class Initialized
INFO - 2022-06-24 09:58:19 --> Loader Class Initialized
INFO - 2022-06-24 09:58:19 --> Helper loaded: url_helper
INFO - 2022-06-24 09:58:19 --> Helper loaded: file_helper
INFO - 2022-06-24 09:58:19 --> Database Driver Class Initialized
INFO - 2022-06-24 09:58:19 --> Email Class Initialized
DEBUG - 2022-06-24 09:58:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 09:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 09:58:19 --> Controller Class Initialized
INFO - 2022-06-24 09:58:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 09:58:19 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 09:58:19 --> Final output sent to browser
DEBUG - 2022-06-24 09:58:19 --> Total execution time: 0.0325
INFO - 2022-06-24 09:58:44 --> Config Class Initialized
INFO - 2022-06-24 09:58:44 --> Hooks Class Initialized
DEBUG - 2022-06-24 09:58:44 --> UTF-8 Support Enabled
INFO - 2022-06-24 09:58:44 --> Utf8 Class Initialized
INFO - 2022-06-24 09:58:44 --> URI Class Initialized
INFO - 2022-06-24 09:58:44 --> Router Class Initialized
INFO - 2022-06-24 09:58:44 --> Output Class Initialized
INFO - 2022-06-24 09:58:44 --> Security Class Initialized
DEBUG - 2022-06-24 09:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 09:58:44 --> Input Class Initialized
INFO - 2022-06-24 09:58:44 --> Language Class Initialized
INFO - 2022-06-24 09:58:44 --> Loader Class Initialized
INFO - 2022-06-24 09:58:44 --> Helper loaded: url_helper
INFO - 2022-06-24 09:58:44 --> Helper loaded: file_helper
INFO - 2022-06-24 09:58:44 --> Database Driver Class Initialized
INFO - 2022-06-24 09:58:44 --> Config Class Initialized
INFO - 2022-06-24 09:58:44 --> Hooks Class Initialized
INFO - 2022-06-24 09:58:44 --> Email Class Initialized
DEBUG - 2022-06-24 09:58:44 --> UTF-8 Support Enabled
INFO - 2022-06-24 09:58:44 --> Utf8 Class Initialized
INFO - 2022-06-24 09:58:44 --> URI Class Initialized
DEBUG - 2022-06-24 09:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 09:58:44 --> Router Class Initialized
INFO - 2022-06-24 09:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 09:58:44 --> Output Class Initialized
INFO - 2022-06-24 09:58:44 --> Controller Class Initialized
INFO - 2022-06-24 09:58:44 --> Security Class Initialized
INFO - 2022-06-24 09:58:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 09:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 09:58:44 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 09:58:44 --> Input Class Initialized
INFO - 2022-06-24 09:58:44 --> Language Class Initialized
INFO - 2022-06-24 09:58:44 --> Loader Class Initialized
INFO - 2022-06-24 09:58:44 --> Helper loaded: url_helper
INFO - 2022-06-24 09:58:44 --> Helper loaded: file_helper
INFO - 2022-06-24 09:58:44 --> Database Driver Class Initialized
INFO - 2022-06-24 09:58:44 --> Email Class Initialized
DEBUG - 2022-06-24 09:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 09:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 09:58:44 --> Controller Class Initialized
INFO - 2022-06-24 09:58:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 09:58:44 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 09:58:44 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 09:58:44 --> Final output sent to browser
DEBUG - 2022-06-24 09:58:44 --> Total execution time: 0.0427
INFO - 2022-06-24 10:00:07 --> Config Class Initialized
INFO - 2022-06-24 10:00:07 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:00:07 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:00:07 --> Utf8 Class Initialized
INFO - 2022-06-24 10:00:07 --> URI Class Initialized
INFO - 2022-06-24 10:00:07 --> Router Class Initialized
INFO - 2022-06-24 10:00:07 --> Output Class Initialized
INFO - 2022-06-24 10:00:07 --> Security Class Initialized
DEBUG - 2022-06-24 10:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:00:07 --> Input Class Initialized
INFO - 2022-06-24 10:00:07 --> Language Class Initialized
INFO - 2022-06-24 10:00:07 --> Loader Class Initialized
INFO - 2022-06-24 10:00:07 --> Helper loaded: url_helper
INFO - 2022-06-24 10:00:07 --> Helper loaded: file_helper
INFO - 2022-06-24 10:00:07 --> Database Driver Class Initialized
INFO - 2022-06-24 10:00:07 --> Email Class Initialized
DEBUG - 2022-06-24 10:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:00:07 --> Controller Class Initialized
INFO - 2022-06-24 10:00:07 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:00:07 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:00:07 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 10:00:07 --> Final output sent to browser
DEBUG - 2022-06-24 10:00:07 --> Total execution time: 0.1318
INFO - 2022-06-24 10:00:22 --> Config Class Initialized
INFO - 2022-06-24 10:00:22 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:00:22 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:00:22 --> Utf8 Class Initialized
INFO - 2022-06-24 10:00:22 --> URI Class Initialized
INFO - 2022-06-24 10:00:22 --> Router Class Initialized
INFO - 2022-06-24 10:00:22 --> Output Class Initialized
INFO - 2022-06-24 10:00:22 --> Security Class Initialized
DEBUG - 2022-06-24 10:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:00:22 --> Input Class Initialized
INFO - 2022-06-24 10:00:22 --> Language Class Initialized
INFO - 2022-06-24 10:00:22 --> Loader Class Initialized
INFO - 2022-06-24 10:00:22 --> Helper loaded: url_helper
INFO - 2022-06-24 10:00:22 --> Helper loaded: file_helper
INFO - 2022-06-24 10:00:22 --> Database Driver Class Initialized
INFO - 2022-06-24 10:00:22 --> Config Class Initialized
INFO - 2022-06-24 10:00:22 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:00:22 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:00:22 --> Utf8 Class Initialized
INFO - 2022-06-24 10:00:22 --> URI Class Initialized
INFO - 2022-06-24 10:00:22 --> Router Class Initialized
INFO - 2022-06-24 10:00:22 --> Output Class Initialized
INFO - 2022-06-24 10:00:22 --> Security Class Initialized
DEBUG - 2022-06-24 10:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:00:22 --> Input Class Initialized
INFO - 2022-06-24 10:00:22 --> Language Class Initialized
INFO - 2022-06-24 10:00:22 --> Loader Class Initialized
INFO - 2022-06-24 10:00:22 --> Helper loaded: url_helper
INFO - 2022-06-24 10:00:22 --> Helper loaded: file_helper
INFO - 2022-06-24 10:00:22 --> Database Driver Class Initialized
INFO - 2022-06-24 10:00:22 --> Email Class Initialized
DEBUG - 2022-06-24 10:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:00:22 --> Controller Class Initialized
INFO - 2022-06-24 10:00:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:00:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:00:22 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 10:00:22 --> Final output sent to browser
DEBUG - 2022-06-24 10:00:22 --> Total execution time: 0.0319
INFO - 2022-06-24 10:00:22 --> Email Class Initialized
DEBUG - 2022-06-24 10:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:00:22 --> Controller Class Initialized
INFO - 2022-06-24 10:00:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:00:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:00:22 --> Final output sent to browser
DEBUG - 2022-06-24 10:00:22 --> Total execution time: 0.1385
INFO - 2022-06-24 10:00:25 --> Config Class Initialized
INFO - 2022-06-24 10:00:25 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:00:25 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:00:25 --> Utf8 Class Initialized
INFO - 2022-06-24 10:00:25 --> URI Class Initialized
INFO - 2022-06-24 10:00:25 --> Router Class Initialized
INFO - 2022-06-24 10:00:25 --> Output Class Initialized
INFO - 2022-06-24 10:00:25 --> Security Class Initialized
DEBUG - 2022-06-24 10:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:00:25 --> Input Class Initialized
INFO - 2022-06-24 10:00:25 --> Language Class Initialized
INFO - 2022-06-24 10:00:25 --> Loader Class Initialized
INFO - 2022-06-24 10:00:25 --> Helper loaded: url_helper
INFO - 2022-06-24 10:00:25 --> Helper loaded: file_helper
INFO - 2022-06-24 10:00:25 --> Database Driver Class Initialized
INFO - 2022-06-24 10:00:25 --> Email Class Initialized
DEBUG - 2022-06-24 10:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:00:25 --> Controller Class Initialized
INFO - 2022-06-24 10:00:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:00:25 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:00:25 --> Final output sent to browser
DEBUG - 2022-06-24 10:00:25 --> Total execution time: 0.0325
INFO - 2022-06-24 10:15:03 --> Config Class Initialized
INFO - 2022-06-24 10:15:03 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:15:03 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:15:03 --> Utf8 Class Initialized
INFO - 2022-06-24 10:15:03 --> URI Class Initialized
INFO - 2022-06-24 10:15:03 --> Router Class Initialized
INFO - 2022-06-24 10:15:03 --> Output Class Initialized
INFO - 2022-06-24 10:15:03 --> Security Class Initialized
DEBUG - 2022-06-24 10:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:15:03 --> Input Class Initialized
INFO - 2022-06-24 10:15:03 --> Language Class Initialized
INFO - 2022-06-24 10:15:03 --> Loader Class Initialized
INFO - 2022-06-24 10:15:03 --> Helper loaded: url_helper
INFO - 2022-06-24 10:15:03 --> Helper loaded: file_helper
INFO - 2022-06-24 10:15:03 --> Database Driver Class Initialized
INFO - 2022-06-24 10:15:03 --> Email Class Initialized
DEBUG - 2022-06-24 10:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:15:03 --> Controller Class Initialized
INFO - 2022-06-24 10:15:03 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:15:03 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:15:03 --> Final output sent to browser
DEBUG - 2022-06-24 10:15:03 --> Total execution time: 0.0485
INFO - 2022-06-24 10:15:32 --> Config Class Initialized
INFO - 2022-06-24 10:15:32 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:15:32 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:15:32 --> Utf8 Class Initialized
INFO - 2022-06-24 10:15:32 --> URI Class Initialized
INFO - 2022-06-24 10:15:32 --> Router Class Initialized
INFO - 2022-06-24 10:15:32 --> Output Class Initialized
INFO - 2022-06-24 10:15:32 --> Security Class Initialized
DEBUG - 2022-06-24 10:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:15:32 --> Input Class Initialized
INFO - 2022-06-24 10:15:32 --> Language Class Initialized
INFO - 2022-06-24 10:15:32 --> Loader Class Initialized
INFO - 2022-06-24 10:15:32 --> Helper loaded: url_helper
INFO - 2022-06-24 10:15:32 --> Helper loaded: file_helper
INFO - 2022-06-24 10:15:32 --> Database Driver Class Initialized
INFO - 2022-06-24 10:15:32 --> Email Class Initialized
DEBUG - 2022-06-24 10:15:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:15:32 --> Controller Class Initialized
INFO - 2022-06-24 10:15:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:15:32 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:15:32 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 10:15:32 --> Final output sent to browser
DEBUG - 2022-06-24 10:15:32 --> Total execution time: 0.0794
INFO - 2022-06-24 10:15:40 --> Config Class Initialized
INFO - 2022-06-24 10:15:40 --> Hooks Class Initialized
INFO - 2022-06-24 10:15:40 --> Config Class Initialized
DEBUG - 2022-06-24 10:15:40 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:15:40 --> Utf8 Class Initialized
INFO - 2022-06-24 10:15:40 --> Hooks Class Initialized
INFO - 2022-06-24 10:15:40 --> URI Class Initialized
DEBUG - 2022-06-24 10:15:40 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:15:40 --> Utf8 Class Initialized
INFO - 2022-06-24 10:15:40 --> Router Class Initialized
INFO - 2022-06-24 10:15:40 --> URI Class Initialized
INFO - 2022-06-24 10:15:40 --> Output Class Initialized
INFO - 2022-06-24 10:15:40 --> Router Class Initialized
INFO - 2022-06-24 10:15:40 --> Security Class Initialized
INFO - 2022-06-24 10:15:40 --> Output Class Initialized
DEBUG - 2022-06-24 10:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:15:40 --> Security Class Initialized
INFO - 2022-06-24 10:15:40 --> Input Class Initialized
DEBUG - 2022-06-24 10:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:15:40 --> Input Class Initialized
INFO - 2022-06-24 10:15:40 --> Language Class Initialized
INFO - 2022-06-24 10:15:40 --> Language Class Initialized
INFO - 2022-06-24 10:15:40 --> Loader Class Initialized
INFO - 2022-06-24 10:15:40 --> Loader Class Initialized
INFO - 2022-06-24 10:15:40 --> Helper loaded: url_helper
INFO - 2022-06-24 10:15:40 --> Helper loaded: url_helper
INFO - 2022-06-24 10:15:40 --> Helper loaded: file_helper
INFO - 2022-06-24 10:15:40 --> Helper loaded: file_helper
INFO - 2022-06-24 10:15:40 --> Database Driver Class Initialized
INFO - 2022-06-24 10:15:40 --> Database Driver Class Initialized
INFO - 2022-06-24 10:15:40 --> Email Class Initialized
INFO - 2022-06-24 10:15:40 --> Email Class Initialized
DEBUG - 2022-06-24 10:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-24 10:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:15:40 --> Controller Class Initialized
INFO - 2022-06-24 10:15:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:15:40 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:15:40 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 10:15:40 --> Final output sent to browser
DEBUG - 2022-06-24 10:15:40 --> Total execution time: 0.0382
INFO - 2022-06-24 10:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:15:40 --> Controller Class Initialized
INFO - 2022-06-24 10:15:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:15:40 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:15:40 --> Final output sent to browser
DEBUG - 2022-06-24 10:15:40 --> Total execution time: 0.0503
INFO - 2022-06-24 10:15:43 --> Config Class Initialized
INFO - 2022-06-24 10:15:43 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:15:43 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:15:43 --> Utf8 Class Initialized
INFO - 2022-06-24 10:15:43 --> URI Class Initialized
INFO - 2022-06-24 10:15:43 --> Router Class Initialized
INFO - 2022-06-24 10:15:43 --> Output Class Initialized
INFO - 2022-06-24 10:15:43 --> Security Class Initialized
DEBUG - 2022-06-24 10:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:15:43 --> Input Class Initialized
INFO - 2022-06-24 10:15:43 --> Language Class Initialized
INFO - 2022-06-24 10:15:44 --> Loader Class Initialized
INFO - 2022-06-24 10:15:44 --> Helper loaded: url_helper
INFO - 2022-06-24 10:15:44 --> Helper loaded: file_helper
INFO - 2022-06-24 10:15:44 --> Database Driver Class Initialized
INFO - 2022-06-24 10:15:44 --> Email Class Initialized
DEBUG - 2022-06-24 10:15:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:15:44 --> Controller Class Initialized
INFO - 2022-06-24 10:15:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:15:44 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:15:44 --> Final output sent to browser
DEBUG - 2022-06-24 10:15:44 --> Total execution time: 0.0723
INFO - 2022-06-24 10:16:55 --> Config Class Initialized
INFO - 2022-06-24 10:16:55 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:16:55 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:16:55 --> Utf8 Class Initialized
INFO - 2022-06-24 10:16:55 --> URI Class Initialized
INFO - 2022-06-24 10:16:55 --> Router Class Initialized
INFO - 2022-06-24 10:16:55 --> Output Class Initialized
INFO - 2022-06-24 10:16:55 --> Security Class Initialized
DEBUG - 2022-06-24 10:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:16:55 --> Input Class Initialized
INFO - 2022-06-24 10:16:55 --> Language Class Initialized
INFO - 2022-06-24 10:16:55 --> Loader Class Initialized
INFO - 2022-06-24 10:16:55 --> Helper loaded: url_helper
INFO - 2022-06-24 10:16:55 --> Helper loaded: file_helper
INFO - 2022-06-24 10:16:55 --> Database Driver Class Initialized
INFO - 2022-06-24 10:16:55 --> Email Class Initialized
DEBUG - 2022-06-24 10:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:16:55 --> Controller Class Initialized
INFO - 2022-06-24 10:16:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:16:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:16:55 --> Final output sent to browser
DEBUG - 2022-06-24 10:16:55 --> Total execution time: 0.0281
INFO - 2022-06-24 10:17:13 --> Config Class Initialized
INFO - 2022-06-24 10:17:13 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:17:13 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:17:13 --> Utf8 Class Initialized
INFO - 2022-06-24 10:17:13 --> URI Class Initialized
INFO - 2022-06-24 10:17:13 --> Config Class Initialized
INFO - 2022-06-24 10:17:13 --> Hooks Class Initialized
INFO - 2022-06-24 10:17:13 --> Router Class Initialized
DEBUG - 2022-06-24 10:17:13 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:17:13 --> Utf8 Class Initialized
INFO - 2022-06-24 10:17:13 --> Output Class Initialized
INFO - 2022-06-24 10:17:13 --> Security Class Initialized
INFO - 2022-06-24 10:17:13 --> URI Class Initialized
DEBUG - 2022-06-24 10:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:17:13 --> Input Class Initialized
INFO - 2022-06-24 10:17:13 --> Router Class Initialized
INFO - 2022-06-24 10:17:13 --> Language Class Initialized
INFO - 2022-06-24 10:17:13 --> Output Class Initialized
INFO - 2022-06-24 10:17:13 --> Loader Class Initialized
INFO - 2022-06-24 10:17:13 --> Security Class Initialized
DEBUG - 2022-06-24 10:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:17:13 --> Helper loaded: url_helper
INFO - 2022-06-24 10:17:13 --> Input Class Initialized
INFO - 2022-06-24 10:17:13 --> Language Class Initialized
INFO - 2022-06-24 10:17:13 --> Helper loaded: file_helper
INFO - 2022-06-24 10:17:13 --> Loader Class Initialized
INFO - 2022-06-24 10:17:13 --> Database Driver Class Initialized
INFO - 2022-06-24 10:17:13 --> Helper loaded: url_helper
INFO - 2022-06-24 10:17:13 --> Helper loaded: file_helper
INFO - 2022-06-24 10:17:13 --> Database Driver Class Initialized
INFO - 2022-06-24 10:17:13 --> Email Class Initialized
DEBUG - 2022-06-24 10:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:17:13 --> Email Class Initialized
INFO - 2022-06-24 10:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:17:13 --> Controller Class Initialized
DEBUG - 2022-06-24 10:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:17:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:17:13 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:17:13 --> Final output sent to browser
DEBUG - 2022-06-24 10:17:13 --> Total execution time: 0.0361
INFO - 2022-06-24 10:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:17:13 --> Controller Class Initialized
INFO - 2022-06-24 10:17:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:17:13 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:17:13 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 10:17:13 --> Final output sent to browser
DEBUG - 2022-06-24 10:17:13 --> Total execution time: 0.0375
INFO - 2022-06-24 10:17:18 --> Config Class Initialized
INFO - 2022-06-24 10:17:18 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:17:18 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:17:18 --> Utf8 Class Initialized
INFO - 2022-06-24 10:17:18 --> URI Class Initialized
INFO - 2022-06-24 10:17:18 --> Router Class Initialized
INFO - 2022-06-24 10:17:18 --> Output Class Initialized
INFO - 2022-06-24 10:17:18 --> Security Class Initialized
DEBUG - 2022-06-24 10:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:17:18 --> Input Class Initialized
INFO - 2022-06-24 10:17:18 --> Language Class Initialized
INFO - 2022-06-24 10:17:18 --> Loader Class Initialized
INFO - 2022-06-24 10:17:18 --> Helper loaded: url_helper
INFO - 2022-06-24 10:17:18 --> Helper loaded: file_helper
INFO - 2022-06-24 10:17:18 --> Database Driver Class Initialized
INFO - 2022-06-24 10:17:18 --> Email Class Initialized
DEBUG - 2022-06-24 10:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:17:18 --> Controller Class Initialized
INFO - 2022-06-24 10:17:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:17:18 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:17:18 --> Final output sent to browser
DEBUG - 2022-06-24 10:17:18 --> Total execution time: 0.0322
INFO - 2022-06-24 10:17:54 --> Config Class Initialized
INFO - 2022-06-24 10:17:54 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:17:54 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:17:54 --> Utf8 Class Initialized
INFO - 2022-06-24 10:17:54 --> URI Class Initialized
INFO - 2022-06-24 10:17:54 --> Router Class Initialized
INFO - 2022-06-24 10:17:54 --> Output Class Initialized
INFO - 2022-06-24 10:17:54 --> Security Class Initialized
DEBUG - 2022-06-24 10:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:17:54 --> Input Class Initialized
INFO - 2022-06-24 10:17:54 --> Language Class Initialized
INFO - 2022-06-24 10:17:54 --> Loader Class Initialized
INFO - 2022-06-24 10:17:54 --> Helper loaded: url_helper
INFO - 2022-06-24 10:17:54 --> Helper loaded: file_helper
INFO - 2022-06-24 10:17:54 --> Database Driver Class Initialized
INFO - 2022-06-24 10:17:54 --> Email Class Initialized
DEBUG - 2022-06-24 10:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:17:54 --> Controller Class Initialized
INFO - 2022-06-24 10:17:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:17:54 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:17:54 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 10:17:54 --> Final output sent to browser
DEBUG - 2022-06-24 10:17:54 --> Total execution time: 0.1377
INFO - 2022-06-24 10:18:19 --> Config Class Initialized
INFO - 2022-06-24 10:18:19 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:18:19 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:18:19 --> Utf8 Class Initialized
INFO - 2022-06-24 10:18:19 --> URI Class Initialized
INFO - 2022-06-24 10:18:19 --> Router Class Initialized
INFO - 2022-06-24 10:18:19 --> Output Class Initialized
INFO - 2022-06-24 10:18:19 --> Security Class Initialized
DEBUG - 2022-06-24 10:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:18:19 --> Input Class Initialized
INFO - 2022-06-24 10:18:19 --> Language Class Initialized
INFO - 2022-06-24 10:18:19 --> Loader Class Initialized
INFO - 2022-06-24 10:18:19 --> Helper loaded: url_helper
INFO - 2022-06-24 10:18:19 --> Config Class Initialized
INFO - 2022-06-24 10:18:19 --> Hooks Class Initialized
INFO - 2022-06-24 10:18:19 --> Helper loaded: file_helper
DEBUG - 2022-06-24 10:18:19 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:18:19 --> Database Driver Class Initialized
INFO - 2022-06-24 10:18:19 --> Utf8 Class Initialized
INFO - 2022-06-24 10:18:19 --> URI Class Initialized
INFO - 2022-06-24 10:18:19 --> Router Class Initialized
INFO - 2022-06-24 10:18:19 --> Output Class Initialized
INFO - 2022-06-24 10:18:19 --> Email Class Initialized
INFO - 2022-06-24 10:18:19 --> Security Class Initialized
DEBUG - 2022-06-24 10:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:18:19 --> Input Class Initialized
DEBUG - 2022-06-24 10:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:18:19 --> Language Class Initialized
INFO - 2022-06-24 10:18:19 --> Loader Class Initialized
INFO - 2022-06-24 10:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:18:19 --> Controller Class Initialized
INFO - 2022-06-24 10:18:19 --> Helper loaded: url_helper
INFO - 2022-06-24 10:18:19 --> Model "Tokenmodel" initialized
INFO - 2022-06-24 10:18:19 --> Helper loaded: file_helper
DEBUG - 2022-06-24 10:18:19 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:18:19 --> Database Driver Class Initialized
INFO - 2022-06-24 10:18:19 --> Final output sent to browser
DEBUG - 2022-06-24 10:18:19 --> Total execution time: 0.0375
INFO - 2022-06-24 10:18:19 --> Email Class Initialized
DEBUG - 2022-06-24 10:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:18:19 --> Controller Class Initialized
INFO - 2022-06-24 10:18:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:18:19 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:18:19 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 10:18:19 --> Final output sent to browser
DEBUG - 2022-06-24 10:18:19 --> Total execution time: 0.3363
INFO - 2022-06-24 10:18:25 --> Config Class Initialized
INFO - 2022-06-24 10:18:25 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:18:25 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:18:25 --> Utf8 Class Initialized
INFO - 2022-06-24 10:18:25 --> URI Class Initialized
INFO - 2022-06-24 10:18:25 --> Router Class Initialized
INFO - 2022-06-24 10:18:25 --> Output Class Initialized
INFO - 2022-06-24 10:18:25 --> Security Class Initialized
DEBUG - 2022-06-24 10:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:18:25 --> Input Class Initialized
INFO - 2022-06-24 10:18:25 --> Language Class Initialized
INFO - 2022-06-24 10:18:25 --> Loader Class Initialized
INFO - 2022-06-24 10:18:25 --> Helper loaded: url_helper
INFO - 2022-06-24 10:18:25 --> Helper loaded: file_helper
INFO - 2022-06-24 10:18:25 --> Database Driver Class Initialized
INFO - 2022-06-24 10:18:25 --> Email Class Initialized
DEBUG - 2022-06-24 10:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:18:25 --> Controller Class Initialized
INFO - 2022-06-24 10:18:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:18:25 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:18:25 --> Final output sent to browser
DEBUG - 2022-06-24 10:18:25 --> Total execution time: 0.0351
INFO - 2022-06-24 10:20:02 --> Config Class Initialized
INFO - 2022-06-24 10:20:02 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:20:02 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:20:02 --> Utf8 Class Initialized
INFO - 2022-06-24 10:20:02 --> URI Class Initialized
INFO - 2022-06-24 10:20:02 --> Router Class Initialized
INFO - 2022-06-24 10:20:02 --> Output Class Initialized
INFO - 2022-06-24 10:20:02 --> Security Class Initialized
DEBUG - 2022-06-24 10:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:20:02 --> Input Class Initialized
INFO - 2022-06-24 10:20:02 --> Language Class Initialized
INFO - 2022-06-24 10:20:02 --> Loader Class Initialized
INFO - 2022-06-24 10:20:02 --> Helper loaded: url_helper
INFO - 2022-06-24 10:20:02 --> Helper loaded: file_helper
INFO - 2022-06-24 10:20:02 --> Database Driver Class Initialized
INFO - 2022-06-24 10:20:02 --> Email Class Initialized
DEBUG - 2022-06-24 10:20:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:20:02 --> Controller Class Initialized
INFO - 2022-06-24 10:20:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:20:02 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:20:02 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 10:20:02 --> Final output sent to browser
DEBUG - 2022-06-24 10:20:02 --> Total execution time: 0.0304
INFO - 2022-06-24 10:20:09 --> Config Class Initialized
INFO - 2022-06-24 10:20:09 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:20:09 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:20:09 --> Utf8 Class Initialized
INFO - 2022-06-24 10:20:09 --> URI Class Initialized
INFO - 2022-06-24 10:20:09 --> Router Class Initialized
INFO - 2022-06-24 10:20:09 --> Output Class Initialized
INFO - 2022-06-24 10:20:09 --> Security Class Initialized
DEBUG - 2022-06-24 10:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:20:09 --> Input Class Initialized
INFO - 2022-06-24 10:20:09 --> Language Class Initialized
INFO - 2022-06-24 10:20:09 --> Loader Class Initialized
INFO - 2022-06-24 10:20:09 --> Helper loaded: url_helper
INFO - 2022-06-24 10:20:09 --> Helper loaded: file_helper
INFO - 2022-06-24 10:20:09 --> Database Driver Class Initialized
INFO - 2022-06-24 10:20:09 --> Email Class Initialized
DEBUG - 2022-06-24 10:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:20:09 --> Controller Class Initialized
INFO - 2022-06-24 10:20:09 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:20:09 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:20:09 --> Config Class Initialized
INFO - 2022-06-24 10:20:09 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:20:09 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:20:09 --> Utf8 Class Initialized
INFO - 2022-06-24 10:20:10 --> URI Class Initialized
INFO - 2022-06-24 10:20:10 --> Router Class Initialized
INFO - 2022-06-24 10:20:10 --> Output Class Initialized
INFO - 2022-06-24 10:20:10 --> Security Class Initialized
DEBUG - 2022-06-24 10:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:20:10 --> Input Class Initialized
INFO - 2022-06-24 10:20:10 --> Language Class Initialized
INFO - 2022-06-24 10:20:10 --> Loader Class Initialized
INFO - 2022-06-24 10:20:10 --> Helper loaded: url_helper
INFO - 2022-06-24 10:20:10 --> Helper loaded: file_helper
INFO - 2022-06-24 10:20:10 --> Database Driver Class Initialized
INFO - 2022-06-24 10:20:10 --> Email Class Initialized
DEBUG - 2022-06-24 10:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:20:10 --> Controller Class Initialized
INFO - 2022-06-24 10:20:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:20:10 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:20:10 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 10:20:10 --> Final output sent to browser
DEBUG - 2022-06-24 10:20:10 --> Total execution time: 0.0688
INFO - 2022-06-24 10:20:18 --> Config Class Initialized
INFO - 2022-06-24 10:20:18 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:20:18 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:20:18 --> Utf8 Class Initialized
INFO - 2022-06-24 10:20:18 --> URI Class Initialized
INFO - 2022-06-24 10:20:18 --> Router Class Initialized
INFO - 2022-06-24 10:20:18 --> Output Class Initialized
INFO - 2022-06-24 10:20:18 --> Security Class Initialized
DEBUG - 2022-06-24 10:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:20:18 --> Input Class Initialized
INFO - 2022-06-24 10:20:18 --> Language Class Initialized
INFO - 2022-06-24 10:20:18 --> Loader Class Initialized
INFO - 2022-06-24 10:20:18 --> Helper loaded: url_helper
INFO - 2022-06-24 10:20:18 --> Helper loaded: file_helper
INFO - 2022-06-24 10:20:18 --> Database Driver Class Initialized
INFO - 2022-06-24 10:20:18 --> Email Class Initialized
DEBUG - 2022-06-24 10:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:20:18 --> Controller Class Initialized
INFO - 2022-06-24 10:20:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:20:18 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:33:51 --> Config Class Initialized
INFO - 2022-06-24 10:33:51 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:33:51 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:33:51 --> Utf8 Class Initialized
INFO - 2022-06-24 10:33:51 --> URI Class Initialized
INFO - 2022-06-24 10:33:51 --> Router Class Initialized
INFO - 2022-06-24 10:33:51 --> Output Class Initialized
INFO - 2022-06-24 10:33:51 --> Security Class Initialized
DEBUG - 2022-06-24 10:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:33:51 --> Input Class Initialized
INFO - 2022-06-24 10:33:51 --> Language Class Initialized
INFO - 2022-06-24 10:33:51 --> Loader Class Initialized
INFO - 2022-06-24 10:33:51 --> Helper loaded: url_helper
INFO - 2022-06-24 10:33:51 --> Helper loaded: file_helper
INFO - 2022-06-24 10:33:51 --> Database Driver Class Initialized
INFO - 2022-06-24 10:33:51 --> Email Class Initialized
DEBUG - 2022-06-24 10:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:33:51 --> Controller Class Initialized
INFO - 2022-06-24 10:33:51 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:33:51 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:33:51 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 10:33:51 --> Final output sent to browser
DEBUG - 2022-06-24 10:33:51 --> Total execution time: 0.1787
INFO - 2022-06-24 10:33:58 --> Config Class Initialized
INFO - 2022-06-24 10:33:58 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:33:58 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:33:58 --> Utf8 Class Initialized
INFO - 2022-06-24 10:33:58 --> Config Class Initialized
INFO - 2022-06-24 10:33:58 --> URI Class Initialized
INFO - 2022-06-24 10:33:58 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:33:58 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:33:58 --> Router Class Initialized
INFO - 2022-06-24 10:33:58 --> Utf8 Class Initialized
INFO - 2022-06-24 10:33:58 --> URI Class Initialized
INFO - 2022-06-24 10:33:58 --> Output Class Initialized
INFO - 2022-06-24 10:33:58 --> Security Class Initialized
INFO - 2022-06-24 10:33:58 --> Router Class Initialized
DEBUG - 2022-06-24 10:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:33:58 --> Output Class Initialized
INFO - 2022-06-24 10:33:58 --> Input Class Initialized
INFO - 2022-06-24 10:33:58 --> Security Class Initialized
INFO - 2022-06-24 10:33:58 --> Language Class Initialized
DEBUG - 2022-06-24 10:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:33:58 --> Loader Class Initialized
INFO - 2022-06-24 10:33:58 --> Input Class Initialized
INFO - 2022-06-24 10:33:58 --> Language Class Initialized
INFO - 2022-06-24 10:33:58 --> Helper loaded: url_helper
INFO - 2022-06-24 10:33:58 --> Loader Class Initialized
INFO - 2022-06-24 10:33:58 --> Helper loaded: file_helper
INFO - 2022-06-24 10:33:58 --> Helper loaded: url_helper
INFO - 2022-06-24 10:33:58 --> Helper loaded: file_helper
INFO - 2022-06-24 10:33:58 --> Database Driver Class Initialized
INFO - 2022-06-24 10:33:58 --> Database Driver Class Initialized
INFO - 2022-06-24 10:33:59 --> Email Class Initialized
DEBUG - 2022-06-24 10:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:33:59 --> Controller Class Initialized
INFO - 2022-06-24 10:33:59 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:33:59 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:33:59 --> Email Class Initialized
DEBUG - 2022-06-24 10:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-06-24 10:33:59 --> Severity: Warning --> Use of undefined constant verrified - assumed 'verrified' (this will throw an Error in a future version of PHP) C:\wamp64\www\qr\application\controllers\Tokenctrl.php 38
INFO - 2022-06-24 10:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:33:59 --> Controller Class Initialized
INFO - 2022-06-24 10:33:59 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:33:59 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:33:59 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 10:33:59 --> Final output sent to browser
DEBUG - 2022-06-24 10:33:59 --> Total execution time: 0.1798
INFO - 2022-06-24 10:34:07 --> Config Class Initialized
INFO - 2022-06-24 10:34:07 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:34:07 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:34:07 --> Utf8 Class Initialized
INFO - 2022-06-24 10:34:07 --> URI Class Initialized
INFO - 2022-06-24 10:34:07 --> Router Class Initialized
INFO - 2022-06-24 10:34:07 --> Output Class Initialized
INFO - 2022-06-24 10:34:07 --> Security Class Initialized
DEBUG - 2022-06-24 10:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:34:07 --> Input Class Initialized
INFO - 2022-06-24 10:34:07 --> Language Class Initialized
INFO - 2022-06-24 10:34:07 --> Loader Class Initialized
INFO - 2022-06-24 10:34:07 --> Helper loaded: url_helper
INFO - 2022-06-24 10:34:07 --> Helper loaded: file_helper
INFO - 2022-06-24 10:34:07 --> Database Driver Class Initialized
INFO - 2022-06-24 10:34:07 --> Email Class Initialized
DEBUG - 2022-06-24 10:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:34:07 --> Controller Class Initialized
INFO - 2022-06-24 10:34:07 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:34:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-24 10:34:07 --> Severity: Warning --> Use of undefined constant verrified - assumed 'verrified' (this will throw an Error in a future version of PHP) C:\wamp64\www\qr\application\controllers\Tokenctrl.php 38
INFO - 2022-06-24 10:34:31 --> Config Class Initialized
INFO - 2022-06-24 10:34:31 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:34:31 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:34:31 --> Utf8 Class Initialized
INFO - 2022-06-24 10:34:31 --> URI Class Initialized
INFO - 2022-06-24 10:34:31 --> Router Class Initialized
INFO - 2022-06-24 10:34:31 --> Output Class Initialized
INFO - 2022-06-24 10:34:31 --> Security Class Initialized
DEBUG - 2022-06-24 10:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:34:31 --> Input Class Initialized
INFO - 2022-06-24 10:34:31 --> Language Class Initialized
INFO - 2022-06-24 10:34:31 --> Loader Class Initialized
INFO - 2022-06-24 10:34:31 --> Helper loaded: url_helper
INFO - 2022-06-24 10:34:31 --> Helper loaded: file_helper
INFO - 2022-06-24 10:34:31 --> Database Driver Class Initialized
INFO - 2022-06-24 10:34:31 --> Email Class Initialized
DEBUG - 2022-06-24 10:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:34:31 --> Controller Class Initialized
INFO - 2022-06-24 10:34:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:34:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:34:37 --> Config Class Initialized
INFO - 2022-06-24 10:34:37 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:34:37 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:34:37 --> Utf8 Class Initialized
INFO - 2022-06-24 10:34:37 --> URI Class Initialized
INFO - 2022-06-24 10:34:37 --> Router Class Initialized
INFO - 2022-06-24 10:34:37 --> Output Class Initialized
INFO - 2022-06-24 10:34:37 --> Security Class Initialized
DEBUG - 2022-06-24 10:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:34:37 --> Input Class Initialized
INFO - 2022-06-24 10:34:37 --> Language Class Initialized
INFO - 2022-06-24 10:34:37 --> Loader Class Initialized
INFO - 2022-06-24 10:34:37 --> Helper loaded: url_helper
INFO - 2022-06-24 10:34:37 --> Helper loaded: file_helper
INFO - 2022-06-24 10:34:37 --> Database Driver Class Initialized
INFO - 2022-06-24 10:34:37 --> Email Class Initialized
DEBUG - 2022-06-24 10:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:34:37 --> Controller Class Initialized
INFO - 2022-06-24 10:34:37 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:34:37 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:34:37 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 10:34:37 --> Final output sent to browser
DEBUG - 2022-06-24 10:34:37 --> Total execution time: 0.0384
INFO - 2022-06-24 10:34:46 --> Config Class Initialized
INFO - 2022-06-24 10:34:46 --> Config Class Initialized
INFO - 2022-06-24 10:34:46 --> Hooks Class Initialized
INFO - 2022-06-24 10:34:46 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 10:34:46 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:34:46 --> Utf8 Class Initialized
INFO - 2022-06-24 10:34:46 --> Utf8 Class Initialized
INFO - 2022-06-24 10:34:46 --> URI Class Initialized
INFO - 2022-06-24 10:34:46 --> URI Class Initialized
INFO - 2022-06-24 10:34:46 --> Router Class Initialized
INFO - 2022-06-24 10:34:46 --> Router Class Initialized
INFO - 2022-06-24 10:34:46 --> Output Class Initialized
INFO - 2022-06-24 10:34:46 --> Output Class Initialized
INFO - 2022-06-24 10:34:46 --> Security Class Initialized
INFO - 2022-06-24 10:34:46 --> Security Class Initialized
DEBUG - 2022-06-24 10:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-24 10:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:34:46 --> Input Class Initialized
INFO - 2022-06-24 10:34:46 --> Input Class Initialized
INFO - 2022-06-24 10:34:46 --> Language Class Initialized
INFO - 2022-06-24 10:34:46 --> Language Class Initialized
INFO - 2022-06-24 10:34:46 --> Loader Class Initialized
INFO - 2022-06-24 10:34:46 --> Loader Class Initialized
INFO - 2022-06-24 10:34:46 --> Helper loaded: url_helper
INFO - 2022-06-24 10:34:46 --> Helper loaded: file_helper
INFO - 2022-06-24 10:34:46 --> Helper loaded: url_helper
INFO - 2022-06-24 10:34:46 --> Helper loaded: file_helper
INFO - 2022-06-24 10:34:46 --> Database Driver Class Initialized
INFO - 2022-06-24 10:34:46 --> Database Driver Class Initialized
INFO - 2022-06-24 10:34:46 --> Email Class Initialized
INFO - 2022-06-24 10:34:46 --> Email Class Initialized
DEBUG - 2022-06-24 10:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-24 10:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:34:46 --> Controller Class Initialized
INFO - 2022-06-24 10:34:46 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:34:46 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:34:46 --> Controller Class Initialized
INFO - 2022-06-24 10:34:46 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:34:46 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:34:46 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 10:34:46 --> Final output sent to browser
DEBUG - 2022-06-24 10:34:46 --> Total execution time: 0.0351
INFO - 2022-06-24 10:34:51 --> Config Class Initialized
INFO - 2022-06-24 10:34:51 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:34:51 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:34:51 --> Utf8 Class Initialized
INFO - 2022-06-24 10:34:51 --> URI Class Initialized
INFO - 2022-06-24 10:34:51 --> Router Class Initialized
INFO - 2022-06-24 10:34:51 --> Output Class Initialized
INFO - 2022-06-24 10:34:51 --> Security Class Initialized
DEBUG - 2022-06-24 10:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:34:51 --> Input Class Initialized
INFO - 2022-06-24 10:34:51 --> Language Class Initialized
INFO - 2022-06-24 10:34:51 --> Loader Class Initialized
INFO - 2022-06-24 10:34:51 --> Helper loaded: url_helper
INFO - 2022-06-24 10:34:51 --> Helper loaded: file_helper
INFO - 2022-06-24 10:34:51 --> Database Driver Class Initialized
INFO - 2022-06-24 10:34:51 --> Email Class Initialized
DEBUG - 2022-06-24 10:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:34:51 --> Controller Class Initialized
INFO - 2022-06-24 10:34:51 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:34:51 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:41:56 --> Config Class Initialized
INFO - 2022-06-24 10:41:56 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:41:56 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:41:56 --> Utf8 Class Initialized
INFO - 2022-06-24 10:41:56 --> URI Class Initialized
INFO - 2022-06-24 10:41:56 --> Router Class Initialized
INFO - 2022-06-24 10:41:56 --> Output Class Initialized
INFO - 2022-06-24 10:41:56 --> Security Class Initialized
DEBUG - 2022-06-24 10:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:41:56 --> Input Class Initialized
INFO - 2022-06-24 10:41:56 --> Language Class Initialized
INFO - 2022-06-24 10:41:56 --> Loader Class Initialized
INFO - 2022-06-24 10:41:56 --> Helper loaded: url_helper
INFO - 2022-06-24 10:41:56 --> Helper loaded: file_helper
INFO - 2022-06-24 10:41:56 --> Database Driver Class Initialized
INFO - 2022-06-24 10:41:56 --> Email Class Initialized
DEBUG - 2022-06-24 10:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:41:56 --> Controller Class Initialized
INFO - 2022-06-24 10:41:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:41:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:41:56 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 10:41:56 --> Final output sent to browser
DEBUG - 2022-06-24 10:41:56 --> Total execution time: 0.0400
INFO - 2022-06-24 10:42:04 --> Config Class Initialized
INFO - 2022-06-24 10:42:04 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:42:04 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:42:04 --> Utf8 Class Initialized
INFO - 2022-06-24 10:42:04 --> URI Class Initialized
INFO - 2022-06-24 10:42:04 --> Router Class Initialized
INFO - 2022-06-24 10:42:04 --> Output Class Initialized
INFO - 2022-06-24 10:42:04 --> Config Class Initialized
INFO - 2022-06-24 10:42:04 --> Security Class Initialized
DEBUG - 2022-06-24 10:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:42:04 --> Hooks Class Initialized
INFO - 2022-06-24 10:42:04 --> Input Class Initialized
INFO - 2022-06-24 10:42:04 --> Language Class Initialized
DEBUG - 2022-06-24 10:42:04 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:42:04 --> Utf8 Class Initialized
INFO - 2022-06-24 10:42:04 --> Loader Class Initialized
INFO - 2022-06-24 10:42:04 --> URI Class Initialized
INFO - 2022-06-24 10:42:04 --> Helper loaded: url_helper
INFO - 2022-06-24 10:42:04 --> Router Class Initialized
INFO - 2022-06-24 10:42:04 --> Helper loaded: file_helper
INFO - 2022-06-24 10:42:04 --> Output Class Initialized
INFO - 2022-06-24 10:42:04 --> Database Driver Class Initialized
INFO - 2022-06-24 10:42:04 --> Security Class Initialized
DEBUG - 2022-06-24 10:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:42:04 --> Input Class Initialized
INFO - 2022-06-24 10:42:04 --> Language Class Initialized
INFO - 2022-06-24 10:42:04 --> Email Class Initialized
INFO - 2022-06-24 10:42:04 --> Loader Class Initialized
INFO - 2022-06-24 10:42:04 --> Helper loaded: url_helper
DEBUG - 2022-06-24 10:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:42:04 --> Helper loaded: file_helper
INFO - 2022-06-24 10:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:42:04 --> Database Driver Class Initialized
INFO - 2022-06-24 10:42:04 --> Controller Class Initialized
INFO - 2022-06-24 10:42:04 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:42:04 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:42:04 --> Email Class Initialized
DEBUG - 2022-06-24 10:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:42:04 --> Controller Class Initialized
INFO - 2022-06-24 10:42:04 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:42:04 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:42:04 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 10:42:04 --> Final output sent to browser
DEBUG - 2022-06-24 10:42:04 --> Total execution time: 0.0324
INFO - 2022-06-24 10:42:10 --> Config Class Initialized
INFO - 2022-06-24 10:42:10 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:42:10 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:42:10 --> Utf8 Class Initialized
INFO - 2022-06-24 10:42:10 --> URI Class Initialized
INFO - 2022-06-24 10:42:10 --> Router Class Initialized
INFO - 2022-06-24 10:42:10 --> Output Class Initialized
INFO - 2022-06-24 10:42:10 --> Security Class Initialized
DEBUG - 2022-06-24 10:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:42:10 --> Input Class Initialized
INFO - 2022-06-24 10:42:10 --> Language Class Initialized
INFO - 2022-06-24 10:42:10 --> Loader Class Initialized
INFO - 2022-06-24 10:42:10 --> Helper loaded: url_helper
INFO - 2022-06-24 10:42:10 --> Helper loaded: file_helper
INFO - 2022-06-24 10:42:10 --> Database Driver Class Initialized
INFO - 2022-06-24 10:42:10 --> Email Class Initialized
DEBUG - 2022-06-24 10:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:42:10 --> Controller Class Initialized
INFO - 2022-06-24 10:42:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:42:10 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:48:30 --> Config Class Initialized
INFO - 2022-06-24 10:48:30 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:48:30 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:48:30 --> Utf8 Class Initialized
INFO - 2022-06-24 10:48:30 --> URI Class Initialized
INFO - 2022-06-24 10:48:30 --> Router Class Initialized
INFO - 2022-06-24 10:48:30 --> Output Class Initialized
INFO - 2022-06-24 10:48:30 --> Security Class Initialized
DEBUG - 2022-06-24 10:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:48:30 --> Input Class Initialized
INFO - 2022-06-24 10:48:30 --> Language Class Initialized
INFO - 2022-06-24 10:48:30 --> Loader Class Initialized
INFO - 2022-06-24 10:48:30 --> Helper loaded: url_helper
INFO - 2022-06-24 10:48:30 --> Helper loaded: file_helper
INFO - 2022-06-24 10:48:30 --> Database Driver Class Initialized
INFO - 2022-06-24 10:48:30 --> Email Class Initialized
DEBUG - 2022-06-24 10:48:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:48:30 --> Controller Class Initialized
INFO - 2022-06-24 10:48:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:48:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:48:30 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 10:48:30 --> Final output sent to browser
DEBUG - 2022-06-24 10:48:30 --> Total execution time: 0.0664
INFO - 2022-06-24 10:48:38 --> Config Class Initialized
INFO - 2022-06-24 10:48:38 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:48:38 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:48:38 --> Utf8 Class Initialized
INFO - 2022-06-24 10:48:38 --> URI Class Initialized
INFO - 2022-06-24 10:48:38 --> Router Class Initialized
INFO - 2022-06-24 10:48:38 --> Output Class Initialized
INFO - 2022-06-24 10:48:38 --> Security Class Initialized
DEBUG - 2022-06-24 10:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:48:38 --> Input Class Initialized
INFO - 2022-06-24 10:48:38 --> Language Class Initialized
INFO - 2022-06-24 10:48:38 --> Loader Class Initialized
INFO - 2022-06-24 10:48:38 --> Helper loaded: url_helper
INFO - 2022-06-24 10:48:38 --> Helper loaded: file_helper
INFO - 2022-06-24 10:48:38 --> Database Driver Class Initialized
INFO - 2022-06-24 10:48:38 --> Email Class Initialized
DEBUG - 2022-06-24 10:48:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:48:38 --> Controller Class Initialized
INFO - 2022-06-24 10:48:38 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:48:38 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:48:38 --> Config Class Initialized
INFO - 2022-06-24 10:48:38 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:48:38 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:48:38 --> Utf8 Class Initialized
INFO - 2022-06-24 10:48:38 --> URI Class Initialized
INFO - 2022-06-24 10:48:38 --> Router Class Initialized
INFO - 2022-06-24 10:48:38 --> Output Class Initialized
INFO - 2022-06-24 10:48:38 --> Security Class Initialized
DEBUG - 2022-06-24 10:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:48:38 --> Input Class Initialized
INFO - 2022-06-24 10:48:38 --> Language Class Initialized
INFO - 2022-06-24 10:48:38 --> Loader Class Initialized
INFO - 2022-06-24 10:48:38 --> Helper loaded: url_helper
INFO - 2022-06-24 10:48:38 --> Helper loaded: file_helper
INFO - 2022-06-24 10:48:38 --> Database Driver Class Initialized
INFO - 2022-06-24 10:48:38 --> Email Class Initialized
DEBUG - 2022-06-24 10:48:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:48:38 --> Controller Class Initialized
INFO - 2022-06-24 10:48:38 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:48:38 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:48:38 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 10:48:38 --> Final output sent to browser
DEBUG - 2022-06-24 10:48:38 --> Total execution time: 0.0305
INFO - 2022-06-24 10:48:43 --> Config Class Initialized
INFO - 2022-06-24 10:48:43 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:48:43 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:48:43 --> Utf8 Class Initialized
INFO - 2022-06-24 10:48:43 --> URI Class Initialized
INFO - 2022-06-24 10:48:43 --> Router Class Initialized
INFO - 2022-06-24 10:48:43 --> Output Class Initialized
INFO - 2022-06-24 10:48:43 --> Security Class Initialized
DEBUG - 2022-06-24 10:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:48:43 --> Input Class Initialized
INFO - 2022-06-24 10:48:43 --> Language Class Initialized
INFO - 2022-06-24 10:48:43 --> Loader Class Initialized
INFO - 2022-06-24 10:48:43 --> Helper loaded: url_helper
INFO - 2022-06-24 10:48:43 --> Helper loaded: file_helper
INFO - 2022-06-24 10:48:43 --> Database Driver Class Initialized
INFO - 2022-06-24 10:48:43 --> Email Class Initialized
DEBUG - 2022-06-24 10:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:48:43 --> Controller Class Initialized
INFO - 2022-06-24 10:48:43 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:48:43 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:49:31 --> Config Class Initialized
INFO - 2022-06-24 10:49:31 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:49:31 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:49:31 --> Utf8 Class Initialized
INFO - 2022-06-24 10:49:31 --> URI Class Initialized
INFO - 2022-06-24 10:49:31 --> Router Class Initialized
INFO - 2022-06-24 10:49:31 --> Output Class Initialized
INFO - 2022-06-24 10:49:31 --> Security Class Initialized
DEBUG - 2022-06-24 10:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:49:31 --> Input Class Initialized
INFO - 2022-06-24 10:49:31 --> Language Class Initialized
INFO - 2022-06-24 10:49:31 --> Loader Class Initialized
INFO - 2022-06-24 10:49:31 --> Helper loaded: url_helper
INFO - 2022-06-24 10:49:31 --> Helper loaded: file_helper
INFO - 2022-06-24 10:49:31 --> Database Driver Class Initialized
INFO - 2022-06-24 10:49:31 --> Email Class Initialized
DEBUG - 2022-06-24 10:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:49:31 --> Controller Class Initialized
INFO - 2022-06-24 10:49:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:49:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:49:31 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 10:49:31 --> Final output sent to browser
DEBUG - 2022-06-24 10:49:31 --> Total execution time: 0.1630
INFO - 2022-06-24 10:49:38 --> Config Class Initialized
INFO - 2022-06-24 10:49:38 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:49:38 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:49:38 --> Utf8 Class Initialized
INFO - 2022-06-24 10:49:38 --> URI Class Initialized
INFO - 2022-06-24 10:49:38 --> Router Class Initialized
INFO - 2022-06-24 10:49:38 --> Output Class Initialized
INFO - 2022-06-24 10:49:38 --> Security Class Initialized
DEBUG - 2022-06-24 10:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:49:38 --> Input Class Initialized
INFO - 2022-06-24 10:49:38 --> Language Class Initialized
INFO - 2022-06-24 10:49:38 --> Loader Class Initialized
INFO - 2022-06-24 10:49:38 --> Helper loaded: url_helper
INFO - 2022-06-24 10:49:38 --> Helper loaded: file_helper
INFO - 2022-06-24 10:49:38 --> Database Driver Class Initialized
INFO - 2022-06-24 10:49:38 --> Email Class Initialized
DEBUG - 2022-06-24 10:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:49:38 --> Controller Class Initialized
INFO - 2022-06-24 10:49:38 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:49:38 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:49:38 --> Config Class Initialized
INFO - 2022-06-24 10:49:38 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:49:38 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:49:38 --> Utf8 Class Initialized
INFO - 2022-06-24 10:49:38 --> URI Class Initialized
INFO - 2022-06-24 10:49:38 --> Router Class Initialized
INFO - 2022-06-24 10:49:38 --> Output Class Initialized
INFO - 2022-06-24 10:49:38 --> Security Class Initialized
DEBUG - 2022-06-24 10:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:49:38 --> Input Class Initialized
INFO - 2022-06-24 10:49:38 --> Language Class Initialized
INFO - 2022-06-24 10:49:38 --> Loader Class Initialized
INFO - 2022-06-24 10:49:38 --> Helper loaded: url_helper
INFO - 2022-06-24 10:49:38 --> Helper loaded: file_helper
INFO - 2022-06-24 10:49:38 --> Database Driver Class Initialized
INFO - 2022-06-24 10:49:38 --> Email Class Initialized
DEBUG - 2022-06-24 10:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:49:38 --> Controller Class Initialized
INFO - 2022-06-24 10:49:38 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:49:38 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:49:38 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 10:49:38 --> Final output sent to browser
DEBUG - 2022-06-24 10:49:38 --> Total execution time: 0.0312
INFO - 2022-06-24 10:49:42 --> Config Class Initialized
INFO - 2022-06-24 10:49:42 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:49:42 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:49:42 --> Utf8 Class Initialized
INFO - 2022-06-24 10:49:42 --> URI Class Initialized
INFO - 2022-06-24 10:49:42 --> Router Class Initialized
INFO - 2022-06-24 10:49:42 --> Output Class Initialized
INFO - 2022-06-24 10:49:42 --> Security Class Initialized
DEBUG - 2022-06-24 10:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:49:42 --> Input Class Initialized
INFO - 2022-06-24 10:49:42 --> Language Class Initialized
INFO - 2022-06-24 10:49:42 --> Loader Class Initialized
INFO - 2022-06-24 10:49:42 --> Helper loaded: url_helper
INFO - 2022-06-24 10:49:42 --> Helper loaded: file_helper
INFO - 2022-06-24 10:49:42 --> Database Driver Class Initialized
INFO - 2022-06-24 10:49:42 --> Email Class Initialized
DEBUG - 2022-06-24 10:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:49:42 --> Controller Class Initialized
INFO - 2022-06-24 10:49:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:49:42 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:52:31 --> Config Class Initialized
INFO - 2022-06-24 10:52:31 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:52:31 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:52:31 --> Utf8 Class Initialized
INFO - 2022-06-24 10:52:31 --> URI Class Initialized
INFO - 2022-06-24 10:52:31 --> Router Class Initialized
INFO - 2022-06-24 10:52:31 --> Output Class Initialized
INFO - 2022-06-24 10:52:31 --> Security Class Initialized
DEBUG - 2022-06-24 10:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:52:31 --> Input Class Initialized
INFO - 2022-06-24 10:52:31 --> Language Class Initialized
INFO - 2022-06-24 10:52:31 --> Loader Class Initialized
INFO - 2022-06-24 10:52:31 --> Helper loaded: url_helper
INFO - 2022-06-24 10:52:31 --> Helper loaded: file_helper
INFO - 2022-06-24 10:52:31 --> Database Driver Class Initialized
INFO - 2022-06-24 10:52:31 --> Email Class Initialized
DEBUG - 2022-06-24 10:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:52:31 --> Controller Class Initialized
INFO - 2022-06-24 10:52:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:52:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:52:34 --> Config Class Initialized
INFO - 2022-06-24 10:52:34 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:52:34 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:52:34 --> Utf8 Class Initialized
INFO - 2022-06-24 10:52:34 --> URI Class Initialized
INFO - 2022-06-24 10:52:34 --> Router Class Initialized
INFO - 2022-06-24 10:52:34 --> Output Class Initialized
INFO - 2022-06-24 10:52:34 --> Security Class Initialized
DEBUG - 2022-06-24 10:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:52:34 --> Input Class Initialized
INFO - 2022-06-24 10:52:34 --> Language Class Initialized
INFO - 2022-06-24 10:52:34 --> Loader Class Initialized
INFO - 2022-06-24 10:52:34 --> Helper loaded: url_helper
INFO - 2022-06-24 10:52:34 --> Helper loaded: file_helper
INFO - 2022-06-24 10:52:34 --> Database Driver Class Initialized
INFO - 2022-06-24 10:52:34 --> Email Class Initialized
DEBUG - 2022-06-24 10:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:52:34 --> Controller Class Initialized
INFO - 2022-06-24 10:52:34 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:52:34 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:52:39 --> Config Class Initialized
INFO - 2022-06-24 10:52:39 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:52:39 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:52:39 --> Utf8 Class Initialized
INFO - 2022-06-24 10:52:39 --> URI Class Initialized
INFO - 2022-06-24 10:52:39 --> Router Class Initialized
INFO - 2022-06-24 10:52:39 --> Output Class Initialized
INFO - 2022-06-24 10:52:39 --> Security Class Initialized
DEBUG - 2022-06-24 10:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:52:39 --> Input Class Initialized
INFO - 2022-06-24 10:52:39 --> Language Class Initialized
INFO - 2022-06-24 10:52:39 --> Loader Class Initialized
INFO - 2022-06-24 10:52:39 --> Helper loaded: url_helper
INFO - 2022-06-24 10:52:39 --> Helper loaded: file_helper
INFO - 2022-06-24 10:52:39 --> Database Driver Class Initialized
INFO - 2022-06-24 10:52:39 --> Email Class Initialized
DEBUG - 2022-06-24 10:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:52:39 --> Controller Class Initialized
INFO - 2022-06-24 10:52:39 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:52:39 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:52:39 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 10:52:39 --> Final output sent to browser
DEBUG - 2022-06-24 10:52:39 --> Total execution time: 0.0320
INFO - 2022-06-24 10:52:47 --> Config Class Initialized
INFO - 2022-06-24 10:52:47 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:52:47 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:52:47 --> Utf8 Class Initialized
INFO - 2022-06-24 10:52:47 --> URI Class Initialized
INFO - 2022-06-24 10:52:47 --> Config Class Initialized
INFO - 2022-06-24 10:52:47 --> Hooks Class Initialized
INFO - 2022-06-24 10:52:47 --> Router Class Initialized
DEBUG - 2022-06-24 10:52:47 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:52:47 --> Output Class Initialized
INFO - 2022-06-24 10:52:47 --> Utf8 Class Initialized
INFO - 2022-06-24 10:52:47 --> Security Class Initialized
INFO - 2022-06-24 10:52:47 --> URI Class Initialized
DEBUG - 2022-06-24 10:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:52:47 --> Input Class Initialized
INFO - 2022-06-24 10:52:47 --> Router Class Initialized
INFO - 2022-06-24 10:52:47 --> Language Class Initialized
INFO - 2022-06-24 10:52:47 --> Output Class Initialized
INFO - 2022-06-24 10:52:47 --> Loader Class Initialized
INFO - 2022-06-24 10:52:47 --> Security Class Initialized
DEBUG - 2022-06-24 10:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:52:47 --> Helper loaded: url_helper
INFO - 2022-06-24 10:52:47 --> Input Class Initialized
INFO - 2022-06-24 10:52:47 --> Language Class Initialized
INFO - 2022-06-24 10:52:47 --> Helper loaded: file_helper
INFO - 2022-06-24 10:52:47 --> Loader Class Initialized
INFO - 2022-06-24 10:52:47 --> Database Driver Class Initialized
INFO - 2022-06-24 10:52:47 --> Helper loaded: url_helper
INFO - 2022-06-24 10:52:47 --> Helper loaded: file_helper
INFO - 2022-06-24 10:52:47 --> Email Class Initialized
INFO - 2022-06-24 10:52:47 --> Database Driver Class Initialized
DEBUG - 2022-06-24 10:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:52:47 --> Email Class Initialized
INFO - 2022-06-24 10:52:47 --> Controller Class Initialized
INFO - 2022-06-24 10:52:47 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-24 10:52:47 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:52:47 --> Controller Class Initialized
INFO - 2022-06-24 10:52:47 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:52:47 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:52:47 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 10:52:47 --> Final output sent to browser
DEBUG - 2022-06-24 10:52:47 --> Total execution time: 0.0306
INFO - 2022-06-24 10:52:52 --> Config Class Initialized
INFO - 2022-06-24 10:52:52 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:52:52 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:52:52 --> Utf8 Class Initialized
INFO - 2022-06-24 10:52:52 --> URI Class Initialized
INFO - 2022-06-24 10:52:52 --> Router Class Initialized
INFO - 2022-06-24 10:52:52 --> Output Class Initialized
INFO - 2022-06-24 10:52:52 --> Security Class Initialized
DEBUG - 2022-06-24 10:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:52:52 --> Input Class Initialized
INFO - 2022-06-24 10:52:52 --> Language Class Initialized
INFO - 2022-06-24 10:52:52 --> Loader Class Initialized
INFO - 2022-06-24 10:52:52 --> Helper loaded: url_helper
INFO - 2022-06-24 10:52:52 --> Helper loaded: file_helper
INFO - 2022-06-24 10:52:52 --> Database Driver Class Initialized
INFO - 2022-06-24 10:52:52 --> Email Class Initialized
DEBUG - 2022-06-24 10:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:52:52 --> Controller Class Initialized
INFO - 2022-06-24 10:52:52 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:52:52 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:58:41 --> Config Class Initialized
INFO - 2022-06-24 10:58:41 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:58:41 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:58:41 --> Utf8 Class Initialized
INFO - 2022-06-24 10:58:41 --> URI Class Initialized
INFO - 2022-06-24 10:58:41 --> Router Class Initialized
INFO - 2022-06-24 10:58:41 --> Output Class Initialized
INFO - 2022-06-24 10:58:41 --> Security Class Initialized
DEBUG - 2022-06-24 10:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:58:41 --> Input Class Initialized
INFO - 2022-06-24 10:58:41 --> Language Class Initialized
INFO - 2022-06-24 10:58:41 --> Loader Class Initialized
INFO - 2022-06-24 10:58:41 --> Helper loaded: url_helper
INFO - 2022-06-24 10:58:41 --> Helper loaded: file_helper
INFO - 2022-06-24 10:58:41 --> Database Driver Class Initialized
INFO - 2022-06-24 10:58:41 --> Email Class Initialized
DEBUG - 2022-06-24 10:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:58:41 --> Controller Class Initialized
INFO - 2022-06-24 10:58:41 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:58:41 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:58:41 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 10:58:41 --> Final output sent to browser
DEBUG - 2022-06-24 10:58:41 --> Total execution time: 0.0402
INFO - 2022-06-24 10:58:50 --> Config Class Initialized
INFO - 2022-06-24 10:58:50 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:58:50 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:58:50 --> Utf8 Class Initialized
INFO - 2022-06-24 10:58:50 --> URI Class Initialized
INFO - 2022-06-24 10:58:50 --> Router Class Initialized
INFO - 2022-06-24 10:58:50 --> Output Class Initialized
INFO - 2022-06-24 10:58:50 --> Security Class Initialized
DEBUG - 2022-06-24 10:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:58:50 --> Input Class Initialized
INFO - 2022-06-24 10:58:50 --> Language Class Initialized
INFO - 2022-06-24 10:58:50 --> Loader Class Initialized
INFO - 2022-06-24 10:58:50 --> Helper loaded: url_helper
INFO - 2022-06-24 10:58:50 --> Helper loaded: file_helper
INFO - 2022-06-24 10:58:50 --> Database Driver Class Initialized
INFO - 2022-06-24 10:58:50 --> Email Class Initialized
DEBUG - 2022-06-24 10:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:58:50 --> Controller Class Initialized
INFO - 2022-06-24 10:58:50 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:58:50 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:58:50 --> Config Class Initialized
INFO - 2022-06-24 10:58:50 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:58:50 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:58:50 --> Utf8 Class Initialized
INFO - 2022-06-24 10:58:50 --> URI Class Initialized
INFO - 2022-06-24 10:58:50 --> Router Class Initialized
INFO - 2022-06-24 10:58:50 --> Output Class Initialized
INFO - 2022-06-24 10:58:50 --> Security Class Initialized
DEBUG - 2022-06-24 10:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:58:50 --> Input Class Initialized
INFO - 2022-06-24 10:58:50 --> Language Class Initialized
INFO - 2022-06-24 10:58:50 --> Loader Class Initialized
INFO - 2022-06-24 10:58:50 --> Helper loaded: url_helper
INFO - 2022-06-24 10:58:50 --> Helper loaded: file_helper
INFO - 2022-06-24 10:58:50 --> Database Driver Class Initialized
INFO - 2022-06-24 10:58:50 --> Email Class Initialized
DEBUG - 2022-06-24 10:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:58:50 --> Controller Class Initialized
INFO - 2022-06-24 10:58:50 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:58:50 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:58:50 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 10:58:50 --> Final output sent to browser
DEBUG - 2022-06-24 10:58:50 --> Total execution time: 0.0370
INFO - 2022-06-24 10:58:54 --> Config Class Initialized
INFO - 2022-06-24 10:58:54 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:58:54 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:58:54 --> Utf8 Class Initialized
INFO - 2022-06-24 10:58:54 --> URI Class Initialized
INFO - 2022-06-24 10:58:54 --> Router Class Initialized
INFO - 2022-06-24 10:58:54 --> Output Class Initialized
INFO - 2022-06-24 10:58:54 --> Security Class Initialized
DEBUG - 2022-06-24 10:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:58:54 --> Input Class Initialized
INFO - 2022-06-24 10:58:54 --> Language Class Initialized
INFO - 2022-06-24 10:58:54 --> Loader Class Initialized
INFO - 2022-06-24 10:58:54 --> Helper loaded: url_helper
INFO - 2022-06-24 10:58:54 --> Helper loaded: file_helper
INFO - 2022-06-24 10:58:54 --> Database Driver Class Initialized
INFO - 2022-06-24 10:58:54 --> Email Class Initialized
DEBUG - 2022-06-24 10:58:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:58:54 --> Controller Class Initialized
INFO - 2022-06-24 10:58:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:58:54 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 10:59:53 --> Config Class Initialized
INFO - 2022-06-24 10:59:53 --> Hooks Class Initialized
DEBUG - 2022-06-24 10:59:53 --> UTF-8 Support Enabled
INFO - 2022-06-24 10:59:53 --> Utf8 Class Initialized
INFO - 2022-06-24 10:59:53 --> URI Class Initialized
INFO - 2022-06-24 10:59:53 --> Router Class Initialized
INFO - 2022-06-24 10:59:53 --> Output Class Initialized
INFO - 2022-06-24 10:59:53 --> Security Class Initialized
DEBUG - 2022-06-24 10:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 10:59:53 --> Input Class Initialized
INFO - 2022-06-24 10:59:53 --> Language Class Initialized
INFO - 2022-06-24 10:59:53 --> Loader Class Initialized
INFO - 2022-06-24 10:59:53 --> Helper loaded: url_helper
INFO - 2022-06-24 10:59:53 --> Helper loaded: file_helper
INFO - 2022-06-24 10:59:53 --> Database Driver Class Initialized
INFO - 2022-06-24 10:59:53 --> Email Class Initialized
DEBUG - 2022-06-24 10:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 10:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 10:59:53 --> Controller Class Initialized
INFO - 2022-06-24 10:59:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 10:59:53 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:01:19 --> Config Class Initialized
INFO - 2022-06-24 11:01:19 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:01:19 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:01:19 --> Utf8 Class Initialized
INFO - 2022-06-24 11:01:19 --> URI Class Initialized
INFO - 2022-06-24 11:01:19 --> Router Class Initialized
INFO - 2022-06-24 11:01:19 --> Output Class Initialized
INFO - 2022-06-24 11:01:19 --> Security Class Initialized
DEBUG - 2022-06-24 11:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:01:19 --> Input Class Initialized
INFO - 2022-06-24 11:01:19 --> Language Class Initialized
INFO - 2022-06-24 11:01:19 --> Loader Class Initialized
INFO - 2022-06-24 11:01:19 --> Helper loaded: url_helper
INFO - 2022-06-24 11:01:19 --> Helper loaded: file_helper
INFO - 2022-06-24 11:01:19 --> Database Driver Class Initialized
INFO - 2022-06-24 11:01:19 --> Email Class Initialized
DEBUG - 2022-06-24 11:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:01:19 --> Controller Class Initialized
INFO - 2022-06-24 11:01:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:01:19 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:04:16 --> Config Class Initialized
INFO - 2022-06-24 11:04:16 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:04:16 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:04:16 --> Utf8 Class Initialized
INFO - 2022-06-24 11:04:16 --> URI Class Initialized
INFO - 2022-06-24 11:04:16 --> Router Class Initialized
INFO - 2022-06-24 11:04:16 --> Output Class Initialized
INFO - 2022-06-24 11:04:16 --> Security Class Initialized
DEBUG - 2022-06-24 11:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:04:16 --> Input Class Initialized
INFO - 2022-06-24 11:04:16 --> Language Class Initialized
INFO - 2022-06-24 11:04:16 --> Loader Class Initialized
INFO - 2022-06-24 11:04:16 --> Helper loaded: url_helper
INFO - 2022-06-24 11:04:16 --> Helper loaded: file_helper
INFO - 2022-06-24 11:04:16 --> Database Driver Class Initialized
INFO - 2022-06-24 11:04:16 --> Email Class Initialized
DEBUG - 2022-06-24 11:04:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:04:16 --> Controller Class Initialized
INFO - 2022-06-24 11:04:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:04:16 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:04:36 --> Config Class Initialized
INFO - 2022-06-24 11:04:36 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:04:36 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:04:36 --> Utf8 Class Initialized
INFO - 2022-06-24 11:04:36 --> URI Class Initialized
INFO - 2022-06-24 11:04:36 --> Router Class Initialized
INFO - 2022-06-24 11:04:36 --> Output Class Initialized
INFO - 2022-06-24 11:04:36 --> Security Class Initialized
DEBUG - 2022-06-24 11:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:04:36 --> Input Class Initialized
INFO - 2022-06-24 11:04:36 --> Language Class Initialized
INFO - 2022-06-24 11:04:36 --> Loader Class Initialized
INFO - 2022-06-24 11:04:36 --> Helper loaded: url_helper
INFO - 2022-06-24 11:04:36 --> Helper loaded: file_helper
INFO - 2022-06-24 11:04:36 --> Database Driver Class Initialized
INFO - 2022-06-24 11:04:36 --> Email Class Initialized
DEBUG - 2022-06-24 11:04:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:04:36 --> Controller Class Initialized
INFO - 2022-06-24 11:04:36 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:04:36 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:04:36 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 11:04:36 --> Final output sent to browser
DEBUG - 2022-06-24 11:04:36 --> Total execution time: 0.0303
INFO - 2022-06-24 11:04:43 --> Config Class Initialized
INFO - 2022-06-24 11:04:43 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:04:43 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:04:43 --> Utf8 Class Initialized
INFO - 2022-06-24 11:04:43 --> URI Class Initialized
INFO - 2022-06-24 11:04:43 --> Router Class Initialized
INFO - 2022-06-24 11:04:43 --> Output Class Initialized
INFO - 2022-06-24 11:04:43 --> Security Class Initialized
DEBUG - 2022-06-24 11:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:04:43 --> Input Class Initialized
INFO - 2022-06-24 11:04:43 --> Language Class Initialized
INFO - 2022-06-24 11:04:43 --> Loader Class Initialized
INFO - 2022-06-24 11:04:43 --> Helper loaded: url_helper
INFO - 2022-06-24 11:04:43 --> Helper loaded: file_helper
INFO - 2022-06-24 11:04:43 --> Database Driver Class Initialized
INFO - 2022-06-24 11:04:43 --> Email Class Initialized
DEBUG - 2022-06-24 11:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:04:43 --> Controller Class Initialized
INFO - 2022-06-24 11:04:43 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:04:43 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:04:43 --> Config Class Initialized
INFO - 2022-06-24 11:04:43 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:04:43 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:04:43 --> Utf8 Class Initialized
INFO - 2022-06-24 11:04:43 --> URI Class Initialized
INFO - 2022-06-24 11:04:43 --> Router Class Initialized
INFO - 2022-06-24 11:04:43 --> Output Class Initialized
INFO - 2022-06-24 11:04:43 --> Security Class Initialized
DEBUG - 2022-06-24 11:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:04:43 --> Input Class Initialized
INFO - 2022-06-24 11:04:43 --> Language Class Initialized
INFO - 2022-06-24 11:04:43 --> Loader Class Initialized
INFO - 2022-06-24 11:04:43 --> Helper loaded: url_helper
INFO - 2022-06-24 11:04:43 --> Helper loaded: file_helper
INFO - 2022-06-24 11:04:43 --> Database Driver Class Initialized
INFO - 2022-06-24 11:04:43 --> Email Class Initialized
DEBUG - 2022-06-24 11:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:04:43 --> Controller Class Initialized
INFO - 2022-06-24 11:04:43 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:04:43 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:04:43 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 11:04:43 --> Final output sent to browser
DEBUG - 2022-06-24 11:04:43 --> Total execution time: 0.0340
INFO - 2022-06-24 11:04:50 --> Config Class Initialized
INFO - 2022-06-24 11:04:50 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:04:50 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:04:50 --> Utf8 Class Initialized
INFO - 2022-06-24 11:04:50 --> URI Class Initialized
INFO - 2022-06-24 11:04:50 --> Router Class Initialized
INFO - 2022-06-24 11:04:50 --> Output Class Initialized
INFO - 2022-06-24 11:04:50 --> Security Class Initialized
DEBUG - 2022-06-24 11:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:04:50 --> Input Class Initialized
INFO - 2022-06-24 11:04:50 --> Language Class Initialized
INFO - 2022-06-24 11:04:50 --> Loader Class Initialized
INFO - 2022-06-24 11:04:50 --> Helper loaded: url_helper
INFO - 2022-06-24 11:04:50 --> Helper loaded: file_helper
INFO - 2022-06-24 11:04:50 --> Database Driver Class Initialized
INFO - 2022-06-24 11:04:50 --> Email Class Initialized
DEBUG - 2022-06-24 11:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:04:50 --> Controller Class Initialized
INFO - 2022-06-24 11:04:50 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:04:50 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:05:08 --> Config Class Initialized
INFO - 2022-06-24 11:05:08 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:05:08 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:05:08 --> Utf8 Class Initialized
INFO - 2022-06-24 11:05:08 --> URI Class Initialized
INFO - 2022-06-24 11:05:08 --> Router Class Initialized
INFO - 2022-06-24 11:05:08 --> Output Class Initialized
INFO - 2022-06-24 11:05:08 --> Security Class Initialized
DEBUG - 2022-06-24 11:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:05:08 --> Input Class Initialized
INFO - 2022-06-24 11:05:08 --> Language Class Initialized
INFO - 2022-06-24 11:05:08 --> Loader Class Initialized
INFO - 2022-06-24 11:05:08 --> Helper loaded: url_helper
INFO - 2022-06-24 11:05:08 --> Helper loaded: file_helper
INFO - 2022-06-24 11:05:08 --> Database Driver Class Initialized
INFO - 2022-06-24 11:05:08 --> Email Class Initialized
DEBUG - 2022-06-24 11:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:05:08 --> Controller Class Initialized
INFO - 2022-06-24 11:05:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:05:08 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:05:42 --> Config Class Initialized
INFO - 2022-06-24 11:05:42 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:05:42 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:05:42 --> Utf8 Class Initialized
INFO - 2022-06-24 11:05:42 --> URI Class Initialized
INFO - 2022-06-24 11:05:42 --> Router Class Initialized
INFO - 2022-06-24 11:05:42 --> Output Class Initialized
INFO - 2022-06-24 11:05:42 --> Security Class Initialized
DEBUG - 2022-06-24 11:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:05:42 --> Input Class Initialized
INFO - 2022-06-24 11:05:42 --> Language Class Initialized
INFO - 2022-06-24 11:05:42 --> Loader Class Initialized
INFO - 2022-06-24 11:05:42 --> Helper loaded: url_helper
INFO - 2022-06-24 11:05:42 --> Helper loaded: file_helper
INFO - 2022-06-24 11:05:42 --> Database Driver Class Initialized
INFO - 2022-06-24 11:05:42 --> Email Class Initialized
DEBUG - 2022-06-24 11:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:05:42 --> Controller Class Initialized
INFO - 2022-06-24 11:05:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:05:42 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:05:42 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 11:05:42 --> Final output sent to browser
DEBUG - 2022-06-24 11:05:42 --> Total execution time: 0.0335
INFO - 2022-06-24 11:05:51 --> Config Class Initialized
INFO - 2022-06-24 11:05:51 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:05:51 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:05:51 --> Utf8 Class Initialized
INFO - 2022-06-24 11:05:51 --> URI Class Initialized
INFO - 2022-06-24 11:05:51 --> Router Class Initialized
INFO - 2022-06-24 11:05:51 --> Output Class Initialized
INFO - 2022-06-24 11:05:51 --> Security Class Initialized
DEBUG - 2022-06-24 11:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:05:51 --> Input Class Initialized
INFO - 2022-06-24 11:05:51 --> Language Class Initialized
INFO - 2022-06-24 11:05:51 --> Loader Class Initialized
INFO - 2022-06-24 11:05:51 --> Helper loaded: url_helper
INFO - 2022-06-24 11:05:51 --> Helper loaded: file_helper
INFO - 2022-06-24 11:05:51 --> Database Driver Class Initialized
INFO - 2022-06-24 11:05:51 --> Email Class Initialized
DEBUG - 2022-06-24 11:05:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:05:51 --> Controller Class Initialized
INFO - 2022-06-24 11:05:51 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:05:51 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:05:51 --> Config Class Initialized
INFO - 2022-06-24 11:05:51 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:05:51 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:05:51 --> Utf8 Class Initialized
INFO - 2022-06-24 11:05:51 --> URI Class Initialized
INFO - 2022-06-24 11:05:51 --> Router Class Initialized
INFO - 2022-06-24 11:05:51 --> Output Class Initialized
INFO - 2022-06-24 11:05:51 --> Security Class Initialized
DEBUG - 2022-06-24 11:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:05:51 --> Input Class Initialized
INFO - 2022-06-24 11:05:51 --> Language Class Initialized
INFO - 2022-06-24 11:05:51 --> Loader Class Initialized
INFO - 2022-06-24 11:05:51 --> Helper loaded: url_helper
INFO - 2022-06-24 11:05:51 --> Helper loaded: file_helper
INFO - 2022-06-24 11:05:51 --> Database Driver Class Initialized
INFO - 2022-06-24 11:05:51 --> Email Class Initialized
DEBUG - 2022-06-24 11:05:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:05:51 --> Controller Class Initialized
INFO - 2022-06-24 11:05:51 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:05:51 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:05:51 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 11:05:51 --> Final output sent to browser
DEBUG - 2022-06-24 11:05:51 --> Total execution time: 0.0246
INFO - 2022-06-24 11:05:59 --> Config Class Initialized
INFO - 2022-06-24 11:05:59 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:05:59 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:05:59 --> Utf8 Class Initialized
INFO - 2022-06-24 11:05:59 --> URI Class Initialized
INFO - 2022-06-24 11:05:59 --> Router Class Initialized
INFO - 2022-06-24 11:05:59 --> Output Class Initialized
INFO - 2022-06-24 11:05:59 --> Security Class Initialized
DEBUG - 2022-06-24 11:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:05:59 --> Input Class Initialized
INFO - 2022-06-24 11:05:59 --> Language Class Initialized
INFO - 2022-06-24 11:05:59 --> Loader Class Initialized
INFO - 2022-06-24 11:05:59 --> Helper loaded: url_helper
INFO - 2022-06-24 11:05:59 --> Helper loaded: file_helper
INFO - 2022-06-24 11:05:59 --> Database Driver Class Initialized
INFO - 2022-06-24 11:05:59 --> Email Class Initialized
DEBUG - 2022-06-24 11:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:05:59 --> Controller Class Initialized
INFO - 2022-06-24 11:05:59 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:05:59 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:07:27 --> Config Class Initialized
INFO - 2022-06-24 11:07:27 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:07:27 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:07:27 --> Utf8 Class Initialized
INFO - 2022-06-24 11:07:27 --> URI Class Initialized
INFO - 2022-06-24 11:07:27 --> Router Class Initialized
INFO - 2022-06-24 11:07:27 --> Output Class Initialized
INFO - 2022-06-24 11:07:27 --> Security Class Initialized
DEBUG - 2022-06-24 11:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:07:27 --> Input Class Initialized
INFO - 2022-06-24 11:07:27 --> Language Class Initialized
INFO - 2022-06-24 11:07:27 --> Loader Class Initialized
INFO - 2022-06-24 11:07:27 --> Helper loaded: url_helper
INFO - 2022-06-24 11:07:27 --> Helper loaded: file_helper
INFO - 2022-06-24 11:07:27 --> Database Driver Class Initialized
INFO - 2022-06-24 11:07:27 --> Email Class Initialized
DEBUG - 2022-06-24 11:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:07:27 --> Controller Class Initialized
INFO - 2022-06-24 11:07:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:07:27 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:07:27 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-24 11:07:27 --> Final output sent to browser
DEBUG - 2022-06-24 11:07:27 --> Total execution time: 0.1417
INFO - 2022-06-24 11:07:30 --> Config Class Initialized
INFO - 2022-06-24 11:07:30 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:07:30 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:07:30 --> Utf8 Class Initialized
INFO - 2022-06-24 11:07:30 --> URI Class Initialized
INFO - 2022-06-24 11:07:30 --> Router Class Initialized
INFO - 2022-06-24 11:07:30 --> Output Class Initialized
INFO - 2022-06-24 11:07:30 --> Security Class Initialized
DEBUG - 2022-06-24 11:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:07:30 --> Input Class Initialized
INFO - 2022-06-24 11:07:30 --> Language Class Initialized
INFO - 2022-06-24 11:07:30 --> Loader Class Initialized
INFO - 2022-06-24 11:07:30 --> Helper loaded: url_helper
INFO - 2022-06-24 11:07:30 --> Helper loaded: file_helper
INFO - 2022-06-24 11:07:30 --> Database Driver Class Initialized
INFO - 2022-06-24 11:07:30 --> Email Class Initialized
DEBUG - 2022-06-24 11:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:07:30 --> Controller Class Initialized
INFO - 2022-06-24 11:07:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:07:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:07:30 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-24 11:07:30 --> Final output sent to browser
DEBUG - 2022-06-24 11:07:30 --> Total execution time: 0.0439
INFO - 2022-06-24 11:07:46 --> Config Class Initialized
INFO - 2022-06-24 11:07:46 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:07:46 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:07:46 --> Utf8 Class Initialized
INFO - 2022-06-24 11:07:46 --> URI Class Initialized
INFO - 2022-06-24 11:07:46 --> Router Class Initialized
INFO - 2022-06-24 11:07:46 --> Output Class Initialized
INFO - 2022-06-24 11:07:46 --> Security Class Initialized
DEBUG - 2022-06-24 11:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:07:46 --> Input Class Initialized
INFO - 2022-06-24 11:07:46 --> Language Class Initialized
INFO - 2022-06-24 11:07:46 --> Loader Class Initialized
INFO - 2022-06-24 11:07:46 --> Helper loaded: url_helper
INFO - 2022-06-24 11:07:46 --> Helper loaded: file_helper
INFO - 2022-06-24 11:07:46 --> Database Driver Class Initialized
INFO - 2022-06-24 11:07:46 --> Email Class Initialized
DEBUG - 2022-06-24 11:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:07:46 --> Controller Class Initialized
INFO - 2022-06-24 11:07:46 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:07:46 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:07:46 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-24 11:07:46 --> Final output sent to browser
DEBUG - 2022-06-24 11:07:46 --> Total execution time: 0.1237
INFO - 2022-06-24 11:08:20 --> Config Class Initialized
INFO - 2022-06-24 11:08:20 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:08:20 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:08:20 --> Utf8 Class Initialized
INFO - 2022-06-24 11:08:20 --> URI Class Initialized
INFO - 2022-06-24 11:08:20 --> Router Class Initialized
INFO - 2022-06-24 11:08:20 --> Output Class Initialized
INFO - 2022-06-24 11:08:20 --> Security Class Initialized
DEBUG - 2022-06-24 11:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:08:20 --> Input Class Initialized
INFO - 2022-06-24 11:08:20 --> Language Class Initialized
INFO - 2022-06-24 11:08:20 --> Loader Class Initialized
INFO - 2022-06-24 11:08:20 --> Helper loaded: url_helper
INFO - 2022-06-24 11:08:20 --> Helper loaded: file_helper
INFO - 2022-06-24 11:08:20 --> Database Driver Class Initialized
INFO - 2022-06-24 11:08:20 --> Email Class Initialized
DEBUG - 2022-06-24 11:08:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:08:20 --> Controller Class Initialized
INFO - 2022-06-24 11:08:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:08:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 11:08:20 --> test
INFO - 2022-06-24 11:08:20 --> Final output sent to browser
DEBUG - 2022-06-24 11:08:20 --> Total execution time: 0.0332
INFO - 2022-06-24 11:08:20 --> Config Class Initialized
INFO - 2022-06-24 11:08:20 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:08:20 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:08:20 --> Utf8 Class Initialized
INFO - 2022-06-24 11:08:20 --> URI Class Initialized
INFO - 2022-06-24 11:08:20 --> Router Class Initialized
INFO - 2022-06-24 11:08:20 --> Output Class Initialized
INFO - 2022-06-24 11:08:20 --> Security Class Initialized
DEBUG - 2022-06-24 11:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:08:20 --> Input Class Initialized
INFO - 2022-06-24 11:08:20 --> Language Class Initialized
INFO - 2022-06-24 11:08:20 --> Loader Class Initialized
INFO - 2022-06-24 11:08:20 --> Helper loaded: url_helper
INFO - 2022-06-24 11:08:20 --> Helper loaded: file_helper
INFO - 2022-06-24 11:08:20 --> Database Driver Class Initialized
INFO - 2022-06-24 11:08:20 --> Config Class Initialized
INFO - 2022-06-24 11:08:20 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:08:20 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:08:20 --> Utf8 Class Initialized
INFO - 2022-06-24 11:08:20 --> URI Class Initialized
INFO - 2022-06-24 11:08:20 --> Email Class Initialized
INFO - 2022-06-24 11:08:20 --> Router Class Initialized
DEBUG - 2022-06-24 11:08:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:08:20 --> Output Class Initialized
INFO - 2022-06-24 11:08:20 --> Security Class Initialized
INFO - 2022-06-24 11:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:08:20 --> Controller Class Initialized
DEBUG - 2022-06-24 11:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:08:20 --> Input Class Initialized
INFO - 2022-06-24 11:08:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:08:20 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:08:20 --> Language Class Initialized
INFO - 2022-06-24 11:08:20 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-24 11:08:20 --> Final output sent to browser
INFO - 2022-06-24 11:08:20 --> Loader Class Initialized
DEBUG - 2022-06-24 11:08:20 --> Total execution time: 0.0343
INFO - 2022-06-24 11:08:20 --> Helper loaded: url_helper
INFO - 2022-06-24 11:08:20 --> Helper loaded: file_helper
INFO - 2022-06-24 11:08:20 --> Database Driver Class Initialized
INFO - 2022-06-24 11:08:20 --> Email Class Initialized
DEBUG - 2022-06-24 11:08:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:08:20 --> Controller Class Initialized
INFO - 2022-06-24 11:08:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:08:20 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:08:20 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 11:08:20 --> Final output sent to browser
DEBUG - 2022-06-24 11:08:20 --> Total execution time: 0.0310
INFO - 2022-06-24 11:08:52 --> Config Class Initialized
INFO - 2022-06-24 11:08:52 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:08:52 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:08:52 --> Utf8 Class Initialized
INFO - 2022-06-24 11:08:52 --> URI Class Initialized
INFO - 2022-06-24 11:08:52 --> Router Class Initialized
INFO - 2022-06-24 11:08:52 --> Output Class Initialized
INFO - 2022-06-24 11:08:52 --> Security Class Initialized
DEBUG - 2022-06-24 11:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:08:52 --> Input Class Initialized
INFO - 2022-06-24 11:08:52 --> Language Class Initialized
INFO - 2022-06-24 11:08:52 --> Loader Class Initialized
INFO - 2022-06-24 11:08:52 --> Helper loaded: url_helper
INFO - 2022-06-24 11:08:52 --> Helper loaded: file_helper
INFO - 2022-06-24 11:08:52 --> Database Driver Class Initialized
INFO - 2022-06-24 11:08:52 --> Config Class Initialized
INFO - 2022-06-24 11:08:52 --> Hooks Class Initialized
INFO - 2022-06-24 11:08:52 --> Email Class Initialized
DEBUG - 2022-06-24 11:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-24 11:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:08:52 --> Utf8 Class Initialized
INFO - 2022-06-24 11:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:08:52 --> Controller Class Initialized
INFO - 2022-06-24 11:08:52 --> URI Class Initialized
INFO - 2022-06-24 11:08:52 --> Model "Tokenmodel" initialized
INFO - 2022-06-24 11:08:52 --> Router Class Initialized
DEBUG - 2022-06-24 11:08:52 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:08:52 --> Output Class Initialized
INFO - 2022-06-24 11:08:52 --> Security Class Initialized
DEBUG - 2022-06-24 11:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:08:52 --> Input Class Initialized
INFO - 2022-06-24 11:08:52 --> Language Class Initialized
INFO - 2022-06-24 11:08:52 --> Loader Class Initialized
INFO - 2022-06-24 11:08:52 --> Helper loaded: url_helper
INFO - 2022-06-24 11:08:52 --> Helper loaded: file_helper
INFO - 2022-06-24 11:08:52 --> Database Driver Class Initialized
INFO - 2022-06-24 11:08:52 --> Email Class Initialized
DEBUG - 2022-06-24 11:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:08:52 --> Controller Class Initialized
INFO - 2022-06-24 11:08:52 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:08:52 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:08:52 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 11:08:52 --> Final output sent to browser
DEBUG - 2022-06-24 11:08:52 --> Total execution time: 0.0379
INFO - 2022-06-24 11:09:00 --> Config Class Initialized
INFO - 2022-06-24 11:09:00 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:09:00 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:09:00 --> Utf8 Class Initialized
INFO - 2022-06-24 11:09:00 --> URI Class Initialized
INFO - 2022-06-24 11:09:00 --> Router Class Initialized
INFO - 2022-06-24 11:09:00 --> Config Class Initialized
INFO - 2022-06-24 11:09:00 --> Output Class Initialized
INFO - 2022-06-24 11:09:00 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:09:00 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:09:00 --> Security Class Initialized
INFO - 2022-06-24 11:09:00 --> Utf8 Class Initialized
INFO - 2022-06-24 11:09:00 --> URI Class Initialized
DEBUG - 2022-06-24 11:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:09:00 --> Router Class Initialized
INFO - 2022-06-24 11:09:00 --> Input Class Initialized
INFO - 2022-06-24 11:09:00 --> Output Class Initialized
INFO - 2022-06-24 11:09:00 --> Language Class Initialized
INFO - 2022-06-24 11:09:00 --> Security Class Initialized
DEBUG - 2022-06-24 11:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:09:00 --> Input Class Initialized
INFO - 2022-06-24 11:09:00 --> Loader Class Initialized
INFO - 2022-06-24 11:09:00 --> Language Class Initialized
INFO - 2022-06-24 11:09:00 --> Loader Class Initialized
INFO - 2022-06-24 11:09:00 --> Helper loaded: url_helper
INFO - 2022-06-24 11:09:00 --> Helper loaded: file_helper
INFO - 2022-06-24 11:09:00 --> Helper loaded: url_helper
INFO - 2022-06-24 11:09:00 --> Helper loaded: file_helper
INFO - 2022-06-24 11:09:00 --> Database Driver Class Initialized
INFO - 2022-06-24 11:09:00 --> Database Driver Class Initialized
INFO - 2022-06-24 11:09:00 --> Email Class Initialized
DEBUG - 2022-06-24 11:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:09:00 --> Controller Class Initialized
INFO - 2022-06-24 11:09:00 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:09:00 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:09:00 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 11:09:00 --> Final output sent to browser
DEBUG - 2022-06-24 11:09:00 --> Total execution time: 0.0299
INFO - 2022-06-24 11:09:00 --> Email Class Initialized
DEBUG - 2022-06-24 11:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:09:00 --> Controller Class Initialized
INFO - 2022-06-24 11:09:00 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:09:00 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:10:02 --> Config Class Initialized
INFO - 2022-06-24 11:10:02 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:10:02 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:10:02 --> Utf8 Class Initialized
INFO - 2022-06-24 11:10:02 --> URI Class Initialized
INFO - 2022-06-24 11:10:02 --> Router Class Initialized
INFO - 2022-06-24 11:10:02 --> Output Class Initialized
INFO - 2022-06-24 11:10:02 --> Security Class Initialized
DEBUG - 2022-06-24 11:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:10:02 --> Input Class Initialized
INFO - 2022-06-24 11:10:02 --> Language Class Initialized
INFO - 2022-06-24 11:10:02 --> Loader Class Initialized
INFO - 2022-06-24 11:10:02 --> Helper loaded: url_helper
INFO - 2022-06-24 11:10:02 --> Helper loaded: file_helper
INFO - 2022-06-24 11:10:02 --> Database Driver Class Initialized
INFO - 2022-06-24 11:10:02 --> Email Class Initialized
DEBUG - 2022-06-24 11:10:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:10:02 --> Controller Class Initialized
INFO - 2022-06-24 11:10:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:10:02 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:10:02 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 11:10:02 --> Final output sent to browser
DEBUG - 2022-06-24 11:10:02 --> Total execution time: 0.0432
INFO - 2022-06-24 11:10:11 --> Config Class Initialized
INFO - 2022-06-24 11:10:11 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:10:11 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:10:11 --> Utf8 Class Initialized
INFO - 2022-06-24 11:10:11 --> URI Class Initialized
INFO - 2022-06-24 11:10:11 --> Router Class Initialized
INFO - 2022-06-24 11:10:11 --> Output Class Initialized
INFO - 2022-06-24 11:10:11 --> Security Class Initialized
DEBUG - 2022-06-24 11:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:10:11 --> Input Class Initialized
INFO - 2022-06-24 11:10:11 --> Language Class Initialized
INFO - 2022-06-24 11:10:11 --> Loader Class Initialized
INFO - 2022-06-24 11:10:11 --> Helper loaded: url_helper
INFO - 2022-06-24 11:10:11 --> Helper loaded: file_helper
INFO - 2022-06-24 11:10:11 --> Database Driver Class Initialized
INFO - 2022-06-24 11:10:11 --> Email Class Initialized
DEBUG - 2022-06-24 11:10:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:10:11 --> Controller Class Initialized
INFO - 2022-06-24 11:10:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:10:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:10:11 --> Config Class Initialized
INFO - 2022-06-24 11:10:11 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:10:11 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:10:11 --> Utf8 Class Initialized
INFO - 2022-06-24 11:10:11 --> URI Class Initialized
INFO - 2022-06-24 11:10:11 --> Router Class Initialized
INFO - 2022-06-24 11:10:11 --> Output Class Initialized
INFO - 2022-06-24 11:10:11 --> Security Class Initialized
DEBUG - 2022-06-24 11:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:10:11 --> Input Class Initialized
INFO - 2022-06-24 11:10:11 --> Language Class Initialized
INFO - 2022-06-24 11:10:11 --> Loader Class Initialized
INFO - 2022-06-24 11:10:11 --> Helper loaded: url_helper
INFO - 2022-06-24 11:10:11 --> Helper loaded: file_helper
INFO - 2022-06-24 11:10:11 --> Database Driver Class Initialized
INFO - 2022-06-24 11:10:11 --> Email Class Initialized
DEBUG - 2022-06-24 11:10:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:10:11 --> Controller Class Initialized
INFO - 2022-06-24 11:10:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:10:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:10:11 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 11:10:11 --> Final output sent to browser
DEBUG - 2022-06-24 11:10:11 --> Total execution time: 0.0330
INFO - 2022-06-24 11:10:25 --> Config Class Initialized
INFO - 2022-06-24 11:10:25 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:10:25 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:10:25 --> Utf8 Class Initialized
INFO - 2022-06-24 11:10:25 --> URI Class Initialized
INFO - 2022-06-24 11:10:25 --> Router Class Initialized
INFO - 2022-06-24 11:10:25 --> Output Class Initialized
INFO - 2022-06-24 11:10:25 --> Security Class Initialized
DEBUG - 2022-06-24 11:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:10:25 --> Input Class Initialized
INFO - 2022-06-24 11:10:25 --> Language Class Initialized
INFO - 2022-06-24 11:10:25 --> Loader Class Initialized
INFO - 2022-06-24 11:10:25 --> Helper loaded: url_helper
INFO - 2022-06-24 11:10:25 --> Helper loaded: file_helper
INFO - 2022-06-24 11:10:25 --> Database Driver Class Initialized
INFO - 2022-06-24 11:10:25 --> Email Class Initialized
DEBUG - 2022-06-24 11:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:10:25 --> Config Class Initialized
INFO - 2022-06-24 11:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:10:25 --> Hooks Class Initialized
INFO - 2022-06-24 11:10:25 --> Controller Class Initialized
INFO - 2022-06-24 11:10:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:10:25 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:10:25 --> Utf8 Class Initialized
DEBUG - 2022-06-24 11:10:25 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:10:25 --> URI Class Initialized
INFO - 2022-06-24 11:10:25 --> Router Class Initialized
INFO - 2022-06-24 11:10:25 --> Output Class Initialized
INFO - 2022-06-24 11:10:25 --> Security Class Initialized
DEBUG - 2022-06-24 11:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:10:25 --> Input Class Initialized
INFO - 2022-06-24 11:10:25 --> Language Class Initialized
INFO - 2022-06-24 11:10:25 --> Loader Class Initialized
INFO - 2022-06-24 11:10:25 --> Helper loaded: url_helper
INFO - 2022-06-24 11:10:25 --> Helper loaded: file_helper
INFO - 2022-06-24 11:10:25 --> Database Driver Class Initialized
INFO - 2022-06-24 11:10:26 --> Email Class Initialized
DEBUG - 2022-06-24 11:10:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:10:26 --> Controller Class Initialized
INFO - 2022-06-24 11:10:26 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:10:26 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:10:26 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 11:10:26 --> Final output sent to browser
DEBUG - 2022-06-24 11:10:26 --> Total execution time: 0.1351
INFO - 2022-06-24 11:10:35 --> Config Class Initialized
INFO - 2022-06-24 11:10:35 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:10:35 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:10:35 --> Utf8 Class Initialized
INFO - 2022-06-24 11:10:35 --> URI Class Initialized
INFO - 2022-06-24 11:10:35 --> Router Class Initialized
INFO - 2022-06-24 11:10:35 --> Output Class Initialized
INFO - 2022-06-24 11:10:35 --> Security Class Initialized
DEBUG - 2022-06-24 11:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:10:35 --> Input Class Initialized
INFO - 2022-06-24 11:10:35 --> Language Class Initialized
INFO - 2022-06-24 11:10:35 --> Loader Class Initialized
INFO - 2022-06-24 11:10:35 --> Helper loaded: url_helper
INFO - 2022-06-24 11:10:35 --> Helper loaded: file_helper
INFO - 2022-06-24 11:10:35 --> Database Driver Class Initialized
INFO - 2022-06-24 11:10:35 --> Email Class Initialized
DEBUG - 2022-06-24 11:10:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:10:35 --> Controller Class Initialized
INFO - 2022-06-24 11:10:35 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:10:35 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:11:15 --> Config Class Initialized
INFO - 2022-06-24 11:11:15 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:11:15 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:11:15 --> Utf8 Class Initialized
INFO - 2022-06-24 11:11:15 --> URI Class Initialized
INFO - 2022-06-24 11:11:15 --> Router Class Initialized
INFO - 2022-06-24 11:11:15 --> Output Class Initialized
INFO - 2022-06-24 11:11:15 --> Security Class Initialized
DEBUG - 2022-06-24 11:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:11:15 --> Input Class Initialized
INFO - 2022-06-24 11:11:15 --> Language Class Initialized
INFO - 2022-06-24 11:11:15 --> Loader Class Initialized
INFO - 2022-06-24 11:11:15 --> Helper loaded: url_helper
INFO - 2022-06-24 11:11:15 --> Helper loaded: file_helper
INFO - 2022-06-24 11:11:15 --> Database Driver Class Initialized
INFO - 2022-06-24 11:11:15 --> Email Class Initialized
DEBUG - 2022-06-24 11:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:11:15 --> Controller Class Initialized
INFO - 2022-06-24 11:11:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:11:15 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:12:19 --> Config Class Initialized
INFO - 2022-06-24 11:12:19 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:12:19 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:12:19 --> Utf8 Class Initialized
INFO - 2022-06-24 11:12:19 --> URI Class Initialized
INFO - 2022-06-24 11:12:19 --> Router Class Initialized
INFO - 2022-06-24 11:12:19 --> Output Class Initialized
INFO - 2022-06-24 11:12:19 --> Security Class Initialized
DEBUG - 2022-06-24 11:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:12:19 --> Input Class Initialized
INFO - 2022-06-24 11:12:19 --> Language Class Initialized
ERROR - 2022-06-24 11:12:20 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) C:\wamp64\www\qr\application\controllers\Tokenctrl.php 39
INFO - 2022-06-24 11:12:54 --> Config Class Initialized
INFO - 2022-06-24 11:12:54 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:12:54 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:12:54 --> Utf8 Class Initialized
INFO - 2022-06-24 11:12:54 --> URI Class Initialized
INFO - 2022-06-24 11:12:54 --> Router Class Initialized
INFO - 2022-06-24 11:12:54 --> Output Class Initialized
INFO - 2022-06-24 11:12:54 --> Security Class Initialized
DEBUG - 2022-06-24 11:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:12:54 --> Input Class Initialized
INFO - 2022-06-24 11:12:54 --> Language Class Initialized
INFO - 2022-06-24 11:12:54 --> Loader Class Initialized
INFO - 2022-06-24 11:12:54 --> Helper loaded: url_helper
INFO - 2022-06-24 11:12:54 --> Helper loaded: file_helper
INFO - 2022-06-24 11:12:54 --> Database Driver Class Initialized
INFO - 2022-06-24 11:12:54 --> Email Class Initialized
DEBUG - 2022-06-24 11:12:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:12:54 --> Controller Class Initialized
INFO - 2022-06-24 11:12:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:12:54 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:13:35 --> Config Class Initialized
INFO - 2022-06-24 11:13:35 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:13:35 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:13:35 --> Utf8 Class Initialized
INFO - 2022-06-24 11:13:35 --> URI Class Initialized
INFO - 2022-06-24 11:13:35 --> Router Class Initialized
INFO - 2022-06-24 11:13:35 --> Output Class Initialized
INFO - 2022-06-24 11:13:35 --> Security Class Initialized
DEBUG - 2022-06-24 11:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:13:35 --> Input Class Initialized
INFO - 2022-06-24 11:13:35 --> Language Class Initialized
INFO - 2022-06-24 11:13:35 --> Loader Class Initialized
INFO - 2022-06-24 11:13:35 --> Helper loaded: url_helper
INFO - 2022-06-24 11:13:35 --> Helper loaded: file_helper
INFO - 2022-06-24 11:13:35 --> Database Driver Class Initialized
INFO - 2022-06-24 11:13:35 --> Email Class Initialized
DEBUG - 2022-06-24 11:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:13:35 --> Controller Class Initialized
INFO - 2022-06-24 11:13:35 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:13:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-24 11:13:35 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::result_row() C:\wamp64\www\qr\application\models\Tokenmodel.php 34
INFO - 2022-06-24 11:13:50 --> Config Class Initialized
INFO - 2022-06-24 11:13:50 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:13:50 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:13:50 --> Utf8 Class Initialized
INFO - 2022-06-24 11:13:50 --> URI Class Initialized
INFO - 2022-06-24 11:13:50 --> Router Class Initialized
INFO - 2022-06-24 11:13:50 --> Output Class Initialized
INFO - 2022-06-24 11:13:50 --> Security Class Initialized
DEBUG - 2022-06-24 11:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:13:50 --> Input Class Initialized
INFO - 2022-06-24 11:13:50 --> Language Class Initialized
INFO - 2022-06-24 11:13:50 --> Loader Class Initialized
INFO - 2022-06-24 11:13:50 --> Helper loaded: url_helper
INFO - 2022-06-24 11:13:50 --> Helper loaded: file_helper
INFO - 2022-06-24 11:13:50 --> Database Driver Class Initialized
INFO - 2022-06-24 11:13:50 --> Email Class Initialized
DEBUG - 2022-06-24 11:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:13:50 --> Controller Class Initialized
INFO - 2022-06-24 11:13:50 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:13:50 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:14:06 --> Config Class Initialized
INFO - 2022-06-24 11:14:06 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:14:06 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:14:06 --> Utf8 Class Initialized
INFO - 2022-06-24 11:14:06 --> URI Class Initialized
INFO - 2022-06-24 11:14:06 --> Router Class Initialized
INFO - 2022-06-24 11:14:06 --> Output Class Initialized
INFO - 2022-06-24 11:14:06 --> Security Class Initialized
DEBUG - 2022-06-24 11:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:14:06 --> Input Class Initialized
INFO - 2022-06-24 11:14:06 --> Language Class Initialized
INFO - 2022-06-24 11:14:06 --> Loader Class Initialized
INFO - 2022-06-24 11:14:06 --> Helper loaded: url_helper
INFO - 2022-06-24 11:14:06 --> Helper loaded: file_helper
INFO - 2022-06-24 11:14:06 --> Database Driver Class Initialized
INFO - 2022-06-24 11:14:06 --> Email Class Initialized
DEBUG - 2022-06-24 11:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:14:06 --> Controller Class Initialized
INFO - 2022-06-24 11:14:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:14:06 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:16:23 --> Config Class Initialized
INFO - 2022-06-24 11:16:23 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:16:23 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:16:23 --> Utf8 Class Initialized
INFO - 2022-06-24 11:16:23 --> URI Class Initialized
INFO - 2022-06-24 11:16:23 --> Router Class Initialized
INFO - 2022-06-24 11:16:23 --> Output Class Initialized
INFO - 2022-06-24 11:16:23 --> Security Class Initialized
DEBUG - 2022-06-24 11:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:16:23 --> Input Class Initialized
INFO - 2022-06-24 11:16:23 --> Language Class Initialized
INFO - 2022-06-24 11:16:23 --> Loader Class Initialized
INFO - 2022-06-24 11:16:23 --> Helper loaded: url_helper
INFO - 2022-06-24 11:16:23 --> Helper loaded: file_helper
INFO - 2022-06-24 11:16:23 --> Database Driver Class Initialized
INFO - 2022-06-24 11:16:23 --> Email Class Initialized
DEBUG - 2022-06-24 11:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:16:23 --> Controller Class Initialized
INFO - 2022-06-24 11:16:23 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:16:23 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:16:23 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 11:16:23 --> Final output sent to browser
DEBUG - 2022-06-24 11:16:23 --> Total execution time: 0.0335
INFO - 2022-06-24 11:16:32 --> Config Class Initialized
INFO - 2022-06-24 11:16:32 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:16:32 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:16:32 --> Utf8 Class Initialized
INFO - 2022-06-24 11:16:32 --> URI Class Initialized
INFO - 2022-06-24 11:16:32 --> Router Class Initialized
INFO - 2022-06-24 11:16:32 --> Output Class Initialized
INFO - 2022-06-24 11:16:32 --> Security Class Initialized
DEBUG - 2022-06-24 11:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:16:32 --> Input Class Initialized
INFO - 2022-06-24 11:16:32 --> Language Class Initialized
INFO - 2022-06-24 11:16:32 --> Loader Class Initialized
INFO - 2022-06-24 11:16:32 --> Helper loaded: url_helper
INFO - 2022-06-24 11:16:32 --> Helper loaded: file_helper
INFO - 2022-06-24 11:16:32 --> Database Driver Class Initialized
INFO - 2022-06-24 11:16:32 --> Config Class Initialized
INFO - 2022-06-24 11:16:32 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:16:32 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:16:32 --> Email Class Initialized
INFO - 2022-06-24 11:16:32 --> Utf8 Class Initialized
INFO - 2022-06-24 11:16:32 --> URI Class Initialized
INFO - 2022-06-24 11:16:32 --> Router Class Initialized
DEBUG - 2022-06-24 11:16:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:16:32 --> Output Class Initialized
INFO - 2022-06-24 11:16:32 --> Security Class Initialized
DEBUG - 2022-06-24 11:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:16:32 --> Input Class Initialized
INFO - 2022-06-24 11:16:32 --> Controller Class Initialized
INFO - 2022-06-24 11:16:32 --> Language Class Initialized
INFO - 2022-06-24 11:16:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:16:32 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:16:32 --> Loader Class Initialized
INFO - 2022-06-24 11:16:32 --> Final output sent to browser
INFO - 2022-06-24 11:16:32 --> Helper loaded: url_helper
DEBUG - 2022-06-24 11:16:32 --> Total execution time: 0.0382
INFO - 2022-06-24 11:16:32 --> Helper loaded: file_helper
INFO - 2022-06-24 11:16:32 --> Database Driver Class Initialized
INFO - 2022-06-24 11:16:32 --> Email Class Initialized
DEBUG - 2022-06-24 11:16:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:16:32 --> Controller Class Initialized
INFO - 2022-06-24 11:16:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:16:32 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:16:32 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 11:16:32 --> Final output sent to browser
DEBUG - 2022-06-24 11:16:32 --> Total execution time: 0.0323
INFO - 2022-06-24 11:16:37 --> Config Class Initialized
INFO - 2022-06-24 11:16:37 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:16:37 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:16:37 --> Utf8 Class Initialized
INFO - 2022-06-24 11:16:37 --> URI Class Initialized
INFO - 2022-06-24 11:16:37 --> Router Class Initialized
INFO - 2022-06-24 11:16:37 --> Output Class Initialized
INFO - 2022-06-24 11:16:37 --> Security Class Initialized
DEBUG - 2022-06-24 11:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:16:37 --> Input Class Initialized
INFO - 2022-06-24 11:16:37 --> Language Class Initialized
INFO - 2022-06-24 11:16:37 --> Loader Class Initialized
INFO - 2022-06-24 11:16:37 --> Helper loaded: url_helper
INFO - 2022-06-24 11:16:37 --> Helper loaded: file_helper
INFO - 2022-06-24 11:16:37 --> Database Driver Class Initialized
INFO - 2022-06-24 11:16:37 --> Email Class Initialized
DEBUG - 2022-06-24 11:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:16:37 --> Controller Class Initialized
INFO - 2022-06-24 11:16:37 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:16:37 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:16:37 --> Final output sent to browser
DEBUG - 2022-06-24 11:16:37 --> Total execution time: 0.0388
INFO - 2022-06-24 11:16:52 --> Config Class Initialized
INFO - 2022-06-24 11:16:52 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:16:52 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:16:52 --> Utf8 Class Initialized
INFO - 2022-06-24 11:16:52 --> URI Class Initialized
INFO - 2022-06-24 11:16:52 --> Router Class Initialized
INFO - 2022-06-24 11:16:52 --> Output Class Initialized
INFO - 2022-06-24 11:16:52 --> Security Class Initialized
DEBUG - 2022-06-24 11:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:16:52 --> Input Class Initialized
INFO - 2022-06-24 11:16:52 --> Config Class Initialized
INFO - 2022-06-24 11:16:52 --> Hooks Class Initialized
INFO - 2022-06-24 11:16:52 --> Language Class Initialized
DEBUG - 2022-06-24 11:16:52 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:16:52 --> Loader Class Initialized
INFO - 2022-06-24 11:16:52 --> Utf8 Class Initialized
INFO - 2022-06-24 11:16:52 --> URI Class Initialized
INFO - 2022-06-24 11:16:52 --> Helper loaded: url_helper
INFO - 2022-06-24 11:16:52 --> Helper loaded: file_helper
INFO - 2022-06-24 11:16:52 --> Router Class Initialized
INFO - 2022-06-24 11:16:52 --> Output Class Initialized
INFO - 2022-06-24 11:16:52 --> Database Driver Class Initialized
INFO - 2022-06-24 11:16:52 --> Security Class Initialized
DEBUG - 2022-06-24 11:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:16:52 --> Input Class Initialized
INFO - 2022-06-24 11:16:52 --> Email Class Initialized
INFO - 2022-06-24 11:16:52 --> Language Class Initialized
INFO - 2022-06-24 11:16:52 --> Loader Class Initialized
INFO - 2022-06-24 11:16:52 --> Helper loaded: url_helper
DEBUG - 2022-06-24 11:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:16:52 --> Helper loaded: file_helper
INFO - 2022-06-24 11:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:16:52 --> Controller Class Initialized
INFO - 2022-06-24 11:16:52 --> Database Driver Class Initialized
INFO - 2022-06-24 11:16:52 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:16:52 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:16:52 --> Final output sent to browser
DEBUG - 2022-06-24 11:16:52 --> Total execution time: 0.0348
INFO - 2022-06-24 11:16:52 --> Email Class Initialized
DEBUG - 2022-06-24 11:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:16:52 --> Controller Class Initialized
INFO - 2022-06-24 11:16:52 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:16:52 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:16:52 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 11:16:52 --> Final output sent to browser
DEBUG - 2022-06-24 11:16:52 --> Total execution time: 0.0315
INFO - 2022-06-24 11:16:57 --> Config Class Initialized
INFO - 2022-06-24 11:16:57 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:16:57 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:16:57 --> Utf8 Class Initialized
INFO - 2022-06-24 11:16:57 --> URI Class Initialized
INFO - 2022-06-24 11:16:57 --> Router Class Initialized
INFO - 2022-06-24 11:16:57 --> Output Class Initialized
INFO - 2022-06-24 11:16:57 --> Security Class Initialized
DEBUG - 2022-06-24 11:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:16:57 --> Input Class Initialized
INFO - 2022-06-24 11:16:57 --> Language Class Initialized
INFO - 2022-06-24 11:16:57 --> Loader Class Initialized
INFO - 2022-06-24 11:16:57 --> Helper loaded: url_helper
INFO - 2022-06-24 11:16:57 --> Helper loaded: file_helper
INFO - 2022-06-24 11:16:57 --> Database Driver Class Initialized
INFO - 2022-06-24 11:16:57 --> Email Class Initialized
DEBUG - 2022-06-24 11:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:16:57 --> Controller Class Initialized
INFO - 2022-06-24 11:16:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:16:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:16:57 --> Final output sent to browser
DEBUG - 2022-06-24 11:16:57 --> Total execution time: 0.0465
INFO - 2022-06-24 11:17:00 --> Config Class Initialized
INFO - 2022-06-24 11:17:00 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:17:00 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:17:00 --> Utf8 Class Initialized
INFO - 2022-06-24 11:17:00 --> URI Class Initialized
INFO - 2022-06-24 11:17:00 --> Router Class Initialized
INFO - 2022-06-24 11:17:00 --> Output Class Initialized
INFO - 2022-06-24 11:17:00 --> Security Class Initialized
DEBUG - 2022-06-24 11:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:17:00 --> Input Class Initialized
INFO - 2022-06-24 11:17:00 --> Language Class Initialized
INFO - 2022-06-24 11:17:00 --> Loader Class Initialized
INFO - 2022-06-24 11:17:00 --> Helper loaded: url_helper
INFO - 2022-06-24 11:17:00 --> Helper loaded: file_helper
INFO - 2022-06-24 11:17:00 --> Database Driver Class Initialized
INFO - 2022-06-24 11:17:00 --> Email Class Initialized
DEBUG - 2022-06-24 11:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:17:00 --> Controller Class Initialized
INFO - 2022-06-24 11:17:00 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:17:00 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:17:00 --> Final output sent to browser
DEBUG - 2022-06-24 11:17:00 --> Total execution time: 0.0370
INFO - 2022-06-24 11:18:23 --> Config Class Initialized
INFO - 2022-06-24 11:18:23 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:18:23 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:18:23 --> Utf8 Class Initialized
INFO - 2022-06-24 11:18:23 --> URI Class Initialized
INFO - 2022-06-24 11:18:23 --> Router Class Initialized
INFO - 2022-06-24 11:18:23 --> Output Class Initialized
INFO - 2022-06-24 11:18:23 --> Security Class Initialized
DEBUG - 2022-06-24 11:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:18:23 --> Input Class Initialized
INFO - 2022-06-24 11:18:23 --> Language Class Initialized
INFO - 2022-06-24 11:18:23 --> Loader Class Initialized
INFO - 2022-06-24 11:18:23 --> Config Class Initialized
INFO - 2022-06-24 11:18:23 --> Hooks Class Initialized
INFO - 2022-06-24 11:18:23 --> Helper loaded: url_helper
DEBUG - 2022-06-24 11:18:23 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:18:23 --> Utf8 Class Initialized
INFO - 2022-06-24 11:18:23 --> Helper loaded: file_helper
INFO - 2022-06-24 11:18:23 --> URI Class Initialized
INFO - 2022-06-24 11:18:23 --> Database Driver Class Initialized
INFO - 2022-06-24 11:18:23 --> Router Class Initialized
INFO - 2022-06-24 11:18:23 --> Output Class Initialized
INFO - 2022-06-24 11:18:23 --> Security Class Initialized
INFO - 2022-06-24 11:18:23 --> Email Class Initialized
DEBUG - 2022-06-24 11:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:18:23 --> Input Class Initialized
INFO - 2022-06-24 11:18:23 --> Language Class Initialized
DEBUG - 2022-06-24 11:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:18:23 --> Loader Class Initialized
INFO - 2022-06-24 11:18:23 --> Helper loaded: url_helper
INFO - 2022-06-24 11:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:18:23 --> Controller Class Initialized
INFO - 2022-06-24 11:18:23 --> Helper loaded: file_helper
INFO - 2022-06-24 11:18:23 --> Model "Tokenmodel" initialized
INFO - 2022-06-24 11:18:23 --> Database Driver Class Initialized
DEBUG - 2022-06-24 11:18:23 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:18:23 --> Email Class Initialized
DEBUG - 2022-06-24 11:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:18:23 --> Controller Class Initialized
INFO - 2022-06-24 11:18:23 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:18:23 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:18:23 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 11:18:23 --> Final output sent to browser
DEBUG - 2022-06-24 11:18:23 --> Total execution time: 0.0498
INFO - 2022-06-24 11:18:28 --> Config Class Initialized
INFO - 2022-06-24 11:18:28 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:18:28 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:18:28 --> Utf8 Class Initialized
INFO - 2022-06-24 11:18:28 --> URI Class Initialized
INFO - 2022-06-24 11:18:28 --> Router Class Initialized
INFO - 2022-06-24 11:18:28 --> Output Class Initialized
INFO - 2022-06-24 11:18:28 --> Security Class Initialized
DEBUG - 2022-06-24 11:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:18:28 --> Input Class Initialized
INFO - 2022-06-24 11:18:28 --> Language Class Initialized
INFO - 2022-06-24 11:18:28 --> Loader Class Initialized
INFO - 2022-06-24 11:18:28 --> Helper loaded: url_helper
INFO - 2022-06-24 11:18:28 --> Helper loaded: file_helper
INFO - 2022-06-24 11:18:28 --> Database Driver Class Initialized
INFO - 2022-06-24 11:18:28 --> Email Class Initialized
DEBUG - 2022-06-24 11:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:18:28 --> Controller Class Initialized
INFO - 2022-06-24 11:18:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:18:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:19:39 --> Config Class Initialized
INFO - 2022-06-24 11:19:39 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:19:39 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:19:39 --> Utf8 Class Initialized
INFO - 2022-06-24 11:19:39 --> URI Class Initialized
INFO - 2022-06-24 11:19:39 --> Router Class Initialized
INFO - 2022-06-24 11:19:39 --> Output Class Initialized
INFO - 2022-06-24 11:19:39 --> Security Class Initialized
DEBUG - 2022-06-24 11:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:19:39 --> Input Class Initialized
INFO - 2022-06-24 11:19:39 --> Language Class Initialized
INFO - 2022-06-24 11:19:39 --> Loader Class Initialized
INFO - 2022-06-24 11:19:39 --> Helper loaded: url_helper
INFO - 2022-06-24 11:19:39 --> Helper loaded: file_helper
INFO - 2022-06-24 11:19:39 --> Database Driver Class Initialized
INFO - 2022-06-24 11:19:39 --> Config Class Initialized
INFO - 2022-06-24 11:19:39 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:19:39 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:19:39 --> Utf8 Class Initialized
INFO - 2022-06-24 11:19:39 --> URI Class Initialized
INFO - 2022-06-24 11:19:39 --> Router Class Initialized
INFO - 2022-06-24 11:19:39 --> Output Class Initialized
INFO - 2022-06-24 11:19:39 --> Security Class Initialized
DEBUG - 2022-06-24 11:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:19:39 --> Input Class Initialized
INFO - 2022-06-24 11:19:39 --> Language Class Initialized
INFO - 2022-06-24 11:19:39 --> Loader Class Initialized
INFO - 2022-06-24 11:19:39 --> Helper loaded: url_helper
INFO - 2022-06-24 11:19:39 --> Helper loaded: file_helper
INFO - 2022-06-24 11:19:39 --> Database Driver Class Initialized
INFO - 2022-06-24 11:19:39 --> Email Class Initialized
DEBUG - 2022-06-24 11:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:19:39 --> Controller Class Initialized
INFO - 2022-06-24 11:19:39 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:19:39 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:19:39 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 11:19:39 --> Final output sent to browser
DEBUG - 2022-06-24 11:19:39 --> Total execution time: 0.0305
INFO - 2022-06-24 11:19:39 --> Email Class Initialized
DEBUG - 2022-06-24 11:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:19:39 --> Controller Class Initialized
INFO - 2022-06-24 11:19:39 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:19:39 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:19:42 --> Config Class Initialized
INFO - 2022-06-24 11:19:42 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:19:42 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:19:42 --> Utf8 Class Initialized
INFO - 2022-06-24 11:19:42 --> URI Class Initialized
INFO - 2022-06-24 11:19:42 --> Router Class Initialized
INFO - 2022-06-24 11:19:42 --> Output Class Initialized
INFO - 2022-06-24 11:19:42 --> Security Class Initialized
DEBUG - 2022-06-24 11:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:19:42 --> Input Class Initialized
INFO - 2022-06-24 11:19:42 --> Language Class Initialized
INFO - 2022-06-24 11:19:42 --> Loader Class Initialized
INFO - 2022-06-24 11:19:42 --> Helper loaded: url_helper
INFO - 2022-06-24 11:19:42 --> Helper loaded: file_helper
INFO - 2022-06-24 11:19:42 --> Database Driver Class Initialized
INFO - 2022-06-24 11:19:42 --> Email Class Initialized
DEBUG - 2022-06-24 11:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:19:42 --> Controller Class Initialized
INFO - 2022-06-24 11:19:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:19:42 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:20:10 --> Config Class Initialized
INFO - 2022-06-24 11:20:10 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:20:10 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:20:10 --> Utf8 Class Initialized
INFO - 2022-06-24 11:20:10 --> URI Class Initialized
INFO - 2022-06-24 11:20:10 --> Router Class Initialized
INFO - 2022-06-24 11:20:10 --> Output Class Initialized
INFO - 2022-06-24 11:20:10 --> Config Class Initialized
INFO - 2022-06-24 11:20:10 --> Hooks Class Initialized
INFO - 2022-06-24 11:20:10 --> Security Class Initialized
DEBUG - 2022-06-24 11:20:10 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:20:10 --> Utf8 Class Initialized
DEBUG - 2022-06-24 11:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:20:10 --> Input Class Initialized
INFO - 2022-06-24 11:20:10 --> URI Class Initialized
INFO - 2022-06-24 11:20:10 --> Language Class Initialized
INFO - 2022-06-24 11:20:10 --> Router Class Initialized
INFO - 2022-06-24 11:20:10 --> Loader Class Initialized
INFO - 2022-06-24 11:20:10 --> Helper loaded: url_helper
INFO - 2022-06-24 11:20:10 --> Output Class Initialized
INFO - 2022-06-24 11:20:10 --> Helper loaded: file_helper
INFO - 2022-06-24 11:20:10 --> Database Driver Class Initialized
INFO - 2022-06-24 11:20:10 --> Security Class Initialized
INFO - 2022-06-24 11:20:10 --> Email Class Initialized
DEBUG - 2022-06-24 11:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:20:10 --> Input Class Initialized
DEBUG - 2022-06-24 11:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:20:10 --> Language Class Initialized
INFO - 2022-06-24 11:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:20:10 --> Loader Class Initialized
INFO - 2022-06-24 11:20:10 --> Controller Class Initialized
INFO - 2022-06-24 11:20:10 --> Helper loaded: url_helper
INFO - 2022-06-24 11:20:10 --> Model "Tokenmodel" initialized
INFO - 2022-06-24 11:20:10 --> Helper loaded: file_helper
DEBUG - 2022-06-24 11:20:10 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:20:10 --> Database Driver Class Initialized
INFO - 2022-06-24 11:20:10 --> Final output sent to browser
DEBUG - 2022-06-24 11:20:10 --> Total execution time: 0.0672
INFO - 2022-06-24 11:20:10 --> Email Class Initialized
DEBUG - 2022-06-24 11:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:20:10 --> Controller Class Initialized
INFO - 2022-06-24 11:20:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:20:10 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:20:10 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 11:20:10 --> Final output sent to browser
DEBUG - 2022-06-24 11:20:10 --> Total execution time: 0.0685
INFO - 2022-06-24 11:20:15 --> Config Class Initialized
INFO - 2022-06-24 11:20:15 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:20:15 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:20:15 --> Utf8 Class Initialized
INFO - 2022-06-24 11:20:15 --> URI Class Initialized
INFO - 2022-06-24 11:20:15 --> Router Class Initialized
INFO - 2022-06-24 11:20:15 --> Output Class Initialized
INFO - 2022-06-24 11:20:15 --> Security Class Initialized
DEBUG - 2022-06-24 11:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:20:15 --> Input Class Initialized
INFO - 2022-06-24 11:20:15 --> Language Class Initialized
INFO - 2022-06-24 11:20:15 --> Loader Class Initialized
INFO - 2022-06-24 11:20:15 --> Helper loaded: url_helper
INFO - 2022-06-24 11:20:15 --> Helper loaded: file_helper
INFO - 2022-06-24 11:20:15 --> Database Driver Class Initialized
INFO - 2022-06-24 11:20:15 --> Email Class Initialized
DEBUG - 2022-06-24 11:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:20:15 --> Controller Class Initialized
INFO - 2022-06-24 11:20:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:20:15 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:20:15 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 11:20:15 --> Final output sent to browser
DEBUG - 2022-06-24 11:20:15 --> Total execution time: 0.0418
INFO - 2022-06-24 11:20:25 --> Config Class Initialized
INFO - 2022-06-24 11:20:25 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:20:25 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:20:25 --> Utf8 Class Initialized
INFO - 2022-06-24 11:20:25 --> URI Class Initialized
INFO - 2022-06-24 11:20:25 --> Router Class Initialized
INFO - 2022-06-24 11:20:25 --> Output Class Initialized
INFO - 2022-06-24 11:20:25 --> Security Class Initialized
DEBUG - 2022-06-24 11:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:20:25 --> Input Class Initialized
INFO - 2022-06-24 11:20:25 --> Language Class Initialized
INFO - 2022-06-24 11:20:25 --> Loader Class Initialized
INFO - 2022-06-24 11:20:25 --> Helper loaded: url_helper
INFO - 2022-06-24 11:20:25 --> Helper loaded: file_helper
INFO - 2022-06-24 11:20:25 --> Database Driver Class Initialized
INFO - 2022-06-24 11:20:25 --> Email Class Initialized
DEBUG - 2022-06-24 11:20:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:20:25 --> Controller Class Initialized
INFO - 2022-06-24 11:20:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:20:25 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:20:25 --> Final output sent to browser
DEBUG - 2022-06-24 11:20:25 --> Total execution time: 0.0396
INFO - 2022-06-24 11:21:11 --> Config Class Initialized
INFO - 2022-06-24 11:21:11 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:21:11 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:21:11 --> Utf8 Class Initialized
INFO - 2022-06-24 11:21:11 --> URI Class Initialized
INFO - 2022-06-24 11:21:11 --> Router Class Initialized
INFO - 2022-06-24 11:21:11 --> Output Class Initialized
INFO - 2022-06-24 11:21:11 --> Security Class Initialized
DEBUG - 2022-06-24 11:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:21:11 --> Input Class Initialized
INFO - 2022-06-24 11:21:11 --> Language Class Initialized
INFO - 2022-06-24 11:21:11 --> Loader Class Initialized
INFO - 2022-06-24 11:21:11 --> Helper loaded: url_helper
INFO - 2022-06-24 11:21:11 --> Helper loaded: file_helper
INFO - 2022-06-24 11:21:11 --> Database Driver Class Initialized
INFO - 2022-06-24 11:21:11 --> Email Class Initialized
DEBUG - 2022-06-24 11:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:21:11 --> Controller Class Initialized
INFO - 2022-06-24 11:21:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:21:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:21:11 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-24 11:21:11 --> Final output sent to browser
DEBUG - 2022-06-24 11:21:11 --> Total execution time: 0.1394
INFO - 2022-06-24 11:21:19 --> Config Class Initialized
INFO - 2022-06-24 11:21:19 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:21:19 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:21:19 --> Utf8 Class Initialized
INFO - 2022-06-24 11:21:19 --> URI Class Initialized
INFO - 2022-06-24 11:21:19 --> Router Class Initialized
INFO - 2022-06-24 11:21:19 --> Output Class Initialized
INFO - 2022-06-24 11:21:19 --> Security Class Initialized
DEBUG - 2022-06-24 11:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:21:19 --> Input Class Initialized
INFO - 2022-06-24 11:21:19 --> Language Class Initialized
INFO - 2022-06-24 11:21:19 --> Loader Class Initialized
INFO - 2022-06-24 11:21:19 --> Helper loaded: url_helper
INFO - 2022-06-24 11:21:19 --> Helper loaded: file_helper
INFO - 2022-06-24 11:21:19 --> Database Driver Class Initialized
INFO - 2022-06-24 11:21:19 --> Email Class Initialized
DEBUG - 2022-06-24 11:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:21:19 --> Controller Class Initialized
INFO - 2022-06-24 11:21:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:21:19 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:21:19 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-24 11:21:19 --> Final output sent to browser
DEBUG - 2022-06-24 11:21:19 --> Total execution time: 0.0342
INFO - 2022-06-24 11:21:24 --> Config Class Initialized
INFO - 2022-06-24 11:21:24 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:21:24 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:21:24 --> Utf8 Class Initialized
INFO - 2022-06-24 11:21:24 --> URI Class Initialized
INFO - 2022-06-24 11:21:24 --> Router Class Initialized
INFO - 2022-06-24 11:21:24 --> Output Class Initialized
INFO - 2022-06-24 11:21:24 --> Security Class Initialized
DEBUG - 2022-06-24 11:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:21:24 --> Input Class Initialized
INFO - 2022-06-24 11:21:24 --> Language Class Initialized
INFO - 2022-06-24 11:21:24 --> Loader Class Initialized
INFO - 2022-06-24 11:21:24 --> Helper loaded: url_helper
INFO - 2022-06-24 11:21:24 --> Helper loaded: file_helper
INFO - 2022-06-24 11:21:24 --> Database Driver Class Initialized
INFO - 2022-06-24 11:21:24 --> Email Class Initialized
DEBUG - 2022-06-24 11:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:21:24 --> Controller Class Initialized
INFO - 2022-06-24 11:21:24 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:21:24 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:21:24 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-24 11:21:24 --> Final output sent to browser
DEBUG - 2022-06-24 11:21:24 --> Total execution time: 0.0259
INFO - 2022-06-24 11:21:35 --> Config Class Initialized
INFO - 2022-06-24 11:21:35 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:21:35 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:21:35 --> Utf8 Class Initialized
INFO - 2022-06-24 11:21:35 --> URI Class Initialized
INFO - 2022-06-24 11:21:35 --> Config Class Initialized
INFO - 2022-06-24 11:21:35 --> Hooks Class Initialized
INFO - 2022-06-24 11:21:35 --> Router Class Initialized
DEBUG - 2022-06-24 11:21:35 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:21:35 --> Output Class Initialized
INFO - 2022-06-24 11:21:35 --> Utf8 Class Initialized
INFO - 2022-06-24 11:21:35 --> Security Class Initialized
INFO - 2022-06-24 11:21:35 --> URI Class Initialized
DEBUG - 2022-06-24 11:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:21:35 --> Input Class Initialized
INFO - 2022-06-24 11:21:35 --> Router Class Initialized
INFO - 2022-06-24 11:21:35 --> Language Class Initialized
INFO - 2022-06-24 11:21:35 --> Output Class Initialized
INFO - 2022-06-24 11:21:35 --> Loader Class Initialized
INFO - 2022-06-24 11:21:35 --> Security Class Initialized
DEBUG - 2022-06-24 11:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:21:35 --> Helper loaded: url_helper
INFO - 2022-06-24 11:21:35 --> Input Class Initialized
INFO - 2022-06-24 11:21:35 --> Language Class Initialized
INFO - 2022-06-24 11:21:35 --> Helper loaded: file_helper
INFO - 2022-06-24 11:21:35 --> Loader Class Initialized
INFO - 2022-06-24 11:21:35 --> Database Driver Class Initialized
INFO - 2022-06-24 11:21:35 --> Helper loaded: url_helper
INFO - 2022-06-24 11:21:35 --> Helper loaded: file_helper
INFO - 2022-06-24 11:21:35 --> Database Driver Class Initialized
INFO - 2022-06-24 11:21:35 --> Email Class Initialized
DEBUG - 2022-06-24 11:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:21:35 --> Email Class Initialized
INFO - 2022-06-24 11:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:21:35 --> Controller Class Initialized
DEBUG - 2022-06-24 11:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:21:35 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:21:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-24 11:21:35 --> test
INFO - 2022-06-24 11:21:35 --> Final output sent to browser
DEBUG - 2022-06-24 11:21:35 --> Total execution time: 0.0354
INFO - 2022-06-24 11:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:21:35 --> Controller Class Initialized
INFO - 2022-06-24 11:21:35 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:21:35 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:21:35 --> File loaded: C:\wamp64\www\qr\application\views\filldetails/filldetails.php
INFO - 2022-06-24 11:21:35 --> Final output sent to browser
DEBUG - 2022-06-24 11:21:35 --> Total execution time: 0.0359
INFO - 2022-06-24 11:21:35 --> Config Class Initialized
INFO - 2022-06-24 11:21:35 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:21:35 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:21:35 --> Utf8 Class Initialized
INFO - 2022-06-24 11:21:35 --> URI Class Initialized
INFO - 2022-06-24 11:21:35 --> Router Class Initialized
INFO - 2022-06-24 11:21:35 --> Output Class Initialized
INFO - 2022-06-24 11:21:35 --> Security Class Initialized
DEBUG - 2022-06-24 11:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:21:35 --> Input Class Initialized
INFO - 2022-06-24 11:21:35 --> Language Class Initialized
INFO - 2022-06-24 11:21:35 --> Loader Class Initialized
INFO - 2022-06-24 11:21:35 --> Helper loaded: url_helper
INFO - 2022-06-24 11:21:35 --> Helper loaded: file_helper
INFO - 2022-06-24 11:21:35 --> Database Driver Class Initialized
INFO - 2022-06-24 11:21:35 --> Email Class Initialized
DEBUG - 2022-06-24 11:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:21:35 --> Controller Class Initialized
INFO - 2022-06-24 11:21:35 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:21:35 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:21:35 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 11:21:35 --> Final output sent to browser
DEBUG - 2022-06-24 11:21:35 --> Total execution time: 0.0245
INFO - 2022-06-24 11:21:48 --> Config Class Initialized
INFO - 2022-06-24 11:21:48 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:21:48 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:21:48 --> Utf8 Class Initialized
INFO - 2022-06-24 11:21:48 --> URI Class Initialized
INFO - 2022-06-24 11:21:48 --> Router Class Initialized
INFO - 2022-06-24 11:21:48 --> Output Class Initialized
INFO - 2022-06-24 11:21:48 --> Security Class Initialized
DEBUG - 2022-06-24 11:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:21:48 --> Input Class Initialized
INFO - 2022-06-24 11:21:48 --> Language Class Initialized
INFO - 2022-06-24 11:21:48 --> Loader Class Initialized
INFO - 2022-06-24 11:21:48 --> Helper loaded: url_helper
INFO - 2022-06-24 11:21:48 --> Helper loaded: file_helper
INFO - 2022-06-24 11:21:48 --> Database Driver Class Initialized
INFO - 2022-06-24 11:21:48 --> Config Class Initialized
INFO - 2022-06-24 11:21:48 --> Email Class Initialized
INFO - 2022-06-24 11:21:48 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:21:48 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:21:48 --> Utf8 Class Initialized
DEBUG - 2022-06-24 11:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:21:48 --> URI Class Initialized
INFO - 2022-06-24 11:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:21:48 --> Controller Class Initialized
INFO - 2022-06-24 11:21:48 --> Router Class Initialized
INFO - 2022-06-24 11:21:48 --> Output Class Initialized
INFO - 2022-06-24 11:21:48 --> Security Class Initialized
DEBUG - 2022-06-24 11:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:21:48 --> Input Class Initialized
INFO - 2022-06-24 11:21:48 --> Model "Tokenmodel" initialized
INFO - 2022-06-24 11:21:48 --> Language Class Initialized
DEBUG - 2022-06-24 11:21:48 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:21:48 --> Loader Class Initialized
INFO - 2022-06-24 11:21:48 --> Helper loaded: url_helper
INFO - 2022-06-24 11:21:48 --> Helper loaded: file_helper
INFO - 2022-06-24 11:21:48 --> Database Driver Class Initialized
INFO - 2022-06-24 11:21:48 --> Email Class Initialized
DEBUG - 2022-06-24 11:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:21:48 --> Controller Class Initialized
INFO - 2022-06-24 11:21:48 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:21:48 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:21:48 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 11:21:48 --> Final output sent to browser
DEBUG - 2022-06-24 11:21:48 --> Total execution time: 0.0335
INFO - 2022-06-24 11:21:59 --> Config Class Initialized
INFO - 2022-06-24 11:21:59 --> Hooks Class Initialized
DEBUG - 2022-06-24 11:21:59 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:21:59 --> Utf8 Class Initialized
INFO - 2022-06-24 11:21:59 --> URI Class Initialized
INFO - 2022-06-24 11:21:59 --> Router Class Initialized
INFO - 2022-06-24 11:21:59 --> Config Class Initialized
INFO - 2022-06-24 11:21:59 --> Hooks Class Initialized
INFO - 2022-06-24 11:21:59 --> Output Class Initialized
DEBUG - 2022-06-24 11:21:59 --> UTF-8 Support Enabled
INFO - 2022-06-24 11:21:59 --> Security Class Initialized
INFO - 2022-06-24 11:21:59 --> Utf8 Class Initialized
DEBUG - 2022-06-24 11:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:21:59 --> URI Class Initialized
INFO - 2022-06-24 11:21:59 --> Input Class Initialized
INFO - 2022-06-24 11:21:59 --> Language Class Initialized
INFO - 2022-06-24 11:21:59 --> Router Class Initialized
INFO - 2022-06-24 11:21:59 --> Loader Class Initialized
INFO - 2022-06-24 11:21:59 --> Output Class Initialized
INFO - 2022-06-24 11:21:59 --> Security Class Initialized
INFO - 2022-06-24 11:21:59 --> Helper loaded: url_helper
DEBUG - 2022-06-24 11:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 11:21:59 --> Helper loaded: file_helper
INFO - 2022-06-24 11:21:59 --> Input Class Initialized
INFO - 2022-06-24 11:21:59 --> Language Class Initialized
INFO - 2022-06-24 11:21:59 --> Database Driver Class Initialized
INFO - 2022-06-24 11:21:59 --> Loader Class Initialized
INFO - 2022-06-24 11:21:59 --> Helper loaded: url_helper
INFO - 2022-06-24 11:21:59 --> Helper loaded: file_helper
INFO - 2022-06-24 11:21:59 --> Email Class Initialized
INFO - 2022-06-24 11:21:59 --> Database Driver Class Initialized
DEBUG - 2022-06-24 11:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 11:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:21:59 --> Email Class Initialized
INFO - 2022-06-24 11:21:59 --> Controller Class Initialized
INFO - 2022-06-24 11:21:59 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-24 11:21:59 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:21:59 --> Final output sent to browser
DEBUG - 2022-06-24 11:21:59 --> Total execution time: 0.0373
INFO - 2022-06-24 11:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 11:21:59 --> Controller Class Initialized
INFO - 2022-06-24 11:21:59 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 11:21:59 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 11:21:59 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 11:21:59 --> Final output sent to browser
DEBUG - 2022-06-24 11:21:59 --> Total execution time: 0.0391
INFO - 2022-06-24 12:37:56 --> Config Class Initialized
INFO - 2022-06-24 12:37:56 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:37:56 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:37:56 --> Utf8 Class Initialized
INFO - 2022-06-24 12:37:56 --> URI Class Initialized
INFO - 2022-06-24 12:37:56 --> Router Class Initialized
INFO - 2022-06-24 12:37:56 --> Output Class Initialized
INFO - 2022-06-24 12:37:56 --> Security Class Initialized
DEBUG - 2022-06-24 12:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:37:56 --> Input Class Initialized
INFO - 2022-06-24 12:37:56 --> Language Class Initialized
INFO - 2022-06-24 12:37:56 --> Loader Class Initialized
INFO - 2022-06-24 12:37:56 --> Helper loaded: url_helper
INFO - 2022-06-24 12:37:56 --> Helper loaded: file_helper
INFO - 2022-06-24 12:37:56 --> Database Driver Class Initialized
INFO - 2022-06-24 12:37:56 --> Email Class Initialized
DEBUG - 2022-06-24 12:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 12:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 12:37:56 --> Controller Class Initialized
INFO - 2022-06-24 12:37:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 12:37:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 12:37:56 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-24 12:37:56 --> Final output sent to browser
DEBUG - 2022-06-24 12:37:56 --> Total execution time: 0.3390
INFO - 2022-06-24 12:37:56 --> Config Class Initialized
INFO - 2022-06-24 12:37:56 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:37:56 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:37:56 --> Utf8 Class Initialized
INFO - 2022-06-24 12:37:56 --> URI Class Initialized
INFO - 2022-06-24 12:37:56 --> Router Class Initialized
INFO - 2022-06-24 12:37:56 --> Output Class Initialized
INFO - 2022-06-24 12:37:56 --> Security Class Initialized
DEBUG - 2022-06-24 12:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:37:56 --> Input Class Initialized
INFO - 2022-06-24 12:37:56 --> Language Class Initialized
ERROR - 2022-06-24 12:37:56 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-24 12:37:56 --> Config Class Initialized
INFO - 2022-06-24 12:37:56 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:37:56 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:37:56 --> Utf8 Class Initialized
INFO - 2022-06-24 12:37:56 --> URI Class Initialized
INFO - 2022-06-24 12:37:56 --> Router Class Initialized
INFO - 2022-06-24 12:37:56 --> Output Class Initialized
INFO - 2022-06-24 12:37:56 --> Security Class Initialized
DEBUG - 2022-06-24 12:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:37:56 --> Input Class Initialized
INFO - 2022-06-24 12:37:56 --> Language Class Initialized
ERROR - 2022-06-24 12:37:56 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-24 12:38:02 --> Config Class Initialized
INFO - 2022-06-24 12:38:02 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:38:02 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:38:02 --> Utf8 Class Initialized
INFO - 2022-06-24 12:38:02 --> URI Class Initialized
INFO - 2022-06-24 12:38:02 --> Router Class Initialized
INFO - 2022-06-24 12:38:02 --> Output Class Initialized
INFO - 2022-06-24 12:38:02 --> Security Class Initialized
DEBUG - 2022-06-24 12:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:38:02 --> Input Class Initialized
INFO - 2022-06-24 12:38:02 --> Language Class Initialized
INFO - 2022-06-24 12:38:02 --> Loader Class Initialized
INFO - 2022-06-24 12:38:02 --> Helper loaded: url_helper
INFO - 2022-06-24 12:38:02 --> Helper loaded: file_helper
INFO - 2022-06-24 12:38:02 --> Database Driver Class Initialized
INFO - 2022-06-24 12:38:02 --> Email Class Initialized
DEBUG - 2022-06-24 12:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 12:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 12:38:02 --> Controller Class Initialized
INFO - 2022-06-24 12:38:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 12:38:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-24 12:38:02 --> Severity: error --> Exception: Call to undefined method Tokenmodel::current() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 74
INFO - 2022-06-24 12:38:06 --> Config Class Initialized
INFO - 2022-06-24 12:38:06 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:38:06 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:38:06 --> Utf8 Class Initialized
INFO - 2022-06-24 12:38:06 --> URI Class Initialized
INFO - 2022-06-24 12:38:06 --> Router Class Initialized
INFO - 2022-06-24 12:38:06 --> Output Class Initialized
INFO - 2022-06-24 12:38:06 --> Security Class Initialized
DEBUG - 2022-06-24 12:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:38:06 --> Input Class Initialized
INFO - 2022-06-24 12:38:06 --> Language Class Initialized
INFO - 2022-06-24 12:38:06 --> Loader Class Initialized
INFO - 2022-06-24 12:38:06 --> Helper loaded: url_helper
INFO - 2022-06-24 12:38:06 --> Helper loaded: file_helper
INFO - 2022-06-24 12:38:06 --> Database Driver Class Initialized
INFO - 2022-06-24 12:38:06 --> Email Class Initialized
DEBUG - 2022-06-24 12:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 12:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 12:38:06 --> Controller Class Initialized
INFO - 2022-06-24 12:38:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 12:38:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-24 12:38:06 --> Severity: error --> Exception: Call to undefined method Tokenmodel::current() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 74
INFO - 2022-06-24 12:39:12 --> Config Class Initialized
INFO - 2022-06-24 12:39:12 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:39:12 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:39:12 --> Utf8 Class Initialized
INFO - 2022-06-24 12:39:12 --> URI Class Initialized
INFO - 2022-06-24 12:39:12 --> Router Class Initialized
INFO - 2022-06-24 12:39:12 --> Output Class Initialized
INFO - 2022-06-24 12:39:12 --> Security Class Initialized
DEBUG - 2022-06-24 12:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:39:12 --> Input Class Initialized
INFO - 2022-06-24 12:39:12 --> Language Class Initialized
INFO - 2022-06-24 12:39:12 --> Loader Class Initialized
INFO - 2022-06-24 12:39:12 --> Helper loaded: url_helper
INFO - 2022-06-24 12:39:12 --> Helper loaded: file_helper
INFO - 2022-06-24 12:39:12 --> Database Driver Class Initialized
INFO - 2022-06-24 12:39:12 --> Email Class Initialized
DEBUG - 2022-06-24 12:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 12:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 12:39:12 --> Controller Class Initialized
INFO - 2022-06-24 12:39:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 12:39:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-24 12:39:12 --> Severity: error --> Exception: Call to undefined method Tokenmodel::current() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 74
INFO - 2022-06-24 12:39:23 --> Config Class Initialized
INFO - 2022-06-24 12:39:24 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:39:24 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:39:24 --> Utf8 Class Initialized
INFO - 2022-06-24 12:39:24 --> URI Class Initialized
INFO - 2022-06-24 12:39:24 --> Router Class Initialized
INFO - 2022-06-24 12:39:24 --> Output Class Initialized
INFO - 2022-06-24 12:39:24 --> Security Class Initialized
DEBUG - 2022-06-24 12:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:39:24 --> Input Class Initialized
INFO - 2022-06-24 12:39:24 --> Language Class Initialized
INFO - 2022-06-24 12:39:24 --> Loader Class Initialized
INFO - 2022-06-24 12:39:24 --> Helper loaded: url_helper
INFO - 2022-06-24 12:39:24 --> Helper loaded: file_helper
INFO - 2022-06-24 12:39:24 --> Database Driver Class Initialized
INFO - 2022-06-24 12:39:24 --> Email Class Initialized
DEBUG - 2022-06-24 12:39:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 12:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 12:39:24 --> Controller Class Initialized
INFO - 2022-06-24 12:39:24 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 12:39:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-24 12:39:24 --> Severity: error --> Exception: Call to undefined method Tokenmodel::current() C:\wamp64\www\qr\application\controllers\Tokenctrl.php 74
INFO - 2022-06-24 12:41:07 --> Config Class Initialized
INFO - 2022-06-24 12:41:07 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:41:07 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:41:07 --> Utf8 Class Initialized
INFO - 2022-06-24 12:41:07 --> URI Class Initialized
INFO - 2022-06-24 12:41:07 --> Router Class Initialized
INFO - 2022-06-24 12:41:07 --> Output Class Initialized
INFO - 2022-06-24 12:41:07 --> Security Class Initialized
DEBUG - 2022-06-24 12:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:41:07 --> Input Class Initialized
INFO - 2022-06-24 12:41:07 --> Language Class Initialized
INFO - 2022-06-24 12:41:07 --> Loader Class Initialized
INFO - 2022-06-24 12:41:07 --> Helper loaded: url_helper
INFO - 2022-06-24 12:41:07 --> Helper loaded: file_helper
INFO - 2022-06-24 12:41:07 --> Database Driver Class Initialized
INFO - 2022-06-24 12:41:07 --> Email Class Initialized
DEBUG - 2022-06-24 12:41:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 12:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 12:41:07 --> Controller Class Initialized
INFO - 2022-06-24 12:41:07 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 12:41:07 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 12:41:07 --> Final output sent to browser
DEBUG - 2022-06-24 12:41:07 --> Total execution time: 0.2211
INFO - 2022-06-24 12:42:14 --> Config Class Initialized
INFO - 2022-06-24 12:42:14 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:42:14 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:42:14 --> Utf8 Class Initialized
INFO - 2022-06-24 12:42:14 --> URI Class Initialized
INFO - 2022-06-24 12:42:14 --> Router Class Initialized
INFO - 2022-06-24 12:42:14 --> Output Class Initialized
INFO - 2022-06-24 12:42:14 --> Security Class Initialized
DEBUG - 2022-06-24 12:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:42:14 --> Input Class Initialized
INFO - 2022-06-24 12:42:14 --> Language Class Initialized
INFO - 2022-06-24 12:42:14 --> Loader Class Initialized
INFO - 2022-06-24 12:42:14 --> Helper loaded: url_helper
INFO - 2022-06-24 12:42:14 --> Helper loaded: file_helper
INFO - 2022-06-24 12:42:14 --> Database Driver Class Initialized
INFO - 2022-06-24 12:42:14 --> Email Class Initialized
DEBUG - 2022-06-24 12:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 12:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 12:42:14 --> Controller Class Initialized
INFO - 2022-06-24 12:42:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 12:42:14 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 12:42:14 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-24 12:42:14 --> Final output sent to browser
DEBUG - 2022-06-24 12:42:14 --> Total execution time: 0.0561
INFO - 2022-06-24 12:42:14 --> Config Class Initialized
INFO - 2022-06-24 12:42:14 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:42:14 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:42:14 --> Utf8 Class Initialized
INFO - 2022-06-24 12:42:14 --> URI Class Initialized
INFO - 2022-06-24 12:42:14 --> Router Class Initialized
INFO - 2022-06-24 12:42:14 --> Output Class Initialized
INFO - 2022-06-24 12:42:14 --> Security Class Initialized
DEBUG - 2022-06-24 12:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:42:14 --> Input Class Initialized
INFO - 2022-06-24 12:42:14 --> Language Class Initialized
ERROR - 2022-06-24 12:42:14 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-24 12:42:14 --> Config Class Initialized
INFO - 2022-06-24 12:42:14 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:42:14 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:42:14 --> Utf8 Class Initialized
INFO - 2022-06-24 12:42:14 --> URI Class Initialized
INFO - 2022-06-24 12:42:14 --> Router Class Initialized
INFO - 2022-06-24 12:42:14 --> Output Class Initialized
INFO - 2022-06-24 12:42:14 --> Security Class Initialized
DEBUG - 2022-06-24 12:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:42:14 --> Input Class Initialized
INFO - 2022-06-24 12:42:14 --> Language Class Initialized
ERROR - 2022-06-24 12:42:14 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-24 12:42:17 --> Config Class Initialized
INFO - 2022-06-24 12:42:17 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:42:17 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:42:17 --> Utf8 Class Initialized
INFO - 2022-06-24 12:42:17 --> URI Class Initialized
INFO - 2022-06-24 12:42:17 --> Router Class Initialized
INFO - 2022-06-24 12:42:17 --> Output Class Initialized
INFO - 2022-06-24 12:42:17 --> Security Class Initialized
DEBUG - 2022-06-24 12:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:42:17 --> Input Class Initialized
INFO - 2022-06-24 12:42:17 --> Language Class Initialized
INFO - 2022-06-24 12:42:17 --> Loader Class Initialized
INFO - 2022-06-24 12:42:17 --> Helper loaded: url_helper
INFO - 2022-06-24 12:42:17 --> Helper loaded: file_helper
INFO - 2022-06-24 12:42:17 --> Database Driver Class Initialized
INFO - 2022-06-24 12:42:17 --> Email Class Initialized
DEBUG - 2022-06-24 12:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 12:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 12:42:17 --> Controller Class Initialized
INFO - 2022-06-24 12:42:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 12:42:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 12:42:17 --> Final output sent to browser
DEBUG - 2022-06-24 12:42:17 --> Total execution time: 0.1711
INFO - 2022-06-24 12:42:18 --> Config Class Initialized
INFO - 2022-06-24 12:42:18 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:42:18 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:42:18 --> Utf8 Class Initialized
INFO - 2022-06-24 12:42:18 --> URI Class Initialized
INFO - 2022-06-24 12:42:18 --> Router Class Initialized
INFO - 2022-06-24 12:42:18 --> Output Class Initialized
INFO - 2022-06-24 12:42:18 --> Security Class Initialized
DEBUG - 2022-06-24 12:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:42:18 --> Input Class Initialized
INFO - 2022-06-24 12:42:18 --> Language Class Initialized
INFO - 2022-06-24 12:42:18 --> Loader Class Initialized
INFO - 2022-06-24 12:42:18 --> Helper loaded: url_helper
INFO - 2022-06-24 12:42:18 --> Helper loaded: file_helper
INFO - 2022-06-24 12:42:18 --> Database Driver Class Initialized
INFO - 2022-06-24 12:42:18 --> Email Class Initialized
DEBUG - 2022-06-24 12:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 12:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 12:42:18 --> Controller Class Initialized
INFO - 2022-06-24 12:42:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 12:42:18 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 12:42:18 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 12:42:18 --> Final output sent to browser
DEBUG - 2022-06-24 12:42:18 --> Total execution time: 0.0736
INFO - 2022-06-24 12:42:38 --> Config Class Initialized
INFO - 2022-06-24 12:42:38 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:42:38 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:42:38 --> Utf8 Class Initialized
INFO - 2022-06-24 12:42:38 --> URI Class Initialized
INFO - 2022-06-24 12:42:38 --> Router Class Initialized
INFO - 2022-06-24 12:42:38 --> Output Class Initialized
INFO - 2022-06-24 12:42:38 --> Security Class Initialized
DEBUG - 2022-06-24 12:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:42:38 --> Input Class Initialized
INFO - 2022-06-24 12:42:38 --> Language Class Initialized
INFO - 2022-06-24 12:42:38 --> Loader Class Initialized
INFO - 2022-06-24 12:42:38 --> Helper loaded: url_helper
INFO - 2022-06-24 12:42:38 --> Helper loaded: file_helper
INFO - 2022-06-24 12:42:38 --> Database Driver Class Initialized
INFO - 2022-06-24 12:42:38 --> Email Class Initialized
DEBUG - 2022-06-24 12:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 12:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 12:42:38 --> Controller Class Initialized
INFO - 2022-06-24 12:42:38 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 12:42:38 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 12:42:38 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-24 12:42:38 --> Final output sent to browser
DEBUG - 2022-06-24 12:42:38 --> Total execution time: 0.0244
INFO - 2022-06-24 12:42:38 --> Config Class Initialized
INFO - 2022-06-24 12:42:38 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:42:38 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:42:38 --> Utf8 Class Initialized
INFO - 2022-06-24 12:42:38 --> URI Class Initialized
INFO - 2022-06-24 12:42:38 --> Router Class Initialized
INFO - 2022-06-24 12:42:38 --> Output Class Initialized
INFO - 2022-06-24 12:42:38 --> Security Class Initialized
DEBUG - 2022-06-24 12:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:42:38 --> Input Class Initialized
INFO - 2022-06-24 12:42:38 --> Language Class Initialized
ERROR - 2022-06-24 12:42:38 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-24 12:42:38 --> Config Class Initialized
INFO - 2022-06-24 12:42:38 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:42:38 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:42:38 --> Utf8 Class Initialized
INFO - 2022-06-24 12:42:38 --> URI Class Initialized
INFO - 2022-06-24 12:42:38 --> Router Class Initialized
INFO - 2022-06-24 12:42:38 --> Output Class Initialized
INFO - 2022-06-24 12:42:38 --> Security Class Initialized
DEBUG - 2022-06-24 12:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:42:38 --> Input Class Initialized
INFO - 2022-06-24 12:42:38 --> Language Class Initialized
ERROR - 2022-06-24 12:42:38 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-24 12:42:57 --> Config Class Initialized
INFO - 2022-06-24 12:42:57 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:42:57 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:42:57 --> Utf8 Class Initialized
INFO - 2022-06-24 12:42:57 --> URI Class Initialized
INFO - 2022-06-24 12:42:57 --> Router Class Initialized
INFO - 2022-06-24 12:42:57 --> Output Class Initialized
INFO - 2022-06-24 12:42:57 --> Security Class Initialized
DEBUG - 2022-06-24 12:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:42:57 --> Input Class Initialized
INFO - 2022-06-24 12:42:57 --> Language Class Initialized
INFO - 2022-06-24 12:42:57 --> Loader Class Initialized
INFO - 2022-06-24 12:42:57 --> Helper loaded: url_helper
INFO - 2022-06-24 12:42:57 --> Helper loaded: file_helper
INFO - 2022-06-24 12:42:57 --> Database Driver Class Initialized
INFO - 2022-06-24 12:42:57 --> Email Class Initialized
DEBUG - 2022-06-24 12:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 12:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 12:42:57 --> Controller Class Initialized
INFO - 2022-06-24 12:42:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 12:42:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 12:42:57 --> Final output sent to browser
DEBUG - 2022-06-24 12:42:57 --> Total execution time: 0.0243
INFO - 2022-06-24 12:42:57 --> Config Class Initialized
INFO - 2022-06-24 12:42:57 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:42:57 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:42:57 --> Utf8 Class Initialized
INFO - 2022-06-24 12:42:57 --> URI Class Initialized
INFO - 2022-06-24 12:42:57 --> Router Class Initialized
INFO - 2022-06-24 12:42:57 --> Output Class Initialized
INFO - 2022-06-24 12:42:57 --> Security Class Initialized
DEBUG - 2022-06-24 12:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:42:57 --> Input Class Initialized
INFO - 2022-06-24 12:42:57 --> Language Class Initialized
INFO - 2022-06-24 12:42:57 --> Loader Class Initialized
INFO - 2022-06-24 12:42:57 --> Helper loaded: url_helper
INFO - 2022-06-24 12:42:57 --> Helper loaded: file_helper
INFO - 2022-06-24 12:42:57 --> Database Driver Class Initialized
INFO - 2022-06-24 12:42:57 --> Email Class Initialized
DEBUG - 2022-06-24 12:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 12:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 12:42:57 --> Controller Class Initialized
INFO - 2022-06-24 12:42:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 12:42:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 12:42:57 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 12:42:57 --> Final output sent to browser
DEBUG - 2022-06-24 12:42:57 --> Total execution time: 0.0307
INFO - 2022-06-24 12:43:09 --> Config Class Initialized
INFO - 2022-06-24 12:43:09 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:43:09 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:43:09 --> Utf8 Class Initialized
INFO - 2022-06-24 12:43:09 --> URI Class Initialized
INFO - 2022-06-24 12:43:09 --> Router Class Initialized
INFO - 2022-06-24 12:43:09 --> Output Class Initialized
INFO - 2022-06-24 12:43:09 --> Security Class Initialized
DEBUG - 2022-06-24 12:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:43:09 --> Input Class Initialized
INFO - 2022-06-24 12:43:09 --> Language Class Initialized
INFO - 2022-06-24 12:43:09 --> Loader Class Initialized
INFO - 2022-06-24 12:43:09 --> Helper loaded: url_helper
INFO - 2022-06-24 12:43:09 --> Helper loaded: file_helper
INFO - 2022-06-24 12:43:09 --> Database Driver Class Initialized
INFO - 2022-06-24 12:43:09 --> Email Class Initialized
DEBUG - 2022-06-24 12:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 12:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 12:43:09 --> Controller Class Initialized
INFO - 2022-06-24 12:43:09 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 12:43:09 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 12:43:09 --> Final output sent to browser
DEBUG - 2022-06-24 12:43:09 --> Total execution time: 0.1614
INFO - 2022-06-24 12:45:48 --> Config Class Initialized
INFO - 2022-06-24 12:45:48 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:45:48 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:45:48 --> Utf8 Class Initialized
INFO - 2022-06-24 12:45:48 --> URI Class Initialized
INFO - 2022-06-24 12:45:48 --> Router Class Initialized
INFO - 2022-06-24 12:45:48 --> Output Class Initialized
INFO - 2022-06-24 12:45:48 --> Security Class Initialized
DEBUG - 2022-06-24 12:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:45:48 --> Input Class Initialized
INFO - 2022-06-24 12:45:48 --> Language Class Initialized
INFO - 2022-06-24 12:45:48 --> Loader Class Initialized
INFO - 2022-06-24 12:45:48 --> Helper loaded: url_helper
INFO - 2022-06-24 12:45:48 --> Helper loaded: file_helper
INFO - 2022-06-24 12:45:48 --> Database Driver Class Initialized
INFO - 2022-06-24 12:45:48 --> Email Class Initialized
DEBUG - 2022-06-24 12:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 12:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 12:45:48 --> Controller Class Initialized
INFO - 2022-06-24 12:45:48 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 12:45:48 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 12:45:48 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-24 12:45:48 --> Final output sent to browser
DEBUG - 2022-06-24 12:45:48 --> Total execution time: 0.1318
INFO - 2022-06-24 12:45:53 --> Config Class Initialized
INFO - 2022-06-24 12:45:53 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:45:53 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:45:53 --> Utf8 Class Initialized
INFO - 2022-06-24 12:45:53 --> URI Class Initialized
INFO - 2022-06-24 12:45:53 --> Router Class Initialized
INFO - 2022-06-24 12:45:53 --> Output Class Initialized
INFO - 2022-06-24 12:45:53 --> Security Class Initialized
DEBUG - 2022-06-24 12:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:45:53 --> Input Class Initialized
INFO - 2022-06-24 12:45:53 --> Language Class Initialized
INFO - 2022-06-24 12:45:53 --> Loader Class Initialized
INFO - 2022-06-24 12:45:53 --> Helper loaded: url_helper
INFO - 2022-06-24 12:45:53 --> Helper loaded: file_helper
INFO - 2022-06-24 12:45:53 --> Database Driver Class Initialized
INFO - 2022-06-24 12:45:53 --> Email Class Initialized
DEBUG - 2022-06-24 12:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 12:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 12:45:53 --> Controller Class Initialized
INFO - 2022-06-24 12:45:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 12:45:53 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 12:45:53 --> Final output sent to browser
DEBUG - 2022-06-24 12:45:53 --> Total execution time: 0.1784
INFO - 2022-06-24 12:45:53 --> Config Class Initialized
INFO - 2022-06-24 12:45:53 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:45:53 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:45:53 --> Utf8 Class Initialized
INFO - 2022-06-24 12:45:53 --> URI Class Initialized
INFO - 2022-06-24 12:45:53 --> Router Class Initialized
INFO - 2022-06-24 12:45:53 --> Output Class Initialized
INFO - 2022-06-24 12:45:53 --> Security Class Initialized
DEBUG - 2022-06-24 12:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:45:53 --> Input Class Initialized
INFO - 2022-06-24 12:45:53 --> Language Class Initialized
INFO - 2022-06-24 12:45:53 --> Loader Class Initialized
INFO - 2022-06-24 12:45:53 --> Helper loaded: url_helper
INFO - 2022-06-24 12:45:53 --> Helper loaded: file_helper
INFO - 2022-06-24 12:45:53 --> Database Driver Class Initialized
INFO - 2022-06-24 12:45:53 --> Email Class Initialized
DEBUG - 2022-06-24 12:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 12:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 12:45:53 --> Controller Class Initialized
INFO - 2022-06-24 12:45:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 12:45:53 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 12:45:53 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 12:45:53 --> Final output sent to browser
DEBUG - 2022-06-24 12:45:53 --> Total execution time: 0.0495
INFO - 2022-06-24 12:46:08 --> Config Class Initialized
INFO - 2022-06-24 12:46:08 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:46:08 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:46:08 --> Utf8 Class Initialized
INFO - 2022-06-24 12:46:08 --> URI Class Initialized
INFO - 2022-06-24 12:46:08 --> Router Class Initialized
INFO - 2022-06-24 12:46:08 --> Output Class Initialized
INFO - 2022-06-24 12:46:08 --> Security Class Initialized
DEBUG - 2022-06-24 12:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:46:08 --> Input Class Initialized
INFO - 2022-06-24 12:46:08 --> Language Class Initialized
ERROR - 2022-06-24 12:46:08 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-24 12:46:08 --> Config Class Initialized
INFO - 2022-06-24 12:46:08 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:46:08 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:46:08 --> Utf8 Class Initialized
INFO - 2022-06-24 12:46:08 --> URI Class Initialized
INFO - 2022-06-24 12:46:08 --> Router Class Initialized
INFO - 2022-06-24 12:46:08 --> Output Class Initialized
INFO - 2022-06-24 12:46:08 --> Security Class Initialized
DEBUG - 2022-06-24 12:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:46:08 --> Input Class Initialized
INFO - 2022-06-24 12:46:08 --> Language Class Initialized
ERROR - 2022-06-24 12:46:08 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-24 12:46:11 --> Config Class Initialized
INFO - 2022-06-24 12:46:11 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:46:11 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:46:11 --> Utf8 Class Initialized
INFO - 2022-06-24 12:46:11 --> URI Class Initialized
INFO - 2022-06-24 12:46:11 --> Router Class Initialized
INFO - 2022-06-24 12:46:11 --> Output Class Initialized
INFO - 2022-06-24 12:46:11 --> Security Class Initialized
DEBUG - 2022-06-24 12:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:46:11 --> Input Class Initialized
INFO - 2022-06-24 12:46:11 --> Language Class Initialized
INFO - 2022-06-24 12:46:11 --> Loader Class Initialized
INFO - 2022-06-24 12:46:11 --> Helper loaded: url_helper
INFO - 2022-06-24 12:46:11 --> Helper loaded: file_helper
INFO - 2022-06-24 12:46:11 --> Database Driver Class Initialized
INFO - 2022-06-24 12:46:11 --> Email Class Initialized
DEBUG - 2022-06-24 12:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 12:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 12:46:11 --> Controller Class Initialized
INFO - 2022-06-24 12:46:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 12:46:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 12:46:11 --> Final output sent to browser
DEBUG - 2022-06-24 12:46:11 --> Total execution time: 0.0653
INFO - 2022-06-24 12:49:45 --> Config Class Initialized
INFO - 2022-06-24 12:49:45 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:49:45 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:49:45 --> Utf8 Class Initialized
INFO - 2022-06-24 12:49:45 --> URI Class Initialized
INFO - 2022-06-24 12:49:45 --> Router Class Initialized
INFO - 2022-06-24 12:49:45 --> Output Class Initialized
INFO - 2022-06-24 12:49:45 --> Security Class Initialized
DEBUG - 2022-06-24 12:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:49:45 --> Input Class Initialized
INFO - 2022-06-24 12:49:45 --> Language Class Initialized
INFO - 2022-06-24 12:49:45 --> Loader Class Initialized
INFO - 2022-06-24 12:49:45 --> Helper loaded: url_helper
INFO - 2022-06-24 12:49:45 --> Helper loaded: file_helper
INFO - 2022-06-24 12:49:45 --> Database Driver Class Initialized
INFO - 2022-06-24 12:49:45 --> Email Class Initialized
DEBUG - 2022-06-24 12:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 12:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 12:49:45 --> Controller Class Initialized
INFO - 2022-06-24 12:49:45 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 12:49:45 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 12:49:45 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-24 12:49:45 --> Final output sent to browser
DEBUG - 2022-06-24 12:49:45 --> Total execution time: 0.0404
INFO - 2022-06-24 12:50:12 --> Config Class Initialized
INFO - 2022-06-24 12:50:12 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:50:12 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:50:12 --> Utf8 Class Initialized
INFO - 2022-06-24 12:50:12 --> URI Class Initialized
INFO - 2022-06-24 12:50:12 --> Router Class Initialized
INFO - 2022-06-24 12:50:12 --> Output Class Initialized
INFO - 2022-06-24 12:50:12 --> Security Class Initialized
DEBUG - 2022-06-24 12:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:50:12 --> Input Class Initialized
INFO - 2022-06-24 12:50:12 --> Language Class Initialized
INFO - 2022-06-24 12:50:12 --> Loader Class Initialized
INFO - 2022-06-24 12:50:12 --> Helper loaded: url_helper
INFO - 2022-06-24 12:50:12 --> Helper loaded: file_helper
INFO - 2022-06-24 12:50:12 --> Database Driver Class Initialized
INFO - 2022-06-24 12:50:12 --> Email Class Initialized
DEBUG - 2022-06-24 12:50:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 12:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 12:50:12 --> Controller Class Initialized
INFO - 2022-06-24 12:50:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 12:50:12 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 12:50:12 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-24 12:50:12 --> Final output sent to browser
DEBUG - 2022-06-24 12:50:12 --> Total execution time: 0.1316
INFO - 2022-06-24 12:50:12 --> Config Class Initialized
INFO - 2022-06-24 12:50:12 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:50:12 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:50:12 --> Utf8 Class Initialized
INFO - 2022-06-24 12:50:12 --> URI Class Initialized
INFO - 2022-06-24 12:50:12 --> Router Class Initialized
INFO - 2022-06-24 12:50:12 --> Output Class Initialized
INFO - 2022-06-24 12:50:12 --> Security Class Initialized
DEBUG - 2022-06-24 12:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:50:12 --> Input Class Initialized
INFO - 2022-06-24 12:50:12 --> Language Class Initialized
ERROR - 2022-06-24 12:50:12 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-24 12:50:13 --> Config Class Initialized
INFO - 2022-06-24 12:50:13 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:50:13 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:50:13 --> Utf8 Class Initialized
INFO - 2022-06-24 12:50:13 --> URI Class Initialized
INFO - 2022-06-24 12:50:13 --> Router Class Initialized
INFO - 2022-06-24 12:50:13 --> Output Class Initialized
INFO - 2022-06-24 12:50:13 --> Security Class Initialized
DEBUG - 2022-06-24 12:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:50:13 --> Input Class Initialized
INFO - 2022-06-24 12:50:13 --> Language Class Initialized
ERROR - 2022-06-24 12:50:13 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-24 12:50:28 --> Config Class Initialized
INFO - 2022-06-24 12:50:28 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:50:28 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:50:28 --> Utf8 Class Initialized
INFO - 2022-06-24 12:50:28 --> URI Class Initialized
INFO - 2022-06-24 12:50:28 --> Router Class Initialized
INFO - 2022-06-24 12:50:28 --> Output Class Initialized
INFO - 2022-06-24 12:50:28 --> Security Class Initialized
DEBUG - 2022-06-24 12:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:50:28 --> Input Class Initialized
INFO - 2022-06-24 12:50:28 --> Language Class Initialized
INFO - 2022-06-24 12:50:28 --> Loader Class Initialized
INFO - 2022-06-24 12:50:28 --> Helper loaded: url_helper
INFO - 2022-06-24 12:50:28 --> Helper loaded: file_helper
INFO - 2022-06-24 12:50:28 --> Database Driver Class Initialized
INFO - 2022-06-24 12:50:28 --> Email Class Initialized
DEBUG - 2022-06-24 12:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 12:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 12:50:28 --> Controller Class Initialized
INFO - 2022-06-24 12:50:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 12:50:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 12:50:28 --> Final output sent to browser
DEBUG - 2022-06-24 12:50:28 --> Total execution time: 0.1346
INFO - 2022-06-24 12:50:28 --> Config Class Initialized
INFO - 2022-06-24 12:50:28 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:50:28 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:50:28 --> Utf8 Class Initialized
INFO - 2022-06-24 12:50:28 --> URI Class Initialized
INFO - 2022-06-24 12:50:28 --> Router Class Initialized
INFO - 2022-06-24 12:50:28 --> Output Class Initialized
INFO - 2022-06-24 12:50:28 --> Security Class Initialized
DEBUG - 2022-06-24 12:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:50:28 --> Input Class Initialized
INFO - 2022-06-24 12:50:28 --> Language Class Initialized
INFO - 2022-06-24 12:50:28 --> Loader Class Initialized
INFO - 2022-06-24 12:50:28 --> Helper loaded: url_helper
INFO - 2022-06-24 12:50:28 --> Helper loaded: file_helper
INFO - 2022-06-24 12:50:28 --> Database Driver Class Initialized
INFO - 2022-06-24 12:50:28 --> Email Class Initialized
DEBUG - 2022-06-24 12:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 12:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 12:50:28 --> Controller Class Initialized
INFO - 2022-06-24 12:50:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 12:50:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 12:50:28 --> File loaded: C:\wamp64\www\qr\application\views\otp/otp.php
INFO - 2022-06-24 12:50:28 --> Final output sent to browser
DEBUG - 2022-06-24 12:50:28 --> Total execution time: 0.0367
INFO - 2022-06-24 12:54:15 --> Config Class Initialized
INFO - 2022-06-24 12:54:15 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:54:15 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:54:15 --> Utf8 Class Initialized
INFO - 2022-06-24 12:54:15 --> URI Class Initialized
INFO - 2022-06-24 12:54:15 --> Router Class Initialized
INFO - 2022-06-24 12:54:15 --> Output Class Initialized
INFO - 2022-06-24 12:54:15 --> Security Class Initialized
DEBUG - 2022-06-24 12:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:54:15 --> Input Class Initialized
INFO - 2022-06-24 12:54:15 --> Language Class Initialized
INFO - 2022-06-24 12:54:15 --> Loader Class Initialized
INFO - 2022-06-24 12:54:15 --> Helper loaded: url_helper
INFO - 2022-06-24 12:54:15 --> Helper loaded: file_helper
INFO - 2022-06-24 12:54:15 --> Database Driver Class Initialized
INFO - 2022-06-24 12:54:15 --> Email Class Initialized
DEBUG - 2022-06-24 12:54:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 12:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 12:54:15 --> Controller Class Initialized
INFO - 2022-06-24 12:54:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 12:54:15 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 12:54:15 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-24 12:54:15 --> Final output sent to browser
DEBUG - 2022-06-24 12:54:15 --> Total execution time: 0.0257
INFO - 2022-06-24 12:54:20 --> Config Class Initialized
INFO - 2022-06-24 12:54:20 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:54:20 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:54:20 --> Utf8 Class Initialized
INFO - 2022-06-24 12:54:20 --> URI Class Initialized
INFO - 2022-06-24 12:54:20 --> Router Class Initialized
INFO - 2022-06-24 12:54:20 --> Output Class Initialized
INFO - 2022-06-24 12:54:20 --> Security Class Initialized
DEBUG - 2022-06-24 12:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:54:20 --> Input Class Initialized
INFO - 2022-06-24 12:54:20 --> Language Class Initialized
INFO - 2022-06-24 12:54:20 --> Loader Class Initialized
INFO - 2022-06-24 12:54:20 --> Helper loaded: url_helper
INFO - 2022-06-24 12:54:20 --> Helper loaded: file_helper
INFO - 2022-06-24 12:54:20 --> Database Driver Class Initialized
INFO - 2022-06-24 12:54:21 --> Email Class Initialized
DEBUG - 2022-06-24 12:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 12:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 12:54:21 --> Controller Class Initialized
INFO - 2022-06-24 12:54:21 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 12:54:21 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 12:54:21 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-24 12:54:21 --> Final output sent to browser
DEBUG - 2022-06-24 12:54:21 --> Total execution time: 0.1889
INFO - 2022-06-24 12:54:21 --> Config Class Initialized
INFO - 2022-06-24 12:54:21 --> Hooks Class Initialized
INFO - 2022-06-24 12:54:21 --> Config Class Initialized
INFO - 2022-06-24 12:54:21 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:54:21 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:54:21 --> Utf8 Class Initialized
DEBUG - 2022-06-24 12:54:21 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:54:21 --> Utf8 Class Initialized
INFO - 2022-06-24 12:54:21 --> URI Class Initialized
INFO - 2022-06-24 12:54:21 --> URI Class Initialized
INFO - 2022-06-24 12:54:21 --> Router Class Initialized
INFO - 2022-06-24 12:54:21 --> Output Class Initialized
INFO - 2022-06-24 12:54:21 --> Router Class Initialized
INFO - 2022-06-24 12:54:21 --> Security Class Initialized
INFO - 2022-06-24 12:54:21 --> Output Class Initialized
DEBUG - 2022-06-24 12:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:54:21 --> Security Class Initialized
INFO - 2022-06-24 12:54:21 --> Input Class Initialized
DEBUG - 2022-06-24 12:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:54:21 --> Input Class Initialized
INFO - 2022-06-24 12:54:21 --> Language Class Initialized
INFO - 2022-06-24 12:54:21 --> Language Class Initialized
ERROR - 2022-06-24 12:54:21 --> 404 Page Not Found: Tokenctrl/localhost
ERROR - 2022-06-24 12:54:21 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-24 12:54:26 --> Config Class Initialized
INFO - 2022-06-24 12:54:26 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:54:26 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:54:26 --> Utf8 Class Initialized
INFO - 2022-06-24 12:54:26 --> URI Class Initialized
INFO - 2022-06-24 12:54:26 --> Router Class Initialized
INFO - 2022-06-24 12:54:26 --> Output Class Initialized
INFO - 2022-06-24 12:54:26 --> Security Class Initialized
DEBUG - 2022-06-24 12:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:54:26 --> Input Class Initialized
INFO - 2022-06-24 12:54:26 --> Language Class Initialized
ERROR - 2022-06-24 12:54:26 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-24 12:54:26 --> Config Class Initialized
INFO - 2022-06-24 12:54:26 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:54:26 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:54:26 --> Utf8 Class Initialized
INFO - 2022-06-24 12:54:26 --> URI Class Initialized
INFO - 2022-06-24 12:54:26 --> Router Class Initialized
INFO - 2022-06-24 12:54:26 --> Output Class Initialized
INFO - 2022-06-24 12:54:26 --> Security Class Initialized
DEBUG - 2022-06-24 12:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:54:26 --> Input Class Initialized
INFO - 2022-06-24 12:54:26 --> Language Class Initialized
ERROR - 2022-06-24 12:54:26 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-24 12:55:30 --> Config Class Initialized
INFO - 2022-06-24 12:55:30 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:55:30 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:55:30 --> Utf8 Class Initialized
INFO - 2022-06-24 12:55:30 --> URI Class Initialized
INFO - 2022-06-24 12:55:30 --> Router Class Initialized
INFO - 2022-06-24 12:55:30 --> Output Class Initialized
INFO - 2022-06-24 12:55:30 --> Security Class Initialized
DEBUG - 2022-06-24 12:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:55:30 --> Input Class Initialized
INFO - 2022-06-24 12:55:30 --> Language Class Initialized
INFO - 2022-06-24 12:55:30 --> Loader Class Initialized
INFO - 2022-06-24 12:55:30 --> Helper loaded: url_helper
INFO - 2022-06-24 12:55:30 --> Helper loaded: file_helper
INFO - 2022-06-24 12:55:30 --> Database Driver Class Initialized
INFO - 2022-06-24 12:55:30 --> Email Class Initialized
DEBUG - 2022-06-24 12:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 12:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 12:55:30 --> Controller Class Initialized
INFO - 2022-06-24 12:55:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 12:55:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 12:55:30 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-24 12:55:30 --> Final output sent to browser
DEBUG - 2022-06-24 12:55:30 --> Total execution time: 0.0349
INFO - 2022-06-24 12:55:30 --> Config Class Initialized
INFO - 2022-06-24 12:55:30 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:55:30 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:55:30 --> Utf8 Class Initialized
INFO - 2022-06-24 12:55:30 --> URI Class Initialized
INFO - 2022-06-24 12:55:30 --> Router Class Initialized
INFO - 2022-06-24 12:55:30 --> Output Class Initialized
INFO - 2022-06-24 12:55:30 --> Security Class Initialized
DEBUG - 2022-06-24 12:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:55:30 --> Input Class Initialized
INFO - 2022-06-24 12:55:30 --> Config Class Initialized
INFO - 2022-06-24 12:55:30 --> Language Class Initialized
INFO - 2022-06-24 12:55:30 --> Hooks Class Initialized
ERROR - 2022-06-24 12:55:30 --> 404 Page Not Found: Tokenctrl/localhost
DEBUG - 2022-06-24 12:55:30 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:55:30 --> Utf8 Class Initialized
INFO - 2022-06-24 12:55:30 --> URI Class Initialized
INFO - 2022-06-24 12:55:30 --> Router Class Initialized
INFO - 2022-06-24 12:55:30 --> Output Class Initialized
INFO - 2022-06-24 12:55:30 --> Security Class Initialized
DEBUG - 2022-06-24 12:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:55:30 --> Input Class Initialized
INFO - 2022-06-24 12:55:30 --> Language Class Initialized
ERROR - 2022-06-24 12:55:30 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-24 12:55:52 --> Config Class Initialized
INFO - 2022-06-24 12:55:52 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:55:52 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:55:52 --> Utf8 Class Initialized
INFO - 2022-06-24 12:55:52 --> URI Class Initialized
INFO - 2022-06-24 12:55:52 --> Router Class Initialized
INFO - 2022-06-24 12:55:52 --> Output Class Initialized
INFO - 2022-06-24 12:55:52 --> Security Class Initialized
DEBUG - 2022-06-24 12:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:55:52 --> Input Class Initialized
INFO - 2022-06-24 12:55:52 --> Language Class Initialized
INFO - 2022-06-24 12:55:52 --> Loader Class Initialized
INFO - 2022-06-24 12:55:52 --> Helper loaded: url_helper
INFO - 2022-06-24 12:55:52 --> Helper loaded: file_helper
INFO - 2022-06-24 12:55:52 --> Database Driver Class Initialized
INFO - 2022-06-24 12:55:52 --> Email Class Initialized
DEBUG - 2022-06-24 12:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 12:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 12:55:52 --> Controller Class Initialized
INFO - 2022-06-24 12:55:52 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 12:55:52 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 12:55:52 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-24 12:55:52 --> Final output sent to browser
DEBUG - 2022-06-24 12:55:52 --> Total execution time: 0.2785
INFO - 2022-06-24 12:55:52 --> Config Class Initialized
INFO - 2022-06-24 12:55:52 --> Hooks Class Initialized
INFO - 2022-06-24 12:55:52 --> Config Class Initialized
INFO - 2022-06-24 12:55:52 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:55:52 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:55:52 --> Utf8 Class Initialized
DEBUG - 2022-06-24 12:55:52 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:55:52 --> Utf8 Class Initialized
INFO - 2022-06-24 12:55:52 --> URI Class Initialized
INFO - 2022-06-24 12:55:52 --> URI Class Initialized
INFO - 2022-06-24 12:55:52 --> Router Class Initialized
INFO - 2022-06-24 12:55:52 --> Router Class Initialized
INFO - 2022-06-24 12:55:52 --> Output Class Initialized
INFO - 2022-06-24 12:55:52 --> Output Class Initialized
INFO - 2022-06-24 12:55:52 --> Security Class Initialized
INFO - 2022-06-24 12:55:52 --> Security Class Initialized
DEBUG - 2022-06-24 12:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:55:52 --> Input Class Initialized
DEBUG - 2022-06-24 12:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:55:52 --> Input Class Initialized
INFO - 2022-06-24 12:55:52 --> Language Class Initialized
INFO - 2022-06-24 12:55:52 --> Language Class Initialized
ERROR - 2022-06-24 12:55:52 --> 404 Page Not Found: Tokenctrl/localhost
ERROR - 2022-06-24 12:55:52 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-24 12:56:15 --> Config Class Initialized
INFO - 2022-06-24 12:56:15 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:56:15 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:56:15 --> Utf8 Class Initialized
INFO - 2022-06-24 12:56:15 --> URI Class Initialized
INFO - 2022-06-24 12:56:15 --> Router Class Initialized
INFO - 2022-06-24 12:56:15 --> Output Class Initialized
INFO - 2022-06-24 12:56:15 --> Security Class Initialized
DEBUG - 2022-06-24 12:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:56:15 --> Input Class Initialized
INFO - 2022-06-24 12:56:15 --> Language Class Initialized
INFO - 2022-06-24 12:56:15 --> Loader Class Initialized
INFO - 2022-06-24 12:56:15 --> Helper loaded: url_helper
INFO - 2022-06-24 12:56:15 --> Helper loaded: file_helper
INFO - 2022-06-24 12:56:15 --> Database Driver Class Initialized
INFO - 2022-06-24 12:56:15 --> Email Class Initialized
DEBUG - 2022-06-24 12:56:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 12:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 12:56:15 --> Controller Class Initialized
INFO - 2022-06-24 12:56:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 12:56:15 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 12:56:15 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-24 12:56:15 --> Final output sent to browser
DEBUG - 2022-06-24 12:56:15 --> Total execution time: 0.0942
INFO - 2022-06-24 12:56:15 --> Config Class Initialized
INFO - 2022-06-24 12:56:15 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:56:15 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:56:15 --> Utf8 Class Initialized
INFO - 2022-06-24 12:56:15 --> Config Class Initialized
INFO - 2022-06-24 12:56:15 --> URI Class Initialized
INFO - 2022-06-24 12:56:15 --> Hooks Class Initialized
INFO - 2022-06-24 12:56:15 --> Router Class Initialized
INFO - 2022-06-24 12:56:15 --> Output Class Initialized
INFO - 2022-06-24 12:56:15 --> Security Class Initialized
DEBUG - 2022-06-24 12:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:56:15 --> Input Class Initialized
INFO - 2022-06-24 12:56:15 --> Language Class Initialized
ERROR - 2022-06-24 12:56:15 --> 404 Page Not Found: Tokenctrl/localhost
DEBUG - 2022-06-24 12:56:15 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:56:15 --> Utf8 Class Initialized
INFO - 2022-06-24 12:56:15 --> URI Class Initialized
INFO - 2022-06-24 12:56:15 --> Router Class Initialized
INFO - 2022-06-24 12:56:15 --> Output Class Initialized
INFO - 2022-06-24 12:56:15 --> Security Class Initialized
DEBUG - 2022-06-24 12:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:56:15 --> Input Class Initialized
INFO - 2022-06-24 12:56:15 --> Language Class Initialized
ERROR - 2022-06-24 12:56:15 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-24 12:59:24 --> Config Class Initialized
INFO - 2022-06-24 12:59:24 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:59:24 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:59:24 --> Utf8 Class Initialized
INFO - 2022-06-24 12:59:24 --> URI Class Initialized
INFO - 2022-06-24 12:59:24 --> Router Class Initialized
INFO - 2022-06-24 12:59:24 --> Output Class Initialized
INFO - 2022-06-24 12:59:24 --> Security Class Initialized
DEBUG - 2022-06-24 12:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:59:24 --> Input Class Initialized
INFO - 2022-06-24 12:59:24 --> Language Class Initialized
INFO - 2022-06-24 12:59:24 --> Loader Class Initialized
INFO - 2022-06-24 12:59:24 --> Helper loaded: url_helper
INFO - 2022-06-24 12:59:24 --> Helper loaded: file_helper
INFO - 2022-06-24 12:59:24 --> Database Driver Class Initialized
INFO - 2022-06-24 12:59:24 --> Email Class Initialized
DEBUG - 2022-06-24 12:59:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 12:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 12:59:24 --> Controller Class Initialized
INFO - 2022-06-24 12:59:24 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 12:59:24 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 12:59:24 --> Final output sent to browser
DEBUG - 2022-06-24 12:59:24 --> Total execution time: 0.1266
INFO - 2022-06-24 12:59:27 --> Config Class Initialized
INFO - 2022-06-24 12:59:27 --> Hooks Class Initialized
DEBUG - 2022-06-24 12:59:27 --> UTF-8 Support Enabled
INFO - 2022-06-24 12:59:27 --> Utf8 Class Initialized
INFO - 2022-06-24 12:59:27 --> URI Class Initialized
INFO - 2022-06-24 12:59:27 --> Router Class Initialized
INFO - 2022-06-24 12:59:27 --> Output Class Initialized
INFO - 2022-06-24 12:59:27 --> Security Class Initialized
DEBUG - 2022-06-24 12:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 12:59:27 --> Input Class Initialized
INFO - 2022-06-24 12:59:27 --> Language Class Initialized
INFO - 2022-06-24 12:59:27 --> Loader Class Initialized
INFO - 2022-06-24 12:59:27 --> Helper loaded: url_helper
INFO - 2022-06-24 12:59:27 --> Helper loaded: file_helper
INFO - 2022-06-24 12:59:27 --> Database Driver Class Initialized
INFO - 2022-06-24 12:59:27 --> Email Class Initialized
DEBUG - 2022-06-24 12:59:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 12:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 12:59:28 --> Controller Class Initialized
INFO - 2022-06-24 12:59:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 12:59:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 12:59:28 --> Final output sent to browser
DEBUG - 2022-06-24 12:59:28 --> Total execution time: 0.1907
INFO - 2022-06-24 13:00:24 --> Config Class Initialized
INFO - 2022-06-24 13:00:24 --> Hooks Class Initialized
DEBUG - 2022-06-24 13:00:24 --> UTF-8 Support Enabled
INFO - 2022-06-24 13:00:24 --> Utf8 Class Initialized
INFO - 2022-06-24 13:00:24 --> URI Class Initialized
INFO - 2022-06-24 13:00:24 --> Router Class Initialized
INFO - 2022-06-24 13:00:24 --> Output Class Initialized
INFO - 2022-06-24 13:00:24 --> Security Class Initialized
DEBUG - 2022-06-24 13:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 13:00:24 --> Input Class Initialized
INFO - 2022-06-24 13:00:24 --> Language Class Initialized
INFO - 2022-06-24 13:00:24 --> Loader Class Initialized
INFO - 2022-06-24 13:00:24 --> Helper loaded: url_helper
INFO - 2022-06-24 13:00:24 --> Helper loaded: file_helper
INFO - 2022-06-24 13:00:24 --> Database Driver Class Initialized
INFO - 2022-06-24 13:00:24 --> Email Class Initialized
DEBUG - 2022-06-24 13:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 13:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 13:00:24 --> Controller Class Initialized
INFO - 2022-06-24 13:00:24 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 13:00:24 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 13:00:24 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-24 13:00:24 --> Final output sent to browser
DEBUG - 2022-06-24 13:00:24 --> Total execution time: 0.0570
INFO - 2022-06-24 13:00:30 --> Config Class Initialized
INFO - 2022-06-24 13:00:30 --> Hooks Class Initialized
DEBUG - 2022-06-24 13:00:30 --> UTF-8 Support Enabled
INFO - 2022-06-24 13:00:30 --> Utf8 Class Initialized
INFO - 2022-06-24 13:00:30 --> URI Class Initialized
INFO - 2022-06-24 13:00:30 --> Router Class Initialized
INFO - 2022-06-24 13:00:30 --> Output Class Initialized
INFO - 2022-06-24 13:00:30 --> Security Class Initialized
DEBUG - 2022-06-24 13:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 13:00:30 --> Input Class Initialized
INFO - 2022-06-24 13:00:30 --> Language Class Initialized
INFO - 2022-06-24 13:00:30 --> Loader Class Initialized
INFO - 2022-06-24 13:00:30 --> Helper loaded: url_helper
INFO - 2022-06-24 13:00:30 --> Helper loaded: file_helper
INFO - 2022-06-24 13:00:30 --> Database Driver Class Initialized
INFO - 2022-06-24 13:00:30 --> Email Class Initialized
DEBUG - 2022-06-24 13:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 13:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 13:00:30 --> Controller Class Initialized
INFO - 2022-06-24 13:00:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 13:00:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 13:00:30 --> File loaded: C:\wamp64\www\qr\application\views\tokenscreen/Tokenscreen.php
INFO - 2022-06-24 13:00:30 --> Final output sent to browser
DEBUG - 2022-06-24 13:00:30 --> Total execution time: 0.0937
INFO - 2022-06-24 13:00:42 --> Config Class Initialized
INFO - 2022-06-24 13:00:42 --> Hooks Class Initialized
DEBUG - 2022-06-24 13:00:42 --> UTF-8 Support Enabled
INFO - 2022-06-24 13:00:42 --> Utf8 Class Initialized
INFO - 2022-06-24 13:00:42 --> URI Class Initialized
INFO - 2022-06-24 13:00:42 --> Router Class Initialized
INFO - 2022-06-24 13:00:42 --> Output Class Initialized
INFO - 2022-06-24 13:00:42 --> Security Class Initialized
DEBUG - 2022-06-24 13:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 13:00:42 --> Input Class Initialized
INFO - 2022-06-24 13:00:42 --> Language Class Initialized
INFO - 2022-06-24 13:00:42 --> Loader Class Initialized
INFO - 2022-06-24 13:00:42 --> Helper loaded: url_helper
INFO - 2022-06-24 13:00:42 --> Helper loaded: file_helper
INFO - 2022-06-24 13:00:42 --> Database Driver Class Initialized
INFO - 2022-06-24 13:00:42 --> Email Class Initialized
DEBUG - 2022-06-24 13:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 13:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 13:00:42 --> Controller Class Initialized
INFO - 2022-06-24 13:00:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 13:00:42 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 13:00:42 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-24 13:00:42 --> Final output sent to browser
DEBUG - 2022-06-24 13:00:42 --> Total execution time: 0.1313
INFO - 2022-06-24 13:00:42 --> Config Class Initialized
INFO - 2022-06-24 13:00:42 --> Hooks Class Initialized
DEBUG - 2022-06-24 13:00:42 --> UTF-8 Support Enabled
INFO - 2022-06-24 13:00:42 --> Utf8 Class Initialized
INFO - 2022-06-24 13:00:42 --> URI Class Initialized
INFO - 2022-06-24 13:00:42 --> Router Class Initialized
INFO - 2022-06-24 13:00:42 --> Output Class Initialized
INFO - 2022-06-24 13:00:42 --> Security Class Initialized
DEBUG - 2022-06-24 13:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 13:00:42 --> Input Class Initialized
INFO - 2022-06-24 13:00:42 --> Language Class Initialized
ERROR - 2022-06-24 13:00:42 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-24 13:00:42 --> Config Class Initialized
INFO - 2022-06-24 13:00:42 --> Hooks Class Initialized
DEBUG - 2022-06-24 13:00:42 --> UTF-8 Support Enabled
INFO - 2022-06-24 13:00:42 --> Utf8 Class Initialized
INFO - 2022-06-24 13:00:42 --> URI Class Initialized
INFO - 2022-06-24 13:00:42 --> Router Class Initialized
INFO - 2022-06-24 13:00:42 --> Output Class Initialized
INFO - 2022-06-24 13:00:42 --> Security Class Initialized
DEBUG - 2022-06-24 13:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 13:00:42 --> Input Class Initialized
INFO - 2022-06-24 13:00:42 --> Language Class Initialized
ERROR - 2022-06-24 13:00:42 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-24 13:02:12 --> Config Class Initialized
INFO - 2022-06-24 13:02:12 --> Hooks Class Initialized
DEBUG - 2022-06-24 13:02:12 --> UTF-8 Support Enabled
INFO - 2022-06-24 13:02:12 --> Utf8 Class Initialized
INFO - 2022-06-24 13:02:12 --> URI Class Initialized
INFO - 2022-06-24 13:02:12 --> Router Class Initialized
INFO - 2022-06-24 13:02:12 --> Output Class Initialized
INFO - 2022-06-24 13:02:12 --> Security Class Initialized
DEBUG - 2022-06-24 13:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 13:02:12 --> Input Class Initialized
INFO - 2022-06-24 13:02:12 --> Language Class Initialized
INFO - 2022-06-24 13:02:12 --> Loader Class Initialized
INFO - 2022-06-24 13:02:12 --> Helper loaded: url_helper
INFO - 2022-06-24 13:02:12 --> Helper loaded: file_helper
INFO - 2022-06-24 13:02:12 --> Database Driver Class Initialized
INFO - 2022-06-24 13:02:12 --> Email Class Initialized
DEBUG - 2022-06-24 13:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 13:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 13:02:12 --> Controller Class Initialized
INFO - 2022-06-24 13:02:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 13:02:12 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 13:02:12 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-24 13:02:12 --> Final output sent to browser
DEBUG - 2022-06-24 13:02:12 --> Total execution time: 0.0761
INFO - 2022-06-24 13:02:12 --> Config Class Initialized
INFO - 2022-06-24 13:02:12 --> Hooks Class Initialized
DEBUG - 2022-06-24 13:02:12 --> UTF-8 Support Enabled
INFO - 2022-06-24 13:02:12 --> Utf8 Class Initialized
INFO - 2022-06-24 13:02:12 --> URI Class Initialized
INFO - 2022-06-24 13:02:12 --> Router Class Initialized
INFO - 2022-06-24 13:02:12 --> Output Class Initialized
INFO - 2022-06-24 13:02:12 --> Security Class Initialized
DEBUG - 2022-06-24 13:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 13:02:12 --> Input Class Initialized
INFO - 2022-06-24 13:02:12 --> Language Class Initialized
ERROR - 2022-06-24 13:02:12 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-24 13:02:13 --> Config Class Initialized
INFO - 2022-06-24 13:02:13 --> Hooks Class Initialized
DEBUG - 2022-06-24 13:02:13 --> UTF-8 Support Enabled
INFO - 2022-06-24 13:02:13 --> Utf8 Class Initialized
INFO - 2022-06-24 13:02:13 --> URI Class Initialized
INFO - 2022-06-24 13:02:13 --> Router Class Initialized
INFO - 2022-06-24 13:02:13 --> Output Class Initialized
INFO - 2022-06-24 13:02:13 --> Security Class Initialized
DEBUG - 2022-06-24 13:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 13:02:13 --> Input Class Initialized
INFO - 2022-06-24 13:02:13 --> Language Class Initialized
ERROR - 2022-06-24 13:02:13 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-24 13:03:07 --> Config Class Initialized
INFO - 2022-06-24 13:03:07 --> Hooks Class Initialized
DEBUG - 2022-06-24 13:03:07 --> UTF-8 Support Enabled
INFO - 2022-06-24 13:03:07 --> Utf8 Class Initialized
INFO - 2022-06-24 13:03:07 --> URI Class Initialized
INFO - 2022-06-24 13:03:07 --> Router Class Initialized
INFO - 2022-06-24 13:03:07 --> Output Class Initialized
INFO - 2022-06-24 13:03:07 --> Security Class Initialized
DEBUG - 2022-06-24 13:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 13:03:07 --> Input Class Initialized
INFO - 2022-06-24 13:03:07 --> Language Class Initialized
INFO - 2022-06-24 13:03:07 --> Loader Class Initialized
INFO - 2022-06-24 13:03:07 --> Helper loaded: url_helper
INFO - 2022-06-24 13:03:07 --> Helper loaded: file_helper
INFO - 2022-06-24 13:03:07 --> Database Driver Class Initialized
INFO - 2022-06-24 13:03:08 --> Email Class Initialized
DEBUG - 2022-06-24 13:03:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 13:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 13:03:08 --> Controller Class Initialized
INFO - 2022-06-24 13:03:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 13:03:08 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 13:03:08 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-24 13:03:08 --> Final output sent to browser
DEBUG - 2022-06-24 13:03:08 --> Total execution time: 0.1749
INFO - 2022-06-24 13:03:08 --> Config Class Initialized
INFO - 2022-06-24 13:03:08 --> Hooks Class Initialized
DEBUG - 2022-06-24 13:03:08 --> UTF-8 Support Enabled
INFO - 2022-06-24 13:03:08 --> Utf8 Class Initialized
INFO - 2022-06-24 13:03:08 --> URI Class Initialized
INFO - 2022-06-24 13:03:08 --> Router Class Initialized
INFO - 2022-06-24 13:03:08 --> Output Class Initialized
INFO - 2022-06-24 13:03:08 --> Security Class Initialized
DEBUG - 2022-06-24 13:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 13:03:08 --> Input Class Initialized
INFO - 2022-06-24 13:03:08 --> Language Class Initialized
ERROR - 2022-06-24 13:03:08 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-24 13:03:08 --> Config Class Initialized
INFO - 2022-06-24 13:03:08 --> Hooks Class Initialized
DEBUG - 2022-06-24 13:03:08 --> UTF-8 Support Enabled
INFO - 2022-06-24 13:03:08 --> Utf8 Class Initialized
INFO - 2022-06-24 13:03:08 --> URI Class Initialized
INFO - 2022-06-24 13:03:08 --> Router Class Initialized
INFO - 2022-06-24 13:03:08 --> Output Class Initialized
INFO - 2022-06-24 13:03:08 --> Security Class Initialized
DEBUG - 2022-06-24 13:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 13:03:08 --> Input Class Initialized
INFO - 2022-06-24 13:03:08 --> Language Class Initialized
ERROR - 2022-06-24 13:03:08 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-24 13:05:08 --> Config Class Initialized
INFO - 2022-06-24 13:05:08 --> Hooks Class Initialized
DEBUG - 2022-06-24 13:05:08 --> UTF-8 Support Enabled
INFO - 2022-06-24 13:05:08 --> Utf8 Class Initialized
INFO - 2022-06-24 13:05:08 --> URI Class Initialized
INFO - 2022-06-24 13:05:08 --> Router Class Initialized
INFO - 2022-06-24 13:05:08 --> Output Class Initialized
INFO - 2022-06-24 13:05:08 --> Security Class Initialized
DEBUG - 2022-06-24 13:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 13:05:08 --> Input Class Initialized
INFO - 2022-06-24 13:05:08 --> Language Class Initialized
INFO - 2022-06-24 13:05:08 --> Loader Class Initialized
INFO - 2022-06-24 13:05:08 --> Helper loaded: url_helper
INFO - 2022-06-24 13:05:08 --> Helper loaded: file_helper
INFO - 2022-06-24 13:05:08 --> Database Driver Class Initialized
INFO - 2022-06-24 13:05:08 --> Email Class Initialized
DEBUG - 2022-06-24 13:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 13:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 13:05:08 --> Controller Class Initialized
INFO - 2022-06-24 13:05:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 13:05:08 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 13:05:08 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-24 13:05:08 --> Final output sent to browser
DEBUG - 2022-06-24 13:05:08 --> Total execution time: 0.0392
INFO - 2022-06-24 13:05:08 --> Config Class Initialized
INFO - 2022-06-24 13:05:08 --> Hooks Class Initialized
DEBUG - 2022-06-24 13:05:08 --> UTF-8 Support Enabled
INFO - 2022-06-24 13:05:08 --> Utf8 Class Initialized
INFO - 2022-06-24 13:05:08 --> URI Class Initialized
INFO - 2022-06-24 13:05:08 --> Router Class Initialized
INFO - 2022-06-24 13:05:08 --> Output Class Initialized
INFO - 2022-06-24 13:05:08 --> Security Class Initialized
DEBUG - 2022-06-24 13:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 13:05:08 --> Input Class Initialized
INFO - 2022-06-24 13:05:08 --> Language Class Initialized
ERROR - 2022-06-24 13:05:08 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-24 13:05:08 --> Config Class Initialized
INFO - 2022-06-24 13:05:08 --> Hooks Class Initialized
DEBUG - 2022-06-24 13:05:08 --> UTF-8 Support Enabled
INFO - 2022-06-24 13:05:08 --> Utf8 Class Initialized
INFO - 2022-06-24 13:05:08 --> URI Class Initialized
INFO - 2022-06-24 13:05:08 --> Router Class Initialized
INFO - 2022-06-24 13:05:08 --> Output Class Initialized
INFO - 2022-06-24 13:05:08 --> Security Class Initialized
DEBUG - 2022-06-24 13:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 13:05:08 --> Input Class Initialized
INFO - 2022-06-24 13:05:08 --> Language Class Initialized
ERROR - 2022-06-24 13:05:08 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-24 13:05:28 --> Config Class Initialized
INFO - 2022-06-24 13:05:28 --> Hooks Class Initialized
DEBUG - 2022-06-24 13:05:28 --> UTF-8 Support Enabled
INFO - 2022-06-24 13:05:28 --> Utf8 Class Initialized
INFO - 2022-06-24 13:05:28 --> URI Class Initialized
INFO - 2022-06-24 13:05:28 --> Router Class Initialized
INFO - 2022-06-24 13:05:28 --> Output Class Initialized
INFO - 2022-06-24 13:05:28 --> Security Class Initialized
DEBUG - 2022-06-24 13:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 13:05:28 --> Input Class Initialized
INFO - 2022-06-24 13:05:28 --> Language Class Initialized
INFO - 2022-06-24 13:05:28 --> Loader Class Initialized
INFO - 2022-06-24 13:05:28 --> Helper loaded: url_helper
INFO - 2022-06-24 13:05:28 --> Helper loaded: file_helper
INFO - 2022-06-24 13:05:28 --> Database Driver Class Initialized
INFO - 2022-06-24 13:05:28 --> Email Class Initialized
DEBUG - 2022-06-24 13:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 13:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 13:05:28 --> Controller Class Initialized
INFO - 2022-06-24 13:05:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 13:05:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 13:05:28 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-24 13:05:28 --> Final output sent to browser
DEBUG - 2022-06-24 13:05:28 --> Total execution time: 0.1169
INFO - 2022-06-24 13:05:28 --> Config Class Initialized
INFO - 2022-06-24 13:05:28 --> Hooks Class Initialized
DEBUG - 2022-06-24 13:05:28 --> UTF-8 Support Enabled
INFO - 2022-06-24 13:05:28 --> Utf8 Class Initialized
INFO - 2022-06-24 13:05:28 --> URI Class Initialized
INFO - 2022-06-24 13:05:28 --> Router Class Initialized
INFO - 2022-06-24 13:05:28 --> Output Class Initialized
INFO - 2022-06-24 13:05:28 --> Security Class Initialized
DEBUG - 2022-06-24 13:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 13:05:28 --> Input Class Initialized
INFO - 2022-06-24 13:05:28 --> Language Class Initialized
ERROR - 2022-06-24 13:05:28 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-24 13:05:29 --> Config Class Initialized
INFO - 2022-06-24 13:05:29 --> Hooks Class Initialized
DEBUG - 2022-06-24 13:05:29 --> UTF-8 Support Enabled
INFO - 2022-06-24 13:05:29 --> Utf8 Class Initialized
INFO - 2022-06-24 13:05:29 --> URI Class Initialized
INFO - 2022-06-24 13:05:29 --> Router Class Initialized
INFO - 2022-06-24 13:05:29 --> Output Class Initialized
INFO - 2022-06-24 13:05:29 --> Security Class Initialized
DEBUG - 2022-06-24 13:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 13:05:29 --> Input Class Initialized
INFO - 2022-06-24 13:05:29 --> Language Class Initialized
ERROR - 2022-06-24 13:05:29 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-24 13:06:31 --> Config Class Initialized
INFO - 2022-06-24 13:06:31 --> Hooks Class Initialized
DEBUG - 2022-06-24 13:06:31 --> UTF-8 Support Enabled
INFO - 2022-06-24 13:06:31 --> Utf8 Class Initialized
INFO - 2022-06-24 13:06:31 --> URI Class Initialized
INFO - 2022-06-24 13:06:31 --> Router Class Initialized
INFO - 2022-06-24 13:06:31 --> Output Class Initialized
INFO - 2022-06-24 13:06:31 --> Security Class Initialized
DEBUG - 2022-06-24 13:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 13:06:31 --> Input Class Initialized
INFO - 2022-06-24 13:06:31 --> Language Class Initialized
INFO - 2022-06-24 13:06:31 --> Loader Class Initialized
INFO - 2022-06-24 13:06:31 --> Helper loaded: url_helper
INFO - 2022-06-24 13:06:31 --> Helper loaded: file_helper
INFO - 2022-06-24 13:06:31 --> Database Driver Class Initialized
INFO - 2022-06-24 13:06:31 --> Email Class Initialized
DEBUG - 2022-06-24 13:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 13:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 13:06:31 --> Controller Class Initialized
INFO - 2022-06-24 13:06:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 13:06:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 13:06:31 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-24 13:06:31 --> Final output sent to browser
DEBUG - 2022-06-24 13:06:31 --> Total execution time: 0.0264
INFO - 2022-06-24 13:06:31 --> Config Class Initialized
INFO - 2022-06-24 13:06:31 --> Hooks Class Initialized
DEBUG - 2022-06-24 13:06:31 --> UTF-8 Support Enabled
INFO - 2022-06-24 13:06:31 --> Utf8 Class Initialized
INFO - 2022-06-24 13:06:31 --> URI Class Initialized
INFO - 2022-06-24 13:06:31 --> Router Class Initialized
INFO - 2022-06-24 13:06:31 --> Output Class Initialized
INFO - 2022-06-24 13:06:31 --> Security Class Initialized
DEBUG - 2022-06-24 13:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 13:06:31 --> Input Class Initialized
INFO - 2022-06-24 13:06:31 --> Language Class Initialized
ERROR - 2022-06-24 13:06:31 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-24 13:06:31 --> Config Class Initialized
INFO - 2022-06-24 13:06:31 --> Hooks Class Initialized
DEBUG - 2022-06-24 13:06:31 --> UTF-8 Support Enabled
INFO - 2022-06-24 13:06:31 --> Utf8 Class Initialized
INFO - 2022-06-24 13:06:31 --> URI Class Initialized
INFO - 2022-06-24 13:06:31 --> Router Class Initialized
INFO - 2022-06-24 13:06:31 --> Output Class Initialized
INFO - 2022-06-24 13:06:31 --> Security Class Initialized
DEBUG - 2022-06-24 13:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 13:06:31 --> Input Class Initialized
INFO - 2022-06-24 13:06:31 --> Language Class Initialized
ERROR - 2022-06-24 13:06:31 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-24 13:06:37 --> Config Class Initialized
INFO - 2022-06-24 13:06:37 --> Config Class Initialized
INFO - 2022-06-24 13:06:37 --> Hooks Class Initialized
INFO - 2022-06-24 13:06:37 --> Hooks Class Initialized
DEBUG - 2022-06-24 13:06:37 --> UTF-8 Support Enabled
INFO - 2022-06-24 13:06:37 --> Utf8 Class Initialized
DEBUG - 2022-06-24 13:06:37 --> UTF-8 Support Enabled
INFO - 2022-06-24 13:06:37 --> Utf8 Class Initialized
INFO - 2022-06-24 13:06:37 --> URI Class Initialized
INFO - 2022-06-24 13:06:37 --> URI Class Initialized
INFO - 2022-06-24 13:06:37 --> Router Class Initialized
INFO - 2022-06-24 13:06:37 --> Output Class Initialized
INFO - 2022-06-24 13:06:37 --> Security Class Initialized
INFO - 2022-06-24 13:06:37 --> Router Class Initialized
DEBUG - 2022-06-24 13:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 13:06:37 --> Input Class Initialized
INFO - 2022-06-24 13:06:37 --> Output Class Initialized
INFO - 2022-06-24 13:06:37 --> Language Class Initialized
INFO - 2022-06-24 13:06:37 --> Security Class Initialized
ERROR - 2022-06-24 13:06:37 --> 404 Page Not Found: Tokenctrl/localhost
DEBUG - 2022-06-24 13:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 13:06:37 --> Input Class Initialized
INFO - 2022-06-24 13:06:37 --> Language Class Initialized
ERROR - 2022-06-24 13:06:37 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-24 13:07:01 --> Config Class Initialized
INFO - 2022-06-24 13:07:01 --> Hooks Class Initialized
DEBUG - 2022-06-24 13:07:01 --> UTF-8 Support Enabled
INFO - 2022-06-24 13:07:01 --> Utf8 Class Initialized
INFO - 2022-06-24 13:07:01 --> URI Class Initialized
INFO - 2022-06-24 13:07:01 --> Router Class Initialized
INFO - 2022-06-24 13:07:01 --> Output Class Initialized
INFO - 2022-06-24 13:07:01 --> Security Class Initialized
DEBUG - 2022-06-24 13:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 13:07:01 --> Input Class Initialized
INFO - 2022-06-24 13:07:01 --> Language Class Initialized
INFO - 2022-06-24 13:07:01 --> Loader Class Initialized
INFO - 2022-06-24 13:07:01 --> Helper loaded: url_helper
INFO - 2022-06-24 13:07:01 --> Helper loaded: file_helper
INFO - 2022-06-24 13:07:01 --> Database Driver Class Initialized
INFO - 2022-06-24 13:07:01 --> Email Class Initialized
DEBUG - 2022-06-24 13:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 13:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 13:07:01 --> Controller Class Initialized
INFO - 2022-06-24 13:07:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 13:07:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 13:07:01 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-24 13:07:01 --> Final output sent to browser
DEBUG - 2022-06-24 13:07:01 --> Total execution time: 0.1794
INFO - 2022-06-24 13:07:01 --> Config Class Initialized
INFO - 2022-06-24 13:07:01 --> Hooks Class Initialized
DEBUG - 2022-06-24 13:07:01 --> UTF-8 Support Enabled
INFO - 2022-06-24 13:07:01 --> Utf8 Class Initialized
INFO - 2022-06-24 13:07:01 --> URI Class Initialized
INFO - 2022-06-24 13:07:01 --> Router Class Initialized
INFO - 2022-06-24 13:07:01 --> Output Class Initialized
INFO - 2022-06-24 13:07:01 --> Security Class Initialized
DEBUG - 2022-06-24 13:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 13:07:01 --> Input Class Initialized
INFO - 2022-06-24 13:07:01 --> Language Class Initialized
ERROR - 2022-06-24 13:07:01 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-24 13:07:01 --> Config Class Initialized
INFO - 2022-06-24 13:07:01 --> Hooks Class Initialized
DEBUG - 2022-06-24 13:07:01 --> UTF-8 Support Enabled
INFO - 2022-06-24 13:07:01 --> Utf8 Class Initialized
INFO - 2022-06-24 13:07:01 --> URI Class Initialized
INFO - 2022-06-24 13:07:01 --> Router Class Initialized
INFO - 2022-06-24 13:07:01 --> Output Class Initialized
INFO - 2022-06-24 13:07:01 --> Security Class Initialized
DEBUG - 2022-06-24 13:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 13:07:01 --> Input Class Initialized
INFO - 2022-06-24 13:07:01 --> Language Class Initialized
ERROR - 2022-06-24 13:07:01 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-24 13:07:41 --> Config Class Initialized
INFO - 2022-06-24 13:07:41 --> Hooks Class Initialized
DEBUG - 2022-06-24 13:07:41 --> UTF-8 Support Enabled
INFO - 2022-06-24 13:07:41 --> Utf8 Class Initialized
INFO - 2022-06-24 13:07:41 --> URI Class Initialized
INFO - 2022-06-24 13:07:41 --> Router Class Initialized
INFO - 2022-06-24 13:07:41 --> Output Class Initialized
INFO - 2022-06-24 13:07:41 --> Security Class Initialized
DEBUG - 2022-06-24 13:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 13:07:41 --> Input Class Initialized
INFO - 2022-06-24 13:07:41 --> Language Class Initialized
INFO - 2022-06-24 13:07:41 --> Loader Class Initialized
INFO - 2022-06-24 13:07:41 --> Helper loaded: url_helper
INFO - 2022-06-24 13:07:41 --> Helper loaded: file_helper
INFO - 2022-06-24 13:07:41 --> Database Driver Class Initialized
INFO - 2022-06-24 13:07:41 --> Email Class Initialized
DEBUG - 2022-06-24 13:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 13:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 13:07:41 --> Controller Class Initialized
INFO - 2022-06-24 13:07:41 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 13:07:41 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 13:07:41 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-24 13:07:41 --> Final output sent to browser
DEBUG - 2022-06-24 13:07:41 --> Total execution time: 0.1897
INFO - 2022-06-24 13:07:41 --> Config Class Initialized
INFO - 2022-06-24 13:07:41 --> Hooks Class Initialized
DEBUG - 2022-06-24 13:07:41 --> UTF-8 Support Enabled
INFO - 2022-06-24 13:07:41 --> Utf8 Class Initialized
INFO - 2022-06-24 13:07:41 --> URI Class Initialized
INFO - 2022-06-24 13:07:41 --> Router Class Initialized
INFO - 2022-06-24 13:07:41 --> Output Class Initialized
INFO - 2022-06-24 13:07:41 --> Security Class Initialized
DEBUG - 2022-06-24 13:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 13:07:41 --> Input Class Initialized
INFO - 2022-06-24 13:07:41 --> Language Class Initialized
ERROR - 2022-06-24 13:07:41 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-24 13:07:41 --> Config Class Initialized
INFO - 2022-06-24 13:07:41 --> Hooks Class Initialized
DEBUG - 2022-06-24 13:07:41 --> UTF-8 Support Enabled
INFO - 2022-06-24 13:07:41 --> Utf8 Class Initialized
INFO - 2022-06-24 13:07:41 --> URI Class Initialized
INFO - 2022-06-24 13:07:41 --> Router Class Initialized
INFO - 2022-06-24 13:07:41 --> Output Class Initialized
INFO - 2022-06-24 13:07:41 --> Security Class Initialized
DEBUG - 2022-06-24 13:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 13:07:41 --> Input Class Initialized
INFO - 2022-06-24 13:07:41 --> Language Class Initialized
ERROR - 2022-06-24 13:07:41 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-24 13:07:43 --> Config Class Initialized
INFO - 2022-06-24 13:07:43 --> Hooks Class Initialized
DEBUG - 2022-06-24 13:07:43 --> UTF-8 Support Enabled
INFO - 2022-06-24 13:07:43 --> Utf8 Class Initialized
INFO - 2022-06-24 13:07:43 --> URI Class Initialized
INFO - 2022-06-24 13:07:43 --> Router Class Initialized
INFO - 2022-06-24 13:07:43 --> Output Class Initialized
INFO - 2022-06-24 13:07:43 --> Security Class Initialized
DEBUG - 2022-06-24 13:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 13:07:43 --> Input Class Initialized
INFO - 2022-06-24 13:07:43 --> Language Class Initialized
INFO - 2022-06-24 13:07:43 --> Loader Class Initialized
INFO - 2022-06-24 13:07:43 --> Helper loaded: url_helper
INFO - 2022-06-24 13:07:43 --> Helper loaded: file_helper
INFO - 2022-06-24 13:07:43 --> Database Driver Class Initialized
INFO - 2022-06-24 13:07:43 --> Email Class Initialized
DEBUG - 2022-06-24 13:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 13:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 13:07:43 --> Controller Class Initialized
INFO - 2022-06-24 13:07:43 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 13:07:43 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 13:07:43 --> Final output sent to browser
DEBUG - 2022-06-24 13:07:43 --> Total execution time: 0.0235
INFO - 2022-06-24 13:07:44 --> Config Class Initialized
INFO - 2022-06-24 13:07:44 --> Hooks Class Initialized
DEBUG - 2022-06-24 13:07:44 --> UTF-8 Support Enabled
INFO - 2022-06-24 13:07:44 --> Utf8 Class Initialized
INFO - 2022-06-24 13:07:44 --> URI Class Initialized
INFO - 2022-06-24 13:07:44 --> Router Class Initialized
INFO - 2022-06-24 13:07:44 --> Output Class Initialized
INFO - 2022-06-24 13:07:44 --> Security Class Initialized
DEBUG - 2022-06-24 13:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 13:07:44 --> Input Class Initialized
INFO - 2022-06-24 13:07:44 --> Language Class Initialized
INFO - 2022-06-24 13:07:44 --> Loader Class Initialized
INFO - 2022-06-24 13:07:44 --> Helper loaded: url_helper
INFO - 2022-06-24 13:07:44 --> Helper loaded: file_helper
INFO - 2022-06-24 13:07:44 --> Database Driver Class Initialized
INFO - 2022-06-24 13:07:44 --> Email Class Initialized
DEBUG - 2022-06-24 13:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 13:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 13:07:44 --> Controller Class Initialized
INFO - 2022-06-24 13:07:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 13:07:44 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 13:07:44 --> Final output sent to browser
DEBUG - 2022-06-24 13:07:44 --> Total execution time: 0.1455
INFO - 2022-06-24 13:07:56 --> Config Class Initialized
INFO - 2022-06-24 13:07:56 --> Hooks Class Initialized
DEBUG - 2022-06-24 13:07:56 --> UTF-8 Support Enabled
INFO - 2022-06-24 13:07:56 --> Utf8 Class Initialized
INFO - 2022-06-24 13:07:56 --> URI Class Initialized
INFO - 2022-06-24 13:07:56 --> Router Class Initialized
INFO - 2022-06-24 13:07:56 --> Output Class Initialized
INFO - 2022-06-24 13:07:56 --> Security Class Initialized
DEBUG - 2022-06-24 13:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 13:07:56 --> Input Class Initialized
INFO - 2022-06-24 13:07:56 --> Language Class Initialized
INFO - 2022-06-24 13:07:56 --> Loader Class Initialized
INFO - 2022-06-24 13:07:56 --> Helper loaded: url_helper
INFO - 2022-06-24 13:07:56 --> Helper loaded: file_helper
INFO - 2022-06-24 13:07:56 --> Database Driver Class Initialized
INFO - 2022-06-24 13:07:57 --> Email Class Initialized
DEBUG - 2022-06-24 13:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 13:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 13:07:57 --> Controller Class Initialized
INFO - 2022-06-24 13:07:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 13:07:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 13:07:57 --> Final output sent to browser
DEBUG - 2022-06-24 13:07:57 --> Total execution time: 0.3587
INFO - 2022-06-24 13:07:59 --> Config Class Initialized
INFO - 2022-06-24 13:07:59 --> Hooks Class Initialized
DEBUG - 2022-06-24 13:07:59 --> UTF-8 Support Enabled
INFO - 2022-06-24 13:07:59 --> Utf8 Class Initialized
INFO - 2022-06-24 13:07:59 --> URI Class Initialized
INFO - 2022-06-24 13:07:59 --> Router Class Initialized
INFO - 2022-06-24 13:07:59 --> Output Class Initialized
INFO - 2022-06-24 13:07:59 --> Security Class Initialized
DEBUG - 2022-06-24 13:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 13:07:59 --> Input Class Initialized
INFO - 2022-06-24 13:07:59 --> Language Class Initialized
INFO - 2022-06-24 13:07:59 --> Loader Class Initialized
INFO - 2022-06-24 13:07:59 --> Helper loaded: url_helper
INFO - 2022-06-24 13:07:59 --> Helper loaded: file_helper
INFO - 2022-06-24 13:07:59 --> Database Driver Class Initialized
INFO - 2022-06-24 13:07:59 --> Email Class Initialized
DEBUG - 2022-06-24 13:07:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 13:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 13:07:59 --> Controller Class Initialized
INFO - 2022-06-24 13:07:59 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 13:07:59 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 13:07:59 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-24 13:07:59 --> Final output sent to browser
DEBUG - 2022-06-24 13:07:59 --> Total execution time: 0.0509
INFO - 2022-06-24 13:07:59 --> Config Class Initialized
INFO - 2022-06-24 13:07:59 --> Hooks Class Initialized
DEBUG - 2022-06-24 13:07:59 --> UTF-8 Support Enabled
INFO - 2022-06-24 13:07:59 --> Utf8 Class Initialized
INFO - 2022-06-24 13:07:59 --> URI Class Initialized
INFO - 2022-06-24 13:07:59 --> Router Class Initialized
INFO - 2022-06-24 13:07:59 --> Output Class Initialized
INFO - 2022-06-24 13:07:59 --> Security Class Initialized
DEBUG - 2022-06-24 13:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 13:07:59 --> Input Class Initialized
INFO - 2022-06-24 13:07:59 --> Language Class Initialized
ERROR - 2022-06-24 13:07:59 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-24 13:07:59 --> Config Class Initialized
INFO - 2022-06-24 13:07:59 --> Hooks Class Initialized
DEBUG - 2022-06-24 13:07:59 --> UTF-8 Support Enabled
INFO - 2022-06-24 13:07:59 --> Utf8 Class Initialized
INFO - 2022-06-24 13:07:59 --> URI Class Initialized
INFO - 2022-06-24 13:07:59 --> Router Class Initialized
INFO - 2022-06-24 13:07:59 --> Output Class Initialized
INFO - 2022-06-24 13:07:59 --> Security Class Initialized
DEBUG - 2022-06-24 13:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 13:07:59 --> Input Class Initialized
INFO - 2022-06-24 13:07:59 --> Language Class Initialized
ERROR - 2022-06-24 13:07:59 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-24 13:08:06 --> Config Class Initialized
INFO - 2022-06-24 13:08:06 --> Config Class Initialized
INFO - 2022-06-24 13:08:06 --> Hooks Class Initialized
INFO - 2022-06-24 13:08:06 --> Hooks Class Initialized
DEBUG - 2022-06-24 13:08:06 --> UTF-8 Support Enabled
INFO - 2022-06-24 13:08:06 --> Utf8 Class Initialized
INFO - 2022-06-24 13:08:06 --> URI Class Initialized
DEBUG - 2022-06-24 13:08:06 --> UTF-8 Support Enabled
INFO - 2022-06-24 13:08:06 --> Utf8 Class Initialized
INFO - 2022-06-24 13:08:06 --> Router Class Initialized
INFO - 2022-06-24 13:08:06 --> URI Class Initialized
INFO - 2022-06-24 13:08:06 --> Output Class Initialized
INFO - 2022-06-24 13:08:06 --> Router Class Initialized
INFO - 2022-06-24 13:08:06 --> Security Class Initialized
INFO - 2022-06-24 13:08:06 --> Output Class Initialized
DEBUG - 2022-06-24 13:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 13:08:06 --> Security Class Initialized
INFO - 2022-06-24 13:08:06 --> Input Class Initialized
DEBUG - 2022-06-24 13:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 13:08:06 --> Language Class Initialized
INFO - 2022-06-24 13:08:06 --> Input Class Initialized
INFO - 2022-06-24 13:08:06 --> Language Class Initialized
ERROR - 2022-06-24 13:08:06 --> 404 Page Not Found: Tokenctrl/localhost
ERROR - 2022-06-24 13:08:06 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-24 13:08:13 --> Config Class Initialized
INFO - 2022-06-24 13:08:13 --> Hooks Class Initialized
DEBUG - 2022-06-24 13:08:13 --> UTF-8 Support Enabled
INFO - 2022-06-24 13:08:13 --> Utf8 Class Initialized
INFO - 2022-06-24 13:08:13 --> URI Class Initialized
INFO - 2022-06-24 13:08:13 --> Router Class Initialized
INFO - 2022-06-24 13:08:13 --> Output Class Initialized
INFO - 2022-06-24 13:08:13 --> Security Class Initialized
DEBUG - 2022-06-24 13:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 13:08:13 --> Input Class Initialized
INFO - 2022-06-24 13:08:13 --> Language Class Initialized
INFO - 2022-06-24 13:08:13 --> Loader Class Initialized
INFO - 2022-06-24 13:08:13 --> Helper loaded: url_helper
INFO - 2022-06-24 13:08:13 --> Helper loaded: file_helper
INFO - 2022-06-24 13:08:13 --> Database Driver Class Initialized
INFO - 2022-06-24 13:08:13 --> Email Class Initialized
DEBUG - 2022-06-24 13:08:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 13:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 13:08:13 --> Controller Class Initialized
INFO - 2022-06-24 13:08:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 13:08:13 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 13:08:13 --> Final output sent to browser
DEBUG - 2022-06-24 13:08:13 --> Total execution time: 0.0925
INFO - 2022-06-24 13:08:18 --> Config Class Initialized
INFO - 2022-06-24 13:08:18 --> Hooks Class Initialized
DEBUG - 2022-06-24 13:08:18 --> UTF-8 Support Enabled
INFO - 2022-06-24 13:08:18 --> Utf8 Class Initialized
INFO - 2022-06-24 13:08:18 --> URI Class Initialized
INFO - 2022-06-24 13:08:18 --> Router Class Initialized
INFO - 2022-06-24 13:08:18 --> Output Class Initialized
INFO - 2022-06-24 13:08:18 --> Security Class Initialized
DEBUG - 2022-06-24 13:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 13:08:18 --> Input Class Initialized
INFO - 2022-06-24 13:08:18 --> Language Class Initialized
INFO - 2022-06-24 13:08:18 --> Loader Class Initialized
INFO - 2022-06-24 13:08:18 --> Helper loaded: url_helper
INFO - 2022-06-24 13:08:18 --> Helper loaded: file_helper
INFO - 2022-06-24 13:08:18 --> Database Driver Class Initialized
INFO - 2022-06-24 13:08:18 --> Email Class Initialized
DEBUG - 2022-06-24 13:08:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 13:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 13:08:18 --> Controller Class Initialized
INFO - 2022-06-24 13:08:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 13:08:18 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 13:08:18 --> Final output sent to browser
DEBUG - 2022-06-24 13:08:18 --> Total execution time: 0.0522
INFO - 2022-06-24 13:18:32 --> Config Class Initialized
INFO - 2022-06-24 13:18:32 --> Hooks Class Initialized
DEBUG - 2022-06-24 13:18:32 --> UTF-8 Support Enabled
INFO - 2022-06-24 13:18:32 --> Utf8 Class Initialized
INFO - 2022-06-24 13:18:32 --> URI Class Initialized
INFO - 2022-06-24 13:18:32 --> Router Class Initialized
INFO - 2022-06-24 13:18:32 --> Output Class Initialized
INFO - 2022-06-24 13:18:32 --> Security Class Initialized
DEBUG - 2022-06-24 13:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 13:18:32 --> Input Class Initialized
INFO - 2022-06-24 13:18:32 --> Language Class Initialized
INFO - 2022-06-24 13:18:32 --> Loader Class Initialized
INFO - 2022-06-24 13:18:32 --> Helper loaded: url_helper
INFO - 2022-06-24 13:18:32 --> Helper loaded: file_helper
INFO - 2022-06-24 13:18:32 --> Database Driver Class Initialized
INFO - 2022-06-24 13:18:32 --> Email Class Initialized
DEBUG - 2022-06-24 13:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 13:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 13:18:32 --> Controller Class Initialized
INFO - 2022-06-24 13:18:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 13:18:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-24 13:18:32 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::array() C:\wamp64\www\qr\application\models\Tokenmodel.php 28
INFO - 2022-06-24 13:19:06 --> Config Class Initialized
INFO - 2022-06-24 13:19:06 --> Hooks Class Initialized
DEBUG - 2022-06-24 13:19:06 --> UTF-8 Support Enabled
INFO - 2022-06-24 13:19:06 --> Utf8 Class Initialized
INFO - 2022-06-24 13:19:06 --> URI Class Initialized
INFO - 2022-06-24 13:19:06 --> Router Class Initialized
INFO - 2022-06-24 13:19:06 --> Output Class Initialized
INFO - 2022-06-24 13:19:06 --> Security Class Initialized
DEBUG - 2022-06-24 13:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-24 13:19:06 --> Input Class Initialized
INFO - 2022-06-24 13:19:06 --> Language Class Initialized
INFO - 2022-06-24 13:19:06 --> Loader Class Initialized
INFO - 2022-06-24 13:19:06 --> Helper loaded: url_helper
INFO - 2022-06-24 13:19:06 --> Helper loaded: file_helper
INFO - 2022-06-24 13:19:06 --> Database Driver Class Initialized
INFO - 2022-06-24 13:19:06 --> Email Class Initialized
DEBUG - 2022-06-24 13:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-24 13:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-24 13:19:06 --> Controller Class Initialized
INFO - 2022-06-24 13:19:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-24 13:19:06 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-24 13:19:06 --> Final output sent to browser
DEBUG - 2022-06-24 13:19:06 --> Total execution time: 0.0712
