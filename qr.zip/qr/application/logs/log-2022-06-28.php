<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-06-28 04:26:54 --> Config Class Initialized
INFO - 2022-06-28 04:26:54 --> Hooks Class Initialized
DEBUG - 2022-06-28 04:26:54 --> UTF-8 Support Enabled
INFO - 2022-06-28 04:26:54 --> Utf8 Class Initialized
INFO - 2022-06-28 04:26:54 --> URI Class Initialized
INFO - 2022-06-28 04:26:54 --> Router Class Initialized
INFO - 2022-06-28 04:26:54 --> Output Class Initialized
INFO - 2022-06-28 04:26:54 --> Security Class Initialized
DEBUG - 2022-06-28 04:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 04:26:54 --> Input Class Initialized
INFO - 2022-06-28 04:26:54 --> Language Class Initialized
INFO - 2022-06-28 04:26:54 --> Loader Class Initialized
INFO - 2022-06-28 04:26:54 --> Helper loaded: url_helper
INFO - 2022-06-28 04:26:54 --> Helper loaded: file_helper
INFO - 2022-06-28 04:26:54 --> Database Driver Class Initialized
INFO - 2022-06-28 04:26:54 --> Email Class Initialized
DEBUG - 2022-06-28 04:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 04:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 04:26:54 --> Controller Class Initialized
INFO - 2022-06-28 04:26:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 04:26:54 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 04:26:54 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 04:26:54 --> Final output sent to browser
DEBUG - 2022-06-28 04:26:54 --> Total execution time: 0.1321
INFO - 2022-06-28 04:26:58 --> Config Class Initialized
INFO - 2022-06-28 04:26:58 --> Hooks Class Initialized
DEBUG - 2022-06-28 04:26:58 --> UTF-8 Support Enabled
INFO - 2022-06-28 04:26:58 --> Utf8 Class Initialized
INFO - 2022-06-28 04:26:58 --> URI Class Initialized
INFO - 2022-06-28 04:26:58 --> Router Class Initialized
INFO - 2022-06-28 04:26:58 --> Output Class Initialized
INFO - 2022-06-28 04:26:58 --> Security Class Initialized
DEBUG - 2022-06-28 04:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 04:26:58 --> Input Class Initialized
INFO - 2022-06-28 04:26:58 --> Language Class Initialized
INFO - 2022-06-28 04:26:58 --> Loader Class Initialized
INFO - 2022-06-28 04:26:58 --> Helper loaded: url_helper
INFO - 2022-06-28 04:26:58 --> Helper loaded: file_helper
INFO - 2022-06-28 04:26:58 --> Database Driver Class Initialized
INFO - 2022-06-28 04:26:58 --> Email Class Initialized
DEBUG - 2022-06-28 04:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 04:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 04:26:58 --> Controller Class Initialized
INFO - 2022-06-28 04:26:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 04:26:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 04:26:58 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 04:26:58 --> Final output sent to browser
DEBUG - 2022-06-28 04:26:58 --> Total execution time: 0.3476
INFO - 2022-06-28 04:26:58 --> Config Class Initialized
INFO - 2022-06-28 04:26:58 --> Hooks Class Initialized
DEBUG - 2022-06-28 04:26:58 --> UTF-8 Support Enabled
INFO - 2022-06-28 04:26:58 --> Utf8 Class Initialized
INFO - 2022-06-28 04:26:58 --> URI Class Initialized
INFO - 2022-06-28 04:26:58 --> Router Class Initialized
INFO - 2022-06-28 04:26:58 --> Output Class Initialized
INFO - 2022-06-28 04:26:58 --> Security Class Initialized
DEBUG - 2022-06-28 04:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 04:26:58 --> Input Class Initialized
INFO - 2022-06-28 04:26:58 --> Language Class Initialized
ERROR - 2022-06-28 04:26:58 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-28 04:26:58 --> Config Class Initialized
INFO - 2022-06-28 04:26:58 --> Hooks Class Initialized
DEBUG - 2022-06-28 04:26:58 --> UTF-8 Support Enabled
INFO - 2022-06-28 04:26:58 --> Utf8 Class Initialized
INFO - 2022-06-28 04:26:58 --> URI Class Initialized
INFO - 2022-06-28 04:26:58 --> Router Class Initialized
INFO - 2022-06-28 04:26:58 --> Output Class Initialized
INFO - 2022-06-28 04:26:58 --> Security Class Initialized
DEBUG - 2022-06-28 04:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 04:26:58 --> Input Class Initialized
INFO - 2022-06-28 04:26:58 --> Language Class Initialized
ERROR - 2022-06-28 04:26:58 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-28 04:27:05 --> Config Class Initialized
INFO - 2022-06-28 04:27:05 --> Hooks Class Initialized
DEBUG - 2022-06-28 04:27:05 --> UTF-8 Support Enabled
INFO - 2022-06-28 04:27:05 --> Utf8 Class Initialized
INFO - 2022-06-28 04:27:05 --> URI Class Initialized
INFO - 2022-06-28 04:27:05 --> Router Class Initialized
INFO - 2022-06-28 04:27:05 --> Output Class Initialized
INFO - 2022-06-28 04:27:05 --> Security Class Initialized
DEBUG - 2022-06-28 04:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 04:27:05 --> Input Class Initialized
INFO - 2022-06-28 04:27:05 --> Language Class Initialized
INFO - 2022-06-28 04:27:05 --> Loader Class Initialized
INFO - 2022-06-28 04:27:05 --> Helper loaded: url_helper
INFO - 2022-06-28 04:27:05 --> Helper loaded: file_helper
INFO - 2022-06-28 04:27:05 --> Database Driver Class Initialized
INFO - 2022-06-28 04:27:05 --> Email Class Initialized
DEBUG - 2022-06-28 04:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 04:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 04:27:05 --> Controller Class Initialized
INFO - 2022-06-28 04:27:05 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 04:27:05 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 04:27:05 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 04:27:05 --> Final output sent to browser
DEBUG - 2022-06-28 04:27:05 --> Total execution time: 0.0216
INFO - 2022-06-28 05:16:16 --> Config Class Initialized
INFO - 2022-06-28 05:16:16 --> Hooks Class Initialized
DEBUG - 2022-06-28 05:16:16 --> UTF-8 Support Enabled
INFO - 2022-06-28 05:16:16 --> Utf8 Class Initialized
INFO - 2022-06-28 05:16:16 --> URI Class Initialized
INFO - 2022-06-28 05:16:16 --> Router Class Initialized
INFO - 2022-06-28 05:16:16 --> Output Class Initialized
INFO - 2022-06-28 05:16:16 --> Security Class Initialized
DEBUG - 2022-06-28 05:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 05:16:16 --> Input Class Initialized
INFO - 2022-06-28 05:16:16 --> Language Class Initialized
INFO - 2022-06-28 05:16:16 --> Loader Class Initialized
INFO - 2022-06-28 05:16:16 --> Helper loaded: url_helper
INFO - 2022-06-28 05:16:16 --> Helper loaded: file_helper
INFO - 2022-06-28 05:16:16 --> Database Driver Class Initialized
INFO - 2022-06-28 05:16:17 --> Email Class Initialized
DEBUG - 2022-06-28 05:16:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 05:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 05:16:17 --> Controller Class Initialized
INFO - 2022-06-28 05:16:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 05:16:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 05:16:17 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 05:16:17 --> Final output sent to browser
DEBUG - 2022-06-28 05:16:17 --> Total execution time: 1.0496
INFO - 2022-06-28 05:18:05 --> Config Class Initialized
INFO - 2022-06-28 05:18:05 --> Hooks Class Initialized
DEBUG - 2022-06-28 05:18:05 --> UTF-8 Support Enabled
INFO - 2022-06-28 05:18:05 --> Utf8 Class Initialized
INFO - 2022-06-28 05:18:05 --> URI Class Initialized
INFO - 2022-06-28 05:18:05 --> Router Class Initialized
INFO - 2022-06-28 05:18:05 --> Output Class Initialized
INFO - 2022-06-28 05:18:05 --> Security Class Initialized
DEBUG - 2022-06-28 05:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 05:18:05 --> Input Class Initialized
INFO - 2022-06-28 05:18:05 --> Language Class Initialized
INFO - 2022-06-28 05:18:05 --> Loader Class Initialized
INFO - 2022-06-28 05:18:05 --> Helper loaded: url_helper
INFO - 2022-06-28 05:18:05 --> Helper loaded: file_helper
INFO - 2022-06-28 05:18:05 --> Database Driver Class Initialized
INFO - 2022-06-28 05:18:05 --> Email Class Initialized
DEBUG - 2022-06-28 05:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 05:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 05:18:05 --> Controller Class Initialized
INFO - 2022-06-28 05:18:05 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 05:18:05 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 05:18:05 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 05:18:05 --> Final output sent to browser
DEBUG - 2022-06-28 05:18:05 --> Total execution time: 0.2561
INFO - 2022-06-28 05:20:30 --> Config Class Initialized
INFO - 2022-06-28 05:20:30 --> Hooks Class Initialized
DEBUG - 2022-06-28 05:20:30 --> UTF-8 Support Enabled
INFO - 2022-06-28 05:20:30 --> Utf8 Class Initialized
INFO - 2022-06-28 05:20:30 --> URI Class Initialized
INFO - 2022-06-28 05:20:30 --> Router Class Initialized
INFO - 2022-06-28 05:20:30 --> Output Class Initialized
INFO - 2022-06-28 05:20:30 --> Security Class Initialized
DEBUG - 2022-06-28 05:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 05:20:30 --> Input Class Initialized
INFO - 2022-06-28 05:20:30 --> Language Class Initialized
INFO - 2022-06-28 05:20:30 --> Loader Class Initialized
INFO - 2022-06-28 05:20:30 --> Helper loaded: url_helper
INFO - 2022-06-28 05:20:30 --> Helper loaded: file_helper
INFO - 2022-06-28 05:20:30 --> Database Driver Class Initialized
INFO - 2022-06-28 05:20:30 --> Email Class Initialized
DEBUG - 2022-06-28 05:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 05:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 05:20:30 --> Controller Class Initialized
INFO - 2022-06-28 05:20:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 05:20:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 05:20:30 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 05:20:30 --> Final output sent to browser
DEBUG - 2022-06-28 05:20:30 --> Total execution time: 0.1008
INFO - 2022-06-28 05:21:15 --> Config Class Initialized
INFO - 2022-06-28 05:21:15 --> Hooks Class Initialized
DEBUG - 2022-06-28 05:21:15 --> UTF-8 Support Enabled
INFO - 2022-06-28 05:21:15 --> Utf8 Class Initialized
INFO - 2022-06-28 05:21:15 --> URI Class Initialized
INFO - 2022-06-28 05:21:15 --> Router Class Initialized
INFO - 2022-06-28 05:21:15 --> Output Class Initialized
INFO - 2022-06-28 05:21:15 --> Security Class Initialized
DEBUG - 2022-06-28 05:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 05:21:15 --> Input Class Initialized
INFO - 2022-06-28 05:21:15 --> Language Class Initialized
INFO - 2022-06-28 05:21:15 --> Loader Class Initialized
INFO - 2022-06-28 05:21:15 --> Helper loaded: url_helper
INFO - 2022-06-28 05:21:15 --> Helper loaded: file_helper
INFO - 2022-06-28 05:21:15 --> Database Driver Class Initialized
INFO - 2022-06-28 05:21:15 --> Email Class Initialized
DEBUG - 2022-06-28 05:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 05:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 05:21:15 --> Controller Class Initialized
INFO - 2022-06-28 05:21:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 05:21:15 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 05:21:15 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 05:21:15 --> Final output sent to browser
DEBUG - 2022-06-28 05:21:15 --> Total execution time: 0.2137
INFO - 2022-06-28 05:22:31 --> Config Class Initialized
INFO - 2022-06-28 05:22:31 --> Hooks Class Initialized
DEBUG - 2022-06-28 05:22:31 --> UTF-8 Support Enabled
INFO - 2022-06-28 05:22:31 --> Utf8 Class Initialized
INFO - 2022-06-28 05:22:31 --> URI Class Initialized
INFO - 2022-06-28 05:22:31 --> Router Class Initialized
INFO - 2022-06-28 05:22:31 --> Output Class Initialized
INFO - 2022-06-28 05:22:31 --> Security Class Initialized
DEBUG - 2022-06-28 05:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 05:22:31 --> Input Class Initialized
INFO - 2022-06-28 05:22:31 --> Language Class Initialized
INFO - 2022-06-28 05:22:31 --> Loader Class Initialized
INFO - 2022-06-28 05:22:31 --> Helper loaded: url_helper
INFO - 2022-06-28 05:22:31 --> Helper loaded: file_helper
INFO - 2022-06-28 05:22:31 --> Database Driver Class Initialized
INFO - 2022-06-28 05:22:31 --> Email Class Initialized
DEBUG - 2022-06-28 05:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 05:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 05:22:31 --> Controller Class Initialized
INFO - 2022-06-28 05:22:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 05:22:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 05:22:31 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 05:22:31 --> Final output sent to browser
DEBUG - 2022-06-28 05:22:31 --> Total execution time: 0.0446
INFO - 2022-06-28 05:24:27 --> Config Class Initialized
INFO - 2022-06-28 05:24:27 --> Hooks Class Initialized
DEBUG - 2022-06-28 05:24:27 --> UTF-8 Support Enabled
INFO - 2022-06-28 05:24:27 --> Utf8 Class Initialized
INFO - 2022-06-28 05:24:27 --> URI Class Initialized
INFO - 2022-06-28 05:24:27 --> Router Class Initialized
INFO - 2022-06-28 05:24:27 --> Output Class Initialized
INFO - 2022-06-28 05:24:27 --> Security Class Initialized
DEBUG - 2022-06-28 05:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 05:24:27 --> Input Class Initialized
INFO - 2022-06-28 05:24:27 --> Language Class Initialized
INFO - 2022-06-28 05:24:27 --> Loader Class Initialized
INFO - 2022-06-28 05:24:27 --> Helper loaded: url_helper
INFO - 2022-06-28 05:24:27 --> Helper loaded: file_helper
INFO - 2022-06-28 05:24:27 --> Database Driver Class Initialized
INFO - 2022-06-28 05:24:27 --> Email Class Initialized
DEBUG - 2022-06-28 05:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 05:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 05:24:27 --> Controller Class Initialized
INFO - 2022-06-28 05:24:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 05:24:27 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 05:24:27 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 05:24:27 --> Final output sent to browser
DEBUG - 2022-06-28 05:24:27 --> Total execution time: 0.0610
INFO - 2022-06-28 05:25:32 --> Config Class Initialized
INFO - 2022-06-28 05:25:32 --> Hooks Class Initialized
DEBUG - 2022-06-28 05:25:32 --> UTF-8 Support Enabled
INFO - 2022-06-28 05:25:32 --> Utf8 Class Initialized
INFO - 2022-06-28 05:25:32 --> URI Class Initialized
INFO - 2022-06-28 05:25:32 --> Router Class Initialized
INFO - 2022-06-28 05:25:32 --> Output Class Initialized
INFO - 2022-06-28 05:25:32 --> Security Class Initialized
DEBUG - 2022-06-28 05:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 05:25:32 --> Input Class Initialized
INFO - 2022-06-28 05:25:32 --> Language Class Initialized
INFO - 2022-06-28 05:25:32 --> Loader Class Initialized
INFO - 2022-06-28 05:25:32 --> Helper loaded: url_helper
INFO - 2022-06-28 05:25:32 --> Helper loaded: file_helper
INFO - 2022-06-28 05:25:32 --> Database Driver Class Initialized
INFO - 2022-06-28 05:25:32 --> Email Class Initialized
DEBUG - 2022-06-28 05:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 05:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 05:25:32 --> Controller Class Initialized
INFO - 2022-06-28 05:25:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 05:25:32 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 05:25:32 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 05:25:32 --> Final output sent to browser
DEBUG - 2022-06-28 05:25:32 --> Total execution time: 0.1595
INFO - 2022-06-28 05:27:28 --> Config Class Initialized
INFO - 2022-06-28 05:27:28 --> Hooks Class Initialized
DEBUG - 2022-06-28 05:27:28 --> UTF-8 Support Enabled
INFO - 2022-06-28 05:27:28 --> Utf8 Class Initialized
INFO - 2022-06-28 05:27:28 --> URI Class Initialized
INFO - 2022-06-28 05:27:28 --> Router Class Initialized
INFO - 2022-06-28 05:27:28 --> Output Class Initialized
INFO - 2022-06-28 05:27:28 --> Security Class Initialized
DEBUG - 2022-06-28 05:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 05:27:28 --> Input Class Initialized
INFO - 2022-06-28 05:27:28 --> Language Class Initialized
INFO - 2022-06-28 05:27:28 --> Loader Class Initialized
INFO - 2022-06-28 05:27:28 --> Helper loaded: url_helper
INFO - 2022-06-28 05:27:28 --> Helper loaded: file_helper
INFO - 2022-06-28 05:27:28 --> Database Driver Class Initialized
INFO - 2022-06-28 05:27:28 --> Email Class Initialized
DEBUG - 2022-06-28 05:27:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 05:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 05:27:28 --> Controller Class Initialized
INFO - 2022-06-28 05:27:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 05:27:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 05:27:28 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 05:27:28 --> Final output sent to browser
DEBUG - 2022-06-28 05:27:28 --> Total execution time: 0.3172
INFO - 2022-06-28 05:28:20 --> Config Class Initialized
INFO - 2022-06-28 05:28:20 --> Hooks Class Initialized
DEBUG - 2022-06-28 05:28:20 --> UTF-8 Support Enabled
INFO - 2022-06-28 05:28:20 --> Utf8 Class Initialized
INFO - 2022-06-28 05:28:20 --> URI Class Initialized
INFO - 2022-06-28 05:28:20 --> Router Class Initialized
INFO - 2022-06-28 05:28:20 --> Output Class Initialized
INFO - 2022-06-28 05:28:20 --> Security Class Initialized
DEBUG - 2022-06-28 05:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 05:28:20 --> Input Class Initialized
INFO - 2022-06-28 05:28:20 --> Language Class Initialized
INFO - 2022-06-28 05:28:20 --> Loader Class Initialized
INFO - 2022-06-28 05:28:20 --> Helper loaded: url_helper
INFO - 2022-06-28 05:28:20 --> Helper loaded: file_helper
INFO - 2022-06-28 05:28:20 --> Database Driver Class Initialized
INFO - 2022-06-28 05:28:20 --> Email Class Initialized
DEBUG - 2022-06-28 05:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 05:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 05:28:20 --> Controller Class Initialized
INFO - 2022-06-28 05:28:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 05:28:20 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 05:28:20 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 05:28:20 --> Final output sent to browser
DEBUG - 2022-06-28 05:28:20 --> Total execution time: 0.0503
INFO - 2022-06-28 05:29:04 --> Config Class Initialized
INFO - 2022-06-28 05:29:04 --> Hooks Class Initialized
DEBUG - 2022-06-28 05:29:04 --> UTF-8 Support Enabled
INFO - 2022-06-28 05:29:04 --> Utf8 Class Initialized
INFO - 2022-06-28 05:29:04 --> URI Class Initialized
INFO - 2022-06-28 05:29:04 --> Router Class Initialized
INFO - 2022-06-28 05:29:04 --> Output Class Initialized
INFO - 2022-06-28 05:29:04 --> Security Class Initialized
DEBUG - 2022-06-28 05:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 05:29:04 --> Input Class Initialized
INFO - 2022-06-28 05:29:04 --> Language Class Initialized
INFO - 2022-06-28 05:29:04 --> Loader Class Initialized
INFO - 2022-06-28 05:29:04 --> Helper loaded: url_helper
INFO - 2022-06-28 05:29:04 --> Helper loaded: file_helper
INFO - 2022-06-28 05:29:04 --> Database Driver Class Initialized
INFO - 2022-06-28 05:29:05 --> Email Class Initialized
DEBUG - 2022-06-28 05:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 05:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 05:29:05 --> Controller Class Initialized
INFO - 2022-06-28 05:29:05 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 05:29:05 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 05:29:05 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 05:29:05 --> Final output sent to browser
DEBUG - 2022-06-28 05:29:05 --> Total execution time: 0.1232
INFO - 2022-06-28 05:29:26 --> Config Class Initialized
INFO - 2022-06-28 05:29:26 --> Hooks Class Initialized
DEBUG - 2022-06-28 05:29:26 --> UTF-8 Support Enabled
INFO - 2022-06-28 05:29:26 --> Utf8 Class Initialized
INFO - 2022-06-28 05:29:26 --> URI Class Initialized
INFO - 2022-06-28 05:29:26 --> Router Class Initialized
INFO - 2022-06-28 05:29:26 --> Output Class Initialized
INFO - 2022-06-28 05:29:26 --> Security Class Initialized
DEBUG - 2022-06-28 05:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 05:29:26 --> Input Class Initialized
INFO - 2022-06-28 05:29:26 --> Language Class Initialized
INFO - 2022-06-28 05:29:26 --> Loader Class Initialized
INFO - 2022-06-28 05:29:26 --> Helper loaded: url_helper
INFO - 2022-06-28 05:29:26 --> Helper loaded: file_helper
INFO - 2022-06-28 05:29:26 --> Database Driver Class Initialized
INFO - 2022-06-28 05:29:26 --> Email Class Initialized
DEBUG - 2022-06-28 05:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 05:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 05:29:26 --> Controller Class Initialized
INFO - 2022-06-28 05:29:26 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 05:29:26 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 05:29:26 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 05:29:26 --> Final output sent to browser
DEBUG - 2022-06-28 05:29:26 --> Total execution time: 0.0555
INFO - 2022-06-28 05:30:24 --> Config Class Initialized
INFO - 2022-06-28 05:30:24 --> Hooks Class Initialized
DEBUG - 2022-06-28 05:30:24 --> UTF-8 Support Enabled
INFO - 2022-06-28 05:30:24 --> Utf8 Class Initialized
INFO - 2022-06-28 05:30:24 --> URI Class Initialized
INFO - 2022-06-28 05:30:24 --> Router Class Initialized
INFO - 2022-06-28 05:30:24 --> Output Class Initialized
INFO - 2022-06-28 05:30:24 --> Security Class Initialized
DEBUG - 2022-06-28 05:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 05:30:24 --> Input Class Initialized
INFO - 2022-06-28 05:30:24 --> Language Class Initialized
INFO - 2022-06-28 05:30:24 --> Loader Class Initialized
INFO - 2022-06-28 05:30:24 --> Helper loaded: url_helper
INFO - 2022-06-28 05:30:24 --> Helper loaded: file_helper
INFO - 2022-06-28 05:30:24 --> Database Driver Class Initialized
INFO - 2022-06-28 05:30:24 --> Email Class Initialized
DEBUG - 2022-06-28 05:30:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 05:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 05:30:24 --> Controller Class Initialized
INFO - 2022-06-28 05:30:24 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 05:30:24 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 05:30:24 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 05:30:24 --> Final output sent to browser
DEBUG - 2022-06-28 05:30:24 --> Total execution time: 0.1336
INFO - 2022-06-28 05:30:35 --> Config Class Initialized
INFO - 2022-06-28 05:30:35 --> Hooks Class Initialized
DEBUG - 2022-06-28 05:30:35 --> UTF-8 Support Enabled
INFO - 2022-06-28 05:30:35 --> Utf8 Class Initialized
INFO - 2022-06-28 05:30:35 --> URI Class Initialized
INFO - 2022-06-28 05:30:35 --> Router Class Initialized
INFO - 2022-06-28 05:30:35 --> Output Class Initialized
INFO - 2022-06-28 05:30:35 --> Security Class Initialized
DEBUG - 2022-06-28 05:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 05:30:35 --> Input Class Initialized
INFO - 2022-06-28 05:30:35 --> Language Class Initialized
INFO - 2022-06-28 05:30:35 --> Loader Class Initialized
INFO - 2022-06-28 05:30:35 --> Helper loaded: url_helper
INFO - 2022-06-28 05:30:35 --> Helper loaded: file_helper
INFO - 2022-06-28 05:30:35 --> Database Driver Class Initialized
INFO - 2022-06-28 05:30:35 --> Email Class Initialized
DEBUG - 2022-06-28 05:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 05:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 05:30:35 --> Controller Class Initialized
INFO - 2022-06-28 05:30:35 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 05:30:35 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 05:30:35 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 05:30:35 --> Final output sent to browser
DEBUG - 2022-06-28 05:30:35 --> Total execution time: 0.0358
INFO - 2022-06-28 05:32:28 --> Config Class Initialized
INFO - 2022-06-28 05:32:28 --> Hooks Class Initialized
DEBUG - 2022-06-28 05:32:28 --> UTF-8 Support Enabled
INFO - 2022-06-28 05:32:28 --> Utf8 Class Initialized
INFO - 2022-06-28 05:32:28 --> URI Class Initialized
INFO - 2022-06-28 05:32:28 --> Router Class Initialized
INFO - 2022-06-28 05:32:28 --> Output Class Initialized
INFO - 2022-06-28 05:32:28 --> Security Class Initialized
DEBUG - 2022-06-28 05:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 05:32:28 --> Input Class Initialized
INFO - 2022-06-28 05:32:28 --> Language Class Initialized
INFO - 2022-06-28 05:32:28 --> Loader Class Initialized
INFO - 2022-06-28 05:32:28 --> Helper loaded: url_helper
INFO - 2022-06-28 05:32:28 --> Helper loaded: file_helper
INFO - 2022-06-28 05:32:28 --> Database Driver Class Initialized
INFO - 2022-06-28 05:32:28 --> Email Class Initialized
DEBUG - 2022-06-28 05:32:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 05:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 05:32:28 --> Controller Class Initialized
INFO - 2022-06-28 05:32:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 05:32:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 05:32:28 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 05:32:28 --> Final output sent to browser
DEBUG - 2022-06-28 05:32:28 --> Total execution time: 0.0390
INFO - 2022-06-28 05:32:59 --> Config Class Initialized
INFO - 2022-06-28 05:32:59 --> Hooks Class Initialized
DEBUG - 2022-06-28 05:32:59 --> UTF-8 Support Enabled
INFO - 2022-06-28 05:32:59 --> Utf8 Class Initialized
INFO - 2022-06-28 05:32:59 --> URI Class Initialized
INFO - 2022-06-28 05:32:59 --> Router Class Initialized
INFO - 2022-06-28 05:32:59 --> Output Class Initialized
INFO - 2022-06-28 05:32:59 --> Security Class Initialized
DEBUG - 2022-06-28 05:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 05:32:59 --> Input Class Initialized
INFO - 2022-06-28 05:32:59 --> Language Class Initialized
INFO - 2022-06-28 05:32:59 --> Loader Class Initialized
INFO - 2022-06-28 05:32:59 --> Helper loaded: url_helper
INFO - 2022-06-28 05:32:59 --> Helper loaded: file_helper
INFO - 2022-06-28 05:32:59 --> Database Driver Class Initialized
INFO - 2022-06-28 05:32:59 --> Email Class Initialized
DEBUG - 2022-06-28 05:32:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 05:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 05:32:59 --> Controller Class Initialized
INFO - 2022-06-28 05:32:59 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 05:32:59 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 05:32:59 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 05:32:59 --> Final output sent to browser
DEBUG - 2022-06-28 05:32:59 --> Total execution time: 0.0290
INFO - 2022-06-28 05:34:08 --> Config Class Initialized
INFO - 2022-06-28 05:34:08 --> Hooks Class Initialized
DEBUG - 2022-06-28 05:34:08 --> UTF-8 Support Enabled
INFO - 2022-06-28 05:34:08 --> Utf8 Class Initialized
INFO - 2022-06-28 05:34:08 --> URI Class Initialized
INFO - 2022-06-28 05:34:08 --> Router Class Initialized
INFO - 2022-06-28 05:34:08 --> Output Class Initialized
INFO - 2022-06-28 05:34:08 --> Security Class Initialized
DEBUG - 2022-06-28 05:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 05:34:08 --> Input Class Initialized
INFO - 2022-06-28 05:34:08 --> Language Class Initialized
INFO - 2022-06-28 05:34:08 --> Loader Class Initialized
INFO - 2022-06-28 05:34:08 --> Helper loaded: url_helper
INFO - 2022-06-28 05:34:08 --> Helper loaded: file_helper
INFO - 2022-06-28 05:34:08 --> Database Driver Class Initialized
INFO - 2022-06-28 05:34:08 --> Email Class Initialized
DEBUG - 2022-06-28 05:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 05:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 05:34:08 --> Controller Class Initialized
INFO - 2022-06-28 05:34:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 05:34:08 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 05:34:08 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 05:34:08 --> Final output sent to browser
DEBUG - 2022-06-28 05:34:08 --> Total execution time: 0.1208
INFO - 2022-06-28 05:35:02 --> Config Class Initialized
INFO - 2022-06-28 05:35:02 --> Hooks Class Initialized
DEBUG - 2022-06-28 05:35:02 --> UTF-8 Support Enabled
INFO - 2022-06-28 05:35:02 --> Utf8 Class Initialized
INFO - 2022-06-28 05:35:02 --> URI Class Initialized
INFO - 2022-06-28 05:35:02 --> Router Class Initialized
INFO - 2022-06-28 05:35:02 --> Output Class Initialized
INFO - 2022-06-28 05:35:02 --> Security Class Initialized
DEBUG - 2022-06-28 05:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 05:35:02 --> Input Class Initialized
INFO - 2022-06-28 05:35:02 --> Language Class Initialized
INFO - 2022-06-28 05:35:02 --> Loader Class Initialized
INFO - 2022-06-28 05:35:02 --> Helper loaded: url_helper
INFO - 2022-06-28 05:35:02 --> Helper loaded: file_helper
INFO - 2022-06-28 05:35:02 --> Database Driver Class Initialized
INFO - 2022-06-28 05:35:02 --> Email Class Initialized
DEBUG - 2022-06-28 05:35:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 05:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 05:35:02 --> Controller Class Initialized
INFO - 2022-06-28 05:35:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 05:35:02 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 05:35:02 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 05:35:02 --> Final output sent to browser
DEBUG - 2022-06-28 05:35:02 --> Total execution time: 0.0357
INFO - 2022-06-28 05:36:54 --> Config Class Initialized
INFO - 2022-06-28 05:36:54 --> Hooks Class Initialized
DEBUG - 2022-06-28 05:36:54 --> UTF-8 Support Enabled
INFO - 2022-06-28 05:36:54 --> Utf8 Class Initialized
INFO - 2022-06-28 05:36:54 --> URI Class Initialized
INFO - 2022-06-28 05:36:54 --> Router Class Initialized
INFO - 2022-06-28 05:36:54 --> Output Class Initialized
INFO - 2022-06-28 05:36:54 --> Security Class Initialized
DEBUG - 2022-06-28 05:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 05:36:54 --> Input Class Initialized
INFO - 2022-06-28 05:36:54 --> Language Class Initialized
INFO - 2022-06-28 05:36:54 --> Loader Class Initialized
INFO - 2022-06-28 05:36:54 --> Helper loaded: url_helper
INFO - 2022-06-28 05:36:54 --> Helper loaded: file_helper
INFO - 2022-06-28 05:36:54 --> Database Driver Class Initialized
INFO - 2022-06-28 05:36:54 --> Email Class Initialized
DEBUG - 2022-06-28 05:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 05:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 05:36:54 --> Controller Class Initialized
INFO - 2022-06-28 05:36:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 05:36:54 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 05:36:54 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 05:36:54 --> Final output sent to browser
DEBUG - 2022-06-28 05:36:54 --> Total execution time: 0.0295
INFO - 2022-06-28 06:03:37 --> Config Class Initialized
INFO - 2022-06-28 06:03:37 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:03:37 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:03:37 --> Utf8 Class Initialized
INFO - 2022-06-28 06:03:37 --> URI Class Initialized
INFO - 2022-06-28 06:03:37 --> Router Class Initialized
INFO - 2022-06-28 06:03:37 --> Output Class Initialized
INFO - 2022-06-28 06:03:37 --> Security Class Initialized
DEBUG - 2022-06-28 06:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:03:37 --> Input Class Initialized
INFO - 2022-06-28 06:03:37 --> Language Class Initialized
INFO - 2022-06-28 06:03:37 --> Loader Class Initialized
INFO - 2022-06-28 06:03:37 --> Helper loaded: url_helper
INFO - 2022-06-28 06:03:37 --> Helper loaded: file_helper
INFO - 2022-06-28 06:03:37 --> Database Driver Class Initialized
INFO - 2022-06-28 06:03:37 --> Email Class Initialized
DEBUG - 2022-06-28 06:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:03:37 --> Controller Class Initialized
INFO - 2022-06-28 06:03:37 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:03:37 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:03:37 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 06:03:37 --> Final output sent to browser
DEBUG - 2022-06-28 06:03:37 --> Total execution time: 0.0321
INFO - 2022-06-28 06:05:07 --> Config Class Initialized
INFO - 2022-06-28 06:05:07 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:05:07 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:05:07 --> Utf8 Class Initialized
INFO - 2022-06-28 06:05:07 --> URI Class Initialized
INFO - 2022-06-28 06:05:07 --> Router Class Initialized
INFO - 2022-06-28 06:05:07 --> Output Class Initialized
INFO - 2022-06-28 06:05:07 --> Security Class Initialized
DEBUG - 2022-06-28 06:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:05:07 --> Input Class Initialized
INFO - 2022-06-28 06:05:07 --> Language Class Initialized
INFO - 2022-06-28 06:05:07 --> Loader Class Initialized
INFO - 2022-06-28 06:05:07 --> Helper loaded: url_helper
INFO - 2022-06-28 06:05:07 --> Helper loaded: file_helper
INFO - 2022-06-28 06:05:07 --> Database Driver Class Initialized
INFO - 2022-06-28 06:05:07 --> Email Class Initialized
DEBUG - 2022-06-28 06:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:05:07 --> Controller Class Initialized
INFO - 2022-06-28 06:05:07 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:05:07 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:05:07 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 06:05:07 --> Final output sent to browser
DEBUG - 2022-06-28 06:05:07 --> Total execution time: 0.0379
INFO - 2022-06-28 06:22:53 --> Config Class Initialized
INFO - 2022-06-28 06:22:53 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:22:53 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:22:53 --> Utf8 Class Initialized
INFO - 2022-06-28 06:22:53 --> URI Class Initialized
INFO - 2022-06-28 06:22:53 --> Router Class Initialized
INFO - 2022-06-28 06:22:53 --> Output Class Initialized
INFO - 2022-06-28 06:22:53 --> Security Class Initialized
DEBUG - 2022-06-28 06:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:22:53 --> Input Class Initialized
INFO - 2022-06-28 06:22:53 --> Language Class Initialized
INFO - 2022-06-28 06:22:53 --> Loader Class Initialized
INFO - 2022-06-28 06:22:53 --> Helper loaded: url_helper
INFO - 2022-06-28 06:22:53 --> Helper loaded: file_helper
INFO - 2022-06-28 06:22:53 --> Database Driver Class Initialized
INFO - 2022-06-28 06:22:53 --> Email Class Initialized
DEBUG - 2022-06-28 06:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:22:53 --> Controller Class Initialized
INFO - 2022-06-28 06:22:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:22:53 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:22:53 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 06:22:53 --> Final output sent to browser
DEBUG - 2022-06-28 06:22:53 --> Total execution time: 0.0362
INFO - 2022-06-28 06:23:14 --> Config Class Initialized
INFO - 2022-06-28 06:23:14 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:23:14 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:23:14 --> Utf8 Class Initialized
INFO - 2022-06-28 06:23:14 --> URI Class Initialized
INFO - 2022-06-28 06:23:14 --> Router Class Initialized
INFO - 2022-06-28 06:23:14 --> Output Class Initialized
INFO - 2022-06-28 06:23:14 --> Security Class Initialized
DEBUG - 2022-06-28 06:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:23:14 --> Input Class Initialized
INFO - 2022-06-28 06:23:14 --> Language Class Initialized
INFO - 2022-06-28 06:23:14 --> Loader Class Initialized
INFO - 2022-06-28 06:23:14 --> Helper loaded: url_helper
INFO - 2022-06-28 06:23:14 --> Helper loaded: file_helper
INFO - 2022-06-28 06:23:14 --> Database Driver Class Initialized
INFO - 2022-06-28 06:23:14 --> Email Class Initialized
DEBUG - 2022-06-28 06:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:23:14 --> Controller Class Initialized
INFO - 2022-06-28 06:23:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:23:14 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:23:14 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 06:23:14 --> Final output sent to browser
DEBUG - 2022-06-28 06:23:14 --> Total execution time: 0.1413
INFO - 2022-06-28 06:32:15 --> Config Class Initialized
INFO - 2022-06-28 06:32:15 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:32:15 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:32:15 --> Utf8 Class Initialized
INFO - 2022-06-28 06:32:15 --> URI Class Initialized
INFO - 2022-06-28 06:32:15 --> Router Class Initialized
INFO - 2022-06-28 06:32:15 --> Output Class Initialized
INFO - 2022-06-28 06:32:15 --> Security Class Initialized
DEBUG - 2022-06-28 06:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:32:15 --> Input Class Initialized
INFO - 2022-06-28 06:32:15 --> Language Class Initialized
INFO - 2022-06-28 06:32:15 --> Loader Class Initialized
INFO - 2022-06-28 06:32:15 --> Helper loaded: url_helper
INFO - 2022-06-28 06:32:15 --> Helper loaded: file_helper
INFO - 2022-06-28 06:32:15 --> Database Driver Class Initialized
INFO - 2022-06-28 06:32:15 --> Email Class Initialized
DEBUG - 2022-06-28 06:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:32:15 --> Controller Class Initialized
INFO - 2022-06-28 06:32:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:32:15 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:32:15 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 06:32:15 --> Final output sent to browser
DEBUG - 2022-06-28 06:32:15 --> Total execution time: 0.1870
INFO - 2022-06-28 06:33:21 --> Config Class Initialized
INFO - 2022-06-28 06:33:21 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:33:21 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:33:21 --> Utf8 Class Initialized
INFO - 2022-06-28 06:33:21 --> URI Class Initialized
INFO - 2022-06-28 06:33:21 --> Router Class Initialized
INFO - 2022-06-28 06:33:21 --> Output Class Initialized
INFO - 2022-06-28 06:33:21 --> Security Class Initialized
DEBUG - 2022-06-28 06:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:33:21 --> Input Class Initialized
INFO - 2022-06-28 06:33:21 --> Language Class Initialized
INFO - 2022-06-28 06:33:21 --> Loader Class Initialized
INFO - 2022-06-28 06:33:21 --> Helper loaded: url_helper
INFO - 2022-06-28 06:33:21 --> Helper loaded: file_helper
INFO - 2022-06-28 06:33:21 --> Database Driver Class Initialized
INFO - 2022-06-28 06:33:22 --> Email Class Initialized
DEBUG - 2022-06-28 06:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:33:22 --> Controller Class Initialized
INFO - 2022-06-28 06:33:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:33:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:33:22 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 06:33:22 --> Final output sent to browser
DEBUG - 2022-06-28 06:33:22 --> Total execution time: 0.1090
INFO - 2022-06-28 06:33:30 --> Config Class Initialized
INFO - 2022-06-28 06:33:30 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:33:30 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:33:30 --> Utf8 Class Initialized
INFO - 2022-06-28 06:33:30 --> URI Class Initialized
INFO - 2022-06-28 06:33:30 --> Router Class Initialized
INFO - 2022-06-28 06:33:30 --> Output Class Initialized
INFO - 2022-06-28 06:33:30 --> Security Class Initialized
DEBUG - 2022-06-28 06:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:33:30 --> Input Class Initialized
INFO - 2022-06-28 06:33:30 --> Language Class Initialized
INFO - 2022-06-28 06:33:30 --> Loader Class Initialized
INFO - 2022-06-28 06:33:30 --> Helper loaded: url_helper
INFO - 2022-06-28 06:33:30 --> Helper loaded: file_helper
INFO - 2022-06-28 06:33:30 --> Database Driver Class Initialized
INFO - 2022-06-28 06:33:31 --> Email Class Initialized
DEBUG - 2022-06-28 06:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:33:31 --> Controller Class Initialized
INFO - 2022-06-28 06:33:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:33:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:33:31 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 06:33:31 --> Final output sent to browser
DEBUG - 2022-06-28 06:33:31 --> Total execution time: 0.3335
INFO - 2022-06-28 06:34:41 --> Config Class Initialized
INFO - 2022-06-28 06:34:41 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:34:41 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:34:41 --> Utf8 Class Initialized
INFO - 2022-06-28 06:34:41 --> URI Class Initialized
INFO - 2022-06-28 06:34:41 --> Router Class Initialized
INFO - 2022-06-28 06:34:41 --> Output Class Initialized
INFO - 2022-06-28 06:34:41 --> Security Class Initialized
DEBUG - 2022-06-28 06:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:34:41 --> Input Class Initialized
INFO - 2022-06-28 06:34:41 --> Language Class Initialized
INFO - 2022-06-28 06:34:41 --> Loader Class Initialized
INFO - 2022-06-28 06:34:41 --> Helper loaded: url_helper
INFO - 2022-06-28 06:34:41 --> Helper loaded: file_helper
INFO - 2022-06-28 06:34:41 --> Database Driver Class Initialized
INFO - 2022-06-28 06:34:41 --> Email Class Initialized
DEBUG - 2022-06-28 06:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:34:41 --> Controller Class Initialized
INFO - 2022-06-28 06:34:41 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:34:41 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:34:41 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 06:34:41 --> Final output sent to browser
DEBUG - 2022-06-28 06:34:41 --> Total execution time: 0.0403
INFO - 2022-06-28 06:34:44 --> Config Class Initialized
INFO - 2022-06-28 06:34:44 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:34:44 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:34:44 --> Utf8 Class Initialized
INFO - 2022-06-28 06:34:44 --> URI Class Initialized
INFO - 2022-06-28 06:34:44 --> Router Class Initialized
INFO - 2022-06-28 06:34:44 --> Output Class Initialized
INFO - 2022-06-28 06:34:44 --> Security Class Initialized
DEBUG - 2022-06-28 06:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:34:44 --> Input Class Initialized
INFO - 2022-06-28 06:34:44 --> Language Class Initialized
INFO - 2022-06-28 06:34:44 --> Loader Class Initialized
INFO - 2022-06-28 06:34:44 --> Helper loaded: url_helper
INFO - 2022-06-28 06:34:44 --> Helper loaded: file_helper
INFO - 2022-06-28 06:34:44 --> Database Driver Class Initialized
INFO - 2022-06-28 06:34:44 --> Email Class Initialized
DEBUG - 2022-06-28 06:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:34:44 --> Controller Class Initialized
INFO - 2022-06-28 06:34:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:34:44 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:34:44 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 06:34:44 --> Final output sent to browser
DEBUG - 2022-06-28 06:34:44 --> Total execution time: 0.2582
INFO - 2022-06-28 06:57:15 --> Config Class Initialized
INFO - 2022-06-28 06:57:15 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:57:15 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:57:15 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:15 --> URI Class Initialized
INFO - 2022-06-28 06:57:15 --> Router Class Initialized
INFO - 2022-06-28 06:57:15 --> Output Class Initialized
INFO - 2022-06-28 06:57:15 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:15 --> Input Class Initialized
INFO - 2022-06-28 06:57:15 --> Language Class Initialized
INFO - 2022-06-28 06:57:15 --> Loader Class Initialized
INFO - 2022-06-28 06:57:15 --> Helper loaded: url_helper
INFO - 2022-06-28 06:57:15 --> Helper loaded: file_helper
INFO - 2022-06-28 06:57:15 --> Database Driver Class Initialized
INFO - 2022-06-28 06:57:15 --> Email Class Initialized
DEBUG - 2022-06-28 06:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:57:15 --> Controller Class Initialized
INFO - 2022-06-28 06:57:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:57:15 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:57:15 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 06:57:15 --> Final output sent to browser
DEBUG - 2022-06-28 06:57:15 --> Total execution time: 0.2222
INFO - 2022-06-28 06:57:15 --> Config Class Initialized
INFO - 2022-06-28 06:57:15 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:57:15 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:57:15 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:15 --> URI Class Initialized
INFO - 2022-06-28 06:57:15 --> Router Class Initialized
INFO - 2022-06-28 06:57:15 --> Output Class Initialized
INFO - 2022-06-28 06:57:15 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:15 --> Input Class Initialized
INFO - 2022-06-28 06:57:15 --> Language Class Initialized
ERROR - 2022-06-28 06:57:15 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-28 06:57:15 --> Config Class Initialized
INFO - 2022-06-28 06:57:15 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:57:15 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:57:15 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:15 --> URI Class Initialized
INFO - 2022-06-28 06:57:15 --> Router Class Initialized
INFO - 2022-06-28 06:57:15 --> Output Class Initialized
INFO - 2022-06-28 06:57:15 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:15 --> Input Class Initialized
INFO - 2022-06-28 06:57:15 --> Language Class Initialized
ERROR - 2022-06-28 06:57:15 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-28 06:57:20 --> Config Class Initialized
INFO - 2022-06-28 06:57:20 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:57:20 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:57:20 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:20 --> URI Class Initialized
INFO - 2022-06-28 06:57:20 --> Router Class Initialized
INFO - 2022-06-28 06:57:20 --> Output Class Initialized
INFO - 2022-06-28 06:57:20 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:20 --> Input Class Initialized
INFO - 2022-06-28 06:57:20 --> Language Class Initialized
INFO - 2022-06-28 06:57:20 --> Loader Class Initialized
INFO - 2022-06-28 06:57:20 --> Helper loaded: url_helper
INFO - 2022-06-28 06:57:20 --> Helper loaded: file_helper
INFO - 2022-06-28 06:57:20 --> Database Driver Class Initialized
INFO - 2022-06-28 06:57:20 --> Email Class Initialized
DEBUG - 2022-06-28 06:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:57:20 --> Controller Class Initialized
INFO - 2022-06-28 06:57:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:57:20 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:57:20 --> Final output sent to browser
DEBUG - 2022-06-28 06:57:20 --> Total execution time: 0.2161
INFO - 2022-06-28 06:57:21 --> Config Class Initialized
INFO - 2022-06-28 06:57:21 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:57:21 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:57:21 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:21 --> URI Class Initialized
INFO - 2022-06-28 06:57:21 --> Router Class Initialized
INFO - 2022-06-28 06:57:21 --> Output Class Initialized
INFO - 2022-06-28 06:57:21 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:21 --> Input Class Initialized
INFO - 2022-06-28 06:57:21 --> Language Class Initialized
INFO - 2022-06-28 06:57:21 --> Loader Class Initialized
INFO - 2022-06-28 06:57:21 --> Helper loaded: url_helper
INFO - 2022-06-28 06:57:21 --> Helper loaded: file_helper
INFO - 2022-06-28 06:57:21 --> Database Driver Class Initialized
INFO - 2022-06-28 06:57:21 --> Email Class Initialized
DEBUG - 2022-06-28 06:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:57:21 --> Controller Class Initialized
INFO - 2022-06-28 06:57:21 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:57:21 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:57:21 --> Final output sent to browser
DEBUG - 2022-06-28 06:57:21 --> Total execution time: 0.1492
INFO - 2022-06-28 06:57:24 --> Config Class Initialized
INFO - 2022-06-28 06:57:24 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:57:24 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:57:24 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:24 --> URI Class Initialized
INFO - 2022-06-28 06:57:24 --> Router Class Initialized
INFO - 2022-06-28 06:57:24 --> Output Class Initialized
INFO - 2022-06-28 06:57:24 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:24 --> Input Class Initialized
INFO - 2022-06-28 06:57:24 --> Language Class Initialized
INFO - 2022-06-28 06:57:24 --> Loader Class Initialized
INFO - 2022-06-28 06:57:24 --> Helper loaded: url_helper
INFO - 2022-06-28 06:57:24 --> Helper loaded: file_helper
INFO - 2022-06-28 06:57:24 --> Database Driver Class Initialized
INFO - 2022-06-28 06:57:25 --> Email Class Initialized
DEBUG - 2022-06-28 06:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:57:25 --> Controller Class Initialized
INFO - 2022-06-28 06:57:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:57:25 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:57:25 --> Final output sent to browser
DEBUG - 2022-06-28 06:57:25 --> Total execution time: 0.1649
INFO - 2022-06-28 06:57:25 --> Config Class Initialized
INFO - 2022-06-28 06:57:25 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:57:25 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:57:25 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:25 --> URI Class Initialized
INFO - 2022-06-28 06:57:25 --> Router Class Initialized
INFO - 2022-06-28 06:57:25 --> Output Class Initialized
INFO - 2022-06-28 06:57:25 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:25 --> Input Class Initialized
INFO - 2022-06-28 06:57:25 --> Language Class Initialized
INFO - 2022-06-28 06:57:25 --> Loader Class Initialized
INFO - 2022-06-28 06:57:25 --> Helper loaded: url_helper
INFO - 2022-06-28 06:57:25 --> Helper loaded: file_helper
INFO - 2022-06-28 06:57:25 --> Database Driver Class Initialized
INFO - 2022-06-28 06:57:25 --> Email Class Initialized
DEBUG - 2022-06-28 06:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:57:25 --> Controller Class Initialized
INFO - 2022-06-28 06:57:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:57:25 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:57:26 --> Final output sent to browser
DEBUG - 2022-06-28 06:57:26 --> Total execution time: 0.1178
INFO - 2022-06-28 06:57:26 --> Config Class Initialized
INFO - 2022-06-28 06:57:26 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:57:26 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:57:26 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:26 --> URI Class Initialized
INFO - 2022-06-28 06:57:26 --> Router Class Initialized
INFO - 2022-06-28 06:57:26 --> Output Class Initialized
INFO - 2022-06-28 06:57:26 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:26 --> Input Class Initialized
INFO - 2022-06-28 06:57:26 --> Language Class Initialized
INFO - 2022-06-28 06:57:26 --> Loader Class Initialized
INFO - 2022-06-28 06:57:26 --> Helper loaded: url_helper
INFO - 2022-06-28 06:57:26 --> Helper loaded: file_helper
INFO - 2022-06-28 06:57:26 --> Database Driver Class Initialized
INFO - 2022-06-28 06:57:26 --> Email Class Initialized
DEBUG - 2022-06-28 06:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:57:26 --> Controller Class Initialized
INFO - 2022-06-28 06:57:26 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:57:26 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:57:26 --> Final output sent to browser
DEBUG - 2022-06-28 06:57:26 --> Total execution time: 0.1092
INFO - 2022-06-28 06:57:26 --> Config Class Initialized
INFO - 2022-06-28 06:57:26 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:57:26 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:57:26 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:26 --> URI Class Initialized
INFO - 2022-06-28 06:57:26 --> Router Class Initialized
INFO - 2022-06-28 06:57:26 --> Output Class Initialized
INFO - 2022-06-28 06:57:26 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:26 --> Input Class Initialized
INFO - 2022-06-28 06:57:26 --> Language Class Initialized
INFO - 2022-06-28 06:57:26 --> Loader Class Initialized
INFO - 2022-06-28 06:57:26 --> Helper loaded: url_helper
INFO - 2022-06-28 06:57:26 --> Helper loaded: file_helper
INFO - 2022-06-28 06:57:26 --> Database Driver Class Initialized
INFO - 2022-06-28 06:57:26 --> Email Class Initialized
DEBUG - 2022-06-28 06:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:57:26 --> Controller Class Initialized
INFO - 2022-06-28 06:57:26 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:57:26 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:57:26 --> Final output sent to browser
DEBUG - 2022-06-28 06:57:26 --> Total execution time: 0.0351
INFO - 2022-06-28 06:57:26 --> Config Class Initialized
INFO - 2022-06-28 06:57:26 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:57:26 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:57:26 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:26 --> URI Class Initialized
INFO - 2022-06-28 06:57:26 --> Router Class Initialized
INFO - 2022-06-28 06:57:26 --> Output Class Initialized
INFO - 2022-06-28 06:57:26 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:26 --> Input Class Initialized
INFO - 2022-06-28 06:57:26 --> Language Class Initialized
INFO - 2022-06-28 06:57:26 --> Loader Class Initialized
INFO - 2022-06-28 06:57:26 --> Helper loaded: url_helper
INFO - 2022-06-28 06:57:26 --> Helper loaded: file_helper
INFO - 2022-06-28 06:57:26 --> Database Driver Class Initialized
INFO - 2022-06-28 06:57:26 --> Email Class Initialized
DEBUG - 2022-06-28 06:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:57:26 --> Controller Class Initialized
INFO - 2022-06-28 06:57:26 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:57:26 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:57:26 --> Final output sent to browser
DEBUG - 2022-06-28 06:57:26 --> Total execution time: 0.0783
INFO - 2022-06-28 06:57:27 --> Config Class Initialized
INFO - 2022-06-28 06:57:27 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:57:27 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:57:27 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:27 --> URI Class Initialized
INFO - 2022-06-28 06:57:27 --> Router Class Initialized
INFO - 2022-06-28 06:57:27 --> Output Class Initialized
INFO - 2022-06-28 06:57:27 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:27 --> Input Class Initialized
INFO - 2022-06-28 06:57:27 --> Language Class Initialized
INFO - 2022-06-28 06:57:27 --> Loader Class Initialized
INFO - 2022-06-28 06:57:27 --> Helper loaded: url_helper
INFO - 2022-06-28 06:57:27 --> Helper loaded: file_helper
INFO - 2022-06-28 06:57:27 --> Database Driver Class Initialized
INFO - 2022-06-28 06:57:27 --> Email Class Initialized
DEBUG - 2022-06-28 06:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:57:27 --> Controller Class Initialized
INFO - 2022-06-28 06:57:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:57:27 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:57:27 --> Final output sent to browser
DEBUG - 2022-06-28 06:57:27 --> Total execution time: 0.0182
INFO - 2022-06-28 06:57:27 --> Config Class Initialized
INFO - 2022-06-28 06:57:27 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:57:27 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:57:27 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:27 --> URI Class Initialized
INFO - 2022-06-28 06:57:27 --> Router Class Initialized
INFO - 2022-06-28 06:57:27 --> Output Class Initialized
INFO - 2022-06-28 06:57:27 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:27 --> Input Class Initialized
INFO - 2022-06-28 06:57:27 --> Language Class Initialized
INFO - 2022-06-28 06:57:27 --> Loader Class Initialized
INFO - 2022-06-28 06:57:27 --> Helper loaded: url_helper
INFO - 2022-06-28 06:57:27 --> Helper loaded: file_helper
INFO - 2022-06-28 06:57:27 --> Database Driver Class Initialized
INFO - 2022-06-28 06:57:27 --> Email Class Initialized
DEBUG - 2022-06-28 06:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:57:27 --> Controller Class Initialized
INFO - 2022-06-28 06:57:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:57:27 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:57:27 --> Final output sent to browser
DEBUG - 2022-06-28 06:57:27 --> Total execution time: 0.0158
INFO - 2022-06-28 06:57:27 --> Config Class Initialized
INFO - 2022-06-28 06:57:27 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:57:27 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:57:27 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:27 --> URI Class Initialized
INFO - 2022-06-28 06:57:27 --> Router Class Initialized
INFO - 2022-06-28 06:57:27 --> Output Class Initialized
INFO - 2022-06-28 06:57:27 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:27 --> Input Class Initialized
INFO - 2022-06-28 06:57:27 --> Language Class Initialized
INFO - 2022-06-28 06:57:27 --> Loader Class Initialized
INFO - 2022-06-28 06:57:27 --> Helper loaded: url_helper
INFO - 2022-06-28 06:57:27 --> Helper loaded: file_helper
INFO - 2022-06-28 06:57:27 --> Database Driver Class Initialized
INFO - 2022-06-28 06:57:27 --> Email Class Initialized
DEBUG - 2022-06-28 06:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:57:27 --> Controller Class Initialized
INFO - 2022-06-28 06:57:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:57:27 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:57:27 --> Final output sent to browser
DEBUG - 2022-06-28 06:57:27 --> Total execution time: 0.1208
INFO - 2022-06-28 06:57:27 --> Config Class Initialized
INFO - 2022-06-28 06:57:27 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:57:27 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:57:27 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:27 --> URI Class Initialized
INFO - 2022-06-28 06:57:27 --> Router Class Initialized
INFO - 2022-06-28 06:57:27 --> Output Class Initialized
INFO - 2022-06-28 06:57:27 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:27 --> Input Class Initialized
INFO - 2022-06-28 06:57:27 --> Language Class Initialized
INFO - 2022-06-28 06:57:27 --> Loader Class Initialized
INFO - 2022-06-28 06:57:27 --> Helper loaded: url_helper
INFO - 2022-06-28 06:57:27 --> Helper loaded: file_helper
INFO - 2022-06-28 06:57:27 --> Database Driver Class Initialized
INFO - 2022-06-28 06:57:27 --> Email Class Initialized
DEBUG - 2022-06-28 06:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:57:27 --> Controller Class Initialized
INFO - 2022-06-28 06:57:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:57:27 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:57:27 --> Final output sent to browser
DEBUG - 2022-06-28 06:57:27 --> Total execution time: 0.0433
INFO - 2022-06-28 06:57:27 --> Config Class Initialized
INFO - 2022-06-28 06:57:27 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:57:27 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:57:27 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:27 --> URI Class Initialized
INFO - 2022-06-28 06:57:27 --> Router Class Initialized
INFO - 2022-06-28 06:57:27 --> Output Class Initialized
INFO - 2022-06-28 06:57:27 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:27 --> Input Class Initialized
INFO - 2022-06-28 06:57:27 --> Language Class Initialized
INFO - 2022-06-28 06:57:27 --> Loader Class Initialized
INFO - 2022-06-28 06:57:27 --> Helper loaded: url_helper
INFO - 2022-06-28 06:57:27 --> Helper loaded: file_helper
INFO - 2022-06-28 06:57:27 --> Database Driver Class Initialized
INFO - 2022-06-28 06:57:27 --> Email Class Initialized
DEBUG - 2022-06-28 06:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:57:27 --> Controller Class Initialized
INFO - 2022-06-28 06:57:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:57:27 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:57:27 --> Final output sent to browser
DEBUG - 2022-06-28 06:57:27 --> Total execution time: 0.0379
INFO - 2022-06-28 06:57:27 --> Config Class Initialized
INFO - 2022-06-28 06:57:27 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:57:27 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:57:27 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:27 --> URI Class Initialized
INFO - 2022-06-28 06:57:27 --> Router Class Initialized
INFO - 2022-06-28 06:57:27 --> Output Class Initialized
INFO - 2022-06-28 06:57:27 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:27 --> Input Class Initialized
INFO - 2022-06-28 06:57:27 --> Language Class Initialized
INFO - 2022-06-28 06:57:27 --> Loader Class Initialized
INFO - 2022-06-28 06:57:27 --> Helper loaded: url_helper
INFO - 2022-06-28 06:57:27 --> Helper loaded: file_helper
INFO - 2022-06-28 06:57:27 --> Database Driver Class Initialized
INFO - 2022-06-28 06:57:27 --> Email Class Initialized
DEBUG - 2022-06-28 06:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:57:27 --> Controller Class Initialized
INFO - 2022-06-28 06:57:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:57:27 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:57:27 --> Final output sent to browser
DEBUG - 2022-06-28 06:57:27 --> Total execution time: 0.1095
INFO - 2022-06-28 06:57:28 --> Config Class Initialized
INFO - 2022-06-28 06:57:28 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:57:28 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:57:28 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:28 --> URI Class Initialized
INFO - 2022-06-28 06:57:28 --> Router Class Initialized
INFO - 2022-06-28 06:57:28 --> Output Class Initialized
INFO - 2022-06-28 06:57:28 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:28 --> Input Class Initialized
INFO - 2022-06-28 06:57:28 --> Language Class Initialized
INFO - 2022-06-28 06:57:28 --> Config Class Initialized
INFO - 2022-06-28 06:57:28 --> Loader Class Initialized
INFO - 2022-06-28 06:57:28 --> Hooks Class Initialized
INFO - 2022-06-28 06:57:28 --> Helper loaded: url_helper
DEBUG - 2022-06-28 06:57:28 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:57:28 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:28 --> Helper loaded: file_helper
INFO - 2022-06-28 06:57:28 --> URI Class Initialized
INFO - 2022-06-28 06:57:28 --> Database Driver Class Initialized
INFO - 2022-06-28 06:57:28 --> Router Class Initialized
INFO - 2022-06-28 06:57:28 --> Output Class Initialized
INFO - 2022-06-28 06:57:28 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:28 --> Input Class Initialized
INFO - 2022-06-28 06:57:28 --> Language Class Initialized
INFO - 2022-06-28 06:57:28 --> Loader Class Initialized
INFO - 2022-06-28 06:57:28 --> Helper loaded: url_helper
INFO - 2022-06-28 06:57:28 --> Helper loaded: file_helper
INFO - 2022-06-28 06:57:28 --> Database Driver Class Initialized
INFO - 2022-06-28 06:57:28 --> Email Class Initialized
DEBUG - 2022-06-28 06:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:57:28 --> Controller Class Initialized
INFO - 2022-06-28 06:57:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:57:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:57:28 --> Email Class Initialized
DEBUG - 2022-06-28 06:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:57:28 --> Final output sent to browser
DEBUG - 2022-06-28 06:57:28 --> Total execution time: 0.1407
INFO - 2022-06-28 06:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:57:28 --> Config Class Initialized
INFO - 2022-06-28 06:57:28 --> Controller Class Initialized
INFO - 2022-06-28 06:57:28 --> Hooks Class Initialized
INFO - 2022-06-28 06:57:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:57:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-28 06:57:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:57:28 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:28 --> URI Class Initialized
INFO - 2022-06-28 06:57:28 --> Final output sent to browser
DEBUG - 2022-06-28 06:57:28 --> Total execution time: 0.1251
INFO - 2022-06-28 06:57:28 --> Router Class Initialized
INFO - 2022-06-28 06:57:28 --> Output Class Initialized
INFO - 2022-06-28 06:57:28 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:28 --> Input Class Initialized
INFO - 2022-06-28 06:57:28 --> Language Class Initialized
INFO - 2022-06-28 06:57:28 --> Loader Class Initialized
INFO - 2022-06-28 06:57:28 --> Helper loaded: url_helper
INFO - 2022-06-28 06:57:28 --> Helper loaded: file_helper
INFO - 2022-06-28 06:57:28 --> Database Driver Class Initialized
INFO - 2022-06-28 06:57:28 --> Email Class Initialized
DEBUG - 2022-06-28 06:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:57:28 --> Controller Class Initialized
INFO - 2022-06-28 06:57:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:57:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:57:28 --> Config Class Initialized
INFO - 2022-06-28 06:57:28 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:57:28 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:57:28 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:28 --> URI Class Initialized
INFO - 2022-06-28 06:57:28 --> Router Class Initialized
INFO - 2022-06-28 06:57:28 --> Final output sent to browser
DEBUG - 2022-06-28 06:57:28 --> Total execution time: 0.1004
INFO - 2022-06-28 06:57:28 --> Output Class Initialized
INFO - 2022-06-28 06:57:28 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:28 --> Input Class Initialized
INFO - 2022-06-28 06:57:28 --> Language Class Initialized
INFO - 2022-06-28 06:57:28 --> Loader Class Initialized
INFO - 2022-06-28 06:57:28 --> Helper loaded: url_helper
INFO - 2022-06-28 06:57:28 --> Helper loaded: file_helper
INFO - 2022-06-28 06:57:28 --> Database Driver Class Initialized
INFO - 2022-06-28 06:57:28 --> Email Class Initialized
DEBUG - 2022-06-28 06:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:57:28 --> Controller Class Initialized
INFO - 2022-06-28 06:57:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:57:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:57:28 --> Final output sent to browser
DEBUG - 2022-06-28 06:57:28 --> Total execution time: 0.0181
INFO - 2022-06-28 06:57:28 --> Config Class Initialized
INFO - 2022-06-28 06:57:28 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:57:28 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:57:28 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:28 --> URI Class Initialized
INFO - 2022-06-28 06:57:28 --> Router Class Initialized
INFO - 2022-06-28 06:57:28 --> Output Class Initialized
INFO - 2022-06-28 06:57:28 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:28 --> Input Class Initialized
INFO - 2022-06-28 06:57:28 --> Language Class Initialized
INFO - 2022-06-28 06:57:28 --> Loader Class Initialized
INFO - 2022-06-28 06:57:28 --> Helper loaded: url_helper
INFO - 2022-06-28 06:57:28 --> Helper loaded: file_helper
INFO - 2022-06-28 06:57:28 --> Database Driver Class Initialized
INFO - 2022-06-28 06:57:28 --> Email Class Initialized
DEBUG - 2022-06-28 06:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:57:28 --> Controller Class Initialized
INFO - 2022-06-28 06:57:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:57:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:57:28 --> Final output sent to browser
DEBUG - 2022-06-28 06:57:28 --> Total execution time: 0.0583
INFO - 2022-06-28 06:57:28 --> Config Class Initialized
INFO - 2022-06-28 06:57:28 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:57:28 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:57:28 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:28 --> URI Class Initialized
INFO - 2022-06-28 06:57:28 --> Router Class Initialized
INFO - 2022-06-28 06:57:28 --> Output Class Initialized
INFO - 2022-06-28 06:57:28 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:28 --> Input Class Initialized
INFO - 2022-06-28 06:57:28 --> Language Class Initialized
INFO - 2022-06-28 06:57:28 --> Loader Class Initialized
INFO - 2022-06-28 06:57:28 --> Helper loaded: url_helper
INFO - 2022-06-28 06:57:28 --> Helper loaded: file_helper
INFO - 2022-06-28 06:57:28 --> Database Driver Class Initialized
INFO - 2022-06-28 06:57:28 --> Email Class Initialized
DEBUG - 2022-06-28 06:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:57:28 --> Controller Class Initialized
INFO - 2022-06-28 06:57:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:57:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:57:28 --> Final output sent to browser
DEBUG - 2022-06-28 06:57:28 --> Total execution time: 0.0161
INFO - 2022-06-28 06:57:28 --> Config Class Initialized
INFO - 2022-06-28 06:57:28 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:57:28 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:57:28 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:28 --> URI Class Initialized
INFO - 2022-06-28 06:57:28 --> Router Class Initialized
INFO - 2022-06-28 06:57:28 --> Output Class Initialized
INFO - 2022-06-28 06:57:28 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:28 --> Input Class Initialized
INFO - 2022-06-28 06:57:28 --> Language Class Initialized
INFO - 2022-06-28 06:57:28 --> Loader Class Initialized
INFO - 2022-06-28 06:57:28 --> Helper loaded: url_helper
INFO - 2022-06-28 06:57:28 --> Helper loaded: file_helper
INFO - 2022-06-28 06:57:28 --> Database Driver Class Initialized
INFO - 2022-06-28 06:57:28 --> Email Class Initialized
DEBUG - 2022-06-28 06:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:57:28 --> Controller Class Initialized
INFO - 2022-06-28 06:57:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:57:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:57:28 --> Final output sent to browser
DEBUG - 2022-06-28 06:57:28 --> Total execution time: 0.0247
INFO - 2022-06-28 06:57:28 --> Config Class Initialized
INFO - 2022-06-28 06:57:28 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:57:28 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:57:28 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:28 --> URI Class Initialized
INFO - 2022-06-28 06:57:28 --> Router Class Initialized
INFO - 2022-06-28 06:57:28 --> Output Class Initialized
INFO - 2022-06-28 06:57:28 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:28 --> Input Class Initialized
INFO - 2022-06-28 06:57:28 --> Language Class Initialized
INFO - 2022-06-28 06:57:28 --> Loader Class Initialized
INFO - 2022-06-28 06:57:28 --> Helper loaded: url_helper
INFO - 2022-06-28 06:57:28 --> Helper loaded: file_helper
INFO - 2022-06-28 06:57:28 --> Database Driver Class Initialized
INFO - 2022-06-28 06:57:28 --> Email Class Initialized
DEBUG - 2022-06-28 06:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:57:28 --> Controller Class Initialized
INFO - 2022-06-28 06:57:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:57:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:57:28 --> Final output sent to browser
DEBUG - 2022-06-28 06:57:28 --> Total execution time: 0.0160
INFO - 2022-06-28 06:57:28 --> Config Class Initialized
INFO - 2022-06-28 06:57:28 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:57:28 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:57:28 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:28 --> URI Class Initialized
INFO - 2022-06-28 06:57:28 --> Router Class Initialized
INFO - 2022-06-28 06:57:28 --> Output Class Initialized
INFO - 2022-06-28 06:57:28 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:28 --> Input Class Initialized
INFO - 2022-06-28 06:57:28 --> Language Class Initialized
INFO - 2022-06-28 06:57:28 --> Loader Class Initialized
INFO - 2022-06-28 06:57:28 --> Helper loaded: url_helper
INFO - 2022-06-28 06:57:28 --> Helper loaded: file_helper
INFO - 2022-06-28 06:57:28 --> Database Driver Class Initialized
INFO - 2022-06-28 06:57:28 --> Email Class Initialized
DEBUG - 2022-06-28 06:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:57:28 --> Controller Class Initialized
INFO - 2022-06-28 06:57:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:57:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:57:28 --> Final output sent to browser
DEBUG - 2022-06-28 06:57:28 --> Total execution time: 0.0164
INFO - 2022-06-28 06:57:28 --> Config Class Initialized
INFO - 2022-06-28 06:57:28 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:57:28 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:57:28 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:28 --> URI Class Initialized
INFO - 2022-06-28 06:57:28 --> Router Class Initialized
INFO - 2022-06-28 06:57:28 --> Output Class Initialized
INFO - 2022-06-28 06:57:28 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:28 --> Input Class Initialized
INFO - 2022-06-28 06:57:28 --> Language Class Initialized
INFO - 2022-06-28 06:57:28 --> Loader Class Initialized
INFO - 2022-06-28 06:57:28 --> Helper loaded: url_helper
INFO - 2022-06-28 06:57:28 --> Helper loaded: file_helper
INFO - 2022-06-28 06:57:28 --> Database Driver Class Initialized
INFO - 2022-06-28 06:57:28 --> Email Class Initialized
DEBUG - 2022-06-28 06:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:57:28 --> Controller Class Initialized
INFO - 2022-06-28 06:57:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:57:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:57:28 --> Final output sent to browser
DEBUG - 2022-06-28 06:57:28 --> Total execution time: 0.0160
INFO - 2022-06-28 06:57:29 --> Config Class Initialized
INFO - 2022-06-28 06:57:29 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:57:29 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:57:29 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:29 --> URI Class Initialized
INFO - 2022-06-28 06:57:29 --> Router Class Initialized
INFO - 2022-06-28 06:57:29 --> Output Class Initialized
INFO - 2022-06-28 06:57:29 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:29 --> Input Class Initialized
INFO - 2022-06-28 06:57:29 --> Language Class Initialized
INFO - 2022-06-28 06:57:29 --> Loader Class Initialized
INFO - 2022-06-28 06:57:29 --> Helper loaded: url_helper
INFO - 2022-06-28 06:57:29 --> Helper loaded: file_helper
INFO - 2022-06-28 06:57:29 --> Database Driver Class Initialized
INFO - 2022-06-28 06:57:29 --> Email Class Initialized
DEBUG - 2022-06-28 06:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:57:29 --> Controller Class Initialized
INFO - 2022-06-28 06:57:29 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:57:29 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:57:29 --> Final output sent to browser
DEBUG - 2022-06-28 06:57:29 --> Total execution time: 0.0160
INFO - 2022-06-28 06:57:29 --> Config Class Initialized
INFO - 2022-06-28 06:57:29 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:57:29 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:57:29 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:29 --> URI Class Initialized
INFO - 2022-06-28 06:57:29 --> Router Class Initialized
INFO - 2022-06-28 06:57:29 --> Output Class Initialized
INFO - 2022-06-28 06:57:29 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:29 --> Input Class Initialized
INFO - 2022-06-28 06:57:29 --> Language Class Initialized
INFO - 2022-06-28 06:57:29 --> Loader Class Initialized
INFO - 2022-06-28 06:57:29 --> Helper loaded: url_helper
INFO - 2022-06-28 06:57:29 --> Helper loaded: file_helper
INFO - 2022-06-28 06:57:29 --> Database Driver Class Initialized
INFO - 2022-06-28 06:57:29 --> Email Class Initialized
DEBUG - 2022-06-28 06:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:57:29 --> Controller Class Initialized
INFO - 2022-06-28 06:57:29 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:57:29 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:57:29 --> Final output sent to browser
DEBUG - 2022-06-28 06:57:29 --> Total execution time: 0.0159
INFO - 2022-06-28 06:57:29 --> Config Class Initialized
INFO - 2022-06-28 06:57:29 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:57:29 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:57:29 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:29 --> URI Class Initialized
INFO - 2022-06-28 06:57:29 --> Router Class Initialized
INFO - 2022-06-28 06:57:29 --> Output Class Initialized
INFO - 2022-06-28 06:57:29 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:29 --> Input Class Initialized
INFO - 2022-06-28 06:57:29 --> Language Class Initialized
INFO - 2022-06-28 06:57:29 --> Loader Class Initialized
INFO - 2022-06-28 06:57:29 --> Helper loaded: url_helper
INFO - 2022-06-28 06:57:29 --> Helper loaded: file_helper
INFO - 2022-06-28 06:57:29 --> Database Driver Class Initialized
INFO - 2022-06-28 06:57:29 --> Email Class Initialized
DEBUG - 2022-06-28 06:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:57:29 --> Controller Class Initialized
INFO - 2022-06-28 06:57:29 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:57:29 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:57:29 --> Config Class Initialized
INFO - 2022-06-28 06:57:29 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:57:29 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:57:29 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:29 --> URI Class Initialized
INFO - 2022-06-28 06:57:29 --> Router Class Initialized
INFO - 2022-06-28 06:57:29 --> Output Class Initialized
INFO - 2022-06-28 06:57:29 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:29 --> Input Class Initialized
INFO - 2022-06-28 06:57:29 --> Language Class Initialized
INFO - 2022-06-28 06:57:29 --> Loader Class Initialized
INFO - 2022-06-28 06:57:29 --> Helper loaded: url_helper
INFO - 2022-06-28 06:57:29 --> Helper loaded: file_helper
INFO - 2022-06-28 06:57:29 --> Database Driver Class Initialized
INFO - 2022-06-28 06:57:29 --> Final output sent to browser
DEBUG - 2022-06-28 06:57:29 --> Total execution time: 0.1858
INFO - 2022-06-28 06:57:29 --> Email Class Initialized
DEBUG - 2022-06-28 06:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:57:29 --> Controller Class Initialized
INFO - 2022-06-28 06:57:29 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:57:29 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:57:29 --> Final output sent to browser
DEBUG - 2022-06-28 06:57:29 --> Total execution time: 0.0365
INFO - 2022-06-28 06:57:29 --> Config Class Initialized
INFO - 2022-06-28 06:57:29 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:57:29 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:57:29 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:29 --> URI Class Initialized
INFO - 2022-06-28 06:57:29 --> Router Class Initialized
INFO - 2022-06-28 06:57:29 --> Output Class Initialized
INFO - 2022-06-28 06:57:29 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:29 --> Input Class Initialized
INFO - 2022-06-28 06:57:29 --> Language Class Initialized
INFO - 2022-06-28 06:57:29 --> Loader Class Initialized
INFO - 2022-06-28 06:57:29 --> Helper loaded: url_helper
INFO - 2022-06-28 06:57:29 --> Helper loaded: file_helper
INFO - 2022-06-28 06:57:29 --> Database Driver Class Initialized
INFO - 2022-06-28 06:57:29 --> Email Class Initialized
DEBUG - 2022-06-28 06:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:57:29 --> Controller Class Initialized
INFO - 2022-06-28 06:57:29 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:57:29 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:57:29 --> Final output sent to browser
DEBUG - 2022-06-28 06:57:29 --> Total execution time: 0.0319
INFO - 2022-06-28 06:57:29 --> Config Class Initialized
INFO - 2022-06-28 06:57:29 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:57:29 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:57:29 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:29 --> URI Class Initialized
INFO - 2022-06-28 06:57:29 --> Router Class Initialized
INFO - 2022-06-28 06:57:29 --> Output Class Initialized
INFO - 2022-06-28 06:57:29 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:29 --> Input Class Initialized
INFO - 2022-06-28 06:57:29 --> Language Class Initialized
INFO - 2022-06-28 06:57:29 --> Loader Class Initialized
INFO - 2022-06-28 06:57:29 --> Helper loaded: url_helper
INFO - 2022-06-28 06:57:29 --> Helper loaded: file_helper
INFO - 2022-06-28 06:57:29 --> Database Driver Class Initialized
INFO - 2022-06-28 06:57:29 --> Email Class Initialized
DEBUG - 2022-06-28 06:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:57:29 --> Controller Class Initialized
INFO - 2022-06-28 06:57:29 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:57:29 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:57:29 --> Final output sent to browser
DEBUG - 2022-06-28 06:57:29 --> Total execution time: 0.0164
INFO - 2022-06-28 06:57:29 --> Config Class Initialized
INFO - 2022-06-28 06:57:29 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:57:29 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:57:29 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:29 --> URI Class Initialized
INFO - 2022-06-28 06:57:29 --> Router Class Initialized
INFO - 2022-06-28 06:57:29 --> Output Class Initialized
INFO - 2022-06-28 06:57:29 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:29 --> Input Class Initialized
INFO - 2022-06-28 06:57:29 --> Language Class Initialized
INFO - 2022-06-28 06:57:29 --> Loader Class Initialized
INFO - 2022-06-28 06:57:29 --> Helper loaded: url_helper
INFO - 2022-06-28 06:57:29 --> Helper loaded: file_helper
INFO - 2022-06-28 06:57:29 --> Database Driver Class Initialized
INFO - 2022-06-28 06:57:29 --> Email Class Initialized
DEBUG - 2022-06-28 06:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:57:29 --> Controller Class Initialized
INFO - 2022-06-28 06:57:29 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:57:29 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:57:29 --> Final output sent to browser
DEBUG - 2022-06-28 06:57:29 --> Total execution time: 0.0157
INFO - 2022-06-28 06:57:29 --> Config Class Initialized
INFO - 2022-06-28 06:57:29 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:57:29 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:57:29 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:29 --> URI Class Initialized
INFO - 2022-06-28 06:57:29 --> Router Class Initialized
INFO - 2022-06-28 06:57:29 --> Output Class Initialized
INFO - 2022-06-28 06:57:29 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:29 --> Input Class Initialized
INFO - 2022-06-28 06:57:29 --> Language Class Initialized
INFO - 2022-06-28 06:57:29 --> Loader Class Initialized
INFO - 2022-06-28 06:57:29 --> Helper loaded: url_helper
INFO - 2022-06-28 06:57:29 --> Helper loaded: file_helper
INFO - 2022-06-28 06:57:29 --> Database Driver Class Initialized
INFO - 2022-06-28 06:57:30 --> Config Class Initialized
INFO - 2022-06-28 06:57:30 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:57:30 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:57:30 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:30 --> URI Class Initialized
INFO - 2022-06-28 06:57:30 --> Router Class Initialized
INFO - 2022-06-28 06:57:30 --> Output Class Initialized
INFO - 2022-06-28 06:57:30 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:30 --> Input Class Initialized
INFO - 2022-06-28 06:57:30 --> Language Class Initialized
INFO - 2022-06-28 06:57:30 --> Loader Class Initialized
INFO - 2022-06-28 06:57:30 --> Helper loaded: url_helper
INFO - 2022-06-28 06:57:30 --> Helper loaded: file_helper
INFO - 2022-06-28 06:57:30 --> Database Driver Class Initialized
INFO - 2022-06-28 06:57:30 --> Email Class Initialized
DEBUG - 2022-06-28 06:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:57:30 --> Controller Class Initialized
INFO - 2022-06-28 06:57:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:57:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:57:30 --> Final output sent to browser
INFO - 2022-06-28 06:57:30 --> Email Class Initialized
DEBUG - 2022-06-28 06:57:30 --> Total execution time: 0.0166
DEBUG - 2022-06-28 06:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:57:30 --> Controller Class Initialized
INFO - 2022-06-28 06:57:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:57:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:57:30 --> Final output sent to browser
DEBUG - 2022-06-28 06:57:30 --> Total execution time: 0.1424
INFO - 2022-06-28 06:57:30 --> Config Class Initialized
INFO - 2022-06-28 06:57:30 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:57:30 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:57:30 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:30 --> URI Class Initialized
INFO - 2022-06-28 06:57:30 --> Router Class Initialized
INFO - 2022-06-28 06:57:30 --> Output Class Initialized
INFO - 2022-06-28 06:57:30 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:30 --> Input Class Initialized
INFO - 2022-06-28 06:57:30 --> Language Class Initialized
INFO - 2022-06-28 06:57:30 --> Loader Class Initialized
INFO - 2022-06-28 06:57:30 --> Helper loaded: url_helper
INFO - 2022-06-28 06:57:30 --> Helper loaded: file_helper
INFO - 2022-06-28 06:57:30 --> Database Driver Class Initialized
INFO - 2022-06-28 06:57:30 --> Email Class Initialized
DEBUG - 2022-06-28 06:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:57:30 --> Controller Class Initialized
INFO - 2022-06-28 06:57:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:57:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:57:30 --> Final output sent to browser
DEBUG - 2022-06-28 06:57:30 --> Total execution time: 0.0153
INFO - 2022-06-28 06:57:30 --> Config Class Initialized
INFO - 2022-06-28 06:57:30 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:57:30 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:57:30 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:30 --> URI Class Initialized
INFO - 2022-06-28 06:57:30 --> Router Class Initialized
INFO - 2022-06-28 06:57:30 --> Output Class Initialized
INFO - 2022-06-28 06:57:30 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:30 --> Input Class Initialized
INFO - 2022-06-28 06:57:30 --> Language Class Initialized
INFO - 2022-06-28 06:57:30 --> Loader Class Initialized
INFO - 2022-06-28 06:57:30 --> Helper loaded: url_helper
INFO - 2022-06-28 06:57:30 --> Helper loaded: file_helper
INFO - 2022-06-28 06:57:30 --> Database Driver Class Initialized
INFO - 2022-06-28 06:57:30 --> Email Class Initialized
DEBUG - 2022-06-28 06:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:57:30 --> Controller Class Initialized
INFO - 2022-06-28 06:57:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:57:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:57:30 --> Final output sent to browser
DEBUG - 2022-06-28 06:57:30 --> Total execution time: 0.0519
INFO - 2022-06-28 06:57:30 --> Config Class Initialized
INFO - 2022-06-28 06:57:30 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:57:30 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:57:30 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:30 --> URI Class Initialized
INFO - 2022-06-28 06:57:30 --> Router Class Initialized
INFO - 2022-06-28 06:57:30 --> Output Class Initialized
INFO - 2022-06-28 06:57:30 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:30 --> Input Class Initialized
INFO - 2022-06-28 06:57:30 --> Language Class Initialized
INFO - 2022-06-28 06:57:30 --> Loader Class Initialized
INFO - 2022-06-28 06:57:30 --> Helper loaded: url_helper
INFO - 2022-06-28 06:57:30 --> Helper loaded: file_helper
INFO - 2022-06-28 06:57:30 --> Database Driver Class Initialized
INFO - 2022-06-28 06:57:30 --> Email Class Initialized
DEBUG - 2022-06-28 06:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:57:30 --> Controller Class Initialized
INFO - 2022-06-28 06:57:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:57:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:57:30 --> Final output sent to browser
DEBUG - 2022-06-28 06:57:30 --> Total execution time: 0.0323
INFO - 2022-06-28 06:57:30 --> Config Class Initialized
INFO - 2022-06-28 06:57:30 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:57:30 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:57:30 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:30 --> URI Class Initialized
INFO - 2022-06-28 06:57:30 --> Router Class Initialized
INFO - 2022-06-28 06:57:30 --> Output Class Initialized
INFO - 2022-06-28 06:57:30 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:30 --> Input Class Initialized
INFO - 2022-06-28 06:57:30 --> Language Class Initialized
INFO - 2022-06-28 06:57:30 --> Loader Class Initialized
INFO - 2022-06-28 06:57:30 --> Helper loaded: url_helper
INFO - 2022-06-28 06:57:30 --> Helper loaded: file_helper
INFO - 2022-06-28 06:57:30 --> Database Driver Class Initialized
INFO - 2022-06-28 06:57:30 --> Email Class Initialized
DEBUG - 2022-06-28 06:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:57:30 --> Controller Class Initialized
INFO - 2022-06-28 06:57:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:57:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:57:30 --> Final output sent to browser
DEBUG - 2022-06-28 06:57:30 --> Total execution time: 0.0158
INFO - 2022-06-28 06:57:30 --> Config Class Initialized
INFO - 2022-06-28 06:57:30 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:57:30 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:57:30 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:30 --> URI Class Initialized
INFO - 2022-06-28 06:57:30 --> Router Class Initialized
INFO - 2022-06-28 06:57:30 --> Output Class Initialized
INFO - 2022-06-28 06:57:30 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:30 --> Input Class Initialized
INFO - 2022-06-28 06:57:30 --> Language Class Initialized
INFO - 2022-06-28 06:57:30 --> Loader Class Initialized
INFO - 2022-06-28 06:57:30 --> Helper loaded: url_helper
INFO - 2022-06-28 06:57:30 --> Helper loaded: file_helper
INFO - 2022-06-28 06:57:30 --> Database Driver Class Initialized
INFO - 2022-06-28 06:57:30 --> Email Class Initialized
DEBUG - 2022-06-28 06:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:57:30 --> Controller Class Initialized
INFO - 2022-06-28 06:57:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:57:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:57:30 --> Final output sent to browser
DEBUG - 2022-06-28 06:57:30 --> Total execution time: 0.0159
INFO - 2022-06-28 06:57:30 --> Config Class Initialized
INFO - 2022-06-28 06:57:30 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:57:30 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:57:30 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:30 --> URI Class Initialized
INFO - 2022-06-28 06:57:30 --> Router Class Initialized
INFO - 2022-06-28 06:57:30 --> Output Class Initialized
INFO - 2022-06-28 06:57:30 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:30 --> Input Class Initialized
INFO - 2022-06-28 06:57:30 --> Language Class Initialized
INFO - 2022-06-28 06:57:30 --> Loader Class Initialized
INFO - 2022-06-28 06:57:30 --> Helper loaded: url_helper
INFO - 2022-06-28 06:57:30 --> Helper loaded: file_helper
INFO - 2022-06-28 06:57:30 --> Database Driver Class Initialized
INFO - 2022-06-28 06:57:30 --> Email Class Initialized
DEBUG - 2022-06-28 06:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:57:30 --> Controller Class Initialized
INFO - 2022-06-28 06:57:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:57:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:57:30 --> Final output sent to browser
DEBUG - 2022-06-28 06:57:30 --> Total execution time: 0.0365
INFO - 2022-06-28 06:57:31 --> Config Class Initialized
INFO - 2022-06-28 06:57:31 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:57:31 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:57:31 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:31 --> URI Class Initialized
INFO - 2022-06-28 06:57:31 --> Router Class Initialized
INFO - 2022-06-28 06:57:31 --> Output Class Initialized
INFO - 2022-06-28 06:57:31 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:31 --> Input Class Initialized
INFO - 2022-06-28 06:57:31 --> Language Class Initialized
INFO - 2022-06-28 06:57:31 --> Loader Class Initialized
INFO - 2022-06-28 06:57:31 --> Helper loaded: url_helper
INFO - 2022-06-28 06:57:31 --> Helper loaded: file_helper
INFO - 2022-06-28 06:57:31 --> Database Driver Class Initialized
INFO - 2022-06-28 06:57:31 --> Email Class Initialized
DEBUG - 2022-06-28 06:57:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:57:31 --> Controller Class Initialized
INFO - 2022-06-28 06:57:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:57:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:57:31 --> Final output sent to browser
DEBUG - 2022-06-28 06:57:31 --> Total execution time: 0.0152
INFO - 2022-06-28 06:57:38 --> Config Class Initialized
INFO - 2022-06-28 06:57:38 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:57:38 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:57:38 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:38 --> URI Class Initialized
INFO - 2022-06-28 06:57:38 --> Router Class Initialized
INFO - 2022-06-28 06:57:38 --> Output Class Initialized
INFO - 2022-06-28 06:57:38 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:38 --> Input Class Initialized
INFO - 2022-06-28 06:57:38 --> Language Class Initialized
INFO - 2022-06-28 06:57:38 --> Loader Class Initialized
INFO - 2022-06-28 06:57:38 --> Helper loaded: url_helper
INFO - 2022-06-28 06:57:38 --> Helper loaded: file_helper
INFO - 2022-06-28 06:57:38 --> Database Driver Class Initialized
INFO - 2022-06-28 06:57:38 --> Email Class Initialized
DEBUG - 2022-06-28 06:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:57:38 --> Controller Class Initialized
INFO - 2022-06-28 06:57:38 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:57:38 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:57:38 --> Final output sent to browser
DEBUG - 2022-06-28 06:57:38 --> Total execution time: 0.1221
INFO - 2022-06-28 06:57:45 --> Config Class Initialized
INFO - 2022-06-28 06:57:45 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:57:45 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:57:45 --> Utf8 Class Initialized
INFO - 2022-06-28 06:57:45 --> URI Class Initialized
INFO - 2022-06-28 06:57:45 --> Router Class Initialized
INFO - 2022-06-28 06:57:45 --> Output Class Initialized
INFO - 2022-06-28 06:57:45 --> Security Class Initialized
DEBUG - 2022-06-28 06:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:57:45 --> Input Class Initialized
INFO - 2022-06-28 06:57:45 --> Language Class Initialized
INFO - 2022-06-28 06:57:45 --> Loader Class Initialized
INFO - 2022-06-28 06:57:45 --> Helper loaded: url_helper
INFO - 2022-06-28 06:57:45 --> Helper loaded: file_helper
INFO - 2022-06-28 06:57:45 --> Database Driver Class Initialized
INFO - 2022-06-28 06:57:45 --> Email Class Initialized
DEBUG - 2022-06-28 06:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:57:45 --> Controller Class Initialized
INFO - 2022-06-28 06:57:45 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:57:45 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:57:45 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 06:57:45 --> Final output sent to browser
DEBUG - 2022-06-28 06:57:45 --> Total execution time: 0.0389
INFO - 2022-06-28 06:58:11 --> Config Class Initialized
INFO - 2022-06-28 06:58:11 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:58:11 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:58:11 --> Utf8 Class Initialized
INFO - 2022-06-28 06:58:11 --> URI Class Initialized
INFO - 2022-06-28 06:58:11 --> Router Class Initialized
INFO - 2022-06-28 06:58:11 --> Output Class Initialized
INFO - 2022-06-28 06:58:11 --> Security Class Initialized
DEBUG - 2022-06-28 06:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:58:11 --> Input Class Initialized
INFO - 2022-06-28 06:58:11 --> Language Class Initialized
INFO - 2022-06-28 06:58:11 --> Loader Class Initialized
INFO - 2022-06-28 06:58:11 --> Helper loaded: url_helper
INFO - 2022-06-28 06:58:11 --> Helper loaded: file_helper
INFO - 2022-06-28 06:58:11 --> Database Driver Class Initialized
INFO - 2022-06-28 06:58:11 --> Email Class Initialized
DEBUG - 2022-06-28 06:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 06:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 06:58:11 --> Controller Class Initialized
INFO - 2022-06-28 06:58:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 06:58:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 06:58:11 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 06:58:11 --> Final output sent to browser
DEBUG - 2022-06-28 06:58:11 --> Total execution time: 0.1311
INFO - 2022-06-28 06:58:11 --> Config Class Initialized
INFO - 2022-06-28 06:58:11 --> Config Class Initialized
INFO - 2022-06-28 06:58:11 --> Hooks Class Initialized
INFO - 2022-06-28 06:58:11 --> Hooks Class Initialized
DEBUG - 2022-06-28 06:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-28 06:58:11 --> UTF-8 Support Enabled
INFO - 2022-06-28 06:58:11 --> Utf8 Class Initialized
INFO - 2022-06-28 06:58:11 --> Utf8 Class Initialized
INFO - 2022-06-28 06:58:11 --> URI Class Initialized
INFO - 2022-06-28 06:58:11 --> URI Class Initialized
INFO - 2022-06-28 06:58:11 --> Router Class Initialized
INFO - 2022-06-28 06:58:11 --> Router Class Initialized
INFO - 2022-06-28 06:58:11 --> Output Class Initialized
INFO - 2022-06-28 06:58:11 --> Output Class Initialized
INFO - 2022-06-28 06:58:11 --> Security Class Initialized
INFO - 2022-06-28 06:58:11 --> Security Class Initialized
DEBUG - 2022-06-28 06:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:58:11 --> Input Class Initialized
DEBUG - 2022-06-28 06:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 06:58:11 --> Input Class Initialized
INFO - 2022-06-28 06:58:11 --> Language Class Initialized
INFO - 2022-06-28 06:58:11 --> Language Class Initialized
ERROR - 2022-06-28 06:58:11 --> 404 Page Not Found: Tokenctrl/localhost
ERROR - 2022-06-28 06:58:11 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-28 07:02:19 --> Config Class Initialized
INFO - 2022-06-28 07:02:19 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:02:19 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:02:19 --> Utf8 Class Initialized
INFO - 2022-06-28 07:02:19 --> URI Class Initialized
INFO - 2022-06-28 07:02:19 --> Router Class Initialized
INFO - 2022-06-28 07:02:19 --> Output Class Initialized
INFO - 2022-06-28 07:02:19 --> Security Class Initialized
DEBUG - 2022-06-28 07:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:02:19 --> Input Class Initialized
INFO - 2022-06-28 07:02:19 --> Language Class Initialized
INFO - 2022-06-28 07:02:19 --> Loader Class Initialized
INFO - 2022-06-28 07:02:19 --> Helper loaded: url_helper
INFO - 2022-06-28 07:02:19 --> Helper loaded: file_helper
INFO - 2022-06-28 07:02:19 --> Database Driver Class Initialized
INFO - 2022-06-28 07:02:19 --> Email Class Initialized
DEBUG - 2022-06-28 07:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 07:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 07:02:19 --> Controller Class Initialized
INFO - 2022-06-28 07:02:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 07:02:19 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 07:02:19 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 07:02:19 --> Final output sent to browser
DEBUG - 2022-06-28 07:02:19 --> Total execution time: 0.1544
INFO - 2022-06-28 07:02:22 --> Config Class Initialized
INFO - 2022-06-28 07:02:22 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:02:22 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:02:22 --> Utf8 Class Initialized
INFO - 2022-06-28 07:02:22 --> URI Class Initialized
INFO - 2022-06-28 07:02:22 --> Router Class Initialized
INFO - 2022-06-28 07:02:22 --> Output Class Initialized
INFO - 2022-06-28 07:02:22 --> Security Class Initialized
DEBUG - 2022-06-28 07:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:02:22 --> Input Class Initialized
INFO - 2022-06-28 07:02:22 --> Language Class Initialized
INFO - 2022-06-28 07:02:22 --> Loader Class Initialized
INFO - 2022-06-28 07:02:22 --> Helper loaded: url_helper
INFO - 2022-06-28 07:02:22 --> Helper loaded: file_helper
INFO - 2022-06-28 07:02:22 --> Database Driver Class Initialized
INFO - 2022-06-28 07:02:22 --> Email Class Initialized
DEBUG - 2022-06-28 07:02:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 07:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 07:02:22 --> Controller Class Initialized
INFO - 2022-06-28 07:02:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 07:02:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 07:02:22 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 07:02:22 --> Final output sent to browser
DEBUG - 2022-06-28 07:02:22 --> Total execution time: 0.1460
INFO - 2022-06-28 07:02:40 --> Config Class Initialized
INFO - 2022-06-28 07:02:40 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:02:40 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:02:40 --> Utf8 Class Initialized
INFO - 2022-06-28 07:02:40 --> URI Class Initialized
INFO - 2022-06-28 07:02:40 --> Router Class Initialized
INFO - 2022-06-28 07:02:40 --> Output Class Initialized
INFO - 2022-06-28 07:02:40 --> Security Class Initialized
DEBUG - 2022-06-28 07:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:02:40 --> Input Class Initialized
INFO - 2022-06-28 07:02:40 --> Language Class Initialized
INFO - 2022-06-28 07:02:40 --> Loader Class Initialized
INFO - 2022-06-28 07:02:40 --> Helper loaded: url_helper
INFO - 2022-06-28 07:02:40 --> Helper loaded: file_helper
INFO - 2022-06-28 07:02:40 --> Database Driver Class Initialized
INFO - 2022-06-28 07:02:40 --> Email Class Initialized
DEBUG - 2022-06-28 07:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 07:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 07:02:40 --> Controller Class Initialized
INFO - 2022-06-28 07:02:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 07:02:40 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 07:02:40 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 07:02:40 --> Final output sent to browser
DEBUG - 2022-06-28 07:02:40 --> Total execution time: 0.0415
INFO - 2022-06-28 07:20:41 --> Config Class Initialized
INFO - 2022-06-28 07:20:41 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:20:41 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:20:41 --> Utf8 Class Initialized
INFO - 2022-06-28 07:20:41 --> URI Class Initialized
INFO - 2022-06-28 07:20:41 --> Router Class Initialized
INFO - 2022-06-28 07:20:41 --> Output Class Initialized
INFO - 2022-06-28 07:20:41 --> Security Class Initialized
DEBUG - 2022-06-28 07:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:20:41 --> Input Class Initialized
INFO - 2022-06-28 07:20:41 --> Language Class Initialized
INFO - 2022-06-28 07:20:41 --> Loader Class Initialized
INFO - 2022-06-28 07:20:41 --> Helper loaded: url_helper
INFO - 2022-06-28 07:20:41 --> Helper loaded: file_helper
INFO - 2022-06-28 07:20:41 --> Database Driver Class Initialized
INFO - 2022-06-28 07:20:42 --> Email Class Initialized
DEBUG - 2022-06-28 07:20:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 07:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 07:20:42 --> Controller Class Initialized
INFO - 2022-06-28 07:20:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 07:20:42 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 07:20:42 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 07:20:42 --> Final output sent to browser
DEBUG - 2022-06-28 07:20:42 --> Total execution time: 0.1731
INFO - 2022-06-28 07:20:49 --> Config Class Initialized
INFO - 2022-06-28 07:20:49 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:20:49 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:20:49 --> Utf8 Class Initialized
INFO - 2022-06-28 07:20:49 --> URI Class Initialized
INFO - 2022-06-28 07:20:49 --> Router Class Initialized
INFO - 2022-06-28 07:20:49 --> Output Class Initialized
INFO - 2022-06-28 07:20:49 --> Security Class Initialized
DEBUG - 2022-06-28 07:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:20:49 --> Input Class Initialized
INFO - 2022-06-28 07:20:49 --> Language Class Initialized
INFO - 2022-06-28 07:20:49 --> Loader Class Initialized
INFO - 2022-06-28 07:20:49 --> Helper loaded: url_helper
INFO - 2022-06-28 07:20:49 --> Helper loaded: file_helper
INFO - 2022-06-28 07:20:49 --> Database Driver Class Initialized
INFO - 2022-06-28 07:20:49 --> Email Class Initialized
DEBUG - 2022-06-28 07:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 07:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 07:20:49 --> Controller Class Initialized
INFO - 2022-06-28 07:20:49 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 07:20:49 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 07:20:49 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 07:20:49 --> Final output sent to browser
DEBUG - 2022-06-28 07:20:49 --> Total execution time: 0.0428
INFO - 2022-06-28 07:20:49 --> Config Class Initialized
INFO - 2022-06-28 07:20:49 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:20:49 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:20:49 --> Utf8 Class Initialized
INFO - 2022-06-28 07:20:49 --> URI Class Initialized
INFO - 2022-06-28 07:20:49 --> Router Class Initialized
INFO - 2022-06-28 07:20:49 --> Output Class Initialized
INFO - 2022-06-28 07:20:49 --> Security Class Initialized
DEBUG - 2022-06-28 07:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:20:49 --> Input Class Initialized
INFO - 2022-06-28 07:20:49 --> Language Class Initialized
ERROR - 2022-06-28 07:20:49 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-28 07:20:49 --> Config Class Initialized
INFO - 2022-06-28 07:20:49 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:20:49 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:20:49 --> Utf8 Class Initialized
INFO - 2022-06-28 07:20:49 --> URI Class Initialized
INFO - 2022-06-28 07:20:49 --> Router Class Initialized
INFO - 2022-06-28 07:20:49 --> Output Class Initialized
INFO - 2022-06-28 07:20:49 --> Security Class Initialized
DEBUG - 2022-06-28 07:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:20:49 --> Input Class Initialized
INFO - 2022-06-28 07:20:49 --> Language Class Initialized
ERROR - 2022-06-28 07:20:49 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-28 07:22:07 --> Config Class Initialized
INFO - 2022-06-28 07:22:07 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:22:07 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:22:07 --> Utf8 Class Initialized
INFO - 2022-06-28 07:22:07 --> URI Class Initialized
INFO - 2022-06-28 07:22:07 --> Router Class Initialized
INFO - 2022-06-28 07:22:07 --> Output Class Initialized
INFO - 2022-06-28 07:22:07 --> Security Class Initialized
DEBUG - 2022-06-28 07:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:22:07 --> Input Class Initialized
INFO - 2022-06-28 07:22:07 --> Language Class Initialized
INFO - 2022-06-28 07:22:07 --> Loader Class Initialized
INFO - 2022-06-28 07:22:07 --> Helper loaded: url_helper
INFO - 2022-06-28 07:22:07 --> Helper loaded: file_helper
INFO - 2022-06-28 07:22:07 --> Database Driver Class Initialized
INFO - 2022-06-28 07:22:07 --> Email Class Initialized
DEBUG - 2022-06-28 07:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 07:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 07:22:07 --> Controller Class Initialized
INFO - 2022-06-28 07:22:07 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 07:22:07 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 07:22:07 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 07:22:07 --> Final output sent to browser
DEBUG - 2022-06-28 07:22:07 --> Total execution time: 0.1222
INFO - 2022-06-28 07:22:16 --> Config Class Initialized
INFO - 2022-06-28 07:22:16 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:22:16 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:22:16 --> Utf8 Class Initialized
INFO - 2022-06-28 07:22:16 --> URI Class Initialized
INFO - 2022-06-28 07:22:16 --> Router Class Initialized
INFO - 2022-06-28 07:22:16 --> Output Class Initialized
INFO - 2022-06-28 07:22:16 --> Security Class Initialized
DEBUG - 2022-06-28 07:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:22:16 --> Input Class Initialized
INFO - 2022-06-28 07:22:16 --> Language Class Initialized
INFO - 2022-06-28 07:22:16 --> Loader Class Initialized
INFO - 2022-06-28 07:22:16 --> Helper loaded: url_helper
INFO - 2022-06-28 07:22:16 --> Helper loaded: file_helper
INFO - 2022-06-28 07:22:16 --> Database Driver Class Initialized
INFO - 2022-06-28 07:22:16 --> Email Class Initialized
DEBUG - 2022-06-28 07:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 07:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 07:22:16 --> Controller Class Initialized
INFO - 2022-06-28 07:22:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 07:22:16 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 07:22:16 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 07:22:16 --> Final output sent to browser
DEBUG - 2022-06-28 07:22:16 --> Total execution time: 0.1683
INFO - 2022-06-28 07:22:16 --> Config Class Initialized
INFO - 2022-06-28 07:22:16 --> Config Class Initialized
INFO - 2022-06-28 07:22:16 --> Hooks Class Initialized
INFO - 2022-06-28 07:22:16 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-28 07:22:16 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:22:16 --> Utf8 Class Initialized
INFO - 2022-06-28 07:22:16 --> Utf8 Class Initialized
INFO - 2022-06-28 07:22:16 --> URI Class Initialized
INFO - 2022-06-28 07:22:16 --> URI Class Initialized
INFO - 2022-06-28 07:22:16 --> Router Class Initialized
INFO - 2022-06-28 07:22:16 --> Router Class Initialized
INFO - 2022-06-28 07:22:16 --> Output Class Initialized
INFO - 2022-06-28 07:22:16 --> Output Class Initialized
INFO - 2022-06-28 07:22:16 --> Security Class Initialized
INFO - 2022-06-28 07:22:16 --> Security Class Initialized
DEBUG - 2022-06-28 07:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-28 07:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:22:16 --> Input Class Initialized
INFO - 2022-06-28 07:22:16 --> Input Class Initialized
INFO - 2022-06-28 07:22:16 --> Language Class Initialized
INFO - 2022-06-28 07:22:16 --> Language Class Initialized
ERROR - 2022-06-28 07:22:16 --> 404 Page Not Found: Tokenctrl/localhost
ERROR - 2022-06-28 07:22:16 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-28 07:25:32 --> Config Class Initialized
INFO - 2022-06-28 07:25:32 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:25:32 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:25:32 --> Utf8 Class Initialized
INFO - 2022-06-28 07:25:32 --> URI Class Initialized
INFO - 2022-06-28 07:25:32 --> Router Class Initialized
INFO - 2022-06-28 07:25:32 --> Output Class Initialized
INFO - 2022-06-28 07:25:32 --> Security Class Initialized
DEBUG - 2022-06-28 07:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:25:32 --> Input Class Initialized
INFO - 2022-06-28 07:25:32 --> Language Class Initialized
INFO - 2022-06-28 07:25:32 --> Loader Class Initialized
INFO - 2022-06-28 07:25:32 --> Helper loaded: url_helper
INFO - 2022-06-28 07:25:32 --> Helper loaded: file_helper
INFO - 2022-06-28 07:25:32 --> Database Driver Class Initialized
INFO - 2022-06-28 07:25:32 --> Email Class Initialized
DEBUG - 2022-06-28 07:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 07:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 07:25:32 --> Controller Class Initialized
INFO - 2022-06-28 07:25:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 07:25:32 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 07:25:32 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 07:25:32 --> Final output sent to browser
DEBUG - 2022-06-28 07:25:32 --> Total execution time: 0.2071
INFO - 2022-06-28 07:25:35 --> Config Class Initialized
INFO - 2022-06-28 07:25:35 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:25:35 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:25:35 --> Utf8 Class Initialized
INFO - 2022-06-28 07:25:35 --> URI Class Initialized
INFO - 2022-06-28 07:25:35 --> Router Class Initialized
INFO - 2022-06-28 07:25:35 --> Output Class Initialized
INFO - 2022-06-28 07:25:35 --> Security Class Initialized
DEBUG - 2022-06-28 07:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:25:35 --> Input Class Initialized
INFO - 2022-06-28 07:25:35 --> Language Class Initialized
INFO - 2022-06-28 07:25:35 --> Loader Class Initialized
INFO - 2022-06-28 07:25:35 --> Helper loaded: url_helper
INFO - 2022-06-28 07:25:35 --> Helper loaded: file_helper
INFO - 2022-06-28 07:25:35 --> Database Driver Class Initialized
INFO - 2022-06-28 07:25:35 --> Email Class Initialized
DEBUG - 2022-06-28 07:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 07:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 07:25:35 --> Controller Class Initialized
INFO - 2022-06-28 07:25:35 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 07:25:35 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 07:25:35 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 07:25:35 --> Final output sent to browser
DEBUG - 2022-06-28 07:25:35 --> Total execution time: 0.1091
INFO - 2022-06-28 07:25:35 --> Config Class Initialized
INFO - 2022-06-28 07:25:35 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:25:35 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:25:35 --> Utf8 Class Initialized
INFO - 2022-06-28 07:25:35 --> URI Class Initialized
INFO - 2022-06-28 07:25:35 --> Router Class Initialized
INFO - 2022-06-28 07:25:35 --> Output Class Initialized
INFO - 2022-06-28 07:25:35 --> Security Class Initialized
DEBUG - 2022-06-28 07:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:25:35 --> Input Class Initialized
INFO - 2022-06-28 07:25:35 --> Language Class Initialized
ERROR - 2022-06-28 07:25:35 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-28 07:25:36 --> Config Class Initialized
INFO - 2022-06-28 07:25:36 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:25:36 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:25:36 --> Utf8 Class Initialized
INFO - 2022-06-28 07:25:36 --> URI Class Initialized
INFO - 2022-06-28 07:25:36 --> Router Class Initialized
INFO - 2022-06-28 07:25:36 --> Output Class Initialized
INFO - 2022-06-28 07:25:36 --> Security Class Initialized
DEBUG - 2022-06-28 07:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:25:36 --> Input Class Initialized
INFO - 2022-06-28 07:25:36 --> Language Class Initialized
ERROR - 2022-06-28 07:25:36 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-28 07:25:42 --> Config Class Initialized
INFO - 2022-06-28 07:25:42 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:25:42 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:25:42 --> Utf8 Class Initialized
INFO - 2022-06-28 07:25:42 --> URI Class Initialized
INFO - 2022-06-28 07:25:42 --> Router Class Initialized
INFO - 2022-06-28 07:25:42 --> Output Class Initialized
INFO - 2022-06-28 07:25:42 --> Security Class Initialized
DEBUG - 2022-06-28 07:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:25:42 --> Input Class Initialized
INFO - 2022-06-28 07:25:42 --> Language Class Initialized
INFO - 2022-06-28 07:25:42 --> Loader Class Initialized
INFO - 2022-06-28 07:25:42 --> Helper loaded: url_helper
INFO - 2022-06-28 07:25:42 --> Helper loaded: file_helper
INFO - 2022-06-28 07:25:42 --> Database Driver Class Initialized
INFO - 2022-06-28 07:25:42 --> Email Class Initialized
DEBUG - 2022-06-28 07:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 07:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 07:25:42 --> Controller Class Initialized
INFO - 2022-06-28 07:25:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 07:25:42 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 07:25:42 --> Final output sent to browser
DEBUG - 2022-06-28 07:25:42 --> Total execution time: 0.1319
INFO - 2022-06-28 07:25:44 --> Config Class Initialized
INFO - 2022-06-28 07:25:44 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:25:44 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:25:44 --> Utf8 Class Initialized
INFO - 2022-06-28 07:25:44 --> URI Class Initialized
INFO - 2022-06-28 07:25:44 --> Router Class Initialized
INFO - 2022-06-28 07:25:44 --> Output Class Initialized
INFO - 2022-06-28 07:25:44 --> Security Class Initialized
DEBUG - 2022-06-28 07:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:25:44 --> Input Class Initialized
INFO - 2022-06-28 07:25:44 --> Language Class Initialized
INFO - 2022-06-28 07:25:44 --> Loader Class Initialized
INFO - 2022-06-28 07:25:44 --> Helper loaded: url_helper
INFO - 2022-06-28 07:25:44 --> Helper loaded: file_helper
INFO - 2022-06-28 07:25:44 --> Database Driver Class Initialized
INFO - 2022-06-28 07:25:44 --> Email Class Initialized
DEBUG - 2022-06-28 07:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 07:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 07:25:44 --> Controller Class Initialized
INFO - 2022-06-28 07:25:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 07:25:44 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 07:25:44 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 07:25:44 --> Final output sent to browser
DEBUG - 2022-06-28 07:25:44 --> Total execution time: 0.0425
INFO - 2022-06-28 07:26:41 --> Config Class Initialized
INFO - 2022-06-28 07:26:41 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:26:41 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:26:41 --> Utf8 Class Initialized
INFO - 2022-06-28 07:26:41 --> URI Class Initialized
INFO - 2022-06-28 07:26:41 --> Router Class Initialized
INFO - 2022-06-28 07:26:41 --> Output Class Initialized
INFO - 2022-06-28 07:26:41 --> Security Class Initialized
DEBUG - 2022-06-28 07:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:26:41 --> Input Class Initialized
INFO - 2022-06-28 07:26:41 --> Language Class Initialized
INFO - 2022-06-28 07:26:41 --> Loader Class Initialized
INFO - 2022-06-28 07:26:41 --> Helper loaded: url_helper
INFO - 2022-06-28 07:26:41 --> Helper loaded: file_helper
INFO - 2022-06-28 07:26:41 --> Database Driver Class Initialized
INFO - 2022-06-28 07:26:41 --> Email Class Initialized
DEBUG - 2022-06-28 07:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 07:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 07:26:41 --> Controller Class Initialized
INFO - 2022-06-28 07:26:41 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 07:26:41 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 07:26:41 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 07:26:41 --> Final output sent to browser
DEBUG - 2022-06-28 07:26:41 --> Total execution time: 0.1497
INFO - 2022-06-28 07:26:42 --> Config Class Initialized
INFO - 2022-06-28 07:26:42 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:26:42 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:26:42 --> Utf8 Class Initialized
INFO - 2022-06-28 07:26:42 --> URI Class Initialized
INFO - 2022-06-28 07:26:42 --> Router Class Initialized
INFO - 2022-06-28 07:26:42 --> Output Class Initialized
INFO - 2022-06-28 07:26:42 --> Security Class Initialized
DEBUG - 2022-06-28 07:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:26:42 --> Input Class Initialized
INFO - 2022-06-28 07:26:42 --> Language Class Initialized
INFO - 2022-06-28 07:26:42 --> Loader Class Initialized
INFO - 2022-06-28 07:26:42 --> Helper loaded: url_helper
INFO - 2022-06-28 07:26:42 --> Helper loaded: file_helper
INFO - 2022-06-28 07:26:42 --> Database Driver Class Initialized
INFO - 2022-06-28 07:26:42 --> Email Class Initialized
DEBUG - 2022-06-28 07:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 07:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 07:26:42 --> Controller Class Initialized
INFO - 2022-06-28 07:26:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 07:26:42 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 07:26:42 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 07:26:42 --> Final output sent to browser
DEBUG - 2022-06-28 07:26:42 --> Total execution time: 0.0262
INFO - 2022-06-28 07:26:42 --> Config Class Initialized
INFO - 2022-06-28 07:26:42 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:26:42 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:26:42 --> Utf8 Class Initialized
INFO - 2022-06-28 07:26:42 --> URI Class Initialized
INFO - 2022-06-28 07:26:42 --> Router Class Initialized
INFO - 2022-06-28 07:26:42 --> Output Class Initialized
INFO - 2022-06-28 07:26:42 --> Security Class Initialized
DEBUG - 2022-06-28 07:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:26:42 --> Input Class Initialized
INFO - 2022-06-28 07:26:42 --> Language Class Initialized
ERROR - 2022-06-28 07:26:42 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-28 07:26:43 --> Config Class Initialized
INFO - 2022-06-28 07:26:43 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:26:43 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:26:43 --> Utf8 Class Initialized
INFO - 2022-06-28 07:26:43 --> URI Class Initialized
INFO - 2022-06-28 07:26:43 --> Router Class Initialized
INFO - 2022-06-28 07:26:43 --> Output Class Initialized
INFO - 2022-06-28 07:26:43 --> Security Class Initialized
DEBUG - 2022-06-28 07:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:26:43 --> Input Class Initialized
INFO - 2022-06-28 07:26:43 --> Language Class Initialized
ERROR - 2022-06-28 07:26:43 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-28 07:26:45 --> Config Class Initialized
INFO - 2022-06-28 07:26:45 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:26:45 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:26:45 --> Utf8 Class Initialized
INFO - 2022-06-28 07:26:45 --> URI Class Initialized
INFO - 2022-06-28 07:26:45 --> Router Class Initialized
INFO - 2022-06-28 07:26:45 --> Output Class Initialized
INFO - 2022-06-28 07:26:45 --> Security Class Initialized
DEBUG - 2022-06-28 07:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:26:45 --> Input Class Initialized
INFO - 2022-06-28 07:26:45 --> Language Class Initialized
INFO - 2022-06-28 07:26:45 --> Loader Class Initialized
INFO - 2022-06-28 07:26:45 --> Helper loaded: url_helper
INFO - 2022-06-28 07:26:45 --> Helper loaded: file_helper
INFO - 2022-06-28 07:26:45 --> Database Driver Class Initialized
INFO - 2022-06-28 07:26:45 --> Email Class Initialized
DEBUG - 2022-06-28 07:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 07:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 07:26:45 --> Controller Class Initialized
INFO - 2022-06-28 07:26:45 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 07:26:45 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 07:26:45 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 07:26:45 --> Final output sent to browser
DEBUG - 2022-06-28 07:26:45 --> Total execution time: 0.1521
INFO - 2022-06-28 07:26:46 --> Config Class Initialized
INFO - 2022-06-28 07:26:46 --> Config Class Initialized
INFO - 2022-06-28 07:26:46 --> Hooks Class Initialized
INFO - 2022-06-28 07:26:46 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:26:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-28 07:26:46 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:26:46 --> Utf8 Class Initialized
INFO - 2022-06-28 07:26:46 --> Utf8 Class Initialized
INFO - 2022-06-28 07:26:46 --> URI Class Initialized
INFO - 2022-06-28 07:26:46 --> URI Class Initialized
INFO - 2022-06-28 07:26:46 --> Router Class Initialized
INFO - 2022-06-28 07:26:46 --> Router Class Initialized
INFO - 2022-06-28 07:26:46 --> Output Class Initialized
INFO - 2022-06-28 07:26:46 --> Output Class Initialized
INFO - 2022-06-28 07:26:46 --> Security Class Initialized
INFO - 2022-06-28 07:26:46 --> Security Class Initialized
DEBUG - 2022-06-28 07:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-28 07:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:26:46 --> Input Class Initialized
INFO - 2022-06-28 07:26:46 --> Input Class Initialized
INFO - 2022-06-28 07:26:46 --> Language Class Initialized
INFO - 2022-06-28 07:26:46 --> Language Class Initialized
ERROR - 2022-06-28 07:26:46 --> 404 Page Not Found: Tokenctrl/localhost
ERROR - 2022-06-28 07:26:46 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-28 07:26:48 --> Config Class Initialized
INFO - 2022-06-28 07:26:48 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:26:48 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:26:48 --> Utf8 Class Initialized
INFO - 2022-06-28 07:26:48 --> URI Class Initialized
INFO - 2022-06-28 07:26:48 --> Router Class Initialized
INFO - 2022-06-28 07:26:48 --> Output Class Initialized
INFO - 2022-06-28 07:26:48 --> Security Class Initialized
DEBUG - 2022-06-28 07:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:26:48 --> Input Class Initialized
INFO - 2022-06-28 07:26:48 --> Language Class Initialized
INFO - 2022-06-28 07:26:48 --> Loader Class Initialized
INFO - 2022-06-28 07:26:48 --> Helper loaded: url_helper
INFO - 2022-06-28 07:26:48 --> Helper loaded: file_helper
INFO - 2022-06-28 07:26:48 --> Database Driver Class Initialized
INFO - 2022-06-28 07:26:48 --> Email Class Initialized
DEBUG - 2022-06-28 07:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 07:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 07:26:48 --> Controller Class Initialized
INFO - 2022-06-28 07:26:48 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 07:26:48 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 07:26:48 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 07:26:48 --> Final output sent to browser
DEBUG - 2022-06-28 07:26:48 --> Total execution time: 0.1495
INFO - 2022-06-28 07:26:48 --> Config Class Initialized
INFO - 2022-06-28 07:26:48 --> Config Class Initialized
INFO - 2022-06-28 07:26:48 --> Hooks Class Initialized
INFO - 2022-06-28 07:26:48 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:26:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-28 07:26:48 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:26:48 --> Utf8 Class Initialized
INFO - 2022-06-28 07:26:48 --> Utf8 Class Initialized
INFO - 2022-06-28 07:26:48 --> URI Class Initialized
INFO - 2022-06-28 07:26:48 --> URI Class Initialized
INFO - 2022-06-28 07:26:48 --> Router Class Initialized
INFO - 2022-06-28 07:26:48 --> Router Class Initialized
INFO - 2022-06-28 07:26:48 --> Output Class Initialized
INFO - 2022-06-28 07:26:48 --> Output Class Initialized
INFO - 2022-06-28 07:26:48 --> Security Class Initialized
INFO - 2022-06-28 07:26:48 --> Security Class Initialized
DEBUG - 2022-06-28 07:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-28 07:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:26:48 --> Input Class Initialized
INFO - 2022-06-28 07:26:48 --> Input Class Initialized
INFO - 2022-06-28 07:26:48 --> Language Class Initialized
INFO - 2022-06-28 07:26:48 --> Language Class Initialized
ERROR - 2022-06-28 07:26:48 --> 404 Page Not Found: Tokenctrl/localhost
ERROR - 2022-06-28 07:26:48 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-28 07:26:49 --> Config Class Initialized
INFO - 2022-06-28 07:26:49 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:26:49 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:26:49 --> Utf8 Class Initialized
INFO - 2022-06-28 07:26:49 --> URI Class Initialized
INFO - 2022-06-28 07:26:49 --> Router Class Initialized
INFO - 2022-06-28 07:26:49 --> Output Class Initialized
INFO - 2022-06-28 07:26:49 --> Security Class Initialized
DEBUG - 2022-06-28 07:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:26:49 --> Input Class Initialized
INFO - 2022-06-28 07:26:49 --> Language Class Initialized
INFO - 2022-06-28 07:26:49 --> Loader Class Initialized
INFO - 2022-06-28 07:26:49 --> Helper loaded: url_helper
INFO - 2022-06-28 07:26:49 --> Helper loaded: file_helper
INFO - 2022-06-28 07:26:49 --> Database Driver Class Initialized
INFO - 2022-06-28 07:26:49 --> Email Class Initialized
DEBUG - 2022-06-28 07:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 07:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 07:26:49 --> Controller Class Initialized
INFO - 2022-06-28 07:26:49 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 07:26:49 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 07:26:49 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 07:26:49 --> Final output sent to browser
DEBUG - 2022-06-28 07:26:49 --> Total execution time: 0.1639
INFO - 2022-06-28 07:26:49 --> Config Class Initialized
INFO - 2022-06-28 07:26:49 --> Hooks Class Initialized
INFO - 2022-06-28 07:26:49 --> Config Class Initialized
INFO - 2022-06-28 07:26:49 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:26:49 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:26:49 --> Utf8 Class Initialized
DEBUG - 2022-06-28 07:26:49 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:26:49 --> URI Class Initialized
INFO - 2022-06-28 07:26:49 --> Utf8 Class Initialized
INFO - 2022-06-28 07:26:49 --> URI Class Initialized
INFO - 2022-06-28 07:26:49 --> Router Class Initialized
INFO - 2022-06-28 07:26:49 --> Router Class Initialized
INFO - 2022-06-28 07:26:49 --> Output Class Initialized
INFO - 2022-06-28 07:26:49 --> Output Class Initialized
INFO - 2022-06-28 07:26:49 --> Security Class Initialized
INFO - 2022-06-28 07:26:49 --> Security Class Initialized
DEBUG - 2022-06-28 07:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:26:49 --> Input Class Initialized
DEBUG - 2022-06-28 07:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:26:49 --> Language Class Initialized
INFO - 2022-06-28 07:26:49 --> Input Class Initialized
INFO - 2022-06-28 07:26:49 --> Language Class Initialized
ERROR - 2022-06-28 07:26:49 --> 404 Page Not Found: Tokenctrl/localhost
ERROR - 2022-06-28 07:26:49 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-28 07:26:50 --> Config Class Initialized
INFO - 2022-06-28 07:26:50 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:26:50 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:26:50 --> Utf8 Class Initialized
INFO - 2022-06-28 07:26:50 --> URI Class Initialized
INFO - 2022-06-28 07:26:50 --> Router Class Initialized
INFO - 2022-06-28 07:26:50 --> Output Class Initialized
INFO - 2022-06-28 07:26:50 --> Security Class Initialized
DEBUG - 2022-06-28 07:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:26:50 --> Input Class Initialized
INFO - 2022-06-28 07:26:50 --> Language Class Initialized
INFO - 2022-06-28 07:26:50 --> Loader Class Initialized
INFO - 2022-06-28 07:26:50 --> Helper loaded: url_helper
INFO - 2022-06-28 07:26:50 --> Helper loaded: file_helper
INFO - 2022-06-28 07:26:50 --> Database Driver Class Initialized
INFO - 2022-06-28 07:26:50 --> Email Class Initialized
DEBUG - 2022-06-28 07:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 07:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 07:26:50 --> Controller Class Initialized
INFO - 2022-06-28 07:26:50 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 07:26:50 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 07:26:50 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 07:26:50 --> Final output sent to browser
DEBUG - 2022-06-28 07:26:50 --> Total execution time: 0.0168
INFO - 2022-06-28 07:26:50 --> Config Class Initialized
INFO - 2022-06-28 07:26:50 --> Config Class Initialized
INFO - 2022-06-28 07:26:50 --> Hooks Class Initialized
INFO - 2022-06-28 07:26:50 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-28 07:26:50 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:26:50 --> Utf8 Class Initialized
INFO - 2022-06-28 07:26:50 --> Utf8 Class Initialized
INFO - 2022-06-28 07:26:50 --> URI Class Initialized
INFO - 2022-06-28 07:26:50 --> URI Class Initialized
INFO - 2022-06-28 07:26:50 --> Router Class Initialized
INFO - 2022-06-28 07:26:50 --> Router Class Initialized
INFO - 2022-06-28 07:26:50 --> Output Class Initialized
INFO - 2022-06-28 07:26:50 --> Output Class Initialized
INFO - 2022-06-28 07:26:50 --> Security Class Initialized
INFO - 2022-06-28 07:26:50 --> Security Class Initialized
DEBUG - 2022-06-28 07:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-28 07:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:26:50 --> Input Class Initialized
INFO - 2022-06-28 07:26:50 --> Input Class Initialized
INFO - 2022-06-28 07:26:50 --> Language Class Initialized
INFO - 2022-06-28 07:26:50 --> Language Class Initialized
ERROR - 2022-06-28 07:26:50 --> 404 Page Not Found: Tokenctrl/localhost
ERROR - 2022-06-28 07:26:50 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-28 07:26:51 --> Config Class Initialized
INFO - 2022-06-28 07:26:51 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:26:51 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:26:51 --> Utf8 Class Initialized
INFO - 2022-06-28 07:26:51 --> URI Class Initialized
INFO - 2022-06-28 07:26:51 --> Router Class Initialized
INFO - 2022-06-28 07:26:51 --> Output Class Initialized
INFO - 2022-06-28 07:26:51 --> Security Class Initialized
DEBUG - 2022-06-28 07:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:26:51 --> Input Class Initialized
INFO - 2022-06-28 07:26:51 --> Language Class Initialized
INFO - 2022-06-28 07:26:51 --> Loader Class Initialized
INFO - 2022-06-28 07:26:51 --> Helper loaded: url_helper
INFO - 2022-06-28 07:26:51 --> Helper loaded: file_helper
INFO - 2022-06-28 07:26:51 --> Database Driver Class Initialized
INFO - 2022-06-28 07:26:51 --> Email Class Initialized
DEBUG - 2022-06-28 07:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 07:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 07:26:51 --> Controller Class Initialized
INFO - 2022-06-28 07:26:51 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 07:26:51 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 07:26:51 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 07:26:51 --> Final output sent to browser
DEBUG - 2022-06-28 07:26:51 --> Total execution time: 0.1225
INFO - 2022-06-28 07:26:51 --> Config Class Initialized
INFO - 2022-06-28 07:26:51 --> Config Class Initialized
INFO - 2022-06-28 07:26:51 --> Hooks Class Initialized
INFO - 2022-06-28 07:26:51 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:26:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-28 07:26:51 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:26:51 --> Utf8 Class Initialized
INFO - 2022-06-28 07:26:51 --> Utf8 Class Initialized
INFO - 2022-06-28 07:26:51 --> URI Class Initialized
INFO - 2022-06-28 07:26:51 --> URI Class Initialized
INFO - 2022-06-28 07:26:51 --> Router Class Initialized
INFO - 2022-06-28 07:26:51 --> Router Class Initialized
INFO - 2022-06-28 07:26:51 --> Output Class Initialized
INFO - 2022-06-28 07:26:51 --> Output Class Initialized
INFO - 2022-06-28 07:26:51 --> Security Class Initialized
INFO - 2022-06-28 07:26:51 --> Security Class Initialized
DEBUG - 2022-06-28 07:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:26:51 --> Input Class Initialized
DEBUG - 2022-06-28 07:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:26:51 --> Language Class Initialized
INFO - 2022-06-28 07:26:51 --> Input Class Initialized
ERROR - 2022-06-28 07:26:51 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-28 07:26:51 --> Language Class Initialized
ERROR - 2022-06-28 07:26:51 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-28 07:26:51 --> Config Class Initialized
INFO - 2022-06-28 07:26:51 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:26:51 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:26:51 --> Utf8 Class Initialized
INFO - 2022-06-28 07:26:51 --> URI Class Initialized
INFO - 2022-06-28 07:26:51 --> Router Class Initialized
INFO - 2022-06-28 07:26:51 --> Output Class Initialized
INFO - 2022-06-28 07:26:51 --> Security Class Initialized
DEBUG - 2022-06-28 07:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:26:51 --> Input Class Initialized
INFO - 2022-06-28 07:26:51 --> Language Class Initialized
INFO - 2022-06-28 07:26:51 --> Loader Class Initialized
INFO - 2022-06-28 07:26:51 --> Helper loaded: url_helper
INFO - 2022-06-28 07:26:51 --> Helper loaded: file_helper
INFO - 2022-06-28 07:26:51 --> Database Driver Class Initialized
INFO - 2022-06-28 07:26:51 --> Email Class Initialized
DEBUG - 2022-06-28 07:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 07:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 07:26:51 --> Controller Class Initialized
INFO - 2022-06-28 07:26:51 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 07:26:51 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 07:26:51 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 07:26:51 --> Final output sent to browser
DEBUG - 2022-06-28 07:26:51 --> Total execution time: 0.1387
INFO - 2022-06-28 07:26:51 --> Config Class Initialized
INFO - 2022-06-28 07:26:51 --> Config Class Initialized
INFO - 2022-06-28 07:26:51 --> Hooks Class Initialized
INFO - 2022-06-28 07:26:51 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:26:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-28 07:26:51 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:26:51 --> Utf8 Class Initialized
INFO - 2022-06-28 07:26:51 --> Utf8 Class Initialized
INFO - 2022-06-28 07:26:51 --> URI Class Initialized
INFO - 2022-06-28 07:26:51 --> URI Class Initialized
INFO - 2022-06-28 07:26:51 --> Router Class Initialized
INFO - 2022-06-28 07:26:51 --> Router Class Initialized
INFO - 2022-06-28 07:26:51 --> Output Class Initialized
INFO - 2022-06-28 07:26:51 --> Output Class Initialized
INFO - 2022-06-28 07:26:51 --> Security Class Initialized
INFO - 2022-06-28 07:26:51 --> Security Class Initialized
DEBUG - 2022-06-28 07:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:26:51 --> Input Class Initialized
INFO - 2022-06-28 07:26:51 --> Language Class Initialized
ERROR - 2022-06-28 07:26:51 --> 404 Page Not Found: Tokenctrl/localhost
DEBUG - 2022-06-28 07:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:26:51 --> Input Class Initialized
INFO - 2022-06-28 07:26:51 --> Language Class Initialized
ERROR - 2022-06-28 07:26:51 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-28 07:26:52 --> Config Class Initialized
INFO - 2022-06-28 07:26:52 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:26:52 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:26:52 --> Utf8 Class Initialized
INFO - 2022-06-28 07:26:52 --> URI Class Initialized
INFO - 2022-06-28 07:26:52 --> Router Class Initialized
INFO - 2022-06-28 07:26:52 --> Output Class Initialized
INFO - 2022-06-28 07:26:52 --> Security Class Initialized
DEBUG - 2022-06-28 07:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:26:52 --> Input Class Initialized
INFO - 2022-06-28 07:26:52 --> Language Class Initialized
INFO - 2022-06-28 07:26:52 --> Loader Class Initialized
INFO - 2022-06-28 07:26:52 --> Helper loaded: url_helper
INFO - 2022-06-28 07:26:52 --> Helper loaded: file_helper
INFO - 2022-06-28 07:26:52 --> Database Driver Class Initialized
INFO - 2022-06-28 07:26:52 --> Email Class Initialized
DEBUG - 2022-06-28 07:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 07:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 07:26:52 --> Controller Class Initialized
INFO - 2022-06-28 07:26:52 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 07:26:52 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 07:26:52 --> Final output sent to browser
DEBUG - 2022-06-28 07:26:52 --> Total execution time: 0.1596
INFO - 2022-06-28 07:26:53 --> Config Class Initialized
INFO - 2022-06-28 07:26:53 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:26:53 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:26:53 --> Utf8 Class Initialized
INFO - 2022-06-28 07:26:53 --> URI Class Initialized
INFO - 2022-06-28 07:26:53 --> Router Class Initialized
INFO - 2022-06-28 07:26:53 --> Output Class Initialized
INFO - 2022-06-28 07:26:53 --> Security Class Initialized
DEBUG - 2022-06-28 07:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:26:53 --> Input Class Initialized
INFO - 2022-06-28 07:26:53 --> Language Class Initialized
INFO - 2022-06-28 07:26:53 --> Loader Class Initialized
INFO - 2022-06-28 07:26:53 --> Helper loaded: url_helper
INFO - 2022-06-28 07:26:53 --> Helper loaded: file_helper
INFO - 2022-06-28 07:26:53 --> Database Driver Class Initialized
INFO - 2022-06-28 07:26:54 --> Email Class Initialized
DEBUG - 2022-06-28 07:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 07:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 07:26:54 --> Controller Class Initialized
INFO - 2022-06-28 07:26:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 07:26:54 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 07:26:54 --> Final output sent to browser
DEBUG - 2022-06-28 07:26:54 --> Total execution time: 0.2331
INFO - 2022-06-28 07:26:54 --> Config Class Initialized
INFO - 2022-06-28 07:26:54 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:26:54 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:26:54 --> Utf8 Class Initialized
INFO - 2022-06-28 07:26:54 --> URI Class Initialized
INFO - 2022-06-28 07:26:54 --> Router Class Initialized
INFO - 2022-06-28 07:26:54 --> Output Class Initialized
INFO - 2022-06-28 07:26:54 --> Security Class Initialized
DEBUG - 2022-06-28 07:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:26:54 --> Input Class Initialized
INFO - 2022-06-28 07:26:54 --> Language Class Initialized
INFO - 2022-06-28 07:26:54 --> Loader Class Initialized
INFO - 2022-06-28 07:26:54 --> Helper loaded: url_helper
INFO - 2022-06-28 07:26:54 --> Helper loaded: file_helper
INFO - 2022-06-28 07:26:54 --> Database Driver Class Initialized
INFO - 2022-06-28 07:26:54 --> Email Class Initialized
DEBUG - 2022-06-28 07:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 07:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 07:26:54 --> Controller Class Initialized
INFO - 2022-06-28 07:26:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 07:26:54 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 07:26:54 --> Final output sent to browser
DEBUG - 2022-06-28 07:26:54 --> Total execution time: 0.0416
INFO - 2022-06-28 07:26:55 --> Config Class Initialized
INFO - 2022-06-28 07:26:55 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:26:55 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:26:55 --> Utf8 Class Initialized
INFO - 2022-06-28 07:26:55 --> URI Class Initialized
INFO - 2022-06-28 07:26:55 --> Router Class Initialized
INFO - 2022-06-28 07:26:55 --> Output Class Initialized
INFO - 2022-06-28 07:26:55 --> Security Class Initialized
DEBUG - 2022-06-28 07:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:26:55 --> Input Class Initialized
INFO - 2022-06-28 07:26:55 --> Language Class Initialized
INFO - 2022-06-28 07:26:55 --> Loader Class Initialized
INFO - 2022-06-28 07:26:55 --> Helper loaded: url_helper
INFO - 2022-06-28 07:26:55 --> Helper loaded: file_helper
INFO - 2022-06-28 07:26:55 --> Database Driver Class Initialized
INFO - 2022-06-28 07:26:55 --> Email Class Initialized
DEBUG - 2022-06-28 07:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 07:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 07:26:55 --> Controller Class Initialized
INFO - 2022-06-28 07:26:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 07:26:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 07:26:55 --> Final output sent to browser
DEBUG - 2022-06-28 07:26:55 --> Total execution time: 0.1281
INFO - 2022-06-28 07:26:55 --> Config Class Initialized
INFO - 2022-06-28 07:26:55 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:26:55 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:26:55 --> Utf8 Class Initialized
INFO - 2022-06-28 07:26:55 --> URI Class Initialized
INFO - 2022-06-28 07:26:55 --> Router Class Initialized
INFO - 2022-06-28 07:26:55 --> Output Class Initialized
INFO - 2022-06-28 07:26:55 --> Security Class Initialized
DEBUG - 2022-06-28 07:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:26:55 --> Input Class Initialized
INFO - 2022-06-28 07:26:55 --> Language Class Initialized
INFO - 2022-06-28 07:26:55 --> Loader Class Initialized
INFO - 2022-06-28 07:26:55 --> Helper loaded: url_helper
INFO - 2022-06-28 07:26:55 --> Helper loaded: file_helper
INFO - 2022-06-28 07:26:55 --> Database Driver Class Initialized
INFO - 2022-06-28 07:26:55 --> Email Class Initialized
DEBUG - 2022-06-28 07:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 07:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 07:26:55 --> Controller Class Initialized
INFO - 2022-06-28 07:26:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 07:26:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 07:26:55 --> Final output sent to browser
DEBUG - 2022-06-28 07:26:55 --> Total execution time: 0.1463
INFO - 2022-06-28 07:26:56 --> Config Class Initialized
INFO - 2022-06-28 07:26:56 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:26:56 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:26:56 --> Utf8 Class Initialized
INFO - 2022-06-28 07:26:56 --> URI Class Initialized
INFO - 2022-06-28 07:26:56 --> Router Class Initialized
INFO - 2022-06-28 07:26:56 --> Output Class Initialized
INFO - 2022-06-28 07:26:56 --> Security Class Initialized
DEBUG - 2022-06-28 07:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:26:56 --> Input Class Initialized
INFO - 2022-06-28 07:26:56 --> Language Class Initialized
INFO - 2022-06-28 07:26:56 --> Loader Class Initialized
INFO - 2022-06-28 07:26:56 --> Helper loaded: url_helper
INFO - 2022-06-28 07:26:56 --> Helper loaded: file_helper
INFO - 2022-06-28 07:26:56 --> Database Driver Class Initialized
INFO - 2022-06-28 07:26:56 --> Email Class Initialized
DEBUG - 2022-06-28 07:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 07:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 07:26:56 --> Controller Class Initialized
INFO - 2022-06-28 07:26:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 07:26:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 07:26:56 --> Final output sent to browser
DEBUG - 2022-06-28 07:26:56 --> Total execution time: 0.1191
INFO - 2022-06-28 07:26:57 --> Config Class Initialized
INFO - 2022-06-28 07:26:57 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:26:57 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:26:57 --> Utf8 Class Initialized
INFO - 2022-06-28 07:26:57 --> URI Class Initialized
INFO - 2022-06-28 07:26:57 --> Router Class Initialized
INFO - 2022-06-28 07:26:57 --> Output Class Initialized
INFO - 2022-06-28 07:26:57 --> Security Class Initialized
DEBUG - 2022-06-28 07:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:26:57 --> Input Class Initialized
INFO - 2022-06-28 07:26:57 --> Language Class Initialized
INFO - 2022-06-28 07:26:57 --> Loader Class Initialized
INFO - 2022-06-28 07:26:57 --> Helper loaded: url_helper
INFO - 2022-06-28 07:26:57 --> Helper loaded: file_helper
INFO - 2022-06-28 07:26:57 --> Database Driver Class Initialized
INFO - 2022-06-28 07:26:57 --> Email Class Initialized
DEBUG - 2022-06-28 07:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 07:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 07:26:57 --> Controller Class Initialized
INFO - 2022-06-28 07:26:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 07:26:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 07:26:57 --> Final output sent to browser
DEBUG - 2022-06-28 07:26:57 --> Total execution time: 0.0283
INFO - 2022-06-28 07:26:57 --> Config Class Initialized
INFO - 2022-06-28 07:26:57 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:26:57 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:26:57 --> Utf8 Class Initialized
INFO - 2022-06-28 07:26:57 --> URI Class Initialized
INFO - 2022-06-28 07:26:57 --> Router Class Initialized
INFO - 2022-06-28 07:26:57 --> Output Class Initialized
INFO - 2022-06-28 07:26:57 --> Security Class Initialized
DEBUG - 2022-06-28 07:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:26:57 --> Input Class Initialized
INFO - 2022-06-28 07:26:57 --> Language Class Initialized
INFO - 2022-06-28 07:26:57 --> Loader Class Initialized
INFO - 2022-06-28 07:26:57 --> Helper loaded: url_helper
INFO - 2022-06-28 07:26:57 --> Helper loaded: file_helper
INFO - 2022-06-28 07:26:57 --> Database Driver Class Initialized
INFO - 2022-06-28 07:26:57 --> Email Class Initialized
DEBUG - 2022-06-28 07:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 07:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 07:26:57 --> Controller Class Initialized
INFO - 2022-06-28 07:26:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 07:26:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 07:26:57 --> Final output sent to browser
DEBUG - 2022-06-28 07:26:57 --> Total execution time: 0.0161
INFO - 2022-06-28 07:26:59 --> Config Class Initialized
INFO - 2022-06-28 07:26:59 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:26:59 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:26:59 --> Utf8 Class Initialized
INFO - 2022-06-28 07:26:59 --> URI Class Initialized
INFO - 2022-06-28 07:26:59 --> Router Class Initialized
INFO - 2022-06-28 07:26:59 --> Output Class Initialized
INFO - 2022-06-28 07:26:59 --> Security Class Initialized
DEBUG - 2022-06-28 07:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:26:59 --> Input Class Initialized
INFO - 2022-06-28 07:26:59 --> Language Class Initialized
INFO - 2022-06-28 07:26:59 --> Loader Class Initialized
INFO - 2022-06-28 07:26:59 --> Helper loaded: url_helper
INFO - 2022-06-28 07:26:59 --> Helper loaded: file_helper
INFO - 2022-06-28 07:26:59 --> Database Driver Class Initialized
INFO - 2022-06-28 07:26:59 --> Email Class Initialized
DEBUG - 2022-06-28 07:26:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 07:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 07:26:59 --> Controller Class Initialized
INFO - 2022-06-28 07:26:59 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 07:26:59 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 07:26:59 --> Final output sent to browser
DEBUG - 2022-06-28 07:26:59 --> Total execution time: 0.0276
INFO - 2022-06-28 07:27:08 --> Config Class Initialized
INFO - 2022-06-28 07:27:08 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:27:08 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:27:08 --> Utf8 Class Initialized
INFO - 2022-06-28 07:27:08 --> URI Class Initialized
INFO - 2022-06-28 07:27:08 --> Router Class Initialized
INFO - 2022-06-28 07:27:08 --> Output Class Initialized
INFO - 2022-06-28 07:27:08 --> Security Class Initialized
DEBUG - 2022-06-28 07:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:27:08 --> Input Class Initialized
INFO - 2022-06-28 07:27:08 --> Language Class Initialized
INFO - 2022-06-28 07:27:08 --> Loader Class Initialized
INFO - 2022-06-28 07:27:08 --> Helper loaded: url_helper
INFO - 2022-06-28 07:27:08 --> Helper loaded: file_helper
INFO - 2022-06-28 07:27:08 --> Database Driver Class Initialized
INFO - 2022-06-28 07:27:08 --> Email Class Initialized
DEBUG - 2022-06-28 07:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 07:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 07:27:08 --> Controller Class Initialized
INFO - 2022-06-28 07:27:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 07:27:08 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 07:27:08 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 07:27:08 --> Final output sent to browser
DEBUG - 2022-06-28 07:27:08 --> Total execution time: 0.0183
INFO - 2022-06-28 07:27:38 --> Config Class Initialized
INFO - 2022-06-28 07:27:38 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:27:38 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:27:38 --> Utf8 Class Initialized
INFO - 2022-06-28 07:27:38 --> URI Class Initialized
INFO - 2022-06-28 07:27:38 --> Router Class Initialized
INFO - 2022-06-28 07:27:38 --> Output Class Initialized
INFO - 2022-06-28 07:27:38 --> Security Class Initialized
DEBUG - 2022-06-28 07:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:27:38 --> Input Class Initialized
INFO - 2022-06-28 07:27:38 --> Language Class Initialized
INFO - 2022-06-28 07:27:38 --> Loader Class Initialized
INFO - 2022-06-28 07:27:38 --> Helper loaded: url_helper
INFO - 2022-06-28 07:27:38 --> Helper loaded: file_helper
INFO - 2022-06-28 07:27:38 --> Database Driver Class Initialized
INFO - 2022-06-28 07:27:39 --> Email Class Initialized
DEBUG - 2022-06-28 07:27:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 07:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 07:27:39 --> Controller Class Initialized
INFO - 2022-06-28 07:27:39 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 07:27:39 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 07:27:39 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 07:27:39 --> Final output sent to browser
DEBUG - 2022-06-28 07:27:39 --> Total execution time: 0.1284
INFO - 2022-06-28 07:27:39 --> Config Class Initialized
INFO - 2022-06-28 07:27:39 --> Config Class Initialized
INFO - 2022-06-28 07:27:39 --> Hooks Class Initialized
INFO - 2022-06-28 07:27:39 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:27:39 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:27:39 --> Utf8 Class Initialized
DEBUG - 2022-06-28 07:27:39 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:27:39 --> Utf8 Class Initialized
INFO - 2022-06-28 07:27:39 --> URI Class Initialized
INFO - 2022-06-28 07:27:39 --> URI Class Initialized
INFO - 2022-06-28 07:27:39 --> Router Class Initialized
INFO - 2022-06-28 07:27:39 --> Output Class Initialized
INFO - 2022-06-28 07:27:39 --> Router Class Initialized
INFO - 2022-06-28 07:27:39 --> Security Class Initialized
INFO - 2022-06-28 07:27:39 --> Output Class Initialized
DEBUG - 2022-06-28 07:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:27:39 --> Input Class Initialized
INFO - 2022-06-28 07:27:39 --> Security Class Initialized
INFO - 2022-06-28 07:27:39 --> Language Class Initialized
DEBUG - 2022-06-28 07:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:27:39 --> Input Class Initialized
ERROR - 2022-06-28 07:27:39 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-28 07:27:39 --> Language Class Initialized
ERROR - 2022-06-28 07:27:39 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-28 07:27:55 --> Config Class Initialized
INFO - 2022-06-28 07:27:55 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:27:55 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:27:55 --> Utf8 Class Initialized
INFO - 2022-06-28 07:27:55 --> URI Class Initialized
INFO - 2022-06-28 07:27:55 --> Router Class Initialized
INFO - 2022-06-28 07:27:55 --> Output Class Initialized
INFO - 2022-06-28 07:27:55 --> Security Class Initialized
DEBUG - 2022-06-28 07:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:27:55 --> Input Class Initialized
INFO - 2022-06-28 07:27:55 --> Language Class Initialized
INFO - 2022-06-28 07:27:55 --> Loader Class Initialized
INFO - 2022-06-28 07:27:55 --> Helper loaded: url_helper
INFO - 2022-06-28 07:27:55 --> Helper loaded: file_helper
INFO - 2022-06-28 07:27:55 --> Database Driver Class Initialized
INFO - 2022-06-28 07:27:55 --> Email Class Initialized
DEBUG - 2022-06-28 07:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 07:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 07:27:55 --> Controller Class Initialized
INFO - 2022-06-28 07:27:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 07:27:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 07:27:55 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 07:27:55 --> Final output sent to browser
DEBUG - 2022-06-28 07:27:55 --> Total execution time: 0.1170
INFO - 2022-06-28 07:32:02 --> Config Class Initialized
INFO - 2022-06-28 07:32:02 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:32:02 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:32:02 --> Utf8 Class Initialized
INFO - 2022-06-28 07:32:02 --> URI Class Initialized
INFO - 2022-06-28 07:32:02 --> Router Class Initialized
INFO - 2022-06-28 07:32:02 --> Output Class Initialized
INFO - 2022-06-28 07:32:02 --> Security Class Initialized
DEBUG - 2022-06-28 07:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:32:02 --> Input Class Initialized
INFO - 2022-06-28 07:32:02 --> Language Class Initialized
INFO - 2022-06-28 07:32:02 --> Loader Class Initialized
INFO - 2022-06-28 07:32:02 --> Helper loaded: url_helper
INFO - 2022-06-28 07:32:02 --> Helper loaded: file_helper
INFO - 2022-06-28 07:32:02 --> Database Driver Class Initialized
INFO - 2022-06-28 07:32:02 --> Email Class Initialized
DEBUG - 2022-06-28 07:32:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 07:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 07:32:02 --> Controller Class Initialized
INFO - 2022-06-28 07:32:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 07:32:02 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 07:32:02 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 07:32:02 --> Final output sent to browser
DEBUG - 2022-06-28 07:32:02 --> Total execution time: 0.0218
INFO - 2022-06-28 07:32:19 --> Config Class Initialized
INFO - 2022-06-28 07:32:19 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:32:19 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:32:19 --> Utf8 Class Initialized
INFO - 2022-06-28 07:32:19 --> URI Class Initialized
INFO - 2022-06-28 07:32:19 --> Router Class Initialized
INFO - 2022-06-28 07:32:19 --> Output Class Initialized
INFO - 2022-06-28 07:32:19 --> Security Class Initialized
DEBUG - 2022-06-28 07:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:32:19 --> Input Class Initialized
INFO - 2022-06-28 07:32:19 --> Language Class Initialized
ERROR - 2022-06-28 07:32:19 --> 404 Page Not Found: Tokenctrl/Tokenctrl
INFO - 2022-06-28 07:32:39 --> Config Class Initialized
INFO - 2022-06-28 07:32:39 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:32:39 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:32:39 --> Utf8 Class Initialized
INFO - 2022-06-28 07:32:39 --> URI Class Initialized
INFO - 2022-06-28 07:32:39 --> Router Class Initialized
INFO - 2022-06-28 07:32:39 --> Output Class Initialized
INFO - 2022-06-28 07:32:39 --> Security Class Initialized
DEBUG - 2022-06-28 07:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:32:39 --> Input Class Initialized
INFO - 2022-06-28 07:32:39 --> Language Class Initialized
INFO - 2022-06-28 07:32:39 --> Loader Class Initialized
INFO - 2022-06-28 07:32:39 --> Helper loaded: url_helper
INFO - 2022-06-28 07:32:39 --> Helper loaded: file_helper
INFO - 2022-06-28 07:32:39 --> Database Driver Class Initialized
INFO - 2022-06-28 07:32:39 --> Email Class Initialized
DEBUG - 2022-06-28 07:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 07:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 07:32:39 --> Controller Class Initialized
INFO - 2022-06-28 07:32:39 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 07:32:39 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 07:32:39 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 07:32:39 --> Final output sent to browser
DEBUG - 2022-06-28 07:32:39 --> Total execution time: 0.1436
INFO - 2022-06-28 07:32:40 --> Config Class Initialized
INFO - 2022-06-28 07:32:40 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:32:40 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:32:40 --> Utf8 Class Initialized
INFO - 2022-06-28 07:32:40 --> URI Class Initialized
INFO - 2022-06-28 07:32:40 --> Router Class Initialized
INFO - 2022-06-28 07:32:40 --> Output Class Initialized
INFO - 2022-06-28 07:32:40 --> Security Class Initialized
DEBUG - 2022-06-28 07:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:32:40 --> Input Class Initialized
INFO - 2022-06-28 07:32:40 --> Language Class Initialized
INFO - 2022-06-28 07:32:40 --> Loader Class Initialized
INFO - 2022-06-28 07:32:40 --> Helper loaded: url_helper
INFO - 2022-06-28 07:32:40 --> Helper loaded: file_helper
INFO - 2022-06-28 07:32:40 --> Database Driver Class Initialized
INFO - 2022-06-28 07:32:41 --> Email Class Initialized
DEBUG - 2022-06-28 07:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 07:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 07:32:41 --> Controller Class Initialized
INFO - 2022-06-28 07:32:41 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 07:32:41 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 07:32:41 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 07:32:41 --> Final output sent to browser
DEBUG - 2022-06-28 07:32:41 --> Total execution time: 0.1315
INFO - 2022-06-28 07:32:44 --> Config Class Initialized
INFO - 2022-06-28 07:32:44 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:32:44 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:32:44 --> Utf8 Class Initialized
INFO - 2022-06-28 07:32:44 --> URI Class Initialized
INFO - 2022-06-28 07:32:44 --> Router Class Initialized
INFO - 2022-06-28 07:32:44 --> Output Class Initialized
INFO - 2022-06-28 07:32:44 --> Security Class Initialized
DEBUG - 2022-06-28 07:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:32:44 --> Input Class Initialized
INFO - 2022-06-28 07:32:44 --> Language Class Initialized
INFO - 2022-06-28 07:32:44 --> Loader Class Initialized
INFO - 2022-06-28 07:32:44 --> Helper loaded: url_helper
INFO - 2022-06-28 07:32:44 --> Helper loaded: file_helper
INFO - 2022-06-28 07:32:44 --> Database Driver Class Initialized
INFO - 2022-06-28 07:32:44 --> Email Class Initialized
DEBUG - 2022-06-28 07:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 07:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 07:32:44 --> Controller Class Initialized
INFO - 2022-06-28 07:32:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 07:32:44 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 07:32:44 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 07:32:44 --> Final output sent to browser
DEBUG - 2022-06-28 07:32:44 --> Total execution time: 0.1150
INFO - 2022-06-28 07:32:44 --> Config Class Initialized
INFO - 2022-06-28 07:32:44 --> Hooks Class Initialized
INFO - 2022-06-28 07:32:44 --> Config Class Initialized
INFO - 2022-06-28 07:32:44 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:32:44 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:32:44 --> Utf8 Class Initialized
DEBUG - 2022-06-28 07:32:44 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:32:44 --> Utf8 Class Initialized
INFO - 2022-06-28 07:32:44 --> URI Class Initialized
INFO - 2022-06-28 07:32:44 --> URI Class Initialized
INFO - 2022-06-28 07:32:44 --> Router Class Initialized
INFO - 2022-06-28 07:32:44 --> Router Class Initialized
INFO - 2022-06-28 07:32:44 --> Output Class Initialized
INFO - 2022-06-28 07:32:44 --> Output Class Initialized
INFO - 2022-06-28 07:32:44 --> Security Class Initialized
DEBUG - 2022-06-28 07:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:32:44 --> Security Class Initialized
INFO - 2022-06-28 07:32:44 --> Input Class Initialized
DEBUG - 2022-06-28 07:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:32:44 --> Input Class Initialized
INFO - 2022-06-28 07:32:44 --> Language Class Initialized
INFO - 2022-06-28 07:32:44 --> Language Class Initialized
ERROR - 2022-06-28 07:32:44 --> 404 Page Not Found: Tokenctrl/localhost
ERROR - 2022-06-28 07:32:44 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-28 07:33:17 --> Config Class Initialized
INFO - 2022-06-28 07:33:17 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:33:17 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:33:17 --> Utf8 Class Initialized
INFO - 2022-06-28 07:33:17 --> URI Class Initialized
INFO - 2022-06-28 07:33:17 --> Router Class Initialized
INFO - 2022-06-28 07:33:17 --> Output Class Initialized
INFO - 2022-06-28 07:33:17 --> Security Class Initialized
DEBUG - 2022-06-28 07:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:33:17 --> Input Class Initialized
INFO - 2022-06-28 07:33:17 --> Language Class Initialized
ERROR - 2022-06-28 07:33:17 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-28 07:34:38 --> Config Class Initialized
INFO - 2022-06-28 07:34:38 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:34:38 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:34:38 --> Utf8 Class Initialized
INFO - 2022-06-28 07:34:38 --> URI Class Initialized
INFO - 2022-06-28 07:34:38 --> Router Class Initialized
INFO - 2022-06-28 07:34:38 --> Output Class Initialized
INFO - 2022-06-28 07:34:38 --> Security Class Initialized
DEBUG - 2022-06-28 07:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:34:38 --> Input Class Initialized
INFO - 2022-06-28 07:34:38 --> Language Class Initialized
INFO - 2022-06-28 07:34:38 --> Loader Class Initialized
INFO - 2022-06-28 07:34:38 --> Helper loaded: url_helper
INFO - 2022-06-28 07:34:38 --> Helper loaded: file_helper
INFO - 2022-06-28 07:34:38 --> Database Driver Class Initialized
INFO - 2022-06-28 07:34:39 --> Email Class Initialized
DEBUG - 2022-06-28 07:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 07:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 07:34:39 --> Controller Class Initialized
INFO - 2022-06-28 07:34:39 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 07:34:39 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 07:34:39 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 07:34:39 --> Final output sent to browser
DEBUG - 2022-06-28 07:34:39 --> Total execution time: 0.1724
INFO - 2022-06-28 07:34:39 --> Config Class Initialized
INFO - 2022-06-28 07:34:39 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:34:39 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:34:39 --> Utf8 Class Initialized
INFO - 2022-06-28 07:34:39 --> URI Class Initialized
INFO - 2022-06-28 07:34:39 --> Router Class Initialized
INFO - 2022-06-28 07:34:39 --> Output Class Initialized
INFO - 2022-06-28 07:34:39 --> Security Class Initialized
DEBUG - 2022-06-28 07:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:34:39 --> Input Class Initialized
INFO - 2022-06-28 07:34:39 --> Language Class Initialized
ERROR - 2022-06-28 07:34:39 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-28 07:34:39 --> Config Class Initialized
INFO - 2022-06-28 07:34:39 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:34:39 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:34:39 --> Utf8 Class Initialized
INFO - 2022-06-28 07:34:39 --> URI Class Initialized
INFO - 2022-06-28 07:34:39 --> Router Class Initialized
INFO - 2022-06-28 07:34:39 --> Output Class Initialized
INFO - 2022-06-28 07:34:39 --> Security Class Initialized
DEBUG - 2022-06-28 07:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:34:39 --> Input Class Initialized
INFO - 2022-06-28 07:34:39 --> Language Class Initialized
ERROR - 2022-06-28 07:34:39 --> 404 Page Not Found: Tokenctrl/static
INFO - 2022-06-28 07:34:44 --> Config Class Initialized
INFO - 2022-06-28 07:34:44 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:34:44 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:34:44 --> Utf8 Class Initialized
INFO - 2022-06-28 07:34:44 --> URI Class Initialized
INFO - 2022-06-28 07:34:44 --> Router Class Initialized
INFO - 2022-06-28 07:34:44 --> Output Class Initialized
INFO - 2022-06-28 07:34:44 --> Security Class Initialized
DEBUG - 2022-06-28 07:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:34:44 --> Input Class Initialized
INFO - 2022-06-28 07:34:44 --> Language Class Initialized
INFO - 2022-06-28 07:34:44 --> Loader Class Initialized
INFO - 2022-06-28 07:34:44 --> Helper loaded: url_helper
INFO - 2022-06-28 07:34:44 --> Helper loaded: file_helper
INFO - 2022-06-28 07:34:44 --> Database Driver Class Initialized
INFO - 2022-06-28 07:34:44 --> Email Class Initialized
DEBUG - 2022-06-28 07:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 07:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 07:34:44 --> Controller Class Initialized
INFO - 2022-06-28 07:34:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 07:34:44 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 07:34:44 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 07:34:44 --> Final output sent to browser
DEBUG - 2022-06-28 07:34:44 --> Total execution time: 0.1828
INFO - 2022-06-28 07:34:44 --> Config Class Initialized
INFO - 2022-06-28 07:34:44 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:34:44 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:34:44 --> Utf8 Class Initialized
INFO - 2022-06-28 07:34:44 --> URI Class Initialized
INFO - 2022-06-28 07:34:44 --> Router Class Initialized
INFO - 2022-06-28 07:34:44 --> Output Class Initialized
INFO - 2022-06-28 07:34:44 --> Security Class Initialized
DEBUG - 2022-06-28 07:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:34:44 --> Input Class Initialized
INFO - 2022-06-28 07:34:44 --> Language Class Initialized
ERROR - 2022-06-28 07:34:44 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-28 07:34:44 --> Config Class Initialized
INFO - 2022-06-28 07:34:44 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:34:44 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:34:44 --> Utf8 Class Initialized
INFO - 2022-06-28 07:34:44 --> URI Class Initialized
INFO - 2022-06-28 07:34:44 --> Router Class Initialized
INFO - 2022-06-28 07:34:44 --> Output Class Initialized
INFO - 2022-06-28 07:34:44 --> Security Class Initialized
DEBUG - 2022-06-28 07:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:34:44 --> Input Class Initialized
INFO - 2022-06-28 07:34:44 --> Language Class Initialized
ERROR - 2022-06-28 07:34:44 --> 404 Page Not Found: Tokenctrl/static
INFO - 2022-06-28 07:35:03 --> Config Class Initialized
INFO - 2022-06-28 07:35:03 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:35:03 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:35:03 --> Utf8 Class Initialized
INFO - 2022-06-28 07:35:03 --> URI Class Initialized
INFO - 2022-06-28 07:35:03 --> Router Class Initialized
INFO - 2022-06-28 07:35:03 --> Output Class Initialized
INFO - 2022-06-28 07:35:03 --> Security Class Initialized
DEBUG - 2022-06-28 07:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:35:03 --> Input Class Initialized
INFO - 2022-06-28 07:35:03 --> Language Class Initialized
ERROR - 2022-06-28 07:35:03 --> 404 Page Not Found: Tokenctrl/static
INFO - 2022-06-28 07:39:31 --> Config Class Initialized
INFO - 2022-06-28 07:39:31 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:39:31 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:39:31 --> Utf8 Class Initialized
INFO - 2022-06-28 07:39:31 --> URI Class Initialized
INFO - 2022-06-28 07:39:31 --> Router Class Initialized
INFO - 2022-06-28 07:39:31 --> Output Class Initialized
INFO - 2022-06-28 07:39:31 --> Security Class Initialized
DEBUG - 2022-06-28 07:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:39:31 --> Input Class Initialized
INFO - 2022-06-28 07:39:31 --> Language Class Initialized
INFO - 2022-06-28 07:39:31 --> Loader Class Initialized
INFO - 2022-06-28 07:39:31 --> Helper loaded: url_helper
INFO - 2022-06-28 07:39:31 --> Helper loaded: file_helper
INFO - 2022-06-28 07:39:31 --> Database Driver Class Initialized
INFO - 2022-06-28 07:39:31 --> Email Class Initialized
DEBUG - 2022-06-28 07:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 07:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 07:39:31 --> Controller Class Initialized
INFO - 2022-06-28 07:39:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 07:39:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 07:39:31 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 07:39:31 --> Final output sent to browser
DEBUG - 2022-06-28 07:39:31 --> Total execution time: 0.0937
INFO - 2022-06-28 07:39:31 --> Config Class Initialized
INFO - 2022-06-28 07:39:31 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:39:31 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:39:31 --> Utf8 Class Initialized
INFO - 2022-06-28 07:39:31 --> URI Class Initialized
INFO - 2022-06-28 07:39:31 --> Router Class Initialized
INFO - 2022-06-28 07:39:31 --> Output Class Initialized
INFO - 2022-06-28 07:39:31 --> Security Class Initialized
DEBUG - 2022-06-28 07:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:39:31 --> Input Class Initialized
INFO - 2022-06-28 07:39:31 --> Language Class Initialized
ERROR - 2022-06-28 07:39:31 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-28 07:39:31 --> Config Class Initialized
INFO - 2022-06-28 07:39:31 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:39:31 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:39:31 --> Utf8 Class Initialized
INFO - 2022-06-28 07:39:31 --> URI Class Initialized
INFO - 2022-06-28 07:39:31 --> Router Class Initialized
INFO - 2022-06-28 07:39:31 --> Output Class Initialized
INFO - 2022-06-28 07:39:31 --> Security Class Initialized
DEBUG - 2022-06-28 07:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:39:31 --> Input Class Initialized
INFO - 2022-06-28 07:39:31 --> Language Class Initialized
ERROR - 2022-06-28 07:39:31 --> 404 Page Not Found: Tokenctrl/static
INFO - 2022-06-28 07:39:37 --> Config Class Initialized
INFO - 2022-06-28 07:39:37 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:39:37 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:39:37 --> Utf8 Class Initialized
INFO - 2022-06-28 07:39:37 --> URI Class Initialized
INFO - 2022-06-28 07:39:37 --> Router Class Initialized
INFO - 2022-06-28 07:39:37 --> Output Class Initialized
INFO - 2022-06-28 07:39:37 --> Security Class Initialized
DEBUG - 2022-06-28 07:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:39:37 --> Input Class Initialized
INFO - 2022-06-28 07:39:37 --> Language Class Initialized
INFO - 2022-06-28 07:39:37 --> Loader Class Initialized
INFO - 2022-06-28 07:39:37 --> Helper loaded: url_helper
INFO - 2022-06-28 07:39:37 --> Helper loaded: file_helper
INFO - 2022-06-28 07:39:37 --> Database Driver Class Initialized
INFO - 2022-06-28 07:39:37 --> Email Class Initialized
DEBUG - 2022-06-28 07:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 07:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 07:39:37 --> Controller Class Initialized
INFO - 2022-06-28 07:39:37 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 07:39:37 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 07:39:37 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 07:39:37 --> Final output sent to browser
DEBUG - 2022-06-28 07:39:37 --> Total execution time: 0.1520
INFO - 2022-06-28 07:39:37 --> Config Class Initialized
INFO - 2022-06-28 07:39:37 --> Config Class Initialized
INFO - 2022-06-28 07:39:37 --> Hooks Class Initialized
INFO - 2022-06-28 07:39:37 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:39:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-28 07:39:37 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:39:37 --> Utf8 Class Initialized
INFO - 2022-06-28 07:39:37 --> Utf8 Class Initialized
INFO - 2022-06-28 07:39:37 --> URI Class Initialized
INFO - 2022-06-28 07:39:37 --> URI Class Initialized
INFO - 2022-06-28 07:39:37 --> Router Class Initialized
INFO - 2022-06-28 07:39:37 --> Router Class Initialized
INFO - 2022-06-28 07:39:37 --> Output Class Initialized
INFO - 2022-06-28 07:39:37 --> Security Class Initialized
INFO - 2022-06-28 07:39:37 --> Output Class Initialized
INFO - 2022-06-28 07:39:37 --> Security Class Initialized
DEBUG - 2022-06-28 07:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:39:37 --> Input Class Initialized
DEBUG - 2022-06-28 07:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:39:37 --> Input Class Initialized
INFO - 2022-06-28 07:39:37 --> Language Class Initialized
INFO - 2022-06-28 07:39:37 --> Language Class Initialized
ERROR - 2022-06-28 07:39:37 --> 404 Page Not Found: Tokenctrl/static
ERROR - 2022-06-28 07:39:37 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-28 07:39:44 --> Config Class Initialized
INFO - 2022-06-28 07:39:44 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:39:44 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:39:44 --> Utf8 Class Initialized
INFO - 2022-06-28 07:39:44 --> URI Class Initialized
INFO - 2022-06-28 07:39:44 --> Router Class Initialized
INFO - 2022-06-28 07:39:44 --> Output Class Initialized
INFO - 2022-06-28 07:39:44 --> Security Class Initialized
DEBUG - 2022-06-28 07:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:39:44 --> Input Class Initialized
INFO - 2022-06-28 07:39:44 --> Language Class Initialized
INFO - 2022-06-28 07:39:44 --> Loader Class Initialized
INFO - 2022-06-28 07:39:44 --> Helper loaded: url_helper
INFO - 2022-06-28 07:39:44 --> Helper loaded: file_helper
INFO - 2022-06-28 07:39:44 --> Database Driver Class Initialized
INFO - 2022-06-28 07:39:44 --> Email Class Initialized
DEBUG - 2022-06-28 07:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 07:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 07:39:44 --> Controller Class Initialized
INFO - 2022-06-28 07:39:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 07:39:44 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 07:39:45 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 07:39:45 --> Final output sent to browser
DEBUG - 2022-06-28 07:39:45 --> Total execution time: 0.0277
INFO - 2022-06-28 07:39:45 --> Config Class Initialized
INFO - 2022-06-28 07:39:45 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:39:45 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:39:45 --> Utf8 Class Initialized
INFO - 2022-06-28 07:39:45 --> URI Class Initialized
INFO - 2022-06-28 07:39:45 --> Config Class Initialized
INFO - 2022-06-28 07:39:45 --> Hooks Class Initialized
INFO - 2022-06-28 07:39:45 --> Router Class Initialized
DEBUG - 2022-06-28 07:39:45 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:39:45 --> Output Class Initialized
INFO - 2022-06-28 07:39:45 --> Utf8 Class Initialized
INFO - 2022-06-28 07:39:45 --> Security Class Initialized
INFO - 2022-06-28 07:39:45 --> URI Class Initialized
DEBUG - 2022-06-28 07:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:39:45 --> Input Class Initialized
INFO - 2022-06-28 07:39:45 --> Router Class Initialized
INFO - 2022-06-28 07:39:45 --> Language Class Initialized
INFO - 2022-06-28 07:39:45 --> Output Class Initialized
INFO - 2022-06-28 07:39:45 --> Security Class Initialized
ERROR - 2022-06-28 07:39:45 --> 404 Page Not Found: Tokenctrl/localhost
DEBUG - 2022-06-28 07:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:39:45 --> Input Class Initialized
INFO - 2022-06-28 07:39:45 --> Language Class Initialized
ERROR - 2022-06-28 07:39:45 --> 404 Page Not Found: Tokenctrl/static
INFO - 2022-06-28 07:40:40 --> Config Class Initialized
INFO - 2022-06-28 07:40:40 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:40:40 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:40:40 --> Utf8 Class Initialized
INFO - 2022-06-28 07:40:40 --> URI Class Initialized
INFO - 2022-06-28 07:40:40 --> Router Class Initialized
INFO - 2022-06-28 07:40:40 --> Output Class Initialized
INFO - 2022-06-28 07:40:40 --> Security Class Initialized
DEBUG - 2022-06-28 07:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:40:40 --> Input Class Initialized
INFO - 2022-06-28 07:40:40 --> Language Class Initialized
INFO - 2022-06-28 07:40:40 --> Loader Class Initialized
INFO - 2022-06-28 07:40:40 --> Helper loaded: url_helper
INFO - 2022-06-28 07:40:40 --> Helper loaded: file_helper
INFO - 2022-06-28 07:40:40 --> Database Driver Class Initialized
INFO - 2022-06-28 07:40:40 --> Email Class Initialized
DEBUG - 2022-06-28 07:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 07:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 07:40:40 --> Controller Class Initialized
INFO - 2022-06-28 07:40:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 07:40:40 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 07:40:40 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 07:40:40 --> Final output sent to browser
DEBUG - 2022-06-28 07:40:40 --> Total execution time: 0.2066
INFO - 2022-06-28 07:40:40 --> Config Class Initialized
INFO - 2022-06-28 07:40:40 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:40:40 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:40:40 --> Utf8 Class Initialized
INFO - 2022-06-28 07:40:40 --> URI Class Initialized
INFO - 2022-06-28 07:40:40 --> Router Class Initialized
INFO - 2022-06-28 07:40:40 --> Output Class Initialized
INFO - 2022-06-28 07:40:40 --> Security Class Initialized
DEBUG - 2022-06-28 07:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:40:40 --> Input Class Initialized
INFO - 2022-06-28 07:40:40 --> Language Class Initialized
ERROR - 2022-06-28 07:40:40 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-28 07:41:05 --> Config Class Initialized
INFO - 2022-06-28 07:41:05 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:41:05 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:41:05 --> Utf8 Class Initialized
INFO - 2022-06-28 07:41:05 --> URI Class Initialized
INFO - 2022-06-28 07:41:05 --> Router Class Initialized
INFO - 2022-06-28 07:41:05 --> Output Class Initialized
INFO - 2022-06-28 07:41:05 --> Security Class Initialized
DEBUG - 2022-06-28 07:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:41:05 --> Input Class Initialized
INFO - 2022-06-28 07:41:05 --> Language Class Initialized
INFO - 2022-06-28 07:41:05 --> Loader Class Initialized
INFO - 2022-06-28 07:41:05 --> Helper loaded: url_helper
INFO - 2022-06-28 07:41:05 --> Helper loaded: file_helper
INFO - 2022-06-28 07:41:05 --> Database Driver Class Initialized
INFO - 2022-06-28 07:41:05 --> Email Class Initialized
DEBUG - 2022-06-28 07:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 07:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 07:41:05 --> Controller Class Initialized
INFO - 2022-06-28 07:41:05 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 07:41:05 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 07:41:05 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 07:41:05 --> Final output sent to browser
DEBUG - 2022-06-28 07:41:05 --> Total execution time: 0.0348
INFO - 2022-06-28 07:41:05 --> Config Class Initialized
INFO - 2022-06-28 07:41:05 --> Hooks Class Initialized
INFO - 2022-06-28 07:41:05 --> Config Class Initialized
DEBUG - 2022-06-28 07:41:05 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:41:05 --> Hooks Class Initialized
INFO - 2022-06-28 07:41:05 --> Utf8 Class Initialized
DEBUG - 2022-06-28 07:41:05 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:41:05 --> URI Class Initialized
INFO - 2022-06-28 07:41:05 --> Utf8 Class Initialized
INFO - 2022-06-28 07:41:05 --> URI Class Initialized
INFO - 2022-06-28 07:41:05 --> Router Class Initialized
INFO - 2022-06-28 07:41:05 --> Output Class Initialized
INFO - 2022-06-28 07:41:05 --> Router Class Initialized
INFO - 2022-06-28 07:41:05 --> Security Class Initialized
INFO - 2022-06-28 07:41:05 --> Output Class Initialized
DEBUG - 2022-06-28 07:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:41:05 --> Input Class Initialized
INFO - 2022-06-28 07:41:05 --> Security Class Initialized
DEBUG - 2022-06-28 07:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:41:05 --> Language Class Initialized
INFO - 2022-06-28 07:41:05 --> Input Class Initialized
ERROR - 2022-06-28 07:41:05 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-28 07:41:05 --> Language Class Initialized
ERROR - 2022-06-28 07:41:05 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-28 07:41:38 --> Config Class Initialized
INFO - 2022-06-28 07:41:38 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:41:38 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:41:38 --> Utf8 Class Initialized
INFO - 2022-06-28 07:41:38 --> URI Class Initialized
INFO - 2022-06-28 07:41:38 --> Router Class Initialized
INFO - 2022-06-28 07:41:38 --> Output Class Initialized
INFO - 2022-06-28 07:41:38 --> Security Class Initialized
DEBUG - 2022-06-28 07:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:41:38 --> Input Class Initialized
INFO - 2022-06-28 07:41:38 --> Language Class Initialized
INFO - 2022-06-28 07:41:38 --> Loader Class Initialized
INFO - 2022-06-28 07:41:38 --> Helper loaded: url_helper
INFO - 2022-06-28 07:41:38 --> Helper loaded: file_helper
INFO - 2022-06-28 07:41:38 --> Database Driver Class Initialized
INFO - 2022-06-28 07:41:38 --> Email Class Initialized
DEBUG - 2022-06-28 07:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 07:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 07:41:38 --> Controller Class Initialized
INFO - 2022-06-28 07:41:38 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 07:41:38 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 07:41:38 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 07:41:38 --> Final output sent to browser
DEBUG - 2022-06-28 07:41:38 --> Total execution time: 0.1145
INFO - 2022-06-28 07:41:38 --> Config Class Initialized
INFO - 2022-06-28 07:41:38 --> Hooks Class Initialized
DEBUG - 2022-06-28 07:41:38 --> UTF-8 Support Enabled
INFO - 2022-06-28 07:41:38 --> Utf8 Class Initialized
INFO - 2022-06-28 07:41:38 --> URI Class Initialized
INFO - 2022-06-28 07:41:38 --> Router Class Initialized
INFO - 2022-06-28 07:41:38 --> Output Class Initialized
INFO - 2022-06-28 07:41:38 --> Security Class Initialized
DEBUG - 2022-06-28 07:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 07:41:38 --> Input Class Initialized
INFO - 2022-06-28 07:41:38 --> Language Class Initialized
ERROR - 2022-06-28 07:41:38 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-28 08:30:45 --> Config Class Initialized
INFO - 2022-06-28 08:30:45 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:30:45 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:30:45 --> Utf8 Class Initialized
INFO - 2022-06-28 08:30:45 --> URI Class Initialized
INFO - 2022-06-28 08:30:45 --> Router Class Initialized
INFO - 2022-06-28 08:30:45 --> Output Class Initialized
INFO - 2022-06-28 08:30:45 --> Security Class Initialized
DEBUG - 2022-06-28 08:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:30:45 --> Input Class Initialized
INFO - 2022-06-28 08:30:45 --> Language Class Initialized
INFO - 2022-06-28 08:30:45 --> Loader Class Initialized
INFO - 2022-06-28 08:30:45 --> Helper loaded: url_helper
INFO - 2022-06-28 08:30:45 --> Helper loaded: file_helper
INFO - 2022-06-28 08:30:45 --> Database Driver Class Initialized
INFO - 2022-06-28 08:30:46 --> Email Class Initialized
DEBUG - 2022-06-28 08:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:30:46 --> Controller Class Initialized
INFO - 2022-06-28 08:30:46 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:30:46 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:30:46 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 08:30:46 --> Final output sent to browser
DEBUG - 2022-06-28 08:30:46 --> Total execution time: 0.4123
INFO - 2022-06-28 08:30:48 --> Config Class Initialized
INFO - 2022-06-28 08:30:48 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:30:48 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:30:48 --> Utf8 Class Initialized
INFO - 2022-06-28 08:30:48 --> URI Class Initialized
INFO - 2022-06-28 08:30:48 --> Router Class Initialized
INFO - 2022-06-28 08:30:48 --> Output Class Initialized
INFO - 2022-06-28 08:30:48 --> Security Class Initialized
DEBUG - 2022-06-28 08:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:30:48 --> Input Class Initialized
INFO - 2022-06-28 08:30:48 --> Language Class Initialized
INFO - 2022-06-28 08:30:48 --> Loader Class Initialized
INFO - 2022-06-28 08:30:48 --> Helper loaded: url_helper
INFO - 2022-06-28 08:30:48 --> Helper loaded: file_helper
INFO - 2022-06-28 08:30:48 --> Database Driver Class Initialized
INFO - 2022-06-28 08:30:48 --> Email Class Initialized
DEBUG - 2022-06-28 08:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:30:48 --> Controller Class Initialized
INFO - 2022-06-28 08:30:48 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:30:48 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:30:48 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 08:30:48 --> Final output sent to browser
DEBUG - 2022-06-28 08:30:48 --> Total execution time: 0.0746
INFO - 2022-06-28 08:31:00 --> Config Class Initialized
INFO - 2022-06-28 08:31:00 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:31:00 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:31:00 --> Utf8 Class Initialized
INFO - 2022-06-28 08:31:00 --> URI Class Initialized
INFO - 2022-06-28 08:31:00 --> Router Class Initialized
INFO - 2022-06-28 08:31:00 --> Output Class Initialized
INFO - 2022-06-28 08:31:00 --> Security Class Initialized
DEBUG - 2022-06-28 08:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:31:00 --> Input Class Initialized
INFO - 2022-06-28 08:31:00 --> Language Class Initialized
INFO - 2022-06-28 08:31:00 --> Loader Class Initialized
INFO - 2022-06-28 08:31:00 --> Helper loaded: url_helper
INFO - 2022-06-28 08:31:00 --> Helper loaded: file_helper
INFO - 2022-06-28 08:31:00 --> Database Driver Class Initialized
INFO - 2022-06-28 08:31:00 --> Email Class Initialized
DEBUG - 2022-06-28 08:31:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:31:00 --> Controller Class Initialized
INFO - 2022-06-28 08:31:00 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:31:00 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:31:00 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 08:31:00 --> Final output sent to browser
DEBUG - 2022-06-28 08:31:00 --> Total execution time: 0.1567
INFO - 2022-06-28 08:31:07 --> Config Class Initialized
INFO - 2022-06-28 08:31:07 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:31:07 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:31:07 --> Utf8 Class Initialized
INFO - 2022-06-28 08:31:07 --> URI Class Initialized
INFO - 2022-06-28 08:31:07 --> Router Class Initialized
INFO - 2022-06-28 08:31:07 --> Output Class Initialized
INFO - 2022-06-28 08:31:07 --> Security Class Initialized
DEBUG - 2022-06-28 08:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:31:07 --> Input Class Initialized
INFO - 2022-06-28 08:31:07 --> Language Class Initialized
INFO - 2022-06-28 08:31:07 --> Loader Class Initialized
INFO - 2022-06-28 08:31:07 --> Helper loaded: url_helper
INFO - 2022-06-28 08:31:07 --> Helper loaded: file_helper
INFO - 2022-06-28 08:31:07 --> Database Driver Class Initialized
INFO - 2022-06-28 08:31:07 --> Email Class Initialized
DEBUG - 2022-06-28 08:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:31:07 --> Controller Class Initialized
INFO - 2022-06-28 08:31:07 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:31:07 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:31:07 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 08:31:07 --> Final output sent to browser
DEBUG - 2022-06-28 08:31:07 --> Total execution time: 0.1463
INFO - 2022-06-28 08:31:11 --> Config Class Initialized
INFO - 2022-06-28 08:31:11 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:31:11 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:31:11 --> Utf8 Class Initialized
INFO - 2022-06-28 08:31:11 --> URI Class Initialized
INFO - 2022-06-28 08:31:11 --> Router Class Initialized
INFO - 2022-06-28 08:31:11 --> Output Class Initialized
INFO - 2022-06-28 08:31:11 --> Security Class Initialized
DEBUG - 2022-06-28 08:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:31:11 --> Input Class Initialized
INFO - 2022-06-28 08:31:11 --> Language Class Initialized
INFO - 2022-06-28 08:31:11 --> Loader Class Initialized
INFO - 2022-06-28 08:31:11 --> Helper loaded: url_helper
INFO - 2022-06-28 08:31:11 --> Helper loaded: file_helper
INFO - 2022-06-28 08:31:11 --> Database Driver Class Initialized
INFO - 2022-06-28 08:31:11 --> Email Class Initialized
DEBUG - 2022-06-28 08:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:31:11 --> Controller Class Initialized
INFO - 2022-06-28 08:31:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:31:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:31:11 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 08:31:11 --> Final output sent to browser
DEBUG - 2022-06-28 08:31:11 --> Total execution time: 0.1686
INFO - 2022-06-28 08:31:11 --> Config Class Initialized
INFO - 2022-06-28 08:31:11 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:31:11 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:31:11 --> Utf8 Class Initialized
INFO - 2022-06-28 08:31:11 --> URI Class Initialized
INFO - 2022-06-28 08:31:11 --> Router Class Initialized
INFO - 2022-06-28 08:31:11 --> Output Class Initialized
INFO - 2022-06-28 08:31:11 --> Security Class Initialized
DEBUG - 2022-06-28 08:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:31:11 --> Input Class Initialized
INFO - 2022-06-28 08:31:11 --> Language Class Initialized
ERROR - 2022-06-28 08:31:11 --> 404 Page Not Found: Tokenctrl/localhost
INFO - 2022-06-28 08:32:18 --> Config Class Initialized
INFO - 2022-06-28 08:32:18 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:32:18 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:32:18 --> Utf8 Class Initialized
INFO - 2022-06-28 08:32:18 --> URI Class Initialized
INFO - 2022-06-28 08:32:18 --> Router Class Initialized
INFO - 2022-06-28 08:32:18 --> Output Class Initialized
INFO - 2022-06-28 08:32:18 --> Security Class Initialized
DEBUG - 2022-06-28 08:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:32:18 --> Input Class Initialized
INFO - 2022-06-28 08:32:18 --> Language Class Initialized
INFO - 2022-06-28 08:32:18 --> Loader Class Initialized
INFO - 2022-06-28 08:32:18 --> Helper loaded: url_helper
INFO - 2022-06-28 08:32:18 --> Helper loaded: file_helper
INFO - 2022-06-28 08:32:18 --> Database Driver Class Initialized
INFO - 2022-06-28 08:32:18 --> Email Class Initialized
DEBUG - 2022-06-28 08:32:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:32:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:32:18 --> Controller Class Initialized
INFO - 2022-06-28 08:32:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:32:18 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:32:18 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 08:32:18 --> Final output sent to browser
DEBUG - 2022-06-28 08:32:18 --> Total execution time: 0.3098
INFO - 2022-06-28 08:32:18 --> Config Class Initialized
INFO - 2022-06-28 08:32:18 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:32:18 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:32:18 --> Utf8 Class Initialized
INFO - 2022-06-28 08:32:18 --> URI Class Initialized
INFO - 2022-06-28 08:32:18 --> Router Class Initialized
INFO - 2022-06-28 08:32:18 --> Output Class Initialized
INFO - 2022-06-28 08:32:18 --> Security Class Initialized
DEBUG - 2022-06-28 08:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:32:18 --> Input Class Initialized
INFO - 2022-06-28 08:32:18 --> Language Class Initialized
ERROR - 2022-06-28 08:32:18 --> 404 Page Not Found: %20static/images
INFO - 2022-06-28 08:32:18 --> Config Class Initialized
INFO - 2022-06-28 08:32:18 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:32:18 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:32:18 --> Utf8 Class Initialized
INFO - 2022-06-28 08:32:18 --> URI Class Initialized
INFO - 2022-06-28 08:32:18 --> Router Class Initialized
INFO - 2022-06-28 08:32:18 --> Output Class Initialized
INFO - 2022-06-28 08:32:18 --> Security Class Initialized
DEBUG - 2022-06-28 08:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:32:18 --> Input Class Initialized
INFO - 2022-06-28 08:32:18 --> Language Class Initialized
ERROR - 2022-06-28 08:32:18 --> 404 Page Not Found: %20static/images
INFO - 2022-06-28 08:32:59 --> Config Class Initialized
INFO - 2022-06-28 08:32:59 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:32:59 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:32:59 --> Utf8 Class Initialized
INFO - 2022-06-28 08:32:59 --> URI Class Initialized
INFO - 2022-06-28 08:32:59 --> Router Class Initialized
INFO - 2022-06-28 08:32:59 --> Output Class Initialized
INFO - 2022-06-28 08:32:59 --> Security Class Initialized
DEBUG - 2022-06-28 08:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:32:59 --> Input Class Initialized
INFO - 2022-06-28 08:32:59 --> Language Class Initialized
INFO - 2022-06-28 08:32:59 --> Loader Class Initialized
INFO - 2022-06-28 08:32:59 --> Helper loaded: url_helper
INFO - 2022-06-28 08:32:59 --> Helper loaded: file_helper
INFO - 2022-06-28 08:32:59 --> Database Driver Class Initialized
INFO - 2022-06-28 08:32:59 --> Email Class Initialized
DEBUG - 2022-06-28 08:32:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:32:59 --> Controller Class Initialized
INFO - 2022-06-28 08:32:59 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:32:59 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:32:59 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 08:32:59 --> Final output sent to browser
DEBUG - 2022-06-28 08:32:59 --> Total execution time: 0.0683
INFO - 2022-06-28 08:32:59 --> Config Class Initialized
INFO - 2022-06-28 08:32:59 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:32:59 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:32:59 --> Utf8 Class Initialized
INFO - 2022-06-28 08:32:59 --> URI Class Initialized
INFO - 2022-06-28 08:32:59 --> Router Class Initialized
INFO - 2022-06-28 08:32:59 --> Output Class Initialized
INFO - 2022-06-28 08:32:59 --> Security Class Initialized
DEBUG - 2022-06-28 08:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:32:59 --> Input Class Initialized
INFO - 2022-06-28 08:32:59 --> Language Class Initialized
ERROR - 2022-06-28 08:32:59 --> 404 Page Not Found: %20static/images
INFO - 2022-06-28 08:32:59 --> Config Class Initialized
INFO - 2022-06-28 08:32:59 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:32:59 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:32:59 --> Utf8 Class Initialized
INFO - 2022-06-28 08:32:59 --> URI Class Initialized
INFO - 2022-06-28 08:32:59 --> Router Class Initialized
INFO - 2022-06-28 08:32:59 --> Output Class Initialized
INFO - 2022-06-28 08:32:59 --> Security Class Initialized
DEBUG - 2022-06-28 08:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:32:59 --> Input Class Initialized
INFO - 2022-06-28 08:32:59 --> Language Class Initialized
ERROR - 2022-06-28 08:32:59 --> 404 Page Not Found: %20static/images
INFO - 2022-06-28 08:33:19 --> Config Class Initialized
INFO - 2022-06-28 08:33:19 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:33:19 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:33:19 --> Utf8 Class Initialized
INFO - 2022-06-28 08:33:19 --> URI Class Initialized
INFO - 2022-06-28 08:33:19 --> Router Class Initialized
INFO - 2022-06-28 08:33:19 --> Output Class Initialized
INFO - 2022-06-28 08:33:19 --> Security Class Initialized
DEBUG - 2022-06-28 08:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:33:19 --> Input Class Initialized
INFO - 2022-06-28 08:33:19 --> Language Class Initialized
INFO - 2022-06-28 08:33:19 --> Loader Class Initialized
INFO - 2022-06-28 08:33:19 --> Helper loaded: url_helper
INFO - 2022-06-28 08:33:19 --> Helper loaded: file_helper
INFO - 2022-06-28 08:33:19 --> Database Driver Class Initialized
INFO - 2022-06-28 08:33:19 --> Email Class Initialized
DEBUG - 2022-06-28 08:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:33:19 --> Controller Class Initialized
INFO - 2022-06-28 08:33:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:33:19 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:33:19 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 08:33:19 --> Final output sent to browser
DEBUG - 2022-06-28 08:33:19 --> Total execution time: 0.2052
INFO - 2022-06-28 08:33:29 --> Config Class Initialized
INFO - 2022-06-28 08:33:29 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:33:29 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:33:29 --> Utf8 Class Initialized
INFO - 2022-06-28 08:33:29 --> URI Class Initialized
INFO - 2022-06-28 08:33:29 --> Router Class Initialized
INFO - 2022-06-28 08:33:29 --> Output Class Initialized
INFO - 2022-06-28 08:33:29 --> Security Class Initialized
DEBUG - 2022-06-28 08:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:33:29 --> Input Class Initialized
INFO - 2022-06-28 08:33:29 --> Language Class Initialized
INFO - 2022-06-28 08:33:29 --> Loader Class Initialized
INFO - 2022-06-28 08:33:29 --> Helper loaded: url_helper
INFO - 2022-06-28 08:33:29 --> Helper loaded: file_helper
INFO - 2022-06-28 08:33:29 --> Database Driver Class Initialized
INFO - 2022-06-28 08:33:29 --> Email Class Initialized
DEBUG - 2022-06-28 08:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:33:29 --> Controller Class Initialized
INFO - 2022-06-28 08:33:29 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:33:29 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:33:29 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 08:33:29 --> Final output sent to browser
DEBUG - 2022-06-28 08:33:29 --> Total execution time: 0.1195
INFO - 2022-06-28 08:34:09 --> Config Class Initialized
INFO - 2022-06-28 08:34:09 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:34:09 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:34:09 --> Utf8 Class Initialized
INFO - 2022-06-28 08:34:09 --> URI Class Initialized
INFO - 2022-06-28 08:34:09 --> Router Class Initialized
INFO - 2022-06-28 08:34:09 --> Output Class Initialized
INFO - 2022-06-28 08:34:09 --> Security Class Initialized
DEBUG - 2022-06-28 08:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:34:09 --> Input Class Initialized
INFO - 2022-06-28 08:34:09 --> Language Class Initialized
INFO - 2022-06-28 08:34:09 --> Loader Class Initialized
INFO - 2022-06-28 08:34:09 --> Helper loaded: url_helper
INFO - 2022-06-28 08:34:09 --> Helper loaded: file_helper
INFO - 2022-06-28 08:34:09 --> Database Driver Class Initialized
INFO - 2022-06-28 08:34:09 --> Email Class Initialized
DEBUG - 2022-06-28 08:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:34:09 --> Controller Class Initialized
INFO - 2022-06-28 08:34:09 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:34:09 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:34:09 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 08:34:09 --> Final output sent to browser
DEBUG - 2022-06-28 08:34:09 --> Total execution time: 0.1779
INFO - 2022-06-28 08:40:38 --> Config Class Initialized
INFO - 2022-06-28 08:40:38 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:40:38 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:40:38 --> Utf8 Class Initialized
INFO - 2022-06-28 08:40:38 --> URI Class Initialized
INFO - 2022-06-28 08:40:38 --> Router Class Initialized
INFO - 2022-06-28 08:40:38 --> Output Class Initialized
INFO - 2022-06-28 08:40:38 --> Security Class Initialized
DEBUG - 2022-06-28 08:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:40:38 --> Input Class Initialized
INFO - 2022-06-28 08:40:38 --> Language Class Initialized
INFO - 2022-06-28 08:40:38 --> Loader Class Initialized
INFO - 2022-06-28 08:40:38 --> Helper loaded: url_helper
INFO - 2022-06-28 08:40:38 --> Helper loaded: file_helper
INFO - 2022-06-28 08:40:38 --> Database Driver Class Initialized
INFO - 2022-06-28 08:40:39 --> Email Class Initialized
DEBUG - 2022-06-28 08:40:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:40:39 --> Controller Class Initialized
INFO - 2022-06-28 08:40:39 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:40:39 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:40:39 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 08:40:39 --> Final output sent to browser
DEBUG - 2022-06-28 08:40:39 --> Total execution time: 0.1910
INFO - 2022-06-28 08:40:42 --> Config Class Initialized
INFO - 2022-06-28 08:40:42 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:40:42 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:40:42 --> Utf8 Class Initialized
INFO - 2022-06-28 08:40:42 --> URI Class Initialized
INFO - 2022-06-28 08:40:42 --> Router Class Initialized
INFO - 2022-06-28 08:40:42 --> Output Class Initialized
INFO - 2022-06-28 08:40:42 --> Security Class Initialized
DEBUG - 2022-06-28 08:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:40:42 --> Input Class Initialized
INFO - 2022-06-28 08:40:42 --> Language Class Initialized
INFO - 2022-06-28 08:40:42 --> Loader Class Initialized
INFO - 2022-06-28 08:40:42 --> Helper loaded: url_helper
INFO - 2022-06-28 08:40:42 --> Helper loaded: file_helper
INFO - 2022-06-28 08:40:42 --> Database Driver Class Initialized
INFO - 2022-06-28 08:40:42 --> Email Class Initialized
DEBUG - 2022-06-28 08:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:40:42 --> Controller Class Initialized
INFO - 2022-06-28 08:40:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:40:42 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:40:42 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 08:40:42 --> Final output sent to browser
DEBUG - 2022-06-28 08:40:42 --> Total execution time: 0.2186
INFO - 2022-06-28 08:42:22 --> Config Class Initialized
INFO - 2022-06-28 08:42:22 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:42:22 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:42:22 --> Utf8 Class Initialized
INFO - 2022-06-28 08:42:22 --> URI Class Initialized
INFO - 2022-06-28 08:42:22 --> Router Class Initialized
INFO - 2022-06-28 08:42:22 --> Output Class Initialized
INFO - 2022-06-28 08:42:22 --> Security Class Initialized
DEBUG - 2022-06-28 08:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:42:22 --> Input Class Initialized
INFO - 2022-06-28 08:42:22 --> Language Class Initialized
INFO - 2022-06-28 08:42:22 --> Loader Class Initialized
INFO - 2022-06-28 08:42:22 --> Helper loaded: url_helper
INFO - 2022-06-28 08:42:22 --> Helper loaded: file_helper
INFO - 2022-06-28 08:42:22 --> Database Driver Class Initialized
INFO - 2022-06-28 08:42:22 --> Email Class Initialized
DEBUG - 2022-06-28 08:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:42:22 --> Controller Class Initialized
INFO - 2022-06-28 08:42:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:42:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:42:22 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 08:42:22 --> Final output sent to browser
DEBUG - 2022-06-28 08:42:22 --> Total execution time: 0.0402
INFO - 2022-06-28 08:42:24 --> Config Class Initialized
INFO - 2022-06-28 08:42:24 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:42:24 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:42:24 --> Utf8 Class Initialized
INFO - 2022-06-28 08:42:24 --> URI Class Initialized
INFO - 2022-06-28 08:42:24 --> Router Class Initialized
INFO - 2022-06-28 08:42:24 --> Output Class Initialized
INFO - 2022-06-28 08:42:24 --> Security Class Initialized
DEBUG - 2022-06-28 08:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:42:24 --> Input Class Initialized
INFO - 2022-06-28 08:42:24 --> Language Class Initialized
INFO - 2022-06-28 08:42:24 --> Loader Class Initialized
INFO - 2022-06-28 08:42:24 --> Helper loaded: url_helper
INFO - 2022-06-28 08:42:24 --> Helper loaded: file_helper
INFO - 2022-06-28 08:42:24 --> Database Driver Class Initialized
INFO - 2022-06-28 08:42:24 --> Email Class Initialized
DEBUG - 2022-06-28 08:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:42:24 --> Controller Class Initialized
INFO - 2022-06-28 08:42:24 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:42:24 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:42:24 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 08:42:24 --> Final output sent to browser
DEBUG - 2022-06-28 08:42:24 --> Total execution time: 0.1450
INFO - 2022-06-28 08:42:37 --> Config Class Initialized
INFO - 2022-06-28 08:42:37 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:42:37 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:42:37 --> Utf8 Class Initialized
INFO - 2022-06-28 08:42:37 --> URI Class Initialized
INFO - 2022-06-28 08:42:37 --> Router Class Initialized
INFO - 2022-06-28 08:42:37 --> Output Class Initialized
INFO - 2022-06-28 08:42:37 --> Security Class Initialized
DEBUG - 2022-06-28 08:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:42:37 --> Input Class Initialized
INFO - 2022-06-28 08:42:37 --> Language Class Initialized
INFO - 2022-06-28 08:42:37 --> Loader Class Initialized
INFO - 2022-06-28 08:42:37 --> Helper loaded: url_helper
INFO - 2022-06-28 08:42:37 --> Helper loaded: file_helper
INFO - 2022-06-28 08:42:37 --> Database Driver Class Initialized
INFO - 2022-06-28 08:42:37 --> Email Class Initialized
DEBUG - 2022-06-28 08:42:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:42:37 --> Controller Class Initialized
INFO - 2022-06-28 08:42:37 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:42:37 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:42:37 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 08:42:37 --> Final output sent to browser
DEBUG - 2022-06-28 08:42:37 --> Total execution time: 0.0255
INFO - 2022-06-28 08:42:38 --> Config Class Initialized
INFO - 2022-06-28 08:42:38 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:42:38 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:42:38 --> Utf8 Class Initialized
INFO - 2022-06-28 08:42:38 --> URI Class Initialized
INFO - 2022-06-28 08:42:38 --> Router Class Initialized
INFO - 2022-06-28 08:42:38 --> Output Class Initialized
INFO - 2022-06-28 08:42:38 --> Security Class Initialized
DEBUG - 2022-06-28 08:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:42:38 --> Input Class Initialized
INFO - 2022-06-28 08:42:38 --> Language Class Initialized
INFO - 2022-06-28 08:42:38 --> Loader Class Initialized
INFO - 2022-06-28 08:42:38 --> Helper loaded: url_helper
INFO - 2022-06-28 08:42:38 --> Helper loaded: file_helper
INFO - 2022-06-28 08:42:38 --> Database Driver Class Initialized
INFO - 2022-06-28 08:42:38 --> Email Class Initialized
DEBUG - 2022-06-28 08:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:42:38 --> Controller Class Initialized
INFO - 2022-06-28 08:42:38 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:42:38 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:42:38 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 08:42:38 --> Final output sent to browser
DEBUG - 2022-06-28 08:42:38 --> Total execution time: 0.1409
INFO - 2022-06-28 08:53:01 --> Config Class Initialized
INFO - 2022-06-28 08:53:01 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:53:01 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:53:01 --> Utf8 Class Initialized
INFO - 2022-06-28 08:53:01 --> URI Class Initialized
INFO - 2022-06-28 08:53:01 --> Router Class Initialized
INFO - 2022-06-28 08:53:01 --> Output Class Initialized
INFO - 2022-06-28 08:53:01 --> Security Class Initialized
DEBUG - 2022-06-28 08:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:53:01 --> Input Class Initialized
INFO - 2022-06-28 08:53:01 --> Language Class Initialized
INFO - 2022-06-28 08:53:01 --> Loader Class Initialized
INFO - 2022-06-28 08:53:01 --> Helper loaded: url_helper
INFO - 2022-06-28 08:53:01 --> Helper loaded: file_helper
INFO - 2022-06-28 08:53:01 --> Database Driver Class Initialized
INFO - 2022-06-28 08:53:01 --> Email Class Initialized
DEBUG - 2022-06-28 08:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:53:01 --> Controller Class Initialized
INFO - 2022-06-28 08:53:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:53:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:53:01 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 08:53:01 --> Final output sent to browser
DEBUG - 2022-06-28 08:53:01 --> Total execution time: 0.0247
INFO - 2022-06-28 08:53:01 --> Config Class Initialized
INFO - 2022-06-28 08:53:01 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:53:01 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:53:01 --> Utf8 Class Initialized
INFO - 2022-06-28 08:53:13 --> Config Class Initialized
INFO - 2022-06-28 08:53:13 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:53:13 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:53:13 --> Utf8 Class Initialized
INFO - 2022-06-28 08:53:13 --> URI Class Initialized
INFO - 2022-06-28 08:53:13 --> Router Class Initialized
INFO - 2022-06-28 08:53:13 --> Output Class Initialized
INFO - 2022-06-28 08:53:13 --> Security Class Initialized
DEBUG - 2022-06-28 08:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:53:13 --> Input Class Initialized
INFO - 2022-06-28 08:53:13 --> Language Class Initialized
INFO - 2022-06-28 08:53:13 --> Loader Class Initialized
INFO - 2022-06-28 08:53:13 --> Helper loaded: url_helper
INFO - 2022-06-28 08:53:13 --> Helper loaded: file_helper
INFO - 2022-06-28 08:53:13 --> Database Driver Class Initialized
INFO - 2022-06-28 08:53:13 --> Email Class Initialized
DEBUG - 2022-06-28 08:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:53:13 --> Controller Class Initialized
INFO - 2022-06-28 08:53:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:53:13 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:53:13 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 08:53:13 --> Final output sent to browser
DEBUG - 2022-06-28 08:53:13 --> Total execution time: 0.1450
INFO - 2022-06-28 08:53:13 --> Config Class Initialized
INFO - 2022-06-28 08:53:13 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:53:13 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:53:13 --> Utf8 Class Initialized
INFO - 2022-06-28 08:53:14 --> Config Class Initialized
INFO - 2022-06-28 08:53:14 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:53:14 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:53:14 --> Utf8 Class Initialized
INFO - 2022-06-28 08:53:14 --> URI Class Initialized
INFO - 2022-06-28 08:53:14 --> Router Class Initialized
INFO - 2022-06-28 08:53:14 --> Output Class Initialized
INFO - 2022-06-28 08:53:14 --> Security Class Initialized
DEBUG - 2022-06-28 08:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:53:14 --> Input Class Initialized
INFO - 2022-06-28 08:53:14 --> Language Class Initialized
INFO - 2022-06-28 08:53:14 --> Loader Class Initialized
INFO - 2022-06-28 08:53:14 --> Helper loaded: url_helper
INFO - 2022-06-28 08:53:14 --> Helper loaded: file_helper
INFO - 2022-06-28 08:53:14 --> Database Driver Class Initialized
INFO - 2022-06-28 08:53:14 --> Email Class Initialized
DEBUG - 2022-06-28 08:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:53:14 --> Controller Class Initialized
INFO - 2022-06-28 08:53:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:53:14 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:53:14 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 08:53:14 --> Final output sent to browser
DEBUG - 2022-06-28 08:53:14 --> Total execution time: 0.1232
INFO - 2022-06-28 08:53:14 --> Config Class Initialized
INFO - 2022-06-28 08:53:14 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:53:14 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:53:14 --> Utf8 Class Initialized
INFO - 2022-06-28 08:53:18 --> Config Class Initialized
INFO - 2022-06-28 08:53:18 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:53:18 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:53:18 --> Utf8 Class Initialized
INFO - 2022-06-28 08:53:18 --> URI Class Initialized
INFO - 2022-06-28 08:53:18 --> Router Class Initialized
INFO - 2022-06-28 08:53:18 --> Output Class Initialized
INFO - 2022-06-28 08:53:18 --> Security Class Initialized
DEBUG - 2022-06-28 08:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:53:18 --> Input Class Initialized
INFO - 2022-06-28 08:53:18 --> Language Class Initialized
INFO - 2022-06-28 08:53:18 --> Loader Class Initialized
INFO - 2022-06-28 08:53:18 --> Helper loaded: url_helper
INFO - 2022-06-28 08:53:18 --> Helper loaded: file_helper
INFO - 2022-06-28 08:53:18 --> Database Driver Class Initialized
INFO - 2022-06-28 08:53:18 --> Email Class Initialized
DEBUG - 2022-06-28 08:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:53:18 --> Controller Class Initialized
INFO - 2022-06-28 08:53:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:53:18 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:53:18 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 08:53:18 --> Final output sent to browser
DEBUG - 2022-06-28 08:53:18 --> Total execution time: 0.1217
INFO - 2022-06-28 08:53:18 --> Config Class Initialized
INFO - 2022-06-28 08:53:18 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:53:18 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:53:18 --> Utf8 Class Initialized
INFO - 2022-06-28 08:53:19 --> Config Class Initialized
INFO - 2022-06-28 08:53:19 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:53:19 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:53:19 --> Utf8 Class Initialized
INFO - 2022-06-28 08:53:19 --> URI Class Initialized
INFO - 2022-06-28 08:53:19 --> Router Class Initialized
INFO - 2022-06-28 08:53:19 --> Output Class Initialized
INFO - 2022-06-28 08:53:19 --> Security Class Initialized
DEBUG - 2022-06-28 08:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:53:19 --> Input Class Initialized
INFO - 2022-06-28 08:53:19 --> Language Class Initialized
INFO - 2022-06-28 08:53:19 --> Loader Class Initialized
INFO - 2022-06-28 08:53:19 --> Helper loaded: url_helper
INFO - 2022-06-28 08:53:19 --> Helper loaded: file_helper
INFO - 2022-06-28 08:53:19 --> Database Driver Class Initialized
INFO - 2022-06-28 08:53:19 --> Email Class Initialized
DEBUG - 2022-06-28 08:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:53:19 --> Controller Class Initialized
INFO - 2022-06-28 08:53:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:53:19 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:53:19 --> Final output sent to browser
DEBUG - 2022-06-28 08:53:19 --> Total execution time: 0.1469
INFO - 2022-06-28 08:53:20 --> Config Class Initialized
INFO - 2022-06-28 08:53:20 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:53:20 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:53:20 --> Utf8 Class Initialized
INFO - 2022-06-28 08:53:20 --> URI Class Initialized
INFO - 2022-06-28 08:53:20 --> Router Class Initialized
INFO - 2022-06-28 08:53:20 --> Output Class Initialized
INFO - 2022-06-28 08:53:20 --> Security Class Initialized
DEBUG - 2022-06-28 08:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:53:20 --> Input Class Initialized
INFO - 2022-06-28 08:53:20 --> Language Class Initialized
INFO - 2022-06-28 08:53:20 --> Loader Class Initialized
INFO - 2022-06-28 08:53:20 --> Helper loaded: url_helper
INFO - 2022-06-28 08:53:20 --> Helper loaded: file_helper
INFO - 2022-06-28 08:53:20 --> Database Driver Class Initialized
INFO - 2022-06-28 08:53:20 --> Email Class Initialized
DEBUG - 2022-06-28 08:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:53:20 --> Controller Class Initialized
INFO - 2022-06-28 08:53:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:53:20 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:53:20 --> Final output sent to browser
DEBUG - 2022-06-28 08:53:20 --> Total execution time: 0.1654
INFO - 2022-06-28 08:53:20 --> Config Class Initialized
INFO - 2022-06-28 08:53:20 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:53:20 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:53:20 --> Utf8 Class Initialized
INFO - 2022-06-28 08:53:20 --> URI Class Initialized
INFO - 2022-06-28 08:53:20 --> Router Class Initialized
INFO - 2022-06-28 08:53:20 --> Output Class Initialized
INFO - 2022-06-28 08:53:20 --> Security Class Initialized
DEBUG - 2022-06-28 08:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:53:20 --> Input Class Initialized
INFO - 2022-06-28 08:53:20 --> Language Class Initialized
INFO - 2022-06-28 08:53:20 --> Loader Class Initialized
INFO - 2022-06-28 08:53:20 --> Helper loaded: url_helper
INFO - 2022-06-28 08:53:20 --> Helper loaded: file_helper
INFO - 2022-06-28 08:53:20 --> Database Driver Class Initialized
INFO - 2022-06-28 08:53:20 --> Email Class Initialized
DEBUG - 2022-06-28 08:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:53:20 --> Controller Class Initialized
INFO - 2022-06-28 08:53:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:53:20 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:53:20 --> Final output sent to browser
DEBUG - 2022-06-28 08:53:20 --> Total execution time: 0.1242
INFO - 2022-06-28 08:53:20 --> Config Class Initialized
INFO - 2022-06-28 08:53:20 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:53:20 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:53:20 --> Utf8 Class Initialized
INFO - 2022-06-28 08:53:20 --> URI Class Initialized
INFO - 2022-06-28 08:53:20 --> Router Class Initialized
INFO - 2022-06-28 08:53:20 --> Output Class Initialized
INFO - 2022-06-28 08:53:20 --> Security Class Initialized
DEBUG - 2022-06-28 08:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:53:20 --> Input Class Initialized
INFO - 2022-06-28 08:53:20 --> Language Class Initialized
INFO - 2022-06-28 08:53:20 --> Loader Class Initialized
INFO - 2022-06-28 08:53:20 --> Helper loaded: url_helper
INFO - 2022-06-28 08:53:20 --> Helper loaded: file_helper
INFO - 2022-06-28 08:53:20 --> Database Driver Class Initialized
INFO - 2022-06-28 08:53:20 --> Email Class Initialized
DEBUG - 2022-06-28 08:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:53:20 --> Controller Class Initialized
INFO - 2022-06-28 08:53:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:53:20 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:53:20 --> Final output sent to browser
DEBUG - 2022-06-28 08:53:20 --> Total execution time: 0.0621
INFO - 2022-06-28 08:53:21 --> Config Class Initialized
INFO - 2022-06-28 08:53:21 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:53:21 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:53:21 --> Utf8 Class Initialized
INFO - 2022-06-28 08:53:21 --> URI Class Initialized
INFO - 2022-06-28 08:53:21 --> Router Class Initialized
INFO - 2022-06-28 08:53:21 --> Output Class Initialized
INFO - 2022-06-28 08:53:21 --> Security Class Initialized
DEBUG - 2022-06-28 08:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:53:21 --> Input Class Initialized
INFO - 2022-06-28 08:53:21 --> Language Class Initialized
INFO - 2022-06-28 08:53:21 --> Loader Class Initialized
INFO - 2022-06-28 08:53:21 --> Helper loaded: url_helper
INFO - 2022-06-28 08:53:21 --> Helper loaded: file_helper
INFO - 2022-06-28 08:53:21 --> Database Driver Class Initialized
INFO - 2022-06-28 08:53:21 --> Email Class Initialized
DEBUG - 2022-06-28 08:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:53:21 --> Controller Class Initialized
INFO - 2022-06-28 08:53:21 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:53:21 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:53:21 --> Final output sent to browser
DEBUG - 2022-06-28 08:53:21 --> Total execution time: 0.0449
INFO - 2022-06-28 08:53:21 --> Config Class Initialized
INFO - 2022-06-28 08:53:21 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:53:21 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:53:21 --> Utf8 Class Initialized
INFO - 2022-06-28 08:53:21 --> URI Class Initialized
INFO - 2022-06-28 08:53:21 --> Router Class Initialized
INFO - 2022-06-28 08:53:21 --> Output Class Initialized
INFO - 2022-06-28 08:53:21 --> Security Class Initialized
DEBUG - 2022-06-28 08:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:53:21 --> Input Class Initialized
INFO - 2022-06-28 08:53:21 --> Language Class Initialized
INFO - 2022-06-28 08:53:21 --> Loader Class Initialized
INFO - 2022-06-28 08:53:21 --> Helper loaded: url_helper
INFO - 2022-06-28 08:53:21 --> Helper loaded: file_helper
INFO - 2022-06-28 08:53:21 --> Database Driver Class Initialized
INFO - 2022-06-28 08:53:21 --> Email Class Initialized
DEBUG - 2022-06-28 08:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:53:21 --> Controller Class Initialized
INFO - 2022-06-28 08:53:21 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:53:21 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:53:21 --> Final output sent to browser
DEBUG - 2022-06-28 08:53:21 --> Total execution time: 0.0368
INFO - 2022-06-28 08:53:21 --> Config Class Initialized
INFO - 2022-06-28 08:53:21 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:53:21 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:53:21 --> Utf8 Class Initialized
INFO - 2022-06-28 08:53:21 --> URI Class Initialized
INFO - 2022-06-28 08:53:21 --> Router Class Initialized
INFO - 2022-06-28 08:53:21 --> Output Class Initialized
INFO - 2022-06-28 08:53:21 --> Security Class Initialized
DEBUG - 2022-06-28 08:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:53:21 --> Input Class Initialized
INFO - 2022-06-28 08:53:21 --> Language Class Initialized
INFO - 2022-06-28 08:53:21 --> Loader Class Initialized
INFO - 2022-06-28 08:53:21 --> Helper loaded: url_helper
INFO - 2022-06-28 08:53:21 --> Helper loaded: file_helper
INFO - 2022-06-28 08:53:21 --> Database Driver Class Initialized
INFO - 2022-06-28 08:53:21 --> Email Class Initialized
DEBUG - 2022-06-28 08:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:53:21 --> Controller Class Initialized
INFO - 2022-06-28 08:53:21 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:53:21 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:53:21 --> Final output sent to browser
DEBUG - 2022-06-28 08:53:21 --> Total execution time: 0.0396
INFO - 2022-06-28 08:53:21 --> Config Class Initialized
INFO - 2022-06-28 08:53:21 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:53:21 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:53:21 --> Utf8 Class Initialized
INFO - 2022-06-28 08:53:21 --> URI Class Initialized
INFO - 2022-06-28 08:53:21 --> Router Class Initialized
INFO - 2022-06-28 08:53:21 --> Output Class Initialized
INFO - 2022-06-28 08:53:21 --> Security Class Initialized
DEBUG - 2022-06-28 08:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:53:21 --> Input Class Initialized
INFO - 2022-06-28 08:53:21 --> Language Class Initialized
INFO - 2022-06-28 08:53:21 --> Loader Class Initialized
INFO - 2022-06-28 08:53:21 --> Helper loaded: url_helper
INFO - 2022-06-28 08:53:21 --> Helper loaded: file_helper
INFO - 2022-06-28 08:53:21 --> Database Driver Class Initialized
INFO - 2022-06-28 08:53:21 --> Email Class Initialized
DEBUG - 2022-06-28 08:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:53:21 --> Controller Class Initialized
INFO - 2022-06-28 08:53:21 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:53:21 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:53:21 --> Final output sent to browser
DEBUG - 2022-06-28 08:53:21 --> Total execution time: 0.0331
INFO - 2022-06-28 08:53:21 --> Config Class Initialized
INFO - 2022-06-28 08:53:21 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:53:21 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:53:21 --> Utf8 Class Initialized
INFO - 2022-06-28 08:53:21 --> URI Class Initialized
INFO - 2022-06-28 08:53:21 --> Router Class Initialized
INFO - 2022-06-28 08:53:21 --> Output Class Initialized
INFO - 2022-06-28 08:53:21 --> Security Class Initialized
DEBUG - 2022-06-28 08:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:53:21 --> Input Class Initialized
INFO - 2022-06-28 08:53:21 --> Language Class Initialized
INFO - 2022-06-28 08:53:21 --> Loader Class Initialized
INFO - 2022-06-28 08:53:21 --> Helper loaded: url_helper
INFO - 2022-06-28 08:53:21 --> Helper loaded: file_helper
INFO - 2022-06-28 08:53:21 --> Database Driver Class Initialized
INFO - 2022-06-28 08:53:21 --> Config Class Initialized
INFO - 2022-06-28 08:53:21 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:53:21 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:53:21 --> Utf8 Class Initialized
INFO - 2022-06-28 08:53:21 --> URI Class Initialized
INFO - 2022-06-28 08:53:21 --> Router Class Initialized
INFO - 2022-06-28 08:53:21 --> Output Class Initialized
INFO - 2022-06-28 08:53:21 --> Security Class Initialized
DEBUG - 2022-06-28 08:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:53:21 --> Input Class Initialized
INFO - 2022-06-28 08:53:21 --> Language Class Initialized
INFO - 2022-06-28 08:53:21 --> Loader Class Initialized
INFO - 2022-06-28 08:53:21 --> Helper loaded: url_helper
INFO - 2022-06-28 08:53:21 --> Helper loaded: file_helper
INFO - 2022-06-28 08:53:21 --> Database Driver Class Initialized
INFO - 2022-06-28 08:53:21 --> Email Class Initialized
DEBUG - 2022-06-28 08:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:53:21 --> Controller Class Initialized
INFO - 2022-06-28 08:53:21 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:53:21 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:53:21 --> Final output sent to browser
DEBUG - 2022-06-28 08:53:21 --> Total execution time: 0.1385
INFO - 2022-06-28 08:53:21 --> Email Class Initialized
DEBUG - 2022-06-28 08:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:53:21 --> Controller Class Initialized
INFO - 2022-06-28 08:53:21 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:53:21 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:53:21 --> Final output sent to browser
DEBUG - 2022-06-28 08:53:21 --> Total execution time: 0.1493
INFO - 2022-06-28 08:53:21 --> Config Class Initialized
INFO - 2022-06-28 08:53:21 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:53:21 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:53:21 --> Utf8 Class Initialized
INFO - 2022-06-28 08:53:21 --> URI Class Initialized
INFO - 2022-06-28 08:53:21 --> Router Class Initialized
INFO - 2022-06-28 08:53:21 --> Output Class Initialized
INFO - 2022-06-28 08:53:21 --> Security Class Initialized
DEBUG - 2022-06-28 08:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:53:21 --> Input Class Initialized
INFO - 2022-06-28 08:53:21 --> Language Class Initialized
INFO - 2022-06-28 08:53:21 --> Loader Class Initialized
INFO - 2022-06-28 08:53:21 --> Helper loaded: url_helper
INFO - 2022-06-28 08:53:21 --> Helper loaded: file_helper
INFO - 2022-06-28 08:53:21 --> Database Driver Class Initialized
INFO - 2022-06-28 08:53:22 --> Email Class Initialized
DEBUG - 2022-06-28 08:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:53:22 --> Controller Class Initialized
INFO - 2022-06-28 08:53:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:53:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:53:22 --> Final output sent to browser
DEBUG - 2022-06-28 08:53:22 --> Total execution time: 0.0986
INFO - 2022-06-28 08:53:22 --> Config Class Initialized
INFO - 2022-06-28 08:53:22 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:53:22 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:53:22 --> Utf8 Class Initialized
INFO - 2022-06-28 08:53:22 --> URI Class Initialized
INFO - 2022-06-28 08:53:22 --> Router Class Initialized
INFO - 2022-06-28 08:53:22 --> Output Class Initialized
INFO - 2022-06-28 08:53:22 --> Security Class Initialized
DEBUG - 2022-06-28 08:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:53:22 --> Input Class Initialized
INFO - 2022-06-28 08:53:22 --> Language Class Initialized
INFO - 2022-06-28 08:53:22 --> Loader Class Initialized
INFO - 2022-06-28 08:53:22 --> Helper loaded: url_helper
INFO - 2022-06-28 08:53:22 --> Helper loaded: file_helper
INFO - 2022-06-28 08:53:22 --> Database Driver Class Initialized
INFO - 2022-06-28 08:53:22 --> Email Class Initialized
DEBUG - 2022-06-28 08:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:53:22 --> Controller Class Initialized
INFO - 2022-06-28 08:53:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:53:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:53:22 --> Final output sent to browser
DEBUG - 2022-06-28 08:53:22 --> Total execution time: 0.0494
INFO - 2022-06-28 08:53:22 --> Config Class Initialized
INFO - 2022-06-28 08:53:22 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:53:22 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:53:22 --> Utf8 Class Initialized
INFO - 2022-06-28 08:53:22 --> URI Class Initialized
INFO - 2022-06-28 08:53:22 --> Router Class Initialized
INFO - 2022-06-28 08:53:22 --> Output Class Initialized
INFO - 2022-06-28 08:53:22 --> Security Class Initialized
DEBUG - 2022-06-28 08:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:53:22 --> Input Class Initialized
INFO - 2022-06-28 08:53:22 --> Language Class Initialized
INFO - 2022-06-28 08:53:22 --> Loader Class Initialized
INFO - 2022-06-28 08:53:22 --> Helper loaded: url_helper
INFO - 2022-06-28 08:53:22 --> Helper loaded: file_helper
INFO - 2022-06-28 08:53:22 --> Database Driver Class Initialized
INFO - 2022-06-28 08:53:22 --> Email Class Initialized
DEBUG - 2022-06-28 08:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:53:22 --> Controller Class Initialized
INFO - 2022-06-28 08:53:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:53:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:53:22 --> Final output sent to browser
DEBUG - 2022-06-28 08:53:22 --> Total execution time: 0.0407
INFO - 2022-06-28 08:53:22 --> Config Class Initialized
INFO - 2022-06-28 08:53:22 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:53:22 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:53:22 --> Utf8 Class Initialized
INFO - 2022-06-28 08:53:22 --> URI Class Initialized
INFO - 2022-06-28 08:53:22 --> Router Class Initialized
INFO - 2022-06-28 08:53:22 --> Output Class Initialized
INFO - 2022-06-28 08:53:22 --> Security Class Initialized
DEBUG - 2022-06-28 08:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:53:22 --> Input Class Initialized
INFO - 2022-06-28 08:53:22 --> Language Class Initialized
INFO - 2022-06-28 08:53:22 --> Loader Class Initialized
INFO - 2022-06-28 08:53:22 --> Helper loaded: url_helper
INFO - 2022-06-28 08:53:22 --> Helper loaded: file_helper
INFO - 2022-06-28 08:53:22 --> Database Driver Class Initialized
INFO - 2022-06-28 08:53:22 --> Email Class Initialized
DEBUG - 2022-06-28 08:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:53:22 --> Controller Class Initialized
INFO - 2022-06-28 08:53:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:53:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:53:22 --> Final output sent to browser
DEBUG - 2022-06-28 08:53:22 --> Total execution time: 0.0346
INFO - 2022-06-28 08:53:22 --> Config Class Initialized
INFO - 2022-06-28 08:53:22 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:53:22 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:53:22 --> Utf8 Class Initialized
INFO - 2022-06-28 08:53:22 --> URI Class Initialized
INFO - 2022-06-28 08:53:22 --> Router Class Initialized
INFO - 2022-06-28 08:53:22 --> Output Class Initialized
INFO - 2022-06-28 08:53:22 --> Security Class Initialized
DEBUG - 2022-06-28 08:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:53:22 --> Input Class Initialized
INFO - 2022-06-28 08:53:22 --> Language Class Initialized
INFO - 2022-06-28 08:53:22 --> Loader Class Initialized
INFO - 2022-06-28 08:53:22 --> Helper loaded: url_helper
INFO - 2022-06-28 08:53:22 --> Helper loaded: file_helper
INFO - 2022-06-28 08:53:22 --> Database Driver Class Initialized
INFO - 2022-06-28 08:53:22 --> Email Class Initialized
DEBUG - 2022-06-28 08:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:53:22 --> Controller Class Initialized
INFO - 2022-06-28 08:53:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:53:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:53:22 --> Final output sent to browser
DEBUG - 2022-06-28 08:53:22 --> Total execution time: 0.0159
INFO - 2022-06-28 08:53:22 --> Config Class Initialized
INFO - 2022-06-28 08:53:22 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:53:22 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:53:22 --> Utf8 Class Initialized
INFO - 2022-06-28 08:53:22 --> URI Class Initialized
INFO - 2022-06-28 08:53:22 --> Router Class Initialized
INFO - 2022-06-28 08:53:22 --> Output Class Initialized
INFO - 2022-06-28 08:53:22 --> Security Class Initialized
DEBUG - 2022-06-28 08:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:53:22 --> Input Class Initialized
INFO - 2022-06-28 08:53:22 --> Language Class Initialized
INFO - 2022-06-28 08:53:22 --> Loader Class Initialized
INFO - 2022-06-28 08:53:22 --> Helper loaded: url_helper
INFO - 2022-06-28 08:53:22 --> Helper loaded: file_helper
INFO - 2022-06-28 08:53:22 --> Database Driver Class Initialized
INFO - 2022-06-28 08:53:22 --> Email Class Initialized
DEBUG - 2022-06-28 08:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:53:22 --> Controller Class Initialized
INFO - 2022-06-28 08:53:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:53:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:53:22 --> Final output sent to browser
DEBUG - 2022-06-28 08:53:22 --> Total execution time: 0.0160
INFO - 2022-06-28 08:53:22 --> Config Class Initialized
INFO - 2022-06-28 08:53:22 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:53:22 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:53:22 --> Utf8 Class Initialized
INFO - 2022-06-28 08:53:22 --> URI Class Initialized
INFO - 2022-06-28 08:53:22 --> Router Class Initialized
INFO - 2022-06-28 08:53:22 --> Output Class Initialized
INFO - 2022-06-28 08:53:22 --> Security Class Initialized
DEBUG - 2022-06-28 08:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:53:22 --> Input Class Initialized
INFO - 2022-06-28 08:53:22 --> Language Class Initialized
INFO - 2022-06-28 08:53:22 --> Loader Class Initialized
INFO - 2022-06-28 08:53:22 --> Helper loaded: url_helper
INFO - 2022-06-28 08:53:22 --> Helper loaded: file_helper
INFO - 2022-06-28 08:53:22 --> Database Driver Class Initialized
INFO - 2022-06-28 08:53:22 --> Config Class Initialized
INFO - 2022-06-28 08:53:22 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:53:22 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:53:22 --> Utf8 Class Initialized
INFO - 2022-06-28 08:53:22 --> URI Class Initialized
INFO - 2022-06-28 08:53:22 --> Router Class Initialized
INFO - 2022-06-28 08:53:22 --> Output Class Initialized
INFO - 2022-06-28 08:53:22 --> Security Class Initialized
DEBUG - 2022-06-28 08:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:53:22 --> Input Class Initialized
INFO - 2022-06-28 08:53:22 --> Language Class Initialized
INFO - 2022-06-28 08:53:22 --> Loader Class Initialized
INFO - 2022-06-28 08:53:22 --> Helper loaded: url_helper
INFO - 2022-06-28 08:53:22 --> Helper loaded: file_helper
INFO - 2022-06-28 08:53:22 --> Database Driver Class Initialized
INFO - 2022-06-28 08:53:22 --> Email Class Initialized
DEBUG - 2022-06-28 08:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:53:22 --> Controller Class Initialized
INFO - 2022-06-28 08:53:22 --> Email Class Initialized
INFO - 2022-06-28 08:53:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:53:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-28 08:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:53:22 --> Final output sent to browser
DEBUG - 2022-06-28 08:53:22 --> Total execution time: 0.0455
INFO - 2022-06-28 08:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:53:22 --> Controller Class Initialized
INFO - 2022-06-28 08:53:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:53:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:53:22 --> Final output sent to browser
DEBUG - 2022-06-28 08:53:22 --> Total execution time: 0.1540
INFO - 2022-06-28 08:53:22 --> Config Class Initialized
INFO - 2022-06-28 08:53:22 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:53:22 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:53:22 --> Utf8 Class Initialized
INFO - 2022-06-28 08:53:22 --> URI Class Initialized
INFO - 2022-06-28 08:53:22 --> Router Class Initialized
INFO - 2022-06-28 08:53:22 --> Output Class Initialized
INFO - 2022-06-28 08:53:22 --> Security Class Initialized
DEBUG - 2022-06-28 08:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:53:22 --> Input Class Initialized
INFO - 2022-06-28 08:53:22 --> Language Class Initialized
INFO - 2022-06-28 08:53:22 --> Loader Class Initialized
INFO - 2022-06-28 08:53:22 --> Helper loaded: url_helper
INFO - 2022-06-28 08:53:22 --> Helper loaded: file_helper
INFO - 2022-06-28 08:53:22 --> Database Driver Class Initialized
INFO - 2022-06-28 08:53:22 --> Email Class Initialized
DEBUG - 2022-06-28 08:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:53:22 --> Controller Class Initialized
INFO - 2022-06-28 08:53:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:53:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:53:22 --> Final output sent to browser
DEBUG - 2022-06-28 08:53:22 --> Total execution time: 0.0157
INFO - 2022-06-28 08:53:22 --> Config Class Initialized
INFO - 2022-06-28 08:53:22 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:53:22 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:53:22 --> Utf8 Class Initialized
INFO - 2022-06-28 08:53:22 --> URI Class Initialized
INFO - 2022-06-28 08:53:22 --> Router Class Initialized
INFO - 2022-06-28 08:53:22 --> Output Class Initialized
INFO - 2022-06-28 08:53:22 --> Security Class Initialized
DEBUG - 2022-06-28 08:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:53:22 --> Input Class Initialized
INFO - 2022-06-28 08:53:22 --> Language Class Initialized
INFO - 2022-06-28 08:53:22 --> Loader Class Initialized
INFO - 2022-06-28 08:53:22 --> Helper loaded: url_helper
INFO - 2022-06-28 08:53:22 --> Helper loaded: file_helper
INFO - 2022-06-28 08:53:22 --> Database Driver Class Initialized
INFO - 2022-06-28 08:53:22 --> Email Class Initialized
DEBUG - 2022-06-28 08:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:53:23 --> Controller Class Initialized
INFO - 2022-06-28 08:53:23 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:53:23 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:53:23 --> Final output sent to browser
DEBUG - 2022-06-28 08:53:23 --> Total execution time: 0.0272
INFO - 2022-06-28 08:53:23 --> Config Class Initialized
INFO - 2022-06-28 08:53:23 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:53:23 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:53:23 --> Utf8 Class Initialized
INFO - 2022-06-28 08:53:23 --> URI Class Initialized
INFO - 2022-06-28 08:53:23 --> Router Class Initialized
INFO - 2022-06-28 08:53:23 --> Output Class Initialized
INFO - 2022-06-28 08:53:23 --> Security Class Initialized
DEBUG - 2022-06-28 08:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:53:23 --> Input Class Initialized
INFO - 2022-06-28 08:53:23 --> Language Class Initialized
INFO - 2022-06-28 08:53:23 --> Loader Class Initialized
INFO - 2022-06-28 08:53:23 --> Helper loaded: url_helper
INFO - 2022-06-28 08:53:23 --> Helper loaded: file_helper
INFO - 2022-06-28 08:53:23 --> Database Driver Class Initialized
INFO - 2022-06-28 08:53:23 --> Email Class Initialized
DEBUG - 2022-06-28 08:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:53:23 --> Controller Class Initialized
INFO - 2022-06-28 08:53:23 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:53:23 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:53:23 --> Final output sent to browser
DEBUG - 2022-06-28 08:53:23 --> Total execution time: 0.0325
INFO - 2022-06-28 08:53:23 --> Config Class Initialized
INFO - 2022-06-28 08:53:23 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:53:23 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:53:23 --> Utf8 Class Initialized
INFO - 2022-06-28 08:53:23 --> URI Class Initialized
INFO - 2022-06-28 08:53:23 --> Router Class Initialized
INFO - 2022-06-28 08:53:23 --> Output Class Initialized
INFO - 2022-06-28 08:53:23 --> Security Class Initialized
DEBUG - 2022-06-28 08:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:53:23 --> Input Class Initialized
INFO - 2022-06-28 08:53:23 --> Language Class Initialized
INFO - 2022-06-28 08:53:23 --> Loader Class Initialized
INFO - 2022-06-28 08:53:23 --> Helper loaded: url_helper
INFO - 2022-06-28 08:53:23 --> Helper loaded: file_helper
INFO - 2022-06-28 08:53:23 --> Database Driver Class Initialized
INFO - 2022-06-28 08:53:23 --> Email Class Initialized
DEBUG - 2022-06-28 08:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:53:23 --> Controller Class Initialized
INFO - 2022-06-28 08:53:23 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:53:23 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:53:23 --> Final output sent to browser
DEBUG - 2022-06-28 08:53:23 --> Total execution time: 0.0293
INFO - 2022-06-28 08:53:23 --> Config Class Initialized
INFO - 2022-06-28 08:53:23 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:53:23 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:53:23 --> Utf8 Class Initialized
INFO - 2022-06-28 08:53:23 --> URI Class Initialized
INFO - 2022-06-28 08:53:23 --> Router Class Initialized
INFO - 2022-06-28 08:53:23 --> Output Class Initialized
INFO - 2022-06-28 08:53:23 --> Security Class Initialized
DEBUG - 2022-06-28 08:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:53:23 --> Input Class Initialized
INFO - 2022-06-28 08:53:23 --> Language Class Initialized
INFO - 2022-06-28 08:53:23 --> Loader Class Initialized
INFO - 2022-06-28 08:53:23 --> Helper loaded: url_helper
INFO - 2022-06-28 08:53:23 --> Helper loaded: file_helper
INFO - 2022-06-28 08:53:23 --> Database Driver Class Initialized
INFO - 2022-06-28 08:53:23 --> Email Class Initialized
DEBUG - 2022-06-28 08:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:53:23 --> Controller Class Initialized
INFO - 2022-06-28 08:53:23 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:53:23 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:53:23 --> Final output sent to browser
DEBUG - 2022-06-28 08:53:23 --> Total execution time: 0.0161
INFO - 2022-06-28 08:53:23 --> Config Class Initialized
INFO - 2022-06-28 08:53:23 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:53:23 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:53:23 --> Utf8 Class Initialized
INFO - 2022-06-28 08:53:23 --> URI Class Initialized
INFO - 2022-06-28 08:53:23 --> Router Class Initialized
INFO - 2022-06-28 08:53:23 --> Output Class Initialized
INFO - 2022-06-28 08:53:23 --> Security Class Initialized
DEBUG - 2022-06-28 08:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:53:23 --> Input Class Initialized
INFO - 2022-06-28 08:53:23 --> Language Class Initialized
INFO - 2022-06-28 08:53:23 --> Loader Class Initialized
INFO - 2022-06-28 08:53:23 --> Helper loaded: url_helper
INFO - 2022-06-28 08:53:23 --> Helper loaded: file_helper
INFO - 2022-06-28 08:53:23 --> Database Driver Class Initialized
INFO - 2022-06-28 08:53:23 --> Email Class Initialized
DEBUG - 2022-06-28 08:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:53:23 --> Controller Class Initialized
INFO - 2022-06-28 08:53:23 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:53:23 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:53:23 --> Final output sent to browser
DEBUG - 2022-06-28 08:53:23 --> Total execution time: 0.0158
INFO - 2022-06-28 08:53:23 --> Config Class Initialized
INFO - 2022-06-28 08:53:23 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:53:23 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:53:23 --> Utf8 Class Initialized
INFO - 2022-06-28 08:53:23 --> URI Class Initialized
INFO - 2022-06-28 08:53:23 --> Router Class Initialized
INFO - 2022-06-28 08:53:23 --> Output Class Initialized
INFO - 2022-06-28 08:53:23 --> Security Class Initialized
DEBUG - 2022-06-28 08:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:53:23 --> Input Class Initialized
INFO - 2022-06-28 08:53:23 --> Language Class Initialized
INFO - 2022-06-28 08:53:23 --> Loader Class Initialized
INFO - 2022-06-28 08:53:23 --> Helper loaded: url_helper
INFO - 2022-06-28 08:53:23 --> Helper loaded: file_helper
INFO - 2022-06-28 08:53:23 --> Database Driver Class Initialized
INFO - 2022-06-28 08:53:23 --> Email Class Initialized
DEBUG - 2022-06-28 08:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:53:23 --> Controller Class Initialized
INFO - 2022-06-28 08:53:23 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:53:23 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:53:23 --> Final output sent to browser
DEBUG - 2022-06-28 08:53:23 --> Total execution time: 0.0307
INFO - 2022-06-28 08:53:27 --> Config Class Initialized
INFO - 2022-06-28 08:53:27 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:53:27 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:53:27 --> Utf8 Class Initialized
INFO - 2022-06-28 08:53:27 --> URI Class Initialized
INFO - 2022-06-28 08:53:27 --> Router Class Initialized
INFO - 2022-06-28 08:53:27 --> Output Class Initialized
INFO - 2022-06-28 08:53:27 --> Security Class Initialized
DEBUG - 2022-06-28 08:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:53:27 --> Input Class Initialized
INFO - 2022-06-28 08:53:27 --> Language Class Initialized
INFO - 2022-06-28 08:53:27 --> Loader Class Initialized
INFO - 2022-06-28 08:53:27 --> Helper loaded: url_helper
INFO - 2022-06-28 08:53:27 --> Helper loaded: file_helper
INFO - 2022-06-28 08:53:27 --> Database Driver Class Initialized
INFO - 2022-06-28 08:53:27 --> Email Class Initialized
DEBUG - 2022-06-28 08:53:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:53:27 --> Controller Class Initialized
INFO - 2022-06-28 08:53:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:53:27 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:53:27 --> Final output sent to browser
DEBUG - 2022-06-28 08:53:27 --> Total execution time: 0.0166
INFO - 2022-06-28 08:53:58 --> Config Class Initialized
INFO - 2022-06-28 08:53:58 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:53:58 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:53:58 --> Utf8 Class Initialized
INFO - 2022-06-28 08:53:58 --> URI Class Initialized
INFO - 2022-06-28 08:53:58 --> Router Class Initialized
INFO - 2022-06-28 08:53:58 --> Output Class Initialized
INFO - 2022-06-28 08:53:58 --> Security Class Initialized
DEBUG - 2022-06-28 08:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:53:58 --> Input Class Initialized
INFO - 2022-06-28 08:53:58 --> Language Class Initialized
INFO - 2022-06-28 08:53:58 --> Loader Class Initialized
INFO - 2022-06-28 08:53:58 --> Helper loaded: url_helper
INFO - 2022-06-28 08:53:58 --> Helper loaded: file_helper
INFO - 2022-06-28 08:53:58 --> Database Driver Class Initialized
INFO - 2022-06-28 08:53:58 --> Email Class Initialized
DEBUG - 2022-06-28 08:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:53:58 --> Controller Class Initialized
INFO - 2022-06-28 08:53:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:53:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:53:58 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 08:53:58 --> Final output sent to browser
DEBUG - 2022-06-28 08:53:58 --> Total execution time: 0.0418
INFO - 2022-06-28 08:53:58 --> Config Class Initialized
INFO - 2022-06-28 08:53:58 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:53:58 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:53:58 --> Utf8 Class Initialized
INFO - 2022-06-28 08:54:02 --> Config Class Initialized
INFO - 2022-06-28 08:54:02 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:54:02 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:54:02 --> Utf8 Class Initialized
INFO - 2022-06-28 08:54:02 --> URI Class Initialized
INFO - 2022-06-28 08:54:02 --> Router Class Initialized
INFO - 2022-06-28 08:54:02 --> Output Class Initialized
INFO - 2022-06-28 08:54:02 --> Security Class Initialized
DEBUG - 2022-06-28 08:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:54:02 --> Input Class Initialized
INFO - 2022-06-28 08:54:02 --> Language Class Initialized
INFO - 2022-06-28 08:54:02 --> Loader Class Initialized
INFO - 2022-06-28 08:54:02 --> Helper loaded: url_helper
INFO - 2022-06-28 08:54:02 --> Helper loaded: file_helper
INFO - 2022-06-28 08:54:02 --> Database Driver Class Initialized
INFO - 2022-06-28 08:54:02 --> Email Class Initialized
DEBUG - 2022-06-28 08:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:54:02 --> Controller Class Initialized
INFO - 2022-06-28 08:54:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:54:02 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:54:02 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 08:54:02 --> Final output sent to browser
DEBUG - 2022-06-28 08:54:02 --> Total execution time: 0.1387
INFO - 2022-06-28 08:54:02 --> Config Class Initialized
INFO - 2022-06-28 08:54:02 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:54:02 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:54:02 --> Utf8 Class Initialized
INFO - 2022-06-28 08:54:04 --> Config Class Initialized
INFO - 2022-06-28 08:54:04 --> Hooks Class Initialized
DEBUG - 2022-06-28 08:54:04 --> UTF-8 Support Enabled
INFO - 2022-06-28 08:54:04 --> Utf8 Class Initialized
INFO - 2022-06-28 08:54:04 --> URI Class Initialized
INFO - 2022-06-28 08:54:04 --> Router Class Initialized
INFO - 2022-06-28 08:54:04 --> Output Class Initialized
INFO - 2022-06-28 08:54:04 --> Security Class Initialized
DEBUG - 2022-06-28 08:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 08:54:04 --> Input Class Initialized
INFO - 2022-06-28 08:54:04 --> Language Class Initialized
INFO - 2022-06-28 08:54:04 --> Loader Class Initialized
INFO - 2022-06-28 08:54:04 --> Helper loaded: url_helper
INFO - 2022-06-28 08:54:04 --> Helper loaded: file_helper
INFO - 2022-06-28 08:54:04 --> Database Driver Class Initialized
INFO - 2022-06-28 08:54:04 --> Email Class Initialized
DEBUG - 2022-06-28 08:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 08:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 08:54:04 --> Controller Class Initialized
INFO - 2022-06-28 08:54:04 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 08:54:04 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 08:54:04 --> Final output sent to browser
DEBUG - 2022-06-28 08:54:04 --> Total execution time: 0.0153
INFO - 2022-06-28 09:04:53 --> Config Class Initialized
INFO - 2022-06-28 09:04:53 --> Hooks Class Initialized
DEBUG - 2022-06-28 09:04:53 --> UTF-8 Support Enabled
INFO - 2022-06-28 09:04:53 --> Utf8 Class Initialized
INFO - 2022-06-28 09:04:53 --> URI Class Initialized
INFO - 2022-06-28 09:04:53 --> Router Class Initialized
INFO - 2022-06-28 09:04:53 --> Output Class Initialized
INFO - 2022-06-28 09:04:53 --> Security Class Initialized
DEBUG - 2022-06-28 09:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 09:04:53 --> Input Class Initialized
INFO - 2022-06-28 09:04:53 --> Language Class Initialized
INFO - 2022-06-28 09:04:53 --> Loader Class Initialized
INFO - 2022-06-28 09:04:53 --> Helper loaded: url_helper
INFO - 2022-06-28 09:04:53 --> Helper loaded: file_helper
INFO - 2022-06-28 09:04:53 --> Database Driver Class Initialized
INFO - 2022-06-28 09:04:53 --> Email Class Initialized
DEBUG - 2022-06-28 09:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 09:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 09:04:53 --> Controller Class Initialized
INFO - 2022-06-28 09:04:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 09:04:53 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 09:04:53 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 09:04:53 --> Final output sent to browser
DEBUG - 2022-06-28 09:04:53 --> Total execution time: 0.0294
INFO - 2022-06-28 09:04:56 --> Config Class Initialized
INFO - 2022-06-28 09:04:56 --> Hooks Class Initialized
DEBUG - 2022-06-28 09:04:56 --> UTF-8 Support Enabled
INFO - 2022-06-28 09:04:56 --> Utf8 Class Initialized
INFO - 2022-06-28 09:04:56 --> URI Class Initialized
INFO - 2022-06-28 09:04:56 --> Router Class Initialized
INFO - 2022-06-28 09:04:56 --> Output Class Initialized
INFO - 2022-06-28 09:04:56 --> Security Class Initialized
DEBUG - 2022-06-28 09:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 09:04:56 --> Input Class Initialized
INFO - 2022-06-28 09:04:56 --> Language Class Initialized
INFO - 2022-06-28 09:04:56 --> Loader Class Initialized
INFO - 2022-06-28 09:04:56 --> Helper loaded: url_helper
INFO - 2022-06-28 09:04:56 --> Helper loaded: file_helper
INFO - 2022-06-28 09:04:56 --> Database Driver Class Initialized
INFO - 2022-06-28 09:04:56 --> Email Class Initialized
DEBUG - 2022-06-28 09:04:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 09:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 09:04:56 --> Controller Class Initialized
INFO - 2022-06-28 09:04:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 09:04:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 09:04:56 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 09:04:56 --> Final output sent to browser
DEBUG - 2022-06-28 09:04:56 --> Total execution time: 0.1217
INFO - 2022-06-28 09:05:15 --> Config Class Initialized
INFO - 2022-06-28 09:05:15 --> Hooks Class Initialized
DEBUG - 2022-06-28 09:05:15 --> UTF-8 Support Enabled
INFO - 2022-06-28 09:05:15 --> Utf8 Class Initialized
INFO - 2022-06-28 09:05:15 --> URI Class Initialized
INFO - 2022-06-28 09:05:15 --> Router Class Initialized
INFO - 2022-06-28 09:05:15 --> Output Class Initialized
INFO - 2022-06-28 09:05:15 --> Security Class Initialized
DEBUG - 2022-06-28 09:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 09:05:15 --> Input Class Initialized
INFO - 2022-06-28 09:05:15 --> Language Class Initialized
INFO - 2022-06-28 09:05:15 --> Loader Class Initialized
INFO - 2022-06-28 09:05:15 --> Helper loaded: url_helper
INFO - 2022-06-28 09:05:15 --> Helper loaded: file_helper
INFO - 2022-06-28 09:05:15 --> Database Driver Class Initialized
INFO - 2022-06-28 09:05:15 --> Email Class Initialized
DEBUG - 2022-06-28 09:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 09:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 09:05:15 --> Controller Class Initialized
INFO - 2022-06-28 09:05:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 09:05:15 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 09:05:15 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 09:05:15 --> Final output sent to browser
DEBUG - 2022-06-28 09:05:15 --> Total execution time: 0.0383
INFO - 2022-06-28 09:05:16 --> Config Class Initialized
INFO - 2022-06-28 09:05:16 --> Hooks Class Initialized
DEBUG - 2022-06-28 09:05:16 --> UTF-8 Support Enabled
INFO - 2022-06-28 09:05:16 --> Utf8 Class Initialized
INFO - 2022-06-28 09:05:16 --> URI Class Initialized
INFO - 2022-06-28 09:05:16 --> Router Class Initialized
INFO - 2022-06-28 09:05:16 --> Output Class Initialized
INFO - 2022-06-28 09:05:16 --> Security Class Initialized
DEBUG - 2022-06-28 09:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 09:05:16 --> Input Class Initialized
INFO - 2022-06-28 09:05:16 --> Language Class Initialized
INFO - 2022-06-28 09:05:16 --> Loader Class Initialized
INFO - 2022-06-28 09:05:16 --> Helper loaded: url_helper
INFO - 2022-06-28 09:05:16 --> Helper loaded: file_helper
INFO - 2022-06-28 09:05:17 --> Database Driver Class Initialized
INFO - 2022-06-28 09:05:17 --> Email Class Initialized
DEBUG - 2022-06-28 09:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 09:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 09:05:17 --> Controller Class Initialized
INFO - 2022-06-28 09:05:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 09:05:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 09:05:17 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 09:05:17 --> Final output sent to browser
DEBUG - 2022-06-28 09:05:17 --> Total execution time: 0.1163
INFO - 2022-06-28 09:05:21 --> Config Class Initialized
INFO - 2022-06-28 09:05:21 --> Hooks Class Initialized
DEBUG - 2022-06-28 09:05:21 --> UTF-8 Support Enabled
INFO - 2022-06-28 09:05:21 --> Utf8 Class Initialized
INFO - 2022-06-28 09:05:21 --> URI Class Initialized
INFO - 2022-06-28 09:05:21 --> Router Class Initialized
INFO - 2022-06-28 09:05:21 --> Output Class Initialized
INFO - 2022-06-28 09:05:21 --> Security Class Initialized
DEBUG - 2022-06-28 09:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 09:05:21 --> Input Class Initialized
INFO - 2022-06-28 09:05:21 --> Language Class Initialized
INFO - 2022-06-28 09:05:21 --> Loader Class Initialized
INFO - 2022-06-28 09:05:21 --> Helper loaded: url_helper
INFO - 2022-06-28 09:05:21 --> Helper loaded: file_helper
INFO - 2022-06-28 09:05:21 --> Database Driver Class Initialized
INFO - 2022-06-28 09:05:21 --> Email Class Initialized
DEBUG - 2022-06-28 09:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 09:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 09:05:21 --> Controller Class Initialized
INFO - 2022-06-28 09:05:21 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 09:05:21 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 09:05:21 --> Final output sent to browser
DEBUG - 2022-06-28 09:05:21 --> Total execution time: 0.0414
INFO - 2022-06-28 09:05:22 --> Config Class Initialized
INFO - 2022-06-28 09:05:22 --> Hooks Class Initialized
DEBUG - 2022-06-28 09:05:22 --> UTF-8 Support Enabled
INFO - 2022-06-28 09:05:22 --> Utf8 Class Initialized
INFO - 2022-06-28 09:05:22 --> URI Class Initialized
INFO - 2022-06-28 09:05:22 --> Router Class Initialized
INFO - 2022-06-28 09:05:22 --> Output Class Initialized
INFO - 2022-06-28 09:05:22 --> Security Class Initialized
DEBUG - 2022-06-28 09:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 09:05:22 --> Input Class Initialized
INFO - 2022-06-28 09:05:22 --> Language Class Initialized
INFO - 2022-06-28 09:05:22 --> Loader Class Initialized
INFO - 2022-06-28 09:05:22 --> Helper loaded: url_helper
INFO - 2022-06-28 09:05:22 --> Helper loaded: file_helper
INFO - 2022-06-28 09:05:22 --> Database Driver Class Initialized
INFO - 2022-06-28 09:05:22 --> Email Class Initialized
DEBUG - 2022-06-28 09:05:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 09:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 09:05:22 --> Controller Class Initialized
INFO - 2022-06-28 09:05:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 09:05:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 09:05:22 --> Final output sent to browser
DEBUG - 2022-06-28 09:05:22 --> Total execution time: 0.0165
INFO - 2022-06-28 09:05:22 --> Config Class Initialized
INFO - 2022-06-28 09:05:22 --> Hooks Class Initialized
DEBUG - 2022-06-28 09:05:22 --> UTF-8 Support Enabled
INFO - 2022-06-28 09:05:22 --> Utf8 Class Initialized
INFO - 2022-06-28 09:05:22 --> URI Class Initialized
INFO - 2022-06-28 09:05:22 --> Router Class Initialized
INFO - 2022-06-28 09:05:22 --> Output Class Initialized
INFO - 2022-06-28 09:05:22 --> Security Class Initialized
DEBUG - 2022-06-28 09:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 09:05:22 --> Input Class Initialized
INFO - 2022-06-28 09:05:22 --> Language Class Initialized
INFO - 2022-06-28 09:05:22 --> Loader Class Initialized
INFO - 2022-06-28 09:05:22 --> Helper loaded: url_helper
INFO - 2022-06-28 09:05:22 --> Helper loaded: file_helper
INFO - 2022-06-28 09:05:22 --> Database Driver Class Initialized
INFO - 2022-06-28 09:05:22 --> Email Class Initialized
DEBUG - 2022-06-28 09:05:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 09:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 09:05:22 --> Controller Class Initialized
INFO - 2022-06-28 09:05:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 09:05:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 09:05:22 --> Final output sent to browser
DEBUG - 2022-06-28 09:05:22 --> Total execution time: 0.0359
INFO - 2022-06-28 09:05:22 --> Config Class Initialized
INFO - 2022-06-28 09:05:22 --> Hooks Class Initialized
DEBUG - 2022-06-28 09:05:22 --> UTF-8 Support Enabled
INFO - 2022-06-28 09:05:22 --> Utf8 Class Initialized
INFO - 2022-06-28 09:05:22 --> URI Class Initialized
INFO - 2022-06-28 09:05:22 --> Router Class Initialized
INFO - 2022-06-28 09:05:22 --> Output Class Initialized
INFO - 2022-06-28 09:05:22 --> Security Class Initialized
DEBUG - 2022-06-28 09:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 09:05:22 --> Input Class Initialized
INFO - 2022-06-28 09:05:22 --> Language Class Initialized
INFO - 2022-06-28 09:05:22 --> Loader Class Initialized
INFO - 2022-06-28 09:05:22 --> Helper loaded: url_helper
INFO - 2022-06-28 09:05:22 --> Helper loaded: file_helper
INFO - 2022-06-28 09:05:22 --> Database Driver Class Initialized
INFO - 2022-06-28 09:05:22 --> Email Class Initialized
DEBUG - 2022-06-28 09:05:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 09:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 09:05:22 --> Controller Class Initialized
INFO - 2022-06-28 09:05:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 09:05:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 09:05:22 --> Final output sent to browser
DEBUG - 2022-06-28 09:05:22 --> Total execution time: 0.0164
INFO - 2022-06-28 09:05:23 --> Config Class Initialized
INFO - 2022-06-28 09:05:23 --> Hooks Class Initialized
DEBUG - 2022-06-28 09:05:23 --> UTF-8 Support Enabled
INFO - 2022-06-28 09:05:23 --> Utf8 Class Initialized
INFO - 2022-06-28 09:05:23 --> URI Class Initialized
INFO - 2022-06-28 09:05:23 --> Router Class Initialized
INFO - 2022-06-28 09:05:23 --> Output Class Initialized
INFO - 2022-06-28 09:05:23 --> Security Class Initialized
DEBUG - 2022-06-28 09:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 09:05:23 --> Input Class Initialized
INFO - 2022-06-28 09:05:23 --> Language Class Initialized
INFO - 2022-06-28 09:05:23 --> Loader Class Initialized
INFO - 2022-06-28 09:05:23 --> Helper loaded: url_helper
INFO - 2022-06-28 09:05:23 --> Helper loaded: file_helper
INFO - 2022-06-28 09:05:23 --> Database Driver Class Initialized
INFO - 2022-06-28 09:05:23 --> Email Class Initialized
DEBUG - 2022-06-28 09:05:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 09:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 09:05:23 --> Controller Class Initialized
INFO - 2022-06-28 09:05:23 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 09:05:23 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 09:05:23 --> Final output sent to browser
DEBUG - 2022-06-28 09:05:23 --> Total execution time: 0.0316
INFO - 2022-06-28 09:06:20 --> Config Class Initialized
INFO - 2022-06-28 09:06:20 --> Hooks Class Initialized
DEBUG - 2022-06-28 09:06:20 --> UTF-8 Support Enabled
INFO - 2022-06-28 09:06:20 --> Utf8 Class Initialized
INFO - 2022-06-28 09:06:20 --> URI Class Initialized
INFO - 2022-06-28 09:06:20 --> Router Class Initialized
INFO - 2022-06-28 09:06:20 --> Output Class Initialized
INFO - 2022-06-28 09:06:20 --> Security Class Initialized
DEBUG - 2022-06-28 09:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 09:06:20 --> Input Class Initialized
INFO - 2022-06-28 09:06:20 --> Language Class Initialized
INFO - 2022-06-28 09:06:20 --> Loader Class Initialized
INFO - 2022-06-28 09:06:20 --> Helper loaded: url_helper
INFO - 2022-06-28 09:06:20 --> Helper loaded: file_helper
INFO - 2022-06-28 09:06:20 --> Database Driver Class Initialized
INFO - 2022-06-28 09:06:20 --> Email Class Initialized
DEBUG - 2022-06-28 09:06:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 09:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 09:06:20 --> Controller Class Initialized
INFO - 2022-06-28 09:06:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 09:06:20 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 09:06:20 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 09:06:20 --> Final output sent to browser
DEBUG - 2022-06-28 09:06:20 --> Total execution time: 0.0447
INFO - 2022-06-28 09:06:22 --> Config Class Initialized
INFO - 2022-06-28 09:06:22 --> Hooks Class Initialized
DEBUG - 2022-06-28 09:06:22 --> UTF-8 Support Enabled
INFO - 2022-06-28 09:06:22 --> Utf8 Class Initialized
INFO - 2022-06-28 09:06:22 --> URI Class Initialized
INFO - 2022-06-28 09:06:22 --> Router Class Initialized
INFO - 2022-06-28 09:06:22 --> Output Class Initialized
INFO - 2022-06-28 09:06:22 --> Security Class Initialized
DEBUG - 2022-06-28 09:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 09:06:22 --> Input Class Initialized
INFO - 2022-06-28 09:06:22 --> Language Class Initialized
INFO - 2022-06-28 09:06:22 --> Loader Class Initialized
INFO - 2022-06-28 09:06:22 --> Helper loaded: url_helper
INFO - 2022-06-28 09:06:22 --> Helper loaded: file_helper
INFO - 2022-06-28 09:06:22 --> Database Driver Class Initialized
INFO - 2022-06-28 09:06:22 --> Email Class Initialized
DEBUG - 2022-06-28 09:06:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 09:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 09:06:22 --> Controller Class Initialized
INFO - 2022-06-28 09:06:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 09:06:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 09:06:22 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 09:06:22 --> Final output sent to browser
DEBUG - 2022-06-28 09:06:22 --> Total execution time: 0.0207
INFO - 2022-06-28 09:06:41 --> Config Class Initialized
INFO - 2022-06-28 09:06:41 --> Hooks Class Initialized
DEBUG - 2022-06-28 09:06:41 --> UTF-8 Support Enabled
INFO - 2022-06-28 09:06:41 --> Utf8 Class Initialized
INFO - 2022-06-28 09:06:41 --> URI Class Initialized
INFO - 2022-06-28 09:06:41 --> Router Class Initialized
INFO - 2022-06-28 09:06:41 --> Output Class Initialized
INFO - 2022-06-28 09:06:41 --> Security Class Initialized
DEBUG - 2022-06-28 09:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 09:06:41 --> Input Class Initialized
INFO - 2022-06-28 09:06:41 --> Language Class Initialized
INFO - 2022-06-28 09:06:41 --> Loader Class Initialized
INFO - 2022-06-28 09:06:41 --> Helper loaded: url_helper
INFO - 2022-06-28 09:06:41 --> Helper loaded: file_helper
INFO - 2022-06-28 09:06:41 --> Database Driver Class Initialized
INFO - 2022-06-28 09:06:41 --> Email Class Initialized
DEBUG - 2022-06-28 09:06:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 09:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 09:06:41 --> Controller Class Initialized
INFO - 2022-06-28 09:06:41 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 09:06:41 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 09:06:41 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 09:06:41 --> Final output sent to browser
DEBUG - 2022-06-28 09:06:41 --> Total execution time: 0.1459
INFO - 2022-06-28 09:07:07 --> Config Class Initialized
INFO - 2022-06-28 09:07:07 --> Hooks Class Initialized
DEBUG - 2022-06-28 09:07:07 --> UTF-8 Support Enabled
INFO - 2022-06-28 09:07:07 --> Utf8 Class Initialized
INFO - 2022-06-28 09:07:07 --> URI Class Initialized
INFO - 2022-06-28 09:07:07 --> Router Class Initialized
INFO - 2022-06-28 09:07:07 --> Output Class Initialized
INFO - 2022-06-28 09:07:07 --> Security Class Initialized
DEBUG - 2022-06-28 09:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 09:07:07 --> Input Class Initialized
INFO - 2022-06-28 09:07:07 --> Language Class Initialized
INFO - 2022-06-28 09:07:07 --> Loader Class Initialized
INFO - 2022-06-28 09:07:07 --> Helper loaded: url_helper
INFO - 2022-06-28 09:07:07 --> Helper loaded: file_helper
INFO - 2022-06-28 09:07:07 --> Database Driver Class Initialized
INFO - 2022-06-28 09:07:07 --> Email Class Initialized
DEBUG - 2022-06-28 09:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 09:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 09:07:07 --> Controller Class Initialized
INFO - 2022-06-28 09:07:07 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 09:07:07 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 09:07:07 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 09:07:07 --> Final output sent to browser
DEBUG - 2022-06-28 09:07:07 --> Total execution time: 0.0183
INFO - 2022-06-28 09:07:09 --> Config Class Initialized
INFO - 2022-06-28 09:07:09 --> Hooks Class Initialized
DEBUG - 2022-06-28 09:07:09 --> UTF-8 Support Enabled
INFO - 2022-06-28 09:07:09 --> Utf8 Class Initialized
INFO - 2022-06-28 09:07:09 --> URI Class Initialized
INFO - 2022-06-28 09:07:09 --> Router Class Initialized
INFO - 2022-06-28 09:07:09 --> Output Class Initialized
INFO - 2022-06-28 09:07:09 --> Security Class Initialized
DEBUG - 2022-06-28 09:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 09:07:09 --> Input Class Initialized
INFO - 2022-06-28 09:07:09 --> Language Class Initialized
INFO - 2022-06-28 09:07:09 --> Loader Class Initialized
INFO - 2022-06-28 09:07:09 --> Helper loaded: url_helper
INFO - 2022-06-28 09:07:09 --> Helper loaded: file_helper
INFO - 2022-06-28 09:07:09 --> Database Driver Class Initialized
INFO - 2022-06-28 09:07:09 --> Email Class Initialized
DEBUG - 2022-06-28 09:07:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 09:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 09:07:09 --> Controller Class Initialized
INFO - 2022-06-28 09:07:09 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 09:07:09 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 09:07:09 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 09:07:09 --> Final output sent to browser
DEBUG - 2022-06-28 09:07:09 --> Total execution time: 0.0385
INFO - 2022-06-28 09:07:10 --> Config Class Initialized
INFO - 2022-06-28 09:07:10 --> Hooks Class Initialized
DEBUG - 2022-06-28 09:07:10 --> UTF-8 Support Enabled
INFO - 2022-06-28 09:07:10 --> Utf8 Class Initialized
INFO - 2022-06-28 09:07:10 --> URI Class Initialized
INFO - 2022-06-28 09:07:10 --> Router Class Initialized
INFO - 2022-06-28 09:07:10 --> Output Class Initialized
INFO - 2022-06-28 09:07:10 --> Security Class Initialized
DEBUG - 2022-06-28 09:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 09:07:10 --> Input Class Initialized
INFO - 2022-06-28 09:07:10 --> Language Class Initialized
INFO - 2022-06-28 09:07:10 --> Loader Class Initialized
INFO - 2022-06-28 09:07:10 --> Helper loaded: url_helper
INFO - 2022-06-28 09:07:10 --> Helper loaded: file_helper
INFO - 2022-06-28 09:07:10 --> Database Driver Class Initialized
INFO - 2022-06-28 09:07:10 --> Email Class Initialized
DEBUG - 2022-06-28 09:07:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 09:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 09:07:10 --> Controller Class Initialized
INFO - 2022-06-28 09:07:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 09:07:10 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 09:07:10 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 09:07:10 --> Final output sent to browser
DEBUG - 2022-06-28 09:07:10 --> Total execution time: 0.0396
INFO - 2022-06-28 09:07:11 --> Config Class Initialized
INFO - 2022-06-28 09:07:11 --> Hooks Class Initialized
DEBUG - 2022-06-28 09:07:11 --> UTF-8 Support Enabled
INFO - 2022-06-28 09:07:11 --> Utf8 Class Initialized
INFO - 2022-06-28 09:07:11 --> URI Class Initialized
INFO - 2022-06-28 09:07:11 --> Router Class Initialized
INFO - 2022-06-28 09:07:11 --> Output Class Initialized
INFO - 2022-06-28 09:07:11 --> Security Class Initialized
DEBUG - 2022-06-28 09:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 09:07:11 --> Input Class Initialized
INFO - 2022-06-28 09:07:11 --> Language Class Initialized
INFO - 2022-06-28 09:07:11 --> Loader Class Initialized
INFO - 2022-06-28 09:07:11 --> Helper loaded: url_helper
INFO - 2022-06-28 09:07:11 --> Helper loaded: file_helper
INFO - 2022-06-28 09:07:11 --> Database Driver Class Initialized
INFO - 2022-06-28 09:07:11 --> Email Class Initialized
DEBUG - 2022-06-28 09:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 09:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 09:07:11 --> Controller Class Initialized
INFO - 2022-06-28 09:07:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 09:07:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 09:07:11 --> Final output sent to browser
DEBUG - 2022-06-28 09:07:11 --> Total execution time: 0.0386
INFO - 2022-06-28 09:07:12 --> Config Class Initialized
INFO - 2022-06-28 09:07:12 --> Hooks Class Initialized
DEBUG - 2022-06-28 09:07:12 --> UTF-8 Support Enabled
INFO - 2022-06-28 09:07:12 --> Utf8 Class Initialized
INFO - 2022-06-28 09:07:12 --> URI Class Initialized
INFO - 2022-06-28 09:07:12 --> Router Class Initialized
INFO - 2022-06-28 09:07:12 --> Output Class Initialized
INFO - 2022-06-28 09:07:12 --> Security Class Initialized
DEBUG - 2022-06-28 09:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 09:07:12 --> Input Class Initialized
INFO - 2022-06-28 09:07:12 --> Language Class Initialized
INFO - 2022-06-28 09:07:12 --> Loader Class Initialized
INFO - 2022-06-28 09:07:12 --> Helper loaded: url_helper
INFO - 2022-06-28 09:07:12 --> Helper loaded: file_helper
INFO - 2022-06-28 09:07:12 --> Database Driver Class Initialized
INFO - 2022-06-28 09:07:12 --> Email Class Initialized
DEBUG - 2022-06-28 09:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 09:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 09:07:12 --> Controller Class Initialized
INFO - 2022-06-28 09:07:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 09:07:12 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 09:07:12 --> Final output sent to browser
DEBUG - 2022-06-28 09:07:12 --> Total execution time: 0.0155
INFO - 2022-06-28 09:08:33 --> Config Class Initialized
INFO - 2022-06-28 09:08:33 --> Hooks Class Initialized
DEBUG - 2022-06-28 09:08:33 --> UTF-8 Support Enabled
INFO - 2022-06-28 09:08:33 --> Utf8 Class Initialized
INFO - 2022-06-28 09:08:33 --> URI Class Initialized
INFO - 2022-06-28 09:08:33 --> Router Class Initialized
INFO - 2022-06-28 09:08:33 --> Output Class Initialized
INFO - 2022-06-28 09:08:33 --> Security Class Initialized
DEBUG - 2022-06-28 09:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 09:08:33 --> Input Class Initialized
INFO - 2022-06-28 09:08:33 --> Language Class Initialized
INFO - 2022-06-28 09:08:33 --> Loader Class Initialized
INFO - 2022-06-28 09:08:33 --> Helper loaded: url_helper
INFO - 2022-06-28 09:08:33 --> Helper loaded: file_helper
INFO - 2022-06-28 09:08:33 --> Database Driver Class Initialized
INFO - 2022-06-28 09:08:33 --> Email Class Initialized
DEBUG - 2022-06-28 09:08:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 09:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 09:08:33 --> Controller Class Initialized
INFO - 2022-06-28 09:08:33 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 09:08:33 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 09:08:33 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 09:08:33 --> Final output sent to browser
DEBUG - 2022-06-28 09:08:33 --> Total execution time: 0.0201
INFO - 2022-06-28 09:10:33 --> Config Class Initialized
INFO - 2022-06-28 09:10:33 --> Hooks Class Initialized
DEBUG - 2022-06-28 09:10:33 --> UTF-8 Support Enabled
INFO - 2022-06-28 09:10:33 --> Utf8 Class Initialized
INFO - 2022-06-28 09:10:33 --> URI Class Initialized
INFO - 2022-06-28 09:10:33 --> Router Class Initialized
INFO - 2022-06-28 09:10:33 --> Output Class Initialized
INFO - 2022-06-28 09:10:33 --> Security Class Initialized
DEBUG - 2022-06-28 09:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 09:10:33 --> Input Class Initialized
INFO - 2022-06-28 09:10:33 --> Language Class Initialized
INFO - 2022-06-28 09:10:33 --> Loader Class Initialized
INFO - 2022-06-28 09:10:33 --> Helper loaded: url_helper
INFO - 2022-06-28 09:10:33 --> Helper loaded: file_helper
INFO - 2022-06-28 09:10:33 --> Database Driver Class Initialized
INFO - 2022-06-28 09:10:34 --> Email Class Initialized
DEBUG - 2022-06-28 09:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 09:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 09:10:34 --> Controller Class Initialized
INFO - 2022-06-28 09:10:34 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 09:10:34 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 09:10:34 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 09:10:34 --> Final output sent to browser
DEBUG - 2022-06-28 09:10:34 --> Total execution time: 0.0284
INFO - 2022-06-28 09:10:35 --> Config Class Initialized
INFO - 2022-06-28 09:10:35 --> Hooks Class Initialized
DEBUG - 2022-06-28 09:10:35 --> UTF-8 Support Enabled
INFO - 2022-06-28 09:10:35 --> Utf8 Class Initialized
INFO - 2022-06-28 09:10:35 --> URI Class Initialized
INFO - 2022-06-28 09:10:35 --> Router Class Initialized
INFO - 2022-06-28 09:10:35 --> Output Class Initialized
INFO - 2022-06-28 09:10:35 --> Security Class Initialized
DEBUG - 2022-06-28 09:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 09:10:35 --> Input Class Initialized
INFO - 2022-06-28 09:10:35 --> Language Class Initialized
INFO - 2022-06-28 09:10:35 --> Loader Class Initialized
INFO - 2022-06-28 09:10:35 --> Helper loaded: url_helper
INFO - 2022-06-28 09:10:35 --> Helper loaded: file_helper
INFO - 2022-06-28 09:10:35 --> Database Driver Class Initialized
INFO - 2022-06-28 09:10:35 --> Email Class Initialized
DEBUG - 2022-06-28 09:10:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 09:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 09:10:35 --> Controller Class Initialized
INFO - 2022-06-28 09:10:35 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 09:10:35 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 09:10:35 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 09:10:35 --> Final output sent to browser
DEBUG - 2022-06-28 09:10:35 --> Total execution time: 0.0280
INFO - 2022-06-28 09:12:55 --> Config Class Initialized
INFO - 2022-06-28 09:12:55 --> Hooks Class Initialized
DEBUG - 2022-06-28 09:12:55 --> UTF-8 Support Enabled
INFO - 2022-06-28 09:12:55 --> Utf8 Class Initialized
INFO - 2022-06-28 09:12:55 --> URI Class Initialized
INFO - 2022-06-28 09:12:55 --> Router Class Initialized
INFO - 2022-06-28 09:12:55 --> Output Class Initialized
INFO - 2022-06-28 09:12:55 --> Security Class Initialized
DEBUG - 2022-06-28 09:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 09:12:55 --> Input Class Initialized
INFO - 2022-06-28 09:12:55 --> Language Class Initialized
INFO - 2022-06-28 09:12:55 --> Loader Class Initialized
INFO - 2022-06-28 09:12:55 --> Helper loaded: url_helper
INFO - 2022-06-28 09:12:55 --> Helper loaded: file_helper
INFO - 2022-06-28 09:12:55 --> Database Driver Class Initialized
INFO - 2022-06-28 09:12:55 --> Email Class Initialized
DEBUG - 2022-06-28 09:12:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 09:12:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 09:12:55 --> Controller Class Initialized
INFO - 2022-06-28 09:12:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 09:12:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 09:12:55 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 09:12:55 --> Final output sent to browser
DEBUG - 2022-06-28 09:12:55 --> Total execution time: 0.0316
INFO - 2022-06-28 09:12:57 --> Config Class Initialized
INFO - 2022-06-28 09:12:57 --> Hooks Class Initialized
DEBUG - 2022-06-28 09:12:57 --> UTF-8 Support Enabled
INFO - 2022-06-28 09:12:57 --> Utf8 Class Initialized
INFO - 2022-06-28 09:12:57 --> URI Class Initialized
INFO - 2022-06-28 09:12:57 --> Router Class Initialized
INFO - 2022-06-28 09:12:57 --> Output Class Initialized
INFO - 2022-06-28 09:12:57 --> Security Class Initialized
DEBUG - 2022-06-28 09:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 09:12:57 --> Input Class Initialized
INFO - 2022-06-28 09:12:57 --> Language Class Initialized
INFO - 2022-06-28 09:12:57 --> Loader Class Initialized
INFO - 2022-06-28 09:12:57 --> Helper loaded: url_helper
INFO - 2022-06-28 09:12:57 --> Helper loaded: file_helper
INFO - 2022-06-28 09:12:57 --> Database Driver Class Initialized
INFO - 2022-06-28 09:12:57 --> Email Class Initialized
DEBUG - 2022-06-28 09:12:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 09:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 09:12:57 --> Controller Class Initialized
INFO - 2022-06-28 09:12:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 09:12:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 09:12:57 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 09:12:57 --> Final output sent to browser
DEBUG - 2022-06-28 09:12:57 --> Total execution time: 0.0257
INFO - 2022-06-28 09:13:36 --> Config Class Initialized
INFO - 2022-06-28 09:13:36 --> Hooks Class Initialized
DEBUG - 2022-06-28 09:13:36 --> UTF-8 Support Enabled
INFO - 2022-06-28 09:13:36 --> Utf8 Class Initialized
INFO - 2022-06-28 09:13:36 --> URI Class Initialized
INFO - 2022-06-28 09:13:36 --> Router Class Initialized
INFO - 2022-06-28 09:13:36 --> Output Class Initialized
INFO - 2022-06-28 09:13:36 --> Security Class Initialized
DEBUG - 2022-06-28 09:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 09:13:36 --> Input Class Initialized
INFO - 2022-06-28 09:13:36 --> Language Class Initialized
INFO - 2022-06-28 09:13:36 --> Loader Class Initialized
INFO - 2022-06-28 09:13:36 --> Helper loaded: url_helper
INFO - 2022-06-28 09:13:36 --> Helper loaded: file_helper
INFO - 2022-06-28 09:13:36 --> Database Driver Class Initialized
INFO - 2022-06-28 09:13:36 --> Email Class Initialized
DEBUG - 2022-06-28 09:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 09:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 09:13:36 --> Controller Class Initialized
INFO - 2022-06-28 09:13:36 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 09:13:36 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 09:13:36 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 09:13:36 --> Final output sent to browser
DEBUG - 2022-06-28 09:13:36 --> Total execution time: 0.0179
INFO - 2022-06-28 09:40:14 --> Config Class Initialized
INFO - 2022-06-28 09:40:14 --> Hooks Class Initialized
DEBUG - 2022-06-28 09:40:14 --> UTF-8 Support Enabled
INFO - 2022-06-28 09:40:14 --> Utf8 Class Initialized
INFO - 2022-06-28 09:40:14 --> URI Class Initialized
INFO - 2022-06-28 09:40:14 --> Router Class Initialized
INFO - 2022-06-28 09:40:14 --> Output Class Initialized
INFO - 2022-06-28 09:40:14 --> Security Class Initialized
DEBUG - 2022-06-28 09:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 09:40:14 --> Input Class Initialized
INFO - 2022-06-28 09:40:14 --> Language Class Initialized
INFO - 2022-06-28 09:40:14 --> Loader Class Initialized
INFO - 2022-06-28 09:40:14 --> Helper loaded: url_helper
INFO - 2022-06-28 09:40:14 --> Helper loaded: file_helper
INFO - 2022-06-28 09:40:14 --> Database Driver Class Initialized
INFO - 2022-06-28 09:40:14 --> Email Class Initialized
DEBUG - 2022-06-28 09:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 09:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 09:40:14 --> Controller Class Initialized
INFO - 2022-06-28 09:40:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 09:40:14 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 09:40:14 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 09:40:14 --> Final output sent to browser
DEBUG - 2022-06-28 09:40:14 --> Total execution time: 0.1458
INFO - 2022-06-28 09:40:16 --> Config Class Initialized
INFO - 2022-06-28 09:40:16 --> Hooks Class Initialized
DEBUG - 2022-06-28 09:40:16 --> UTF-8 Support Enabled
INFO - 2022-06-28 09:40:16 --> Utf8 Class Initialized
INFO - 2022-06-28 09:40:16 --> URI Class Initialized
INFO - 2022-06-28 09:40:16 --> Router Class Initialized
INFO - 2022-06-28 09:40:16 --> Output Class Initialized
INFO - 2022-06-28 09:40:16 --> Security Class Initialized
DEBUG - 2022-06-28 09:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 09:40:16 --> Input Class Initialized
INFO - 2022-06-28 09:40:16 --> Language Class Initialized
INFO - 2022-06-28 09:40:16 --> Loader Class Initialized
INFO - 2022-06-28 09:40:16 --> Helper loaded: url_helper
INFO - 2022-06-28 09:40:16 --> Helper loaded: file_helper
INFO - 2022-06-28 09:40:16 --> Database Driver Class Initialized
INFO - 2022-06-28 09:40:16 --> Email Class Initialized
DEBUG - 2022-06-28 09:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 09:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 09:40:16 --> Controller Class Initialized
INFO - 2022-06-28 09:40:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 09:40:16 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 09:40:16 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 09:40:16 --> Final output sent to browser
DEBUG - 2022-06-28 09:40:16 --> Total execution time: 0.1240
INFO - 2022-06-28 09:44:12 --> Config Class Initialized
INFO - 2022-06-28 09:44:12 --> Hooks Class Initialized
DEBUG - 2022-06-28 09:44:12 --> UTF-8 Support Enabled
INFO - 2022-06-28 09:44:12 --> Utf8 Class Initialized
INFO - 2022-06-28 09:44:12 --> URI Class Initialized
INFO - 2022-06-28 09:44:12 --> Router Class Initialized
INFO - 2022-06-28 09:44:12 --> Output Class Initialized
INFO - 2022-06-28 09:44:12 --> Security Class Initialized
DEBUG - 2022-06-28 09:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 09:44:12 --> Input Class Initialized
INFO - 2022-06-28 09:44:12 --> Language Class Initialized
INFO - 2022-06-28 09:44:12 --> Loader Class Initialized
INFO - 2022-06-28 09:44:12 --> Helper loaded: url_helper
INFO - 2022-06-28 09:44:12 --> Helper loaded: file_helper
INFO - 2022-06-28 09:44:12 --> Database Driver Class Initialized
INFO - 2022-06-28 09:44:12 --> Email Class Initialized
DEBUG - 2022-06-28 09:44:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 09:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 09:44:12 --> Controller Class Initialized
INFO - 2022-06-28 09:44:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 09:44:12 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 09:44:12 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 09:44:12 --> Final output sent to browser
DEBUG - 2022-06-28 09:44:12 --> Total execution time: 0.1316
INFO - 2022-06-28 09:50:20 --> Config Class Initialized
INFO - 2022-06-28 09:50:20 --> Hooks Class Initialized
DEBUG - 2022-06-28 09:50:20 --> UTF-8 Support Enabled
INFO - 2022-06-28 09:50:20 --> Utf8 Class Initialized
INFO - 2022-06-28 09:50:20 --> URI Class Initialized
INFO - 2022-06-28 09:50:20 --> Router Class Initialized
INFO - 2022-06-28 09:50:20 --> Output Class Initialized
INFO - 2022-06-28 09:50:20 --> Security Class Initialized
DEBUG - 2022-06-28 09:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 09:50:20 --> Input Class Initialized
INFO - 2022-06-28 09:50:20 --> Language Class Initialized
INFO - 2022-06-28 09:50:20 --> Loader Class Initialized
INFO - 2022-06-28 09:50:20 --> Helper loaded: url_helper
INFO - 2022-06-28 09:50:20 --> Helper loaded: file_helper
INFO - 2022-06-28 09:50:20 --> Database Driver Class Initialized
INFO - 2022-06-28 09:50:20 --> Email Class Initialized
DEBUG - 2022-06-28 09:50:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 09:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 09:50:20 --> Controller Class Initialized
INFO - 2022-06-28 09:50:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 09:50:20 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 09:50:20 --> File loaded: C:\wamp64\www\qr\application\views\reception screen/qr.php
INFO - 2022-06-28 09:50:20 --> Final output sent to browser
DEBUG - 2022-06-28 09:50:20 --> Total execution time: 0.0377
INFO - 2022-06-28 09:50:20 --> Config Class Initialized
INFO - 2022-06-28 09:50:20 --> Hooks Class Initialized
DEBUG - 2022-06-28 09:50:20 --> UTF-8 Support Enabled
INFO - 2022-06-28 09:50:20 --> Utf8 Class Initialized
INFO - 2022-06-28 09:50:20 --> URI Class Initialized
INFO - 2022-06-28 09:50:20 --> Router Class Initialized
INFO - 2022-06-28 09:50:20 --> Output Class Initialized
INFO - 2022-06-28 09:50:20 --> Security Class Initialized
DEBUG - 2022-06-28 09:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 09:50:20 --> Input Class Initialized
INFO - 2022-06-28 09:50:20 --> Language Class Initialized
ERROR - 2022-06-28 09:50:20 --> 404 Page Not Found: Tokenctrl/img
INFO - 2022-06-28 09:56:13 --> Config Class Initialized
INFO - 2022-06-28 09:56:13 --> Hooks Class Initialized
DEBUG - 2022-06-28 09:56:13 --> UTF-8 Support Enabled
INFO - 2022-06-28 09:56:13 --> Utf8 Class Initialized
INFO - 2022-06-28 09:56:13 --> URI Class Initialized
INFO - 2022-06-28 09:56:13 --> Router Class Initialized
INFO - 2022-06-28 09:56:13 --> Output Class Initialized
INFO - 2022-06-28 09:56:13 --> Security Class Initialized
DEBUG - 2022-06-28 09:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 09:56:13 --> Input Class Initialized
INFO - 2022-06-28 09:56:13 --> Language Class Initialized
INFO - 2022-06-28 09:56:13 --> Loader Class Initialized
INFO - 2022-06-28 09:56:13 --> Helper loaded: url_helper
INFO - 2022-06-28 09:56:13 --> Helper loaded: file_helper
INFO - 2022-06-28 09:56:13 --> Database Driver Class Initialized
INFO - 2022-06-28 09:56:13 --> Email Class Initialized
DEBUG - 2022-06-28 09:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 09:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 09:56:13 --> Controller Class Initialized
INFO - 2022-06-28 09:56:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 09:56:13 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 09:56:13 --> File loaded: C:\wamp64\www\qr\application\views\reception screen/qr.php
INFO - 2022-06-28 09:56:13 --> Final output sent to browser
DEBUG - 2022-06-28 09:56:13 --> Total execution time: 0.2082
INFO - 2022-06-28 09:56:13 --> Config Class Initialized
INFO - 2022-06-28 09:56:13 --> Hooks Class Initialized
DEBUG - 2022-06-28 09:56:13 --> UTF-8 Support Enabled
INFO - 2022-06-28 09:56:13 --> Utf8 Class Initialized
INFO - 2022-06-28 09:56:13 --> URI Class Initialized
INFO - 2022-06-28 09:56:13 --> Router Class Initialized
INFO - 2022-06-28 09:56:13 --> Output Class Initialized
INFO - 2022-06-28 09:56:13 --> Security Class Initialized
DEBUG - 2022-06-28 09:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 09:56:13 --> Input Class Initialized
INFO - 2022-06-28 09:56:13 --> Language Class Initialized
ERROR - 2022-06-28 09:56:13 --> 404 Page Not Found: Tokenctrl/img
INFO - 2022-06-28 10:00:50 --> Config Class Initialized
INFO - 2022-06-28 10:00:50 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:00:50 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:00:50 --> Utf8 Class Initialized
INFO - 2022-06-28 10:00:50 --> URI Class Initialized
INFO - 2022-06-28 10:00:50 --> Router Class Initialized
INFO - 2022-06-28 10:00:50 --> Output Class Initialized
INFO - 2022-06-28 10:00:50 --> Security Class Initialized
DEBUG - 2022-06-28 10:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:00:50 --> Input Class Initialized
INFO - 2022-06-28 10:00:50 --> Language Class Initialized
INFO - 2022-06-28 10:00:50 --> Loader Class Initialized
INFO - 2022-06-28 10:00:50 --> Helper loaded: url_helper
INFO - 2022-06-28 10:00:50 --> Helper loaded: file_helper
INFO - 2022-06-28 10:00:50 --> Database Driver Class Initialized
INFO - 2022-06-28 10:00:50 --> Email Class Initialized
DEBUG - 2022-06-28 10:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:00:50 --> Controller Class Initialized
INFO - 2022-06-28 10:00:50 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:00:50 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:00:50 --> File loaded: C:\wamp64\www\qr\application\views\reception screen/qr.php
INFO - 2022-06-28 10:00:50 --> Final output sent to browser
DEBUG - 2022-06-28 10:00:50 --> Total execution time: 0.1545
INFO - 2022-06-28 10:00:50 --> Config Class Initialized
INFO - 2022-06-28 10:00:50 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:00:50 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:00:50 --> Utf8 Class Initialized
INFO - 2022-06-28 10:00:50 --> URI Class Initialized
INFO - 2022-06-28 10:00:50 --> Router Class Initialized
INFO - 2022-06-28 10:00:50 --> Output Class Initialized
INFO - 2022-06-28 10:00:50 --> Security Class Initialized
DEBUG - 2022-06-28 10:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:00:50 --> Input Class Initialized
INFO - 2022-06-28 10:00:50 --> Language Class Initialized
ERROR - 2022-06-28 10:00:50 --> 404 Page Not Found: Tokenctrl/img
INFO - 2022-06-28 10:00:51 --> Config Class Initialized
INFO - 2022-06-28 10:00:51 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:00:51 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:00:51 --> Utf8 Class Initialized
INFO - 2022-06-28 10:00:51 --> URI Class Initialized
INFO - 2022-06-28 10:00:51 --> Router Class Initialized
INFO - 2022-06-28 10:00:51 --> Output Class Initialized
INFO - 2022-06-28 10:00:51 --> Security Class Initialized
DEBUG - 2022-06-28 10:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:00:51 --> Input Class Initialized
INFO - 2022-06-28 10:00:51 --> Language Class Initialized
INFO - 2022-06-28 10:00:51 --> Loader Class Initialized
INFO - 2022-06-28 10:00:51 --> Helper loaded: url_helper
INFO - 2022-06-28 10:00:51 --> Helper loaded: file_helper
INFO - 2022-06-28 10:00:51 --> Database Driver Class Initialized
INFO - 2022-06-28 10:00:51 --> Email Class Initialized
DEBUG - 2022-06-28 10:00:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:00:51 --> Controller Class Initialized
INFO - 2022-06-28 10:00:51 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:00:51 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:00:51 --> File loaded: C:\wamp64\www\qr\application\views\reception screen/qr.php
INFO - 2022-06-28 10:00:51 --> Final output sent to browser
DEBUG - 2022-06-28 10:00:51 --> Total execution time: 0.0380
INFO - 2022-06-28 10:00:51 --> Config Class Initialized
INFO - 2022-06-28 10:00:51 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:00:51 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:00:51 --> Utf8 Class Initialized
INFO - 2022-06-28 10:00:51 --> URI Class Initialized
INFO - 2022-06-28 10:00:51 --> Router Class Initialized
INFO - 2022-06-28 10:00:51 --> Output Class Initialized
INFO - 2022-06-28 10:00:51 --> Security Class Initialized
DEBUG - 2022-06-28 10:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:00:51 --> Input Class Initialized
INFO - 2022-06-28 10:00:51 --> Language Class Initialized
ERROR - 2022-06-28 10:00:51 --> 404 Page Not Found: Tokenctrl/img
INFO - 2022-06-28 10:03:55 --> Config Class Initialized
INFO - 2022-06-28 10:03:55 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:03:55 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:03:55 --> Utf8 Class Initialized
INFO - 2022-06-28 10:03:55 --> URI Class Initialized
INFO - 2022-06-28 10:03:55 --> Router Class Initialized
INFO - 2022-06-28 10:03:55 --> Output Class Initialized
INFO - 2022-06-28 10:03:55 --> Security Class Initialized
DEBUG - 2022-06-28 10:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:03:55 --> Input Class Initialized
INFO - 2022-06-28 10:03:55 --> Language Class Initialized
INFO - 2022-06-28 10:03:55 --> Loader Class Initialized
INFO - 2022-06-28 10:03:55 --> Helper loaded: url_helper
INFO - 2022-06-28 10:03:55 --> Helper loaded: file_helper
INFO - 2022-06-28 10:03:55 --> Database Driver Class Initialized
INFO - 2022-06-28 10:03:55 --> Email Class Initialized
DEBUG - 2022-06-28 10:03:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:03:55 --> Controller Class Initialized
INFO - 2022-06-28 10:03:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:03:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:03:55 --> File loaded: C:\wamp64\www\qr\application\views\reception screen/qr.php
INFO - 2022-06-28 10:03:55 --> Final output sent to browser
DEBUG - 2022-06-28 10:03:55 --> Total execution time: 0.0989
INFO - 2022-06-28 10:03:55 --> Config Class Initialized
INFO - 2022-06-28 10:03:55 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:03:55 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:03:55 --> Utf8 Class Initialized
INFO - 2022-06-28 10:03:55 --> URI Class Initialized
INFO - 2022-06-28 10:03:55 --> Router Class Initialized
INFO - 2022-06-28 10:03:55 --> Output Class Initialized
INFO - 2022-06-28 10:03:55 --> Security Class Initialized
DEBUG - 2022-06-28 10:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:03:55 --> Input Class Initialized
INFO - 2022-06-28 10:03:55 --> Language Class Initialized
ERROR - 2022-06-28 10:03:55 --> 404 Page Not Found: Tokenctrl/img
INFO - 2022-06-28 10:04:21 --> Config Class Initialized
INFO - 2022-06-28 10:04:21 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:04:21 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:04:21 --> Utf8 Class Initialized
INFO - 2022-06-28 10:04:21 --> URI Class Initialized
INFO - 2022-06-28 10:04:21 --> Router Class Initialized
INFO - 2022-06-28 10:04:21 --> Output Class Initialized
INFO - 2022-06-28 10:04:21 --> Security Class Initialized
DEBUG - 2022-06-28 10:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:04:21 --> Input Class Initialized
INFO - 2022-06-28 10:04:21 --> Language Class Initialized
INFO - 2022-06-28 10:04:21 --> Loader Class Initialized
INFO - 2022-06-28 10:04:21 --> Helper loaded: url_helper
INFO - 2022-06-28 10:04:21 --> Helper loaded: file_helper
INFO - 2022-06-28 10:04:21 --> Database Driver Class Initialized
INFO - 2022-06-28 10:04:21 --> Email Class Initialized
DEBUG - 2022-06-28 10:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:04:21 --> Controller Class Initialized
INFO - 2022-06-28 10:04:21 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:04:21 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:04:21 --> File loaded: C:\wamp64\www\qr\application\views\reception screen/qr.php
INFO - 2022-06-28 10:04:21 --> Final output sent to browser
DEBUG - 2022-06-28 10:04:21 --> Total execution time: 0.1468
INFO - 2022-06-28 10:07:19 --> Config Class Initialized
INFO - 2022-06-28 10:07:19 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:07:19 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:07:19 --> Utf8 Class Initialized
INFO - 2022-06-28 10:07:19 --> URI Class Initialized
INFO - 2022-06-28 10:07:19 --> Router Class Initialized
INFO - 2022-06-28 10:07:19 --> Output Class Initialized
INFO - 2022-06-28 10:07:19 --> Security Class Initialized
DEBUG - 2022-06-28 10:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:07:19 --> Input Class Initialized
INFO - 2022-06-28 10:07:19 --> Language Class Initialized
INFO - 2022-06-28 10:07:19 --> Loader Class Initialized
INFO - 2022-06-28 10:07:19 --> Helper loaded: url_helper
INFO - 2022-06-28 10:07:19 --> Helper loaded: file_helper
INFO - 2022-06-28 10:07:19 --> Database Driver Class Initialized
INFO - 2022-06-28 10:07:20 --> Email Class Initialized
DEBUG - 2022-06-28 10:07:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:07:20 --> Controller Class Initialized
INFO - 2022-06-28 10:07:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:07:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 10:07:20 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\reception screen\qr.php 176
INFO - 2022-06-28 10:07:20 --> File loaded: C:\wamp64\www\qr\application\views\reception screen/qr.php
INFO - 2022-06-28 10:07:20 --> Final output sent to browser
DEBUG - 2022-06-28 10:07:20 --> Total execution time: 0.1408
INFO - 2022-06-28 10:10:10 --> Config Class Initialized
INFO - 2022-06-28 10:10:10 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:10:10 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:10:10 --> Utf8 Class Initialized
INFO - 2022-06-28 10:10:10 --> URI Class Initialized
INFO - 2022-06-28 10:10:10 --> Router Class Initialized
INFO - 2022-06-28 10:10:10 --> Output Class Initialized
INFO - 2022-06-28 10:10:10 --> Security Class Initialized
DEBUG - 2022-06-28 10:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:10:10 --> Input Class Initialized
INFO - 2022-06-28 10:10:10 --> Language Class Initialized
INFO - 2022-06-28 10:10:10 --> Loader Class Initialized
INFO - 2022-06-28 10:10:10 --> Helper loaded: url_helper
INFO - 2022-06-28 10:10:10 --> Helper loaded: file_helper
INFO - 2022-06-28 10:10:10 --> Database Driver Class Initialized
INFO - 2022-06-28 10:10:10 --> Email Class Initialized
DEBUG - 2022-06-28 10:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:10:10 --> Controller Class Initialized
INFO - 2022-06-28 10:10:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:10:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 10:10:10 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\reception screen\qr.php 178
INFO - 2022-06-28 10:10:10 --> File loaded: C:\wamp64\www\qr\application\views\reception screen/qr.php
INFO - 2022-06-28 10:10:10 --> Final output sent to browser
DEBUG - 2022-06-28 10:10:10 --> Total execution time: 0.1323
INFO - 2022-06-28 10:10:12 --> Config Class Initialized
INFO - 2022-06-28 10:10:12 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:10:12 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:10:12 --> Utf8 Class Initialized
INFO - 2022-06-28 10:10:12 --> URI Class Initialized
INFO - 2022-06-28 10:10:12 --> Router Class Initialized
INFO - 2022-06-28 10:10:12 --> Output Class Initialized
INFO - 2022-06-28 10:10:12 --> Security Class Initialized
DEBUG - 2022-06-28 10:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:10:12 --> Input Class Initialized
INFO - 2022-06-28 10:10:12 --> Language Class Initialized
INFO - 2022-06-28 10:10:12 --> Loader Class Initialized
INFO - 2022-06-28 10:10:12 --> Helper loaded: url_helper
INFO - 2022-06-28 10:10:12 --> Helper loaded: file_helper
INFO - 2022-06-28 10:10:12 --> Database Driver Class Initialized
INFO - 2022-06-28 10:10:12 --> Email Class Initialized
DEBUG - 2022-06-28 10:10:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:10:12 --> Controller Class Initialized
INFO - 2022-06-28 10:10:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:10:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 10:10:12 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\reception screen\qr.php 178
INFO - 2022-06-28 10:10:12 --> File loaded: C:\wamp64\www\qr\application\views\reception screen/qr.php
INFO - 2022-06-28 10:10:12 --> Final output sent to browser
DEBUG - 2022-06-28 10:10:12 --> Total execution time: 0.0613
INFO - 2022-06-28 10:19:56 --> Config Class Initialized
INFO - 2022-06-28 10:19:56 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:19:56 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:19:56 --> Utf8 Class Initialized
INFO - 2022-06-28 10:19:56 --> URI Class Initialized
INFO - 2022-06-28 10:19:56 --> Router Class Initialized
INFO - 2022-06-28 10:19:56 --> Output Class Initialized
INFO - 2022-06-28 10:19:56 --> Security Class Initialized
DEBUG - 2022-06-28 10:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:19:56 --> Input Class Initialized
INFO - 2022-06-28 10:19:56 --> Language Class Initialized
INFO - 2022-06-28 10:19:56 --> Loader Class Initialized
INFO - 2022-06-28 10:19:56 --> Helper loaded: url_helper
INFO - 2022-06-28 10:19:56 --> Helper loaded: file_helper
INFO - 2022-06-28 10:19:56 --> Database Driver Class Initialized
INFO - 2022-06-28 10:19:57 --> Email Class Initialized
DEBUG - 2022-06-28 10:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:19:57 --> Controller Class Initialized
INFO - 2022-06-28 10:19:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:19:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:19:57 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 10:19:57 --> Final output sent to browser
DEBUG - 2022-06-28 10:19:57 --> Total execution time: 0.1872
INFO - 2022-06-28 10:23:22 --> Config Class Initialized
INFO - 2022-06-28 10:23:22 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:23:22 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:23:22 --> Utf8 Class Initialized
INFO - 2022-06-28 10:23:22 --> URI Class Initialized
INFO - 2022-06-28 10:23:22 --> Router Class Initialized
INFO - 2022-06-28 10:23:22 --> Output Class Initialized
INFO - 2022-06-28 10:23:22 --> Security Class Initialized
DEBUG - 2022-06-28 10:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:23:22 --> Input Class Initialized
INFO - 2022-06-28 10:23:22 --> Language Class Initialized
INFO - 2022-06-28 10:23:22 --> Loader Class Initialized
INFO - 2022-06-28 10:23:22 --> Helper loaded: url_helper
INFO - 2022-06-28 10:23:22 --> Helper loaded: file_helper
INFO - 2022-06-28 10:23:22 --> Database Driver Class Initialized
INFO - 2022-06-28 10:23:23 --> Email Class Initialized
DEBUG - 2022-06-28 10:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:23:23 --> Controller Class Initialized
INFO - 2022-06-28 10:23:23 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:23:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 10:23:23 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\qr\application\views\reception screen\qr.php 165
ERROR - 2022-06-28 10:23:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\wamp64\www\qr\application\views\reception screen\qr.php 165
ERROR - 2022-06-28 10:23:23 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\reception screen\qr.php 178
INFO - 2022-06-28 10:23:23 --> File loaded: C:\wamp64\www\qr\application\views\reception screen/qr.php
INFO - 2022-06-28 10:23:23 --> Final output sent to browser
DEBUG - 2022-06-28 10:23:23 --> Total execution time: 0.8572
INFO - 2022-06-28 10:23:43 --> Config Class Initialized
INFO - 2022-06-28 10:23:43 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:23:43 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:23:43 --> Utf8 Class Initialized
INFO - 2022-06-28 10:23:43 --> URI Class Initialized
INFO - 2022-06-28 10:23:43 --> Router Class Initialized
INFO - 2022-06-28 10:23:43 --> Output Class Initialized
INFO - 2022-06-28 10:23:43 --> Security Class Initialized
DEBUG - 2022-06-28 10:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:23:43 --> Input Class Initialized
INFO - 2022-06-28 10:23:43 --> Language Class Initialized
INFO - 2022-06-28 10:23:43 --> Loader Class Initialized
INFO - 2022-06-28 10:23:43 --> Helper loaded: url_helper
INFO - 2022-06-28 10:23:43 --> Helper loaded: file_helper
INFO - 2022-06-28 10:23:43 --> Database Driver Class Initialized
INFO - 2022-06-28 10:23:44 --> Email Class Initialized
DEBUG - 2022-06-28 10:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:23:44 --> Controller Class Initialized
INFO - 2022-06-28 10:23:44 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:23:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 10:23:44 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\qr\application\views\reception screen\qr.php 165
ERROR - 2022-06-28 10:23:44 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\reception screen\qr.php 178
INFO - 2022-06-28 10:23:44 --> File loaded: C:\wamp64\www\qr\application\views\reception screen/qr.php
INFO - 2022-06-28 10:23:44 --> Final output sent to browser
DEBUG - 2022-06-28 10:23:44 --> Total execution time: 0.9986
INFO - 2022-06-28 10:24:24 --> Config Class Initialized
INFO - 2022-06-28 10:24:24 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:24:24 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:24:24 --> Utf8 Class Initialized
INFO - 2022-06-28 10:24:24 --> URI Class Initialized
INFO - 2022-06-28 10:24:24 --> Router Class Initialized
INFO - 2022-06-28 10:24:24 --> Output Class Initialized
INFO - 2022-06-28 10:24:24 --> Security Class Initialized
DEBUG - 2022-06-28 10:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:24:24 --> Input Class Initialized
INFO - 2022-06-28 10:24:24 --> Language Class Initialized
INFO - 2022-06-28 10:24:24 --> Loader Class Initialized
INFO - 2022-06-28 10:24:24 --> Helper loaded: url_helper
INFO - 2022-06-28 10:24:24 --> Helper loaded: file_helper
INFO - 2022-06-28 10:24:24 --> Database Driver Class Initialized
INFO - 2022-06-28 10:24:25 --> Email Class Initialized
DEBUG - 2022-06-28 10:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:24:25 --> Controller Class Initialized
INFO - 2022-06-28 10:24:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:24:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 10:24:25 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\qr\application\views\reception screen\qr.php 165
ERROR - 2022-06-28 10:24:25 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\reception screen\qr.php 178
INFO - 2022-06-28 10:24:25 --> File loaded: C:\wamp64\www\qr\application\views\reception screen/qr.php
INFO - 2022-06-28 10:24:25 --> Final output sent to browser
DEBUG - 2022-06-28 10:24:25 --> Total execution time: 0.7923
INFO - 2022-06-28 10:25:35 --> Config Class Initialized
INFO - 2022-06-28 10:25:35 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:25:35 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:25:35 --> Utf8 Class Initialized
INFO - 2022-06-28 10:25:35 --> URI Class Initialized
INFO - 2022-06-28 10:25:35 --> Router Class Initialized
INFO - 2022-06-28 10:25:35 --> Output Class Initialized
INFO - 2022-06-28 10:25:35 --> Security Class Initialized
DEBUG - 2022-06-28 10:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:25:35 --> Input Class Initialized
INFO - 2022-06-28 10:25:35 --> Language Class Initialized
INFO - 2022-06-28 10:25:35 --> Loader Class Initialized
INFO - 2022-06-28 10:25:35 --> Helper loaded: url_helper
INFO - 2022-06-28 10:25:35 --> Helper loaded: file_helper
INFO - 2022-06-28 10:25:35 --> Database Driver Class Initialized
INFO - 2022-06-28 10:25:35 --> Email Class Initialized
DEBUG - 2022-06-28 10:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:25:35 --> Controller Class Initialized
INFO - 2022-06-28 10:25:35 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:25:35 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:25:36 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 10:25:36 --> Final output sent to browser
DEBUG - 2022-06-28 10:25:36 --> Total execution time: 0.5704
INFO - 2022-06-28 10:25:42 --> Config Class Initialized
INFO - 2022-06-28 10:25:42 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:25:42 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:25:42 --> Utf8 Class Initialized
INFO - 2022-06-28 10:25:42 --> URI Class Initialized
INFO - 2022-06-28 10:25:42 --> Router Class Initialized
INFO - 2022-06-28 10:25:42 --> Output Class Initialized
INFO - 2022-06-28 10:25:42 --> Security Class Initialized
DEBUG - 2022-06-28 10:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:25:42 --> Input Class Initialized
INFO - 2022-06-28 10:25:42 --> Language Class Initialized
INFO - 2022-06-28 10:25:42 --> Loader Class Initialized
INFO - 2022-06-28 10:25:42 --> Helper loaded: url_helper
INFO - 2022-06-28 10:25:42 --> Helper loaded: file_helper
INFO - 2022-06-28 10:25:42 --> Database Driver Class Initialized
INFO - 2022-06-28 10:25:42 --> Email Class Initialized
DEBUG - 2022-06-28 10:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:25:42 --> Controller Class Initialized
INFO - 2022-06-28 10:25:42 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:25:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 10:25:42 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\qr\application\views\reception screen\qr.php 165
INFO - 2022-06-28 10:25:42 --> File loaded: C:\wamp64\www\qr\application\views\reception screen/qr.php
INFO - 2022-06-28 10:25:42 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 10:25:42 --> Final output sent to browser
DEBUG - 2022-06-28 10:25:42 --> Total execution time: 0.3961
INFO - 2022-06-28 10:25:46 --> Config Class Initialized
INFO - 2022-06-28 10:25:46 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:25:46 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:25:46 --> Utf8 Class Initialized
INFO - 2022-06-28 10:25:46 --> URI Class Initialized
INFO - 2022-06-28 10:25:46 --> Router Class Initialized
INFO - 2022-06-28 10:25:46 --> Output Class Initialized
INFO - 2022-06-28 10:25:46 --> Security Class Initialized
DEBUG - 2022-06-28 10:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:25:46 --> Input Class Initialized
INFO - 2022-06-28 10:25:46 --> Language Class Initialized
INFO - 2022-06-28 10:25:46 --> Loader Class Initialized
INFO - 2022-06-28 10:25:46 --> Helper loaded: url_helper
INFO - 2022-06-28 10:25:46 --> Helper loaded: file_helper
INFO - 2022-06-28 10:25:46 --> Database Driver Class Initialized
INFO - 2022-06-28 10:25:46 --> Email Class Initialized
DEBUG - 2022-06-28 10:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:25:46 --> Controller Class Initialized
INFO - 2022-06-28 10:25:46 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:25:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 10:25:46 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\qr\application\views\reception screen\qr.php 165
INFO - 2022-06-28 10:25:46 --> File loaded: C:\wamp64\www\qr\application\views\reception screen/qr.php
INFO - 2022-06-28 10:25:46 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 10:25:46 --> Final output sent to browser
DEBUG - 2022-06-28 10:25:46 --> Total execution time: 0.2068
INFO - 2022-06-28 10:25:48 --> Config Class Initialized
INFO - 2022-06-28 10:25:48 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:25:48 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:25:48 --> Utf8 Class Initialized
INFO - 2022-06-28 10:25:48 --> URI Class Initialized
INFO - 2022-06-28 10:25:48 --> Router Class Initialized
INFO - 2022-06-28 10:25:48 --> Output Class Initialized
INFO - 2022-06-28 10:25:48 --> Security Class Initialized
DEBUG - 2022-06-28 10:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:25:48 --> Input Class Initialized
INFO - 2022-06-28 10:25:48 --> Language Class Initialized
INFO - 2022-06-28 10:25:48 --> Loader Class Initialized
INFO - 2022-06-28 10:25:48 --> Helper loaded: url_helper
INFO - 2022-06-28 10:25:48 --> Helper loaded: file_helper
INFO - 2022-06-28 10:25:48 --> Database Driver Class Initialized
INFO - 2022-06-28 10:25:48 --> Email Class Initialized
DEBUG - 2022-06-28 10:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:25:48 --> Controller Class Initialized
INFO - 2022-06-28 10:25:48 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:25:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 10:25:48 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\qr\application\views\reception screen\qr.php 165
INFO - 2022-06-28 10:25:48 --> File loaded: C:\wamp64\www\qr\application\views\reception screen/qr.php
INFO - 2022-06-28 10:25:48 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 10:25:48 --> Final output sent to browser
DEBUG - 2022-06-28 10:25:48 --> Total execution time: 0.3549
INFO - 2022-06-28 10:25:50 --> Config Class Initialized
INFO - 2022-06-28 10:25:50 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:25:50 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:25:50 --> Utf8 Class Initialized
INFO - 2022-06-28 10:25:50 --> URI Class Initialized
INFO - 2022-06-28 10:25:50 --> Router Class Initialized
INFO - 2022-06-28 10:25:50 --> Output Class Initialized
INFO - 2022-06-28 10:25:50 --> Security Class Initialized
DEBUG - 2022-06-28 10:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:25:50 --> Input Class Initialized
INFO - 2022-06-28 10:25:50 --> Language Class Initialized
INFO - 2022-06-28 10:25:50 --> Loader Class Initialized
INFO - 2022-06-28 10:25:50 --> Helper loaded: url_helper
INFO - 2022-06-28 10:25:50 --> Helper loaded: file_helper
INFO - 2022-06-28 10:25:50 --> Database Driver Class Initialized
INFO - 2022-06-28 10:25:50 --> Email Class Initialized
DEBUG - 2022-06-28 10:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:25:50 --> Controller Class Initialized
INFO - 2022-06-28 10:25:50 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:25:50 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:25:51 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 10:25:51 --> Final output sent to browser
DEBUG - 2022-06-28 10:25:51 --> Total execution time: 0.6067
INFO - 2022-06-28 10:25:53 --> Config Class Initialized
INFO - 2022-06-28 10:25:53 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:25:53 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:25:53 --> Utf8 Class Initialized
INFO - 2022-06-28 10:25:53 --> URI Class Initialized
INFO - 2022-06-28 10:25:53 --> Router Class Initialized
INFO - 2022-06-28 10:25:53 --> Output Class Initialized
INFO - 2022-06-28 10:25:53 --> Security Class Initialized
DEBUG - 2022-06-28 10:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:25:53 --> Input Class Initialized
INFO - 2022-06-28 10:25:53 --> Language Class Initialized
INFO - 2022-06-28 10:25:53 --> Loader Class Initialized
INFO - 2022-06-28 10:25:53 --> Helper loaded: url_helper
INFO - 2022-06-28 10:25:53 --> Helper loaded: file_helper
INFO - 2022-06-28 10:25:53 --> Database Driver Class Initialized
INFO - 2022-06-28 10:25:53 --> Email Class Initialized
DEBUG - 2022-06-28 10:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:25:53 --> Controller Class Initialized
INFO - 2022-06-28 10:25:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:25:53 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:25:53 --> Final output sent to browser
DEBUG - 2022-06-28 10:25:53 --> Total execution time: 0.1535
INFO - 2022-06-28 10:25:54 --> Config Class Initialized
INFO - 2022-06-28 10:25:54 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:25:54 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:25:54 --> Utf8 Class Initialized
INFO - 2022-06-28 10:25:54 --> URI Class Initialized
INFO - 2022-06-28 10:25:54 --> Router Class Initialized
INFO - 2022-06-28 10:25:54 --> Output Class Initialized
INFO - 2022-06-28 10:25:54 --> Security Class Initialized
DEBUG - 2022-06-28 10:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:25:54 --> Input Class Initialized
INFO - 2022-06-28 10:25:54 --> Language Class Initialized
INFO - 2022-06-28 10:25:54 --> Loader Class Initialized
INFO - 2022-06-28 10:25:54 --> Helper loaded: url_helper
INFO - 2022-06-28 10:25:54 --> Helper loaded: file_helper
INFO - 2022-06-28 10:25:54 --> Database Driver Class Initialized
INFO - 2022-06-28 10:25:54 --> Email Class Initialized
DEBUG - 2022-06-28 10:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:25:54 --> Controller Class Initialized
INFO - 2022-06-28 10:25:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:25:54 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:25:54 --> Final output sent to browser
DEBUG - 2022-06-28 10:25:54 --> Total execution time: 0.0916
INFO - 2022-06-28 10:25:54 --> Config Class Initialized
INFO - 2022-06-28 10:25:54 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:25:54 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:25:54 --> Utf8 Class Initialized
INFO - 2022-06-28 10:25:54 --> URI Class Initialized
INFO - 2022-06-28 10:25:54 --> Router Class Initialized
INFO - 2022-06-28 10:25:54 --> Output Class Initialized
INFO - 2022-06-28 10:25:54 --> Security Class Initialized
DEBUG - 2022-06-28 10:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:25:54 --> Input Class Initialized
INFO - 2022-06-28 10:25:54 --> Language Class Initialized
INFO - 2022-06-28 10:25:54 --> Loader Class Initialized
INFO - 2022-06-28 10:25:54 --> Helper loaded: url_helper
INFO - 2022-06-28 10:25:54 --> Helper loaded: file_helper
INFO - 2022-06-28 10:25:54 --> Database Driver Class Initialized
INFO - 2022-06-28 10:25:54 --> Email Class Initialized
DEBUG - 2022-06-28 10:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:25:54 --> Controller Class Initialized
INFO - 2022-06-28 10:25:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:25:54 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:25:54 --> Final output sent to browser
DEBUG - 2022-06-28 10:25:54 --> Total execution time: 0.1260
INFO - 2022-06-28 10:25:54 --> Config Class Initialized
INFO - 2022-06-28 10:25:54 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:25:54 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:25:54 --> Utf8 Class Initialized
INFO - 2022-06-28 10:25:54 --> URI Class Initialized
INFO - 2022-06-28 10:25:54 --> Router Class Initialized
INFO - 2022-06-28 10:25:54 --> Output Class Initialized
INFO - 2022-06-28 10:25:54 --> Security Class Initialized
DEBUG - 2022-06-28 10:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:25:54 --> Input Class Initialized
INFO - 2022-06-28 10:25:54 --> Language Class Initialized
INFO - 2022-06-28 10:25:54 --> Loader Class Initialized
INFO - 2022-06-28 10:25:54 --> Helper loaded: url_helper
INFO - 2022-06-28 10:25:54 --> Helper loaded: file_helper
INFO - 2022-06-28 10:25:54 --> Database Driver Class Initialized
INFO - 2022-06-28 10:25:54 --> Email Class Initialized
DEBUG - 2022-06-28 10:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:25:54 --> Controller Class Initialized
INFO - 2022-06-28 10:25:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:25:54 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:25:54 --> Final output sent to browser
DEBUG - 2022-06-28 10:25:54 --> Total execution time: 0.0747
INFO - 2022-06-28 10:25:54 --> Config Class Initialized
INFO - 2022-06-28 10:25:54 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:25:54 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:25:54 --> Utf8 Class Initialized
INFO - 2022-06-28 10:25:54 --> URI Class Initialized
INFO - 2022-06-28 10:25:54 --> Router Class Initialized
INFO - 2022-06-28 10:25:54 --> Output Class Initialized
INFO - 2022-06-28 10:25:54 --> Security Class Initialized
DEBUG - 2022-06-28 10:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:25:54 --> Input Class Initialized
INFO - 2022-06-28 10:25:54 --> Language Class Initialized
INFO - 2022-06-28 10:25:54 --> Loader Class Initialized
INFO - 2022-06-28 10:25:54 --> Helper loaded: url_helper
INFO - 2022-06-28 10:25:54 --> Helper loaded: file_helper
INFO - 2022-06-28 10:25:54 --> Database Driver Class Initialized
INFO - 2022-06-28 10:25:54 --> Email Class Initialized
DEBUG - 2022-06-28 10:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:25:54 --> Controller Class Initialized
INFO - 2022-06-28 10:25:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:25:54 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:25:54 --> Final output sent to browser
DEBUG - 2022-06-28 10:25:54 --> Total execution time: 0.0928
INFO - 2022-06-28 10:25:54 --> Config Class Initialized
INFO - 2022-06-28 10:25:54 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:25:54 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:25:54 --> Utf8 Class Initialized
INFO - 2022-06-28 10:25:54 --> URI Class Initialized
INFO - 2022-06-28 10:25:54 --> Router Class Initialized
INFO - 2022-06-28 10:25:54 --> Output Class Initialized
INFO - 2022-06-28 10:25:54 --> Security Class Initialized
DEBUG - 2022-06-28 10:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:25:54 --> Input Class Initialized
INFO - 2022-06-28 10:25:54 --> Language Class Initialized
INFO - 2022-06-28 10:25:54 --> Loader Class Initialized
INFO - 2022-06-28 10:25:54 --> Helper loaded: url_helper
INFO - 2022-06-28 10:25:54 --> Helper loaded: file_helper
INFO - 2022-06-28 10:25:54 --> Database Driver Class Initialized
INFO - 2022-06-28 10:25:54 --> Email Class Initialized
DEBUG - 2022-06-28 10:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:25:54 --> Controller Class Initialized
INFO - 2022-06-28 10:25:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:25:54 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:25:54 --> Final output sent to browser
DEBUG - 2022-06-28 10:25:54 --> Total execution time: 0.0227
INFO - 2022-06-28 10:25:54 --> Config Class Initialized
INFO - 2022-06-28 10:25:54 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:25:54 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:25:54 --> Utf8 Class Initialized
INFO - 2022-06-28 10:25:54 --> URI Class Initialized
INFO - 2022-06-28 10:25:54 --> Router Class Initialized
INFO - 2022-06-28 10:25:54 --> Output Class Initialized
INFO - 2022-06-28 10:25:54 --> Security Class Initialized
DEBUG - 2022-06-28 10:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:25:54 --> Input Class Initialized
INFO - 2022-06-28 10:25:54 --> Language Class Initialized
INFO - 2022-06-28 10:25:54 --> Loader Class Initialized
INFO - 2022-06-28 10:25:54 --> Helper loaded: url_helper
INFO - 2022-06-28 10:25:54 --> Helper loaded: file_helper
INFO - 2022-06-28 10:25:54 --> Database Driver Class Initialized
INFO - 2022-06-28 10:25:55 --> Email Class Initialized
DEBUG - 2022-06-28 10:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:25:55 --> Controller Class Initialized
INFO - 2022-06-28 10:25:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:25:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:25:55 --> Final output sent to browser
DEBUG - 2022-06-28 10:25:55 --> Total execution time: 0.0709
INFO - 2022-06-28 10:25:55 --> Config Class Initialized
INFO - 2022-06-28 10:25:55 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:25:55 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:25:55 --> Utf8 Class Initialized
INFO - 2022-06-28 10:25:55 --> URI Class Initialized
INFO - 2022-06-28 10:25:55 --> Router Class Initialized
INFO - 2022-06-28 10:25:55 --> Output Class Initialized
INFO - 2022-06-28 10:25:55 --> Security Class Initialized
DEBUG - 2022-06-28 10:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:25:55 --> Input Class Initialized
INFO - 2022-06-28 10:25:55 --> Language Class Initialized
INFO - 2022-06-28 10:25:55 --> Loader Class Initialized
INFO - 2022-06-28 10:25:55 --> Helper loaded: url_helper
INFO - 2022-06-28 10:25:55 --> Helper loaded: file_helper
INFO - 2022-06-28 10:25:55 --> Database Driver Class Initialized
INFO - 2022-06-28 10:25:55 --> Email Class Initialized
DEBUG - 2022-06-28 10:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:25:55 --> Controller Class Initialized
INFO - 2022-06-28 10:25:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:25:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:25:55 --> Final output sent to browser
DEBUG - 2022-06-28 10:25:55 --> Total execution time: 0.2565
INFO - 2022-06-28 10:25:55 --> Config Class Initialized
INFO - 2022-06-28 10:25:55 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:25:55 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:25:55 --> Utf8 Class Initialized
INFO - 2022-06-28 10:25:55 --> URI Class Initialized
INFO - 2022-06-28 10:25:55 --> Router Class Initialized
INFO - 2022-06-28 10:25:55 --> Output Class Initialized
INFO - 2022-06-28 10:25:55 --> Security Class Initialized
DEBUG - 2022-06-28 10:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:25:55 --> Input Class Initialized
INFO - 2022-06-28 10:25:55 --> Language Class Initialized
INFO - 2022-06-28 10:25:55 --> Loader Class Initialized
INFO - 2022-06-28 10:25:55 --> Helper loaded: url_helper
INFO - 2022-06-28 10:25:55 --> Helper loaded: file_helper
INFO - 2022-06-28 10:25:55 --> Database Driver Class Initialized
INFO - 2022-06-28 10:25:55 --> Email Class Initialized
DEBUG - 2022-06-28 10:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:25:55 --> Config Class Initialized
INFO - 2022-06-28 10:25:55 --> Hooks Class Initialized
INFO - 2022-06-28 10:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:25:55 --> Controller Class Initialized
DEBUG - 2022-06-28 10:25:55 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:25:55 --> Utf8 Class Initialized
INFO - 2022-06-28 10:25:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:25:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:25:55 --> URI Class Initialized
INFO - 2022-06-28 10:25:55 --> Final output sent to browser
DEBUG - 2022-06-28 10:25:55 --> Total execution time: 0.1470
INFO - 2022-06-28 10:25:55 --> Router Class Initialized
INFO - 2022-06-28 10:25:55 --> Output Class Initialized
INFO - 2022-06-28 10:25:55 --> Security Class Initialized
DEBUG - 2022-06-28 10:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:25:55 --> Input Class Initialized
INFO - 2022-06-28 10:25:55 --> Language Class Initialized
INFO - 2022-06-28 10:25:55 --> Config Class Initialized
INFO - 2022-06-28 10:25:55 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:25:55 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:25:55 --> Utf8 Class Initialized
INFO - 2022-06-28 10:25:55 --> URI Class Initialized
INFO - 2022-06-28 10:25:55 --> Router Class Initialized
INFO - 2022-06-28 10:25:55 --> Output Class Initialized
INFO - 2022-06-28 10:25:55 --> Security Class Initialized
DEBUG - 2022-06-28 10:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:25:55 --> Input Class Initialized
INFO - 2022-06-28 10:25:55 --> Language Class Initialized
INFO - 2022-06-28 10:25:55 --> Loader Class Initialized
INFO - 2022-06-28 10:25:55 --> Helper loaded: url_helper
INFO - 2022-06-28 10:25:55 --> Helper loaded: file_helper
INFO - 2022-06-28 10:25:55 --> Database Driver Class Initialized
INFO - 2022-06-28 10:25:55 --> Loader Class Initialized
INFO - 2022-06-28 10:25:55 --> Helper loaded: url_helper
INFO - 2022-06-28 10:25:55 --> Helper loaded: file_helper
INFO - 2022-06-28 10:25:55 --> Database Driver Class Initialized
INFO - 2022-06-28 10:25:56 --> Email Class Initialized
DEBUG - 2022-06-28 10:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:25:56 --> Controller Class Initialized
INFO - 2022-06-28 10:25:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:25:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:25:56 --> Email Class Initialized
DEBUG - 2022-06-28 10:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:25:56 --> Final output sent to browser
DEBUG - 2022-06-28 10:25:56 --> Total execution time: 0.9047
INFO - 2022-06-28 10:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:25:56 --> Controller Class Initialized
INFO - 2022-06-28 10:25:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:25:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:25:56 --> Config Class Initialized
INFO - 2022-06-28 10:25:56 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:25:56 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:25:56 --> Utf8 Class Initialized
INFO - 2022-06-28 10:25:56 --> URI Class Initialized
INFO - 2022-06-28 10:25:56 --> Router Class Initialized
INFO - 2022-06-28 10:25:56 --> Output Class Initialized
INFO - 2022-06-28 10:25:56 --> Security Class Initialized
DEBUG - 2022-06-28 10:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:25:56 --> Input Class Initialized
INFO - 2022-06-28 10:25:56 --> Language Class Initialized
INFO - 2022-06-28 10:25:56 --> Loader Class Initialized
INFO - 2022-06-28 10:25:56 --> Helper loaded: url_helper
INFO - 2022-06-28 10:25:56 --> Helper loaded: file_helper
INFO - 2022-06-28 10:25:56 --> Database Driver Class Initialized
INFO - 2022-06-28 10:25:56 --> Final output sent to browser
DEBUG - 2022-06-28 10:25:56 --> Total execution time: 0.8572
INFO - 2022-06-28 10:25:56 --> Config Class Initialized
INFO - 2022-06-28 10:25:56 --> Config Class Initialized
INFO - 2022-06-28 10:25:56 --> Hooks Class Initialized
INFO - 2022-06-28 10:25:56 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-28 10:25:56 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:25:56 --> Utf8 Class Initialized
INFO - 2022-06-28 10:25:56 --> Utf8 Class Initialized
INFO - 2022-06-28 10:25:56 --> URI Class Initialized
INFO - 2022-06-28 10:25:56 --> URI Class Initialized
INFO - 2022-06-28 10:25:56 --> Router Class Initialized
INFO - 2022-06-28 10:25:56 --> Router Class Initialized
INFO - 2022-06-28 10:25:56 --> Output Class Initialized
INFO - 2022-06-28 10:25:56 --> Output Class Initialized
INFO - 2022-06-28 10:25:56 --> Security Class Initialized
INFO - 2022-06-28 10:25:56 --> Security Class Initialized
DEBUG - 2022-06-28 10:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-28 10:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:25:56 --> Input Class Initialized
INFO - 2022-06-28 10:25:56 --> Input Class Initialized
INFO - 2022-06-28 10:25:56 --> Language Class Initialized
INFO - 2022-06-28 10:25:56 --> Language Class Initialized
INFO - 2022-06-28 10:25:56 --> Loader Class Initialized
INFO - 2022-06-28 10:25:56 --> Loader Class Initialized
INFO - 2022-06-28 10:25:56 --> Helper loaded: url_helper
INFO - 2022-06-28 10:25:56 --> Helper loaded: file_helper
INFO - 2022-06-28 10:25:56 --> Database Driver Class Initialized
INFO - 2022-06-28 10:25:56 --> Helper loaded: url_helper
INFO - 2022-06-28 10:25:56 --> Helper loaded: file_helper
INFO - 2022-06-28 10:25:56 --> Database Driver Class Initialized
INFO - 2022-06-28 10:25:56 --> Email Class Initialized
INFO - 2022-06-28 10:25:56 --> Email Class Initialized
INFO - 2022-06-28 10:25:56 --> Email Class Initialized
DEBUG - 2022-06-28 10:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-28 10:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-28 10:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:25:56 --> Controller Class Initialized
INFO - 2022-06-28 10:25:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:25:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:25:56 --> Final output sent to browser
DEBUG - 2022-06-28 10:25:56 --> Total execution time: 0.0934
INFO - 2022-06-28 10:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:25:56 --> Controller Class Initialized
INFO - 2022-06-28 10:25:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:25:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:25:56 --> Final output sent to browser
DEBUG - 2022-06-28 10:25:56 --> Total execution time: 0.2270
INFO - 2022-06-28 10:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:25:56 --> Controller Class Initialized
INFO - 2022-06-28 10:25:56 --> Model "Tokenmodel" initialized
INFO - 2022-06-28 10:25:56 --> Config Class Initialized
INFO - 2022-06-28 10:25:56 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:25:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2022-06-28 10:25:56 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:25:56 --> Utf8 Class Initialized
INFO - 2022-06-28 10:25:56 --> Final output sent to browser
DEBUG - 2022-06-28 10:25:56 --> Total execution time: 0.2562
INFO - 2022-06-28 10:25:56 --> URI Class Initialized
INFO - 2022-06-28 10:25:56 --> Router Class Initialized
INFO - 2022-06-28 10:25:56 --> Output Class Initialized
INFO - 2022-06-28 10:25:56 --> Security Class Initialized
DEBUG - 2022-06-28 10:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:25:56 --> Input Class Initialized
INFO - 2022-06-28 10:25:56 --> Language Class Initialized
INFO - 2022-06-28 10:25:56 --> Loader Class Initialized
INFO - 2022-06-28 10:25:56 --> Helper loaded: url_helper
INFO - 2022-06-28 10:25:56 --> Helper loaded: file_helper
INFO - 2022-06-28 10:25:56 --> Database Driver Class Initialized
INFO - 2022-06-28 10:25:56 --> Email Class Initialized
DEBUG - 2022-06-28 10:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:25:56 --> Controller Class Initialized
INFO - 2022-06-28 10:25:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:25:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:25:56 --> Final output sent to browser
DEBUG - 2022-06-28 10:25:56 --> Total execution time: 0.0338
INFO - 2022-06-28 10:25:56 --> Config Class Initialized
INFO - 2022-06-28 10:25:56 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:25:56 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:25:56 --> Utf8 Class Initialized
INFO - 2022-06-28 10:25:56 --> URI Class Initialized
INFO - 2022-06-28 10:25:56 --> Router Class Initialized
INFO - 2022-06-28 10:25:56 --> Output Class Initialized
INFO - 2022-06-28 10:25:56 --> Security Class Initialized
DEBUG - 2022-06-28 10:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:25:56 --> Input Class Initialized
INFO - 2022-06-28 10:25:56 --> Language Class Initialized
INFO - 2022-06-28 10:25:56 --> Loader Class Initialized
INFO - 2022-06-28 10:25:56 --> Helper loaded: url_helper
INFO - 2022-06-28 10:25:56 --> Helper loaded: file_helper
INFO - 2022-06-28 10:25:56 --> Database Driver Class Initialized
INFO - 2022-06-28 10:25:56 --> Email Class Initialized
DEBUG - 2022-06-28 10:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:25:56 --> Controller Class Initialized
INFO - 2022-06-28 10:25:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:25:56 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:25:57 --> Final output sent to browser
DEBUG - 2022-06-28 10:25:57 --> Total execution time: 0.6090
INFO - 2022-06-28 10:25:57 --> Config Class Initialized
INFO - 2022-06-28 10:25:57 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:25:57 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:25:57 --> Utf8 Class Initialized
INFO - 2022-06-28 10:25:57 --> URI Class Initialized
INFO - 2022-06-28 10:25:57 --> Router Class Initialized
INFO - 2022-06-28 10:25:57 --> Output Class Initialized
INFO - 2022-06-28 10:25:57 --> Security Class Initialized
DEBUG - 2022-06-28 10:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:25:57 --> Input Class Initialized
INFO - 2022-06-28 10:25:57 --> Language Class Initialized
INFO - 2022-06-28 10:25:57 --> Loader Class Initialized
INFO - 2022-06-28 10:25:57 --> Helper loaded: url_helper
INFO - 2022-06-28 10:25:57 --> Helper loaded: file_helper
INFO - 2022-06-28 10:25:57 --> Database Driver Class Initialized
INFO - 2022-06-28 10:25:57 --> Config Class Initialized
INFO - 2022-06-28 10:25:57 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:25:57 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:25:57 --> Utf8 Class Initialized
INFO - 2022-06-28 10:25:57 --> URI Class Initialized
INFO - 2022-06-28 10:25:57 --> Router Class Initialized
INFO - 2022-06-28 10:25:57 --> Output Class Initialized
INFO - 2022-06-28 10:25:57 --> Security Class Initialized
DEBUG - 2022-06-28 10:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:25:57 --> Input Class Initialized
INFO - 2022-06-28 10:25:57 --> Language Class Initialized
INFO - 2022-06-28 10:25:57 --> Loader Class Initialized
INFO - 2022-06-28 10:25:57 --> Helper loaded: url_helper
INFO - 2022-06-28 10:25:57 --> Helper loaded: file_helper
INFO - 2022-06-28 10:25:57 --> Database Driver Class Initialized
INFO - 2022-06-28 10:25:57 --> Email Class Initialized
DEBUG - 2022-06-28 10:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:25:57 --> Controller Class Initialized
INFO - 2022-06-28 10:25:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:25:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:25:57 --> Email Class Initialized
INFO - 2022-06-28 10:25:57 --> Final output sent to browser
DEBUG - 2022-06-28 10:25:57 --> Total execution time: 0.6564
DEBUG - 2022-06-28 10:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:25:57 --> Controller Class Initialized
INFO - 2022-06-28 10:25:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:25:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:25:57 --> Final output sent to browser
DEBUG - 2022-06-28 10:25:57 --> Total execution time: 0.5491
INFO - 2022-06-28 10:26:02 --> Config Class Initialized
INFO - 2022-06-28 10:26:02 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:26:02 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:26:02 --> Utf8 Class Initialized
INFO - 2022-06-28 10:26:02 --> URI Class Initialized
INFO - 2022-06-28 10:26:02 --> Router Class Initialized
INFO - 2022-06-28 10:26:02 --> Output Class Initialized
INFO - 2022-06-28 10:26:02 --> Security Class Initialized
DEBUG - 2022-06-28 10:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:26:02 --> Input Class Initialized
INFO - 2022-06-28 10:26:02 --> Language Class Initialized
INFO - 2022-06-28 10:26:02 --> Loader Class Initialized
INFO - 2022-06-28 10:26:02 --> Helper loaded: url_helper
INFO - 2022-06-28 10:26:02 --> Helper loaded: file_helper
INFO - 2022-06-28 10:26:02 --> Database Driver Class Initialized
INFO - 2022-06-28 10:26:02 --> Email Class Initialized
DEBUG - 2022-06-28 10:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:26:02 --> Controller Class Initialized
INFO - 2022-06-28 10:26:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:26:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 10:26:02 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\qr\application\views\reception screen\qr.php 165
ERROR - 2022-06-28 10:26:02 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\reception screen\qr.php 178
INFO - 2022-06-28 10:26:02 --> File loaded: C:\wamp64\www\qr\application\views\reception screen/qr.php
INFO - 2022-06-28 10:26:02 --> Final output sent to browser
DEBUG - 2022-06-28 10:26:02 --> Total execution time: 0.1349
INFO - 2022-06-28 10:27:28 --> Config Class Initialized
INFO - 2022-06-28 10:27:28 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:27:28 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:27:28 --> Utf8 Class Initialized
INFO - 2022-06-28 10:27:28 --> URI Class Initialized
INFO - 2022-06-28 10:27:28 --> Router Class Initialized
INFO - 2022-06-28 10:27:28 --> Output Class Initialized
INFO - 2022-06-28 10:27:28 --> Security Class Initialized
DEBUG - 2022-06-28 10:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:27:28 --> Input Class Initialized
INFO - 2022-06-28 10:27:28 --> Language Class Initialized
INFO - 2022-06-28 10:27:28 --> Loader Class Initialized
INFO - 2022-06-28 10:27:28 --> Helper loaded: url_helper
INFO - 2022-06-28 10:27:28 --> Helper loaded: file_helper
INFO - 2022-06-28 10:27:28 --> Database Driver Class Initialized
INFO - 2022-06-28 10:27:28 --> Email Class Initialized
DEBUG - 2022-06-28 10:27:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:27:28 --> Controller Class Initialized
INFO - 2022-06-28 10:27:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:27:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:27:28 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 10:27:28 --> Final output sent to browser
DEBUG - 2022-06-28 10:27:28 --> Total execution time: 0.0205
INFO - 2022-06-28 10:38:43 --> Config Class Initialized
INFO - 2022-06-28 10:38:43 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:38:43 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:38:43 --> Utf8 Class Initialized
INFO - 2022-06-28 10:38:43 --> URI Class Initialized
INFO - 2022-06-28 10:38:43 --> Router Class Initialized
INFO - 2022-06-28 10:38:43 --> Output Class Initialized
INFO - 2022-06-28 10:38:43 --> Security Class Initialized
DEBUG - 2022-06-28 10:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:38:43 --> Input Class Initialized
INFO - 2022-06-28 10:38:43 --> Language Class Initialized
INFO - 2022-06-28 10:38:43 --> Loader Class Initialized
INFO - 2022-06-28 10:38:43 --> Helper loaded: url_helper
INFO - 2022-06-28 10:38:43 --> Helper loaded: file_helper
INFO - 2022-06-28 10:38:43 --> Database Driver Class Initialized
INFO - 2022-06-28 10:38:43 --> Email Class Initialized
DEBUG - 2022-06-28 10:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:38:43 --> Controller Class Initialized
INFO - 2022-06-28 10:38:43 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:38:43 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:38:43 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 10:38:43 --> Final output sent to browser
DEBUG - 2022-06-28 10:38:43 --> Total execution time: 0.2192
INFO - 2022-06-28 10:38:46 --> Config Class Initialized
INFO - 2022-06-28 10:38:46 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:38:46 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:38:46 --> Utf8 Class Initialized
INFO - 2022-06-28 10:38:46 --> URI Class Initialized
INFO - 2022-06-28 10:38:46 --> Router Class Initialized
INFO - 2022-06-28 10:38:46 --> Output Class Initialized
INFO - 2022-06-28 10:38:46 --> Security Class Initialized
DEBUG - 2022-06-28 10:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:38:46 --> Input Class Initialized
INFO - 2022-06-28 10:38:46 --> Language Class Initialized
INFO - 2022-06-28 10:38:46 --> Loader Class Initialized
INFO - 2022-06-28 10:38:46 --> Helper loaded: url_helper
INFO - 2022-06-28 10:38:46 --> Helper loaded: file_helper
INFO - 2022-06-28 10:38:46 --> Database Driver Class Initialized
INFO - 2022-06-28 10:38:46 --> Email Class Initialized
DEBUG - 2022-06-28 10:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:38:46 --> Controller Class Initialized
INFO - 2022-06-28 10:38:46 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:38:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 10:38:46 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\qr\application\views\reception screen\qr.php 165
INFO - 2022-06-28 10:38:46 --> File loaded: C:\wamp64\www\qr\application\views\reception screen/qr.php
INFO - 2022-06-28 10:38:46 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 10:38:46 --> Final output sent to browser
DEBUG - 2022-06-28 10:38:46 --> Total execution time: 0.0940
INFO - 2022-06-28 10:38:48 --> Config Class Initialized
INFO - 2022-06-28 10:38:48 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:38:48 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:38:48 --> Utf8 Class Initialized
INFO - 2022-06-28 10:38:48 --> URI Class Initialized
INFO - 2022-06-28 10:38:48 --> Router Class Initialized
INFO - 2022-06-28 10:38:48 --> Output Class Initialized
INFO - 2022-06-28 10:38:48 --> Security Class Initialized
DEBUG - 2022-06-28 10:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:38:48 --> Input Class Initialized
INFO - 2022-06-28 10:38:48 --> Language Class Initialized
INFO - 2022-06-28 10:38:48 --> Loader Class Initialized
INFO - 2022-06-28 10:38:48 --> Helper loaded: url_helper
INFO - 2022-06-28 10:38:48 --> Helper loaded: file_helper
INFO - 2022-06-28 10:38:48 --> Database Driver Class Initialized
INFO - 2022-06-28 10:38:48 --> Email Class Initialized
DEBUG - 2022-06-28 10:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:38:48 --> Controller Class Initialized
INFO - 2022-06-28 10:38:48 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:38:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 10:38:48 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\qr\application\views\reception screen\qr.php 165
INFO - 2022-06-28 10:38:48 --> File loaded: C:\wamp64\www\qr\application\views\reception screen/qr.php
INFO - 2022-06-28 10:38:48 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 10:38:48 --> Final output sent to browser
DEBUG - 2022-06-28 10:38:48 --> Total execution time: 0.1911
INFO - 2022-06-28 10:41:15 --> Config Class Initialized
INFO - 2022-06-28 10:41:15 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:41:15 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:41:15 --> Utf8 Class Initialized
INFO - 2022-06-28 10:41:15 --> URI Class Initialized
INFO - 2022-06-28 10:41:15 --> Router Class Initialized
INFO - 2022-06-28 10:41:15 --> Output Class Initialized
INFO - 2022-06-28 10:41:15 --> Security Class Initialized
DEBUG - 2022-06-28 10:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:41:15 --> Input Class Initialized
INFO - 2022-06-28 10:41:15 --> Language Class Initialized
INFO - 2022-06-28 10:41:15 --> Loader Class Initialized
INFO - 2022-06-28 10:41:15 --> Helper loaded: url_helper
INFO - 2022-06-28 10:41:15 --> Helper loaded: file_helper
INFO - 2022-06-28 10:41:15 --> Database Driver Class Initialized
INFO - 2022-06-28 10:41:15 --> Email Class Initialized
DEBUG - 2022-06-28 10:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:41:15 --> Controller Class Initialized
INFO - 2022-06-28 10:41:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:41:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 10:41:15 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\qr\application\views\reception screen\qr.php 165
INFO - 2022-06-28 10:41:15 --> File loaded: C:\wamp64\www\qr\application\views\reception screen/qr.php
INFO - 2022-06-28 10:41:15 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 10:41:15 --> Final output sent to browser
DEBUG - 2022-06-28 10:41:15 --> Total execution time: 0.1720
INFO - 2022-06-28 10:41:16 --> Config Class Initialized
INFO - 2022-06-28 10:41:16 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:41:16 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:41:16 --> Utf8 Class Initialized
INFO - 2022-06-28 10:41:16 --> URI Class Initialized
INFO - 2022-06-28 10:41:16 --> Router Class Initialized
INFO - 2022-06-28 10:41:16 --> Output Class Initialized
INFO - 2022-06-28 10:41:16 --> Security Class Initialized
DEBUG - 2022-06-28 10:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:41:16 --> Input Class Initialized
INFO - 2022-06-28 10:41:16 --> Language Class Initialized
INFO - 2022-06-28 10:41:16 --> Loader Class Initialized
INFO - 2022-06-28 10:41:16 --> Helper loaded: url_helper
INFO - 2022-06-28 10:41:16 --> Helper loaded: file_helper
INFO - 2022-06-28 10:41:16 --> Database Driver Class Initialized
INFO - 2022-06-28 10:41:16 --> Email Class Initialized
DEBUG - 2022-06-28 10:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:41:16 --> Controller Class Initialized
INFO - 2022-06-28 10:41:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:41:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 10:41:16 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\qr\application\views\reception screen\qr.php 165
INFO - 2022-06-28 10:41:16 --> File loaded: C:\wamp64\www\qr\application\views\reception screen/qr.php
INFO - 2022-06-28 10:41:16 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 10:41:16 --> Final output sent to browser
DEBUG - 2022-06-28 10:41:16 --> Total execution time: 0.0763
INFO - 2022-06-28 10:41:17 --> Config Class Initialized
INFO - 2022-06-28 10:41:17 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:41:17 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:41:17 --> Utf8 Class Initialized
INFO - 2022-06-28 10:41:17 --> URI Class Initialized
INFO - 2022-06-28 10:41:17 --> Router Class Initialized
INFO - 2022-06-28 10:41:17 --> Output Class Initialized
INFO - 2022-06-28 10:41:17 --> Security Class Initialized
DEBUG - 2022-06-28 10:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:41:17 --> Input Class Initialized
INFO - 2022-06-28 10:41:17 --> Language Class Initialized
INFO - 2022-06-28 10:41:17 --> Loader Class Initialized
INFO - 2022-06-28 10:41:17 --> Helper loaded: url_helper
INFO - 2022-06-28 10:41:17 --> Helper loaded: file_helper
INFO - 2022-06-28 10:41:17 --> Database Driver Class Initialized
INFO - 2022-06-28 10:41:17 --> Email Class Initialized
DEBUG - 2022-06-28 10:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:41:17 --> Controller Class Initialized
INFO - 2022-06-28 10:41:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:41:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 10:41:17 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\qr\application\views\reception screen\qr.php 165
INFO - 2022-06-28 10:41:17 --> File loaded: C:\wamp64\www\qr\application\views\reception screen/qr.php
INFO - 2022-06-28 10:41:17 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 10:41:17 --> Final output sent to browser
DEBUG - 2022-06-28 10:41:17 --> Total execution time: 0.1758
INFO - 2022-06-28 10:41:17 --> Config Class Initialized
INFO - 2022-06-28 10:41:17 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:41:17 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:41:17 --> Utf8 Class Initialized
INFO - 2022-06-28 10:41:17 --> URI Class Initialized
INFO - 2022-06-28 10:41:17 --> Router Class Initialized
INFO - 2022-06-28 10:41:17 --> Output Class Initialized
INFO - 2022-06-28 10:41:17 --> Security Class Initialized
DEBUG - 2022-06-28 10:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:41:17 --> Input Class Initialized
INFO - 2022-06-28 10:41:17 --> Language Class Initialized
INFO - 2022-06-28 10:41:17 --> Loader Class Initialized
INFO - 2022-06-28 10:41:17 --> Helper loaded: url_helper
INFO - 2022-06-28 10:41:17 --> Helper loaded: file_helper
INFO - 2022-06-28 10:41:17 --> Database Driver Class Initialized
INFO - 2022-06-28 10:41:17 --> Email Class Initialized
DEBUG - 2022-06-28 10:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:41:17 --> Controller Class Initialized
INFO - 2022-06-28 10:41:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:41:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 10:41:17 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\qr\application\views\reception screen\qr.php 165
INFO - 2022-06-28 10:41:17 --> File loaded: C:\wamp64\www\qr\application\views\reception screen/qr.php
INFO - 2022-06-28 10:41:17 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 10:41:17 --> Final output sent to browser
DEBUG - 2022-06-28 10:41:17 --> Total execution time: 0.0686
INFO - 2022-06-28 10:41:17 --> Config Class Initialized
INFO - 2022-06-28 10:41:17 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:41:17 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:41:17 --> Utf8 Class Initialized
INFO - 2022-06-28 10:41:17 --> URI Class Initialized
INFO - 2022-06-28 10:41:17 --> Router Class Initialized
INFO - 2022-06-28 10:41:17 --> Output Class Initialized
INFO - 2022-06-28 10:41:17 --> Security Class Initialized
DEBUG - 2022-06-28 10:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:41:17 --> Input Class Initialized
INFO - 2022-06-28 10:41:17 --> Language Class Initialized
INFO - 2022-06-28 10:41:17 --> Loader Class Initialized
INFO - 2022-06-28 10:41:17 --> Helper loaded: url_helper
INFO - 2022-06-28 10:41:17 --> Helper loaded: file_helper
INFO - 2022-06-28 10:41:17 --> Database Driver Class Initialized
INFO - 2022-06-28 10:41:17 --> Email Class Initialized
DEBUG - 2022-06-28 10:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:41:17 --> Controller Class Initialized
INFO - 2022-06-28 10:41:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:41:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:41:17 --> Final output sent to browser
DEBUG - 2022-06-28 10:41:17 --> Total execution time: 0.0608
INFO - 2022-06-28 10:41:31 --> Config Class Initialized
INFO - 2022-06-28 10:41:31 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:41:31 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:41:31 --> Utf8 Class Initialized
INFO - 2022-06-28 10:41:31 --> URI Class Initialized
INFO - 2022-06-28 10:41:31 --> Router Class Initialized
INFO - 2022-06-28 10:41:31 --> Output Class Initialized
INFO - 2022-06-28 10:41:31 --> Security Class Initialized
DEBUG - 2022-06-28 10:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:41:31 --> Input Class Initialized
INFO - 2022-06-28 10:41:31 --> Language Class Initialized
INFO - 2022-06-28 10:41:31 --> Loader Class Initialized
INFO - 2022-06-28 10:41:31 --> Helper loaded: url_helper
INFO - 2022-06-28 10:41:31 --> Helper loaded: file_helper
INFO - 2022-06-28 10:41:31 --> Database Driver Class Initialized
INFO - 2022-06-28 10:41:31 --> Email Class Initialized
DEBUG - 2022-06-28 10:41:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:41:31 --> Controller Class Initialized
INFO - 2022-06-28 10:41:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:41:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:41:31 --> Final output sent to browser
DEBUG - 2022-06-28 10:41:31 --> Total execution time: 0.0823
INFO - 2022-06-28 10:41:32 --> Config Class Initialized
INFO - 2022-06-28 10:41:32 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:41:32 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:41:32 --> Utf8 Class Initialized
INFO - 2022-06-28 10:41:32 --> URI Class Initialized
INFO - 2022-06-28 10:41:32 --> Router Class Initialized
INFO - 2022-06-28 10:41:32 --> Output Class Initialized
INFO - 2022-06-28 10:41:32 --> Security Class Initialized
DEBUG - 2022-06-28 10:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:41:32 --> Input Class Initialized
INFO - 2022-06-28 10:41:32 --> Language Class Initialized
INFO - 2022-06-28 10:41:32 --> Loader Class Initialized
INFO - 2022-06-28 10:41:32 --> Helper loaded: url_helper
INFO - 2022-06-28 10:41:32 --> Helper loaded: file_helper
INFO - 2022-06-28 10:41:32 --> Database Driver Class Initialized
INFO - 2022-06-28 10:41:32 --> Email Class Initialized
DEBUG - 2022-06-28 10:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:41:32 --> Controller Class Initialized
INFO - 2022-06-28 10:41:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:41:32 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:41:32 --> Final output sent to browser
DEBUG - 2022-06-28 10:41:32 --> Total execution time: 0.1731
INFO - 2022-06-28 10:41:32 --> Config Class Initialized
INFO - 2022-06-28 10:41:32 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:41:32 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:41:32 --> Utf8 Class Initialized
INFO - 2022-06-28 10:41:32 --> URI Class Initialized
INFO - 2022-06-28 10:41:32 --> Router Class Initialized
INFO - 2022-06-28 10:41:32 --> Output Class Initialized
INFO - 2022-06-28 10:41:32 --> Security Class Initialized
DEBUG - 2022-06-28 10:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:41:32 --> Input Class Initialized
INFO - 2022-06-28 10:41:32 --> Language Class Initialized
INFO - 2022-06-28 10:41:32 --> Loader Class Initialized
INFO - 2022-06-28 10:41:32 --> Helper loaded: url_helper
INFO - 2022-06-28 10:41:32 --> Helper loaded: file_helper
INFO - 2022-06-28 10:41:32 --> Database Driver Class Initialized
INFO - 2022-06-28 10:41:32 --> Email Class Initialized
DEBUG - 2022-06-28 10:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:41:32 --> Controller Class Initialized
INFO - 2022-06-28 10:41:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:41:32 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:41:32 --> Final output sent to browser
DEBUG - 2022-06-28 10:41:32 --> Total execution time: 0.0504
INFO - 2022-06-28 10:41:32 --> Config Class Initialized
INFO - 2022-06-28 10:41:32 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:41:32 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:41:32 --> Utf8 Class Initialized
INFO - 2022-06-28 10:41:32 --> URI Class Initialized
INFO - 2022-06-28 10:41:32 --> Router Class Initialized
INFO - 2022-06-28 10:41:32 --> Output Class Initialized
INFO - 2022-06-28 10:41:32 --> Security Class Initialized
DEBUG - 2022-06-28 10:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:41:32 --> Input Class Initialized
INFO - 2022-06-28 10:41:32 --> Language Class Initialized
INFO - 2022-06-28 10:41:32 --> Loader Class Initialized
INFO - 2022-06-28 10:41:32 --> Helper loaded: url_helper
INFO - 2022-06-28 10:41:32 --> Helper loaded: file_helper
INFO - 2022-06-28 10:41:32 --> Database Driver Class Initialized
INFO - 2022-06-28 10:41:32 --> Email Class Initialized
DEBUG - 2022-06-28 10:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:41:32 --> Controller Class Initialized
INFO - 2022-06-28 10:41:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:41:32 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:41:32 --> Final output sent to browser
DEBUG - 2022-06-28 10:41:32 --> Total execution time: 0.0579
INFO - 2022-06-28 10:41:32 --> Config Class Initialized
INFO - 2022-06-28 10:41:32 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:41:32 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:41:32 --> Utf8 Class Initialized
INFO - 2022-06-28 10:41:32 --> URI Class Initialized
INFO - 2022-06-28 10:41:32 --> Router Class Initialized
INFO - 2022-06-28 10:41:32 --> Output Class Initialized
INFO - 2022-06-28 10:41:32 --> Security Class Initialized
DEBUG - 2022-06-28 10:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:41:32 --> Input Class Initialized
INFO - 2022-06-28 10:41:32 --> Language Class Initialized
INFO - 2022-06-28 10:41:32 --> Loader Class Initialized
INFO - 2022-06-28 10:41:32 --> Helper loaded: url_helper
INFO - 2022-06-28 10:41:32 --> Helper loaded: file_helper
INFO - 2022-06-28 10:41:32 --> Database Driver Class Initialized
INFO - 2022-06-28 10:41:32 --> Email Class Initialized
DEBUG - 2022-06-28 10:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:41:32 --> Controller Class Initialized
INFO - 2022-06-28 10:41:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:41:32 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:41:32 --> Final output sent to browser
DEBUG - 2022-06-28 10:41:32 --> Total execution time: 0.0887
INFO - 2022-06-28 10:41:32 --> Config Class Initialized
INFO - 2022-06-28 10:41:32 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:41:32 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:41:32 --> Utf8 Class Initialized
INFO - 2022-06-28 10:41:32 --> URI Class Initialized
INFO - 2022-06-28 10:41:32 --> Router Class Initialized
INFO - 2022-06-28 10:41:32 --> Output Class Initialized
INFO - 2022-06-28 10:41:32 --> Security Class Initialized
DEBUG - 2022-06-28 10:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:41:32 --> Input Class Initialized
INFO - 2022-06-28 10:41:32 --> Language Class Initialized
INFO - 2022-06-28 10:41:32 --> Loader Class Initialized
INFO - 2022-06-28 10:41:32 --> Helper loaded: url_helper
INFO - 2022-06-28 10:41:32 --> Helper loaded: file_helper
INFO - 2022-06-28 10:41:32 --> Database Driver Class Initialized
INFO - 2022-06-28 10:41:32 --> Email Class Initialized
DEBUG - 2022-06-28 10:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:41:32 --> Controller Class Initialized
INFO - 2022-06-28 10:41:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:41:33 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:41:33 --> Final output sent to browser
DEBUG - 2022-06-28 10:41:33 --> Total execution time: 0.0558
INFO - 2022-06-28 10:41:33 --> Config Class Initialized
INFO - 2022-06-28 10:41:33 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:41:33 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:41:33 --> Utf8 Class Initialized
INFO - 2022-06-28 10:41:33 --> URI Class Initialized
INFO - 2022-06-28 10:41:33 --> Router Class Initialized
INFO - 2022-06-28 10:41:33 --> Output Class Initialized
INFO - 2022-06-28 10:41:33 --> Security Class Initialized
DEBUG - 2022-06-28 10:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:41:33 --> Input Class Initialized
INFO - 2022-06-28 10:41:33 --> Language Class Initialized
INFO - 2022-06-28 10:41:33 --> Loader Class Initialized
INFO - 2022-06-28 10:41:33 --> Helper loaded: url_helper
INFO - 2022-06-28 10:41:33 --> Helper loaded: file_helper
INFO - 2022-06-28 10:41:33 --> Database Driver Class Initialized
INFO - 2022-06-28 10:41:33 --> Email Class Initialized
DEBUG - 2022-06-28 10:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:41:33 --> Controller Class Initialized
INFO - 2022-06-28 10:41:33 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:41:33 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:41:33 --> Final output sent to browser
DEBUG - 2022-06-28 10:41:33 --> Total execution time: 0.0680
INFO - 2022-06-28 10:41:33 --> Config Class Initialized
INFO - 2022-06-28 10:41:33 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:41:33 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:41:33 --> Utf8 Class Initialized
INFO - 2022-06-28 10:41:33 --> URI Class Initialized
INFO - 2022-06-28 10:41:33 --> Router Class Initialized
INFO - 2022-06-28 10:41:33 --> Output Class Initialized
INFO - 2022-06-28 10:41:33 --> Security Class Initialized
DEBUG - 2022-06-28 10:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:41:33 --> Input Class Initialized
INFO - 2022-06-28 10:41:33 --> Language Class Initialized
INFO - 2022-06-28 10:41:33 --> Loader Class Initialized
INFO - 2022-06-28 10:41:33 --> Helper loaded: url_helper
INFO - 2022-06-28 10:41:33 --> Helper loaded: file_helper
INFO - 2022-06-28 10:41:33 --> Database Driver Class Initialized
INFO - 2022-06-28 10:41:33 --> Email Class Initialized
DEBUG - 2022-06-28 10:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:41:33 --> Controller Class Initialized
INFO - 2022-06-28 10:41:33 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:41:33 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:41:33 --> Final output sent to browser
DEBUG - 2022-06-28 10:41:33 --> Total execution time: 0.0664
INFO - 2022-06-28 10:41:33 --> Config Class Initialized
INFO - 2022-06-28 10:41:33 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:41:33 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:41:33 --> Utf8 Class Initialized
INFO - 2022-06-28 10:41:33 --> URI Class Initialized
INFO - 2022-06-28 10:41:33 --> Router Class Initialized
INFO - 2022-06-28 10:41:33 --> Output Class Initialized
INFO - 2022-06-28 10:41:33 --> Security Class Initialized
DEBUG - 2022-06-28 10:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:41:33 --> Input Class Initialized
INFO - 2022-06-28 10:41:33 --> Language Class Initialized
INFO - 2022-06-28 10:41:33 --> Loader Class Initialized
INFO - 2022-06-28 10:41:33 --> Helper loaded: url_helper
INFO - 2022-06-28 10:41:33 --> Helper loaded: file_helper
INFO - 2022-06-28 10:41:33 --> Database Driver Class Initialized
INFO - 2022-06-28 10:41:33 --> Email Class Initialized
DEBUG - 2022-06-28 10:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:41:33 --> Controller Class Initialized
INFO - 2022-06-28 10:41:33 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:41:33 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:41:33 --> Final output sent to browser
DEBUG - 2022-06-28 10:41:33 --> Total execution time: 0.1935
INFO - 2022-06-28 10:41:35 --> Config Class Initialized
INFO - 2022-06-28 10:41:35 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:41:35 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:41:35 --> Utf8 Class Initialized
INFO - 2022-06-28 10:41:35 --> URI Class Initialized
INFO - 2022-06-28 10:41:35 --> Router Class Initialized
INFO - 2022-06-28 10:41:35 --> Output Class Initialized
INFO - 2022-06-28 10:41:35 --> Security Class Initialized
DEBUG - 2022-06-28 10:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:41:35 --> Input Class Initialized
INFO - 2022-06-28 10:41:35 --> Language Class Initialized
INFO - 2022-06-28 10:41:35 --> Loader Class Initialized
INFO - 2022-06-28 10:41:35 --> Helper loaded: url_helper
INFO - 2022-06-28 10:41:35 --> Helper loaded: file_helper
INFO - 2022-06-28 10:41:35 --> Database Driver Class Initialized
INFO - 2022-06-28 10:41:35 --> Email Class Initialized
DEBUG - 2022-06-28 10:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:41:35 --> Controller Class Initialized
INFO - 2022-06-28 10:41:35 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:41:35 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:41:35 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 10:41:35 --> Final output sent to browser
DEBUG - 2022-06-28 10:41:35 --> Total execution time: 0.1191
INFO - 2022-06-28 10:41:39 --> Config Class Initialized
INFO - 2022-06-28 10:41:39 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:41:39 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:41:39 --> Utf8 Class Initialized
INFO - 2022-06-28 10:41:39 --> URI Class Initialized
INFO - 2022-06-28 10:41:39 --> Router Class Initialized
INFO - 2022-06-28 10:41:39 --> Output Class Initialized
INFO - 2022-06-28 10:41:39 --> Security Class Initialized
DEBUG - 2022-06-28 10:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:41:39 --> Input Class Initialized
INFO - 2022-06-28 10:41:39 --> Language Class Initialized
INFO - 2022-06-28 10:41:39 --> Loader Class Initialized
INFO - 2022-06-28 10:41:39 --> Helper loaded: url_helper
INFO - 2022-06-28 10:41:39 --> Helper loaded: file_helper
INFO - 2022-06-28 10:41:39 --> Database Driver Class Initialized
INFO - 2022-06-28 10:41:39 --> Email Class Initialized
DEBUG - 2022-06-28 10:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:41:39 --> Controller Class Initialized
INFO - 2022-06-28 10:41:39 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:41:39 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:41:39 --> Final output sent to browser
DEBUG - 2022-06-28 10:41:39 --> Total execution time: 0.0448
INFO - 2022-06-28 10:41:40 --> Config Class Initialized
INFO - 2022-06-28 10:41:40 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:41:40 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:41:40 --> Utf8 Class Initialized
INFO - 2022-06-28 10:41:40 --> URI Class Initialized
INFO - 2022-06-28 10:41:40 --> Router Class Initialized
INFO - 2022-06-28 10:41:40 --> Output Class Initialized
INFO - 2022-06-28 10:41:40 --> Security Class Initialized
DEBUG - 2022-06-28 10:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:41:40 --> Input Class Initialized
INFO - 2022-06-28 10:41:40 --> Language Class Initialized
INFO - 2022-06-28 10:41:40 --> Loader Class Initialized
INFO - 2022-06-28 10:41:40 --> Helper loaded: url_helper
INFO - 2022-06-28 10:41:40 --> Helper loaded: file_helper
INFO - 2022-06-28 10:41:40 --> Database Driver Class Initialized
INFO - 2022-06-28 10:41:40 --> Email Class Initialized
DEBUG - 2022-06-28 10:41:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:41:40 --> Controller Class Initialized
INFO - 2022-06-28 10:41:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:41:40 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:41:40 --> Final output sent to browser
DEBUG - 2022-06-28 10:41:40 --> Total execution time: 0.0547
INFO - 2022-06-28 10:50:28 --> Config Class Initialized
INFO - 2022-06-28 10:50:28 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:50:28 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:50:28 --> Utf8 Class Initialized
INFO - 2022-06-28 10:50:28 --> URI Class Initialized
INFO - 2022-06-28 10:50:28 --> Router Class Initialized
INFO - 2022-06-28 10:50:28 --> Output Class Initialized
INFO - 2022-06-28 10:50:28 --> Security Class Initialized
DEBUG - 2022-06-28 10:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:50:28 --> Input Class Initialized
INFO - 2022-06-28 10:50:28 --> Language Class Initialized
INFO - 2022-06-28 10:50:28 --> Loader Class Initialized
INFO - 2022-06-28 10:50:28 --> Helper loaded: url_helper
INFO - 2022-06-28 10:50:28 --> Helper loaded: file_helper
INFO - 2022-06-28 10:50:28 --> Database Driver Class Initialized
INFO - 2022-06-28 10:50:28 --> Email Class Initialized
DEBUG - 2022-06-28 10:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:50:28 --> Controller Class Initialized
INFO - 2022-06-28 10:50:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:50:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:50:28 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 10:50:28 --> Final output sent to browser
DEBUG - 2022-06-28 10:50:28 --> Total execution time: 0.0348
INFO - 2022-06-28 10:50:31 --> Config Class Initialized
INFO - 2022-06-28 10:50:31 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:50:31 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:50:31 --> Utf8 Class Initialized
INFO - 2022-06-28 10:50:31 --> URI Class Initialized
INFO - 2022-06-28 10:50:31 --> Router Class Initialized
INFO - 2022-06-28 10:50:31 --> Output Class Initialized
INFO - 2022-06-28 10:50:31 --> Security Class Initialized
DEBUG - 2022-06-28 10:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:50:31 --> Input Class Initialized
INFO - 2022-06-28 10:50:31 --> Language Class Initialized
INFO - 2022-06-28 10:50:31 --> Loader Class Initialized
INFO - 2022-06-28 10:50:31 --> Helper loaded: url_helper
INFO - 2022-06-28 10:50:31 --> Helper loaded: file_helper
INFO - 2022-06-28 10:50:31 --> Database Driver Class Initialized
INFO - 2022-06-28 10:50:31 --> Email Class Initialized
DEBUG - 2022-06-28 10:50:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:50:31 --> Controller Class Initialized
INFO - 2022-06-28 10:50:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:50:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:50:31 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 10:50:31 --> Final output sent to browser
DEBUG - 2022-06-28 10:50:31 --> Total execution time: 0.0184
INFO - 2022-06-28 10:50:53 --> Config Class Initialized
INFO - 2022-06-28 10:50:53 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:50:53 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:50:53 --> Utf8 Class Initialized
INFO - 2022-06-28 10:50:53 --> URI Class Initialized
INFO - 2022-06-28 10:50:53 --> Router Class Initialized
INFO - 2022-06-28 10:50:53 --> Output Class Initialized
INFO - 2022-06-28 10:50:53 --> Security Class Initialized
DEBUG - 2022-06-28 10:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:50:53 --> Input Class Initialized
INFO - 2022-06-28 10:50:53 --> Language Class Initialized
INFO - 2022-06-28 10:50:53 --> Loader Class Initialized
INFO - 2022-06-28 10:50:53 --> Helper loaded: url_helper
INFO - 2022-06-28 10:50:53 --> Helper loaded: file_helper
INFO - 2022-06-28 10:50:53 --> Database Driver Class Initialized
INFO - 2022-06-28 10:50:53 --> Email Class Initialized
DEBUG - 2022-06-28 10:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:50:53 --> Controller Class Initialized
INFO - 2022-06-28 10:50:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:50:53 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:50:53 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 10:50:53 --> Final output sent to browser
DEBUG - 2022-06-28 10:50:53 --> Total execution time: 0.0195
INFO - 2022-06-28 10:52:24 --> Config Class Initialized
INFO - 2022-06-28 10:52:24 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:52:24 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:52:24 --> Utf8 Class Initialized
INFO - 2022-06-28 10:52:24 --> URI Class Initialized
INFO - 2022-06-28 10:52:24 --> Router Class Initialized
INFO - 2022-06-28 10:52:24 --> Output Class Initialized
INFO - 2022-06-28 10:52:24 --> Security Class Initialized
DEBUG - 2022-06-28 10:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:52:24 --> Input Class Initialized
INFO - 2022-06-28 10:52:24 --> Language Class Initialized
INFO - 2022-06-28 10:52:24 --> Loader Class Initialized
INFO - 2022-06-28 10:52:24 --> Helper loaded: url_helper
INFO - 2022-06-28 10:52:24 --> Helper loaded: file_helper
INFO - 2022-06-28 10:52:24 --> Database Driver Class Initialized
INFO - 2022-06-28 10:52:24 --> Email Class Initialized
DEBUG - 2022-06-28 10:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:52:24 --> Controller Class Initialized
INFO - 2022-06-28 10:52:24 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:52:24 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:52:24 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 10:52:24 --> Final output sent to browser
DEBUG - 2022-06-28 10:52:24 --> Total execution time: 0.1322
INFO - 2022-06-28 10:52:32 --> Config Class Initialized
INFO - 2022-06-28 10:52:32 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:52:32 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:52:32 --> Utf8 Class Initialized
INFO - 2022-06-28 10:52:32 --> URI Class Initialized
INFO - 2022-06-28 10:52:32 --> Router Class Initialized
INFO - 2022-06-28 10:52:32 --> Output Class Initialized
INFO - 2022-06-28 10:52:32 --> Security Class Initialized
DEBUG - 2022-06-28 10:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:52:32 --> Input Class Initialized
INFO - 2022-06-28 10:52:32 --> Language Class Initialized
INFO - 2022-06-28 10:52:32 --> Loader Class Initialized
INFO - 2022-06-28 10:52:32 --> Helper loaded: url_helper
INFO - 2022-06-28 10:52:32 --> Helper loaded: file_helper
INFO - 2022-06-28 10:52:32 --> Database Driver Class Initialized
INFO - 2022-06-28 10:52:32 --> Email Class Initialized
DEBUG - 2022-06-28 10:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:52:32 --> Controller Class Initialized
INFO - 2022-06-28 10:52:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:52:32 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:52:32 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 10:52:32 --> Final output sent to browser
DEBUG - 2022-06-28 10:52:32 --> Total execution time: 0.0180
INFO - 2022-06-28 10:54:13 --> Config Class Initialized
INFO - 2022-06-28 10:54:13 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:54:13 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:54:13 --> Utf8 Class Initialized
INFO - 2022-06-28 10:54:13 --> URI Class Initialized
INFO - 2022-06-28 10:54:13 --> Router Class Initialized
INFO - 2022-06-28 10:54:13 --> Output Class Initialized
INFO - 2022-06-28 10:54:13 --> Security Class Initialized
DEBUG - 2022-06-28 10:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:54:13 --> Input Class Initialized
INFO - 2022-06-28 10:54:13 --> Language Class Initialized
INFO - 2022-06-28 10:54:13 --> Loader Class Initialized
INFO - 2022-06-28 10:54:13 --> Helper loaded: url_helper
INFO - 2022-06-28 10:54:13 --> Helper loaded: file_helper
INFO - 2022-06-28 10:54:13 --> Database Driver Class Initialized
INFO - 2022-06-28 10:54:13 --> Email Class Initialized
DEBUG - 2022-06-28 10:54:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:54:13 --> Controller Class Initialized
INFO - 2022-06-28 10:54:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:54:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 10:54:13 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\qr\application\views\reception screen\qr.php 165
INFO - 2022-06-28 10:54:13 --> File loaded: C:\wamp64\www\qr\application\views\reception screen/qr.php
INFO - 2022-06-28 10:54:13 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 10:54:13 --> Final output sent to browser
DEBUG - 2022-06-28 10:54:13 --> Total execution time: 0.0446
INFO - 2022-06-28 10:54:53 --> Config Class Initialized
INFO - 2022-06-28 10:54:53 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:54:53 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:54:53 --> Utf8 Class Initialized
INFO - 2022-06-28 10:54:53 --> URI Class Initialized
INFO - 2022-06-28 10:54:53 --> Router Class Initialized
INFO - 2022-06-28 10:54:53 --> Output Class Initialized
INFO - 2022-06-28 10:54:53 --> Security Class Initialized
DEBUG - 2022-06-28 10:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:54:53 --> Input Class Initialized
INFO - 2022-06-28 10:54:53 --> Language Class Initialized
INFO - 2022-06-28 10:54:53 --> Loader Class Initialized
INFO - 2022-06-28 10:54:53 --> Helper loaded: url_helper
INFO - 2022-06-28 10:54:53 --> Helper loaded: file_helper
INFO - 2022-06-28 10:54:53 --> Database Driver Class Initialized
INFO - 2022-06-28 10:54:54 --> Email Class Initialized
DEBUG - 2022-06-28 10:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:54:54 --> Controller Class Initialized
INFO - 2022-06-28 10:54:54 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:54:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 10:54:54 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\qr\application\views\reception screen\qr.php 165
INFO - 2022-06-28 10:54:54 --> File loaded: C:\wamp64\www\qr\application\views\reception screen/qr.php
INFO - 2022-06-28 10:54:54 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 10:54:54 --> Final output sent to browser
DEBUG - 2022-06-28 10:54:54 --> Total execution time: 0.1566
INFO - 2022-06-28 10:55:57 --> Config Class Initialized
INFO - 2022-06-28 10:55:57 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:55:57 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:55:57 --> Utf8 Class Initialized
INFO - 2022-06-28 10:55:57 --> URI Class Initialized
INFO - 2022-06-28 10:55:57 --> Router Class Initialized
INFO - 2022-06-28 10:55:57 --> Output Class Initialized
INFO - 2022-06-28 10:55:57 --> Security Class Initialized
DEBUG - 2022-06-28 10:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:55:57 --> Input Class Initialized
INFO - 2022-06-28 10:55:57 --> Language Class Initialized
INFO - 2022-06-28 10:55:57 --> Loader Class Initialized
INFO - 2022-06-28 10:55:57 --> Helper loaded: url_helper
INFO - 2022-06-28 10:55:57 --> Helper loaded: file_helper
INFO - 2022-06-28 10:55:57 --> Database Driver Class Initialized
INFO - 2022-06-28 10:55:57 --> Email Class Initialized
DEBUG - 2022-06-28 10:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:55:57 --> Controller Class Initialized
INFO - 2022-06-28 10:55:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:55:57 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:55:57 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 10:55:57 --> Final output sent to browser
DEBUG - 2022-06-28 10:55:57 --> Total execution time: 0.0505
INFO - 2022-06-28 10:55:59 --> Config Class Initialized
INFO - 2022-06-28 10:55:59 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:55:59 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:55:59 --> Utf8 Class Initialized
INFO - 2022-06-28 10:55:59 --> URI Class Initialized
INFO - 2022-06-28 10:55:59 --> Router Class Initialized
INFO - 2022-06-28 10:55:59 --> Output Class Initialized
INFO - 2022-06-28 10:55:59 --> Security Class Initialized
DEBUG - 2022-06-28 10:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:55:59 --> Input Class Initialized
INFO - 2022-06-28 10:55:59 --> Language Class Initialized
INFO - 2022-06-28 10:55:59 --> Loader Class Initialized
INFO - 2022-06-28 10:55:59 --> Helper loaded: url_helper
INFO - 2022-06-28 10:55:59 --> Helper loaded: file_helper
INFO - 2022-06-28 10:55:59 --> Database Driver Class Initialized
INFO - 2022-06-28 10:55:59 --> Email Class Initialized
DEBUG - 2022-06-28 10:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:55:59 --> Controller Class Initialized
INFO - 2022-06-28 10:55:59 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:55:59 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:55:59 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 10:55:59 --> Final output sent to browser
DEBUG - 2022-06-28 10:55:59 --> Total execution time: 0.0183
INFO - 2022-06-28 10:56:01 --> Config Class Initialized
INFO - 2022-06-28 10:56:01 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:56:01 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:56:01 --> Utf8 Class Initialized
INFO - 2022-06-28 10:56:01 --> URI Class Initialized
INFO - 2022-06-28 10:56:01 --> Router Class Initialized
INFO - 2022-06-28 10:56:01 --> Output Class Initialized
INFO - 2022-06-28 10:56:01 --> Security Class Initialized
DEBUG - 2022-06-28 10:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:56:01 --> Input Class Initialized
INFO - 2022-06-28 10:56:01 --> Language Class Initialized
INFO - 2022-06-28 10:56:01 --> Loader Class Initialized
INFO - 2022-06-28 10:56:01 --> Helper loaded: url_helper
INFO - 2022-06-28 10:56:01 --> Helper loaded: file_helper
INFO - 2022-06-28 10:56:01 --> Database Driver Class Initialized
INFO - 2022-06-28 10:56:01 --> Email Class Initialized
DEBUG - 2022-06-28 10:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:56:01 --> Controller Class Initialized
INFO - 2022-06-28 10:56:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:56:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:56:02 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 10:56:02 --> Final output sent to browser
DEBUG - 2022-06-28 10:56:02 --> Total execution time: 0.1835
INFO - 2022-06-28 10:56:06 --> Config Class Initialized
INFO - 2022-06-28 10:56:06 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:56:06 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:56:06 --> Utf8 Class Initialized
INFO - 2022-06-28 10:56:06 --> URI Class Initialized
INFO - 2022-06-28 10:56:06 --> Router Class Initialized
INFO - 2022-06-28 10:56:06 --> Output Class Initialized
INFO - 2022-06-28 10:56:06 --> Security Class Initialized
DEBUG - 2022-06-28 10:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:56:06 --> Input Class Initialized
INFO - 2022-06-28 10:56:06 --> Language Class Initialized
INFO - 2022-06-28 10:56:06 --> Loader Class Initialized
INFO - 2022-06-28 10:56:06 --> Helper loaded: url_helper
INFO - 2022-06-28 10:56:06 --> Helper loaded: file_helper
INFO - 2022-06-28 10:56:06 --> Database Driver Class Initialized
INFO - 2022-06-28 10:56:06 --> Email Class Initialized
DEBUG - 2022-06-28 10:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:56:06 --> Controller Class Initialized
INFO - 2022-06-28 10:56:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:56:06 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:56:06 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 10:56:06 --> Final output sent to browser
DEBUG - 2022-06-28 10:56:06 --> Total execution time: 0.0219
INFO - 2022-06-28 10:56:08 --> Config Class Initialized
INFO - 2022-06-28 10:56:08 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:56:08 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:56:08 --> Utf8 Class Initialized
INFO - 2022-06-28 10:56:08 --> URI Class Initialized
INFO - 2022-06-28 10:56:08 --> Router Class Initialized
INFO - 2022-06-28 10:56:08 --> Output Class Initialized
INFO - 2022-06-28 10:56:08 --> Security Class Initialized
DEBUG - 2022-06-28 10:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:56:08 --> Input Class Initialized
INFO - 2022-06-28 10:56:08 --> Language Class Initialized
INFO - 2022-06-28 10:56:08 --> Loader Class Initialized
INFO - 2022-06-28 10:56:08 --> Helper loaded: url_helper
INFO - 2022-06-28 10:56:08 --> Helper loaded: file_helper
INFO - 2022-06-28 10:56:08 --> Database Driver Class Initialized
INFO - 2022-06-28 10:56:08 --> Email Class Initialized
DEBUG - 2022-06-28 10:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:56:08 --> Controller Class Initialized
INFO - 2022-06-28 10:56:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:56:08 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:56:08 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 10:56:08 --> Final output sent to browser
DEBUG - 2022-06-28 10:56:08 --> Total execution time: 0.0221
INFO - 2022-06-28 10:56:09 --> Config Class Initialized
INFO - 2022-06-28 10:56:09 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:56:09 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:56:09 --> Utf8 Class Initialized
INFO - 2022-06-28 10:56:09 --> URI Class Initialized
INFO - 2022-06-28 10:56:09 --> Router Class Initialized
INFO - 2022-06-28 10:56:09 --> Output Class Initialized
INFO - 2022-06-28 10:56:09 --> Security Class Initialized
DEBUG - 2022-06-28 10:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:56:09 --> Input Class Initialized
INFO - 2022-06-28 10:56:09 --> Language Class Initialized
INFO - 2022-06-28 10:56:09 --> Loader Class Initialized
INFO - 2022-06-28 10:56:09 --> Helper loaded: url_helper
INFO - 2022-06-28 10:56:09 --> Helper loaded: file_helper
INFO - 2022-06-28 10:56:09 --> Database Driver Class Initialized
INFO - 2022-06-28 10:56:09 --> Email Class Initialized
DEBUG - 2022-06-28 10:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:56:09 --> Controller Class Initialized
INFO - 2022-06-28 10:56:09 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:56:09 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:56:09 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 10:56:09 --> Final output sent to browser
DEBUG - 2022-06-28 10:56:09 --> Total execution time: 0.0349
INFO - 2022-06-28 10:56:10 --> Config Class Initialized
INFO - 2022-06-28 10:56:10 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:56:10 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:56:10 --> Utf8 Class Initialized
INFO - 2022-06-28 10:56:10 --> URI Class Initialized
INFO - 2022-06-28 10:56:10 --> Router Class Initialized
INFO - 2022-06-28 10:56:10 --> Output Class Initialized
INFO - 2022-06-28 10:56:10 --> Security Class Initialized
DEBUG - 2022-06-28 10:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:56:10 --> Input Class Initialized
INFO - 2022-06-28 10:56:10 --> Language Class Initialized
INFO - 2022-06-28 10:56:10 --> Loader Class Initialized
INFO - 2022-06-28 10:56:10 --> Helper loaded: url_helper
INFO - 2022-06-28 10:56:10 --> Helper loaded: file_helper
INFO - 2022-06-28 10:56:10 --> Database Driver Class Initialized
INFO - 2022-06-28 10:56:10 --> Email Class Initialized
DEBUG - 2022-06-28 10:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:56:10 --> Controller Class Initialized
INFO - 2022-06-28 10:56:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:56:10 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:56:10 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 10:56:10 --> Final output sent to browser
DEBUG - 2022-06-28 10:56:10 --> Total execution time: 0.1527
INFO - 2022-06-28 10:56:11 --> Config Class Initialized
INFO - 2022-06-28 10:56:11 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:56:11 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:56:11 --> Utf8 Class Initialized
INFO - 2022-06-28 10:56:11 --> URI Class Initialized
INFO - 2022-06-28 10:56:11 --> Router Class Initialized
INFO - 2022-06-28 10:56:11 --> Output Class Initialized
INFO - 2022-06-28 10:56:11 --> Security Class Initialized
DEBUG - 2022-06-28 10:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:56:11 --> Input Class Initialized
INFO - 2022-06-28 10:56:11 --> Language Class Initialized
INFO - 2022-06-28 10:56:11 --> Loader Class Initialized
INFO - 2022-06-28 10:56:11 --> Helper loaded: url_helper
INFO - 2022-06-28 10:56:11 --> Helper loaded: file_helper
INFO - 2022-06-28 10:56:11 --> Database Driver Class Initialized
INFO - 2022-06-28 10:56:11 --> Email Class Initialized
DEBUG - 2022-06-28 10:56:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:56:11 --> Controller Class Initialized
INFO - 2022-06-28 10:56:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:56:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:56:11 --> Final output sent to browser
DEBUG - 2022-06-28 10:56:11 --> Total execution time: 0.0197
INFO - 2022-06-28 10:56:12 --> Config Class Initialized
INFO - 2022-06-28 10:56:12 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:56:12 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:56:12 --> Utf8 Class Initialized
INFO - 2022-06-28 10:56:12 --> URI Class Initialized
INFO - 2022-06-28 10:56:12 --> Router Class Initialized
INFO - 2022-06-28 10:56:12 --> Output Class Initialized
INFO - 2022-06-28 10:56:12 --> Security Class Initialized
DEBUG - 2022-06-28 10:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:56:12 --> Input Class Initialized
INFO - 2022-06-28 10:56:12 --> Language Class Initialized
INFO - 2022-06-28 10:56:12 --> Loader Class Initialized
INFO - 2022-06-28 10:56:12 --> Helper loaded: url_helper
INFO - 2022-06-28 10:56:12 --> Helper loaded: file_helper
INFO - 2022-06-28 10:56:12 --> Database Driver Class Initialized
INFO - 2022-06-28 10:56:12 --> Email Class Initialized
DEBUG - 2022-06-28 10:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:56:12 --> Controller Class Initialized
INFO - 2022-06-28 10:56:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:56:12 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:56:12 --> Final output sent to browser
DEBUG - 2022-06-28 10:56:12 --> Total execution time: 0.0301
INFO - 2022-06-28 10:56:12 --> Config Class Initialized
INFO - 2022-06-28 10:56:12 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:56:12 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:56:12 --> Utf8 Class Initialized
INFO - 2022-06-28 10:56:12 --> URI Class Initialized
INFO - 2022-06-28 10:56:12 --> Router Class Initialized
INFO - 2022-06-28 10:56:12 --> Output Class Initialized
INFO - 2022-06-28 10:56:12 --> Security Class Initialized
DEBUG - 2022-06-28 10:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:56:12 --> Input Class Initialized
INFO - 2022-06-28 10:56:12 --> Language Class Initialized
INFO - 2022-06-28 10:56:12 --> Loader Class Initialized
INFO - 2022-06-28 10:56:12 --> Helper loaded: url_helper
INFO - 2022-06-28 10:56:12 --> Helper loaded: file_helper
INFO - 2022-06-28 10:56:12 --> Database Driver Class Initialized
INFO - 2022-06-28 10:56:12 --> Email Class Initialized
DEBUG - 2022-06-28 10:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:56:12 --> Controller Class Initialized
INFO - 2022-06-28 10:56:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:56:12 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:56:12 --> Final output sent to browser
DEBUG - 2022-06-28 10:56:12 --> Total execution time: 0.0285
INFO - 2022-06-28 10:56:13 --> Config Class Initialized
INFO - 2022-06-28 10:56:13 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:56:13 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:56:13 --> Utf8 Class Initialized
INFO - 2022-06-28 10:56:13 --> URI Class Initialized
INFO - 2022-06-28 10:56:13 --> Router Class Initialized
INFO - 2022-06-28 10:56:13 --> Output Class Initialized
INFO - 2022-06-28 10:56:13 --> Security Class Initialized
DEBUG - 2022-06-28 10:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:56:13 --> Input Class Initialized
INFO - 2022-06-28 10:56:13 --> Language Class Initialized
INFO - 2022-06-28 10:56:13 --> Loader Class Initialized
INFO - 2022-06-28 10:56:13 --> Helper loaded: url_helper
INFO - 2022-06-28 10:56:13 --> Helper loaded: file_helper
INFO - 2022-06-28 10:56:13 --> Database Driver Class Initialized
INFO - 2022-06-28 10:56:13 --> Email Class Initialized
DEBUG - 2022-06-28 10:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:56:13 --> Controller Class Initialized
INFO - 2022-06-28 10:56:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:56:13 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:56:13 --> Final output sent to browser
DEBUG - 2022-06-28 10:56:13 --> Total execution time: 0.0172
INFO - 2022-06-28 10:56:13 --> Config Class Initialized
INFO - 2022-06-28 10:56:13 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:56:13 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:56:13 --> Utf8 Class Initialized
INFO - 2022-06-28 10:56:13 --> URI Class Initialized
INFO - 2022-06-28 10:56:13 --> Router Class Initialized
INFO - 2022-06-28 10:56:13 --> Output Class Initialized
INFO - 2022-06-28 10:56:13 --> Security Class Initialized
DEBUG - 2022-06-28 10:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:56:14 --> Input Class Initialized
INFO - 2022-06-28 10:56:14 --> Language Class Initialized
INFO - 2022-06-28 10:56:14 --> Loader Class Initialized
INFO - 2022-06-28 10:56:14 --> Helper loaded: url_helper
INFO - 2022-06-28 10:56:14 --> Helper loaded: file_helper
INFO - 2022-06-28 10:56:14 --> Database Driver Class Initialized
INFO - 2022-06-28 10:56:14 --> Email Class Initialized
DEBUG - 2022-06-28 10:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:56:14 --> Controller Class Initialized
INFO - 2022-06-28 10:56:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:56:14 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:56:14 --> Final output sent to browser
DEBUG - 2022-06-28 10:56:14 --> Total execution time: 0.0176
INFO - 2022-06-28 10:56:14 --> Config Class Initialized
INFO - 2022-06-28 10:56:14 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:56:14 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:56:14 --> Utf8 Class Initialized
INFO - 2022-06-28 10:56:14 --> URI Class Initialized
INFO - 2022-06-28 10:56:14 --> Router Class Initialized
INFO - 2022-06-28 10:56:14 --> Output Class Initialized
INFO - 2022-06-28 10:56:14 --> Security Class Initialized
DEBUG - 2022-06-28 10:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:56:14 --> Input Class Initialized
INFO - 2022-06-28 10:56:14 --> Language Class Initialized
INFO - 2022-06-28 10:56:14 --> Loader Class Initialized
INFO - 2022-06-28 10:56:14 --> Helper loaded: url_helper
INFO - 2022-06-28 10:56:14 --> Helper loaded: file_helper
INFO - 2022-06-28 10:56:14 --> Database Driver Class Initialized
INFO - 2022-06-28 10:56:14 --> Email Class Initialized
DEBUG - 2022-06-28 10:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:56:14 --> Controller Class Initialized
INFO - 2022-06-28 10:56:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:56:14 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:56:14 --> Final output sent to browser
DEBUG - 2022-06-28 10:56:14 --> Total execution time: 0.0287
INFO - 2022-06-28 10:56:14 --> Config Class Initialized
INFO - 2022-06-28 10:56:14 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:56:14 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:56:14 --> Utf8 Class Initialized
INFO - 2022-06-28 10:56:14 --> URI Class Initialized
INFO - 2022-06-28 10:56:14 --> Router Class Initialized
INFO - 2022-06-28 10:56:14 --> Output Class Initialized
INFO - 2022-06-28 10:56:14 --> Security Class Initialized
DEBUG - 2022-06-28 10:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:56:14 --> Input Class Initialized
INFO - 2022-06-28 10:56:14 --> Language Class Initialized
INFO - 2022-06-28 10:56:14 --> Loader Class Initialized
INFO - 2022-06-28 10:56:14 --> Helper loaded: url_helper
INFO - 2022-06-28 10:56:14 --> Helper loaded: file_helper
INFO - 2022-06-28 10:56:14 --> Database Driver Class Initialized
INFO - 2022-06-28 10:56:14 --> Email Class Initialized
DEBUG - 2022-06-28 10:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:56:14 --> Controller Class Initialized
INFO - 2022-06-28 10:56:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:56:14 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:56:14 --> Final output sent to browser
DEBUG - 2022-06-28 10:56:14 --> Total execution time: 0.0177
INFO - 2022-06-28 10:56:14 --> Config Class Initialized
INFO - 2022-06-28 10:56:14 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:56:14 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:56:14 --> Utf8 Class Initialized
INFO - 2022-06-28 10:56:14 --> URI Class Initialized
INFO - 2022-06-28 10:56:14 --> Router Class Initialized
INFO - 2022-06-28 10:56:14 --> Output Class Initialized
INFO - 2022-06-28 10:56:14 --> Security Class Initialized
DEBUG - 2022-06-28 10:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:56:14 --> Input Class Initialized
INFO - 2022-06-28 10:56:14 --> Language Class Initialized
INFO - 2022-06-28 10:56:14 --> Loader Class Initialized
INFO - 2022-06-28 10:56:14 --> Helper loaded: url_helper
INFO - 2022-06-28 10:56:14 --> Helper loaded: file_helper
INFO - 2022-06-28 10:56:14 --> Database Driver Class Initialized
INFO - 2022-06-28 10:56:14 --> Email Class Initialized
DEBUG - 2022-06-28 10:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:56:14 --> Controller Class Initialized
INFO - 2022-06-28 10:56:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:56:14 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:56:14 --> Final output sent to browser
DEBUG - 2022-06-28 10:56:14 --> Total execution time: 0.0263
INFO - 2022-06-28 10:56:15 --> Config Class Initialized
INFO - 2022-06-28 10:56:15 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:56:15 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:56:15 --> Utf8 Class Initialized
INFO - 2022-06-28 10:56:15 --> URI Class Initialized
INFO - 2022-06-28 10:56:15 --> Router Class Initialized
INFO - 2022-06-28 10:56:15 --> Output Class Initialized
INFO - 2022-06-28 10:56:15 --> Security Class Initialized
DEBUG - 2022-06-28 10:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:56:15 --> Input Class Initialized
INFO - 2022-06-28 10:56:15 --> Language Class Initialized
INFO - 2022-06-28 10:56:15 --> Loader Class Initialized
INFO - 2022-06-28 10:56:15 --> Helper loaded: url_helper
INFO - 2022-06-28 10:56:15 --> Helper loaded: file_helper
INFO - 2022-06-28 10:56:15 --> Database Driver Class Initialized
INFO - 2022-06-28 10:56:15 --> Email Class Initialized
DEBUG - 2022-06-28 10:56:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:56:15 --> Controller Class Initialized
INFO - 2022-06-28 10:56:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:56:15 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:56:15 --> Final output sent to browser
DEBUG - 2022-06-28 10:56:15 --> Total execution time: 0.0338
INFO - 2022-06-28 10:56:15 --> Config Class Initialized
INFO - 2022-06-28 10:56:15 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:56:15 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:56:15 --> Utf8 Class Initialized
INFO - 2022-06-28 10:56:15 --> URI Class Initialized
INFO - 2022-06-28 10:56:15 --> Router Class Initialized
INFO - 2022-06-28 10:56:15 --> Output Class Initialized
INFO - 2022-06-28 10:56:15 --> Security Class Initialized
DEBUG - 2022-06-28 10:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:56:15 --> Input Class Initialized
INFO - 2022-06-28 10:56:15 --> Language Class Initialized
INFO - 2022-06-28 10:56:15 --> Loader Class Initialized
INFO - 2022-06-28 10:56:15 --> Helper loaded: url_helper
INFO - 2022-06-28 10:56:15 --> Helper loaded: file_helper
INFO - 2022-06-28 10:56:15 --> Database Driver Class Initialized
INFO - 2022-06-28 10:56:15 --> Email Class Initialized
DEBUG - 2022-06-28 10:56:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:56:15 --> Controller Class Initialized
INFO - 2022-06-28 10:56:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:56:15 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:56:15 --> Final output sent to browser
DEBUG - 2022-06-28 10:56:15 --> Total execution time: 0.0205
INFO - 2022-06-28 10:56:15 --> Config Class Initialized
INFO - 2022-06-28 10:56:15 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:56:15 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:56:15 --> Utf8 Class Initialized
INFO - 2022-06-28 10:56:15 --> URI Class Initialized
INFO - 2022-06-28 10:56:15 --> Router Class Initialized
INFO - 2022-06-28 10:56:15 --> Output Class Initialized
INFO - 2022-06-28 10:56:15 --> Security Class Initialized
DEBUG - 2022-06-28 10:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:56:15 --> Input Class Initialized
INFO - 2022-06-28 10:56:15 --> Language Class Initialized
INFO - 2022-06-28 10:56:15 --> Loader Class Initialized
INFO - 2022-06-28 10:56:15 --> Helper loaded: url_helper
INFO - 2022-06-28 10:56:15 --> Helper loaded: file_helper
INFO - 2022-06-28 10:56:15 --> Database Driver Class Initialized
INFO - 2022-06-28 10:56:15 --> Email Class Initialized
DEBUG - 2022-06-28 10:56:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:56:15 --> Controller Class Initialized
INFO - 2022-06-28 10:56:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:56:15 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:56:15 --> Final output sent to browser
DEBUG - 2022-06-28 10:56:15 --> Total execution time: 0.0189
INFO - 2022-06-28 10:57:28 --> Config Class Initialized
INFO - 2022-06-28 10:57:28 --> Hooks Class Initialized
DEBUG - 2022-06-28 10:57:28 --> UTF-8 Support Enabled
INFO - 2022-06-28 10:57:28 --> Utf8 Class Initialized
INFO - 2022-06-28 10:57:28 --> URI Class Initialized
INFO - 2022-06-28 10:57:28 --> Router Class Initialized
INFO - 2022-06-28 10:57:28 --> Output Class Initialized
INFO - 2022-06-28 10:57:28 --> Security Class Initialized
DEBUG - 2022-06-28 10:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 10:57:28 --> Input Class Initialized
INFO - 2022-06-28 10:57:28 --> Language Class Initialized
INFO - 2022-06-28 10:57:28 --> Loader Class Initialized
INFO - 2022-06-28 10:57:28 --> Helper loaded: url_helper
INFO - 2022-06-28 10:57:28 --> Helper loaded: file_helper
INFO - 2022-06-28 10:57:28 --> Database Driver Class Initialized
INFO - 2022-06-28 10:57:28 --> Email Class Initialized
DEBUG - 2022-06-28 10:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 10:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 10:57:28 --> Controller Class Initialized
INFO - 2022-06-28 10:57:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 10:57:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 10:57:28 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 10:57:28 --> Final output sent to browser
DEBUG - 2022-06-28 10:57:28 --> Total execution time: 0.0224
INFO - 2022-06-28 11:10:01 --> Config Class Initialized
INFO - 2022-06-28 11:10:01 --> Hooks Class Initialized
DEBUG - 2022-06-28 11:10:01 --> UTF-8 Support Enabled
INFO - 2022-06-28 11:10:01 --> Utf8 Class Initialized
INFO - 2022-06-28 11:10:01 --> URI Class Initialized
INFO - 2022-06-28 11:10:01 --> Router Class Initialized
INFO - 2022-06-28 11:10:01 --> Output Class Initialized
INFO - 2022-06-28 11:10:01 --> Security Class Initialized
DEBUG - 2022-06-28 11:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 11:10:01 --> Input Class Initialized
INFO - 2022-06-28 11:10:01 --> Language Class Initialized
INFO - 2022-06-28 11:10:01 --> Loader Class Initialized
INFO - 2022-06-28 11:10:01 --> Helper loaded: url_helper
INFO - 2022-06-28 11:10:01 --> Helper loaded: file_helper
INFO - 2022-06-28 11:10:01 --> Database Driver Class Initialized
INFO - 2022-06-28 11:10:01 --> Email Class Initialized
DEBUG - 2022-06-28 11:10:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 11:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 11:10:01 --> Controller Class Initialized
INFO - 2022-06-28 11:10:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 11:10:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 11:10:01 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 11:10:01 --> Final output sent to browser
DEBUG - 2022-06-28 11:10:01 --> Total execution time: 0.0314
INFO - 2022-06-28 11:10:07 --> Config Class Initialized
INFO - 2022-06-28 11:10:07 --> Hooks Class Initialized
DEBUG - 2022-06-28 11:10:07 --> UTF-8 Support Enabled
INFO - 2022-06-28 11:10:07 --> Utf8 Class Initialized
INFO - 2022-06-28 11:10:07 --> URI Class Initialized
INFO - 2022-06-28 11:10:07 --> Router Class Initialized
INFO - 2022-06-28 11:10:07 --> Output Class Initialized
INFO - 2022-06-28 11:10:07 --> Security Class Initialized
DEBUG - 2022-06-28 11:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 11:10:07 --> Input Class Initialized
INFO - 2022-06-28 11:10:07 --> Language Class Initialized
INFO - 2022-06-28 11:10:07 --> Loader Class Initialized
INFO - 2022-06-28 11:10:07 --> Helper loaded: url_helper
INFO - 2022-06-28 11:10:07 --> Helper loaded: file_helper
INFO - 2022-06-28 11:10:07 --> Database Driver Class Initialized
INFO - 2022-06-28 11:10:07 --> Email Class Initialized
DEBUG - 2022-06-28 11:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 11:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 11:10:07 --> Controller Class Initialized
INFO - 2022-06-28 11:10:07 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 11:10:07 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 11:10:08 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 11:10:08 --> Final output sent to browser
DEBUG - 2022-06-28 11:10:08 --> Total execution time: 0.1691
INFO - 2022-06-28 11:10:48 --> Config Class Initialized
INFO - 2022-06-28 11:10:48 --> Hooks Class Initialized
DEBUG - 2022-06-28 11:10:48 --> UTF-8 Support Enabled
INFO - 2022-06-28 11:10:48 --> Utf8 Class Initialized
INFO - 2022-06-28 11:10:48 --> URI Class Initialized
INFO - 2022-06-28 11:10:48 --> Router Class Initialized
INFO - 2022-06-28 11:10:48 --> Output Class Initialized
INFO - 2022-06-28 11:10:48 --> Security Class Initialized
DEBUG - 2022-06-28 11:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 11:10:48 --> Input Class Initialized
INFO - 2022-06-28 11:10:48 --> Language Class Initialized
INFO - 2022-06-28 11:10:48 --> Loader Class Initialized
INFO - 2022-06-28 11:10:48 --> Helper loaded: url_helper
INFO - 2022-06-28 11:10:48 --> Helper loaded: file_helper
INFO - 2022-06-28 11:10:48 --> Database Driver Class Initialized
INFO - 2022-06-28 11:10:48 --> Email Class Initialized
DEBUG - 2022-06-28 11:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 11:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 11:10:48 --> Controller Class Initialized
INFO - 2022-06-28 11:10:48 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 11:10:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 11:10:49 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\reception screen\qr.php 178
INFO - 2022-06-28 11:10:49 --> File loaded: C:\wamp64\www\qr\application\views\reception screen/qr.php
INFO - 2022-06-28 11:10:49 --> Final output sent to browser
DEBUG - 2022-06-28 11:10:49 --> Total execution time: 0.0318
INFO - 2022-06-28 11:14:23 --> Config Class Initialized
INFO - 2022-06-28 11:14:23 --> Hooks Class Initialized
DEBUG - 2022-06-28 11:14:23 --> UTF-8 Support Enabled
INFO - 2022-06-28 11:14:23 --> Utf8 Class Initialized
INFO - 2022-06-28 11:14:23 --> URI Class Initialized
INFO - 2022-06-28 11:14:23 --> Router Class Initialized
INFO - 2022-06-28 11:14:23 --> Output Class Initialized
INFO - 2022-06-28 11:14:23 --> Security Class Initialized
DEBUG - 2022-06-28 11:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 11:14:23 --> Input Class Initialized
INFO - 2022-06-28 11:14:23 --> Language Class Initialized
INFO - 2022-06-28 11:14:23 --> Loader Class Initialized
INFO - 2022-06-28 11:14:23 --> Helper loaded: url_helper
INFO - 2022-06-28 11:14:23 --> Helper loaded: file_helper
INFO - 2022-06-28 11:14:23 --> Database Driver Class Initialized
INFO - 2022-06-28 11:14:23 --> Email Class Initialized
DEBUG - 2022-06-28 11:14:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 11:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 11:14:23 --> Controller Class Initialized
INFO - 2022-06-28 11:14:23 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 11:14:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 11:14:23 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\reception screen\qr.php 178
INFO - 2022-06-28 11:14:23 --> File loaded: C:\wamp64\www\qr\application\views\reception screen/qr.php
INFO - 2022-06-28 11:14:23 --> Final output sent to browser
DEBUG - 2022-06-28 11:14:23 --> Total execution time: 0.0430
INFO - 2022-06-28 11:15:26 --> Config Class Initialized
INFO - 2022-06-28 11:15:26 --> Hooks Class Initialized
DEBUG - 2022-06-28 11:15:26 --> UTF-8 Support Enabled
INFO - 2022-06-28 11:15:26 --> Utf8 Class Initialized
INFO - 2022-06-28 11:15:26 --> URI Class Initialized
INFO - 2022-06-28 11:15:26 --> Router Class Initialized
INFO - 2022-06-28 11:15:26 --> Output Class Initialized
INFO - 2022-06-28 11:15:26 --> Security Class Initialized
DEBUG - 2022-06-28 11:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 11:15:26 --> Input Class Initialized
INFO - 2022-06-28 11:15:26 --> Language Class Initialized
INFO - 2022-06-28 11:15:26 --> Loader Class Initialized
INFO - 2022-06-28 11:15:26 --> Helper loaded: url_helper
INFO - 2022-06-28 11:15:26 --> Helper loaded: file_helper
INFO - 2022-06-28 11:15:26 --> Database Driver Class Initialized
INFO - 2022-06-28 11:15:26 --> Email Class Initialized
DEBUG - 2022-06-28 11:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 11:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 11:15:26 --> Controller Class Initialized
INFO - 2022-06-28 11:15:26 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 11:15:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 11:15:26 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\reception screen\qr.php 178
INFO - 2022-06-28 11:15:26 --> File loaded: C:\wamp64\www\qr\application\views\reception screen/qr.php
INFO - 2022-06-28 11:15:26 --> Final output sent to browser
DEBUG - 2022-06-28 11:15:26 --> Total execution time: 0.0212
INFO - 2022-06-28 11:15:29 --> Config Class Initialized
INFO - 2022-06-28 11:15:29 --> Hooks Class Initialized
DEBUG - 2022-06-28 11:15:29 --> UTF-8 Support Enabled
INFO - 2022-06-28 11:15:29 --> Utf8 Class Initialized
INFO - 2022-06-28 11:15:29 --> URI Class Initialized
INFO - 2022-06-28 11:15:29 --> Router Class Initialized
INFO - 2022-06-28 11:15:29 --> Output Class Initialized
INFO - 2022-06-28 11:15:29 --> Security Class Initialized
DEBUG - 2022-06-28 11:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 11:15:29 --> Input Class Initialized
INFO - 2022-06-28 11:15:29 --> Language Class Initialized
INFO - 2022-06-28 11:15:29 --> Loader Class Initialized
INFO - 2022-06-28 11:15:29 --> Helper loaded: url_helper
INFO - 2022-06-28 11:15:29 --> Helper loaded: file_helper
INFO - 2022-06-28 11:15:29 --> Database Driver Class Initialized
INFO - 2022-06-28 11:15:29 --> Email Class Initialized
DEBUG - 2022-06-28 11:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 11:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 11:15:29 --> Controller Class Initialized
INFO - 2022-06-28 11:15:29 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 11:15:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 11:15:29 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\reception screen\qr.php 178
INFO - 2022-06-28 11:15:29 --> File loaded: C:\wamp64\www\qr\application\views\reception screen/qr.php
INFO - 2022-06-28 11:15:29 --> Final output sent to browser
DEBUG - 2022-06-28 11:15:29 --> Total execution time: 0.0196
INFO - 2022-06-28 11:17:08 --> Config Class Initialized
INFO - 2022-06-28 11:17:08 --> Hooks Class Initialized
DEBUG - 2022-06-28 11:17:08 --> UTF-8 Support Enabled
INFO - 2022-06-28 11:17:08 --> Utf8 Class Initialized
INFO - 2022-06-28 11:17:08 --> URI Class Initialized
INFO - 2022-06-28 11:17:08 --> Router Class Initialized
INFO - 2022-06-28 11:17:08 --> Output Class Initialized
INFO - 2022-06-28 11:17:08 --> Security Class Initialized
DEBUG - 2022-06-28 11:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 11:17:08 --> Input Class Initialized
INFO - 2022-06-28 11:17:08 --> Language Class Initialized
INFO - 2022-06-28 11:17:08 --> Loader Class Initialized
INFO - 2022-06-28 11:17:08 --> Helper loaded: url_helper
INFO - 2022-06-28 11:17:08 --> Helper loaded: file_helper
INFO - 2022-06-28 11:17:09 --> Database Driver Class Initialized
INFO - 2022-06-28 11:17:09 --> Email Class Initialized
DEBUG - 2022-06-28 11:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 11:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 11:17:09 --> Controller Class Initialized
INFO - 2022-06-28 11:17:09 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 11:17:09 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 11:17:09 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 11:17:09 --> Final output sent to browser
DEBUG - 2022-06-28 11:17:09 --> Total execution time: 0.0671
INFO - 2022-06-28 11:17:11 --> Config Class Initialized
INFO - 2022-06-28 11:17:11 --> Hooks Class Initialized
DEBUG - 2022-06-28 11:17:11 --> UTF-8 Support Enabled
INFO - 2022-06-28 11:17:11 --> Utf8 Class Initialized
INFO - 2022-06-28 11:17:11 --> URI Class Initialized
INFO - 2022-06-28 11:17:11 --> Router Class Initialized
INFO - 2022-06-28 11:17:11 --> Output Class Initialized
INFO - 2022-06-28 11:17:11 --> Security Class Initialized
DEBUG - 2022-06-28 11:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 11:17:11 --> Input Class Initialized
INFO - 2022-06-28 11:17:11 --> Language Class Initialized
INFO - 2022-06-28 11:17:11 --> Loader Class Initialized
INFO - 2022-06-28 11:17:11 --> Helper loaded: url_helper
INFO - 2022-06-28 11:17:11 --> Helper loaded: file_helper
INFO - 2022-06-28 11:17:11 --> Database Driver Class Initialized
INFO - 2022-06-28 11:17:11 --> Email Class Initialized
DEBUG - 2022-06-28 11:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 11:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 11:17:11 --> Controller Class Initialized
INFO - 2022-06-28 11:17:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 11:17:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 11:17:11 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 11:17:11 --> Final output sent to browser
DEBUG - 2022-06-28 11:17:11 --> Total execution time: 0.0458
INFO - 2022-06-28 11:17:12 --> Config Class Initialized
INFO - 2022-06-28 11:17:12 --> Hooks Class Initialized
DEBUG - 2022-06-28 11:17:12 --> UTF-8 Support Enabled
INFO - 2022-06-28 11:17:12 --> Utf8 Class Initialized
INFO - 2022-06-28 11:17:12 --> URI Class Initialized
INFO - 2022-06-28 11:17:12 --> Router Class Initialized
INFO - 2022-06-28 11:17:12 --> Output Class Initialized
INFO - 2022-06-28 11:17:12 --> Security Class Initialized
DEBUG - 2022-06-28 11:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 11:17:12 --> Input Class Initialized
INFO - 2022-06-28 11:17:12 --> Language Class Initialized
INFO - 2022-06-28 11:17:12 --> Loader Class Initialized
INFO - 2022-06-28 11:17:12 --> Helper loaded: url_helper
INFO - 2022-06-28 11:17:12 --> Helper loaded: file_helper
INFO - 2022-06-28 11:17:12 --> Database Driver Class Initialized
INFO - 2022-06-28 11:17:12 --> Email Class Initialized
DEBUG - 2022-06-28 11:17:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 11:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 11:17:12 --> Controller Class Initialized
INFO - 2022-06-28 11:17:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 11:17:12 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 11:17:12 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 11:17:12 --> Final output sent to browser
DEBUG - 2022-06-28 11:17:12 --> Total execution time: 0.0265
INFO - 2022-06-28 11:17:13 --> Config Class Initialized
INFO - 2022-06-28 11:17:13 --> Hooks Class Initialized
DEBUG - 2022-06-28 11:17:13 --> UTF-8 Support Enabled
INFO - 2022-06-28 11:17:13 --> Utf8 Class Initialized
INFO - 2022-06-28 11:17:13 --> URI Class Initialized
INFO - 2022-06-28 11:17:13 --> Router Class Initialized
INFO - 2022-06-28 11:17:13 --> Output Class Initialized
INFO - 2022-06-28 11:17:13 --> Security Class Initialized
DEBUG - 2022-06-28 11:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 11:17:13 --> Input Class Initialized
INFO - 2022-06-28 11:17:13 --> Language Class Initialized
INFO - 2022-06-28 11:17:13 --> Loader Class Initialized
INFO - 2022-06-28 11:17:13 --> Helper loaded: url_helper
INFO - 2022-06-28 11:17:13 --> Helper loaded: file_helper
INFO - 2022-06-28 11:17:13 --> Database Driver Class Initialized
INFO - 2022-06-28 11:17:13 --> Email Class Initialized
DEBUG - 2022-06-28 11:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 11:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 11:17:13 --> Controller Class Initialized
INFO - 2022-06-28 11:17:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 11:17:13 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 11:17:13 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 11:17:13 --> Final output sent to browser
DEBUG - 2022-06-28 11:17:13 --> Total execution time: 0.0626
INFO - 2022-06-28 11:17:14 --> Config Class Initialized
INFO - 2022-06-28 11:17:14 --> Hooks Class Initialized
DEBUG - 2022-06-28 11:17:14 --> UTF-8 Support Enabled
INFO - 2022-06-28 11:17:14 --> Utf8 Class Initialized
INFO - 2022-06-28 11:17:14 --> URI Class Initialized
INFO - 2022-06-28 11:17:14 --> Router Class Initialized
INFO - 2022-06-28 11:17:14 --> Output Class Initialized
INFO - 2022-06-28 11:17:14 --> Security Class Initialized
DEBUG - 2022-06-28 11:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 11:17:14 --> Input Class Initialized
INFO - 2022-06-28 11:17:14 --> Language Class Initialized
INFO - 2022-06-28 11:17:14 --> Loader Class Initialized
INFO - 2022-06-28 11:17:14 --> Helper loaded: url_helper
INFO - 2022-06-28 11:17:14 --> Helper loaded: file_helper
INFO - 2022-06-28 11:17:14 --> Database Driver Class Initialized
INFO - 2022-06-28 11:17:14 --> Email Class Initialized
DEBUG - 2022-06-28 11:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 11:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 11:17:14 --> Controller Class Initialized
INFO - 2022-06-28 11:17:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 11:17:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 11:17:14 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 350
INFO - 2022-06-28 11:17:14 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 11:17:14 --> Final output sent to browser
DEBUG - 2022-06-28 11:17:14 --> Total execution time: 0.0206
INFO - 2022-06-28 11:17:15 --> Config Class Initialized
INFO - 2022-06-28 11:17:15 --> Hooks Class Initialized
DEBUG - 2022-06-28 11:17:15 --> UTF-8 Support Enabled
INFO - 2022-06-28 11:17:15 --> Utf8 Class Initialized
INFO - 2022-06-28 11:17:15 --> URI Class Initialized
INFO - 2022-06-28 11:17:15 --> Router Class Initialized
INFO - 2022-06-28 11:17:15 --> Output Class Initialized
INFO - 2022-06-28 11:17:15 --> Security Class Initialized
DEBUG - 2022-06-28 11:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 11:17:15 --> Input Class Initialized
INFO - 2022-06-28 11:17:15 --> Language Class Initialized
INFO - 2022-06-28 11:17:15 --> Loader Class Initialized
INFO - 2022-06-28 11:17:15 --> Helper loaded: url_helper
INFO - 2022-06-28 11:17:15 --> Helper loaded: file_helper
INFO - 2022-06-28 11:17:15 --> Database Driver Class Initialized
INFO - 2022-06-28 11:17:15 --> Email Class Initialized
DEBUG - 2022-06-28 11:17:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 11:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 11:17:15 --> Controller Class Initialized
INFO - 2022-06-28 11:17:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 11:17:15 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 11:17:15 --> Final output sent to browser
DEBUG - 2022-06-28 11:17:15 --> Total execution time: 0.0429
INFO - 2022-06-28 11:17:16 --> Config Class Initialized
INFO - 2022-06-28 11:17:16 --> Hooks Class Initialized
DEBUG - 2022-06-28 11:17:16 --> UTF-8 Support Enabled
INFO - 2022-06-28 11:17:16 --> Utf8 Class Initialized
INFO - 2022-06-28 11:17:16 --> URI Class Initialized
INFO - 2022-06-28 11:17:16 --> Router Class Initialized
INFO - 2022-06-28 11:17:16 --> Output Class Initialized
INFO - 2022-06-28 11:17:16 --> Security Class Initialized
DEBUG - 2022-06-28 11:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 11:17:16 --> Input Class Initialized
INFO - 2022-06-28 11:17:16 --> Language Class Initialized
INFO - 2022-06-28 11:17:16 --> Loader Class Initialized
INFO - 2022-06-28 11:17:16 --> Helper loaded: url_helper
INFO - 2022-06-28 11:17:16 --> Helper loaded: file_helper
INFO - 2022-06-28 11:17:16 --> Database Driver Class Initialized
INFO - 2022-06-28 11:17:16 --> Email Class Initialized
DEBUG - 2022-06-28 11:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 11:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 11:17:16 --> Controller Class Initialized
INFO - 2022-06-28 11:17:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 11:17:16 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 11:17:16 --> Final output sent to browser
DEBUG - 2022-06-28 11:17:16 --> Total execution time: 0.0180
INFO - 2022-06-28 11:17:16 --> Config Class Initialized
INFO - 2022-06-28 11:17:16 --> Hooks Class Initialized
DEBUG - 2022-06-28 11:17:16 --> UTF-8 Support Enabled
INFO - 2022-06-28 11:17:16 --> Utf8 Class Initialized
INFO - 2022-06-28 11:17:16 --> URI Class Initialized
INFO - 2022-06-28 11:17:16 --> Router Class Initialized
INFO - 2022-06-28 11:17:16 --> Output Class Initialized
INFO - 2022-06-28 11:17:16 --> Security Class Initialized
DEBUG - 2022-06-28 11:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 11:17:16 --> Input Class Initialized
INFO - 2022-06-28 11:17:16 --> Language Class Initialized
INFO - 2022-06-28 11:17:16 --> Loader Class Initialized
INFO - 2022-06-28 11:17:16 --> Helper loaded: url_helper
INFO - 2022-06-28 11:17:16 --> Helper loaded: file_helper
INFO - 2022-06-28 11:17:16 --> Database Driver Class Initialized
INFO - 2022-06-28 11:17:16 --> Email Class Initialized
DEBUG - 2022-06-28 11:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 11:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 11:17:16 --> Controller Class Initialized
INFO - 2022-06-28 11:17:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 11:17:16 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 11:17:16 --> Final output sent to browser
DEBUG - 2022-06-28 11:17:16 --> Total execution time: 0.0183
INFO - 2022-06-28 11:17:17 --> Config Class Initialized
INFO - 2022-06-28 11:17:17 --> Hooks Class Initialized
DEBUG - 2022-06-28 11:17:17 --> UTF-8 Support Enabled
INFO - 2022-06-28 11:17:17 --> Utf8 Class Initialized
INFO - 2022-06-28 11:17:17 --> URI Class Initialized
INFO - 2022-06-28 11:17:17 --> Router Class Initialized
INFO - 2022-06-28 11:17:17 --> Output Class Initialized
INFO - 2022-06-28 11:17:17 --> Security Class Initialized
DEBUG - 2022-06-28 11:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 11:17:17 --> Input Class Initialized
INFO - 2022-06-28 11:17:17 --> Language Class Initialized
INFO - 2022-06-28 11:17:17 --> Loader Class Initialized
INFO - 2022-06-28 11:17:17 --> Helper loaded: url_helper
INFO - 2022-06-28 11:17:17 --> Helper loaded: file_helper
INFO - 2022-06-28 11:17:17 --> Database Driver Class Initialized
INFO - 2022-06-28 11:17:17 --> Email Class Initialized
DEBUG - 2022-06-28 11:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 11:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 11:17:17 --> Controller Class Initialized
INFO - 2022-06-28 11:17:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 11:17:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 11:17:17 --> Final output sent to browser
DEBUG - 2022-06-28 11:17:17 --> Total execution time: 0.0206
INFO - 2022-06-28 11:57:24 --> Config Class Initialized
INFO - 2022-06-28 11:57:24 --> Hooks Class Initialized
DEBUG - 2022-06-28 11:57:24 --> UTF-8 Support Enabled
INFO - 2022-06-28 11:57:24 --> Utf8 Class Initialized
INFO - 2022-06-28 11:57:24 --> URI Class Initialized
INFO - 2022-06-28 11:57:24 --> Router Class Initialized
INFO - 2022-06-28 11:57:24 --> Output Class Initialized
INFO - 2022-06-28 11:57:24 --> Security Class Initialized
DEBUG - 2022-06-28 11:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 11:57:24 --> Input Class Initialized
INFO - 2022-06-28 11:57:24 --> Language Class Initialized
INFO - 2022-06-28 11:57:24 --> Loader Class Initialized
INFO - 2022-06-28 11:57:24 --> Helper loaded: url_helper
INFO - 2022-06-28 11:57:24 --> Helper loaded: file_helper
INFO - 2022-06-28 11:57:24 --> Database Driver Class Initialized
INFO - 2022-06-28 11:57:24 --> Email Class Initialized
DEBUG - 2022-06-28 11:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 11:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 11:57:24 --> Controller Class Initialized
INFO - 2022-06-28 11:57:24 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 11:57:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 11:57:24 --> Severity: error --> Exception: syntax error, unexpected 'tick' (T_STRING), expecting ';' or ',' C:\wamp64\www\qr\application\views\doc_screen\doctor.php 352
INFO - 2022-06-28 11:59:49 --> Config Class Initialized
INFO - 2022-06-28 11:59:49 --> Hooks Class Initialized
DEBUG - 2022-06-28 11:59:49 --> UTF-8 Support Enabled
INFO - 2022-06-28 11:59:49 --> Utf8 Class Initialized
INFO - 2022-06-28 11:59:49 --> URI Class Initialized
INFO - 2022-06-28 11:59:49 --> Router Class Initialized
INFO - 2022-06-28 11:59:49 --> Output Class Initialized
INFO - 2022-06-28 11:59:49 --> Security Class Initialized
DEBUG - 2022-06-28 11:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 11:59:49 --> Input Class Initialized
INFO - 2022-06-28 11:59:49 --> Language Class Initialized
INFO - 2022-06-28 11:59:49 --> Loader Class Initialized
INFO - 2022-06-28 11:59:49 --> Helper loaded: url_helper
INFO - 2022-06-28 11:59:49 --> Helper loaded: file_helper
INFO - 2022-06-28 11:59:49 --> Database Driver Class Initialized
INFO - 2022-06-28 11:59:49 --> Email Class Initialized
DEBUG - 2022-06-28 11:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 11:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 11:59:49 --> Controller Class Initialized
INFO - 2022-06-28 11:59:49 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 11:59:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 11:59:49 --> Severity: error --> Exception: syntax error, unexpected '?' C:\wamp64\www\qr\application\views\doc_screen\doctor.php 352
INFO - 2022-06-28 12:01:12 --> Config Class Initialized
INFO - 2022-06-28 12:01:12 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:01:12 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:01:12 --> Utf8 Class Initialized
INFO - 2022-06-28 12:01:12 --> URI Class Initialized
INFO - 2022-06-28 12:01:12 --> Router Class Initialized
INFO - 2022-06-28 12:01:12 --> Output Class Initialized
INFO - 2022-06-28 12:01:12 --> Security Class Initialized
DEBUG - 2022-06-28 12:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:01:12 --> Input Class Initialized
INFO - 2022-06-28 12:01:12 --> Language Class Initialized
INFO - 2022-06-28 12:01:12 --> Loader Class Initialized
INFO - 2022-06-28 12:01:12 --> Helper loaded: url_helper
INFO - 2022-06-28 12:01:12 --> Helper loaded: file_helper
INFO - 2022-06-28 12:01:12 --> Database Driver Class Initialized
INFO - 2022-06-28 12:01:12 --> Email Class Initialized
DEBUG - 2022-06-28 12:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:01:12 --> Controller Class Initialized
INFO - 2022-06-28 12:01:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:01:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 12:01:12 --> Severity: error --> Exception: syntax error, unexpected '?' C:\wamp64\www\qr\application\views\doc_screen\doctor.php 352
INFO - 2022-06-28 12:01:58 --> Config Class Initialized
INFO - 2022-06-28 12:01:58 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:01:58 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:01:58 --> Utf8 Class Initialized
INFO - 2022-06-28 12:01:58 --> URI Class Initialized
INFO - 2022-06-28 12:01:58 --> Router Class Initialized
INFO - 2022-06-28 12:01:58 --> Output Class Initialized
INFO - 2022-06-28 12:01:58 --> Security Class Initialized
DEBUG - 2022-06-28 12:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:01:58 --> Input Class Initialized
INFO - 2022-06-28 12:01:58 --> Language Class Initialized
INFO - 2022-06-28 12:01:58 --> Loader Class Initialized
INFO - 2022-06-28 12:01:58 --> Helper loaded: url_helper
INFO - 2022-06-28 12:01:58 --> Helper loaded: file_helper
INFO - 2022-06-28 12:01:58 --> Database Driver Class Initialized
INFO - 2022-06-28 12:01:58 --> Email Class Initialized
DEBUG - 2022-06-28 12:01:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:01:58 --> Controller Class Initialized
INFO - 2022-06-28 12:01:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:01:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 12:01:58 --> Severity: error --> Exception: syntax error, unexpected '?' C:\wamp64\www\qr\application\views\doc_screen\doctor.php 352
INFO - 2022-06-28 12:02:00 --> Config Class Initialized
INFO - 2022-06-28 12:02:00 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:02:00 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:02:00 --> Utf8 Class Initialized
INFO - 2022-06-28 12:02:00 --> URI Class Initialized
INFO - 2022-06-28 12:02:00 --> Router Class Initialized
INFO - 2022-06-28 12:02:00 --> Output Class Initialized
INFO - 2022-06-28 12:02:00 --> Security Class Initialized
DEBUG - 2022-06-28 12:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:02:00 --> Input Class Initialized
INFO - 2022-06-28 12:02:00 --> Language Class Initialized
INFO - 2022-06-28 12:02:00 --> Loader Class Initialized
INFO - 2022-06-28 12:02:00 --> Helper loaded: url_helper
INFO - 2022-06-28 12:02:00 --> Helper loaded: file_helper
INFO - 2022-06-28 12:02:00 --> Database Driver Class Initialized
INFO - 2022-06-28 12:02:00 --> Email Class Initialized
DEBUG - 2022-06-28 12:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:02:00 --> Controller Class Initialized
INFO - 2022-06-28 12:02:00 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:02:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 12:02:00 --> Severity: error --> Exception: syntax error, unexpected '?' C:\wamp64\www\qr\application\views\doc_screen\doctor.php 352
INFO - 2022-06-28 12:02:01 --> Config Class Initialized
INFO - 2022-06-28 12:02:01 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:02:01 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:02:01 --> Utf8 Class Initialized
INFO - 2022-06-28 12:02:01 --> URI Class Initialized
INFO - 2022-06-28 12:02:01 --> Router Class Initialized
INFO - 2022-06-28 12:02:01 --> Output Class Initialized
INFO - 2022-06-28 12:02:01 --> Security Class Initialized
DEBUG - 2022-06-28 12:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:02:01 --> Input Class Initialized
INFO - 2022-06-28 12:02:01 --> Language Class Initialized
INFO - 2022-06-28 12:02:01 --> Loader Class Initialized
INFO - 2022-06-28 12:02:01 --> Helper loaded: url_helper
INFO - 2022-06-28 12:02:01 --> Helper loaded: file_helper
INFO - 2022-06-28 12:02:01 --> Database Driver Class Initialized
INFO - 2022-06-28 12:02:01 --> Email Class Initialized
DEBUG - 2022-06-28 12:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:02:01 --> Controller Class Initialized
INFO - 2022-06-28 12:02:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:02:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 12:02:01 --> Severity: error --> Exception: syntax error, unexpected '?' C:\wamp64\www\qr\application\views\doc_screen\doctor.php 352
INFO - 2022-06-28 12:02:02 --> Config Class Initialized
INFO - 2022-06-28 12:02:02 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:02:02 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:02:02 --> Utf8 Class Initialized
INFO - 2022-06-28 12:02:02 --> URI Class Initialized
INFO - 2022-06-28 12:02:02 --> Router Class Initialized
INFO - 2022-06-28 12:02:02 --> Output Class Initialized
INFO - 2022-06-28 12:02:02 --> Security Class Initialized
DEBUG - 2022-06-28 12:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:02:02 --> Input Class Initialized
INFO - 2022-06-28 12:02:02 --> Language Class Initialized
INFO - 2022-06-28 12:02:02 --> Loader Class Initialized
INFO - 2022-06-28 12:02:02 --> Helper loaded: url_helper
INFO - 2022-06-28 12:02:02 --> Helper loaded: file_helper
INFO - 2022-06-28 12:02:02 --> Database Driver Class Initialized
INFO - 2022-06-28 12:02:02 --> Email Class Initialized
DEBUG - 2022-06-28 12:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:02:02 --> Controller Class Initialized
INFO - 2022-06-28 12:02:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:02:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 12:02:02 --> Severity: error --> Exception: syntax error, unexpected '?' C:\wamp64\www\qr\application\views\doc_screen\doctor.php 352
INFO - 2022-06-28 12:02:06 --> Config Class Initialized
INFO - 2022-06-28 12:02:06 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:02:06 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:02:06 --> Utf8 Class Initialized
INFO - 2022-06-28 12:02:06 --> URI Class Initialized
INFO - 2022-06-28 12:02:06 --> Router Class Initialized
INFO - 2022-06-28 12:02:06 --> Output Class Initialized
INFO - 2022-06-28 12:02:06 --> Security Class Initialized
DEBUG - 2022-06-28 12:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:02:06 --> Input Class Initialized
INFO - 2022-06-28 12:02:06 --> Language Class Initialized
INFO - 2022-06-28 12:02:06 --> Loader Class Initialized
INFO - 2022-06-28 12:02:06 --> Helper loaded: url_helper
INFO - 2022-06-28 12:02:06 --> Helper loaded: file_helper
INFO - 2022-06-28 12:02:06 --> Database Driver Class Initialized
INFO - 2022-06-28 12:02:06 --> Email Class Initialized
DEBUG - 2022-06-28 12:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:02:06 --> Controller Class Initialized
INFO - 2022-06-28 12:02:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:02:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 12:02:06 --> Severity: error --> Exception: syntax error, unexpected '?' C:\wamp64\www\qr\application\views\doc_screen\doctor.php 352
INFO - 2022-06-28 12:04:31 --> Config Class Initialized
INFO - 2022-06-28 12:04:31 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:04:31 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:04:31 --> Utf8 Class Initialized
INFO - 2022-06-28 12:04:31 --> URI Class Initialized
INFO - 2022-06-28 12:04:31 --> Router Class Initialized
INFO - 2022-06-28 12:04:31 --> Output Class Initialized
INFO - 2022-06-28 12:04:31 --> Security Class Initialized
DEBUG - 2022-06-28 12:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:04:31 --> Input Class Initialized
INFO - 2022-06-28 12:04:31 --> Language Class Initialized
INFO - 2022-06-28 12:04:31 --> Loader Class Initialized
INFO - 2022-06-28 12:04:31 --> Helper loaded: url_helper
INFO - 2022-06-28 12:04:31 --> Helper loaded: file_helper
INFO - 2022-06-28 12:04:31 --> Database Driver Class Initialized
INFO - 2022-06-28 12:04:31 --> Email Class Initialized
DEBUG - 2022-06-28 12:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:04:31 --> Controller Class Initialized
INFO - 2022-06-28 12:04:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:04:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 12:04:31 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO), expecting ';' or ',' C:\wamp64\www\qr\application\views\doc_screen\doctor.php 352
INFO - 2022-06-28 12:16:14 --> Config Class Initialized
INFO - 2022-06-28 12:16:14 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:16:14 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:16:14 --> Utf8 Class Initialized
INFO - 2022-06-28 12:16:14 --> URI Class Initialized
INFO - 2022-06-28 12:16:14 --> Router Class Initialized
INFO - 2022-06-28 12:16:14 --> Output Class Initialized
INFO - 2022-06-28 12:16:14 --> Security Class Initialized
DEBUG - 2022-06-28 12:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:16:14 --> Input Class Initialized
INFO - 2022-06-28 12:16:14 --> Language Class Initialized
INFO - 2022-06-28 12:16:14 --> Loader Class Initialized
INFO - 2022-06-28 12:16:14 --> Helper loaded: url_helper
INFO - 2022-06-28 12:16:14 --> Helper loaded: file_helper
INFO - 2022-06-28 12:16:14 --> Database Driver Class Initialized
INFO - 2022-06-28 12:16:14 --> Email Class Initialized
DEBUG - 2022-06-28 12:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:16:14 --> Controller Class Initialized
INFO - 2022-06-28 12:16:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:16:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 12:16:14 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 350
INFO - 2022-06-28 12:16:14 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 12:16:14 --> Final output sent to browser
DEBUG - 2022-06-28 12:16:14 --> Total execution time: 0.0499
INFO - 2022-06-28 12:17:53 --> Config Class Initialized
INFO - 2022-06-28 12:17:53 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:17:53 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:17:53 --> Utf8 Class Initialized
INFO - 2022-06-28 12:17:53 --> URI Class Initialized
INFO - 2022-06-28 12:17:53 --> Router Class Initialized
INFO - 2022-06-28 12:17:53 --> Output Class Initialized
INFO - 2022-06-28 12:17:53 --> Security Class Initialized
DEBUG - 2022-06-28 12:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:17:53 --> Input Class Initialized
INFO - 2022-06-28 12:17:53 --> Language Class Initialized
INFO - 2022-06-28 12:17:53 --> Loader Class Initialized
INFO - 2022-06-28 12:17:53 --> Helper loaded: url_helper
INFO - 2022-06-28 12:17:53 --> Helper loaded: file_helper
INFO - 2022-06-28 12:17:53 --> Database Driver Class Initialized
INFO - 2022-06-28 12:17:53 --> Email Class Initialized
DEBUG - 2022-06-28 12:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:17:53 --> Controller Class Initialized
INFO - 2022-06-28 12:17:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:17:53 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 12:17:53 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 12:17:53 --> Final output sent to browser
DEBUG - 2022-06-28 12:17:53 --> Total execution time: 0.0255
INFO - 2022-06-28 12:17:55 --> Config Class Initialized
INFO - 2022-06-28 12:17:55 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:17:55 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:17:55 --> Utf8 Class Initialized
INFO - 2022-06-28 12:17:55 --> URI Class Initialized
INFO - 2022-06-28 12:17:55 --> Router Class Initialized
INFO - 2022-06-28 12:17:55 --> Output Class Initialized
INFO - 2022-06-28 12:17:55 --> Security Class Initialized
DEBUG - 2022-06-28 12:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:17:55 --> Input Class Initialized
INFO - 2022-06-28 12:17:55 --> Language Class Initialized
INFO - 2022-06-28 12:17:55 --> Loader Class Initialized
INFO - 2022-06-28 12:17:55 --> Helper loaded: url_helper
INFO - 2022-06-28 12:17:55 --> Helper loaded: file_helper
INFO - 2022-06-28 12:17:55 --> Database Driver Class Initialized
INFO - 2022-06-28 12:17:55 --> Email Class Initialized
DEBUG - 2022-06-28 12:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:17:55 --> Controller Class Initialized
INFO - 2022-06-28 12:17:55 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:17:55 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 12:17:55 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 12:17:55 --> Final output sent to browser
DEBUG - 2022-06-28 12:17:55 --> Total execution time: 0.0542
INFO - 2022-06-28 12:17:58 --> Config Class Initialized
INFO - 2022-06-28 12:17:58 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:17:58 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:17:58 --> Utf8 Class Initialized
INFO - 2022-06-28 12:17:58 --> URI Class Initialized
INFO - 2022-06-28 12:17:58 --> Router Class Initialized
INFO - 2022-06-28 12:17:58 --> Output Class Initialized
INFO - 2022-06-28 12:17:58 --> Security Class Initialized
DEBUG - 2022-06-28 12:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:17:58 --> Input Class Initialized
INFO - 2022-06-28 12:17:58 --> Language Class Initialized
INFO - 2022-06-28 12:17:58 --> Loader Class Initialized
INFO - 2022-06-28 12:17:58 --> Helper loaded: url_helper
INFO - 2022-06-28 12:17:58 --> Helper loaded: file_helper
INFO - 2022-06-28 12:17:58 --> Database Driver Class Initialized
INFO - 2022-06-28 12:17:58 --> Email Class Initialized
DEBUG - 2022-06-28 12:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:17:58 --> Controller Class Initialized
INFO - 2022-06-28 12:17:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:17:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 12:17:58 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 12:17:58 --> Final output sent to browser
DEBUG - 2022-06-28 12:17:58 --> Total execution time: 0.0205
INFO - 2022-06-28 12:17:59 --> Config Class Initialized
INFO - 2022-06-28 12:17:59 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:17:59 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:17:59 --> Utf8 Class Initialized
INFO - 2022-06-28 12:17:59 --> URI Class Initialized
INFO - 2022-06-28 12:17:59 --> Router Class Initialized
INFO - 2022-06-28 12:17:59 --> Output Class Initialized
INFO - 2022-06-28 12:17:59 --> Security Class Initialized
DEBUG - 2022-06-28 12:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:17:59 --> Input Class Initialized
INFO - 2022-06-28 12:17:59 --> Language Class Initialized
INFO - 2022-06-28 12:17:59 --> Loader Class Initialized
INFO - 2022-06-28 12:17:59 --> Helper loaded: url_helper
INFO - 2022-06-28 12:17:59 --> Helper loaded: file_helper
INFO - 2022-06-28 12:17:59 --> Database Driver Class Initialized
INFO - 2022-06-28 12:17:59 --> Email Class Initialized
DEBUG - 2022-06-28 12:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:17:59 --> Controller Class Initialized
INFO - 2022-06-28 12:17:59 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:17:59 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 12:17:59 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 12:17:59 --> Final output sent to browser
DEBUG - 2022-06-28 12:17:59 --> Total execution time: 0.0292
INFO - 2022-06-28 12:18:00 --> Config Class Initialized
INFO - 2022-06-28 12:18:00 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:18:00 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:18:00 --> Utf8 Class Initialized
INFO - 2022-06-28 12:18:00 --> URI Class Initialized
INFO - 2022-06-28 12:18:00 --> Router Class Initialized
INFO - 2022-06-28 12:18:00 --> Output Class Initialized
INFO - 2022-06-28 12:18:00 --> Security Class Initialized
DEBUG - 2022-06-28 12:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:18:00 --> Input Class Initialized
INFO - 2022-06-28 12:18:00 --> Language Class Initialized
INFO - 2022-06-28 12:18:00 --> Loader Class Initialized
INFO - 2022-06-28 12:18:00 --> Helper loaded: url_helper
INFO - 2022-06-28 12:18:00 --> Helper loaded: file_helper
INFO - 2022-06-28 12:18:00 --> Database Driver Class Initialized
INFO - 2022-06-28 12:18:00 --> Email Class Initialized
DEBUG - 2022-06-28 12:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:18:00 --> Controller Class Initialized
INFO - 2022-06-28 12:18:00 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:18:00 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 12:18:00 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 12:18:00 --> Final output sent to browser
DEBUG - 2022-06-28 12:18:00 --> Total execution time: 0.0186
INFO - 2022-06-28 12:18:01 --> Config Class Initialized
INFO - 2022-06-28 12:18:01 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:18:01 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:18:01 --> Utf8 Class Initialized
INFO - 2022-06-28 12:18:01 --> URI Class Initialized
INFO - 2022-06-28 12:18:01 --> Router Class Initialized
INFO - 2022-06-28 12:18:01 --> Output Class Initialized
INFO - 2022-06-28 12:18:01 --> Security Class Initialized
DEBUG - 2022-06-28 12:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:18:01 --> Input Class Initialized
INFO - 2022-06-28 12:18:01 --> Language Class Initialized
INFO - 2022-06-28 12:18:01 --> Loader Class Initialized
INFO - 2022-06-28 12:18:01 --> Helper loaded: url_helper
INFO - 2022-06-28 12:18:01 --> Helper loaded: file_helper
INFO - 2022-06-28 12:18:01 --> Database Driver Class Initialized
INFO - 2022-06-28 12:18:01 --> Email Class Initialized
DEBUG - 2022-06-28 12:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:18:01 --> Controller Class Initialized
INFO - 2022-06-28 12:18:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:18:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 12:18:01 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 12:18:01 --> Final output sent to browser
DEBUG - 2022-06-28 12:18:01 --> Total execution time: 0.0291
INFO - 2022-06-28 12:18:01 --> Config Class Initialized
INFO - 2022-06-28 12:18:01 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:18:01 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:18:01 --> Utf8 Class Initialized
INFO - 2022-06-28 12:18:01 --> URI Class Initialized
INFO - 2022-06-28 12:18:01 --> Router Class Initialized
INFO - 2022-06-28 12:18:01 --> Output Class Initialized
INFO - 2022-06-28 12:18:01 --> Security Class Initialized
DEBUG - 2022-06-28 12:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:18:01 --> Input Class Initialized
INFO - 2022-06-28 12:18:01 --> Language Class Initialized
ERROR - 2022-06-28 12:18:01 --> 404 Page Not Found: Tokenctrl/%3C
INFO - 2022-06-28 12:18:03 --> Config Class Initialized
INFO - 2022-06-28 12:18:03 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:18:03 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:18:03 --> Utf8 Class Initialized
INFO - 2022-06-28 12:18:03 --> URI Class Initialized
INFO - 2022-06-28 12:18:03 --> Router Class Initialized
INFO - 2022-06-28 12:18:03 --> Output Class Initialized
INFO - 2022-06-28 12:18:03 --> Security Class Initialized
DEBUG - 2022-06-28 12:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:18:03 --> Input Class Initialized
INFO - 2022-06-28 12:18:03 --> Language Class Initialized
INFO - 2022-06-28 12:18:03 --> Loader Class Initialized
INFO - 2022-06-28 12:18:03 --> Helper loaded: url_helper
INFO - 2022-06-28 12:18:03 --> Helper loaded: file_helper
INFO - 2022-06-28 12:18:03 --> Database Driver Class Initialized
INFO - 2022-06-28 12:18:03 --> Email Class Initialized
DEBUG - 2022-06-28 12:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:18:03 --> Controller Class Initialized
INFO - 2022-06-28 12:18:03 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:18:03 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 12:18:03 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 12:18:03 --> Final output sent to browser
DEBUG - 2022-06-28 12:18:03 --> Total execution time: 0.0199
INFO - 2022-06-28 12:18:03 --> Config Class Initialized
INFO - 2022-06-28 12:18:03 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:18:03 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:18:03 --> Utf8 Class Initialized
INFO - 2022-06-28 12:18:03 --> URI Class Initialized
INFO - 2022-06-28 12:18:03 --> Router Class Initialized
INFO - 2022-06-28 12:18:03 --> Output Class Initialized
INFO - 2022-06-28 12:18:03 --> Security Class Initialized
DEBUG - 2022-06-28 12:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:18:03 --> Input Class Initialized
INFO - 2022-06-28 12:18:03 --> Language Class Initialized
ERROR - 2022-06-28 12:18:03 --> 404 Page Not Found: Tokenctrl/%3C
INFO - 2022-06-28 12:18:22 --> Config Class Initialized
INFO - 2022-06-28 12:18:22 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:18:22 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:18:22 --> Utf8 Class Initialized
INFO - 2022-06-28 12:18:22 --> URI Class Initialized
INFO - 2022-06-28 12:18:22 --> Router Class Initialized
INFO - 2022-06-28 12:18:22 --> Output Class Initialized
INFO - 2022-06-28 12:18:22 --> Security Class Initialized
DEBUG - 2022-06-28 12:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:18:22 --> Input Class Initialized
INFO - 2022-06-28 12:18:22 --> Language Class Initialized
INFO - 2022-06-28 12:18:22 --> Loader Class Initialized
INFO - 2022-06-28 12:18:22 --> Helper loaded: url_helper
INFO - 2022-06-28 12:18:22 --> Helper loaded: file_helper
INFO - 2022-06-28 12:18:22 --> Database Driver Class Initialized
INFO - 2022-06-28 12:18:22 --> Email Class Initialized
DEBUG - 2022-06-28 12:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:18:22 --> Controller Class Initialized
INFO - 2022-06-28 12:18:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:18:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 12:18:22 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 350
INFO - 2022-06-28 12:18:22 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 12:18:22 --> Final output sent to browser
DEBUG - 2022-06-28 12:18:22 --> Total execution time: 0.0229
INFO - 2022-06-28 12:18:34 --> Config Class Initialized
INFO - 2022-06-28 12:18:34 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:18:34 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:18:34 --> Utf8 Class Initialized
INFO - 2022-06-28 12:18:34 --> URI Class Initialized
INFO - 2022-06-28 12:18:34 --> Router Class Initialized
INFO - 2022-06-28 12:18:34 --> Output Class Initialized
INFO - 2022-06-28 12:18:34 --> Security Class Initialized
DEBUG - 2022-06-28 12:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:18:34 --> Input Class Initialized
INFO - 2022-06-28 12:18:34 --> Language Class Initialized
INFO - 2022-06-28 12:18:34 --> Loader Class Initialized
INFO - 2022-06-28 12:18:34 --> Helper loaded: url_helper
INFO - 2022-06-28 12:18:34 --> Helper loaded: file_helper
INFO - 2022-06-28 12:18:34 --> Database Driver Class Initialized
INFO - 2022-06-28 12:18:34 --> Email Class Initialized
DEBUG - 2022-06-28 12:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:18:34 --> Controller Class Initialized
INFO - 2022-06-28 12:18:34 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:18:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 12:18:34 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 350
INFO - 2022-06-28 12:18:34 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 12:18:34 --> Final output sent to browser
DEBUG - 2022-06-28 12:18:34 --> Total execution time: 0.0395
INFO - 2022-06-28 12:18:37 --> Config Class Initialized
INFO - 2022-06-28 12:18:37 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:18:37 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:18:37 --> Utf8 Class Initialized
INFO - 2022-06-28 12:18:37 --> URI Class Initialized
INFO - 2022-06-28 12:18:37 --> Router Class Initialized
INFO - 2022-06-28 12:18:37 --> Output Class Initialized
INFO - 2022-06-28 12:18:37 --> Security Class Initialized
DEBUG - 2022-06-28 12:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:18:37 --> Input Class Initialized
INFO - 2022-06-28 12:18:37 --> Language Class Initialized
INFO - 2022-06-28 12:18:37 --> Loader Class Initialized
INFO - 2022-06-28 12:18:37 --> Helper loaded: url_helper
INFO - 2022-06-28 12:18:37 --> Helper loaded: file_helper
INFO - 2022-06-28 12:18:37 --> Database Driver Class Initialized
INFO - 2022-06-28 12:18:37 --> Email Class Initialized
DEBUG - 2022-06-28 12:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:18:37 --> Controller Class Initialized
INFO - 2022-06-28 12:18:37 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:18:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 12:18:37 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 350
INFO - 2022-06-28 12:18:37 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 12:18:37 --> Final output sent to browser
DEBUG - 2022-06-28 12:18:37 --> Total execution time: 0.0258
INFO - 2022-06-28 12:18:39 --> Config Class Initialized
INFO - 2022-06-28 12:18:39 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:18:39 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:18:39 --> Utf8 Class Initialized
INFO - 2022-06-28 12:18:39 --> URI Class Initialized
INFO - 2022-06-28 12:18:39 --> Router Class Initialized
INFO - 2022-06-28 12:18:39 --> Output Class Initialized
INFO - 2022-06-28 12:18:39 --> Security Class Initialized
DEBUG - 2022-06-28 12:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:18:39 --> Input Class Initialized
INFO - 2022-06-28 12:18:39 --> Language Class Initialized
INFO - 2022-06-28 12:18:39 --> Loader Class Initialized
INFO - 2022-06-28 12:18:39 --> Helper loaded: url_helper
INFO - 2022-06-28 12:18:39 --> Helper loaded: file_helper
INFO - 2022-06-28 12:18:39 --> Database Driver Class Initialized
INFO - 2022-06-28 12:18:39 --> Email Class Initialized
DEBUG - 2022-06-28 12:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:18:39 --> Controller Class Initialized
INFO - 2022-06-28 12:18:39 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:18:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 12:18:39 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 350
INFO - 2022-06-28 12:18:39 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 12:18:39 --> Final output sent to browser
DEBUG - 2022-06-28 12:18:39 --> Total execution time: 0.0463
INFO - 2022-06-28 12:18:39 --> Config Class Initialized
INFO - 2022-06-28 12:18:39 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:18:39 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:18:39 --> Utf8 Class Initialized
INFO - 2022-06-28 12:18:39 --> URI Class Initialized
INFO - 2022-06-28 12:18:39 --> Router Class Initialized
INFO - 2022-06-28 12:18:39 --> Output Class Initialized
INFO - 2022-06-28 12:18:39 --> Security Class Initialized
DEBUG - 2022-06-28 12:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:18:39 --> Input Class Initialized
INFO - 2022-06-28 12:18:39 --> Language Class Initialized
INFO - 2022-06-28 12:18:39 --> Loader Class Initialized
INFO - 2022-06-28 12:18:39 --> Helper loaded: url_helper
INFO - 2022-06-28 12:18:39 --> Helper loaded: file_helper
INFO - 2022-06-28 12:18:39 --> Database Driver Class Initialized
INFO - 2022-06-28 12:18:39 --> Email Class Initialized
DEBUG - 2022-06-28 12:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:18:39 --> Controller Class Initialized
INFO - 2022-06-28 12:18:39 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:18:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 12:18:39 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 350
INFO - 2022-06-28 12:18:39 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 12:18:39 --> Final output sent to browser
DEBUG - 2022-06-28 12:18:39 --> Total execution time: 0.1518
INFO - 2022-06-28 12:18:40 --> Config Class Initialized
INFO - 2022-06-28 12:18:40 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:18:40 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:18:40 --> Utf8 Class Initialized
INFO - 2022-06-28 12:18:40 --> URI Class Initialized
INFO - 2022-06-28 12:18:40 --> Router Class Initialized
INFO - 2022-06-28 12:18:40 --> Output Class Initialized
INFO - 2022-06-28 12:18:40 --> Security Class Initialized
DEBUG - 2022-06-28 12:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:18:40 --> Input Class Initialized
INFO - 2022-06-28 12:18:40 --> Language Class Initialized
INFO - 2022-06-28 12:18:40 --> Loader Class Initialized
INFO - 2022-06-28 12:18:40 --> Helper loaded: url_helper
INFO - 2022-06-28 12:18:40 --> Helper loaded: file_helper
INFO - 2022-06-28 12:18:40 --> Database Driver Class Initialized
INFO - 2022-06-28 12:18:40 --> Email Class Initialized
DEBUG - 2022-06-28 12:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:18:40 --> Controller Class Initialized
INFO - 2022-06-28 12:18:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:18:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 12:18:40 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 350
INFO - 2022-06-28 12:18:40 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 12:18:40 --> Final output sent to browser
DEBUG - 2022-06-28 12:18:40 --> Total execution time: 0.0445
INFO - 2022-06-28 12:22:32 --> Config Class Initialized
INFO - 2022-06-28 12:22:32 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:22:32 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:22:32 --> Utf8 Class Initialized
INFO - 2022-06-28 12:22:32 --> URI Class Initialized
INFO - 2022-06-28 12:22:32 --> Router Class Initialized
INFO - 2022-06-28 12:22:32 --> Output Class Initialized
INFO - 2022-06-28 12:22:32 --> Security Class Initialized
DEBUG - 2022-06-28 12:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:22:32 --> Input Class Initialized
INFO - 2022-06-28 12:22:32 --> Language Class Initialized
INFO - 2022-06-28 12:22:32 --> Loader Class Initialized
INFO - 2022-06-28 12:22:32 --> Helper loaded: url_helper
INFO - 2022-06-28 12:22:32 --> Helper loaded: file_helper
INFO - 2022-06-28 12:22:32 --> Database Driver Class Initialized
INFO - 2022-06-28 12:22:32 --> Email Class Initialized
DEBUG - 2022-06-28 12:22:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:22:32 --> Controller Class Initialized
INFO - 2022-06-28 12:22:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:22:32 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 12:22:32 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 12:22:32 --> Final output sent to browser
DEBUG - 2022-06-28 12:22:32 --> Total execution time: 0.1446
INFO - 2022-06-28 12:22:34 --> Config Class Initialized
INFO - 2022-06-28 12:22:34 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:22:34 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:22:34 --> Utf8 Class Initialized
INFO - 2022-06-28 12:22:34 --> URI Class Initialized
INFO - 2022-06-28 12:22:34 --> Router Class Initialized
INFO - 2022-06-28 12:22:34 --> Output Class Initialized
INFO - 2022-06-28 12:22:34 --> Security Class Initialized
DEBUG - 2022-06-28 12:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:22:34 --> Input Class Initialized
INFO - 2022-06-28 12:22:34 --> Language Class Initialized
INFO - 2022-06-28 12:22:34 --> Loader Class Initialized
INFO - 2022-06-28 12:22:34 --> Helper loaded: url_helper
INFO - 2022-06-28 12:22:34 --> Helper loaded: file_helper
INFO - 2022-06-28 12:22:34 --> Database Driver Class Initialized
INFO - 2022-06-28 12:22:34 --> Email Class Initialized
DEBUG - 2022-06-28 12:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:22:34 --> Controller Class Initialized
INFO - 2022-06-28 12:22:34 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:22:34 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 12:22:34 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 12:22:34 --> Final output sent to browser
DEBUG - 2022-06-28 12:22:34 --> Total execution time: 0.0934
INFO - 2022-06-28 12:22:36 --> Config Class Initialized
INFO - 2022-06-28 12:22:36 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:22:36 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:22:36 --> Utf8 Class Initialized
INFO - 2022-06-28 12:22:36 --> URI Class Initialized
INFO - 2022-06-28 12:22:36 --> Router Class Initialized
INFO - 2022-06-28 12:22:36 --> Output Class Initialized
INFO - 2022-06-28 12:22:36 --> Security Class Initialized
DEBUG - 2022-06-28 12:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:22:36 --> Input Class Initialized
INFO - 2022-06-28 12:22:36 --> Language Class Initialized
INFO - 2022-06-28 12:22:36 --> Loader Class Initialized
INFO - 2022-06-28 12:22:36 --> Helper loaded: url_helper
INFO - 2022-06-28 12:22:36 --> Helper loaded: file_helper
INFO - 2022-06-28 12:22:36 --> Database Driver Class Initialized
INFO - 2022-06-28 12:22:36 --> Email Class Initialized
DEBUG - 2022-06-28 12:22:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:22:36 --> Controller Class Initialized
INFO - 2022-06-28 12:22:36 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:22:36 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 12:22:36 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 12:22:36 --> Final output sent to browser
DEBUG - 2022-06-28 12:22:36 --> Total execution time: 0.1418
INFO - 2022-06-28 12:22:38 --> Config Class Initialized
INFO - 2022-06-28 12:22:38 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:22:38 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:22:38 --> Utf8 Class Initialized
INFO - 2022-06-28 12:22:38 --> URI Class Initialized
INFO - 2022-06-28 12:22:38 --> Router Class Initialized
INFO - 2022-06-28 12:22:38 --> Output Class Initialized
INFO - 2022-06-28 12:22:38 --> Security Class Initialized
DEBUG - 2022-06-28 12:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:22:38 --> Input Class Initialized
INFO - 2022-06-28 12:22:38 --> Language Class Initialized
INFO - 2022-06-28 12:22:38 --> Loader Class Initialized
INFO - 2022-06-28 12:22:38 --> Helper loaded: url_helper
INFO - 2022-06-28 12:22:38 --> Helper loaded: file_helper
INFO - 2022-06-28 12:22:38 --> Database Driver Class Initialized
INFO - 2022-06-28 12:22:38 --> Email Class Initialized
DEBUG - 2022-06-28 12:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:22:38 --> Controller Class Initialized
INFO - 2022-06-28 12:22:38 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:22:38 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 12:22:38 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 12:22:38 --> Final output sent to browser
DEBUG - 2022-06-28 12:22:38 --> Total execution time: 0.1169
INFO - 2022-06-28 12:22:40 --> Config Class Initialized
INFO - 2022-06-28 12:22:40 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:22:40 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:22:40 --> Utf8 Class Initialized
INFO - 2022-06-28 12:22:40 --> URI Class Initialized
INFO - 2022-06-28 12:22:40 --> Router Class Initialized
INFO - 2022-06-28 12:22:40 --> Output Class Initialized
INFO - 2022-06-28 12:22:40 --> Security Class Initialized
DEBUG - 2022-06-28 12:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:22:40 --> Input Class Initialized
INFO - 2022-06-28 12:22:40 --> Language Class Initialized
INFO - 2022-06-28 12:22:40 --> Loader Class Initialized
INFO - 2022-06-28 12:22:40 --> Helper loaded: url_helper
INFO - 2022-06-28 12:22:40 --> Helper loaded: file_helper
INFO - 2022-06-28 12:22:40 --> Database Driver Class Initialized
INFO - 2022-06-28 12:22:40 --> Email Class Initialized
DEBUG - 2022-06-28 12:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:22:40 --> Controller Class Initialized
INFO - 2022-06-28 12:22:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:22:40 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 12:22:40 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 12:22:40 --> Final output sent to browser
DEBUG - 2022-06-28 12:22:40 --> Total execution time: 0.0174
INFO - 2022-06-28 12:22:41 --> Config Class Initialized
INFO - 2022-06-28 12:22:41 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:22:41 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:22:41 --> Utf8 Class Initialized
INFO - 2022-06-28 12:22:41 --> URI Class Initialized
INFO - 2022-06-28 12:22:41 --> Router Class Initialized
INFO - 2022-06-28 12:22:41 --> Output Class Initialized
INFO - 2022-06-28 12:22:41 --> Security Class Initialized
DEBUG - 2022-06-28 12:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:22:41 --> Input Class Initialized
INFO - 2022-06-28 12:22:41 --> Language Class Initialized
INFO - 2022-06-28 12:22:41 --> Loader Class Initialized
INFO - 2022-06-28 12:22:41 --> Helper loaded: url_helper
INFO - 2022-06-28 12:22:41 --> Helper loaded: file_helper
INFO - 2022-06-28 12:22:41 --> Database Driver Class Initialized
INFO - 2022-06-28 12:22:41 --> Email Class Initialized
DEBUG - 2022-06-28 12:22:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:22:41 --> Controller Class Initialized
INFO - 2022-06-28 12:22:41 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:22:41 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 12:22:41 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 12:22:41 --> Final output sent to browser
DEBUG - 2022-06-28 12:22:41 --> Total execution time: 0.0192
INFO - 2022-06-28 12:22:41 --> Config Class Initialized
INFO - 2022-06-28 12:22:41 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:22:41 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:22:41 --> Utf8 Class Initialized
INFO - 2022-06-28 12:22:41 --> URI Class Initialized
INFO - 2022-06-28 12:22:41 --> Router Class Initialized
INFO - 2022-06-28 12:22:41 --> Output Class Initialized
INFO - 2022-06-28 12:22:41 --> Security Class Initialized
DEBUG - 2022-06-28 12:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:22:41 --> Input Class Initialized
INFO - 2022-06-28 12:22:41 --> Language Class Initialized
ERROR - 2022-06-28 12:22:41 --> 404 Page Not Found: Tokenctrl/%3C
INFO - 2022-06-28 12:24:24 --> Config Class Initialized
INFO - 2022-06-28 12:24:24 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:24:24 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:24:24 --> Utf8 Class Initialized
INFO - 2022-06-28 12:24:24 --> URI Class Initialized
INFO - 2022-06-28 12:24:24 --> Router Class Initialized
INFO - 2022-06-28 12:24:24 --> Output Class Initialized
INFO - 2022-06-28 12:24:24 --> Security Class Initialized
DEBUG - 2022-06-28 12:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:24:24 --> Input Class Initialized
INFO - 2022-06-28 12:24:24 --> Language Class Initialized
INFO - 2022-06-28 12:24:24 --> Loader Class Initialized
INFO - 2022-06-28 12:24:24 --> Helper loaded: url_helper
INFO - 2022-06-28 12:24:24 --> Helper loaded: file_helper
INFO - 2022-06-28 12:24:24 --> Database Driver Class Initialized
INFO - 2022-06-28 12:24:24 --> Email Class Initialized
DEBUG - 2022-06-28 12:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:24:24 --> Controller Class Initialized
INFO - 2022-06-28 12:24:24 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:24:24 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 12:24:24 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 12:24:24 --> Final output sent to browser
DEBUG - 2022-06-28 12:24:24 --> Total execution time: 0.1414
INFO - 2022-06-28 12:25:14 --> Config Class Initialized
INFO - 2022-06-28 12:25:14 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:25:14 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:25:14 --> Utf8 Class Initialized
INFO - 2022-06-28 12:25:14 --> URI Class Initialized
INFO - 2022-06-28 12:25:14 --> Router Class Initialized
INFO - 2022-06-28 12:25:14 --> Output Class Initialized
INFO - 2022-06-28 12:25:14 --> Security Class Initialized
DEBUG - 2022-06-28 12:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:25:14 --> Input Class Initialized
INFO - 2022-06-28 12:25:14 --> Language Class Initialized
INFO - 2022-06-28 12:25:14 --> Loader Class Initialized
INFO - 2022-06-28 12:25:14 --> Helper loaded: url_helper
INFO - 2022-06-28 12:25:14 --> Helper loaded: file_helper
INFO - 2022-06-28 12:25:14 --> Database Driver Class Initialized
INFO - 2022-06-28 12:25:14 --> Email Class Initialized
DEBUG - 2022-06-28 12:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:25:14 --> Controller Class Initialized
INFO - 2022-06-28 12:25:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:25:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 12:25:14 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 350
ERROR - 2022-06-28 12:25:14 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
INFO - 2022-06-28 12:25:14 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 12:25:14 --> Final output sent to browser
DEBUG - 2022-06-28 12:25:14 --> Total execution time: 0.0285
INFO - 2022-06-28 12:26:11 --> Config Class Initialized
INFO - 2022-06-28 12:26:11 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:26:11 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:26:11 --> Utf8 Class Initialized
INFO - 2022-06-28 12:26:11 --> URI Class Initialized
INFO - 2022-06-28 12:26:11 --> Router Class Initialized
INFO - 2022-06-28 12:26:11 --> Output Class Initialized
INFO - 2022-06-28 12:26:11 --> Security Class Initialized
DEBUG - 2022-06-28 12:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:26:11 --> Input Class Initialized
INFO - 2022-06-28 12:26:11 --> Language Class Initialized
INFO - 2022-06-28 12:26:11 --> Loader Class Initialized
INFO - 2022-06-28 12:26:11 --> Helper loaded: url_helper
INFO - 2022-06-28 12:26:11 --> Helper loaded: file_helper
INFO - 2022-06-28 12:26:11 --> Database Driver Class Initialized
INFO - 2022-06-28 12:26:11 --> Email Class Initialized
DEBUG - 2022-06-28 12:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:26:11 --> Controller Class Initialized
INFO - 2022-06-28 12:26:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:26:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 12:26:11 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 12:26:11 --> Final output sent to browser
DEBUG - 2022-06-28 12:26:11 --> Total execution time: 0.0442
INFO - 2022-06-28 12:26:13 --> Config Class Initialized
INFO - 2022-06-28 12:26:13 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:26:13 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:26:13 --> Utf8 Class Initialized
INFO - 2022-06-28 12:26:13 --> URI Class Initialized
INFO - 2022-06-28 12:26:13 --> Router Class Initialized
INFO - 2022-06-28 12:26:13 --> Output Class Initialized
INFO - 2022-06-28 12:26:13 --> Security Class Initialized
DEBUG - 2022-06-28 12:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:26:13 --> Input Class Initialized
INFO - 2022-06-28 12:26:13 --> Language Class Initialized
INFO - 2022-06-28 12:26:13 --> Loader Class Initialized
INFO - 2022-06-28 12:26:13 --> Helper loaded: url_helper
INFO - 2022-06-28 12:26:13 --> Helper loaded: file_helper
INFO - 2022-06-28 12:26:13 --> Database Driver Class Initialized
INFO - 2022-06-28 12:26:13 --> Email Class Initialized
DEBUG - 2022-06-28 12:26:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:26:13 --> Controller Class Initialized
INFO - 2022-06-28 12:26:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:26:13 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 12:26:13 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 12:26:13 --> Final output sent to browser
DEBUG - 2022-06-28 12:26:13 --> Total execution time: 0.1430
INFO - 2022-06-28 12:26:15 --> Config Class Initialized
INFO - 2022-06-28 12:26:15 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:26:15 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:26:15 --> Utf8 Class Initialized
INFO - 2022-06-28 12:26:15 --> URI Class Initialized
INFO - 2022-06-28 12:26:15 --> Router Class Initialized
INFO - 2022-06-28 12:26:15 --> Output Class Initialized
INFO - 2022-06-28 12:26:15 --> Security Class Initialized
DEBUG - 2022-06-28 12:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:26:15 --> Input Class Initialized
INFO - 2022-06-28 12:26:15 --> Language Class Initialized
INFO - 2022-06-28 12:26:15 --> Loader Class Initialized
INFO - 2022-06-28 12:26:15 --> Helper loaded: url_helper
INFO - 2022-06-28 12:26:15 --> Helper loaded: file_helper
INFO - 2022-06-28 12:26:15 --> Database Driver Class Initialized
INFO - 2022-06-28 12:26:15 --> Email Class Initialized
DEBUG - 2022-06-28 12:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:26:15 --> Controller Class Initialized
INFO - 2022-06-28 12:26:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:26:15 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 12:26:15 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 12:26:15 --> Final output sent to browser
DEBUG - 2022-06-28 12:26:15 --> Total execution time: 0.0399
INFO - 2022-06-28 12:26:16 --> Config Class Initialized
INFO - 2022-06-28 12:26:16 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:26:16 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:26:16 --> Utf8 Class Initialized
INFO - 2022-06-28 12:26:16 --> URI Class Initialized
INFO - 2022-06-28 12:26:16 --> Router Class Initialized
INFO - 2022-06-28 12:26:16 --> Output Class Initialized
INFO - 2022-06-28 12:26:16 --> Security Class Initialized
DEBUG - 2022-06-28 12:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:26:16 --> Input Class Initialized
INFO - 2022-06-28 12:26:16 --> Language Class Initialized
INFO - 2022-06-28 12:26:16 --> Loader Class Initialized
INFO - 2022-06-28 12:26:16 --> Helper loaded: url_helper
INFO - 2022-06-28 12:26:16 --> Helper loaded: file_helper
INFO - 2022-06-28 12:26:16 --> Database Driver Class Initialized
INFO - 2022-06-28 12:26:17 --> Email Class Initialized
DEBUG - 2022-06-28 12:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:26:17 --> Controller Class Initialized
INFO - 2022-06-28 12:26:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:26:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 12:26:17 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 12:26:17 --> Final output sent to browser
DEBUG - 2022-06-28 12:26:17 --> Total execution time: 0.0296
INFO - 2022-06-28 12:26:18 --> Config Class Initialized
INFO - 2022-06-28 12:26:18 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:26:18 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:26:18 --> Utf8 Class Initialized
INFO - 2022-06-28 12:26:18 --> URI Class Initialized
INFO - 2022-06-28 12:26:18 --> Router Class Initialized
INFO - 2022-06-28 12:26:18 --> Output Class Initialized
INFO - 2022-06-28 12:26:18 --> Security Class Initialized
DEBUG - 2022-06-28 12:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:26:18 --> Input Class Initialized
INFO - 2022-06-28 12:26:18 --> Language Class Initialized
INFO - 2022-06-28 12:26:18 --> Loader Class Initialized
INFO - 2022-06-28 12:26:18 --> Helper loaded: url_helper
INFO - 2022-06-28 12:26:18 --> Helper loaded: file_helper
INFO - 2022-06-28 12:26:18 --> Database Driver Class Initialized
INFO - 2022-06-28 12:26:18 --> Email Class Initialized
DEBUG - 2022-06-28 12:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:26:18 --> Controller Class Initialized
INFO - 2022-06-28 12:26:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:26:18 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 12:26:18 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 12:26:18 --> Final output sent to browser
DEBUG - 2022-06-28 12:26:18 --> Total execution time: 0.0194
INFO - 2022-06-28 12:26:19 --> Config Class Initialized
INFO - 2022-06-28 12:26:19 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:26:19 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:26:19 --> Utf8 Class Initialized
INFO - 2022-06-28 12:26:19 --> URI Class Initialized
INFO - 2022-06-28 12:26:19 --> Router Class Initialized
INFO - 2022-06-28 12:26:19 --> Output Class Initialized
INFO - 2022-06-28 12:26:19 --> Security Class Initialized
DEBUG - 2022-06-28 12:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:26:19 --> Input Class Initialized
INFO - 2022-06-28 12:26:19 --> Language Class Initialized
INFO - 2022-06-28 12:26:19 --> Loader Class Initialized
INFO - 2022-06-28 12:26:19 --> Helper loaded: url_helper
INFO - 2022-06-28 12:26:19 --> Helper loaded: file_helper
INFO - 2022-06-28 12:26:19 --> Database Driver Class Initialized
INFO - 2022-06-28 12:26:19 --> Email Class Initialized
DEBUG - 2022-06-28 12:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:26:19 --> Controller Class Initialized
INFO - 2022-06-28 12:26:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:26:19 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 12:26:19 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 12:26:19 --> Final output sent to browser
DEBUG - 2022-06-28 12:26:19 --> Total execution time: 0.0204
INFO - 2022-06-28 12:26:19 --> Config Class Initialized
INFO - 2022-06-28 12:26:19 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:26:19 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:26:19 --> Utf8 Class Initialized
INFO - 2022-06-28 12:26:19 --> URI Class Initialized
INFO - 2022-06-28 12:26:19 --> Router Class Initialized
INFO - 2022-06-28 12:26:19 --> Output Class Initialized
INFO - 2022-06-28 12:26:19 --> Security Class Initialized
DEBUG - 2022-06-28 12:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:26:19 --> Input Class Initialized
INFO - 2022-06-28 12:26:19 --> Language Class Initialized
INFO - 2022-06-28 12:26:19 --> Loader Class Initialized
INFO - 2022-06-28 12:26:19 --> Helper loaded: url_helper
INFO - 2022-06-28 12:26:19 --> Helper loaded: file_helper
INFO - 2022-06-28 12:26:19 --> Database Driver Class Initialized
INFO - 2022-06-28 12:26:19 --> Email Class Initialized
DEBUG - 2022-06-28 12:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:26:19 --> Controller Class Initialized
INFO - 2022-06-28 12:26:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:26:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 12:26:19 --> Severity: Notice --> Undefined variable: current_token C:\wamp64\www\qr\application\views\reception screen\qr.php 178
INFO - 2022-06-28 12:26:19 --> File loaded: C:\wamp64\www\qr\application\views\reception screen/qr.php
INFO - 2022-06-28 12:26:19 --> Final output sent to browser
DEBUG - 2022-06-28 12:26:19 --> Total execution time: 0.0397
INFO - 2022-06-28 12:27:40 --> Config Class Initialized
INFO - 2022-06-28 12:27:40 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:27:40 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:27:40 --> Utf8 Class Initialized
INFO - 2022-06-28 12:27:40 --> URI Class Initialized
INFO - 2022-06-28 12:27:40 --> Router Class Initialized
INFO - 2022-06-28 12:27:40 --> Output Class Initialized
INFO - 2022-06-28 12:27:40 --> Security Class Initialized
DEBUG - 2022-06-28 12:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:27:40 --> Input Class Initialized
INFO - 2022-06-28 12:27:40 --> Language Class Initialized
INFO - 2022-06-28 12:27:40 --> Loader Class Initialized
INFO - 2022-06-28 12:27:40 --> Helper loaded: url_helper
INFO - 2022-06-28 12:27:40 --> Helper loaded: file_helper
INFO - 2022-06-28 12:27:40 --> Database Driver Class Initialized
INFO - 2022-06-28 12:27:40 --> Email Class Initialized
DEBUG - 2022-06-28 12:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:27:40 --> Controller Class Initialized
INFO - 2022-06-28 12:27:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:27:40 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 12:27:40 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 12:27:40 --> Final output sent to browser
DEBUG - 2022-06-28 12:27:40 --> Total execution time: 0.0395
INFO - 2022-06-28 12:27:40 --> Config Class Initialized
INFO - 2022-06-28 12:27:40 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:27:40 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:27:40 --> Utf8 Class Initialized
INFO - 2022-06-28 12:27:40 --> URI Class Initialized
INFO - 2022-06-28 12:27:40 --> Router Class Initialized
INFO - 2022-06-28 12:27:40 --> Output Class Initialized
INFO - 2022-06-28 12:27:40 --> Security Class Initialized
DEBUG - 2022-06-28 12:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:27:40 --> Input Class Initialized
INFO - 2022-06-28 12:27:40 --> Language Class Initialized
ERROR - 2022-06-28 12:27:40 --> 404 Page Not Found: Tokenctrl/%3C
INFO - 2022-06-28 12:27:47 --> Config Class Initialized
INFO - 2022-06-28 12:27:47 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:27:47 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:27:47 --> Utf8 Class Initialized
INFO - 2022-06-28 12:27:47 --> URI Class Initialized
INFO - 2022-06-28 12:27:47 --> Router Class Initialized
INFO - 2022-06-28 12:27:47 --> Output Class Initialized
INFO - 2022-06-28 12:27:47 --> Security Class Initialized
DEBUG - 2022-06-28 12:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:27:47 --> Input Class Initialized
INFO - 2022-06-28 12:27:47 --> Language Class Initialized
INFO - 2022-06-28 12:27:47 --> Loader Class Initialized
INFO - 2022-06-28 12:27:47 --> Helper loaded: url_helper
INFO - 2022-06-28 12:27:47 --> Helper loaded: file_helper
INFO - 2022-06-28 12:27:47 --> Database Driver Class Initialized
INFO - 2022-06-28 12:27:47 --> Email Class Initialized
DEBUG - 2022-06-28 12:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:27:47 --> Controller Class Initialized
INFO - 2022-06-28 12:27:47 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:27:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 12:27:47 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 350
ERROR - 2022-06-28 12:27:47 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
INFO - 2022-06-28 12:27:47 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 12:27:47 --> Final output sent to browser
DEBUG - 2022-06-28 12:27:47 --> Total execution time: 0.0275
INFO - 2022-06-28 12:29:04 --> Config Class Initialized
INFO - 2022-06-28 12:29:04 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:29:04 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:29:04 --> Utf8 Class Initialized
INFO - 2022-06-28 12:29:04 --> URI Class Initialized
INFO - 2022-06-28 12:29:04 --> Router Class Initialized
INFO - 2022-06-28 12:29:04 --> Output Class Initialized
INFO - 2022-06-28 12:29:04 --> Security Class Initialized
DEBUG - 2022-06-28 12:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:29:04 --> Input Class Initialized
INFO - 2022-06-28 12:29:04 --> Language Class Initialized
INFO - 2022-06-28 12:29:04 --> Loader Class Initialized
INFO - 2022-06-28 12:29:04 --> Helper loaded: url_helper
INFO - 2022-06-28 12:29:04 --> Helper loaded: file_helper
INFO - 2022-06-28 12:29:04 --> Database Driver Class Initialized
INFO - 2022-06-28 12:29:04 --> Email Class Initialized
DEBUG - 2022-06-28 12:29:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:29:04 --> Controller Class Initialized
INFO - 2022-06-28 12:29:04 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:29:04 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 12:29:04 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 12:29:04 --> Final output sent to browser
DEBUG - 2022-06-28 12:29:04 --> Total execution time: 0.0401
INFO - 2022-06-28 12:29:06 --> Config Class Initialized
INFO - 2022-06-28 12:29:06 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:29:06 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:29:06 --> Utf8 Class Initialized
INFO - 2022-06-28 12:29:06 --> URI Class Initialized
INFO - 2022-06-28 12:29:06 --> Router Class Initialized
INFO - 2022-06-28 12:29:06 --> Output Class Initialized
INFO - 2022-06-28 12:29:06 --> Security Class Initialized
DEBUG - 2022-06-28 12:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:29:06 --> Input Class Initialized
INFO - 2022-06-28 12:29:06 --> Language Class Initialized
INFO - 2022-06-28 12:29:06 --> Loader Class Initialized
INFO - 2022-06-28 12:29:06 --> Helper loaded: url_helper
INFO - 2022-06-28 12:29:06 --> Helper loaded: file_helper
INFO - 2022-06-28 12:29:06 --> Database Driver Class Initialized
INFO - 2022-06-28 12:29:06 --> Email Class Initialized
DEBUG - 2022-06-28 12:29:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:29:06 --> Controller Class Initialized
INFO - 2022-06-28 12:29:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:29:06 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 12:29:06 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 12:29:06 --> Final output sent to browser
DEBUG - 2022-06-28 12:29:06 --> Total execution time: 0.0424
INFO - 2022-06-28 12:29:09 --> Config Class Initialized
INFO - 2022-06-28 12:29:09 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:29:09 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:29:09 --> Utf8 Class Initialized
INFO - 2022-06-28 12:29:09 --> URI Class Initialized
INFO - 2022-06-28 12:29:09 --> Router Class Initialized
INFO - 2022-06-28 12:29:09 --> Output Class Initialized
INFO - 2022-06-28 12:29:09 --> Security Class Initialized
DEBUG - 2022-06-28 12:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:29:09 --> Input Class Initialized
INFO - 2022-06-28 12:29:09 --> Language Class Initialized
INFO - 2022-06-28 12:29:09 --> Loader Class Initialized
INFO - 2022-06-28 12:29:09 --> Helper loaded: url_helper
INFO - 2022-06-28 12:29:09 --> Helper loaded: file_helper
INFO - 2022-06-28 12:29:09 --> Database Driver Class Initialized
INFO - 2022-06-28 12:29:09 --> Email Class Initialized
DEBUG - 2022-06-28 12:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:29:09 --> Controller Class Initialized
INFO - 2022-06-28 12:29:09 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:29:09 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 12:29:09 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 12:29:09 --> Final output sent to browser
DEBUG - 2022-06-28 12:29:09 --> Total execution time: 0.0185
INFO - 2022-06-28 12:29:10 --> Config Class Initialized
INFO - 2022-06-28 12:29:10 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:29:10 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:29:10 --> Utf8 Class Initialized
INFO - 2022-06-28 12:29:10 --> URI Class Initialized
INFO - 2022-06-28 12:29:10 --> Router Class Initialized
INFO - 2022-06-28 12:29:10 --> Output Class Initialized
INFO - 2022-06-28 12:29:10 --> Security Class Initialized
DEBUG - 2022-06-28 12:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:29:10 --> Input Class Initialized
INFO - 2022-06-28 12:29:10 --> Language Class Initialized
INFO - 2022-06-28 12:29:10 --> Loader Class Initialized
INFO - 2022-06-28 12:29:10 --> Helper loaded: url_helper
INFO - 2022-06-28 12:29:10 --> Helper loaded: file_helper
INFO - 2022-06-28 12:29:10 --> Database Driver Class Initialized
INFO - 2022-06-28 12:29:10 --> Email Class Initialized
DEBUG - 2022-06-28 12:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:29:10 --> Controller Class Initialized
INFO - 2022-06-28 12:29:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:29:10 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 12:29:10 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 12:29:10 --> Final output sent to browser
DEBUG - 2022-06-28 12:29:10 --> Total execution time: 0.0194
INFO - 2022-06-28 12:29:11 --> Config Class Initialized
INFO - 2022-06-28 12:29:11 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:29:11 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:29:11 --> Utf8 Class Initialized
INFO - 2022-06-28 12:29:11 --> URI Class Initialized
INFO - 2022-06-28 12:29:11 --> Router Class Initialized
INFO - 2022-06-28 12:29:11 --> Output Class Initialized
INFO - 2022-06-28 12:29:11 --> Security Class Initialized
DEBUG - 2022-06-28 12:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:29:11 --> Input Class Initialized
INFO - 2022-06-28 12:29:11 --> Language Class Initialized
INFO - 2022-06-28 12:29:11 --> Loader Class Initialized
INFO - 2022-06-28 12:29:11 --> Helper loaded: url_helper
INFO - 2022-06-28 12:29:11 --> Helper loaded: file_helper
INFO - 2022-06-28 12:29:11 --> Database Driver Class Initialized
INFO - 2022-06-28 12:29:11 --> Email Class Initialized
DEBUG - 2022-06-28 12:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:29:11 --> Controller Class Initialized
INFO - 2022-06-28 12:29:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:29:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 12:29:11 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 12:29:11 --> Final output sent to browser
DEBUG - 2022-06-28 12:29:11 --> Total execution time: 0.0180
INFO - 2022-06-28 12:29:12 --> Config Class Initialized
INFO - 2022-06-28 12:29:12 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:29:12 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:29:12 --> Utf8 Class Initialized
INFO - 2022-06-28 12:29:12 --> URI Class Initialized
INFO - 2022-06-28 12:29:12 --> Router Class Initialized
INFO - 2022-06-28 12:29:12 --> Output Class Initialized
INFO - 2022-06-28 12:29:12 --> Security Class Initialized
DEBUG - 2022-06-28 12:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:29:12 --> Input Class Initialized
INFO - 2022-06-28 12:29:12 --> Language Class Initialized
INFO - 2022-06-28 12:29:12 --> Loader Class Initialized
INFO - 2022-06-28 12:29:12 --> Helper loaded: url_helper
INFO - 2022-06-28 12:29:12 --> Helper loaded: file_helper
INFO - 2022-06-28 12:29:12 --> Database Driver Class Initialized
INFO - 2022-06-28 12:29:12 --> Email Class Initialized
DEBUG - 2022-06-28 12:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:29:12 --> Controller Class Initialized
INFO - 2022-06-28 12:29:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:29:12 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 12:29:12 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 12:29:12 --> Final output sent to browser
DEBUG - 2022-06-28 12:29:12 --> Total execution time: 0.0451
INFO - 2022-06-28 12:29:12 --> Config Class Initialized
INFO - 2022-06-28 12:29:12 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:29:12 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:29:12 --> Utf8 Class Initialized
INFO - 2022-06-28 12:29:12 --> URI Class Initialized
INFO - 2022-06-28 12:29:12 --> Router Class Initialized
INFO - 2022-06-28 12:29:12 --> Output Class Initialized
INFO - 2022-06-28 12:29:12 --> Security Class Initialized
DEBUG - 2022-06-28 12:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:29:12 --> Input Class Initialized
INFO - 2022-06-28 12:29:12 --> Language Class Initialized
ERROR - 2022-06-28 12:29:12 --> 404 Page Not Found: Tokenctrl/%3C
INFO - 2022-06-28 12:30:21 --> Config Class Initialized
INFO - 2022-06-28 12:30:21 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:30:21 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:30:21 --> Utf8 Class Initialized
INFO - 2022-06-28 12:30:21 --> URI Class Initialized
INFO - 2022-06-28 12:30:21 --> Router Class Initialized
INFO - 2022-06-28 12:30:21 --> Output Class Initialized
INFO - 2022-06-28 12:30:21 --> Security Class Initialized
DEBUG - 2022-06-28 12:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:30:21 --> Input Class Initialized
INFO - 2022-06-28 12:30:21 --> Language Class Initialized
INFO - 2022-06-28 12:30:21 --> Loader Class Initialized
INFO - 2022-06-28 12:30:21 --> Helper loaded: url_helper
INFO - 2022-06-28 12:30:21 --> Helper loaded: file_helper
INFO - 2022-06-28 12:30:21 --> Database Driver Class Initialized
INFO - 2022-06-28 12:30:22 --> Email Class Initialized
DEBUG - 2022-06-28 12:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:30:22 --> Controller Class Initialized
INFO - 2022-06-28 12:30:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:30:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 12:30:22 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 12:30:22 --> Final output sent to browser
DEBUG - 2022-06-28 12:30:22 --> Total execution time: 0.1349
INFO - 2022-06-28 12:30:22 --> Config Class Initialized
INFO - 2022-06-28 12:30:22 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:30:22 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:30:22 --> Utf8 Class Initialized
INFO - 2022-06-28 12:31:10 --> Config Class Initialized
INFO - 2022-06-28 12:31:10 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:31:10 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:31:10 --> Utf8 Class Initialized
INFO - 2022-06-28 12:31:10 --> URI Class Initialized
INFO - 2022-06-28 12:31:10 --> Router Class Initialized
INFO - 2022-06-28 12:31:10 --> Output Class Initialized
INFO - 2022-06-28 12:31:10 --> Security Class Initialized
DEBUG - 2022-06-28 12:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:31:10 --> Input Class Initialized
INFO - 2022-06-28 12:31:10 --> Language Class Initialized
INFO - 2022-06-28 12:31:10 --> Loader Class Initialized
INFO - 2022-06-28 12:31:10 --> Helper loaded: url_helper
INFO - 2022-06-28 12:31:10 --> Helper loaded: file_helper
INFO - 2022-06-28 12:31:10 --> Database Driver Class Initialized
INFO - 2022-06-28 12:31:10 --> Email Class Initialized
DEBUG - 2022-06-28 12:31:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:31:10 --> Controller Class Initialized
INFO - 2022-06-28 12:31:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:31:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 12:31:10 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 350
ERROR - 2022-06-28 12:31:10 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
INFO - 2022-06-28 12:31:10 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 12:31:10 --> Final output sent to browser
DEBUG - 2022-06-28 12:31:10 --> Total execution time: 0.0308
INFO - 2022-06-28 12:32:01 --> Config Class Initialized
INFO - 2022-06-28 12:32:01 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:32:01 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:32:01 --> Utf8 Class Initialized
INFO - 2022-06-28 12:32:01 --> URI Class Initialized
INFO - 2022-06-28 12:32:01 --> Router Class Initialized
INFO - 2022-06-28 12:32:01 --> Output Class Initialized
INFO - 2022-06-28 12:32:01 --> Security Class Initialized
DEBUG - 2022-06-28 12:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:32:01 --> Input Class Initialized
INFO - 2022-06-28 12:32:01 --> Language Class Initialized
INFO - 2022-06-28 12:32:01 --> Loader Class Initialized
INFO - 2022-06-28 12:32:01 --> Helper loaded: url_helper
INFO - 2022-06-28 12:32:01 --> Helper loaded: file_helper
INFO - 2022-06-28 12:32:01 --> Database Driver Class Initialized
INFO - 2022-06-28 12:32:01 --> Email Class Initialized
DEBUG - 2022-06-28 12:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:32:01 --> Controller Class Initialized
INFO - 2022-06-28 12:32:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:32:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 12:32:01 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 12:32:01 --> Final output sent to browser
DEBUG - 2022-06-28 12:32:01 --> Total execution time: 0.0188
INFO - 2022-06-28 12:32:03 --> Config Class Initialized
INFO - 2022-06-28 12:32:03 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:32:03 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:32:03 --> Utf8 Class Initialized
INFO - 2022-06-28 12:32:03 --> URI Class Initialized
INFO - 2022-06-28 12:32:03 --> Router Class Initialized
INFO - 2022-06-28 12:32:03 --> Output Class Initialized
INFO - 2022-06-28 12:32:03 --> Security Class Initialized
DEBUG - 2022-06-28 12:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:32:03 --> Input Class Initialized
INFO - 2022-06-28 12:32:03 --> Language Class Initialized
INFO - 2022-06-28 12:32:03 --> Loader Class Initialized
INFO - 2022-06-28 12:32:03 --> Helper loaded: url_helper
INFO - 2022-06-28 12:32:03 --> Helper loaded: file_helper
INFO - 2022-06-28 12:32:03 --> Database Driver Class Initialized
INFO - 2022-06-28 12:32:03 --> Email Class Initialized
DEBUG - 2022-06-28 12:32:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:32:03 --> Controller Class Initialized
INFO - 2022-06-28 12:32:03 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:32:03 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 12:32:03 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 12:32:03 --> Final output sent to browser
DEBUG - 2022-06-28 12:32:03 --> Total execution time: 0.0398
INFO - 2022-06-28 12:32:06 --> Config Class Initialized
INFO - 2022-06-28 12:32:06 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:32:06 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:32:06 --> Utf8 Class Initialized
INFO - 2022-06-28 12:32:06 --> URI Class Initialized
INFO - 2022-06-28 12:32:06 --> Router Class Initialized
INFO - 2022-06-28 12:32:06 --> Output Class Initialized
INFO - 2022-06-28 12:32:06 --> Security Class Initialized
DEBUG - 2022-06-28 12:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:32:06 --> Input Class Initialized
INFO - 2022-06-28 12:32:06 --> Language Class Initialized
INFO - 2022-06-28 12:32:06 --> Loader Class Initialized
INFO - 2022-06-28 12:32:06 --> Helper loaded: url_helper
INFO - 2022-06-28 12:32:06 --> Helper loaded: file_helper
INFO - 2022-06-28 12:32:06 --> Database Driver Class Initialized
INFO - 2022-06-28 12:32:06 --> Email Class Initialized
DEBUG - 2022-06-28 12:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:32:06 --> Controller Class Initialized
INFO - 2022-06-28 12:32:06 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:32:06 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 12:32:06 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 12:32:06 --> Final output sent to browser
DEBUG - 2022-06-28 12:32:06 --> Total execution time: 0.0173
INFO - 2022-06-28 12:32:25 --> Config Class Initialized
INFO - 2022-06-28 12:32:25 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:32:25 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:32:25 --> Utf8 Class Initialized
INFO - 2022-06-28 12:32:25 --> URI Class Initialized
INFO - 2022-06-28 12:32:25 --> Router Class Initialized
INFO - 2022-06-28 12:32:25 --> Output Class Initialized
INFO - 2022-06-28 12:32:25 --> Security Class Initialized
DEBUG - 2022-06-28 12:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:32:25 --> Input Class Initialized
INFO - 2022-06-28 12:32:25 --> Language Class Initialized
INFO - 2022-06-28 12:32:25 --> Loader Class Initialized
INFO - 2022-06-28 12:32:25 --> Helper loaded: url_helper
INFO - 2022-06-28 12:32:25 --> Helper loaded: file_helper
INFO - 2022-06-28 12:32:25 --> Database Driver Class Initialized
INFO - 2022-06-28 12:32:25 --> Email Class Initialized
DEBUG - 2022-06-28 12:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:32:25 --> Controller Class Initialized
INFO - 2022-06-28 12:32:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:32:25 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 12:32:25 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 12:32:25 --> Final output sent to browser
DEBUG - 2022-06-28 12:32:25 --> Total execution time: 0.0297
INFO - 2022-06-28 12:40:57 --> Config Class Initialized
INFO - 2022-06-28 12:40:57 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:40:57 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:40:57 --> Utf8 Class Initialized
INFO - 2022-06-28 12:40:57 --> URI Class Initialized
INFO - 2022-06-28 12:40:57 --> Router Class Initialized
INFO - 2022-06-28 12:40:57 --> Output Class Initialized
INFO - 2022-06-28 12:40:57 --> Security Class Initialized
DEBUG - 2022-06-28 12:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:40:57 --> Input Class Initialized
INFO - 2022-06-28 12:40:57 --> Language Class Initialized
INFO - 2022-06-28 12:40:57 --> Loader Class Initialized
INFO - 2022-06-28 12:40:57 --> Helper loaded: url_helper
INFO - 2022-06-28 12:40:57 --> Helper loaded: file_helper
INFO - 2022-06-28 12:40:57 --> Database Driver Class Initialized
INFO - 2022-06-28 12:40:57 --> Email Class Initialized
DEBUG - 2022-06-28 12:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:40:57 --> Controller Class Initialized
INFO - 2022-06-28 12:40:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:40:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 12:40:57 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 350
ERROR - 2022-06-28 12:40:57 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
INFO - 2022-06-28 12:40:57 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 12:40:57 --> Final output sent to browser
DEBUG - 2022-06-28 12:40:57 --> Total execution time: 0.0809
INFO - 2022-06-28 12:47:02 --> Config Class Initialized
INFO - 2022-06-28 12:47:02 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:47:02 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:47:02 --> Utf8 Class Initialized
INFO - 2022-06-28 12:47:02 --> URI Class Initialized
INFO - 2022-06-28 12:47:02 --> Router Class Initialized
INFO - 2022-06-28 12:47:02 --> Output Class Initialized
INFO - 2022-06-28 12:47:02 --> Security Class Initialized
DEBUG - 2022-06-28 12:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:47:02 --> Input Class Initialized
INFO - 2022-06-28 12:47:02 --> Language Class Initialized
INFO - 2022-06-28 12:47:02 --> Loader Class Initialized
INFO - 2022-06-28 12:47:02 --> Helper loaded: url_helper
INFO - 2022-06-28 12:47:02 --> Helper loaded: file_helper
INFO - 2022-06-28 12:47:02 --> Database Driver Class Initialized
INFO - 2022-06-28 12:47:02 --> Email Class Initialized
DEBUG - 2022-06-28 12:47:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:47:02 --> Controller Class Initialized
INFO - 2022-06-28 12:47:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:47:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 12:47:02 --> Severity: error --> Exception: syntax error, unexpected 'if' (T_IF) C:\wamp64\www\qr\application\views\doc_screen\doctor.php 352
INFO - 2022-06-28 12:49:04 --> Config Class Initialized
INFO - 2022-06-28 12:49:04 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:49:04 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:49:04 --> Utf8 Class Initialized
INFO - 2022-06-28 12:49:04 --> URI Class Initialized
INFO - 2022-06-28 12:49:04 --> Router Class Initialized
INFO - 2022-06-28 12:49:04 --> Output Class Initialized
INFO - 2022-06-28 12:49:04 --> Security Class Initialized
DEBUG - 2022-06-28 12:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:49:04 --> Input Class Initialized
INFO - 2022-06-28 12:49:04 --> Language Class Initialized
INFO - 2022-06-28 12:49:04 --> Loader Class Initialized
INFO - 2022-06-28 12:49:04 --> Helper loaded: url_helper
INFO - 2022-06-28 12:49:04 --> Helper loaded: file_helper
INFO - 2022-06-28 12:49:04 --> Database Driver Class Initialized
INFO - 2022-06-28 12:49:04 --> Email Class Initialized
DEBUG - 2022-06-28 12:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:49:04 --> Controller Class Initialized
INFO - 2022-06-28 12:49:04 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:49:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 12:49:04 --> Severity: error --> Exception: syntax error, unexpected 'if' (T_IF) C:\wamp64\www\qr\application\views\doc_screen\doctor.php 352
INFO - 2022-06-28 12:49:07 --> Config Class Initialized
INFO - 2022-06-28 12:49:07 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:49:07 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:49:07 --> Utf8 Class Initialized
INFO - 2022-06-28 12:49:07 --> URI Class Initialized
INFO - 2022-06-28 12:49:07 --> Router Class Initialized
INFO - 2022-06-28 12:49:07 --> Output Class Initialized
INFO - 2022-06-28 12:49:07 --> Security Class Initialized
DEBUG - 2022-06-28 12:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:49:07 --> Input Class Initialized
INFO - 2022-06-28 12:49:07 --> Language Class Initialized
INFO - 2022-06-28 12:49:07 --> Loader Class Initialized
INFO - 2022-06-28 12:49:07 --> Helper loaded: url_helper
INFO - 2022-06-28 12:49:07 --> Helper loaded: file_helper
INFO - 2022-06-28 12:49:07 --> Database Driver Class Initialized
INFO - 2022-06-28 12:49:07 --> Email Class Initialized
DEBUG - 2022-06-28 12:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:49:07 --> Controller Class Initialized
INFO - 2022-06-28 12:49:07 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:49:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 12:49:07 --> Severity: error --> Exception: syntax error, unexpected 'if' (T_IF) C:\wamp64\www\qr\application\views\doc_screen\doctor.php 352
INFO - 2022-06-28 12:51:13 --> Config Class Initialized
INFO - 2022-06-28 12:51:13 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:51:13 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:51:13 --> Utf8 Class Initialized
INFO - 2022-06-28 12:51:13 --> URI Class Initialized
INFO - 2022-06-28 12:51:13 --> Router Class Initialized
INFO - 2022-06-28 12:51:13 --> Output Class Initialized
INFO - 2022-06-28 12:51:13 --> Security Class Initialized
DEBUG - 2022-06-28 12:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:51:13 --> Input Class Initialized
INFO - 2022-06-28 12:51:13 --> Language Class Initialized
INFO - 2022-06-28 12:51:13 --> Loader Class Initialized
INFO - 2022-06-28 12:51:13 --> Helper loaded: url_helper
INFO - 2022-06-28 12:51:13 --> Helper loaded: file_helper
INFO - 2022-06-28 12:51:13 --> Database Driver Class Initialized
INFO - 2022-06-28 12:51:13 --> Email Class Initialized
DEBUG - 2022-06-28 12:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:51:13 --> Controller Class Initialized
INFO - 2022-06-28 12:51:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:51:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 12:51:13 --> Severity: error --> Exception: syntax error, unexpected '?>' C:\wamp64\www\qr\application\views\doc_screen\doctor.php 362
INFO - 2022-06-28 12:51:59 --> Config Class Initialized
INFO - 2022-06-28 12:51:59 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:51:59 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:51:59 --> Utf8 Class Initialized
INFO - 2022-06-28 12:51:59 --> URI Class Initialized
INFO - 2022-06-28 12:51:59 --> Router Class Initialized
INFO - 2022-06-28 12:51:59 --> Output Class Initialized
INFO - 2022-06-28 12:51:59 --> Security Class Initialized
DEBUG - 2022-06-28 12:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:51:59 --> Input Class Initialized
INFO - 2022-06-28 12:51:59 --> Language Class Initialized
INFO - 2022-06-28 12:51:59 --> Loader Class Initialized
INFO - 2022-06-28 12:51:59 --> Helper loaded: url_helper
INFO - 2022-06-28 12:51:59 --> Helper loaded: file_helper
INFO - 2022-06-28 12:51:59 --> Database Driver Class Initialized
INFO - 2022-06-28 12:51:59 --> Email Class Initialized
DEBUG - 2022-06-28 12:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:51:59 --> Controller Class Initialized
INFO - 2022-06-28 12:51:59 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:51:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 12:51:59 --> Severity: error --> Exception: syntax error, unexpected '?>' C:\wamp64\www\qr\application\views\doc_screen\doctor.php 352
INFO - 2022-06-28 12:53:08 --> Config Class Initialized
INFO - 2022-06-28 12:53:08 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:53:08 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:53:08 --> Utf8 Class Initialized
INFO - 2022-06-28 12:53:08 --> URI Class Initialized
INFO - 2022-06-28 12:53:08 --> Router Class Initialized
INFO - 2022-06-28 12:53:08 --> Output Class Initialized
INFO - 2022-06-28 12:53:08 --> Security Class Initialized
DEBUG - 2022-06-28 12:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:53:08 --> Input Class Initialized
INFO - 2022-06-28 12:53:08 --> Language Class Initialized
INFO - 2022-06-28 12:53:08 --> Loader Class Initialized
INFO - 2022-06-28 12:53:08 --> Helper loaded: url_helper
INFO - 2022-06-28 12:53:08 --> Helper loaded: file_helper
INFO - 2022-06-28 12:53:08 --> Database Driver Class Initialized
INFO - 2022-06-28 12:53:08 --> Email Class Initialized
DEBUG - 2022-06-28 12:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:53:08 --> Controller Class Initialized
INFO - 2022-06-28 12:53:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:53:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 12:53:09 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) C:\wamp64\www\qr\application\views\doc_screen\doctor.php 351
INFO - 2022-06-28 12:53:09 --> Config Class Initialized
INFO - 2022-06-28 12:53:09 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:53:09 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:53:09 --> Utf8 Class Initialized
INFO - 2022-06-28 12:53:09 --> URI Class Initialized
INFO - 2022-06-28 12:53:09 --> Router Class Initialized
INFO - 2022-06-28 12:53:09 --> Output Class Initialized
INFO - 2022-06-28 12:53:09 --> Security Class Initialized
DEBUG - 2022-06-28 12:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:53:09 --> Input Class Initialized
INFO - 2022-06-28 12:53:09 --> Language Class Initialized
INFO - 2022-06-28 12:53:09 --> Loader Class Initialized
INFO - 2022-06-28 12:53:09 --> Helper loaded: url_helper
INFO - 2022-06-28 12:53:09 --> Helper loaded: file_helper
INFO - 2022-06-28 12:53:09 --> Database Driver Class Initialized
INFO - 2022-06-28 12:53:09 --> Email Class Initialized
DEBUG - 2022-06-28 12:53:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:53:09 --> Controller Class Initialized
INFO - 2022-06-28 12:53:09 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:53:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 12:53:09 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) C:\wamp64\www\qr\application\views\doc_screen\doctor.php 351
INFO - 2022-06-28 12:53:10 --> Config Class Initialized
INFO - 2022-06-28 12:53:10 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:53:10 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:53:10 --> Utf8 Class Initialized
INFO - 2022-06-28 12:53:10 --> URI Class Initialized
INFO - 2022-06-28 12:53:10 --> Router Class Initialized
INFO - 2022-06-28 12:53:10 --> Output Class Initialized
INFO - 2022-06-28 12:53:10 --> Security Class Initialized
DEBUG - 2022-06-28 12:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:53:10 --> Input Class Initialized
INFO - 2022-06-28 12:53:10 --> Language Class Initialized
INFO - 2022-06-28 12:53:10 --> Loader Class Initialized
INFO - 2022-06-28 12:53:10 --> Helper loaded: url_helper
INFO - 2022-06-28 12:53:10 --> Helper loaded: file_helper
INFO - 2022-06-28 12:53:10 --> Database Driver Class Initialized
INFO - 2022-06-28 12:53:10 --> Email Class Initialized
DEBUG - 2022-06-28 12:53:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:53:10 --> Controller Class Initialized
INFO - 2022-06-28 12:53:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:53:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 12:53:11 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) C:\wamp64\www\qr\application\views\doc_screen\doctor.php 351
INFO - 2022-06-28 12:53:11 --> Config Class Initialized
INFO - 2022-06-28 12:53:11 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:53:11 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:53:11 --> Utf8 Class Initialized
INFO - 2022-06-28 12:53:11 --> URI Class Initialized
INFO - 2022-06-28 12:53:11 --> Router Class Initialized
INFO - 2022-06-28 12:53:11 --> Output Class Initialized
INFO - 2022-06-28 12:53:11 --> Security Class Initialized
DEBUG - 2022-06-28 12:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:53:11 --> Input Class Initialized
INFO - 2022-06-28 12:53:11 --> Language Class Initialized
INFO - 2022-06-28 12:53:11 --> Loader Class Initialized
INFO - 2022-06-28 12:53:11 --> Helper loaded: url_helper
INFO - 2022-06-28 12:53:11 --> Helper loaded: file_helper
INFO - 2022-06-28 12:53:11 --> Database Driver Class Initialized
INFO - 2022-06-28 12:53:11 --> Email Class Initialized
DEBUG - 2022-06-28 12:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:53:11 --> Controller Class Initialized
INFO - 2022-06-28 12:53:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:53:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 12:53:11 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) C:\wamp64\www\qr\application\views\doc_screen\doctor.php 351
INFO - 2022-06-28 12:53:11 --> Config Class Initialized
INFO - 2022-06-28 12:53:11 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:53:11 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:53:11 --> Utf8 Class Initialized
INFO - 2022-06-28 12:53:11 --> URI Class Initialized
INFO - 2022-06-28 12:53:11 --> Router Class Initialized
INFO - 2022-06-28 12:53:11 --> Output Class Initialized
INFO - 2022-06-28 12:53:11 --> Security Class Initialized
DEBUG - 2022-06-28 12:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:53:11 --> Config Class Initialized
INFO - 2022-06-28 12:53:11 --> Input Class Initialized
INFO - 2022-06-28 12:53:11 --> Hooks Class Initialized
INFO - 2022-06-28 12:53:11 --> Language Class Initialized
DEBUG - 2022-06-28 12:53:11 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:53:11 --> Utf8 Class Initialized
INFO - 2022-06-28 12:53:11 --> Loader Class Initialized
INFO - 2022-06-28 12:53:11 --> URI Class Initialized
INFO - 2022-06-28 12:53:11 --> Helper loaded: url_helper
INFO - 2022-06-28 12:53:11 --> Helper loaded: file_helper
INFO - 2022-06-28 12:53:11 --> Router Class Initialized
INFO - 2022-06-28 12:53:11 --> Database Driver Class Initialized
INFO - 2022-06-28 12:53:11 --> Output Class Initialized
INFO - 2022-06-28 12:53:11 --> Security Class Initialized
DEBUG - 2022-06-28 12:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:53:11 --> Input Class Initialized
INFO - 2022-06-28 12:53:11 --> Email Class Initialized
INFO - 2022-06-28 12:53:11 --> Language Class Initialized
INFO - 2022-06-28 12:53:11 --> Loader Class Initialized
DEBUG - 2022-06-28 12:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:53:11 --> Helper loaded: url_helper
INFO - 2022-06-28 12:53:11 --> Helper loaded: file_helper
INFO - 2022-06-28 12:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:53:11 --> Controller Class Initialized
INFO - 2022-06-28 12:53:11 --> Database Driver Class Initialized
INFO - 2022-06-28 12:53:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:53:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 12:53:11 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) C:\wamp64\www\qr\application\views\doc_screen\doctor.php 351
INFO - 2022-06-28 12:53:11 --> Email Class Initialized
DEBUG - 2022-06-28 12:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:53:11 --> Controller Class Initialized
INFO - 2022-06-28 12:53:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:53:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 12:53:11 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) C:\wamp64\www\qr\application\views\doc_screen\doctor.php 351
INFO - 2022-06-28 12:58:14 --> Config Class Initialized
INFO - 2022-06-28 12:58:14 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:58:14 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:58:14 --> Utf8 Class Initialized
INFO - 2022-06-28 12:58:14 --> URI Class Initialized
INFO - 2022-06-28 12:58:14 --> Router Class Initialized
INFO - 2022-06-28 12:58:14 --> Output Class Initialized
INFO - 2022-06-28 12:58:14 --> Security Class Initialized
DEBUG - 2022-06-28 12:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:58:14 --> Input Class Initialized
INFO - 2022-06-28 12:58:14 --> Language Class Initialized
INFO - 2022-06-28 12:58:14 --> Loader Class Initialized
INFO - 2022-06-28 12:58:14 --> Helper loaded: url_helper
INFO - 2022-06-28 12:58:14 --> Helper loaded: file_helper
INFO - 2022-06-28 12:58:14 --> Database Driver Class Initialized
INFO - 2022-06-28 12:58:14 --> Email Class Initialized
DEBUG - 2022-06-28 12:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:58:14 --> Controller Class Initialized
INFO - 2022-06-28 12:58:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:58:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 12:58:14 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) C:\wamp64\www\qr\application\views\doc_screen\doctor.php 351
INFO - 2022-06-28 12:58:16 --> Config Class Initialized
INFO - 2022-06-28 12:58:16 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:58:16 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:58:16 --> Utf8 Class Initialized
INFO - 2022-06-28 12:58:16 --> URI Class Initialized
INFO - 2022-06-28 12:58:16 --> Router Class Initialized
INFO - 2022-06-28 12:58:16 --> Output Class Initialized
INFO - 2022-06-28 12:58:16 --> Security Class Initialized
DEBUG - 2022-06-28 12:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:58:16 --> Input Class Initialized
INFO - 2022-06-28 12:58:16 --> Language Class Initialized
INFO - 2022-06-28 12:58:16 --> Loader Class Initialized
INFO - 2022-06-28 12:58:16 --> Helper loaded: url_helper
INFO - 2022-06-28 12:58:16 --> Helper loaded: file_helper
INFO - 2022-06-28 12:58:16 --> Database Driver Class Initialized
INFO - 2022-06-28 12:58:16 --> Email Class Initialized
DEBUG - 2022-06-28 12:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:58:16 --> Controller Class Initialized
INFO - 2022-06-28 12:58:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:58:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 12:58:16 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) C:\wamp64\www\qr\application\views\doc_screen\doctor.php 351
INFO - 2022-06-28 12:58:57 --> Config Class Initialized
INFO - 2022-06-28 12:58:57 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:58:57 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:58:57 --> Utf8 Class Initialized
INFO - 2022-06-28 12:58:57 --> URI Class Initialized
INFO - 2022-06-28 12:58:57 --> Router Class Initialized
INFO - 2022-06-28 12:58:57 --> Output Class Initialized
INFO - 2022-06-28 12:58:57 --> Security Class Initialized
DEBUG - 2022-06-28 12:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:58:57 --> Input Class Initialized
INFO - 2022-06-28 12:58:57 --> Language Class Initialized
INFO - 2022-06-28 12:58:57 --> Loader Class Initialized
INFO - 2022-06-28 12:58:57 --> Helper loaded: url_helper
INFO - 2022-06-28 12:58:57 --> Helper loaded: file_helper
INFO - 2022-06-28 12:58:57 --> Database Driver Class Initialized
INFO - 2022-06-28 12:58:57 --> Email Class Initialized
DEBUG - 2022-06-28 12:58:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:58:57 --> Controller Class Initialized
INFO - 2022-06-28 12:58:57 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:58:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 12:58:57 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) C:\wamp64\www\qr\application\views\doc_screen\doctor.php 351
INFO - 2022-06-28 12:59:01 --> Config Class Initialized
INFO - 2022-06-28 12:59:01 --> Hooks Class Initialized
DEBUG - 2022-06-28 12:59:01 --> UTF-8 Support Enabled
INFO - 2022-06-28 12:59:01 --> Utf8 Class Initialized
INFO - 2022-06-28 12:59:01 --> URI Class Initialized
INFO - 2022-06-28 12:59:01 --> Router Class Initialized
INFO - 2022-06-28 12:59:01 --> Output Class Initialized
INFO - 2022-06-28 12:59:01 --> Security Class Initialized
DEBUG - 2022-06-28 12:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 12:59:01 --> Input Class Initialized
INFO - 2022-06-28 12:59:01 --> Language Class Initialized
INFO - 2022-06-28 12:59:01 --> Loader Class Initialized
INFO - 2022-06-28 12:59:01 --> Helper loaded: url_helper
INFO - 2022-06-28 12:59:01 --> Helper loaded: file_helper
INFO - 2022-06-28 12:59:01 --> Database Driver Class Initialized
INFO - 2022-06-28 12:59:01 --> Email Class Initialized
DEBUG - 2022-06-28 12:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 12:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 12:59:01 --> Controller Class Initialized
INFO - 2022-06-28 12:59:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 12:59:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 12:59:01 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) C:\wamp64\www\qr\application\views\doc_screen\doctor.php 351
INFO - 2022-06-28 13:02:07 --> Config Class Initialized
INFO - 2022-06-28 13:02:07 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:02:07 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:02:07 --> Utf8 Class Initialized
INFO - 2022-06-28 13:02:07 --> URI Class Initialized
INFO - 2022-06-28 13:02:07 --> Router Class Initialized
INFO - 2022-06-28 13:02:07 --> Output Class Initialized
INFO - 2022-06-28 13:02:07 --> Security Class Initialized
DEBUG - 2022-06-28 13:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:02:07 --> Input Class Initialized
INFO - 2022-06-28 13:02:07 --> Language Class Initialized
INFO - 2022-06-28 13:02:07 --> Loader Class Initialized
INFO - 2022-06-28 13:02:07 --> Helper loaded: url_helper
INFO - 2022-06-28 13:02:07 --> Helper loaded: file_helper
INFO - 2022-06-28 13:02:07 --> Database Driver Class Initialized
INFO - 2022-06-28 13:02:07 --> Email Class Initialized
DEBUG - 2022-06-28 13:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:02:07 --> Controller Class Initialized
INFO - 2022-06-28 13:02:07 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:02:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:02:07 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:02:07 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:02:07 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:02:07 --> Final output sent to browser
DEBUG - 2022-06-28 13:02:07 --> Total execution time: 0.0597
INFO - 2022-06-28 13:02:12 --> Config Class Initialized
INFO - 2022-06-28 13:02:12 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:02:12 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:02:12 --> Utf8 Class Initialized
INFO - 2022-06-28 13:02:12 --> URI Class Initialized
INFO - 2022-06-28 13:02:12 --> Router Class Initialized
INFO - 2022-06-28 13:02:12 --> Output Class Initialized
INFO - 2022-06-28 13:02:12 --> Security Class Initialized
DEBUG - 2022-06-28 13:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:02:12 --> Input Class Initialized
INFO - 2022-06-28 13:02:12 --> Language Class Initialized
INFO - 2022-06-28 13:02:12 --> Loader Class Initialized
INFO - 2022-06-28 13:02:12 --> Helper loaded: url_helper
INFO - 2022-06-28 13:02:12 --> Helper loaded: file_helper
INFO - 2022-06-28 13:02:12 --> Database Driver Class Initialized
INFO - 2022-06-28 13:02:12 --> Email Class Initialized
DEBUG - 2022-06-28 13:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:02:12 --> Controller Class Initialized
INFO - 2022-06-28 13:02:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:02:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:02:12 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:02:12 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:02:12 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:02:12 --> Final output sent to browser
DEBUG - 2022-06-28 13:02:12 --> Total execution time: 0.0578
INFO - 2022-06-28 13:02:16 --> Config Class Initialized
INFO - 2022-06-28 13:02:16 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:02:16 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:02:16 --> Utf8 Class Initialized
INFO - 2022-06-28 13:02:16 --> URI Class Initialized
INFO - 2022-06-28 13:02:16 --> Router Class Initialized
INFO - 2022-06-28 13:02:16 --> Output Class Initialized
INFO - 2022-06-28 13:02:16 --> Security Class Initialized
DEBUG - 2022-06-28 13:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:02:16 --> Input Class Initialized
INFO - 2022-06-28 13:02:16 --> Language Class Initialized
INFO - 2022-06-28 13:02:16 --> Loader Class Initialized
INFO - 2022-06-28 13:02:16 --> Helper loaded: url_helper
INFO - 2022-06-28 13:02:16 --> Helper loaded: file_helper
INFO - 2022-06-28 13:02:16 --> Database Driver Class Initialized
INFO - 2022-06-28 13:02:16 --> Email Class Initialized
DEBUG - 2022-06-28 13:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:02:16 --> Controller Class Initialized
INFO - 2022-06-28 13:02:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:02:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:02:16 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:02:16 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:02:16 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:02:16 --> Final output sent to browser
DEBUG - 2022-06-28 13:02:16 --> Total execution time: 0.0664
INFO - 2022-06-28 13:02:16 --> Config Class Initialized
INFO - 2022-06-28 13:02:16 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:02:16 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:02:16 --> Utf8 Class Initialized
INFO - 2022-06-28 13:02:16 --> URI Class Initialized
INFO - 2022-06-28 13:02:16 --> Router Class Initialized
INFO - 2022-06-28 13:02:16 --> Output Class Initialized
INFO - 2022-06-28 13:02:16 --> Security Class Initialized
DEBUG - 2022-06-28 13:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:02:16 --> Input Class Initialized
INFO - 2022-06-28 13:02:16 --> Language Class Initialized
INFO - 2022-06-28 13:02:16 --> Loader Class Initialized
INFO - 2022-06-28 13:02:16 --> Helper loaded: url_helper
INFO - 2022-06-28 13:02:16 --> Helper loaded: file_helper
INFO - 2022-06-28 13:02:16 --> Database Driver Class Initialized
INFO - 2022-06-28 13:02:16 --> Email Class Initialized
DEBUG - 2022-06-28 13:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:02:16 --> Controller Class Initialized
INFO - 2022-06-28 13:02:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:02:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:02:16 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:02:16 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:02:16 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:02:16 --> Final output sent to browser
DEBUG - 2022-06-28 13:02:16 --> Total execution time: 0.0367
INFO - 2022-06-28 13:02:16 --> Config Class Initialized
INFO - 2022-06-28 13:02:16 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:02:16 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:02:16 --> Utf8 Class Initialized
INFO - 2022-06-28 13:02:16 --> URI Class Initialized
INFO - 2022-06-28 13:02:16 --> Router Class Initialized
INFO - 2022-06-28 13:02:16 --> Output Class Initialized
INFO - 2022-06-28 13:02:16 --> Security Class Initialized
DEBUG - 2022-06-28 13:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:02:16 --> Input Class Initialized
INFO - 2022-06-28 13:02:16 --> Language Class Initialized
INFO - 2022-06-28 13:02:16 --> Loader Class Initialized
INFO - 2022-06-28 13:02:16 --> Helper loaded: url_helper
INFO - 2022-06-28 13:02:16 --> Helper loaded: file_helper
INFO - 2022-06-28 13:02:16 --> Database Driver Class Initialized
INFO - 2022-06-28 13:02:16 --> Email Class Initialized
DEBUG - 2022-06-28 13:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:02:16 --> Controller Class Initialized
INFO - 2022-06-28 13:02:16 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:02:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:02:16 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:02:16 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:02:16 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:02:16 --> Final output sent to browser
DEBUG - 2022-06-28 13:02:16 --> Total execution time: 0.0460
INFO - 2022-06-28 13:02:16 --> Config Class Initialized
INFO - 2022-06-28 13:02:16 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:02:16 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:02:16 --> Utf8 Class Initialized
INFO - 2022-06-28 13:02:16 --> URI Class Initialized
INFO - 2022-06-28 13:02:16 --> Router Class Initialized
INFO - 2022-06-28 13:02:16 --> Output Class Initialized
INFO - 2022-06-28 13:02:16 --> Security Class Initialized
DEBUG - 2022-06-28 13:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:02:16 --> Input Class Initialized
INFO - 2022-06-28 13:02:16 --> Language Class Initialized
INFO - 2022-06-28 13:02:16 --> Loader Class Initialized
INFO - 2022-06-28 13:02:16 --> Helper loaded: url_helper
INFO - 2022-06-28 13:02:16 --> Helper loaded: file_helper
INFO - 2022-06-28 13:02:16 --> Database Driver Class Initialized
INFO - 2022-06-28 13:02:16 --> Email Class Initialized
DEBUG - 2022-06-28 13:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:02:17 --> Controller Class Initialized
INFO - 2022-06-28 13:02:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:02:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:02:17 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:02:17 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:02:17 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:02:17 --> Final output sent to browser
DEBUG - 2022-06-28 13:02:17 --> Total execution time: 0.0415
INFO - 2022-06-28 13:02:17 --> Config Class Initialized
INFO - 2022-06-28 13:02:17 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:02:17 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:02:17 --> Utf8 Class Initialized
INFO - 2022-06-28 13:02:17 --> URI Class Initialized
INFO - 2022-06-28 13:02:17 --> Router Class Initialized
INFO - 2022-06-28 13:02:17 --> Output Class Initialized
INFO - 2022-06-28 13:02:17 --> Security Class Initialized
DEBUG - 2022-06-28 13:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:02:17 --> Input Class Initialized
INFO - 2022-06-28 13:02:17 --> Language Class Initialized
INFO - 2022-06-28 13:02:17 --> Loader Class Initialized
INFO - 2022-06-28 13:02:17 --> Helper loaded: url_helper
INFO - 2022-06-28 13:02:17 --> Helper loaded: file_helper
INFO - 2022-06-28 13:02:17 --> Database Driver Class Initialized
INFO - 2022-06-28 13:02:17 --> Email Class Initialized
DEBUG - 2022-06-28 13:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:02:17 --> Controller Class Initialized
INFO - 2022-06-28 13:02:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:02:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:02:17 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:02:17 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:02:17 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:02:17 --> Final output sent to browser
DEBUG - 2022-06-28 13:02:17 --> Total execution time: 0.0401
INFO - 2022-06-28 13:02:17 --> Config Class Initialized
INFO - 2022-06-28 13:02:17 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:02:17 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:02:17 --> Utf8 Class Initialized
INFO - 2022-06-28 13:02:17 --> URI Class Initialized
INFO - 2022-06-28 13:02:17 --> Router Class Initialized
INFO - 2022-06-28 13:02:17 --> Output Class Initialized
INFO - 2022-06-28 13:02:17 --> Security Class Initialized
DEBUG - 2022-06-28 13:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:02:17 --> Input Class Initialized
INFO - 2022-06-28 13:02:17 --> Language Class Initialized
INFO - 2022-06-28 13:02:17 --> Loader Class Initialized
INFO - 2022-06-28 13:02:17 --> Helper loaded: url_helper
INFO - 2022-06-28 13:02:17 --> Helper loaded: file_helper
INFO - 2022-06-28 13:02:17 --> Database Driver Class Initialized
INFO - 2022-06-28 13:02:17 --> Email Class Initialized
DEBUG - 2022-06-28 13:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:02:17 --> Controller Class Initialized
INFO - 2022-06-28 13:02:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:02:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:02:17 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:02:17 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:02:17 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:02:17 --> Final output sent to browser
DEBUG - 2022-06-28 13:02:17 --> Total execution time: 0.0419
INFO - 2022-06-28 13:02:17 --> Config Class Initialized
INFO - 2022-06-28 13:02:17 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:02:17 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:02:17 --> Utf8 Class Initialized
INFO - 2022-06-28 13:02:17 --> URI Class Initialized
INFO - 2022-06-28 13:02:17 --> Router Class Initialized
INFO - 2022-06-28 13:02:17 --> Output Class Initialized
INFO - 2022-06-28 13:02:17 --> Security Class Initialized
DEBUG - 2022-06-28 13:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:02:17 --> Input Class Initialized
INFO - 2022-06-28 13:02:17 --> Language Class Initialized
INFO - 2022-06-28 13:02:17 --> Loader Class Initialized
INFO - 2022-06-28 13:02:17 --> Helper loaded: url_helper
INFO - 2022-06-28 13:02:17 --> Helper loaded: file_helper
INFO - 2022-06-28 13:02:17 --> Database Driver Class Initialized
INFO - 2022-06-28 13:02:17 --> Email Class Initialized
DEBUG - 2022-06-28 13:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:02:17 --> Controller Class Initialized
INFO - 2022-06-28 13:02:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:02:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:02:17 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:02:17 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:02:17 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:02:17 --> Final output sent to browser
DEBUG - 2022-06-28 13:02:17 --> Total execution time: 0.0440
INFO - 2022-06-28 13:02:17 --> Config Class Initialized
INFO - 2022-06-28 13:02:17 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:02:17 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:02:17 --> Utf8 Class Initialized
INFO - 2022-06-28 13:02:17 --> URI Class Initialized
INFO - 2022-06-28 13:02:17 --> Router Class Initialized
INFO - 2022-06-28 13:02:17 --> Output Class Initialized
INFO - 2022-06-28 13:02:17 --> Security Class Initialized
DEBUG - 2022-06-28 13:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:02:17 --> Input Class Initialized
INFO - 2022-06-28 13:02:17 --> Language Class Initialized
INFO - 2022-06-28 13:02:17 --> Loader Class Initialized
INFO - 2022-06-28 13:02:17 --> Helper loaded: url_helper
INFO - 2022-06-28 13:02:17 --> Helper loaded: file_helper
INFO - 2022-06-28 13:02:17 --> Database Driver Class Initialized
INFO - 2022-06-28 13:02:17 --> Email Class Initialized
DEBUG - 2022-06-28 13:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:02:17 --> Controller Class Initialized
INFO - 2022-06-28 13:02:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:02:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:02:17 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:02:17 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:02:17 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:02:17 --> Final output sent to browser
DEBUG - 2022-06-28 13:02:17 --> Total execution time: 0.0434
INFO - 2022-06-28 13:02:17 --> Config Class Initialized
INFO - 2022-06-28 13:02:17 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:02:17 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:02:17 --> Utf8 Class Initialized
INFO - 2022-06-28 13:02:17 --> URI Class Initialized
INFO - 2022-06-28 13:02:17 --> Router Class Initialized
INFO - 2022-06-28 13:02:17 --> Output Class Initialized
INFO - 2022-06-28 13:02:17 --> Security Class Initialized
DEBUG - 2022-06-28 13:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:02:17 --> Input Class Initialized
INFO - 2022-06-28 13:02:17 --> Language Class Initialized
INFO - 2022-06-28 13:02:17 --> Loader Class Initialized
INFO - 2022-06-28 13:02:17 --> Helper loaded: url_helper
INFO - 2022-06-28 13:02:17 --> Helper loaded: file_helper
INFO - 2022-06-28 13:02:17 --> Database Driver Class Initialized
INFO - 2022-06-28 13:02:17 --> Email Class Initialized
DEBUG - 2022-06-28 13:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:02:18 --> Controller Class Initialized
INFO - 2022-06-28 13:02:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:02:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:02:18 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:02:18 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:02:18 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:02:18 --> Final output sent to browser
DEBUG - 2022-06-28 13:02:18 --> Total execution time: 0.0484
INFO - 2022-06-28 13:02:18 --> Config Class Initialized
INFO - 2022-06-28 13:02:18 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:02:18 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:02:18 --> Utf8 Class Initialized
INFO - 2022-06-28 13:02:18 --> URI Class Initialized
INFO - 2022-06-28 13:02:18 --> Router Class Initialized
INFO - 2022-06-28 13:02:18 --> Output Class Initialized
INFO - 2022-06-28 13:02:18 --> Security Class Initialized
DEBUG - 2022-06-28 13:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:02:18 --> Input Class Initialized
INFO - 2022-06-28 13:02:18 --> Language Class Initialized
INFO - 2022-06-28 13:02:18 --> Loader Class Initialized
INFO - 2022-06-28 13:02:18 --> Helper loaded: url_helper
INFO - 2022-06-28 13:02:18 --> Helper loaded: file_helper
INFO - 2022-06-28 13:02:18 --> Database Driver Class Initialized
INFO - 2022-06-28 13:02:18 --> Email Class Initialized
DEBUG - 2022-06-28 13:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:02:18 --> Controller Class Initialized
INFO - 2022-06-28 13:02:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:02:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:02:18 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:02:18 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:02:18 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:02:18 --> Final output sent to browser
DEBUG - 2022-06-28 13:02:18 --> Total execution time: 0.0359
INFO - 2022-06-28 13:02:18 --> Config Class Initialized
INFO - 2022-06-28 13:02:18 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:02:18 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:02:18 --> Utf8 Class Initialized
INFO - 2022-06-28 13:02:18 --> URI Class Initialized
INFO - 2022-06-28 13:02:18 --> Router Class Initialized
INFO - 2022-06-28 13:02:18 --> Output Class Initialized
INFO - 2022-06-28 13:02:18 --> Security Class Initialized
DEBUG - 2022-06-28 13:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:02:18 --> Input Class Initialized
INFO - 2022-06-28 13:02:18 --> Language Class Initialized
INFO - 2022-06-28 13:02:18 --> Loader Class Initialized
INFO - 2022-06-28 13:02:18 --> Helper loaded: url_helper
INFO - 2022-06-28 13:02:18 --> Helper loaded: file_helper
INFO - 2022-06-28 13:02:18 --> Database Driver Class Initialized
INFO - 2022-06-28 13:02:18 --> Email Class Initialized
DEBUG - 2022-06-28 13:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:02:18 --> Controller Class Initialized
INFO - 2022-06-28 13:02:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:02:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:02:18 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:02:18 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:02:18 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:02:18 --> Final output sent to browser
DEBUG - 2022-06-28 13:02:18 --> Total execution time: 0.0345
INFO - 2022-06-28 13:02:18 --> Config Class Initialized
INFO - 2022-06-28 13:02:18 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:02:18 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:02:18 --> Utf8 Class Initialized
INFO - 2022-06-28 13:02:18 --> URI Class Initialized
INFO - 2022-06-28 13:02:18 --> Router Class Initialized
INFO - 2022-06-28 13:02:18 --> Output Class Initialized
INFO - 2022-06-28 13:02:18 --> Security Class Initialized
DEBUG - 2022-06-28 13:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:02:18 --> Input Class Initialized
INFO - 2022-06-28 13:02:18 --> Language Class Initialized
INFO - 2022-06-28 13:02:18 --> Loader Class Initialized
INFO - 2022-06-28 13:02:18 --> Helper loaded: url_helper
INFO - 2022-06-28 13:02:18 --> Helper loaded: file_helper
INFO - 2022-06-28 13:02:18 --> Database Driver Class Initialized
INFO - 2022-06-28 13:02:18 --> Email Class Initialized
DEBUG - 2022-06-28 13:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:02:18 --> Controller Class Initialized
INFO - 2022-06-28 13:02:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:02:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:02:18 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:02:18 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:02:18 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:02:18 --> Final output sent to browser
DEBUG - 2022-06-28 13:02:18 --> Total execution time: 0.0249
INFO - 2022-06-28 13:02:18 --> Config Class Initialized
INFO - 2022-06-28 13:02:18 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:02:18 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:02:18 --> Utf8 Class Initialized
INFO - 2022-06-28 13:02:18 --> URI Class Initialized
INFO - 2022-06-28 13:02:18 --> Router Class Initialized
INFO - 2022-06-28 13:02:18 --> Output Class Initialized
INFO - 2022-06-28 13:02:18 --> Security Class Initialized
DEBUG - 2022-06-28 13:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:02:18 --> Input Class Initialized
INFO - 2022-06-28 13:02:18 --> Language Class Initialized
INFO - 2022-06-28 13:02:18 --> Loader Class Initialized
INFO - 2022-06-28 13:02:18 --> Helper loaded: url_helper
INFO - 2022-06-28 13:02:18 --> Helper loaded: file_helper
INFO - 2022-06-28 13:02:18 --> Database Driver Class Initialized
INFO - 2022-06-28 13:02:18 --> Email Class Initialized
DEBUG - 2022-06-28 13:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:02:18 --> Controller Class Initialized
INFO - 2022-06-28 13:02:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:02:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:02:18 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:02:18 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:02:18 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:02:18 --> Final output sent to browser
DEBUG - 2022-06-28 13:02:18 --> Total execution time: 0.0392
INFO - 2022-06-28 13:02:18 --> Config Class Initialized
INFO - 2022-06-28 13:02:18 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:02:18 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:02:18 --> Utf8 Class Initialized
INFO - 2022-06-28 13:02:18 --> URI Class Initialized
INFO - 2022-06-28 13:02:18 --> Router Class Initialized
INFO - 2022-06-28 13:02:18 --> Output Class Initialized
INFO - 2022-06-28 13:02:18 --> Security Class Initialized
DEBUG - 2022-06-28 13:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:02:18 --> Input Class Initialized
INFO - 2022-06-28 13:02:18 --> Language Class Initialized
INFO - 2022-06-28 13:02:18 --> Loader Class Initialized
INFO - 2022-06-28 13:02:18 --> Helper loaded: url_helper
INFO - 2022-06-28 13:02:18 --> Helper loaded: file_helper
INFO - 2022-06-28 13:02:18 --> Database Driver Class Initialized
INFO - 2022-06-28 13:02:18 --> Email Class Initialized
DEBUG - 2022-06-28 13:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:02:18 --> Controller Class Initialized
INFO - 2022-06-28 13:02:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:02:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:02:18 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:02:18 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:02:18 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:02:18 --> Final output sent to browser
DEBUG - 2022-06-28 13:02:18 --> Total execution time: 0.0475
INFO - 2022-06-28 13:02:19 --> Config Class Initialized
INFO - 2022-06-28 13:02:19 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:02:19 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:02:19 --> Utf8 Class Initialized
INFO - 2022-06-28 13:02:19 --> URI Class Initialized
INFO - 2022-06-28 13:02:19 --> Router Class Initialized
INFO - 2022-06-28 13:02:19 --> Output Class Initialized
INFO - 2022-06-28 13:02:19 --> Security Class Initialized
DEBUG - 2022-06-28 13:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:02:19 --> Input Class Initialized
INFO - 2022-06-28 13:02:19 --> Language Class Initialized
INFO - 2022-06-28 13:02:19 --> Loader Class Initialized
INFO - 2022-06-28 13:02:19 --> Helper loaded: url_helper
INFO - 2022-06-28 13:02:19 --> Helper loaded: file_helper
INFO - 2022-06-28 13:02:19 --> Database Driver Class Initialized
INFO - 2022-06-28 13:02:19 --> Email Class Initialized
DEBUG - 2022-06-28 13:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:02:19 --> Controller Class Initialized
INFO - 2022-06-28 13:02:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:02:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:02:19 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:02:19 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:02:19 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:02:19 --> Final output sent to browser
DEBUG - 2022-06-28 13:02:19 --> Total execution time: 0.0590
INFO - 2022-06-28 13:02:19 --> Config Class Initialized
INFO - 2022-06-28 13:02:19 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:02:19 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:02:19 --> Utf8 Class Initialized
INFO - 2022-06-28 13:02:19 --> URI Class Initialized
INFO - 2022-06-28 13:02:19 --> Router Class Initialized
INFO - 2022-06-28 13:02:19 --> Output Class Initialized
INFO - 2022-06-28 13:02:19 --> Security Class Initialized
DEBUG - 2022-06-28 13:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:02:19 --> Input Class Initialized
INFO - 2022-06-28 13:02:19 --> Language Class Initialized
INFO - 2022-06-28 13:02:19 --> Loader Class Initialized
INFO - 2022-06-28 13:02:19 --> Helper loaded: url_helper
INFO - 2022-06-28 13:02:19 --> Helper loaded: file_helper
INFO - 2022-06-28 13:02:19 --> Database Driver Class Initialized
INFO - 2022-06-28 13:02:19 --> Email Class Initialized
DEBUG - 2022-06-28 13:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:02:19 --> Controller Class Initialized
INFO - 2022-06-28 13:02:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:02:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:02:19 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:02:19 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:02:19 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:02:19 --> Final output sent to browser
DEBUG - 2022-06-28 13:02:19 --> Total execution time: 0.0368
INFO - 2022-06-28 13:02:19 --> Config Class Initialized
INFO - 2022-06-28 13:02:19 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:02:19 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:02:19 --> Utf8 Class Initialized
INFO - 2022-06-28 13:02:19 --> URI Class Initialized
INFO - 2022-06-28 13:02:19 --> Router Class Initialized
INFO - 2022-06-28 13:02:19 --> Output Class Initialized
INFO - 2022-06-28 13:02:19 --> Security Class Initialized
DEBUG - 2022-06-28 13:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:02:19 --> Input Class Initialized
INFO - 2022-06-28 13:02:19 --> Language Class Initialized
INFO - 2022-06-28 13:02:19 --> Loader Class Initialized
INFO - 2022-06-28 13:02:19 --> Helper loaded: url_helper
INFO - 2022-06-28 13:02:19 --> Helper loaded: file_helper
INFO - 2022-06-28 13:02:19 --> Database Driver Class Initialized
INFO - 2022-06-28 13:02:19 --> Email Class Initialized
DEBUG - 2022-06-28 13:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:02:19 --> Controller Class Initialized
INFO - 2022-06-28 13:02:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:02:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:02:19 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:02:19 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:02:19 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:02:19 --> Final output sent to browser
DEBUG - 2022-06-28 13:02:19 --> Total execution time: 0.0347
INFO - 2022-06-28 13:02:19 --> Config Class Initialized
INFO - 2022-06-28 13:02:19 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:02:19 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:02:19 --> Utf8 Class Initialized
INFO - 2022-06-28 13:02:19 --> URI Class Initialized
INFO - 2022-06-28 13:02:19 --> Router Class Initialized
INFO - 2022-06-28 13:02:19 --> Output Class Initialized
INFO - 2022-06-28 13:02:19 --> Security Class Initialized
DEBUG - 2022-06-28 13:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:02:19 --> Input Class Initialized
INFO - 2022-06-28 13:02:19 --> Config Class Initialized
INFO - 2022-06-28 13:02:19 --> Hooks Class Initialized
INFO - 2022-06-28 13:02:19 --> Language Class Initialized
DEBUG - 2022-06-28 13:02:19 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:02:19 --> Loader Class Initialized
INFO - 2022-06-28 13:02:19 --> Utf8 Class Initialized
INFO - 2022-06-28 13:02:19 --> Helper loaded: url_helper
INFO - 2022-06-28 13:02:19 --> URI Class Initialized
INFO - 2022-06-28 13:02:19 --> Helper loaded: file_helper
INFO - 2022-06-28 13:02:19 --> Router Class Initialized
INFO - 2022-06-28 13:02:19 --> Database Driver Class Initialized
INFO - 2022-06-28 13:02:19 --> Output Class Initialized
INFO - 2022-06-28 13:02:19 --> Security Class Initialized
DEBUG - 2022-06-28 13:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:02:19 --> Input Class Initialized
INFO - 2022-06-28 13:02:19 --> Email Class Initialized
INFO - 2022-06-28 13:02:19 --> Language Class Initialized
INFO - 2022-06-28 13:02:19 --> Loader Class Initialized
DEBUG - 2022-06-28 13:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:02:19 --> Helper loaded: url_helper
INFO - 2022-06-28 13:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:02:19 --> Helper loaded: file_helper
INFO - 2022-06-28 13:02:19 --> Controller Class Initialized
INFO - 2022-06-28 13:02:19 --> Database Driver Class Initialized
INFO - 2022-06-28 13:02:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:02:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:02:19 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:02:19 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:02:19 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:02:19 --> Final output sent to browser
DEBUG - 2022-06-28 13:02:19 --> Total execution time: 0.0333
INFO - 2022-06-28 13:02:19 --> Email Class Initialized
DEBUG - 2022-06-28 13:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:02:19 --> Controller Class Initialized
INFO - 2022-06-28 13:02:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:02:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:02:19 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:02:19 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:02:19 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:02:19 --> Final output sent to browser
DEBUG - 2022-06-28 13:02:19 --> Total execution time: 0.1392
INFO - 2022-06-28 13:02:19 --> Config Class Initialized
INFO - 2022-06-28 13:02:19 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:02:19 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:02:19 --> Utf8 Class Initialized
INFO - 2022-06-28 13:02:19 --> URI Class Initialized
INFO - 2022-06-28 13:02:19 --> Router Class Initialized
INFO - 2022-06-28 13:02:19 --> Output Class Initialized
INFO - 2022-06-28 13:02:19 --> Security Class Initialized
DEBUG - 2022-06-28 13:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:02:19 --> Input Class Initialized
INFO - 2022-06-28 13:02:19 --> Language Class Initialized
INFO - 2022-06-28 13:02:19 --> Loader Class Initialized
INFO - 2022-06-28 13:02:19 --> Helper loaded: url_helper
INFO - 2022-06-28 13:02:19 --> Helper loaded: file_helper
INFO - 2022-06-28 13:02:19 --> Database Driver Class Initialized
INFO - 2022-06-28 13:02:19 --> Email Class Initialized
DEBUG - 2022-06-28 13:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:02:19 --> Controller Class Initialized
INFO - 2022-06-28 13:02:19 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:02:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:02:19 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:02:19 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:02:19 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:02:19 --> Final output sent to browser
DEBUG - 2022-06-28 13:02:19 --> Total execution time: 0.0491
INFO - 2022-06-28 13:02:20 --> Config Class Initialized
INFO - 2022-06-28 13:02:20 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:02:20 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:02:20 --> Utf8 Class Initialized
INFO - 2022-06-28 13:02:20 --> URI Class Initialized
INFO - 2022-06-28 13:02:20 --> Router Class Initialized
INFO - 2022-06-28 13:02:20 --> Output Class Initialized
INFO - 2022-06-28 13:02:20 --> Security Class Initialized
DEBUG - 2022-06-28 13:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:02:20 --> Input Class Initialized
INFO - 2022-06-28 13:02:20 --> Language Class Initialized
INFO - 2022-06-28 13:02:20 --> Loader Class Initialized
INFO - 2022-06-28 13:02:20 --> Helper loaded: url_helper
INFO - 2022-06-28 13:02:20 --> Helper loaded: file_helper
INFO - 2022-06-28 13:02:20 --> Database Driver Class Initialized
INFO - 2022-06-28 13:02:20 --> Email Class Initialized
DEBUG - 2022-06-28 13:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:02:20 --> Controller Class Initialized
INFO - 2022-06-28 13:02:20 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:02:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:02:20 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:02:20 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:02:20 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:02:20 --> Final output sent to browser
DEBUG - 2022-06-28 13:02:20 --> Total execution time: 0.0354
INFO - 2022-06-28 13:03:01 --> Config Class Initialized
INFO - 2022-06-28 13:03:01 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:03:01 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:03:01 --> Utf8 Class Initialized
INFO - 2022-06-28 13:03:01 --> URI Class Initialized
INFO - 2022-06-28 13:03:01 --> Router Class Initialized
INFO - 2022-06-28 13:03:01 --> Output Class Initialized
INFO - 2022-06-28 13:03:01 --> Security Class Initialized
DEBUG - 2022-06-28 13:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:03:01 --> Input Class Initialized
INFO - 2022-06-28 13:03:01 --> Language Class Initialized
INFO - 2022-06-28 13:03:01 --> Loader Class Initialized
INFO - 2022-06-28 13:03:01 --> Helper loaded: url_helper
INFO - 2022-06-28 13:03:01 --> Helper loaded: file_helper
INFO - 2022-06-28 13:03:01 --> Database Driver Class Initialized
INFO - 2022-06-28 13:03:01 --> Email Class Initialized
DEBUG - 2022-06-28 13:03:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:03:01 --> Controller Class Initialized
INFO - 2022-06-28 13:03:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:03:01 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 13:03:01 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:03:01 --> Final output sent to browser
DEBUG - 2022-06-28 13:03:01 --> Total execution time: 0.0231
INFO - 2022-06-28 13:03:04 --> Config Class Initialized
INFO - 2022-06-28 13:03:04 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:03:04 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:03:04 --> Utf8 Class Initialized
INFO - 2022-06-28 13:03:04 --> URI Class Initialized
INFO - 2022-06-28 13:03:04 --> Router Class Initialized
INFO - 2022-06-28 13:03:04 --> Output Class Initialized
INFO - 2022-06-28 13:03:04 --> Security Class Initialized
DEBUG - 2022-06-28 13:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:03:04 --> Input Class Initialized
INFO - 2022-06-28 13:03:04 --> Language Class Initialized
INFO - 2022-06-28 13:03:04 --> Loader Class Initialized
INFO - 2022-06-28 13:03:04 --> Helper loaded: url_helper
INFO - 2022-06-28 13:03:04 --> Helper loaded: file_helper
INFO - 2022-06-28 13:03:04 --> Database Driver Class Initialized
INFO - 2022-06-28 13:03:04 --> Email Class Initialized
DEBUG - 2022-06-28 13:03:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:03:04 --> Controller Class Initialized
INFO - 2022-06-28 13:03:04 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:03:04 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 13:03:04 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:03:04 --> Final output sent to browser
DEBUG - 2022-06-28 13:03:04 --> Total execution time: 0.1066
INFO - 2022-06-28 13:03:05 --> Config Class Initialized
INFO - 2022-06-28 13:03:05 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:03:05 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:03:05 --> Utf8 Class Initialized
INFO - 2022-06-28 13:03:05 --> URI Class Initialized
INFO - 2022-06-28 13:03:05 --> Router Class Initialized
INFO - 2022-06-28 13:03:05 --> Output Class Initialized
INFO - 2022-06-28 13:03:05 --> Security Class Initialized
DEBUG - 2022-06-28 13:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:03:05 --> Input Class Initialized
INFO - 2022-06-28 13:03:05 --> Language Class Initialized
INFO - 2022-06-28 13:03:05 --> Loader Class Initialized
INFO - 2022-06-28 13:03:05 --> Helper loaded: url_helper
INFO - 2022-06-28 13:03:05 --> Helper loaded: file_helper
INFO - 2022-06-28 13:03:05 --> Database Driver Class Initialized
INFO - 2022-06-28 13:03:05 --> Email Class Initialized
DEBUG - 2022-06-28 13:03:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:03:05 --> Controller Class Initialized
INFO - 2022-06-28 13:03:05 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:03:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:03:05 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:03:05 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:03:05 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:03:05 --> Final output sent to browser
DEBUG - 2022-06-28 13:03:05 --> Total execution time: 0.1437
INFO - 2022-06-28 13:04:53 --> Config Class Initialized
INFO - 2022-06-28 13:04:53 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:04:53 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:04:53 --> Utf8 Class Initialized
INFO - 2022-06-28 13:04:53 --> URI Class Initialized
INFO - 2022-06-28 13:04:53 --> Router Class Initialized
INFO - 2022-06-28 13:04:53 --> Output Class Initialized
INFO - 2022-06-28 13:04:53 --> Security Class Initialized
DEBUG - 2022-06-28 13:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:04:53 --> Input Class Initialized
INFO - 2022-06-28 13:04:53 --> Language Class Initialized
INFO - 2022-06-28 13:04:53 --> Loader Class Initialized
INFO - 2022-06-28 13:04:53 --> Helper loaded: url_helper
INFO - 2022-06-28 13:04:53 --> Helper loaded: file_helper
INFO - 2022-06-28 13:04:53 --> Database Driver Class Initialized
INFO - 2022-06-28 13:04:53 --> Email Class Initialized
DEBUG - 2022-06-28 13:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:04:53 --> Controller Class Initialized
INFO - 2022-06-28 13:04:53 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:04:53 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 13:04:53 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 13:04:53 --> Final output sent to browser
DEBUG - 2022-06-28 13:04:53 --> Total execution time: 0.0301
INFO - 2022-06-28 13:24:08 --> Config Class Initialized
INFO - 2022-06-28 13:24:08 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:24:08 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:24:08 --> Utf8 Class Initialized
INFO - 2022-06-28 13:24:08 --> URI Class Initialized
INFO - 2022-06-28 13:24:08 --> Router Class Initialized
INFO - 2022-06-28 13:24:08 --> Output Class Initialized
INFO - 2022-06-28 13:24:08 --> Security Class Initialized
DEBUG - 2022-06-28 13:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:24:08 --> Input Class Initialized
INFO - 2022-06-28 13:24:08 --> Language Class Initialized
INFO - 2022-06-28 13:24:08 --> Loader Class Initialized
INFO - 2022-06-28 13:24:08 --> Helper loaded: url_helper
INFO - 2022-06-28 13:24:08 --> Helper loaded: file_helper
INFO - 2022-06-28 13:24:08 --> Database Driver Class Initialized
INFO - 2022-06-28 13:24:08 --> Email Class Initialized
DEBUG - 2022-06-28 13:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:24:08 --> Controller Class Initialized
INFO - 2022-06-28 13:24:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:24:08 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 13:24:08 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:24:08 --> Final output sent to browser
DEBUG - 2022-06-28 13:24:08 --> Total execution time: 0.0606
INFO - 2022-06-28 13:24:22 --> Config Class Initialized
INFO - 2022-06-28 13:24:22 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:24:22 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:24:22 --> Utf8 Class Initialized
INFO - 2022-06-28 13:24:22 --> URI Class Initialized
INFO - 2022-06-28 13:24:22 --> Router Class Initialized
INFO - 2022-06-28 13:24:22 --> Output Class Initialized
INFO - 2022-06-28 13:24:22 --> Security Class Initialized
DEBUG - 2022-06-28 13:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:24:22 --> Input Class Initialized
INFO - 2022-06-28 13:24:22 --> Language Class Initialized
INFO - 2022-06-28 13:24:22 --> Loader Class Initialized
INFO - 2022-06-28 13:24:22 --> Helper loaded: url_helper
INFO - 2022-06-28 13:24:22 --> Helper loaded: file_helper
INFO - 2022-06-28 13:24:22 --> Database Driver Class Initialized
INFO - 2022-06-28 13:24:22 --> Email Class Initialized
DEBUG - 2022-06-28 13:24:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:24:22 --> Controller Class Initialized
INFO - 2022-06-28 13:24:22 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:24:22 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 13:24:22 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:24:22 --> Final output sent to browser
DEBUG - 2022-06-28 13:24:22 --> Total execution time: 0.0653
INFO - 2022-06-28 13:24:23 --> Config Class Initialized
INFO - 2022-06-28 13:24:23 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:24:23 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:24:23 --> Utf8 Class Initialized
INFO - 2022-06-28 13:24:23 --> URI Class Initialized
INFO - 2022-06-28 13:24:23 --> Router Class Initialized
INFO - 2022-06-28 13:24:23 --> Output Class Initialized
INFO - 2022-06-28 13:24:23 --> Security Class Initialized
DEBUG - 2022-06-28 13:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:24:23 --> Input Class Initialized
INFO - 2022-06-28 13:24:23 --> Language Class Initialized
INFO - 2022-06-28 13:24:23 --> Loader Class Initialized
INFO - 2022-06-28 13:24:23 --> Helper loaded: url_helper
INFO - 2022-06-28 13:24:23 --> Helper loaded: file_helper
INFO - 2022-06-28 13:24:23 --> Database Driver Class Initialized
INFO - 2022-06-28 13:24:23 --> Email Class Initialized
DEBUG - 2022-06-28 13:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:24:23 --> Controller Class Initialized
INFO - 2022-06-28 13:24:23 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:24:23 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 13:24:23 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:24:23 --> Final output sent to browser
DEBUG - 2022-06-28 13:24:23 --> Total execution time: 0.0619
INFO - 2022-06-28 13:24:25 --> Config Class Initialized
INFO - 2022-06-28 13:24:25 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:24:25 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:24:25 --> Utf8 Class Initialized
INFO - 2022-06-28 13:24:25 --> URI Class Initialized
INFO - 2022-06-28 13:24:25 --> Router Class Initialized
INFO - 2022-06-28 13:24:25 --> Output Class Initialized
INFO - 2022-06-28 13:24:25 --> Security Class Initialized
DEBUG - 2022-06-28 13:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:24:25 --> Input Class Initialized
INFO - 2022-06-28 13:24:25 --> Language Class Initialized
INFO - 2022-06-28 13:24:25 --> Loader Class Initialized
INFO - 2022-06-28 13:24:25 --> Helper loaded: url_helper
INFO - 2022-06-28 13:24:25 --> Helper loaded: file_helper
INFO - 2022-06-28 13:24:25 --> Database Driver Class Initialized
INFO - 2022-06-28 13:24:25 --> Email Class Initialized
DEBUG - 2022-06-28 13:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:24:25 --> Controller Class Initialized
INFO - 2022-06-28 13:24:25 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:24:25 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 13:24:25 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:24:25 --> Final output sent to browser
DEBUG - 2022-06-28 13:24:25 --> Total execution time: 0.0338
INFO - 2022-06-28 13:24:26 --> Config Class Initialized
INFO - 2022-06-28 13:24:26 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:24:26 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:24:26 --> Utf8 Class Initialized
INFO - 2022-06-28 13:24:26 --> URI Class Initialized
INFO - 2022-06-28 13:24:26 --> Router Class Initialized
INFO - 2022-06-28 13:24:26 --> Output Class Initialized
INFO - 2022-06-28 13:24:26 --> Security Class Initialized
DEBUG - 2022-06-28 13:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:24:26 --> Input Class Initialized
INFO - 2022-06-28 13:24:26 --> Language Class Initialized
INFO - 2022-06-28 13:24:26 --> Loader Class Initialized
INFO - 2022-06-28 13:24:26 --> Helper loaded: url_helper
INFO - 2022-06-28 13:24:26 --> Helper loaded: file_helper
INFO - 2022-06-28 13:24:26 --> Database Driver Class Initialized
INFO - 2022-06-28 13:24:26 --> Email Class Initialized
DEBUG - 2022-06-28 13:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:24:26 --> Controller Class Initialized
INFO - 2022-06-28 13:24:26 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:24:26 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 13:24:27 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:24:27 --> Final output sent to browser
DEBUG - 2022-06-28 13:24:27 --> Total execution time: 0.0652
INFO - 2022-06-28 13:24:28 --> Config Class Initialized
INFO - 2022-06-28 13:24:28 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:24:28 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:24:28 --> Utf8 Class Initialized
INFO - 2022-06-28 13:24:28 --> URI Class Initialized
INFO - 2022-06-28 13:24:28 --> Router Class Initialized
INFO - 2022-06-28 13:24:28 --> Output Class Initialized
INFO - 2022-06-28 13:24:28 --> Security Class Initialized
DEBUG - 2022-06-28 13:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:24:28 --> Input Class Initialized
INFO - 2022-06-28 13:24:28 --> Language Class Initialized
INFO - 2022-06-28 13:24:28 --> Loader Class Initialized
INFO - 2022-06-28 13:24:28 --> Helper loaded: url_helper
INFO - 2022-06-28 13:24:28 --> Helper loaded: file_helper
INFO - 2022-06-28 13:24:28 --> Database Driver Class Initialized
INFO - 2022-06-28 13:24:28 --> Email Class Initialized
DEBUG - 2022-06-28 13:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:24:28 --> Controller Class Initialized
INFO - 2022-06-28 13:24:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:24:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:24:28 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:24:28 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:24:28 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:24:28 --> Final output sent to browser
DEBUG - 2022-06-28 13:24:28 --> Total execution time: 0.0350
INFO - 2022-06-28 13:29:02 --> Config Class Initialized
INFO - 2022-06-28 13:29:02 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:29:02 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:29:02 --> Utf8 Class Initialized
INFO - 2022-06-28 13:29:02 --> URI Class Initialized
INFO - 2022-06-28 13:29:02 --> Router Class Initialized
INFO - 2022-06-28 13:29:02 --> Output Class Initialized
INFO - 2022-06-28 13:29:02 --> Security Class Initialized
DEBUG - 2022-06-28 13:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:29:02 --> Input Class Initialized
INFO - 2022-06-28 13:29:02 --> Language Class Initialized
INFO - 2022-06-28 13:29:02 --> Loader Class Initialized
INFO - 2022-06-28 13:29:02 --> Helper loaded: url_helper
INFO - 2022-06-28 13:29:02 --> Helper loaded: file_helper
INFO - 2022-06-28 13:29:02 --> Database Driver Class Initialized
INFO - 2022-06-28 13:29:02 --> Email Class Initialized
DEBUG - 2022-06-28 13:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:29:02 --> Controller Class Initialized
INFO - 2022-06-28 13:29:02 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:29:02 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 13:29:02 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 13:29:02 --> Final output sent to browser
DEBUG - 2022-06-28 13:29:02 --> Total execution time: 0.0396
INFO - 2022-06-28 13:30:08 --> Config Class Initialized
INFO - 2022-06-28 13:30:08 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:30:08 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:30:08 --> Utf8 Class Initialized
INFO - 2022-06-28 13:30:08 --> URI Class Initialized
INFO - 2022-06-28 13:30:08 --> Router Class Initialized
INFO - 2022-06-28 13:30:08 --> Output Class Initialized
INFO - 2022-06-28 13:30:08 --> Security Class Initialized
DEBUG - 2022-06-28 13:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:30:08 --> Input Class Initialized
INFO - 2022-06-28 13:30:08 --> Language Class Initialized
INFO - 2022-06-28 13:30:08 --> Loader Class Initialized
INFO - 2022-06-28 13:30:08 --> Helper loaded: url_helper
INFO - 2022-06-28 13:30:08 --> Helper loaded: file_helper
INFO - 2022-06-28 13:30:08 --> Database Driver Class Initialized
INFO - 2022-06-28 13:30:08 --> Email Class Initialized
DEBUG - 2022-06-28 13:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:30:08 --> Controller Class Initialized
INFO - 2022-06-28 13:30:08 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:30:08 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 13:30:08 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:30:08 --> Final output sent to browser
DEBUG - 2022-06-28 13:30:08 --> Total execution time: 0.0614
INFO - 2022-06-28 13:30:10 --> Config Class Initialized
INFO - 2022-06-28 13:30:10 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:30:10 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:30:10 --> Utf8 Class Initialized
INFO - 2022-06-28 13:30:10 --> URI Class Initialized
INFO - 2022-06-28 13:30:10 --> Router Class Initialized
INFO - 2022-06-28 13:30:10 --> Output Class Initialized
INFO - 2022-06-28 13:30:10 --> Security Class Initialized
DEBUG - 2022-06-28 13:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:30:10 --> Input Class Initialized
INFO - 2022-06-28 13:30:10 --> Language Class Initialized
INFO - 2022-06-28 13:30:10 --> Loader Class Initialized
INFO - 2022-06-28 13:30:10 --> Helper loaded: url_helper
INFO - 2022-06-28 13:30:10 --> Helper loaded: file_helper
INFO - 2022-06-28 13:30:10 --> Database Driver Class Initialized
INFO - 2022-06-28 13:30:10 --> Email Class Initialized
DEBUG - 2022-06-28 13:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:30:10 --> Controller Class Initialized
INFO - 2022-06-28 13:30:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:30:10 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 13:30:10 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:30:10 --> Final output sent to browser
DEBUG - 2022-06-28 13:30:10 --> Total execution time: 0.0747
INFO - 2022-06-28 13:30:11 --> Config Class Initialized
INFO - 2022-06-28 13:30:11 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:30:11 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:30:11 --> Utf8 Class Initialized
INFO - 2022-06-28 13:30:11 --> URI Class Initialized
INFO - 2022-06-28 13:30:11 --> Router Class Initialized
INFO - 2022-06-28 13:30:11 --> Output Class Initialized
INFO - 2022-06-28 13:30:11 --> Security Class Initialized
DEBUG - 2022-06-28 13:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:30:11 --> Input Class Initialized
INFO - 2022-06-28 13:30:11 --> Language Class Initialized
INFO - 2022-06-28 13:30:11 --> Loader Class Initialized
INFO - 2022-06-28 13:30:11 --> Helper loaded: url_helper
INFO - 2022-06-28 13:30:11 --> Helper loaded: file_helper
INFO - 2022-06-28 13:30:11 --> Database Driver Class Initialized
INFO - 2022-06-28 13:30:11 --> Email Class Initialized
DEBUG - 2022-06-28 13:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:30:11 --> Controller Class Initialized
INFO - 2022-06-28 13:30:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:30:11 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 13:30:11 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:30:11 --> Final output sent to browser
DEBUG - 2022-06-28 13:30:11 --> Total execution time: 0.0645
INFO - 2022-06-28 13:30:12 --> Config Class Initialized
INFO - 2022-06-28 13:30:12 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:30:12 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:30:12 --> Utf8 Class Initialized
INFO - 2022-06-28 13:30:12 --> URI Class Initialized
INFO - 2022-06-28 13:30:12 --> Router Class Initialized
INFO - 2022-06-28 13:30:12 --> Output Class Initialized
INFO - 2022-06-28 13:30:12 --> Security Class Initialized
DEBUG - 2022-06-28 13:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:30:12 --> Input Class Initialized
INFO - 2022-06-28 13:30:12 --> Language Class Initialized
INFO - 2022-06-28 13:30:12 --> Loader Class Initialized
INFO - 2022-06-28 13:30:12 --> Helper loaded: url_helper
INFO - 2022-06-28 13:30:12 --> Helper loaded: file_helper
INFO - 2022-06-28 13:30:12 --> Database Driver Class Initialized
INFO - 2022-06-28 13:30:12 --> Email Class Initialized
DEBUG - 2022-06-28 13:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:30:12 --> Controller Class Initialized
INFO - 2022-06-28 13:30:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:30:12 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 13:30:12 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:30:12 --> Final output sent to browser
DEBUG - 2022-06-28 13:30:12 --> Total execution time: 0.1463
INFO - 2022-06-28 13:30:13 --> Config Class Initialized
INFO - 2022-06-28 13:30:13 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:30:13 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:30:13 --> Utf8 Class Initialized
INFO - 2022-06-28 13:30:13 --> URI Class Initialized
INFO - 2022-06-28 13:30:13 --> Router Class Initialized
INFO - 2022-06-28 13:30:13 --> Output Class Initialized
INFO - 2022-06-28 13:30:13 --> Security Class Initialized
DEBUG - 2022-06-28 13:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:30:13 --> Input Class Initialized
INFO - 2022-06-28 13:30:13 --> Language Class Initialized
INFO - 2022-06-28 13:30:13 --> Loader Class Initialized
INFO - 2022-06-28 13:30:13 --> Helper loaded: url_helper
INFO - 2022-06-28 13:30:13 --> Helper loaded: file_helper
INFO - 2022-06-28 13:30:13 --> Database Driver Class Initialized
INFO - 2022-06-28 13:30:13 --> Email Class Initialized
DEBUG - 2022-06-28 13:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:30:13 --> Controller Class Initialized
INFO - 2022-06-28 13:30:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:30:13 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 13:30:13 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:30:13 --> Final output sent to browser
DEBUG - 2022-06-28 13:30:13 --> Total execution time: 0.0315
INFO - 2022-06-28 13:30:15 --> Config Class Initialized
INFO - 2022-06-28 13:30:15 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:30:15 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:30:15 --> Utf8 Class Initialized
INFO - 2022-06-28 13:30:15 --> URI Class Initialized
INFO - 2022-06-28 13:30:15 --> Router Class Initialized
INFO - 2022-06-28 13:30:15 --> Output Class Initialized
INFO - 2022-06-28 13:30:15 --> Security Class Initialized
DEBUG - 2022-06-28 13:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:30:15 --> Input Class Initialized
INFO - 2022-06-28 13:30:15 --> Language Class Initialized
INFO - 2022-06-28 13:30:15 --> Loader Class Initialized
INFO - 2022-06-28 13:30:15 --> Helper loaded: url_helper
INFO - 2022-06-28 13:30:15 --> Helper loaded: file_helper
INFO - 2022-06-28 13:30:15 --> Database Driver Class Initialized
INFO - 2022-06-28 13:30:15 --> Email Class Initialized
DEBUG - 2022-06-28 13:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:30:15 --> Controller Class Initialized
INFO - 2022-06-28 13:30:15 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:30:15 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 13:30:15 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:30:15 --> Final output sent to browser
DEBUG - 2022-06-28 13:30:15 --> Total execution time: 0.1624
INFO - 2022-06-28 13:30:56 --> Config Class Initialized
INFO - 2022-06-28 13:30:56 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:30:56 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:30:56 --> Utf8 Class Initialized
INFO - 2022-06-28 13:30:56 --> URI Class Initialized
INFO - 2022-06-28 13:30:56 --> Router Class Initialized
INFO - 2022-06-28 13:30:56 --> Output Class Initialized
INFO - 2022-06-28 13:30:56 --> Security Class Initialized
DEBUG - 2022-06-28 13:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:30:56 --> Input Class Initialized
INFO - 2022-06-28 13:30:56 --> Language Class Initialized
INFO - 2022-06-28 13:30:56 --> Loader Class Initialized
INFO - 2022-06-28 13:30:56 --> Helper loaded: url_helper
INFO - 2022-06-28 13:30:56 --> Helper loaded: file_helper
INFO - 2022-06-28 13:30:56 --> Database Driver Class Initialized
INFO - 2022-06-28 13:30:56 --> Email Class Initialized
DEBUG - 2022-06-28 13:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:30:56 --> Controller Class Initialized
INFO - 2022-06-28 13:30:56 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:30:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:30:56 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:30:56 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:30:56 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:30:56 --> Final output sent to browser
DEBUG - 2022-06-28 13:30:56 --> Total execution time: 0.0753
INFO - 2022-06-28 13:32:14 --> Config Class Initialized
INFO - 2022-06-28 13:32:14 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:32:14 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:32:14 --> Utf8 Class Initialized
INFO - 2022-06-28 13:32:14 --> URI Class Initialized
INFO - 2022-06-28 13:32:14 --> Router Class Initialized
INFO - 2022-06-28 13:32:14 --> Output Class Initialized
INFO - 2022-06-28 13:32:14 --> Security Class Initialized
DEBUG - 2022-06-28 13:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:32:14 --> Input Class Initialized
INFO - 2022-06-28 13:32:14 --> Language Class Initialized
INFO - 2022-06-28 13:32:14 --> Loader Class Initialized
INFO - 2022-06-28 13:32:14 --> Helper loaded: url_helper
INFO - 2022-06-28 13:32:14 --> Helper loaded: file_helper
INFO - 2022-06-28 13:32:14 --> Database Driver Class Initialized
INFO - 2022-06-28 13:32:14 --> Email Class Initialized
DEBUG - 2022-06-28 13:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:32:14 --> Controller Class Initialized
INFO - 2022-06-28 13:32:14 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:32:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:32:14 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:32:14 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:32:14 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:32:14 --> Final output sent to browser
DEBUG - 2022-06-28 13:32:14 --> Total execution time: 0.1161
INFO - 2022-06-28 13:32:18 --> Config Class Initialized
INFO - 2022-06-28 13:32:18 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:32:18 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:32:18 --> Utf8 Class Initialized
INFO - 2022-06-28 13:32:18 --> URI Class Initialized
INFO - 2022-06-28 13:32:18 --> Router Class Initialized
INFO - 2022-06-28 13:32:18 --> Output Class Initialized
INFO - 2022-06-28 13:32:18 --> Security Class Initialized
DEBUG - 2022-06-28 13:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:32:18 --> Input Class Initialized
INFO - 2022-06-28 13:32:18 --> Language Class Initialized
INFO - 2022-06-28 13:32:18 --> Loader Class Initialized
INFO - 2022-06-28 13:32:18 --> Helper loaded: url_helper
INFO - 2022-06-28 13:32:18 --> Helper loaded: file_helper
INFO - 2022-06-28 13:32:18 --> Database Driver Class Initialized
INFO - 2022-06-28 13:32:18 --> Email Class Initialized
DEBUG - 2022-06-28 13:32:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:32:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:32:18 --> Controller Class Initialized
INFO - 2022-06-28 13:32:18 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:32:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:32:18 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:32:18 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:32:18 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:32:18 --> Final output sent to browser
DEBUG - 2022-06-28 13:32:18 --> Total execution time: 0.0723
INFO - 2022-06-28 13:32:46 --> Config Class Initialized
INFO - 2022-06-28 13:32:46 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:32:46 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:32:46 --> Utf8 Class Initialized
INFO - 2022-06-28 13:32:46 --> URI Class Initialized
INFO - 2022-06-28 13:32:46 --> Router Class Initialized
INFO - 2022-06-28 13:32:46 --> Output Class Initialized
INFO - 2022-06-28 13:32:46 --> Security Class Initialized
DEBUG - 2022-06-28 13:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:32:46 --> Input Class Initialized
INFO - 2022-06-28 13:32:46 --> Language Class Initialized
INFO - 2022-06-28 13:32:46 --> Loader Class Initialized
INFO - 2022-06-28 13:32:46 --> Helper loaded: url_helper
INFO - 2022-06-28 13:32:46 --> Helper loaded: file_helper
INFO - 2022-06-28 13:32:46 --> Database Driver Class Initialized
INFO - 2022-06-28 13:32:46 --> Email Class Initialized
DEBUG - 2022-06-28 13:32:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:32:46 --> Controller Class Initialized
INFO - 2022-06-28 13:32:46 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:32:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:32:46 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:32:46 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:32:46 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:32:46 --> Final output sent to browser
DEBUG - 2022-06-28 13:32:46 --> Total execution time: 0.0347
INFO - 2022-06-28 13:32:48 --> Config Class Initialized
INFO - 2022-06-28 13:32:48 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:32:48 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:32:48 --> Utf8 Class Initialized
INFO - 2022-06-28 13:32:48 --> URI Class Initialized
INFO - 2022-06-28 13:32:48 --> Router Class Initialized
INFO - 2022-06-28 13:32:48 --> Output Class Initialized
INFO - 2022-06-28 13:32:48 --> Security Class Initialized
DEBUG - 2022-06-28 13:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:32:48 --> Input Class Initialized
INFO - 2022-06-28 13:32:48 --> Language Class Initialized
INFO - 2022-06-28 13:32:48 --> Loader Class Initialized
INFO - 2022-06-28 13:32:48 --> Helper loaded: url_helper
INFO - 2022-06-28 13:32:48 --> Helper loaded: file_helper
INFO - 2022-06-28 13:32:48 --> Database Driver Class Initialized
INFO - 2022-06-28 13:32:48 --> Email Class Initialized
DEBUG - 2022-06-28 13:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:32:48 --> Controller Class Initialized
INFO - 2022-06-28 13:32:48 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:32:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:32:48 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:32:48 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:32:48 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:32:48 --> Final output sent to browser
DEBUG - 2022-06-28 13:32:48 --> Total execution time: 0.0291
INFO - 2022-06-28 13:32:48 --> Config Class Initialized
INFO - 2022-06-28 13:32:48 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:32:48 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:32:48 --> Utf8 Class Initialized
INFO - 2022-06-28 13:32:48 --> URI Class Initialized
INFO - 2022-06-28 13:32:48 --> Router Class Initialized
INFO - 2022-06-28 13:32:48 --> Output Class Initialized
INFO - 2022-06-28 13:32:48 --> Security Class Initialized
DEBUG - 2022-06-28 13:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:32:48 --> Input Class Initialized
INFO - 2022-06-28 13:32:48 --> Language Class Initialized
INFO - 2022-06-28 13:32:48 --> Loader Class Initialized
INFO - 2022-06-28 13:32:48 --> Helper loaded: url_helper
INFO - 2022-06-28 13:32:48 --> Helper loaded: file_helper
INFO - 2022-06-28 13:32:48 --> Database Driver Class Initialized
INFO - 2022-06-28 13:32:48 --> Email Class Initialized
DEBUG - 2022-06-28 13:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:32:48 --> Controller Class Initialized
INFO - 2022-06-28 13:32:48 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:32:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:32:48 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:32:48 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:32:48 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:32:48 --> Final output sent to browser
DEBUG - 2022-06-28 13:32:48 --> Total execution time: 0.0331
INFO - 2022-06-28 13:32:48 --> Config Class Initialized
INFO - 2022-06-28 13:32:48 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:32:48 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:32:48 --> Utf8 Class Initialized
INFO - 2022-06-28 13:32:48 --> URI Class Initialized
INFO - 2022-06-28 13:32:48 --> Router Class Initialized
INFO - 2022-06-28 13:32:48 --> Output Class Initialized
INFO - 2022-06-28 13:32:48 --> Security Class Initialized
DEBUG - 2022-06-28 13:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:32:48 --> Input Class Initialized
INFO - 2022-06-28 13:32:48 --> Language Class Initialized
INFO - 2022-06-28 13:32:48 --> Loader Class Initialized
INFO - 2022-06-28 13:32:48 --> Helper loaded: url_helper
INFO - 2022-06-28 13:32:48 --> Helper loaded: file_helper
INFO - 2022-06-28 13:32:48 --> Database Driver Class Initialized
INFO - 2022-06-28 13:32:48 --> Email Class Initialized
DEBUG - 2022-06-28 13:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:32:48 --> Controller Class Initialized
INFO - 2022-06-28 13:32:48 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:32:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:32:48 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:32:48 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:32:48 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:32:49 --> Final output sent to browser
DEBUG - 2022-06-28 13:32:49 --> Total execution time: 0.0240
INFO - 2022-06-28 13:32:49 --> Config Class Initialized
INFO - 2022-06-28 13:32:49 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:32:49 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:32:49 --> Utf8 Class Initialized
INFO - 2022-06-28 13:32:49 --> URI Class Initialized
INFO - 2022-06-28 13:32:49 --> Router Class Initialized
INFO - 2022-06-28 13:32:49 --> Output Class Initialized
INFO - 2022-06-28 13:32:49 --> Security Class Initialized
DEBUG - 2022-06-28 13:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:32:49 --> Input Class Initialized
INFO - 2022-06-28 13:32:49 --> Language Class Initialized
INFO - 2022-06-28 13:32:49 --> Loader Class Initialized
INFO - 2022-06-28 13:32:49 --> Helper loaded: url_helper
INFO - 2022-06-28 13:32:49 --> Helper loaded: file_helper
INFO - 2022-06-28 13:32:49 --> Database Driver Class Initialized
INFO - 2022-06-28 13:32:49 --> Email Class Initialized
DEBUG - 2022-06-28 13:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:32:49 --> Controller Class Initialized
INFO - 2022-06-28 13:32:49 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:32:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:32:49 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:32:49 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:32:49 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:32:49 --> Final output sent to browser
DEBUG - 2022-06-28 13:32:49 --> Total execution time: 0.0654
INFO - 2022-06-28 13:32:49 --> Config Class Initialized
INFO - 2022-06-28 13:32:49 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:32:49 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:32:49 --> Utf8 Class Initialized
INFO - 2022-06-28 13:32:49 --> URI Class Initialized
INFO - 2022-06-28 13:32:49 --> Router Class Initialized
INFO - 2022-06-28 13:32:49 --> Output Class Initialized
INFO - 2022-06-28 13:32:49 --> Security Class Initialized
DEBUG - 2022-06-28 13:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:32:49 --> Input Class Initialized
INFO - 2022-06-28 13:32:49 --> Language Class Initialized
INFO - 2022-06-28 13:32:49 --> Loader Class Initialized
INFO - 2022-06-28 13:32:49 --> Helper loaded: url_helper
INFO - 2022-06-28 13:32:49 --> Helper loaded: file_helper
INFO - 2022-06-28 13:32:49 --> Database Driver Class Initialized
INFO - 2022-06-28 13:32:49 --> Email Class Initialized
DEBUG - 2022-06-28 13:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:32:49 --> Controller Class Initialized
INFO - 2022-06-28 13:32:49 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:32:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:32:49 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:32:49 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:32:49 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:32:49 --> Final output sent to browser
DEBUG - 2022-06-28 13:32:49 --> Total execution time: 0.0723
INFO - 2022-06-28 13:32:49 --> Config Class Initialized
INFO - 2022-06-28 13:32:49 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:32:49 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:32:49 --> Utf8 Class Initialized
INFO - 2022-06-28 13:32:49 --> URI Class Initialized
INFO - 2022-06-28 13:32:49 --> Router Class Initialized
INFO - 2022-06-28 13:32:49 --> Output Class Initialized
INFO - 2022-06-28 13:32:49 --> Security Class Initialized
DEBUG - 2022-06-28 13:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:32:49 --> Input Class Initialized
INFO - 2022-06-28 13:32:49 --> Language Class Initialized
INFO - 2022-06-28 13:32:49 --> Loader Class Initialized
INFO - 2022-06-28 13:32:49 --> Helper loaded: url_helper
INFO - 2022-06-28 13:32:49 --> Helper loaded: file_helper
INFO - 2022-06-28 13:32:49 --> Database Driver Class Initialized
INFO - 2022-06-28 13:32:49 --> Email Class Initialized
DEBUG - 2022-06-28 13:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:32:49 --> Controller Class Initialized
INFO - 2022-06-28 13:32:49 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:32:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:32:49 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:32:49 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:32:49 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:32:49 --> Final output sent to browser
DEBUG - 2022-06-28 13:32:49 --> Total execution time: 0.0639
INFO - 2022-06-28 13:32:50 --> Config Class Initialized
INFO - 2022-06-28 13:32:50 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:32:50 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:32:50 --> Utf8 Class Initialized
INFO - 2022-06-28 13:32:50 --> URI Class Initialized
INFO - 2022-06-28 13:32:50 --> Router Class Initialized
INFO - 2022-06-28 13:32:50 --> Output Class Initialized
INFO - 2022-06-28 13:32:50 --> Security Class Initialized
DEBUG - 2022-06-28 13:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:32:50 --> Input Class Initialized
INFO - 2022-06-28 13:32:50 --> Language Class Initialized
INFO - 2022-06-28 13:32:50 --> Loader Class Initialized
INFO - 2022-06-28 13:32:50 --> Helper loaded: url_helper
INFO - 2022-06-28 13:32:50 --> Helper loaded: file_helper
INFO - 2022-06-28 13:32:50 --> Database Driver Class Initialized
INFO - 2022-06-28 13:32:50 --> Email Class Initialized
DEBUG - 2022-06-28 13:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:32:50 --> Controller Class Initialized
INFO - 2022-06-28 13:32:50 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:32:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:32:50 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:32:50 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:32:50 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:32:50 --> Final output sent to browser
DEBUG - 2022-06-28 13:32:50 --> Total execution time: 0.0312
INFO - 2022-06-28 13:32:50 --> Config Class Initialized
INFO - 2022-06-28 13:32:50 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:32:50 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:32:50 --> Utf8 Class Initialized
INFO - 2022-06-28 13:32:50 --> URI Class Initialized
INFO - 2022-06-28 13:32:50 --> Router Class Initialized
INFO - 2022-06-28 13:32:50 --> Output Class Initialized
INFO - 2022-06-28 13:32:50 --> Security Class Initialized
DEBUG - 2022-06-28 13:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:32:50 --> Input Class Initialized
INFO - 2022-06-28 13:32:50 --> Language Class Initialized
INFO - 2022-06-28 13:32:50 --> Loader Class Initialized
INFO - 2022-06-28 13:32:50 --> Helper loaded: url_helper
INFO - 2022-06-28 13:32:50 --> Helper loaded: file_helper
INFO - 2022-06-28 13:32:50 --> Database Driver Class Initialized
INFO - 2022-06-28 13:32:50 --> Email Class Initialized
DEBUG - 2022-06-28 13:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:32:50 --> Controller Class Initialized
INFO - 2022-06-28 13:32:50 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:32:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:32:50 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:32:50 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:32:50 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:32:50 --> Final output sent to browser
DEBUG - 2022-06-28 13:32:50 --> Total execution time: 0.0404
INFO - 2022-06-28 13:32:50 --> Config Class Initialized
INFO - 2022-06-28 13:32:50 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:32:50 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:32:50 --> Utf8 Class Initialized
INFO - 2022-06-28 13:32:50 --> URI Class Initialized
INFO - 2022-06-28 13:32:50 --> Router Class Initialized
INFO - 2022-06-28 13:32:50 --> Output Class Initialized
INFO - 2022-06-28 13:32:50 --> Security Class Initialized
DEBUG - 2022-06-28 13:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:32:50 --> Input Class Initialized
INFO - 2022-06-28 13:32:50 --> Language Class Initialized
INFO - 2022-06-28 13:32:50 --> Loader Class Initialized
INFO - 2022-06-28 13:32:50 --> Helper loaded: url_helper
INFO - 2022-06-28 13:32:50 --> Helper loaded: file_helper
INFO - 2022-06-28 13:32:50 --> Database Driver Class Initialized
INFO - 2022-06-28 13:32:50 --> Email Class Initialized
DEBUG - 2022-06-28 13:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:32:50 --> Controller Class Initialized
INFO - 2022-06-28 13:32:50 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:32:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:32:50 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:32:50 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:32:50 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:32:50 --> Final output sent to browser
DEBUG - 2022-06-28 13:32:50 --> Total execution time: 0.0402
INFO - 2022-06-28 13:32:50 --> Config Class Initialized
INFO - 2022-06-28 13:32:50 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:32:50 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:32:50 --> Utf8 Class Initialized
INFO - 2022-06-28 13:32:50 --> URI Class Initialized
INFO - 2022-06-28 13:32:50 --> Router Class Initialized
INFO - 2022-06-28 13:32:50 --> Output Class Initialized
INFO - 2022-06-28 13:32:50 --> Security Class Initialized
DEBUG - 2022-06-28 13:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:32:50 --> Input Class Initialized
INFO - 2022-06-28 13:32:50 --> Language Class Initialized
INFO - 2022-06-28 13:32:50 --> Loader Class Initialized
INFO - 2022-06-28 13:32:50 --> Helper loaded: url_helper
INFO - 2022-06-28 13:32:50 --> Helper loaded: file_helper
INFO - 2022-06-28 13:32:50 --> Database Driver Class Initialized
INFO - 2022-06-28 13:32:51 --> Email Class Initialized
DEBUG - 2022-06-28 13:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:32:51 --> Controller Class Initialized
INFO - 2022-06-28 13:32:51 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:32:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:32:51 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:32:51 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:32:51 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:32:51 --> Final output sent to browser
DEBUG - 2022-06-28 13:32:51 --> Total execution time: 0.0481
INFO - 2022-06-28 13:32:51 --> Config Class Initialized
INFO - 2022-06-28 13:32:51 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:32:51 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:32:51 --> Utf8 Class Initialized
INFO - 2022-06-28 13:32:51 --> URI Class Initialized
INFO - 2022-06-28 13:32:51 --> Router Class Initialized
INFO - 2022-06-28 13:32:51 --> Output Class Initialized
INFO - 2022-06-28 13:32:51 --> Security Class Initialized
DEBUG - 2022-06-28 13:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:32:51 --> Input Class Initialized
INFO - 2022-06-28 13:32:51 --> Language Class Initialized
INFO - 2022-06-28 13:32:51 --> Loader Class Initialized
INFO - 2022-06-28 13:32:51 --> Helper loaded: url_helper
INFO - 2022-06-28 13:32:51 --> Helper loaded: file_helper
INFO - 2022-06-28 13:32:51 --> Database Driver Class Initialized
INFO - 2022-06-28 13:32:51 --> Email Class Initialized
DEBUG - 2022-06-28 13:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:32:51 --> Controller Class Initialized
INFO - 2022-06-28 13:32:51 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:32:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:32:51 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:32:51 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:32:51 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:32:51 --> Final output sent to browser
DEBUG - 2022-06-28 13:32:51 --> Total execution time: 0.0332
INFO - 2022-06-28 13:34:10 --> Config Class Initialized
INFO - 2022-06-28 13:34:10 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:34:10 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:34:10 --> Utf8 Class Initialized
INFO - 2022-06-28 13:34:10 --> URI Class Initialized
INFO - 2022-06-28 13:34:10 --> Router Class Initialized
INFO - 2022-06-28 13:34:10 --> Output Class Initialized
INFO - 2022-06-28 13:34:10 --> Security Class Initialized
DEBUG - 2022-06-28 13:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:34:10 --> Input Class Initialized
INFO - 2022-06-28 13:34:10 --> Language Class Initialized
INFO - 2022-06-28 13:34:10 --> Loader Class Initialized
INFO - 2022-06-28 13:34:10 --> Helper loaded: url_helper
INFO - 2022-06-28 13:34:10 --> Helper loaded: file_helper
INFO - 2022-06-28 13:34:10 --> Database Driver Class Initialized
INFO - 2022-06-28 13:34:10 --> Email Class Initialized
DEBUG - 2022-06-28 13:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:34:10 --> Controller Class Initialized
INFO - 2022-06-28 13:34:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:34:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:34:10 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:34:10 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:34:10 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:34:10 --> Final output sent to browser
DEBUG - 2022-06-28 13:34:10 --> Total execution time: 0.0285
INFO - 2022-06-28 13:34:10 --> Config Class Initialized
INFO - 2022-06-28 13:34:10 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:34:10 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:34:10 --> Utf8 Class Initialized
INFO - 2022-06-28 13:34:10 --> URI Class Initialized
INFO - 2022-06-28 13:34:10 --> Router Class Initialized
INFO - 2022-06-28 13:34:10 --> Output Class Initialized
INFO - 2022-06-28 13:34:10 --> Security Class Initialized
DEBUG - 2022-06-28 13:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:34:10 --> Input Class Initialized
INFO - 2022-06-28 13:34:10 --> Language Class Initialized
INFO - 2022-06-28 13:34:10 --> Loader Class Initialized
INFO - 2022-06-28 13:34:10 --> Helper loaded: url_helper
INFO - 2022-06-28 13:34:10 --> Helper loaded: file_helper
INFO - 2022-06-28 13:34:10 --> Database Driver Class Initialized
INFO - 2022-06-28 13:34:10 --> Email Class Initialized
DEBUG - 2022-06-28 13:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:34:10 --> Controller Class Initialized
INFO - 2022-06-28 13:34:10 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:34:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:34:10 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:34:10 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:34:10 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:34:10 --> Final output sent to browser
DEBUG - 2022-06-28 13:34:10 --> Total execution time: 0.0346
INFO - 2022-06-28 13:34:11 --> Config Class Initialized
INFO - 2022-06-28 13:34:11 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:34:11 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:34:11 --> Utf8 Class Initialized
INFO - 2022-06-28 13:34:11 --> URI Class Initialized
INFO - 2022-06-28 13:34:11 --> Router Class Initialized
INFO - 2022-06-28 13:34:11 --> Output Class Initialized
INFO - 2022-06-28 13:34:11 --> Security Class Initialized
DEBUG - 2022-06-28 13:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:34:11 --> Input Class Initialized
INFO - 2022-06-28 13:34:11 --> Language Class Initialized
INFO - 2022-06-28 13:34:11 --> Loader Class Initialized
INFO - 2022-06-28 13:34:11 --> Helper loaded: url_helper
INFO - 2022-06-28 13:34:11 --> Helper loaded: file_helper
INFO - 2022-06-28 13:34:11 --> Database Driver Class Initialized
INFO - 2022-06-28 13:34:11 --> Email Class Initialized
DEBUG - 2022-06-28 13:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:34:11 --> Controller Class Initialized
INFO - 2022-06-28 13:34:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:34:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:34:11 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:34:11 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:34:11 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:34:11 --> Final output sent to browser
DEBUG - 2022-06-28 13:34:11 --> Total execution time: 0.0372
INFO - 2022-06-28 13:34:11 --> Config Class Initialized
INFO - 2022-06-28 13:34:11 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:34:11 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:34:11 --> Utf8 Class Initialized
INFO - 2022-06-28 13:34:11 --> URI Class Initialized
INFO - 2022-06-28 13:34:11 --> Router Class Initialized
INFO - 2022-06-28 13:34:11 --> Output Class Initialized
INFO - 2022-06-28 13:34:11 --> Security Class Initialized
DEBUG - 2022-06-28 13:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:34:11 --> Input Class Initialized
INFO - 2022-06-28 13:34:11 --> Language Class Initialized
INFO - 2022-06-28 13:34:11 --> Loader Class Initialized
INFO - 2022-06-28 13:34:11 --> Helper loaded: url_helper
INFO - 2022-06-28 13:34:11 --> Helper loaded: file_helper
INFO - 2022-06-28 13:34:11 --> Database Driver Class Initialized
INFO - 2022-06-28 13:34:11 --> Email Class Initialized
DEBUG - 2022-06-28 13:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:34:11 --> Controller Class Initialized
INFO - 2022-06-28 13:34:11 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:34:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:34:11 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:34:11 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:34:11 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:34:11 --> Final output sent to browser
DEBUG - 2022-06-28 13:34:11 --> Total execution time: 0.0280
INFO - 2022-06-28 13:34:11 --> Config Class Initialized
INFO - 2022-06-28 13:34:11 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:34:11 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:34:11 --> Utf8 Class Initialized
INFO - 2022-06-28 13:34:11 --> URI Class Initialized
INFO - 2022-06-28 13:34:11 --> Router Class Initialized
INFO - 2022-06-28 13:34:11 --> Output Class Initialized
INFO - 2022-06-28 13:34:11 --> Security Class Initialized
DEBUG - 2022-06-28 13:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:34:11 --> Input Class Initialized
INFO - 2022-06-28 13:34:11 --> Language Class Initialized
INFO - 2022-06-28 13:34:12 --> Loader Class Initialized
INFO - 2022-06-28 13:34:12 --> Helper loaded: url_helper
INFO - 2022-06-28 13:34:12 --> Helper loaded: file_helper
INFO - 2022-06-28 13:34:12 --> Database Driver Class Initialized
INFO - 2022-06-28 13:34:12 --> Email Class Initialized
DEBUG - 2022-06-28 13:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:34:12 --> Controller Class Initialized
INFO - 2022-06-28 13:34:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:34:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:34:12 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:34:12 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:34:12 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:34:12 --> Final output sent to browser
DEBUG - 2022-06-28 13:34:12 --> Total execution time: 0.0298
INFO - 2022-06-28 13:34:12 --> Config Class Initialized
INFO - 2022-06-28 13:34:12 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:34:12 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:34:12 --> Utf8 Class Initialized
INFO - 2022-06-28 13:34:12 --> URI Class Initialized
INFO - 2022-06-28 13:34:12 --> Router Class Initialized
INFO - 2022-06-28 13:34:12 --> Output Class Initialized
INFO - 2022-06-28 13:34:12 --> Security Class Initialized
DEBUG - 2022-06-28 13:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:34:12 --> Input Class Initialized
INFO - 2022-06-28 13:34:12 --> Language Class Initialized
INFO - 2022-06-28 13:34:12 --> Loader Class Initialized
INFO - 2022-06-28 13:34:12 --> Helper loaded: url_helper
INFO - 2022-06-28 13:34:12 --> Helper loaded: file_helper
INFO - 2022-06-28 13:34:12 --> Database Driver Class Initialized
INFO - 2022-06-28 13:34:12 --> Email Class Initialized
DEBUG - 2022-06-28 13:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:34:12 --> Controller Class Initialized
INFO - 2022-06-28 13:34:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:34:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:34:12 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:34:12 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:34:12 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:34:12 --> Final output sent to browser
DEBUG - 2022-06-28 13:34:12 --> Total execution time: 0.0588
INFO - 2022-06-28 13:34:12 --> Config Class Initialized
INFO - 2022-06-28 13:34:12 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:34:12 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:34:12 --> Utf8 Class Initialized
INFO - 2022-06-28 13:34:12 --> URI Class Initialized
INFO - 2022-06-28 13:34:12 --> Router Class Initialized
INFO - 2022-06-28 13:34:12 --> Output Class Initialized
INFO - 2022-06-28 13:34:12 --> Security Class Initialized
DEBUG - 2022-06-28 13:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:34:12 --> Input Class Initialized
INFO - 2022-06-28 13:34:12 --> Language Class Initialized
INFO - 2022-06-28 13:34:12 --> Loader Class Initialized
INFO - 2022-06-28 13:34:12 --> Helper loaded: url_helper
INFO - 2022-06-28 13:34:12 --> Helper loaded: file_helper
INFO - 2022-06-28 13:34:12 --> Database Driver Class Initialized
INFO - 2022-06-28 13:34:12 --> Email Class Initialized
DEBUG - 2022-06-28 13:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:34:12 --> Controller Class Initialized
INFO - 2022-06-28 13:34:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:34:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:34:12 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:34:12 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:34:12 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:34:12 --> Final output sent to browser
DEBUG - 2022-06-28 13:34:12 --> Total execution time: 0.0346
INFO - 2022-06-28 13:34:12 --> Config Class Initialized
INFO - 2022-06-28 13:34:12 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:34:12 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:34:12 --> Utf8 Class Initialized
INFO - 2022-06-28 13:34:12 --> URI Class Initialized
INFO - 2022-06-28 13:34:12 --> Router Class Initialized
INFO - 2022-06-28 13:34:12 --> Output Class Initialized
INFO - 2022-06-28 13:34:12 --> Security Class Initialized
DEBUG - 2022-06-28 13:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:34:12 --> Input Class Initialized
INFO - 2022-06-28 13:34:12 --> Language Class Initialized
INFO - 2022-06-28 13:34:12 --> Loader Class Initialized
INFO - 2022-06-28 13:34:12 --> Helper loaded: url_helper
INFO - 2022-06-28 13:34:12 --> Helper loaded: file_helper
INFO - 2022-06-28 13:34:12 --> Database Driver Class Initialized
INFO - 2022-06-28 13:34:12 --> Email Class Initialized
DEBUG - 2022-06-28 13:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:34:12 --> Controller Class Initialized
INFO - 2022-06-28 13:34:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:34:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:34:12 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:34:12 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:34:12 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:34:12 --> Final output sent to browser
DEBUG - 2022-06-28 13:34:12 --> Total execution time: 0.0533
INFO - 2022-06-28 13:34:12 --> Config Class Initialized
INFO - 2022-06-28 13:34:12 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:34:12 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:34:12 --> Utf8 Class Initialized
INFO - 2022-06-28 13:34:12 --> URI Class Initialized
INFO - 2022-06-28 13:34:12 --> Router Class Initialized
INFO - 2022-06-28 13:34:12 --> Output Class Initialized
INFO - 2022-06-28 13:34:12 --> Security Class Initialized
DEBUG - 2022-06-28 13:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:34:12 --> Input Class Initialized
INFO - 2022-06-28 13:34:12 --> Language Class Initialized
INFO - 2022-06-28 13:34:12 --> Loader Class Initialized
INFO - 2022-06-28 13:34:12 --> Helper loaded: url_helper
INFO - 2022-06-28 13:34:12 --> Helper loaded: file_helper
INFO - 2022-06-28 13:34:12 --> Database Driver Class Initialized
INFO - 2022-06-28 13:34:12 --> Email Class Initialized
DEBUG - 2022-06-28 13:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:34:12 --> Controller Class Initialized
INFO - 2022-06-28 13:34:12 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:34:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:34:12 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:34:12 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:34:12 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:34:12 --> Final output sent to browser
DEBUG - 2022-06-28 13:34:12 --> Total execution time: 0.0681
INFO - 2022-06-28 13:34:12 --> Config Class Initialized
INFO - 2022-06-28 13:34:12 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:34:12 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:34:12 --> Utf8 Class Initialized
INFO - 2022-06-28 13:34:12 --> URI Class Initialized
INFO - 2022-06-28 13:34:12 --> Router Class Initialized
INFO - 2022-06-28 13:34:12 --> Output Class Initialized
INFO - 2022-06-28 13:34:12 --> Security Class Initialized
DEBUG - 2022-06-28 13:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:34:12 --> Input Class Initialized
INFO - 2022-06-28 13:34:12 --> Language Class Initialized
INFO - 2022-06-28 13:34:12 --> Loader Class Initialized
INFO - 2022-06-28 13:34:12 --> Helper loaded: url_helper
INFO - 2022-06-28 13:34:12 --> Helper loaded: file_helper
INFO - 2022-06-28 13:34:12 --> Database Driver Class Initialized
INFO - 2022-06-28 13:34:13 --> Email Class Initialized
DEBUG - 2022-06-28 13:34:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:34:13 --> Controller Class Initialized
INFO - 2022-06-28 13:34:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:34:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:34:13 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:34:13 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:34:13 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:34:13 --> Final output sent to browser
DEBUG - 2022-06-28 13:34:13 --> Total execution time: 0.0924
INFO - 2022-06-28 13:34:13 --> Config Class Initialized
INFO - 2022-06-28 13:34:13 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:34:13 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:34:13 --> Utf8 Class Initialized
INFO - 2022-06-28 13:34:13 --> URI Class Initialized
INFO - 2022-06-28 13:34:13 --> Router Class Initialized
INFO - 2022-06-28 13:34:13 --> Output Class Initialized
INFO - 2022-06-28 13:34:13 --> Security Class Initialized
DEBUG - 2022-06-28 13:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:34:13 --> Input Class Initialized
INFO - 2022-06-28 13:34:13 --> Language Class Initialized
INFO - 2022-06-28 13:34:13 --> Loader Class Initialized
INFO - 2022-06-28 13:34:13 --> Helper loaded: url_helper
INFO - 2022-06-28 13:34:13 --> Helper loaded: file_helper
INFO - 2022-06-28 13:34:13 --> Database Driver Class Initialized
INFO - 2022-06-28 13:34:13 --> Email Class Initialized
DEBUG - 2022-06-28 13:34:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:34:13 --> Controller Class Initialized
INFO - 2022-06-28 13:34:13 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:34:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:34:13 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
ERROR - 2022-06-28 13:34:13 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 358
INFO - 2022-06-28 13:34:13 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:34:13 --> Final output sent to browser
DEBUG - 2022-06-28 13:34:13 --> Total execution time: 0.0252
INFO - 2022-06-28 13:35:35 --> Config Class Initialized
INFO - 2022-06-28 13:35:35 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:35:35 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:35:35 --> Utf8 Class Initialized
INFO - 2022-06-28 13:35:35 --> URI Class Initialized
INFO - 2022-06-28 13:35:35 --> Router Class Initialized
INFO - 2022-06-28 13:35:35 --> Output Class Initialized
INFO - 2022-06-28 13:35:35 --> Security Class Initialized
DEBUG - 2022-06-28 13:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:35:35 --> Input Class Initialized
INFO - 2022-06-28 13:35:35 --> Language Class Initialized
INFO - 2022-06-28 13:35:35 --> Loader Class Initialized
INFO - 2022-06-28 13:35:35 --> Helper loaded: url_helper
INFO - 2022-06-28 13:35:35 --> Helper loaded: file_helper
INFO - 2022-06-28 13:35:35 --> Database Driver Class Initialized
INFO - 2022-06-28 13:35:35 --> Email Class Initialized
DEBUG - 2022-06-28 13:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:35:35 --> Controller Class Initialized
INFO - 2022-06-28 13:35:35 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:35:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:35:35 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
INFO - 2022-06-28 13:35:35 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:35:35 --> Final output sent to browser
DEBUG - 2022-06-28 13:35:35 --> Total execution time: 0.0783
INFO - 2022-06-28 13:35:40 --> Config Class Initialized
INFO - 2022-06-28 13:35:40 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:35:40 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:35:40 --> Utf8 Class Initialized
INFO - 2022-06-28 13:35:40 --> URI Class Initialized
INFO - 2022-06-28 13:35:40 --> Router Class Initialized
INFO - 2022-06-28 13:35:40 --> Output Class Initialized
INFO - 2022-06-28 13:35:40 --> Security Class Initialized
DEBUG - 2022-06-28 13:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:35:40 --> Input Class Initialized
INFO - 2022-06-28 13:35:40 --> Language Class Initialized
INFO - 2022-06-28 13:35:40 --> Loader Class Initialized
INFO - 2022-06-28 13:35:40 --> Helper loaded: url_helper
INFO - 2022-06-28 13:35:40 --> Helper loaded: file_helper
INFO - 2022-06-28 13:35:40 --> Database Driver Class Initialized
INFO - 2022-06-28 13:35:40 --> Email Class Initialized
DEBUG - 2022-06-28 13:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:35:40 --> Controller Class Initialized
INFO - 2022-06-28 13:35:40 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:35:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:35:40 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
INFO - 2022-06-28 13:35:40 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:35:40 --> Final output sent to browser
DEBUG - 2022-06-28 13:35:40 --> Total execution time: 0.0674
INFO - 2022-06-28 13:35:59 --> Config Class Initialized
INFO - 2022-06-28 13:35:59 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:35:59 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:35:59 --> Utf8 Class Initialized
INFO - 2022-06-28 13:35:59 --> URI Class Initialized
INFO - 2022-06-28 13:35:59 --> Router Class Initialized
INFO - 2022-06-28 13:35:59 --> Output Class Initialized
INFO - 2022-06-28 13:35:59 --> Security Class Initialized
DEBUG - 2022-06-28 13:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:35:59 --> Input Class Initialized
INFO - 2022-06-28 13:35:59 --> Language Class Initialized
INFO - 2022-06-28 13:35:59 --> Loader Class Initialized
INFO - 2022-06-28 13:35:59 --> Helper loaded: url_helper
INFO - 2022-06-28 13:35:59 --> Helper loaded: file_helper
INFO - 2022-06-28 13:35:59 --> Database Driver Class Initialized
INFO - 2022-06-28 13:35:59 --> Email Class Initialized
DEBUG - 2022-06-28 13:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:35:59 --> Controller Class Initialized
INFO - 2022-06-28 13:35:59 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:35:59 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 13:35:59 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 13:35:59 --> Final output sent to browser
DEBUG - 2022-06-28 13:35:59 --> Total execution time: 0.1264
INFO - 2022-06-28 13:36:01 --> Config Class Initialized
INFO - 2022-06-28 13:36:01 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:36:01 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:36:01 --> Utf8 Class Initialized
INFO - 2022-06-28 13:36:01 --> URI Class Initialized
INFO - 2022-06-28 13:36:01 --> Router Class Initialized
INFO - 2022-06-28 13:36:01 --> Output Class Initialized
INFO - 2022-06-28 13:36:01 --> Security Class Initialized
DEBUG - 2022-06-28 13:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:36:01 --> Input Class Initialized
INFO - 2022-06-28 13:36:01 --> Language Class Initialized
INFO - 2022-06-28 13:36:01 --> Loader Class Initialized
INFO - 2022-06-28 13:36:01 --> Helper loaded: url_helper
INFO - 2022-06-28 13:36:01 --> Helper loaded: file_helper
INFO - 2022-06-28 13:36:01 --> Database Driver Class Initialized
INFO - 2022-06-28 13:36:01 --> Email Class Initialized
DEBUG - 2022-06-28 13:36:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:36:01 --> Controller Class Initialized
INFO - 2022-06-28 13:36:01 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:36:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:36:01 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
INFO - 2022-06-28 13:36:01 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:36:01 --> Final output sent to browser
DEBUG - 2022-06-28 13:36:01 --> Total execution time: 0.0303
INFO - 2022-06-28 13:36:58 --> Config Class Initialized
INFO - 2022-06-28 13:36:58 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:36:58 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:36:58 --> Utf8 Class Initialized
INFO - 2022-06-28 13:36:58 --> URI Class Initialized
INFO - 2022-06-28 13:36:58 --> Router Class Initialized
INFO - 2022-06-28 13:36:58 --> Output Class Initialized
INFO - 2022-06-28 13:36:58 --> Security Class Initialized
DEBUG - 2022-06-28 13:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:36:58 --> Input Class Initialized
INFO - 2022-06-28 13:36:58 --> Language Class Initialized
INFO - 2022-06-28 13:36:58 --> Loader Class Initialized
INFO - 2022-06-28 13:36:58 --> Helper loaded: url_helper
INFO - 2022-06-28 13:36:58 --> Helper loaded: file_helper
INFO - 2022-06-28 13:36:58 --> Database Driver Class Initialized
INFO - 2022-06-28 13:36:58 --> Email Class Initialized
DEBUG - 2022-06-28 13:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:36:58 --> Controller Class Initialized
INFO - 2022-06-28 13:36:58 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:36:58 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 13:36:58 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 13:36:58 --> Final output sent to browser
DEBUG - 2022-06-28 13:36:58 --> Total execution time: 0.0527
INFO - 2022-06-28 13:39:26 --> Config Class Initialized
INFO - 2022-06-28 13:39:26 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:39:26 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:39:26 --> Utf8 Class Initialized
INFO - 2022-06-28 13:39:26 --> URI Class Initialized
INFO - 2022-06-28 13:39:26 --> Router Class Initialized
INFO - 2022-06-28 13:39:26 --> Output Class Initialized
INFO - 2022-06-28 13:39:26 --> Security Class Initialized
DEBUG - 2022-06-28 13:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:39:26 --> Input Class Initialized
INFO - 2022-06-28 13:39:26 --> Language Class Initialized
INFO - 2022-06-28 13:39:26 --> Loader Class Initialized
INFO - 2022-06-28 13:39:26 --> Helper loaded: url_helper
INFO - 2022-06-28 13:39:26 --> Helper loaded: file_helper
INFO - 2022-06-28 13:39:26 --> Database Driver Class Initialized
INFO - 2022-06-28 13:39:26 --> Email Class Initialized
DEBUG - 2022-06-28 13:39:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:39:26 --> Controller Class Initialized
INFO - 2022-06-28 13:39:26 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:39:26 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 13:39:26 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:39:26 --> Final output sent to browser
DEBUG - 2022-06-28 13:39:26 --> Total execution time: 0.0706
INFO - 2022-06-28 13:39:31 --> Config Class Initialized
INFO - 2022-06-28 13:39:31 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:39:31 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:39:31 --> Utf8 Class Initialized
INFO - 2022-06-28 13:39:31 --> URI Class Initialized
INFO - 2022-06-28 13:39:31 --> Router Class Initialized
INFO - 2022-06-28 13:39:31 --> Output Class Initialized
INFO - 2022-06-28 13:39:31 --> Security Class Initialized
DEBUG - 2022-06-28 13:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:39:31 --> Input Class Initialized
INFO - 2022-06-28 13:39:31 --> Language Class Initialized
INFO - 2022-06-28 13:39:31 --> Loader Class Initialized
INFO - 2022-06-28 13:39:31 --> Helper loaded: url_helper
INFO - 2022-06-28 13:39:31 --> Helper loaded: file_helper
INFO - 2022-06-28 13:39:31 --> Database Driver Class Initialized
INFO - 2022-06-28 13:39:31 --> Email Class Initialized
DEBUG - 2022-06-28 13:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:39:31 --> Controller Class Initialized
INFO - 2022-06-28 13:39:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:39:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 13:39:31 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:39:31 --> Final output sent to browser
DEBUG - 2022-06-28 13:39:31 --> Total execution time: 0.0317
INFO - 2022-06-28 13:39:32 --> Config Class Initialized
INFO - 2022-06-28 13:39:32 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:39:32 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:39:32 --> Utf8 Class Initialized
INFO - 2022-06-28 13:39:32 --> URI Class Initialized
INFO - 2022-06-28 13:39:32 --> Router Class Initialized
INFO - 2022-06-28 13:39:32 --> Output Class Initialized
INFO - 2022-06-28 13:39:32 --> Security Class Initialized
DEBUG - 2022-06-28 13:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:39:32 --> Input Class Initialized
INFO - 2022-06-28 13:39:32 --> Language Class Initialized
INFO - 2022-06-28 13:39:32 --> Loader Class Initialized
INFO - 2022-06-28 13:39:32 --> Helper loaded: url_helper
INFO - 2022-06-28 13:39:32 --> Helper loaded: file_helper
INFO - 2022-06-28 13:39:32 --> Database Driver Class Initialized
INFO - 2022-06-28 13:39:32 --> Email Class Initialized
DEBUG - 2022-06-28 13:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:39:32 --> Controller Class Initialized
INFO - 2022-06-28 13:39:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:39:32 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 13:39:32 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:39:32 --> Final output sent to browser
DEBUG - 2022-06-28 13:39:32 --> Total execution time: 0.0718
INFO - 2022-06-28 13:39:32 --> Config Class Initialized
INFO - 2022-06-28 13:39:32 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:39:32 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:39:32 --> Utf8 Class Initialized
INFO - 2022-06-28 13:39:32 --> URI Class Initialized
INFO - 2022-06-28 13:39:32 --> Router Class Initialized
INFO - 2022-06-28 13:39:32 --> Output Class Initialized
INFO - 2022-06-28 13:39:33 --> Security Class Initialized
DEBUG - 2022-06-28 13:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:39:33 --> Input Class Initialized
INFO - 2022-06-28 13:39:33 --> Language Class Initialized
INFO - 2022-06-28 13:39:33 --> Loader Class Initialized
INFO - 2022-06-28 13:39:33 --> Helper loaded: url_helper
INFO - 2022-06-28 13:39:33 --> Helper loaded: file_helper
INFO - 2022-06-28 13:39:33 --> Database Driver Class Initialized
INFO - 2022-06-28 13:39:33 --> Email Class Initialized
DEBUG - 2022-06-28 13:39:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:39:33 --> Controller Class Initialized
INFO - 2022-06-28 13:39:33 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:39:33 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 13:39:33 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:39:33 --> Final output sent to browser
DEBUG - 2022-06-28 13:39:33 --> Total execution time: 0.1324
INFO - 2022-06-28 13:39:33 --> Config Class Initialized
INFO - 2022-06-28 13:39:33 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:39:33 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:39:33 --> Utf8 Class Initialized
INFO - 2022-06-28 13:39:33 --> URI Class Initialized
INFO - 2022-06-28 13:39:33 --> Router Class Initialized
INFO - 2022-06-28 13:39:33 --> Output Class Initialized
INFO - 2022-06-28 13:39:33 --> Security Class Initialized
DEBUG - 2022-06-28 13:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:39:33 --> Input Class Initialized
INFO - 2022-06-28 13:39:33 --> Language Class Initialized
INFO - 2022-06-28 13:39:33 --> Loader Class Initialized
INFO - 2022-06-28 13:39:33 --> Helper loaded: url_helper
INFO - 2022-06-28 13:39:33 --> Helper loaded: file_helper
INFO - 2022-06-28 13:39:33 --> Database Driver Class Initialized
INFO - 2022-06-28 13:39:33 --> Email Class Initialized
DEBUG - 2022-06-28 13:39:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:39:33 --> Controller Class Initialized
INFO - 2022-06-28 13:39:33 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:39:33 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 13:39:33 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:39:33 --> Final output sent to browser
DEBUG - 2022-06-28 13:39:33 --> Total execution time: 0.1494
INFO - 2022-06-28 13:39:34 --> Config Class Initialized
INFO - 2022-06-28 13:39:34 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:39:34 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:39:34 --> Utf8 Class Initialized
INFO - 2022-06-28 13:39:34 --> URI Class Initialized
INFO - 2022-06-28 13:39:34 --> Router Class Initialized
INFO - 2022-06-28 13:39:34 --> Output Class Initialized
INFO - 2022-06-28 13:39:34 --> Security Class Initialized
DEBUG - 2022-06-28 13:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:39:34 --> Input Class Initialized
INFO - 2022-06-28 13:39:34 --> Language Class Initialized
INFO - 2022-06-28 13:39:34 --> Loader Class Initialized
INFO - 2022-06-28 13:39:34 --> Helper loaded: url_helper
INFO - 2022-06-28 13:39:34 --> Helper loaded: file_helper
INFO - 2022-06-28 13:39:34 --> Database Driver Class Initialized
INFO - 2022-06-28 13:39:34 --> Email Class Initialized
DEBUG - 2022-06-28 13:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:39:34 --> Controller Class Initialized
INFO - 2022-06-28 13:39:34 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:39:34 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 13:39:34 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:39:34 --> Final output sent to browser
DEBUG - 2022-06-28 13:39:34 --> Total execution time: 0.1407
INFO - 2022-06-28 13:39:35 --> Config Class Initialized
INFO - 2022-06-28 13:39:35 --> Hooks Class Initialized
DEBUG - 2022-06-28 13:39:35 --> UTF-8 Support Enabled
INFO - 2022-06-28 13:39:35 --> Utf8 Class Initialized
INFO - 2022-06-28 13:39:35 --> URI Class Initialized
INFO - 2022-06-28 13:39:35 --> Router Class Initialized
INFO - 2022-06-28 13:39:35 --> Output Class Initialized
INFO - 2022-06-28 13:39:35 --> Security Class Initialized
DEBUG - 2022-06-28 13:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 13:39:35 --> Input Class Initialized
INFO - 2022-06-28 13:39:35 --> Language Class Initialized
INFO - 2022-06-28 13:39:35 --> Loader Class Initialized
INFO - 2022-06-28 13:39:35 --> Helper loaded: url_helper
INFO - 2022-06-28 13:39:35 --> Helper loaded: file_helper
INFO - 2022-06-28 13:39:35 --> Database Driver Class Initialized
INFO - 2022-06-28 13:39:35 --> Email Class Initialized
DEBUG - 2022-06-28 13:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 13:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 13:39:35 --> Controller Class Initialized
INFO - 2022-06-28 13:39:35 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 13:39:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 13:39:35 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
INFO - 2022-06-28 13:39:35 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 13:39:35 --> Final output sent to browser
DEBUG - 2022-06-28 13:39:35 --> Total execution time: 0.1369
INFO - 2022-06-28 14:51:32 --> Config Class Initialized
INFO - 2022-06-28 14:51:33 --> Hooks Class Initialized
DEBUG - 2022-06-28 14:51:33 --> UTF-8 Support Enabled
INFO - 2022-06-28 14:51:33 --> Utf8 Class Initialized
INFO - 2022-06-28 14:51:33 --> URI Class Initialized
INFO - 2022-06-28 14:51:33 --> Router Class Initialized
INFO - 2022-06-28 14:51:33 --> Output Class Initialized
INFO - 2022-06-28 14:51:33 --> Security Class Initialized
DEBUG - 2022-06-28 14:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 14:51:33 --> Input Class Initialized
INFO - 2022-06-28 14:51:33 --> Language Class Initialized
INFO - 2022-06-28 14:51:33 --> Loader Class Initialized
INFO - 2022-06-28 14:51:33 --> Helper loaded: url_helper
INFO - 2022-06-28 14:51:33 --> Helper loaded: file_helper
INFO - 2022-06-28 14:51:33 --> Database Driver Class Initialized
INFO - 2022-06-28 14:51:33 --> Email Class Initialized
DEBUG - 2022-06-28 14:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 14:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 14:51:33 --> Controller Class Initialized
INFO - 2022-06-28 14:51:33 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 14:51:33 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 14:51:33 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 14:51:33 --> Final output sent to browser
DEBUG - 2022-06-28 14:51:33 --> Total execution time: 0.5383
INFO - 2022-06-28 14:54:30 --> Config Class Initialized
INFO - 2022-06-28 14:54:30 --> Hooks Class Initialized
DEBUG - 2022-06-28 14:54:30 --> UTF-8 Support Enabled
INFO - 2022-06-28 14:54:30 --> Utf8 Class Initialized
INFO - 2022-06-28 14:54:30 --> URI Class Initialized
INFO - 2022-06-28 14:54:30 --> Router Class Initialized
INFO - 2022-06-28 14:54:30 --> Output Class Initialized
INFO - 2022-06-28 14:54:30 --> Security Class Initialized
DEBUG - 2022-06-28 14:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 14:54:30 --> Input Class Initialized
INFO - 2022-06-28 14:54:30 --> Language Class Initialized
INFO - 2022-06-28 14:54:30 --> Loader Class Initialized
INFO - 2022-06-28 14:54:30 --> Helper loaded: url_helper
INFO - 2022-06-28 14:54:30 --> Helper loaded: file_helper
INFO - 2022-06-28 14:54:30 --> Database Driver Class Initialized
INFO - 2022-06-28 14:54:30 --> Email Class Initialized
DEBUG - 2022-06-28 14:54:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 14:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 14:54:30 --> Controller Class Initialized
INFO - 2022-06-28 14:54:30 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 14:54:30 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 14:54:30 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 14:54:30 --> Final output sent to browser
DEBUG - 2022-06-28 14:54:30 --> Total execution time: 0.0414
INFO - 2022-06-28 14:54:33 --> Config Class Initialized
INFO - 2022-06-28 14:54:33 --> Hooks Class Initialized
DEBUG - 2022-06-28 14:54:33 --> UTF-8 Support Enabled
INFO - 2022-06-28 14:54:33 --> Utf8 Class Initialized
INFO - 2022-06-28 14:54:33 --> URI Class Initialized
INFO - 2022-06-28 14:54:33 --> Router Class Initialized
INFO - 2022-06-28 14:54:33 --> Output Class Initialized
INFO - 2022-06-28 14:54:33 --> Security Class Initialized
DEBUG - 2022-06-28 14:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 14:54:33 --> Input Class Initialized
INFO - 2022-06-28 14:54:33 --> Language Class Initialized
INFO - 2022-06-28 14:54:33 --> Loader Class Initialized
INFO - 2022-06-28 14:54:33 --> Helper loaded: url_helper
INFO - 2022-06-28 14:54:33 --> Helper loaded: file_helper
INFO - 2022-06-28 14:54:33 --> Database Driver Class Initialized
INFO - 2022-06-28 14:54:34 --> Email Class Initialized
DEBUG - 2022-06-28 14:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 14:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 14:54:34 --> Controller Class Initialized
INFO - 2022-06-28 14:54:34 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 14:54:34 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 14:54:34 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 14:54:34 --> Final output sent to browser
DEBUG - 2022-06-28 14:54:34 --> Total execution time: 0.1545
INFO - 2022-06-28 14:54:34 --> Config Class Initialized
INFO - 2022-06-28 14:54:34 --> Hooks Class Initialized
DEBUG - 2022-06-28 14:54:34 --> UTF-8 Support Enabled
INFO - 2022-06-28 14:54:34 --> Utf8 Class Initialized
INFO - 2022-06-28 14:54:34 --> URI Class Initialized
INFO - 2022-06-28 14:54:34 --> Router Class Initialized
INFO - 2022-06-28 14:54:34 --> Output Class Initialized
INFO - 2022-06-28 14:54:34 --> Security Class Initialized
DEBUG - 2022-06-28 14:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 14:54:35 --> Input Class Initialized
INFO - 2022-06-28 14:54:35 --> Language Class Initialized
INFO - 2022-06-28 14:54:35 --> Loader Class Initialized
INFO - 2022-06-28 14:54:35 --> Helper loaded: url_helper
INFO - 2022-06-28 14:54:35 --> Helper loaded: file_helper
INFO - 2022-06-28 14:54:35 --> Database Driver Class Initialized
INFO - 2022-06-28 14:54:35 --> Email Class Initialized
DEBUG - 2022-06-28 14:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 14:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 14:54:35 --> Controller Class Initialized
INFO - 2022-06-28 14:54:35 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 14:54:35 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 14:54:35 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 14:54:35 --> Final output sent to browser
DEBUG - 2022-06-28 14:54:35 --> Total execution time: 0.0556
INFO - 2022-06-28 14:54:35 --> Config Class Initialized
INFO - 2022-06-28 14:54:35 --> Hooks Class Initialized
DEBUG - 2022-06-28 14:54:35 --> UTF-8 Support Enabled
INFO - 2022-06-28 14:54:35 --> Utf8 Class Initialized
INFO - 2022-06-28 14:54:35 --> URI Class Initialized
INFO - 2022-06-28 14:54:35 --> Router Class Initialized
INFO - 2022-06-28 14:54:35 --> Output Class Initialized
INFO - 2022-06-28 14:54:35 --> Security Class Initialized
DEBUG - 2022-06-28 14:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 14:54:35 --> Input Class Initialized
INFO - 2022-06-28 14:54:35 --> Language Class Initialized
INFO - 2022-06-28 14:54:35 --> Loader Class Initialized
INFO - 2022-06-28 14:54:35 --> Helper loaded: url_helper
INFO - 2022-06-28 14:54:35 --> Helper loaded: file_helper
INFO - 2022-06-28 14:54:35 --> Database Driver Class Initialized
INFO - 2022-06-28 14:54:35 --> Email Class Initialized
DEBUG - 2022-06-28 14:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 14:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 14:54:35 --> Controller Class Initialized
INFO - 2022-06-28 14:54:35 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 14:54:35 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 14:54:35 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 14:54:35 --> Final output sent to browser
DEBUG - 2022-06-28 14:54:35 --> Total execution time: 0.0363
INFO - 2022-06-28 14:54:36 --> Config Class Initialized
INFO - 2022-06-28 14:54:36 --> Hooks Class Initialized
DEBUG - 2022-06-28 14:54:36 --> UTF-8 Support Enabled
INFO - 2022-06-28 14:54:36 --> Utf8 Class Initialized
INFO - 2022-06-28 14:54:36 --> URI Class Initialized
INFO - 2022-06-28 14:54:36 --> Router Class Initialized
INFO - 2022-06-28 14:54:36 --> Output Class Initialized
INFO - 2022-06-28 14:54:36 --> Security Class Initialized
DEBUG - 2022-06-28 14:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 14:54:36 --> Input Class Initialized
INFO - 2022-06-28 14:54:36 --> Language Class Initialized
INFO - 2022-06-28 14:54:36 --> Loader Class Initialized
INFO - 2022-06-28 14:54:36 --> Helper loaded: url_helper
INFO - 2022-06-28 14:54:36 --> Helper loaded: file_helper
INFO - 2022-06-28 14:54:36 --> Database Driver Class Initialized
INFO - 2022-06-28 14:54:36 --> Email Class Initialized
DEBUG - 2022-06-28 14:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 14:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 14:54:36 --> Controller Class Initialized
INFO - 2022-06-28 14:54:36 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 14:54:36 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 14:54:36 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 14:54:36 --> Final output sent to browser
DEBUG - 2022-06-28 14:54:36 --> Total execution time: 0.0599
INFO - 2022-06-28 14:54:37 --> Config Class Initialized
INFO - 2022-06-28 14:54:37 --> Hooks Class Initialized
DEBUG - 2022-06-28 14:54:37 --> UTF-8 Support Enabled
INFO - 2022-06-28 14:54:37 --> Utf8 Class Initialized
INFO - 2022-06-28 14:54:37 --> URI Class Initialized
INFO - 2022-06-28 14:54:37 --> Router Class Initialized
INFO - 2022-06-28 14:54:37 --> Output Class Initialized
INFO - 2022-06-28 14:54:37 --> Security Class Initialized
DEBUG - 2022-06-28 14:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 14:54:37 --> Input Class Initialized
INFO - 2022-06-28 14:54:37 --> Language Class Initialized
INFO - 2022-06-28 14:54:37 --> Loader Class Initialized
INFO - 2022-06-28 14:54:37 --> Helper loaded: url_helper
INFO - 2022-06-28 14:54:37 --> Helper loaded: file_helper
INFO - 2022-06-28 14:54:37 --> Database Driver Class Initialized
INFO - 2022-06-28 14:54:37 --> Email Class Initialized
DEBUG - 2022-06-28 14:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 14:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 14:54:37 --> Controller Class Initialized
INFO - 2022-06-28 14:54:37 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 14:54:37 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 14:54:37 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 14:54:37 --> Final output sent to browser
DEBUG - 2022-06-28 14:54:37 --> Total execution time: 0.0755
INFO - 2022-06-28 14:54:38 --> Config Class Initialized
INFO - 2022-06-28 14:54:38 --> Hooks Class Initialized
DEBUG - 2022-06-28 14:54:38 --> UTF-8 Support Enabled
INFO - 2022-06-28 14:54:38 --> Utf8 Class Initialized
INFO - 2022-06-28 14:54:38 --> URI Class Initialized
INFO - 2022-06-28 14:54:38 --> Router Class Initialized
INFO - 2022-06-28 14:54:38 --> Output Class Initialized
INFO - 2022-06-28 14:54:38 --> Security Class Initialized
DEBUG - 2022-06-28 14:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 14:54:38 --> Input Class Initialized
INFO - 2022-06-28 14:54:38 --> Language Class Initialized
INFO - 2022-06-28 14:54:38 --> Loader Class Initialized
INFO - 2022-06-28 14:54:38 --> Helper loaded: url_helper
INFO - 2022-06-28 14:54:38 --> Helper loaded: file_helper
INFO - 2022-06-28 14:54:38 --> Database Driver Class Initialized
INFO - 2022-06-28 14:54:38 --> Email Class Initialized
DEBUG - 2022-06-28 14:54:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 14:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 14:54:38 --> Controller Class Initialized
INFO - 2022-06-28 14:54:38 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 14:54:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 14:54:38 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
INFO - 2022-06-28 14:54:38 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 14:54:38 --> Final output sent to browser
DEBUG - 2022-06-28 14:54:38 --> Total execution time: 0.0281
INFO - 2022-06-28 14:58:06 --> Config Class Initialized
INFO - 2022-06-28 14:58:06 --> Hooks Class Initialized
DEBUG - 2022-06-28 14:58:06 --> UTF-8 Support Enabled
INFO - 2022-06-28 14:58:06 --> Utf8 Class Initialized
INFO - 2022-06-28 14:58:06 --> URI Class Initialized
INFO - 2022-06-28 14:58:06 --> Router Class Initialized
INFO - 2022-06-28 14:58:06 --> Output Class Initialized
INFO - 2022-06-28 14:58:06 --> Security Class Initialized
DEBUG - 2022-06-28 14:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 14:58:06 --> Input Class Initialized
INFO - 2022-06-28 14:58:06 --> Language Class Initialized
INFO - 2022-06-28 14:58:06 --> Loader Class Initialized
INFO - 2022-06-28 14:58:06 --> Helper loaded: url_helper
INFO - 2022-06-28 14:58:06 --> Helper loaded: file_helper
INFO - 2022-06-28 14:58:06 --> Database Driver Class Initialized
INFO - 2022-06-28 14:58:06 --> Email Class Initialized
DEBUG - 2022-06-28 14:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 14:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 14:58:07 --> Controller Class Initialized
INFO - 2022-06-28 14:58:07 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 14:58:07 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 14:58:07 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 14:58:07 --> Final output sent to browser
DEBUG - 2022-06-28 14:58:07 --> Total execution time: 0.2434
INFO - 2022-06-28 14:59:28 --> Config Class Initialized
INFO - 2022-06-28 14:59:28 --> Hooks Class Initialized
DEBUG - 2022-06-28 14:59:28 --> UTF-8 Support Enabled
INFO - 2022-06-28 14:59:28 --> Utf8 Class Initialized
INFO - 2022-06-28 14:59:28 --> URI Class Initialized
INFO - 2022-06-28 14:59:28 --> Router Class Initialized
INFO - 2022-06-28 14:59:28 --> Output Class Initialized
INFO - 2022-06-28 14:59:28 --> Security Class Initialized
DEBUG - 2022-06-28 14:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 14:59:28 --> Input Class Initialized
INFO - 2022-06-28 14:59:28 --> Language Class Initialized
INFO - 2022-06-28 14:59:28 --> Loader Class Initialized
INFO - 2022-06-28 14:59:28 --> Helper loaded: url_helper
INFO - 2022-06-28 14:59:28 --> Helper loaded: file_helper
INFO - 2022-06-28 14:59:28 --> Database Driver Class Initialized
INFO - 2022-06-28 14:59:28 --> Email Class Initialized
DEBUG - 2022-06-28 14:59:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 14:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 14:59:28 --> Controller Class Initialized
INFO - 2022-06-28 14:59:28 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 14:59:28 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 14:59:28 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 14:59:28 --> Final output sent to browser
DEBUG - 2022-06-28 14:59:28 --> Total execution time: 0.1600
INFO - 2022-06-28 15:00:17 --> Config Class Initialized
INFO - 2022-06-28 15:00:17 --> Hooks Class Initialized
DEBUG - 2022-06-28 15:00:17 --> UTF-8 Support Enabled
INFO - 2022-06-28 15:00:17 --> Utf8 Class Initialized
INFO - 2022-06-28 15:00:17 --> URI Class Initialized
INFO - 2022-06-28 15:00:17 --> Router Class Initialized
INFO - 2022-06-28 15:00:17 --> Output Class Initialized
INFO - 2022-06-28 15:00:17 --> Security Class Initialized
DEBUG - 2022-06-28 15:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 15:00:17 --> Input Class Initialized
INFO - 2022-06-28 15:00:17 --> Language Class Initialized
INFO - 2022-06-28 15:00:17 --> Loader Class Initialized
INFO - 2022-06-28 15:00:17 --> Helper loaded: url_helper
INFO - 2022-06-28 15:00:17 --> Helper loaded: file_helper
INFO - 2022-06-28 15:00:17 --> Database Driver Class Initialized
INFO - 2022-06-28 15:00:17 --> Email Class Initialized
DEBUG - 2022-06-28 15:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 15:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 15:00:17 --> Controller Class Initialized
INFO - 2022-06-28 15:00:17 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 15:00:17 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 15:00:17 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/startscreen.php
INFO - 2022-06-28 15:00:17 --> Final output sent to browser
DEBUG - 2022-06-28 15:00:17 --> Total execution time: 0.0500
INFO - 2022-06-28 15:00:27 --> Config Class Initialized
INFO - 2022-06-28 15:00:27 --> Hooks Class Initialized
DEBUG - 2022-06-28 15:00:27 --> UTF-8 Support Enabled
INFO - 2022-06-28 15:00:27 --> Utf8 Class Initialized
INFO - 2022-06-28 15:00:27 --> URI Class Initialized
INFO - 2022-06-28 15:00:27 --> Router Class Initialized
INFO - 2022-06-28 15:00:27 --> Output Class Initialized
INFO - 2022-06-28 15:00:27 --> Security Class Initialized
DEBUG - 2022-06-28 15:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 15:00:27 --> Input Class Initialized
INFO - 2022-06-28 15:00:27 --> Language Class Initialized
INFO - 2022-06-28 15:00:27 --> Loader Class Initialized
INFO - 2022-06-28 15:00:27 --> Helper loaded: url_helper
INFO - 2022-06-28 15:00:27 --> Helper loaded: file_helper
INFO - 2022-06-28 15:00:27 --> Database Driver Class Initialized
INFO - 2022-06-28 15:00:27 --> Email Class Initialized
DEBUG - 2022-06-28 15:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 15:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 15:00:27 --> Controller Class Initialized
INFO - 2022-06-28 15:00:27 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 15:00:27 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 15:00:27 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 15:00:27 --> Final output sent to browser
DEBUG - 2022-06-28 15:00:27 --> Total execution time: 0.0993
INFO - 2022-06-28 15:00:31 --> Config Class Initialized
INFO - 2022-06-28 15:00:31 --> Hooks Class Initialized
DEBUG - 2022-06-28 15:00:31 --> UTF-8 Support Enabled
INFO - 2022-06-28 15:00:31 --> Utf8 Class Initialized
INFO - 2022-06-28 15:00:31 --> URI Class Initialized
INFO - 2022-06-28 15:00:31 --> Router Class Initialized
INFO - 2022-06-28 15:00:31 --> Output Class Initialized
INFO - 2022-06-28 15:00:31 --> Security Class Initialized
DEBUG - 2022-06-28 15:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 15:00:31 --> Input Class Initialized
INFO - 2022-06-28 15:00:31 --> Language Class Initialized
INFO - 2022-06-28 15:00:31 --> Loader Class Initialized
INFO - 2022-06-28 15:00:31 --> Helper loaded: url_helper
INFO - 2022-06-28 15:00:31 --> Helper loaded: file_helper
INFO - 2022-06-28 15:00:31 --> Database Driver Class Initialized
INFO - 2022-06-28 15:00:31 --> Email Class Initialized
DEBUG - 2022-06-28 15:00:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 15:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 15:00:31 --> Controller Class Initialized
INFO - 2022-06-28 15:00:31 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 15:00:31 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 15:00:31 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 15:00:31 --> Final output sent to browser
DEBUG - 2022-06-28 15:00:31 --> Total execution time: 0.2193
INFO - 2022-06-28 15:00:32 --> Config Class Initialized
INFO - 2022-06-28 15:00:32 --> Hooks Class Initialized
DEBUG - 2022-06-28 15:00:32 --> UTF-8 Support Enabled
INFO - 2022-06-28 15:00:32 --> Utf8 Class Initialized
INFO - 2022-06-28 15:00:32 --> URI Class Initialized
INFO - 2022-06-28 15:00:32 --> Router Class Initialized
INFO - 2022-06-28 15:00:32 --> Output Class Initialized
INFO - 2022-06-28 15:00:32 --> Security Class Initialized
DEBUG - 2022-06-28 15:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 15:00:32 --> Input Class Initialized
INFO - 2022-06-28 15:00:32 --> Language Class Initialized
INFO - 2022-06-28 15:00:32 --> Loader Class Initialized
INFO - 2022-06-28 15:00:32 --> Helper loaded: url_helper
INFO - 2022-06-28 15:00:32 --> Helper loaded: file_helper
INFO - 2022-06-28 15:00:32 --> Database Driver Class Initialized
INFO - 2022-06-28 15:00:32 --> Email Class Initialized
DEBUG - 2022-06-28 15:00:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 15:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 15:00:32 --> Controller Class Initialized
INFO - 2022-06-28 15:00:32 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 15:00:32 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 15:00:32 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 15:00:32 --> Final output sent to browser
DEBUG - 2022-06-28 15:00:32 --> Total execution time: 0.0482
INFO - 2022-06-28 15:00:34 --> Config Class Initialized
INFO - 2022-06-28 15:00:34 --> Hooks Class Initialized
DEBUG - 2022-06-28 15:00:34 --> UTF-8 Support Enabled
INFO - 2022-06-28 15:00:34 --> Utf8 Class Initialized
INFO - 2022-06-28 15:00:34 --> URI Class Initialized
INFO - 2022-06-28 15:00:34 --> Router Class Initialized
INFO - 2022-06-28 15:00:34 --> Output Class Initialized
INFO - 2022-06-28 15:00:34 --> Security Class Initialized
DEBUG - 2022-06-28 15:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 15:00:34 --> Input Class Initialized
INFO - 2022-06-28 15:00:34 --> Language Class Initialized
INFO - 2022-06-28 15:00:34 --> Loader Class Initialized
INFO - 2022-06-28 15:00:34 --> Helper loaded: url_helper
INFO - 2022-06-28 15:00:34 --> Helper loaded: file_helper
INFO - 2022-06-28 15:00:34 --> Database Driver Class Initialized
INFO - 2022-06-28 15:00:34 --> Email Class Initialized
DEBUG - 2022-06-28 15:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 15:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 15:00:34 --> Controller Class Initialized
INFO - 2022-06-28 15:00:34 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 15:00:34 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 15:00:34 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 15:00:34 --> Final output sent to browser
DEBUG - 2022-06-28 15:00:34 --> Total execution time: 0.0892
INFO - 2022-06-28 15:00:35 --> Config Class Initialized
INFO - 2022-06-28 15:00:35 --> Hooks Class Initialized
DEBUG - 2022-06-28 15:00:35 --> UTF-8 Support Enabled
INFO - 2022-06-28 15:00:35 --> Utf8 Class Initialized
INFO - 2022-06-28 15:00:35 --> URI Class Initialized
INFO - 2022-06-28 15:00:35 --> Router Class Initialized
INFO - 2022-06-28 15:00:35 --> Output Class Initialized
INFO - 2022-06-28 15:00:35 --> Security Class Initialized
DEBUG - 2022-06-28 15:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 15:00:35 --> Input Class Initialized
INFO - 2022-06-28 15:00:35 --> Language Class Initialized
INFO - 2022-06-28 15:00:35 --> Loader Class Initialized
INFO - 2022-06-28 15:00:35 --> Helper loaded: url_helper
INFO - 2022-06-28 15:00:35 --> Helper loaded: file_helper
INFO - 2022-06-28 15:00:35 --> Database Driver Class Initialized
INFO - 2022-06-28 15:00:35 --> Email Class Initialized
DEBUG - 2022-06-28 15:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 15:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 15:00:35 --> Controller Class Initialized
INFO - 2022-06-28 15:00:35 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 15:00:35 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 15:00:35 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 15:00:35 --> Final output sent to browser
DEBUG - 2022-06-28 15:00:35 --> Total execution time: 0.0486
INFO - 2022-06-28 15:00:37 --> Config Class Initialized
INFO - 2022-06-28 15:00:37 --> Hooks Class Initialized
DEBUG - 2022-06-28 15:00:37 --> UTF-8 Support Enabled
INFO - 2022-06-28 15:00:37 --> Utf8 Class Initialized
INFO - 2022-06-28 15:00:37 --> URI Class Initialized
INFO - 2022-06-28 15:00:37 --> Router Class Initialized
INFO - 2022-06-28 15:00:37 --> Output Class Initialized
INFO - 2022-06-28 15:00:37 --> Security Class Initialized
DEBUG - 2022-06-28 15:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 15:00:37 --> Input Class Initialized
INFO - 2022-06-28 15:00:37 --> Language Class Initialized
INFO - 2022-06-28 15:00:37 --> Loader Class Initialized
INFO - 2022-06-28 15:00:37 --> Helper loaded: url_helper
INFO - 2022-06-28 15:00:37 --> Helper loaded: file_helper
INFO - 2022-06-28 15:00:37 --> Database Driver Class Initialized
INFO - 2022-06-28 15:00:37 --> Email Class Initialized
DEBUG - 2022-06-28 15:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 15:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 15:00:37 --> Controller Class Initialized
INFO - 2022-06-28 15:00:37 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 15:00:37 --> Session class already loaded. Second attempt ignored.
INFO - 2022-06-28 15:00:37 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 15:00:37 --> Final output sent to browser
DEBUG - 2022-06-28 15:00:37 --> Total execution time: 0.0347
INFO - 2022-06-28 15:00:38 --> Config Class Initialized
INFO - 2022-06-28 15:00:38 --> Hooks Class Initialized
DEBUG - 2022-06-28 15:00:38 --> UTF-8 Support Enabled
INFO - 2022-06-28 15:00:38 --> Utf8 Class Initialized
INFO - 2022-06-28 15:00:38 --> URI Class Initialized
INFO - 2022-06-28 15:00:38 --> Router Class Initialized
INFO - 2022-06-28 15:00:38 --> Output Class Initialized
INFO - 2022-06-28 15:00:38 --> Security Class Initialized
DEBUG - 2022-06-28 15:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-28 15:00:38 --> Input Class Initialized
INFO - 2022-06-28 15:00:38 --> Language Class Initialized
INFO - 2022-06-28 15:00:38 --> Loader Class Initialized
INFO - 2022-06-28 15:00:38 --> Helper loaded: url_helper
INFO - 2022-06-28 15:00:38 --> Helper loaded: file_helper
INFO - 2022-06-28 15:00:38 --> Database Driver Class Initialized
INFO - 2022-06-28 15:00:38 --> Email Class Initialized
DEBUG - 2022-06-28 15:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-28 15:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-28 15:00:38 --> Controller Class Initialized
INFO - 2022-06-28 15:00:38 --> Model "Tokenmodel" initialized
DEBUG - 2022-06-28 15:00:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2022-06-28 15:00:38 --> Severity: Notice --> Trying to get property 'ud_status' of non-object C:\wamp64\www\qr\application\views\doc_screen\doctor.php 354
INFO - 2022-06-28 15:00:38 --> File loaded: C:\wamp64\www\qr\application\views\doc_screen/doctor.php
INFO - 2022-06-28 15:00:38 --> Final output sent to browser
DEBUG - 2022-06-28 15:00:38 --> Total execution time: 0.0428
