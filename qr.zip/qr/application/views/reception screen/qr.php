
<!DOCTYPE html>
<html lang="">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>scan for token</title>

        <!-- Bootstrap CSS -->
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">

      
    </head>
    <style>
        body
{
background-color: #C4C6F8;
position: fixed;

height: 100%;

width: 100%;
}
.dot1
{
    top: 0%;
    bottom: 6%;
    left: 55%;
    right: 1%;
    height: 104%;
    width: 51%;
    background-color: #4A4A92;
    border-radius: 5%;
    display: inline-block;
    position: absolute;
    box-shadow: -3px -3px 8px;
}
.dot2
{
    top: -61%;
    bottom: 0%;
    left: -76%;
    right: 1%;
    height: 225%;
    width: 130%;
background-color: #C6D0F9;
border-radius: 50%;
display: inline-block;
position: absolute;
}
.dot3
{
    top: -62%;
    bottom: 0%;
    left: -78%;
    right: 1%;
    height: 229%;
    width: 129%;
background-color: #e8def6;
border-radius: 50%;
display: inline-block;
position: absolute;
}
.div_class
{
    position: relative;
    height: 100%;
    width: 100%;
}
.clinic
{
    position:absolute;
    top:8% ;
    right:10%;
    bottom: 10%;
    left: 5%;
    font-size: 25px;
    
    font-family:fantasy;
}
.color1
{
   color: #D5388B;
}
.color2
{
   color: #7F8BF3;
}
#demo
{
  position: absolute;
top: 6%;
right: 10%;
bottom: 10%;
left: 76%;
font-size: 15px;
font-family: 'Times New Roman', Times, serif;
font-weight: bold;
color: #fff;
}
.img
{
    position:absolute;
    top: 6%;
    right: 10%;
    bottom: 10%;
    left: 74%;
    

}
.token_no{
  position: absolute;
  left: 17%;
    top: 28%;
    height: 164px;
    width: 629px;
  font-family: Arial, Helvetica, sans-serif;
  text-shadow: 5px 5px 20px rgba(0, 0, 0, 0.564);
}
.token_no label{
    color: #1d2472;
    font-size: 255px;
    font-weight: normal;
   
}
.token_no p{
    position: absolute;
    font-weight: 600;
    color: #1d2472;
    left: -30%;
    top: 112%;
    font-size: 24px;
}
.qr{
    position: absolute;
    left: 1049px;
    top: 236px;
    background-color: #fff;
    border-radius: 10px;
    border: none;


}
.qr img{
    height: 300px;
    width: 300px;

}
.text{

position: absolute;
top: 143px;
    left: 972px;

}
.text p{
    color: #fff;
    font-size: 40px;
    font-weight: bold;

}
    </style>
    <body>
    
    


        <div class="div_class">
            <span class="dot1"></span>
            <!-- <span class="dot2"></span>
            <span class="dot3"></span> -->
            <span class="clinic"><span class="color1">Carewell</span><span class="color2"> Clinic</span> </span>
            <span id="demo"></span>
            <span class="img"><img src="<?php echo base_url()?>/static/images/clock.png" alt="" height="15px" width="15px"></span>
             <div class="token_no">
                 <label id="no">
                    
                </label>
                 <p>Token Number : </p>
             </div>
             <div class="qr"><img src="<?php echo base_url()?>/static/images/qr_2.png" alt="">
            </div>
             <div class="text">
                 <p>Scan Qr Code for Token</p>
            </div>


        <!-- jQuery -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <!-- Bootstrap JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <script>
            var today = new Date();
var day = today.getDay();
var daylist = ["Sunday","Monday","Tuesday","Wednesday ","Thursday","Friday","Saturday"];
var date = today.getFullYear()+'/'+(today.getMonth()+1)+'/'+today.getDate();
var time = today.getHours() + ":" + today.getMinutes();
var dateTime = date+' '+time;

 
document.getElementById("demo").innerHTML = dateTime + ' <br>' + daylist[day];
        </script>

        <script>
            function fetchdata()
            {
                 $.ajax({
                url: 'qrscreen',
                type: 'post',
                success: function(data){
                document.getElementById("no").innerHTML = data;
                
                },
                complete:function(data){
                setTimeout(fetchdata,10000);
                }
                });
            }

                $(document).ready(function(){
                fetchdata();
                });
                        </script>



    </body>
</html>
