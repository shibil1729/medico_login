
<!DOCTYPE html>
<html lang="">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>token screen</title>

       
       
        <!-- Bootstrap CSS -->
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@700&display=swap" rel="stylesheet">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@600&family=Raleway:wght@100&display=swap" rel="stylesheet"> 
          <!-- jQuery -->
          <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>


        
    </head>
    <style>
         body{
            background-color: #C4C6F8;
            /* position:absolute;
            height: 100%;
            width: 100%; */
        }
        .clinic
        {   
            position: inherit;
            padding:10px 10px 10px 10px;
            margin:10px 10px 10px 10px;
           
            top:28px;
            font-size: 28px;
            font-weight: bold;
            font-family:fantasy;
            
            font-family: 'Raleway', sans-serif;

        }
        .color1
            {
            color: #D5388B;
            }
            .color2
            {
            color: #7F8BF3;
            }

            .btn_class{
               position: inherit;
               bottom:26px;
                border: none;
                background-color: #ffffff;
                border-radius: 25px;
                color: #4A52A2;
                height: 40px;
                width: 110px;
                font-weight: bold;
                margin: -32px 15px 31px 213px;  
                
            }
            .btn_class:hover{
                position: inherit;

                border: none;
                background-color: #4A52A2;
                border-radius: 25px;
                color:#fff;
                height: 40px;
                width: 110px;
                font-weight: bold;
                bottom:26px;

                margin: -32px 15px 31px 213px;            }
            .current
            {
                
                padding: 41px 70px 10px 1px;
                margin: 11px 24px 10px 10px;

            }
            .current a{
               
                position: inherit;
                padding: 12px 16px 27px 13px;
                margin: 7px 12px 13px 24px;
                top: -26px;
                left: 79px;
                bottom: 10px;
                right: 10px;
   
               }
            .current a img{
               
                height: 18px;
                width: 18px;
               
               
    
                }
                .token_no
                {
                    padding: 14px 9px 12px 122px;
                    margin: 3px 10px 10px 10px;
                }
                .token_no label{
                font-family: 'Manrope', sans-serif;
                color: #4A52A2;
                font-size: 196px;
                text-shadow: 11px 15px 33px #000000a3;
                font-weight: lighter;
                text-align: center;
            }
                .info_div
                {
                        padding: 29px 76% 28px 128px;
                        margin: 28px 58px 36px -22px;
                        background-color: #4A4A92;
                        box-shadow: 3px -3px 8px;
                        width: 0px;
                        height: 447px;
                        border-top-right-radius: 50px;
                        border-top-left-radius: 50px;
                }
               .yourtoken
               {
                white-space: nowrap;
                color:#fff;
                padding: 17px 10px 4px 6px;
                margin: 5px 13px 9px -98px;
               }
                   .font{
                    color:#ffff;
                   }
                   #tk{
                    font-weight:bold;
                   }
                   .whitespace{
                    white-space: nowrap;
                   }
                   .spec
                   {
                    color:#fff;
                    padding: 29px 3px 14px 27px;
                    margin: -6px 11px 13px -101px;
                    font-size:15px;
                   }
                   .time
                   {
                    color:#fff;
                    padding: 29px 3px 14px 27px;
                    margin: -6px 11px 13px -101px;
                    
                   }
                   .time h1
                   {
                    font-size:25px;
                   }
                   .new
                   {
                    padding: 25px 56px 51px 5px;
                    margin: -74px -202px 86px 303px;
                    color:#ffff;
                   }
                   #new_token{
                    position: inherit;
               bottom:15px;
                border: none;
               
                color: #ffff;
               
               
                margin: 0px 29px 20px -162px; 
                   }
                  
    </style>
    <body>
        




    </style>
    <body>
<?php 
     if(!$this->session->userdata('token_generated'))
        {
           foreach($token as $value)
	               {
                      $tk =  $value;
	               }

                   foreach($est as $value)
	               {
                      $time =  $value;
	               }        

        }
     else
        {
            $tk=$this->session->userdata('token_generated');
            $time=$this->session->userdata('est_time');

        }
        
?>


   
        <div class="container"> 
            <div class="row">
                <div class="col-md-12">
                    <span class="clinic"><span class="color1">Carewell</span><span class="color2"> Clinic</span> </span>
                </div>
            </div>
        
      <div class="row current">
            <div class="col-md-8">
                <label for="">Current Token</label>
            </div>
            <div class="col-md-4 ">
             <a href="token" onclick="check()"><img src="../static/images/refresh.png" alt=""></a>   
            </div>
      </div>

      <div class="row">
        <div class="col-md-12 token_no">
        <label id="inc" for=""><?php if(isset($current_token)){echo $current_token;} ?></label>
        <input id="id_1" type="hidden" value="<?php if(isset($current_token)){echo $current_token;} ?>">
        </div>
      </div>

      <div class=" container-fluid info_div ">
      <div class="row">
        <div class="col-md-12">
            <h3 class="yourtoken" id="tk">Your Token  &nbsp &nbsp &nbsp   <?php echo $tk; ?></h3>
           <input id="id_2" type="hidden" value=" <?php echo $tk; ?>">
        </div>
      </div>

      <div class="row">
        <div class="col-md-12 spec">
        <h1>Dr.xyzabc</h1>
             <span class=" whitespace">MBBS,MS Ortho</span>
        </div>

      </div>

      <div class="row">
        <div class="col-md-12 time">
        <h1>Estimated Time : <?php echo $time; ?></h1>
            
        </div>

      </div>
        
      
      <div class="row">
        <div class="col-md-12 spec">
        <button class="btn_class" id="fill" onclick="getdata()">
               Fill Details
           </button>
        </div>

      </div>
      <div class="row">
        <div class="col-md-12 new">
        <a class="" id="new_token" onclick="request()" >
               Request second call
    </a>
        </div>

      </div>
       
     </div>
              
              
               
        </div>
      
        
           
       
       </div>
      
    
    
    <script>
        // $("#fill").on('click',function(){
            function getdata(){

            
            // alert('hi');
            var test = 1;

            $.ajax({
                url:"udata",
                    type:'post',
                    data:{test:test},
                    success : function(data) {
                              
                              window.location.href = "<?php echo base_url() ?>/Tokenctrl/udata";
                           
                             },
                    error : function(data) {
                           alert("failed");
                           }
            });
       
            }


    </script>
    <script>
        function request(){
        var current_token = $('#id_1').val();
        var tk =$('#id_2').val();
        if(current_token > tk)
            {
                $('#new_token').removeAttr("hidden");
            }

            $.ajax({
                url:"request",
                    type:'post',
                    data:{tk:tk},
                    success : function(data) {
                              
                              alert("request sent")
                           
                             },
                    error : function(data) {
                           alert("failed");
                           }
            });

        }    
    
    </script>
  

      
        <!-- Bootstrap JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <script>
        
        // document.getElementById("tk").innerHTML=$value['td_tk'];
    </script>



      
    </body>
</html>
