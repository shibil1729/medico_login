
<!DOCTYPE html>
<html lang="">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>token screen</title>

       
       
        <!-- Bootstrap CSS -->
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@700&display=swap" rel="stylesheet">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@600&family=Raleway:wght@100&display=swap" rel="stylesheet"> 
          <!-- jQuery -->
          <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>


        
    </head>
    <style>
         body{
            background-color: #C4C6F8;
            /* position:absolute;
            height: 100%;
            width: 100%; */
        }
        .main_div{
            /* position: relative; */
            /* height: 100%;
            width: 100%; */
        }
        .dot1{
  /* position: absolute; */
     padding: 526px 35px 39px 55px;
    margin: 484px 50px 75px 2px;
    
    /* top: 59%;
    bottom: -2%;
    left: 0%;
    right: -2%; */
    height: 47%;
    width: 100%;
    background-color: #4A4A92;
    border-radius: 12%;
    display: inline-block;
    box-shadow: 3px -3px 8px;
            
        }
       
        .clinic
{
    position:absolute;
    /* padding:10px 10px 10px 10px;
    margin:10px 10px 10px 10px; */
    top:8% ;
    right:10%;
    bottom: 10%;
    left: 5%;
    font-size: 28px;
    font-weight: bold;
    font-family:fantasy;
    
     font-family: 'Raleway', sans-serif;

}
.color1
{
   color: #D5388B;
}
.color2
{
   color: #7F8BF3;
}
.current{
    position: absolute;
    top: 125px;
    left: 36px;
}
.current label{
    font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    color: #121117;
    font-weight: 900;
    font-size:19px ;
}
.current a img{
    position: absolute;
    height: 18px;
    width: 18px;
    left: 145px;
    top: 3px;
    
}
.token_no{
    position: absolute;
    top: 146px;
    left: 30%;
    text-anchor: middle;
}
/* @media screen and (min-width:400px) {

   .token_no{
    position: absolute;
    top: 146px;
    left: 27%;
    text-anchor: middle;
} 

} */

.token_no label{
    /* font-family:'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif ; */
    font-family: 'Manrope', sans-serif;
/* font-family: 'Raleway', sans-serif; */
    color: #4A52A2;
    font-size: 196px;
    text-shadow: 11px 15px 33px #000000a3;
    font-weight: lighter;
    text-align: center;
}
.yourtoken{
    position: absolute;
    top: 556px;
    left: 30px;
}
.yourtoken label
{
    /* font-family:'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif ; */
    color: #ffffff;
    font-size: 26px;
    font-weight:700;
    
    
}
.yourtoken p{
    position: absolute;
    left: 159px;
    top: -11px;
    font-size: 36px;
    font-weight: bold;
    color: #ffffff;
}
.yourtoken h1{
    position: absolute;
    left: 3px;
    top: 45px;
    font-size: 26px;
    color: #ffffff;
    
}
.spec{
    position: absolute;
    left: 3px;
    top: 90px;
    font-size: 17px;
    color: #ffffff;
    
}
.est_time{
    position: absolute;
    left:-10px;
    top: 150px;
    font-size: 19px;
    color: #ffffff;
    font-weight: 700;
    
}
.btn_class{
    position: absolute;
    top: 90%;
    left: 62%;
    border: none;
    background-color: #ffffff;
    border-radius: 25px;
    color: #4A52A2;
    height: 40px;
    width: 110px;
    font-weight: bold;
}
.btn_class:hover{
    position: absolute;
    top: 90%;
    left: 62%;
    border: none;
    background-color: #4A52A2;
    border-radius: 25px;
    color:#fff;
    height: 40px;
    width: 110px;
    font-weight: bold;
}
    </style>
    <body>
        




    </style>
    <body>
<?php 


// var_dump($last_id);



 if(!$this->session->userdata('token_generated'))
{
 foreach($token as $value)
	{
        $tk =  $value;
		// $tk=$value['td_tk'];
	}
}
else{
    $tk=$this->session->userdata('token_generated');
}
?>


   
        <div class="wrapper"> 

       <!-- <div class="main_div"> -->
          <span class="dot1"></span>
         
          <!-- <div class="container"> -->
          <span class="clinic"><span class="color1">Carewell</span><span class="color2"> Clinic</span> </span>
           
          <div class="row current">
              <label for="">Current Token</label>
              <a href="token"><img src="../static/images/refresh.png" alt=""></a>
          </div>
          <div class="row"><div class="col-md-12"><div class="token_no">
               <label id="inc" for=""><?php if(isset($current_token)){echo $current_token;} ?></label>
           </div></div>
               </div>
          
           <div class="yourtoken">
            <label for="">Your Token </label>
            <p id="tk">
                <?php 
                    echo $tk; 
                    ?>
            </p>
           
            <h1>Dr.xyzabc</h1>
             <span class="spec">MBBS,MS Ortho</span>
             <span class=" col-md-12 est_time">Estimated Time 15 Min</span>
           </div>
           <button class="btn_class" id="fill" onclick="getdata()">
               Fill Details
           </button>
          <!-- </div> -->
          
       
       </div>
      
    
    
    <script>
        // $("#fill").on('click',function(){
            function getdata(){

            
            // alert('hi');
            var test = 1;

            $.ajax({
                url:"udata",
                    type:'post',
                    data:{test:test},
                    success : function(data) {
                              
                              window.location.href = "<?php echo base_url() ?>/Tokenctrl/udata";
                           
                             },
                    error : function(data) {
                           alert("failed");
                           }
            });
        // });
            }
    </script>
  

      
        <!-- Bootstrap JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <script>
        
        // document.getElementById("tk").innerHTML=$value['td_tk'];
    </script>



      
    </body>
</html>
