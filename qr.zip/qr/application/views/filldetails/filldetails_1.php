
<!DOCTYPE html>
<html lang="">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>fill details</title>
        <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@600&display=swap" rel="stylesheet">
        <!-- Bootstrap CSS -->
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <style>
          body{
            background-color: #C4C6F8;
            /* position:absolute;
            height: 100%;
            width: 100%; */
        }
        .clinic
        {   
            position: inherit;
            padding:10px 10px 10px 10px;
            margin:10px 10px 10px 10px;
           
            top:28px;
            font-size: 28px;
            font-weight: bold;
            font-family:fantasy;
            
            font-family: 'Raleway', sans-serif;

        }
        .color1
            {
            color: #D5388B;
            }
            .color2
            {
            color: #7F8BF3;
            }

            .btn_class{
               position: inherit;
               bottom:26px;
                border: none;
                background-color: #ffffff;
                border-radius: 25px;
                color: #4A52A2;
                height: 40px;
                width: 110px;
               
                margin: -35px 22px 36px 14px;
                font-weight: bold;
    font-size: 20px;
                
            }
            .btn_class:hover{
                position: inherit;

                border: none;
                background-color: #4A52A2;
                border-radius: 25px;
                color:#fff;
                height: 40px;
                width: 110px;
                bottom:26px;

                margin: -35px 22px 36px 14px;    
                font-weight: bold;
    font-size: 20px;      }
           
                .btn {
    display: inline-block;
    padding: 4px 27px;
    margin:0px 0px 0px 15px;
    margin-bottom: 0;
    font-size: 19px;
    font-weight: 400;
    line-height: 1.42857143;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    -ms-touch-action: manipulation;
    touch-action: manipulation;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    background-image: none;
    border: 1px solid transparent;
    border-radius: 39px;
    width: 106.6px;
}
.btn:hover {
    display: inline-block;
    padding: 4px 27px;
    margin-bottom: 0;
    font-size: 19px;
    font-weight: 400;
    line-height: 1.42857143;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    -ms-touch-action: manipulation;
    touch-action: manipulation;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    background-image: none;
    border: 1px solid transparent;
    border-radius: 39px;
    width: 106.6px;
    box-shadow: 0px 5px 0px #5255936b;
}
            
           
              
                .info_div
                {
                    padding: 96px 67% 72px 165px;
    margin: -31px 63px 44px -21px;
    background-color: #4A4A92;
    box-shadow: 3px -3px 8px;
    width: 0px;
    height: 358px;
    border-top-right-radius: 50px;
    border-top-left-radius: 50px;
                }
              
                   .whitespace{
                    white-space: nowrap;
                   }

                   .button_class {
    color: #7F8BF3;
    background-color: #fff;
    border-color: #2e6da400;
    border-radius: 30px;
    font-weight: bold;
}
.button_class:hover {
    color: #fff;
    background-color: #7F8BF3;
    border-color: #2e6da400;
    border-radius: 30px;
    font-weight: bold;
    border: none;
}

.name_{
    padding: 84px 14px 10px 0px;
    margin: 15px 18px 24px 4px;
}
.age_{
    padding: 31px 10px 18px 4px;
    margin: 66px 28px 30px 3px;
}
.gender_{
    padding: 22px 3px 53px 26px;
    margin: 81px -51px 43px -37px;
}
.submit_
{
    padding: -12px 5px 10px -7px;
    margin: -10px -42px 50px -37px;
}
  .name_div input
  {
    border-radius: 25px;
    border: none;
    width: 308px;
    height: 42px;
    text-align:center;
  }       
  .age_div input
  {
    border-radius:25px;
    border:none;
    width:115px;
    height:42px;
    text-align:center;
  }       
  .gender_div input
  {
    
  }  
  .container p
  {
    font-weight: bold;
color: #4A52A2;
font-size: 20px;
  }              



    </style>
    <body>
    <div class="container"> 
            <div class="row">
                <div class="col-md-12">
                    <span class="clinic"><span class="color1">Carewell</span><span class="color2"> Clinic</span> </span>
                </div>
            </div>
        
      <div class="row name_">
            <div class="col-md-12 name_div">
            <p>Patient Name</p>
                 <input type="text" id="name">
            </div>
     </div>

      <div class="row age_">
        <div class="col-md-12 age_div">
                <p>Age</p>
                <input type="number" id="age">
        </div>
      </div>



      <div class="row gender_">
        <div class="col-md-12 gender_div">
        <p>Gender</p>
                <div class="btn-group" role="group" aria-label="Basic example">
                    <input type="hidden" id="gender">
                    <button type="button" class="btn btn-primary button_class error" id="male">Male</button>
                    <button type="button" class="btn btn-primary button_class" id="female">Female</button>
                    <button type="button" class="btn btn-primary button_class" id="other">Other</button>
                  </div>
        </div>
      </div>

      <div class=" container-fluid info_div ">
      

      
        
      
      <div class="row submit_">
        <div class="col-md-12 ">
        <button class="btn_class" id="submit">
               Submit
           </button>
        </div>

      </div>
       
     </div>
              
              
               
        </div>







       
    <!-- <div class="wrapper">


        <div class="main_div">
            <span class="dot1"></span>
           
            <div class="container">
            <span class="clinic"><span class="color1">Carewell</span><span class="color2"> Clinic</span> </span>
            
            <div class="p_name">
                 <p>Patient Name</p>
                 <input type="text" id="name">
             </div>
             <div class="age">
                <p>Age</p>
                <input type="number" id="age">
            </div>
            <div class="gender">
                <p>Gender</p>
                <div class="btn-group" role="group" aria-label="Basic example">
                    <input type="hidden" id="gender">
                    <button type="button" class="btn btn-primary button_class error" id="male">Male</button>
                    <button type="button" class="btn btn-primary button_class" id="female">Female</button>
                    <button type="button" class="btn btn-primary button_class" id="other">Other</button>
                  </div>
                   
               
                    <div class="submit">
                        <button href="javascript:" id="submit">Submit</button>
                    </div>
               

            </div>
            </div>




        </div>     -->

    





       




        <!-- jQuery -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <!-- Bootstrap JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <script type="text/javascript">
            
            
            
             $("#male").on('click',function(){
               var gender = $("#gender").val('male');
             });
            
            
             $("#female").on('click',function(){
               var gender = $("#gender").val('female');
             });
             
             
             $("#other").on('click',function(){
               var gender = $("#gender").val('other');
             });



            $("#submit").on('click',function(){

                
                var ud_name=$('#name').val();
                var ud_age=$('#age').val();
                var ud_gender=$('#gender').val();


                var today = new Date();
                var day = today.getDay();
                var daylist = ["Sunday","Monday","Tuesday","Wednesday ","Thursday","Friday","Saturday"];
                var date = today.getFullYear()+'/'+(today.getMonth()+1)+'/'+today.getDate();
                var time = today.getHours() + ":" + today.getMinutes();
                var ud_time= date+' '+time;

               


                $.ajax({
                    url:"insertdata",
                    type:'POST',
                    data:{ud_name:ud_name , ud_age:ud_age , ud_gender:ud_gender , ud_time : ud_time },
                    success : function(data1) {
                              
                              window.location.href = "<?php echo base_url()?>/Tokenctrl/mob";
                           
                             },
                    error : function(data1) {
                           alert("failed");
                           }
                    

                });
            });     
         </script> 
         </body>
</html>
