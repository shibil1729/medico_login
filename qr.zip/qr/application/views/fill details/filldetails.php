
<!DOCTYPE html>
<html lang="">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>fill details</title>
        <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@600&display=swap" rel="stylesheet">
        <!-- Bootstrap CSS -->
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <style>
               .wrapper{
            background-color: #C4C6F8;
            position: fixed;
            height: 100%;
            width: 100%;
        }
               .main_div{
            position: relative;
            background-color: #C4C6F8;
            height: 100%;
            width: 100%;
        }
        .dot1{
            position: absolute;
    top: 79%;
    bottom: -2%;
    left: 0%;
    right: -2%;
    height: 31%;
    width: 100%;
    background-color: #4A4A92;
    border-radius: 12%;
    display: inline-block;
    box-shadow: 3px -3px 8px;
            
        }
        /* .dot2{
            position: absolute;
    top: -19%;
    bottom: -2%;
    left: -43%;
    right: 1%;
    height: 105%;
    width: 185%;
    background-color: #C6D0F9;
    border-radius: 50%;
    display: inline-block;
            
        }
        .dot3{
            position: absolute;
    top: -25%;
    bottom: -2%;
    left: -38%;
    right: 1%;
    height: 105%;
    width: 174%;
    background-color: #e8def6;
    border-radius: 50%;
    display: inline-block;
            
        } */
        .clinic
{
    position:absolute;
    top:5% ;
    right:10%;
    bottom: 10%;
    left: 8%;
    font-size: 28px;
    font-family: 'Raleway', sans-serif;
    font-weight: normal;
}
.color1
{
   color: #D5388B;
}
.color2
{
   color: #7F8BF3;
}
.p_name{
position: absolute;
top: 170px;
left: 24px;
}
.p_name p{
color: #4A52A2;
font-weight: bold;
font-size: 20px;
}
.p_name input{
    border: none;
    border-radius: 25px;
    height: 45px;
    width: 320px;
    text-align: center;
}
.p_name input:hover{
    border: none;
    border-radius: 25px;
    height: 45px;
    width: 320px;
    text-align: center;
    box-shadow: 0px 5px 0px #5255936b;
}
.age{
    position: absolute;
    left: 24px;
    top: 343px;
}
.age p{
font-weight: bold;
color: #4A52A2;
font-size: 20px;
}
.age input{
border: none;
border-radius: 25px;
height: 45px;
width: 100px;
text-align: center;
}
.age input:hover{
border: none;
border-radius: 25px;
height: 45px;
width: 100px;
text-align: center;
box-shadow: 0px 5px 0px #5255936b;
}


.gender{
    position: absolute;
    left: 24px;
    top: 505px;
}
.gender p{
    font-weight: bold;
color: #4A52A2;
font-size: 20px;
}
.gender input{
    border: none;
    width: 100px;

}
.btn {
    display: inline-block;
    padding: 4px 27px;
    margin-bottom: 0;
    font-size: 19px;
    font-weight: 400;
    line-height: 1.42857143;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    -ms-touch-action: manipulation;
    touch-action: manipulation;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    background-image: none;
    border: 1px solid transparent;
    border-radius: 39px;
    width: 106.6px;
}
.btn:hover {
    display: inline-block;
    padding: 4px 27px;
    margin-bottom: 0;
    font-size: 19px;
    font-weight: 400;
    line-height: 1.42857143;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    -ms-touch-action: manipulation;
    touch-action: manipulation;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    background-image: none;
    border: 1px solid transparent;
    border-radius: 39px;
    width: 106.6px;
    box-shadow: 0px 5px 0px #5255936b;
}
.submit{
position: absolute;
top: 281%;
    left: 32%;
}
.submit button{
    background-color: #fff;
    color: #4A52A2;
    border: none;
    border-radius: 30px;
    height: 40px;
    width: 136px;
    font-weight: bold;
    font-size: 20px;
}
.submit button:hover{
    background-color: #7A7AC8;
    color: #fff;
    border: none;
    border-radius: 30px;
    height: 40px;
    width: 136px;
    font-weight: bold;
    font-size: 20px;
}
.button_class {
    color: #7F8BF3;
    background-color: #fff;
    border-color: #2e6da400;
    border-radius: 30px;
    font-weight: bold;
}
.button_class:hover {
    color: #fff;
    background-color: #7F8BF3;
    border-color: #2e6da400;
    border-radius: 30px;
    font-weight: bold;
    border: none;
}



    </style>
    <body>
        <?php
        
        
        
        
        
        ?>
    <div class="wrapper">


        <div class="main_div">
            <span class="dot1"></span>
            <!-- <span class="dot2"></span>
            <span class="dot3"></span> -->
            <div class="container">
            <span class="clinic"><span class="color1">Carewell</span><span class="color2"> Clinic</span> </span>
            <form action="" method="post">
            <div class="p_name">
                 <p>Patient Name</p>
                 <input type="text" name="name">
             </div>
             <div class="age">
                <p>Age</p>
                <input type="number" name="age">
            </div>
            <div class="gender">
                <p>Gender</p>
                <div class="btn-group" role="group" aria-label="Basic example">
                    <button type="button" class="btn btn-primary button_class" name="male">Male</button>
                    <button type="button" class="btn btn-primary button_class" name="female">Female</button>
                    <button type="button" class="btn btn-primary button_class" name="other">Other</button>
                  </div>
                  </form> 
                <!-- <input type="radio">Male
                <input type="radio">Female
                <input type="radio">Other -->
                    <div class="submit">
                        <button id="submit">Submit</button>
                    </div>
               

            </div>
            </div>




        </div>    

    </div>





         <script type="text/javascript">
            //ajax post
            $("#submit").click(function(){
                var name=$("input[name='name']").val();
                var age=$("input[name='age']").val();


                $.ajax({
                    url: "<?php echo base_url("udata");?>",
                    post:'POST',
                    data:{ud_name:name , ud_age:age},
                    success : function(data) {
                           alert("success");
                           },
                    error : function(data) {
                           alert("failed");
                           }


                });
            });




         </script>




        <!-- jQuery -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <!-- Bootstrap JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    </body>
</html>
