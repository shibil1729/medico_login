
<!DOCTYPE html>
<html lang="">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>login</title>

        <!-- Bootstrap CSS -->
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.3/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <style>
        body{
	margin: 0;
	padding: 0;
	background: url(ya.jpg) no-repeat center center fixed;;
	background-size: cover;
   -webkit-background-size: cover;
   -moz-background-size: cover;
   -o-background-size: cover;
	background-position: center;
	font-family: sans-serif;
    background-color:#64646b;
}
.loginbox{
	width: 320px;
	height: 500px;
	background: rgba(0, 0, 0, 0.3);
	color: #fff;
	top: 50%;
	left: 50%;
	position: absolute;
	transform: translate(-50%,-50%);
	box-sizing:border-box;
	padding: 70px 30px;
	border-radius: 20px;
}
.pic2{
	width: 100px;
	height: 100px;
	border-radius: 50%;
	position: absolute;
	top: -50px;
	left: calc(50% - 50px);

}
h1{
	margin: 0;
	padding: 0 0 20px;
	text-align: center;
	font-size: 22px;
}
.loginbox p{
	margin: 0;
	padding: 0;
	font-weight: bold;
}
.loginbox input{
	width: 100%;
	margin-bottom:20px ;
}
.loginbox input[type="text"]
{
	border:none ;
	border-bottom:1px solid #fff ;
	background: transparent;
	outline: none;
	height: 40px;
	color: #fff;
	font-size: 16px;
}
.loginbox input[type="submit"]
{
	border: none;
	outline:none ;
	height: 40px;
	background: #8b43b1;
	color: #fff;
	font-size: 18px;
	border-radius: 20px;
}
.loginbox input[type="submit"]:hover
{
	cursor: pointer;
	background: #b72547;
	color: #000;
}
.loginbox a{
	text-decoration: none;
	font-size: 12px;
	line-height: 20px;
	color: darkgrey;
}
.loginbox a:hover
{
	color:#1dcf43;
}

    </style>
    <body>
    <div class="loginbox">
      <h1>Sign in</h1>
      <form>
      	<p>Username</p>
      	<input type="text"  id="uname" name="" placeholder="Enter Username">
      	<p>Password</p>
      	<input type="text" id="password" name="">
      	<input type="submit" id="login" name="" value="Login">
      </form>
</div>


        <!-- jQuery -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <!-- Bootstrap JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <script>
             $('#login').on('click',function(){
                var uname = $('#uname').val();
                var password = $('#password').val();
                
                if(uname!='' && password !='' )

               {

                var say = 1;
                
                $.ajax({
                    url:"login_check",
                    type:'POST',
                    data:{'uname':uname,'password':password},
                    success: function(response) {
                        window.location.href = "<?php echo base_url()?>/Tokenctrl/start";
                    }
                    error:function(data)
                    {
                        alert("login failed");
                    }     
                    });
                }
            
            
            else{alert('enter valid credential');}
                
               
            });
        </script>

    </body>
</html>
