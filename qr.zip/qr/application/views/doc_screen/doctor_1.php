<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@600&display=swap" rel="stylesheet">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
    /* Remove the navbar's default margin-bottom and rounded borders */ 
    body
    {
        background-color: #C4C6F8;
    }
  
  
    
 
      .sidenav {
        height: auto;
        padding: 577px 15px 15px 15px;
    margin: -89px 52px 45px 1076px;

      }
      .row.content {height:auto;} 
    
    .clinic
{
   
    font-family: 'Raleway', sans-serif;
    font-weight: normal;
    font-size:28px;
}
.color1
{
   color: #D5388B;
}
.color2
{
   color: #7F8BF3;
}
h1{
    padding: 16px 642px 6px 33px;
    margin: 33px 6px 33px -27px;
    font-size: 19px;
    font-weight: bold;
    color: #091153;
    font-family: Verdana, Geneva, Tahoma, sans-serif;
}
#demo
{
color:#ffff;
padding: 11px 643px 11px 7px;
    margin: 38px 5px 32px -25px;
    font-family: 'Raleway', sans-serif;
}
.img
{
    padding: 16px 642px 6px 33px;
    margin: 33px 6px 33px -27px;
}
.date
{
    padding: -31px 660px 4px 36px;
    margin: 6px -259px 8px 259px;
}
.info_div
{
    background-color: #4A4A92;
    border-radius:25px;
    height:80%;
    padding: 617px 32px 16px 7px;
    margin: 104px 70px 51px 1030px;
}
.mid_div
{
   
}
  </style>
</head>
<body>

<div class="container">



      <div class="row">
            <div class="col-md-8 logo">
                 <span class="clinic"><span class="color1">Carewell</span><span class="color2"> Clinic</span> </span>
            </div>
            <div class="col-md-4 date">
                 <span id="demo"></span>
            </div>
      </div>

      <div class="row  mid_div">
            <div class="col-md-8 user_info">
                    
            </div>
            <div class="col-md-4 info_div">

            </div>
      </div>




</div>











     <script> 
            var today = new Date();
var day = today.getDay();
var daylist = ["Sunday","Monday","Tuesday","Wednesday ","Thursday","Friday","Saturday"];
var date = today.getFullYear()+'/'+(today.getMonth()+1)+'/'+today.getDate();
var time = today.getHours() + ":" + today.getMinutes();
var dateTime = date+' '+time;

 
document.getElementById("demo").innerHTML = dateTime + ' <br>' + daylist[day];

        </script>



</body>
</html>