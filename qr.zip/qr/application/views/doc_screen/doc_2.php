<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@600&display=swap" rel="stylesheet">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
    /* Remove the navbar's default margin-bottom and rounded borders */ 
    body
    {
        background-color: #fff;
        padding: 10px 10px 10px 10px;
    }
  
  .logo{
    background-color:#a0c3f2;
    width:100%;
  }
    
 
      .sidenav {
        height: auto;
        padding: 577px 15px 15px 15px;
    margin: -89px 52px 45px 1076px;

      }
      .row.content {height:auto;} 
    
    .clinic
{
   
    font-family: 'Raleway', sans-serif;
    font-weight: normal;
    font-size:28px;
}
.color1
{
   color: #D5388B;
}
.color2
{
   color: #7F8BF3;
}
h1{
    padding: 16px 642px 6px 33px;
    margin: 33px 6px 33px -27px;
    font-size: 19px;
    font-weight: bold;
    color: #091153;
    font-family: Verdana, Geneva, Tahoma, sans-serif;
}
#demo
{
color:#ffff;
padding: 11px 643px 11px 7px;
    margin: 38px 5px 32px -25px;
    font-family: 'Raleway', sans-serif;
}
.img
{
    padding: 16px 642px 6px 33px;
    margin: 33px 6px 33px -27px;
}
.date
{
    padding: -31px 660px 4px 36px;
    margin: 6px -259px 8px 259px;
}
.info_div
{
    background-color: #64646b;
    height:100%;
    padding: 75% 69px 12px 63px;
    margin: -543px 150px 23px 1161px;
}
.mid_div
{
   
}

.token_class
{
  padding: 10px 10px 10px 10px;
  margin: 10px 10px 10px 10px;
    top:20% ;
    right:10%;
    bottom: 10%;
    left: 75%;
    font-size: 25px;
    font-family:Verdana, Geneva, Tahoma, sans-serif;
    color: #ffff;
    font-weight: bold;
    text-indent: 5px;
    letter-spacing: 0px;
    

}
.tclass1{
  position: relative;
top: 35%;
right: 10%;
bottom: 10%;
left: 75%;
font-size: 15px;
font-family: Verdana, Geneva, Tahoma, sans-serif;
color: #ffff;
}
.tclass2{
position: relative;
top: 42%;
right: 10%;
bottom: 10%;
left: 75%;
font-size: 15px;
font-family: Verdana, Geneva, Tahoma, sans-serif;
color: #ffff;       
}
.tclass3{
  position: relative;
top: 50%;
right: 10%;
bottom: 10%;
left: 75%;
font-size: 15px;
font-family: Verdana, Geneva, Tahoma, sans-serif;
color: #ffff;
border-radius:15px;
}
.nclass1{
  position: relative;
top: 35%;
right: 10%;
bottom: 10%;
left: 87%;
font-size: 15px;
font-family: Verdana, Geneva, Tahoma, sans-serif;
color: #ffff;
}
.nclass2{
  position: relative;
top: 42%;
right: 10%;
bottom: 10%;
left: 87%;
font-size: 15px;
font-family: Verdana, Geneva, Tahoma, sans-serif;
color: #ffff;
}
.nclass3{
  position: relative;
top: 50%;
right: 10%;
bottom: 10%;
left: 87%;
font-size: 15px;
font-family: Verdana, Geneva, Tahoma, sans-serif;
color: #ffff;
}
.end{
    position relative
    top: 100%;
    left: 5%;
    background-color:#7F8BF3 ;
    color: #fff;
    border-radius: 25px;
    width: 135px;
    border: none;
    height: 26px;
    font-weight: bold;
}
.end:hover{
    position relative
    top: 90%;
    left: 5%;
    background-color:#fff ;
    color: #7F8BF3;
    border-radius: 25px;
    width: 135px;
    border: none;
    height: 26px;
    font-weight: bold;
}
.end_session{
    position: relative;
    top: 90%;
    left: 50%;
    background-color:#7F8BF3 ;
    color: #fff;
    border-radius: 25px;
    width: 125px;
    border: none;
    height: 26px;
    font-weight: bold;
    
    
}
.end_session:hover{
    position relative
    top: 90%;
    left: 50%;
    background-color:#fff ;
    color: #7F8BF3;
    border-radius: 25px;
    width: 125px;
    border: none;
    height: 26px;
    font-weight: bold;
}
.skip{
    position relative
    top: 90%;
    left: 40%;
    background-color:#7F8BF3 ;
    color: #fff;
    border-radius: 25px;
    width: 125px;
    border: none;
    height: 26px;
    font-weight: bold;
}
.skip:hover{
    position relative
    top: 90%;
    left: 40%;
    background-color:#fff ;
    color:#7F8BF3 ;
    border-radius: 25px;
    width: 125px;
    border: none;
    height: 26px;
    font-weight: bold;
}
.break{
    position relative
    top: 90%;
    left: 40%;
    background-color:#7F8BF3 ;
    color: #fff;
    border-radius: 25px;
    width: 125px;
    border: none;
    height: 26px;
    font-weight: bold;
}
.break:hover{
    position relative
    top: 90%;
    left: 40%;
    background-color:#fff ;
    color:#7F8BF3 ;
    border-radius: 25px;
    width: 125px;
    border: none;
    height: 26px;
    font-weight: bold;
}

h1{
    position: relative
    top: 22%;
    left:5%;
    font-size: 25px;
    font-weight: bold;
    color: #091153;
    font-family: Verdana, Geneva, Tahoma, sans-serif;

}
h2{
  position: relative
    top: 22%;
    left:20%;
    font-size: 25px;
    font-weight: bold;
    color: #091153;
    font-family: Verdana, Geneva, Tahoma, sans-serif;
}
.name{
  position: relative;
    top: 31%;
    left:-4%;
    font-size: 20px;
    margin:5px 5px 5px 26px;
    padding:5px 5px 5px 72px;
    color: #091153;
    font-family: Verdana, Geneva, Tahoma, sans-serif;
}
.age{
  position: relative;
    top: 41%;
    left:5.5%;
    font-size: 20px;
    
    color: #091153;
    font-family: Verdana, Geneva, Tahoma, sans-serif;
}
.gender{
position: relative;
    top: 51%;
    left:5.5%;
    font-size: 20px;
    
    color: #091153;
    font-family: Verdana, Geneva, Tahoma, sans-serif;
}
.mob{
position: relative;
    top: 61%;
    left:5.5%;
    font-size: 20px;
    
    color: #091153;
    font-family: Verdana, Geneva, Tahoma, sans-serif;
}
.comments{
position: relative;
    top: 71%;
    left:5.5%;
    font-size: 20px;
    
    color: #091153;
    font-family: Verdana, Geneva, Tahoma, sans-serif;
}
button{
    padding: 5px 5px 5px 5px;
    margin: -16px 50px 0px 14px;
}
.tick
{
    position: relative;
    left: 33%;
    top: 25%;
    height: 87px;
    width: 15px;
}


#NoUserDiv
{
    color: #ffff;
    font-size: font-weight: 931px;
    position: relative;
    top: 30%;
    padding: 113px 19px 31px 201px;
    margin: -458px 13px 125px 411px;
    background-color:#091153b5;
    height: 256px;
    width: 494px;
    border-radius: 5px;
    border-color: rgb(201, 76, 76);
}
#dname
{
    border-radius:25px;
    
    margin:5px 5px 5px 5px;
    background-color:#a19bd7;
    border-color:#fff0;
}
#dage
{
    border-radius:25px;
    background-color:#a19bd7;
    border-color:#fff0;
    margin:5px 5px 5px 105px;

}
#dgender
{
    border-radius:25px;
    background-color:#a19bd7;
    border-color:#fff0;
    margin:5px 5px 5px 71px;


}
#dmob
{
    border-radius:25px;
    background-color:#a19bd7;
    border-color:#fff0;
    margin:5px 5px 5px 48px;


}
#dcomments
{
    border-radius:10px;
    background-color:#a19bd7;
    border-color:#fff0;
    margin:5px 5px 5px 35px;
    font-size: 15px;
    padding:5px 5px 74px 72px;
    
    color:grey;



}
.submit
{
position: relative;
top:78%;
left:82%;
bottom:50%;
margin: -27px 26px -33px -300px;
    padding: 4px 23px 8px 12px;

}
#reg
{
    color:#ffff;
    border-radius:50px;
    height:25px;
    width:75px;
    border-color:#ffff;
    background-color:#4a4a92;
    /* margin: 3px 26px 11px -298px; */
    padding:3px 10px 10px 10px;
}
    

.history
{
    position: relative;
    top: 15%;
    left: 44%;
    background-color: #ffff;
    height: 466px;
    width: 411px;
    border-radius:15px;

}
.hclass1
{
    margin:5px 5px 5px 35px;
    font-size: 15px;
    padding:5px 5px 74px 72px;
    color:#091153;
}
#missed{
    color: #000;
}
.buttons{
    padding: 21px 29px 25px 59px;
    margin: 142px -401px -100px -52px;
}
.container{
    width:100%;
}
.total{
    padding: 17px 36px 17px 20px;
    margin: -666px -39px 38px;
}
.miss{
    padding: 43px 10px 10px 10px;
    margin: 16px 18px 17px -27px;

}
.second_call_class{
    padding: 43px 10px 10px 10px;
    margin: 16px 18px 17px -27px;
}
.early_skip_class{
    padding: 43px 10px 10px 10px;
    margin: 16px 18px 17px -27px;
}
.info_div select{
border-color:#fff0;
border-radius:25px;
background-color:#9585e7;
}
.info_div select option{
    background-color:#9585e7;
}
.info_div span{
    color:#fff;
}
.history
{
    position: absolute;
    top: 5%;
    left: 69%;
    background-color: #64646b;
    height: 466px;
    width: 411px;
    border-radius:15px;

}
.history h5{
    color:#fff;
    text-align:center;
}
.heading{
    background-color:#8578c3;
}
.first_class{
    padding: 16px 517px 6px 33px;
}
  </style>
</head>
<body>

<div class="container" id="doctor_div">



      <div class="row">
            <div class="col-md-12 logo">
                 <span class="clinic"><span class="color1">Carewell</span><span class="color2"> Clinic</span> </span>
            </div>
            <div class="col-md-4 date">
                 <span id="demo"></span>
            </div>
      </div>

      <div class="row  mid_div">
            <div class="col-md-8 user_info">
                <?php //var_dump($current_token); 
              //  die;?>
                <span class="nclass1"><?php echo $current_token ?></span>
            <span class="nclass2">
                <?php  if(isset($total)){echo $total;} ?>
            </span>
            <span class="nclass3"><?php echo (isset($skip_count)?$skip_count:"") ?></span>
            <input type="hidden" id="tdid" value="<?php echo $tdid ?>" />

            <h1 class="first_class" >Current Token : <?php echo $current_token ?> </h1>
            <!-- <h2></h2> -->
            
         <br>
           <span class="name">Patient Name :

               <input id="dname" type="text" value="<?php echo (isset($user_details->ud_name)?$user_details->ud_name:'No Name') ?>"> 

             </span>
         <br>
           <span class="age"> Age   :

           <input id="dage" type="text" value="<?php echo (isset($user_details->ud_age)?$user_details->ud_age:'No age') ?>">  

        </span>
    <br>
           <span class="gender">Gender   :

           <input id="dgender" type="text" value="<?php echo (isset($user_details->ud_gender)?$user_details->ud_gender:'No gender') ?>">  

        </span>
     <br>   <span class="mob">Mobile no   :

<input id="dmob" type="number" value="<?php echo (isset($user_details->ud_mob)?$user_details->ud_mob:'No mob') ?>">  

</span>
<br>
<span class="comments">Comments   :

<input id="dcomments" type="text" value="-comments-">  

</span>
<div class="submit">
    <span> <button id="reg">submit</button></span>

</div>
<div class="buttons">
            <button class="end" id="end">End Consulting</button>
            <button class="end_session" id="next">End Session</button>
            <button class="skip" id="skip">Skip</button>  
            <button class="break" id="break">Take a break</button> 
            <button hidden class="break" id="continue" >continue</button>
            <input type="hidden" id="tdid" value="<?php echo $tdid ?>" />
</div>

<div class="history" hidden>
 <div class="container">
    <div class="row heading">
            <div class="col-md-12">
                     <h5>visit history</h5>
            </div>
    </div>
   
 </div>
</div>
           


 <div class="col-md-4 info_div" >

 <div class="row total">
     <span>Total patients:</span>
 </div>

            
           <div class="row miss">
            <span>missed tokens:</span>
            <br>
             <select name="" id="missed">

            <option value=""></option>

                    <?php
                     foreach($skipped_token as $value)
                     {
                        ?>
                        <option value="<?php echo $value['td_pk']; ?>"><?php echo $value['td_tk']; ?></option>
                        <?php
                     }
                     
                    ?>
            </select>
           </div>

           <div class="row second_call_class">
            <span>requested for second call:</span>
             <select name="" id="second_call">

            <option value=""></option>

                    <?php
                     foreach($requested_token as $value)
                     {
                        ?>
                        <option value="<?php echo $value['td_pk']; ?>"><?php echo $value['td_tk']; ?></option>
                        <?php
                     }
                     
                    ?>
            </select>
           </div>

         
          

           
            
 </div>
            
             
           
           
           


               
        
        
        
         <div id="NoUserDiv" style="display:none"></div>
            
        </div>
       
  
     







        <!-- jQuery -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <!-- Bootstrap JavaScript -->
       
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <script>
              $('#reg').on('click',function(){
                var tdid = $('#tdid').val();
                var ud_name = $('#dname').val();
                var ud_age = $('#dage').val();
                var ud_gender = $('#dgender').val();
                var ud_mob = $('#dmob').val();
                var comment = $('#dcomments').val();
                

                var today = new Date();
                var day = today.getDay();
                var daylist = ["Sunday","Monday","Tuesday","Wednesday ","Thursday","Friday","Saturday"];
                var date = today.getFullYear()+'/'+(today.getMonth()+1)+'/'+today.getDate();
                var time = today.getHours() + ":" + today.getMinutes();
                var ud_time= date+' '+time;

                $.ajax({
                    url:"doctor_submit_data",
                    type:'POST',
                    data:{'tdid':tdid,'ud_name':ud_name,'ud_age':ud_age,'ud_gender':ud_gender,'ud_mob':ud_mob,'comment':comment , 'ud_time':ud_time},
                    success: function(response) {
                       
                    }
                });
              });
       
       
            $('#next').on('click',function(){
                var tdid = $('#tdid').val();
                var missed = $('#missed').val();
                var request = $('#second_call').val();

               

                var say = 1;
                //
                $.ajax({
                    url:"next",
                    type:'POST',
                    data:{'tdid':tdid , 'missed':missed , 'request':request},
                    success: function(response) {
                        var data = JSON.parse(response);
                            if (data.status == 1 ) {
                                
                                $("#doctor_div").html(data.view);
                                
                               
                            } else if (data.status == -1 ) {
                               document.getElementById("NoUserDiv").style.display='block';
                                $("#NoUserDiv").html(data.message);
                                
                                
                            } 
                    }
                });
                
               
            });




            $('#break').on('click',function(){
                var tdid = $('#tdid').val();
                var missed = $('#missed').val();
               

                var say = 1;
                //
                $.ajax({
                    url:"break",
                    type:'POST',
                    data:{'tdid':tdid , 'missed':missed},
                    success: function(response) 
                    {
                       $("#continue").show();
                       $("#break").hide();
                       $("#next").hide();
                       $("#skip").hide();


                    }
                });
                
               
            });

            $('#continue').on('click',function(){
                var tdid = $('#tdid').val();
                var missed = $('#missed').val();
               

                var say = 1;
                //
                $.ajax({
                    url:"continue",
                    type:'POST',
                    data:{'tdid':tdid , 'missed':missed},
                    success: function(response) 
                    {
                       $("#continue").hide();
                       $("#break").show();
                       $("#next").show();
                       $("#skip").show();
                        

                    }
                });
                
               
            });



            $('#end').on('click',function(){
                $.ajax({
                    url:"end",
                    type:'POST',
                    success:function(data)
                    {
                        window.location.href="start";
                        }
                });
            });


            $('#skip').on('click',function(){
                
                var tdid = $('#tdid').val();
                $.ajax({
                    data:{'tdid':tdid},
                    url:"skip",
                    type:'POST',
                    success:function(response)
                    {

                        var data = JSON.parse(response);
                            if (data.status == 1 ) {
                                
                                $("#doctor_div").html(data.view);
                               
                            } else if (data.status == -1 ) {
                               document.getElementById("NoUserDiv").style.display='block';
                                $("#NoUserDiv").html(data.message);
                                
                                
                            } 
                        
                        }
                });
            });
            
        </script>
        
        
       
        
        <script> 
            var today = new Date();
var day = today.getDay();
var daylist = ["Sunday","Monday","Tuesday","Wednesday ","Thursday","Friday","Saturday"];
var date = today.getFullYear()+'/'+(today.getMonth()+1)+'/'+today.getDate();
var time = today.getHours() + ":" + today.getMinutes();
var dateTime = date+' '+time;

 
document.getElementById("demo").innerHTML = dateTime + ' <br>' + daylist[day];

        </script>
        <script>
              $('#reg').on('click',function(){
                var tdid = $('#tdid').val();
                var ud_name = $('#dname').val();
                var ud_age = $('#dage').val();
                var ud_gender = $('#dgender').val();
                var ud_mob = $('#dmob').val();
                var comment = $('#dcomments').val();
    
            
            <div class="col-md-4 info_div" align="left">
            
            </div>
      </div>




</div>











     <script> 
            var today = new Date();
var day = today.getDay();
var daylist = ["Sunday","Monday","Tuesday","Wednesday ","Thursday","Friday","Saturday"];
var date = today.getFullYear()+'/'+(today.getMonth()+1)+'/'+today.getDate();
var time = today.getHours() + ":" + today.getMinutes();
var dateTime = date+' '+time;

 
document.getElementById("demo").innerHTML = dateTime + ' <br>' + daylist[day];

        </script>



</body>
</html>
