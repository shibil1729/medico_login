
<!DOCTYPE html>
<html lang="">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Carewell</title>
        <link rel=”icon” href=”favicon.ico” type=”image/any-icon”>

        <!-- Bootstrap CSS -->
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
       
       <style>
          
          .body
{
background-color: #C4C6F8;
position: fixed;

height: 745.6px;

width: 1536px;
}
.dot1
{
    top: 17%;
    bottom: 0%;
    left: 72%;
    right: 1%;
    height: 89%;
    width: 33%;
    background-color: #4A4A92;
    border-radius: 9%;
    display: inline-block;
    position: absolute;
}

.dot2
{
top: -59%;
bottom: 0%;
left: -60%;
right: 1%;
height: 221%;
width: 129%;
background-color: #C6D0F9;
border-radius: 50%;
display: inline-block;
position: absolute;
}
.dot3
{
top: -59%;
bottom: 0%;
left: -65%;
right: 1%;
height: 221%;
width: 129%;
background-color: #e8def6;
border-radius: 50%;
display: inline-block;
position: absolute;
}
.div_class
{
    position: relative;
    height: 100%;
    width: 100%;
}
.clinic
{
    position:absolute;
    top:8% ;
    right:10%;
    bottom: 10%;
    left: 5%;
    font-size: 25px;
    
    font-family:fantasy;
}
.color1
{
   color: #D5388B;
}
.color2
{
   color: #7F8BF3;
}
#demo
{
  position: absolute;
top: 6%;
right: 10%;
bottom: 10%;
left: 76%;
font-size: 15px;
font-family: 'Times New Roman', Times, serif;
font-weight: bold;
color: #fff;
}
.img
{
    position:absolute;
    top: 6%;
    right: 10%;
    bottom: 10%;
    left: 74%;
    

}
.token_class
{
  position:absolute;
    top:20% ;
    right:10%;
    bottom: 10%;
    left: 75%;
    font-size: 25px;
    font-family:Verdana, Geneva, Tahoma, sans-serif;
    color: #ffff;
    font-weight: bold;
    text-indent: 5px;
    letter-spacing: 0px;
    

}
.tclass1{
  position: absolute;
top: 35%;
right: 10%;
bottom: 10%;
left: 75%;
font-size: 15px;
font-family: Verdana, Geneva, Tahoma, sans-serif;
color: #ffff;
}
.tclass2{
position: absolute;
top: 42%;
right: 10%;
bottom: 10%;
left: 75%;
font-size: 15px;
font-family: Verdana, Geneva, Tahoma, sans-serif;
color: #ffff;       
}
.tclass3{
  position: absolute;
top: 50%;
right: 10%;
bottom: 10%;
left: 75%;
font-size: 15px;
font-family: Verdana, Geneva, Tahoma, sans-serif;
color: #ffff;
border-radius:15px;
}
.nclass1{
  position: absolute;
top: 35%;
right: 10%;
bottom: 10%;
left: 87%;
font-size: 15px;
font-family: Verdana, Geneva, Tahoma, sans-serif;
color: #ffff;
}
.nclass2{
  position: absolute;
top: 42%;
right: 10%;
bottom: 10%;
left: 87%;
font-size: 15px;
font-family: Verdana, Geneva, Tahoma, sans-serif;
color: #ffff;
}
.nclass3{
  position: absolute;
top: 50%;
right: 10%;
bottom: 10%;
left: 87%;
font-size: 15px;
font-family: Verdana, Geneva, Tahoma, sans-serif;
color: #ffff;
}
.end_session{
    position:absolute;
    top: 90%;
    left: 50%;
    background-color:#7F8BF3 ;
    color: #fff;
    border-radius: 25px;
    width: 125px;
    border: none;
    height: 26px;
    font-weight: bold;
    
    
}
.end_session:hover{
    position:absolute;
    top: 90%;
    left: 50%;
    background-color:#fff ;
    color: #7F8BF3;
    border-radius: 25px;
    width: 125px;
    border: none;
    height: 26px;
    font-weight: bold;
}
.skip{
    position:absolute;
    top: 90%;
    left: 40%;
    background-color:#7F8BF3 ;
    color: #fff;
    border-radius: 25px;
    width: 125px;
    border: none;
    height: 26px;
    font-weight: bold;
}
.skip:hover{
    position:absolute;
    top: 90%;
    left: 40%;
    background-color:#fff ;
    color:#7F8BF3 ;
    border-radius: 25px;
    width: 125px;
    border: none;
    height: 26px;
    font-weight: bold;
}
.end{
    position:absolute;
    top: 90%;
    left: 5%;
    background-color:#7F8BF3 ;
    color: #fff;
    border-radius: 25px;
    width: 135px;
    border: none;
    height: 26px;
    font-weight: bold;
}
.end:hover{
    position:absolute;
    top: 90%;
    left: 5%;
    background-color:#fff ;
    color: #7F8BF3;
    border-radius: 25px;
    width: 135px;
    border: none;
    height: 26px;
    font-weight: bold;
}
h1{
    position: absolute;
    top: 22%;
    left:5%;
    font-size: 25px;
    font-weight: bold;
    color: #091153;
    font-family: Verdana, Geneva, Tahoma, sans-serif;

}
h2{
  position: absolute;
    top: 22%;
    left:20%;
    font-size: 25px;
    font-weight: bold;
    color: #091153;
    font-family: Verdana, Geneva, Tahoma, sans-serif;
}
.name{
  position: absolute;
    top: 31%;
    left:-4%;
    font-size: 20px;
    margin:5px 5px 5px 72px;
    padding:5px 5px 5px 72px;
    color: #091153;
    font-family: Verdana, Geneva, Tahoma, sans-serif;
}
.age{
  position: absolute;
    top: 41%;
    left:5.5%;
    font-size: 20px;
    
    color: #091153;
    font-family: Verdana, Geneva, Tahoma, sans-serif;
}
.gender{
position: absolute;
    top: 51%;
    left:5.5%;
    font-size: 20px;
    
    color: #091153;
    font-family: Verdana, Geneva, Tahoma, sans-serif;
}
.mob{
position: absolute;
    top: 61%;
    left:5.5%;
    font-size: 20px;
    
    color: #091153;
    font-family: Verdana, Geneva, Tahoma, sans-serif;
}
.comments{
position: absolute;
    top: 71%;
    left:5.5%;
    font-size: 20px;
    
    color: #091153;
    font-family: Verdana, Geneva, Tahoma, sans-serif;
}
button{
    padding: 5px 5px 5px 5px;
    margin: 5px 5px 5px 5px
}
.tick
{
    position: absolute;
    left: 33%;
    top: 25%;
    height: 87px;
    width: 15px;
}


#NoUserDiv
{
    color: #ffff;
    font-size: font-weight: 931px;
    position: absolute;
    top: 30%;
    padding: 117px 4px 5px 194px;
    margin: 63px 13px 125px 411px;
    background-color: #091153;
    height: 256px;
    width: 494px;
    border-radius: 5px;
    border-color: rgb(201, 76, 76);
}
#dname
{
    border-radius:9px;
    border-color:#ffff;
    margin:5px 5px 5px 12px;
}
#dage
{
    border-radius:9px;
    border-color:#ffff;
    margin:5px 5px 5px 105px;

}
#dgender
{
    border-radius:9px;
    border-color:#ffff;
    margin:5px 5px 5px 71px;


}
#dmob
{
    border-radius:9px;
    border-color:#ffff;
    margin:5px 5px 5px 48px;


}
#dcomments
{
    border-radius:9px;
    border-color:#ffff;
    margin:5px 5px 5px 35px;
    font-size: 15px;
    padding:5px 5px 74px 72px;
    
    color:grey;



}
.submit
{
position: absolute;
top:78%;
left:36%;

}
#reg
{
    color:#ffff;
    border-radius:15px;
    height:50px;
    width:100px;
    border-color:#ffff;
    background-color:#4a4a92;
    
}
.history
{
    position: absolute;
    top: 15%;
    left: 44%;
    background-color: #ffff;
    height: 466px;
    width: 411px;
    border-radius:15px;

}
.hclass1
{
    margin:5px 5px 5px 35px;
    font-size: 15px;
    padding:5px 5px 74px 72px;
    color:#091153;
}
#missed{
    color: #000;
}
.break{
    position:absolute;
    top: 90%;
    left: 19%;
    background-color:#7F8BF3 ;
    color: #fff;
    border-radius: 25px;
    width: 135px;
    border: none;
    height: 26px;
    font-weight: bold;
}
.break:hover{
    position:absolute;
    top: 90%;
    left: 19%;
    background-color:#fff ;
    color: #7F8BF3;
    border-radius: 25px;
    width: 135px;
    border: none;
    height: 26px;
    font-weight: bold;
}

       </style>
    </head>
    <body class="body">
      
        <div class="div_class" id="doctor_div">
        <?php 
                //    var_dump($skipped_token);

    
        ?>
            <span class="dot1"></span>
            <!-- <span class="dot2"></span>
            <span class="dot3"></span> -->
            <span class="clinic"><span class="color1">Carewell</span><span class="color2"> Clinic</span> </span>
            <span id="demo"></span>
            <span class="img">
                <img src="<?php echo base_url()?>/static/images/clock.png" alt="" height="15px" width="15px">
            </span>
            <span class="token_class">Token Details</span>
            
            <span class="tclass1">Current Token  :</span>
            <span class="tclass2">Total Token    :</span>
            <span class="tclass3">Missed Tokens  :

            <select name="" id="missed">

            <option value="">please select a token</option>

                    <?php
                     foreach($skipped_token as $value)
                     {
                        ?>
                        <option value="<?php echo $value['td_pk']; ?>"><?php echo $value['td_tk']; ?></option>
                        <?php
                     }
                     
                    ?>
            </select>

            </span>
            <span class="nclass1"><?php echo $current_token ?></span>
            <span class="nclass2">
                <?php  if(isset($total)){echo $total;} ?>
            </span>
            <span class="nclass3"><?php //echo (isset($skip_count)?$skip_count:) ?></span>
            <input type="hidden" id="tdid" value="<?php echo $tdid ?>" />
            <button class="end_session" id="next">End Session</button>
            <button class="skip" id="skip">Skip</button>
            <button class="end" id="end">End Consulting</button>
            <button class="break" id="break">Take a break</button>
            <button hidden class="break" id="continue">continue</button>
            <h1>Current Token : </h1>
            <h2><?php echo $current_token ?></h2>
<?php 

// isset($user_details->ud_status && $user_details->ud_status=='verified')?echo '<span class="tick"> <img src="../static/images/tick.png" height="15px" width="15px"></span> ':echo "-"


if(isset($user_details->ud_status) && $user_details->ud_status=="verified")
    { 
        echo '<span class="tick"> <img src="../static/images/tick.png" height="15px" width="15px"></span> ';
    }
   
?>

            
          

           <span class="name">Patient Name :

               <input id="dname" type="text" value="<?php echo (isset($user_details->ud_name)?$user_details->ud_name:'No Name') ?>"> 

             </span>
           <span class="age"> Age   :

           <input id="dage" type="text" value="<?php echo (isset($user_details->ud_age)?$user_details->ud_age:'NO age') ?>">  

        </span>
           <span class="gender">Gender   :

           <input id="dgender" type="text" value="<?php echo (isset($user_details->ud_gender)?$user_details->ud_gender:'No gender') ?>">  

        </span>
        <span class="mob">Mobile no   :

<input id="dmob" type="number" value="<?php echo (isset($user_details->ud_mob)?$user_details->ud_mob:'No mob') ?>">  

</span>
<span class="comments">Comments   :

<input id="dcomments" type="text" value="-comments-">  

</span>
<span class="submit"> <button id="reg">submit</button></span>

<!-- <div class="history">
<span class="hclass1">Last visit detials:</span>
</div> -->


               
        
        
        
         <div id="NoUserDiv" style="display:none"></div>
            
        </div>
       
  
     







        <!-- jQuery -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <!-- Bootstrap JavaScript -->
       
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <script>
              $('#reg').on('click',function(){
                var tdid = $('#tdid').val();
                var ud_name = $('#dname').val();
                var ud_age = $('#dage').val();
                var ud_gender = $('#dgender').val();
                var ud_mob = $('#dmob').val();
                var comment = $('#dcomments').val();
                

                var today = new Date();
                var day = today.getDay();
                var daylist = ["Sunday","Monday","Tuesday","Wednesday ","Thursday","Friday","Saturday"];
                var date = today.getFullYear()+'/'+(today.getMonth()+1)+'/'+today.getDate();
                var time = today.getHours() + ":" + today.getMinutes();
                var ud_time= date+' '+time;

                $.ajax({
                    url:"doctor_submit_data",
                    type:'POST',
                    data:{'tdid':tdid,'ud_name':ud_name,'ud_age':ud_age,'ud_gender':ud_gender,'ud_mob':ud_mob,'comment':comment , 'ud_time':ud_time},
                    success: function(response) {
                       
                    }
                });
              });
       
       
            $('#next').on('click',function(){
                var tdid = $('#tdid').val();
                var missed = $('#missed').val();
               

                var say = 1;
                //
                $.ajax({
                    url:"next",
                    type:'POST',
                    data:{'tdid':tdid , 'missed':missed},
                    success: function(response) {
                        var data = JSON.parse(response);
                            if (data.status == 1 ) {
                                
                                $("#doctor_div").html(data.view);
                               
                            } else if (data.status == -1 ) {
                               document.getElementById("NoUserDiv").style.display='block';
                                $("#NoUserDiv").html(data.message);
                                
                                
                            } 
                    }
                });
                
               
            });




            $('#break').on('click',function(){
                var tdid = $('#tdid').val();
                var missed = $('#missed').val();
               

                var say = 1;
                //
                $.ajax({
                    url:"break",
                    type:'POST',
                    data:{'tdid':tdid , 'missed':missed},
                    success: function(response) 
                    {
                       $("#continue").removeAttr("hidden");
                       $("#break").hide();
                       $("#next").hide();
                       $("#skip").hide();


                    }
                });
                
               
            });

            $('#continue').on('click',function(){
                var tdid = $('#tdid').val();
                var missed = $('#missed').val();
               

                var say = 1;
                //
                $.ajax({
                    url:"continue",
                    type:'POST',
                    data:{'tdid':tdid , 'missed':missed},
                    success: function(response) 
                    {
                       $("#continue").attr("hidden");
                       $("#break").show();
                       $("#next").show();
                       $("#skip").show();
                        

                    }
                });
                
               
            });



            $('#end').on('click',function(){
                $.ajax({
                    url:"end",
                    type:'POST',
                    success:function(data)
                    {
                        window.location.href="start";
                        }
                });
            });


            $('#skip').on('click',function(){
                
                var tdid = $('#tdid').val();
                $.ajax({
                    data:{'tdid':tdid},
                    url:"skip",
                    type:'POST',
                    success:function(response)
                    {

                        var data = JSON.parse(response);
                            if (data.status == 1 ) {
                                
                                $("#doctor_div").html(data.view);
                               
                            } else if (data.status == -1 ) {
                               document.getElementById("NoUserDiv").style.display='block';
                                $("#NoUserDiv").html(data.message);
                                
                                
                            } 
                        
                        }
                });
            });
            
        </script>
        
        
       
        
        <script> 
            var today = new Date();
var day = today.getDay();
var daylist = ["Sunday","Monday","Tuesday","Wednesday ","Thursday","Friday","Saturday"];
var date = today.getFullYear()+'/'+(today.getMonth()+1)+'/'+today.getDate();
var time = today.getHours() + ":" + today.getMinutes();
var dateTime = date+' '+time;

 
document.getElementById("demo").innerHTML = dateTime + ' <br>' + daylist[day];

        </script>



            
    </body>
</html>
