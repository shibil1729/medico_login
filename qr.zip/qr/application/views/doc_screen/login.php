<!DOCTYPE html>
<html>
<head>
	<title>Doctors login</title>
	<link rel="stylesheet" type="text/css" href="style.css">

</head>
<style>
    body{
	margin: 0;
	padding: 0;
	background: url(ya.jpg) no-repeat center center fixed;;
	background-size: cover;
   -webkit-background-size: cover;
   -moz-background-size: cover;
   -o-background-size: cover;
	background-position: center;
	font-family: sans-serif;
}
.loginbox{
	width: 320px;
	height: 500px;
	background: rgba(0, 0, 0, 0.3);
	color: #fff;
	top: 50%;
	left: 50%;
	position: absolute;
	transform: translate(-50%,-50%);
	box-sizing:border-box;
	padding: 70px 30px;
	border-radius: 20px;
}
.pic2{
	width: 100px;
	height: 100px;
	border-radius: 50%;
	position: absolute;
	top: -50px;
	left: calc(50% - 50px);

}
h1{
	margin: 0;
	padding: 0 0 20px;
	text-align: center;
	font-size: 22px;
}
.loginbox p{
	margin: 0;
	padding: 0;
	font-weight: bold;
}
.loginbox input{
	width: 100%;
	margin-bottom:20px ;
}
.loginbox input[type="text"]
{
	border:none ;
	border-bottom:1px solid #fff ;
	background: transparent;
	outline: none;
	height: 40px;
	color: #fff;
	font-size: 16px;
}
.loginbox input[type="submit"]
{
	border: none;
	outline:none ;
	height: 40px;
	background: #8b43b1;
	color: #fff;
	font-size: 18px;
	border-radius: 20px;
}
.loginbox input[type="submit"]:hover
{
	cursor: pointer;
	background: #b72547;
	color: #000;
}
.loginbox a{
	text-decoration: none;
	font-size: 12px;
	line-height: 20px;
	color: darkgrey;
}
.loginbox a:hover
{
	color:#1dcf43;
}

</style>
<body>
      <div class="loginbox">
      
      <h1>Profile</h1>
      <form>
      	<p>Username</p>
      	<input type="text" name="" placeholder="Enter Username">
      	<p>Specailization</p>
      	<input type="text" name="">
      	<p>Clinic Name</p>
      	<input type="text" name="" placeholder="Enter Clinic Name">
      	<input type="submit" name="" value="Login">
      	<a href="#">Don`t have account?</a><br>
      </form>
</div>
</body>
</html>
