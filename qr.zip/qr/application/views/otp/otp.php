
<!DOCTYPE html>
<html lang="">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>enter otp</title>

        <!-- Bootstrap CSS -->
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Raleway:wght@700&display=swap" rel="stylesheet">
       
    </head>
    <style>
        .wrapper{
            background-color: #C4C6F8;
            position:fixed;
            height: 100%;
            width: 100%;
        }
        .main_div{
            position: relative;
            height: 100%;
            width: 100%;
        }
        .dot1{
            position: absolute;
    top: 79%;
    bottom: -2%;
    left: 0%;
    right: -2%;
    height: 31%;
    width: 100%;
    background-color: #4A4A92;
    border-radius: 12%;
    display: inline-block;
    box-shadow: 3px -3px 8px;
            
        }
        .dot2{
            position: absolute;
    top: -33%;
    bottom: -2%;
    left: -43%;
    right: 1%;
    height: 105%;
    width: 185%;
    background-color: #C6D0F9;
    border-radius: 50%;
    display: inline-block;
            
        }
        .dot3{
            position: absolute;
    top: -37%;
    bottom: -2%;
    left: -38%;
    right: 1%;
    height: 105%;
    width: 174%;
    background-color: #e8def6;
    border-radius: 50%;
    display: inline-block;
            
        }
        .clinic
{
    position:absolute;
    top:8% ;
    right:10%;
    bottom: 10%;
    left: 8%;
    font-size: 28px;
    
    font-family:fantasy;
    
     font-family: 'Raleway', sans-serif;

}
.color1
{
   color: #D5388B;
}
.color2
{
   color: #7F8BF3;
}
.form_pos{
    position: absolute;
    top: 25%;
    left: 10%;
}
form input{
    border: none;
    border-radius: 25px;
    height: 30px;
}
.mob{
    position: absolute;
    bottom: 10%;
    left: -1%;
    font-weight: bold;
    color: #4A52A2;
    font-size: 18px;
}
.mob_input{
    position: relative;
    left: -4%;
    width: 349px;
    height: 45px;
    text-align: center;
    border-radius:50px;
    border-color:#ffff;
}
.otp_class{
    border: none;
    position: absolute;
    background-color: #7F8BF3;
    border-radius: 25px;
    bottom: -107%;
    color: #fff;
    font-weight: bold;
    width: 100px;
    height: 35px;
    font-size: 18px;
    left: 31%;
}
.otp_class:hover{
    border: none;
    position: absolute;
    background-color:#fff ;
    border-radius: 25px;
    bottom: -107%;
    color: #7F8BF3;
    font-weight: bold;
    width: 100px;
    height: 35px;
    font-size: 18px;
    left: 31%;
}
.enter_otp{
    position: absolute;
    top: 140px;
    font-weight: bold;
    color: #4A52A2;
    font-size: 18px;
    left: -1%;
}
.fillotp_main{
    position: absolute;
    top: 220px;
    left:-1px ;

}
.fillotp1{
    width: 45px;
    padding-left: 0%;
    border-top-left-radius:25px ;
    border-bottom-left-radius:25px ;
    border-top-right-radius:0px ;
    border-bottom-right-radius:0px ;
    text-align: center;
    height: 45px;
    border-color:#ffff;

}
.fillotp2{
    width: 45px;
    padding-left: 0%;
    border-top-left-radius:0px ;
    border-bottom-left-radius:0px ;
    border-top-right-radius:0px ;
    border-bottom-right-radius:0px ;
    text-align: center;
    height: 45px;
    border-color:#ffff;
}
.fillotp3{
    width: 45px;
    padding-left: 0%;
    border-top-left-radius:0px ;
    border-bottom-left-radius:0px ;
    border-top-right-radius:0px ;
    border-bottom-right-radius:0px ;
    text-align: center;
    height: 45px;
    border-color:#ffff;
}
.fillotp4{
    width: 45px;
    padding-left: 0%;
    border-top-left-radius:0px ;
    border-bottom-left-radius:0px ;
    border-top-right-radius:25px ;
    border-bottom-right-radius:25px ;
    text-align: center;
    height: 45px;
    border-color:#ffff;
}
.resend{
    position: absolute;
    top: 270px;
    left: 103px;
}
.resend a{
    color: #4A52A2;
    font-weight: bold;
}
.ok{
    position: absolute;
    top: 474px;
    left: 95px;
    
}
.ok_button{
  border: none;
  background-color: #fff;
  border-radius: 30px;
  width: 150px;
  height: 51px;
  color: #4A52A2;
  font-weight: bold;
  font-size: 25px;
}
.ok_button:hover{
  border: none;
  background-color: #4A52A2;
  border-radius: 30px;
  width: 150px;
  height: 51px;
  color:#fff ;
  font-weight: bold;
  font-size: 25px;
}
    </style>
    <body>
        
        
        <div class="wrapper">

       <div class="main_div">
          <span class="dot1"></span>
          <!-- <span class="dot2"></span>
          <span class="dot3"></span> -->
          <div class="container">
          <span class="clinic"><span class="color1">Carewell</span><span class="color2"> Clinic</span> </span>
          <div class="form_pos">
              
                  <div class="row">
                      <div class="col-md-12">
                        <p class="mob">Mobile Number</p>
                      </div>
                  </div>
                  <div class="row">
                      <div class="col-md-12">
                          <input class="mob_input" type="number" id="ud_mob">
                      </div>
                  </div>
                  <div class="row">
                      <button class="otp_class" id="sendotp">Get OTP</button>
                  </div>
                  <div class="row">
                      <div class="col-md-12">
                          <p class="enter_otp">Enter OTP</p>
                      </div>
                  </div>
                  <div class="row fillotp_main">
                      <!-- <div class="col-md-3"> -->
                          <input class="fillotp1 col-md-3" type="number" min="0" max="9" id="eotp1">
                      <!-- </div> -->
                      <!-- <div class="col-md-3"> -->
                        <input class="fillotp2 col-md-3" type="number" min="0" max="9" id="eotp2">
                    <!-- </div> -->
                    <!-- <div class="col-md-3"> -->
                        <input class="fillotp3 col-md-3" type="number" min="0" max="9" id="eotp3">
                    <!-- </div> -->
                    <!-- <div class="col-md-3"> -->
                        <input class="fillotp4 col-md-3" type="number" min="0" max="9" id="eotp4">
                    <!-- </div> -->
                  </div>
                  <div class="row resend" id="resend_otp">
                      <a href="">Resend OTP</a>
                  </div>

                  <div class="row ok">
                    <button class="ok_button" id="ok" href="window.location=<?php echo base_url()?>/Tokenctrl/token">Register</button>
                </div>
                  
                  
              
            </div>
            </div>
          
       
       </div>
      
    
    </div>


        <!-- jQuery -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <!-- Bootstrap JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <script>
            $(".fillotp1").on('keyup',function(){
                // console.log()
                var fill1 = $(".fillotp1").val();
                var test = validateNumber(fill1);
                if(test === true)
                {
                    $(".fillotp2").focus();
                }
                else
                {
                    $(".fillotp1").val('');
                }
                
            });
            $(".fillotp2").on('keyup',function(e){
                var fill2 = $(".fillotp2").val();
                var test2 = validateNumber(fill2);
                if(test2 === true)
                  {
                      $(".fillotp3").focus();
                  }
                  else
                  {
                    $(".fillotp2").focus();
                  }



                if(e.keyCode == 8)
                {
                    $(".fillotp1").focus().val(''); 
                }
                else
                {
                    $(".fillotp3").focus();
                }
            });
            $(".fillotp3").on('keyup',function(e){
                var fill3 = $(".fillotp3").val();
                var test3 = validateNumber(fill3);
                if(test3 === true)
                  {
                      $(".fillotp4").focus();
                  }
                  else
                  {
                    $(".fillotp3").focus();
                  }
                  if(e.keyCode == 8)
                {
                    $(".fillotp2").focus().val(''); 
                }
                else
                {
                    $(".fillotp4").focus();
                }

            });
            $(".fillotp4").on('keyup',function(e){
                var fill4 = $(".fillotp4").val();
                var test4 = validateNumber(fill4);
                if(test4 === true)
                  {
                      $(".fillotp4").val();
                  }
                  else
                  {
                    $(".fillotp4").focus();
                  }
                  if(e.keyCode == 8)
                {
                    $(".fillotp3").focus().val(''); 
                }
                else
                {
                    $(".fillotp4").focus();
                }

            });
            function validateNumber(nume4) {
                // console.log(e);
                console.log(nume4);
                const pattern = /^[0-9]$/;
                return pattern.test(nume4 )
            }
        </script>
    <script>
           
             
             $("#sendotp").on('click',function() {

                
                if($("#ud_mob").val().length == 10)
                {
                   var ud_otp = Math.floor((Math.random() * 10000) + 1);
                   var ud_mob=$('#ud_mob').val();
                    
                    alert(ud_otp);
                   
                    // send it to mobile number

                    $.ajax({
                    url:"otp",
                    type:'POST',
                    data:{ud_mob:ud_mob, ud_otp:ud_otp},
                    success : function(data) {
                           alert("success");
                           },
                    error : function(data) {
                           alert("failed1");
                           }
                    });
                }
                else 
                  { alert("enter valid mobile number");}
                 
                  });
      //************************************************************** */
                  $("#resend_otp").on('click',function(){
                    var ud_otp = Math.floor((Math.random() * 10000) + 1);
                //    var ud_mob=$('#ud_mob').val();
                    
                    alert(ud_otp);
                    
                   
                    // send it to mobile number
                    $.ajax({
                        url:"resend",
                        type:'POST',
                        data:{ud_otp:ud_otp},
                        success : function(data) {
                           alert("success");
                           },
                        error : function(data) {
                           alert("failed1");
                           }
                    });
                  });


      //**************************************************************** */      
            
                  $("#ok").on('click',function(){
                
               


                var dig1=$("#eotp1").val();
                var dig2=$("#eotp2").val();
                var dig3=$("#eotp3").val();
                var dig4=$("#eotp4").val();


                var ud_eotp=(1000*dig1)+(100*dig2)+(10*dig3)+(1*dig4);

                 

                    $.ajax({
                    url:"e_otp",
                    type:'POST',
                    data:{ud_eotp:ud_eotp},
                    success : function(data) {
                        window.location.href = "<?php echo base_url()?>/Tokenctrl/token";
                           },
                    error : function(data) {
                           alert("failed2");
                           }
             });
            });
            



    </script>
    </body>
</html>
