
<!DOCTYPE html>
<html lang="">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>enter otp</title>

        <!-- Bootstrap CSS -->
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Raleway:wght@700&display=swap" rel="stylesheet">
       
    </head>
    <style>
          body{
            background-color: #C4C6F8;
            /* position:absolute;
            height: 100%;
            width: 100%; */
        }
     .clinic
        {   
            position: inherit;
            padding:10px 10px 10px 10px;
            margin:10px 10px 10px 10px;
           
            top:28px;
            font-size: 28px;
            font-weight: bold;
            font-family:fantasy;
            
            font-family: 'Raleway', sans-serif;

        }
        .color1
            {
            color: #D5388B;
            }
            .color2
            {
            color: #7F8BF3;
            }
            .info_div
                {
                    padding: 62px 78% 43px 118px;
    margin: 35px 63px 40px -24px;
    background-color: #4A4A92;
    box-shadow: 3px -3px 8px;
    width: 0px;
    height: 358px;
    border-top-right-radius: 50px;
    border-top-left-radius: 50px;
                }
                .fillotp1{
    width: 45px;
    padding-left: 0%;
    border-top-left-radius:25px ;
    border-bottom-left-radius:25px ;
    border-top-right-radius:0px ;
    border-bottom-right-radius:0px ;
    text-align: center;
    height: 45px;
    border-color:#ffff;

}
.fillotp2{
    width: 45px;
    padding-left: 0%;
    border-top-left-radius:0px ;
    border-bottom-left-radius:0px ;
    border-top-right-radius:0px ;
    border-bottom-right-radius:0px ;
    text-align: center;
    height: 45px;
    border-color:#ffff;
}
.fillotp3{
    width: 45px;
    padding-left: 0%;
    border-top-left-radius:0px ;
    border-bottom-left-radius:0px ;
    border-top-right-radius:0px ;
    border-bottom-right-radius:0px ;
    text-align: center;
    height: 45px;
    border-color:#ffff;
}
.fillotp4{
    width: 45px;
    padding-left: 0%;
    border-top-left-radius:0px ;
    border-bottom-left-radius:0px ;
    border-top-right-radius:25px ;
    border-bottom-right-radius:25px ;
    text-align: center;
    height: 45px;
    border-color:#ffff;
}
.ok_button{
  border: none;
  background-color: #fff;
  border-radius: 30px;
  width: 150px;
  height: 51px;
  color: #4A52A2;
  font-weight: bold;
  font-size: 25px;
}
.ok_button:hover{
  border: none;
  background-color: #4A52A2;
  border-radius: 30px;
  width: 150px;
  height: 51px;
  color:#fff ;
  font-weight: bold;
  font-size: 25px;
}
.mob{
   
    font-weight: bold;
    color: #4A52A2;
    font-size: 18px;
}
.mob_input{
   
    width: 320px;
    height: 45px;
    text-align: center;
    border-radius:50px;
    border-color:#ffff;
}
.otp_class{
    border: none;
    background-color: #7F8BF3;
    border-radius: 25px;
    color: #fff;
    font-weight: bold;
    width: 100px;
    height: 35px;
    font-size: 18px;
}
.otp_class:hover{
    border: none;
    background-color:#fff ;
    border-radius: 25px;
    color: #7F8BF3;
    font-weight: bold;
    width: 100px;
    height: 35px;
    font-size: 18px;
}
.mobile
{
    padding: 58px 8px 33px 1px;
    margin: 15px -2px 39px 3px;
}
.sendotp_
{
    padding: 5px 15px 20px 96px;
    margin: -57px 10px 10px 10px
}
.otp_
{
    padding: 77px 36px 1px 11px;
    margin: 11px 51px 11px 4px;
}
.fillotp_
{
    padding: 6px 24px 73px 12px;
    margin: -19px 72px 106px -5px;
}
.container p
{
    font-weight: bold;
    color: #4A52A2;
    font-size: 18px;
}
.resend
{
    padding: 19px 50px 30px 11px;
    margin: -188px 57px 74px 100px;
    color: #4A52A2;
    font-weight: bold;
}
    </style>
    <body>
        
        
        <div class="container">

          <div class="row">
                <div class="col-md-12">
                    <span class="clinic"><span class="color1">Carewell</span><span class="color2"> Clinic</span> </span>
                </div>
            </div>


            <div class="row mobile">
              <div class="col-md-12 mob_div">
                  <p class="mob_label">Mobile No</p>
                  <input class="mob_input" type="number" id="ud_mob">
              </div>
           </div>
         

            <div class="row sendotp_">
                <div class="col-md-12">
                     <button class="otp_class" id="sendotp">Get OTP</button>
                </div>
            </div>  


            <div class="row otp_">
              <div class="col-md-12">
                 <p class="enter_otp">Enter OTP</p>  
              </div>
            </div>

            <div class="row fillotp_">
              <div class="col-md-12">
                        <input class="fillotp1 col-md-3" type="number" min="0" max="9" id="eotp1">
                     
                        <input class="fillotp2 col-md-3" type="number" min="0" max="9" id="eotp2">
                  
                        <input class="fillotp3 col-md-3" type="number" min="0" max="9" id="eotp3">
                   
                        <input class="fillotp4 col-md-3" type="number" min="0" max="9" id="eotp4">
              </div>
            </div>

            <div class="row resend">
                <div class="col-md-12" id="resend_otp">
                <a href="">Resend OTP</a>
                </div>
            </div>








            <div class=" container-fluid info_div ">
      

      
        
      
      <div class="row">
        <div class="col-md-12 ">
        <button class="ok_button" disabled id="ok">
               Submit
           </button>
        </div>

      </div>
       
     </div>







          
        
              
                  <!-- <div class="row">
                      <div class="col-md-12">
                        <p class="mob">Mobile Number</p>
                      </div>
                  </div>
                  <div class="row">
                      <div class="col-md-12">
                          <input class="mob_input" type="number" id="ud_mob">
                      </div>
                  </div>
                  <div class="row">
                      <button class="otp_class" id="sendotp">Get OTP</button>
                  </div>
                  <div class="row">
                      <div class="col-md-12">
                          <p class="enter_otp">Enter OTP</p>
                      </div>
                  </div> -->
                  <!-- <div class="row fillotp_main">
                          <input class="fillotp1 col-md-3" type="number" min="0" max="9" id="eotp1">
                        <input class="fillotp2 col-md-3" type="number" min="0" max="9" id="eotp2">
                        <input class="fillotp3 col-md-3" type="number" min="0" max="9" id="eotp3">
                        <input class="fillotp4 col-md-3" type="number" min="0" max="9" id="eotp4">
                  </div> -->
                  <!-- <div class="row resend" id="resend_otp">
                      <a href="">Resend OTP</a>
                  </div> -->

                  <!-- <div class="row ok">
                    <button class="ok_button" id="ok" href="window.location=<?php echo base_url()?>/Tokenctrl/token">Register</button>
                </div> -->
                  
                  
              
            <!-- </div>
            </div>
          
       
       </div> -->
      
    
    


        <!-- jQuery -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <!-- Bootstrap JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <script>
            $(".fillotp1").on('keyup',function(){
                // console.log()
                var fill1 = $(".fillotp1").val();
                var test = validateNumber(fill1);
                if(test === true)
                {
                    $(".fillotp2").focus();
                }
                else
                {
                    $(".fillotp1").val('');
                }
                
            });
            $(".fillotp2").on('keyup',function(e){
                var fill2 = $(".fillotp2").val();
                var test2 = validateNumber(fill2);
                if(test2 === true)
                  {
                      $(".fillotp3").focus();
                  }
                  else
                  {
                    $(".fillotp2").focus();
                  }



                if(e.keyCode == 8)
                {
                    $(".fillotp1").focus().val(''); 
                }
                else
                {
                    $(".fillotp3").focus();
                }
            });
            $(".fillotp3").on('keyup',function(e){
                var fill3 = $(".fillotp3").val();
                var test3 = validateNumber(fill3);
                if(test3 === true)
                  {
                      $(".fillotp4").focus();
                  }
                  else
                  {
                    $(".fillotp3").focus();
                  }
                  if(e.keyCode == 8)
                {
                    $(".fillotp2").focus().val(''); 
                }
                else
                {
                    $(".fillotp4").focus();
                }

            });
            $(".fillotp4").on('keyup',function(e){
                var fill4 = $(".fillotp4").val();
                var test4 = validateNumber(fill4);
                if(test4 === true)
                  {
                      $(".fillotp4").val();
                  }
                  else
                  {
                    $(".fillotp4").focus();
                  }
                  if(e.keyCode == 8)
                {
                    $(".fillotp3").focus().val(''); 
                }
                else
                {
                    $(".fillotp4").focus();
                }

            });
            function validateNumber(nume4) {
                // console.log(e);
                console.log(nume4);
                const pattern = /^[0-9]$/;
                return pattern.test(nume4 )
            }
        </script>
    <script>
           
             
             $("#sendotp").on('click',function() {

                
                if($("#ud_mob").val().length == 10)
                {
                   var ud_otp = Math.floor((Math.random() * 10000) + 1);
                   var ud_mob=$('#ud_mob').val();
                    
                    alert(ud_otp);
                   
                    // send it to mobile number

                    $.ajax({
                    url:"otp",
                    type:'POST',
                    data:{ud_mob:ud_mob, ud_otp:ud_otp},
                    success : function(data) {
                           alert("success");
                           $('#ud_mob').hide();
                           $('#sendotp').hide();
                           $('.mob_label').hide();
                           $('#ok').removeAttr("disabled");

                           },
                    error : function(data) {
                           alert("failed");
                           }
                    });
                }
                else 
                  { alert("enter valid mobile number");}
                 
                  });
      //************************************************************** */
                  $("#resend_otp").on('click',function(){
                    var ud_otp = Math.floor((Math.random() * 10000) + 1);
                //    var ud_mob=$('#ud_mob').val();
                    
                    alert(ud_otp);
                    
                   
                    // send it to mobile number
                    $.ajax({
                        url:"resend",
                        type:'POST',
                        data:{ud_otp:ud_otp},
                        success : function(data) {
                           alert("success");
                           },
                        error : function(data) {
                           alert("failed2");
                           }
                    });
                  });


      //**************************************************************** */      
            
                  $("#ok").on('click',function(){
                
               


                var dig1=$("#eotp1").val();
                var dig2=$("#eotp2").val();
                var dig3=$("#eotp3").val();
                var dig4=$("#eotp4").val();


                var ud_eotp=(1000*dig1)+(100*dig2)+(10*dig3)+(1*dig4);

                 

                    $.ajax({
                    url:"e_otp",
                    type:'POST',
                    data:{ud_eotp:ud_eotp},
                    success : function(data) {
                        window.location.href = "<?php echo base_url()?>/Tokenctrl/token";
                           },
                    error : function(data) {
                           alert("failed2");
                           }
             });
            });
            



    </script>
    </body>
</html>
