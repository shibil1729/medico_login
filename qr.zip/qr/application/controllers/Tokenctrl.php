 <?php 
    defined('BASEPATH') OR exit('No direct script access allowed');

     class Tokenctrl extends CI_Controller
        {
          //global vars
          var  $newToken ;           



          public function __construct()
          {
            parent::__construct();
            //load model
            $this->load->model('Tokenmodel');
            //load session library
            $this->load->library('session');
          }

//*********************************************************************************************************************************** */

public function break()
{
  $tdid=$this->input->post('tdid');
  $missed=$this->input->post('missed');

  date_default_timezone_set('Asia/Kolkata');
  $time=date('H:i:s');
 $update_data=array( 'td_cs' => 1,'td_end_time' => $time );
 $this->Tokenmodel->update1($update_data, $tdid);
 echo 1;



}
//*********************************************************************************************************************************** */
public function continue()
{
  $tdid=$this->input->post('tdid');
  $missed=$this->input->post('missed');
  echo 1;
}
//*********************************************************************************************************************************** */


            public function mob() 
            {
              $this->load->view('otp/otp_1');
            }
             
//*********************************************************************************************************************************** */            
            public function e_otp()
            {
              $data = array(
                'eotp' => $this->input->post('ud_eotp'),  
              );

              $fetch=$this->Tokenmodel->fetch();
              // print_r($fetch->ud_otp);
              if($fetch->ud_otp == $this->input->post('ud_eotp'))
              
               {
                echo "otp verified";
                $data=array('ud_status' => 'verified');
                $this->Tokenmodel->insert3($data);
                
               }

               else
               {
                echo "incorrect otp";
              
               }
           }
//*********************************************************************************************************************************** */            
            public function otp()
             {

              
              $data = array(
                'ud_mob' => $this->input->post('ud_mob'),
                'ud_otp'=>$this->input->post('ud_otp'),
                
                
              );
                 $this->session->set_userdata('mobile',$this->input->post('ud_mob'));
              
             $akw=$this->Tokenmodel->insert2($data);
             echo 'sssss';
             die;
                 

             }
//*********************************************************************************************************************************** */
public function reset()
{
  $this->Tokenmodel->reset();
  echo 1;
}
//*********************************************************************************************************************************** */
public function resend()
{
  $data=array(
    'ud_otp'=>$this->input->post('ud_otp'),
     
  );
  $this->Tokenmodel->update_otp($data);
  echo 1;
}
//*********************************************************************************************************************************** */
public function request()
{
  $tk=$this->input->post('tk');
  $data=array('td_request'=>1);
  $this->Tokenmodel->request($tk,$data);
  return 1;
}
//*********************************************************************************************************************************** */             


          public function next()
          {
             $tdid=$this->input->post('tdid');
             $missed=$this->input->post('missed');
             $request=$this->input->post('request');

             date_default_timezone_set('Asia/Kolkata');
              $time=date('H:i:s');


            $start=$this->Tokenmodel->fetch_time($tdid);
            $start_time = $start->td_start_time;

            if($request){
              $missed = $request;
            }
            if($missed == null || $missed == '' || $missed == 0 )
            {
              date_default_timezone_set('Asia/Kolkata');
              $time=date('H:i:s');
             $update_data=array( 'td_cs' => 2,'td_end_time' => $time );
             $this->Tokenmodel->update1($update_data, $tdid);

             $cs = $this->Tokenmodel->current_cs();
             $total = $this->Tokenmodel->getmax_2();
             $skip=$this->Tokenmodel->skip_count();
             
            //  var_dump($skip->skip_count); die;
             if($cs->td_id <> null){
                $update_data=array('td_cs' => 1);
                 $this->Tokenmodel->update1($update_data,$cs->td_id);
                $user_details = $this->Tokenmodel->select_User($cs->td_id);
                //  var_dump($user_details);
                date_default_timezone_set('Asia/Kolkata');
                $time=date('H:i:s');
                $data_1['td_start_time']=$time;
                $data_2=$cs->td_id;
                
                $this->Tokenmodel->inserttime($data_1,$data_2);
                $requested_token=$this->Tokenmodel->requested_tokens();
                $skipped_token=$this->Tokenmodel->skipped_tokens();
                $data['skipped_token']= $skipped_token;
                $data['requested_token']=$requested_token;
                 $data['user_details']=$user_details;
                 $data['current_token']=$cs->td_tk;
                 $data['tdid']=$cs->td_id;
                 $data['total']=$total;
                //  $data['skip_count']=$skip->skip_count;
                //  $this->load->view('reception screen/qr',$data);
                 $jsonp = json_encode(
                  array(
                    'status' => 1,
                    'view' => ($this->load->view('doc_screen/doc_2', $data, TRUE))
                  )
                );
             }
             else{
              $jsonp = json_encode(
                array(
                  'status' => -1,
                  'message' => 'No New User'
                )
              );                    
             }
                echo $jsonp;
            

            //  die;
            
          }
          else
          {
            $update_data=array( 'td_cs' => 1 , 'td_ss'=>0);
            $this->Tokenmodel->skip_update($update_data,$missed);
            $update_data=array( 'td_cs' => 2 );
            $this->Tokenmodel->update1($update_data, $tdid);

            $cs = $this->Tokenmodel->current_cs_1($missed);
            $total = $this->Tokenmodel->getmax_2();
            $skip=$this->Tokenmodel->skip_count();
            // var_dump($cs);

            
            if($cs->td_pk <> null){
              $update_data=array('td_cs' => 1);
               $this->Tokenmodel->update1($update_data,$cs->td_pk);
              $user_details = $this->Tokenmodel->select_User($cs->td_pk);
              //  var_dump($user_details);
              date_default_timezone_set('Asia/Kolkata');
              $time=date('H:i:s');
              $data_1['td_start_time']=$time;
              $data_2=$cs->td_pk;
              $this->Tokenmodel->inserttime($data_1,$data_2);
              $requested_token=$this->Tokenmodel->requested_tokens();
              
              $data['requested_token']=$requested_token;
              $skipped_token=$this->Tokenmodel->skipped_tokens();
              $data['skipped_token']= $skipped_token;
               $data['user_details']=$user_details;
               $data['current_token']=$cs->td_tk;
               $data['tdid']=$cs->td_pk;
               $data['total']=$total;
              //  $data['skip_count']=$skip->skip_count;
              //  $this->load->view('reception screen/qr',$data);
               $jsonp = json_encode(
                array(
                  'status' => 1,
                  'view' => ($this->load->view('doc_screen/doc_2', $data, TRUE))
                )
              );
           }
           else{
            $jsonp = json_encode(
              array(
                'status' => -1,
                'message' => 'No New User'
              )
            );                    
           }
              echo $jsonp;

          }
        }

//*********************************************************************************************************************************** */

          public function doctor_submit_data()
          {
            $tdid=$this->input->post('tdid');
            $ud_name=$this->input->post('ud_name');
             $ud_age=$this->input->post('ud_age');
             $comment=$this->input->post('comment');
             $ud_gender=$this->input->post('ud_gender'); 
             $ud_mob=$this->input->post('ud_mob'); 
             $cs_=$this->Tokenmodel->current_cs();
             $ud_status="doctor verified";
             $today=$this->input->post('ud_time');

             $ud_token=$cs_->td_tk;
             $darray=array('ud_status' => $ud_status,'ud_time' => $today,'ud_name' => $ud_name,'ud_age' =>$ud_age,'ud_gender' => $ud_gender,'ud_token'=>$ud_token-1,'td_id_fk'=>$tdid,'ud_mob' => $ud_mob,'comment' => $comment);
             $this->Tokenmodel->doctor_insert($darray,$tdid);

            $history = $this->Tokenmodel->history($ud_mob);



          }

//*********************************************************************************************************************************** */
public function end()
{
  $this->session->sess_destroy();
  echo "";
}
//*********************************************************************************************************************************** */ 
public function skip()
{
  $tdid=$this->input->post('tdid');
  
  
  
             $update_data=array( 'td_cs' => 2  ,'td_ss' => 1);
             $this->Tokenmodel->update1($update_data, $tdid);

             $cs = $this->Tokenmodel->current_cs();
             $total = $this->Tokenmodel->getmax_2();
            //  var_dump($cs); die;
             if($cs->td_id <> null){
                $update_data=array('td_cs' => 1);
                 $this->Tokenmodel->update1($update_data,$cs->td_id);
                $user_details = $this->Tokenmodel->select_User($cs->td_id);
                //  var_dump($user_details);

                date_default_timezone_set('Asia/Kolkata');
                $time=date('H:i:s');
                $data_1['td_start_time']=$time;
                $data_2=$cs->td_id;
                $this->Tokenmodel->inserttime($data_1,$data_2);


                $skipped_token=$this->Tokenmodel->skipped_tokens();
                $data['skipped_token']= $skipped_token;
                 $data['user_details']=$user_details;
                 $data['current_token']=$cs->td_tk;
                 $data['tdid']=$cs->td_id;
                 $data['total']=$total;
                //  $this->load->view('reception screen/qr',$data);
                 $jsonp = json_encode(
                  array(
                    'status' => 1,
                    'view' => ($this->load->view('doc_screen/doc_2', $data, TRUE))
                  )
                );
             }
             else{
              $jsonp = json_encode(
                array(
                  'status' => -1,
                  'message' => 'No New User'
                )
              );                    
             }
                echo $jsonp;
            

            //  die;
}
//*********************************************************************************************************************************** */                 

          public function udata()
          {
            // $data = array(
            //   'td_id_fk' => $this->input->post('td_id_fk'),
              
            // );
            $this->load->view('filldetails/filldetails_1');
          //  echo $data;
          }
//*********************************************************************************************************************************** */          


          public function doctor()
          {
            $cs = $this->Tokenmodel->current_cs();
            // var_dump($cs);
            // die;
           
             $update_data=array('td_cs' => 1);
             $this->Tokenmodel->update1($update_data,$cs->td_id);
             $user_details= $this->Tokenmodel->select_User($cs->td_id);
            //  var_dump($user_details);
            $skipped_token=$this->Tokenmodel->skipped_tokens();

            date_default_timezone_set('Asia/Kolkata');
            $time=date('H:i:s');
            $data_1['td_start_time']=$time;
            $data_2=$cs->td_id;
            $test=$this->Tokenmodel->inserttime($data_1,$data_2);
           
             $data['skipped_token']= $skipped_token;
             $data['user_details']=$user_details;
             $data['tdid']=$cs->td_id;
             $data['current_token']=$cs->td_tk;
              return $this->load->view('doc_screen/doc_2',$data);
          }
//*********************************************************************************************************************************** */  
          public function start()
          {
            $this->load->view('doc_screen/startscreen');
          }
//*********************************************************************************************************************************** */          


          public function insertdata()
          {

            $today=date("Y-m-d");

            
            $data = array(
              'ud_name' => $this->input->post('ud_name'),
              'ud_age'=>$this->input->post('ud_age'),
              'ud_gender'=>$this->input->post('ud_gender'),
              'ud_time' =>$this->input->post('ud_time'),
               'ud_token'=>$this->session->userdata('token_generated'),
               'td_id_fk'=>$this->session->userdata('last_id'),
            );

            
	        	$info=$this->Tokenmodel->saveData($data);
            $this->session->set_userdata('current_user', $info);            
            
            
            
           
	        	
          }

//*********************************************************************************************************************************** */  
public function tester()
{
  // $token= $this->Tokenmodel->getmax();
  // $newToken   = $token+1;
  // $val        =  array('td_tk' => $newToken , 'td_cs' => 0);
  // $last_id = $this->Tokenmodel->insert1($val);
  // $data['last_id']=$last_id;
  // $data['test']=172913;
  // $td_visited_date=date('y-m-d');

  // $data['td_visited_date']=$td_visited_date;
  // var_dump($data);
  // $history = $this->Tokenmodel->history($ud_mob);
  // var_dump($);
  // date_default_timezone_set('Asia/Kolkata');
  // $time=date('H:i:s');
  // var_dump($time);
  $tdid=21;
  $start=$this->Tokenmodel->fetch_time($tdid);
  date_default_timezone_set('Asia/Kolkata');
  $time=date('H:i:s');

  $time_ = strtotime($time);

  // $start_time = $start->td_start_time;
  // $start_time_ = strtotime($start_time);
  // $duration=$time - $start_time;
  // $ans = $duration.'minutes';
 



                $time_avg = 5;
              

                $cs=$this->Tokenmodel->current_token_display();

                $r=$cs->td_tk;
                $diff=10-$r;
                $min_est= $time_avg * $diff ; 
                
                 date_default_timezone_set('Asia/Kolkata');
                 $time=date('H:i:s');
                    
                   $time_est = date('H:i:s',strtotime('+"'.$min_est.'"'));
                     var_dump($time_est);
}
//*********************************************************************************************************************************** */  

          
          public function token()
          { 
            
            $today=date("Y-m-d");
            //****************************************** */
            
               $cs = $this->Tokenmodel->current_token_display();
               if(isset($cs))
                    { 
                      $data['current_token']=$cs->td_tk;
                    
                    }
                  
          //****************************************** */
           
            if(!$this->session->userdata('token_generated'))  
            {   
                $today = date("Y-m-d");
                $token= $this->Tokenmodel->getmax();
                if($token == '' || $token == null || $token == 0){$token = 1;}
                else{$token += 1;}

               

                $cs=$this->Tokenmodel->current_token_display();
                $last_week=date('Y-m-d', strtotime($today. ' - 7 days'));
                $last_day=date('Y-m-d', strtotime($today. ' - 1 days'));
                
                
                // if(isset($last_week))
                // {

                // }
                // elseif(isset($last_day))
                // {

                // }
                // else
                // {
                   
                // }



                // $time_avg = 5;
                // $diff=$token-$cs->td_tk;
                // $min_est= $time_avg * $diff ; 
                // date_default_timezone_set('Asia/Kolkata');
                // $time=date('H:i:s');
                   
                //   $time_est  = date('H:i:s',strtotime('+"'.$min_est.'"'));

                          






               
                
                $val=array('td_tk' => $token , 'td_cs' => 0 ,'td_visited_date'=>$today );
                $last_id=$this->Tokenmodel->insert1($val);
                $this->session->set_userdata('last_id',$last_id);
                $data['token']=$val;
                // $data['est']=$time_est;

             
               $this->session->set_userdata('token_generated', $val['td_tk']);
              //  $this->session->set_userdata('est_time', $time_est);
              
            }
            else
            {
             $data['token'] = $this->session->userdata('token_generated');
             $data['est'] = $this->session->userdata('est_time');

            
            }  
            $this->load->view('tokenscreen/Tokenscreen_1',$data);



           
         

           
           }

//*********************************************************************************************************************************** */  
public function qr()
{
  $this->load->view('reception screen/qr');
} 
//*********************************************************************************************************************************** */
public function qrscreen()
{
  $cs = $this->Tokenmodel->current_token_display();
 
 if(isset($cs))
 { 
   $data['current_token']=$cs->td_tk;
  echo $data['current_token'];
}
 else{echo 0;}
}
//*********************************************************************************************************************************** */
public function login()
{
  $this->load->view('doc_screen/login_1');
}
//*********************************************************************************************************************************** */
public function login_check()
{
  $uname=$this->input->post('uname');
  $password=$this->input->post('password');
  $status=$this->Tokenmodel->login_val($uname,$password);
  if($status->count  >0)
  {
    return 1;
  }
  


}
//*********************************************************************************************************************************** */





            
          }

       
          

        


?>