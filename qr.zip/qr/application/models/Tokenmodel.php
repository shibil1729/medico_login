<?php

defined('BASEPATH') OR exit('No direct script access allowed');
class Tokenmodel extends CI_Model 
    {

        //*********************************************************************************************************************************** */
        public function getmax()
        {
            $today=date("Y-m-d");
            $this->db->from('tokendetails');
            $this->db->where('td_visited_date',$today);
            $this->db->select_max('td_tk');
           
            

            $query = $this->db->get();
            $result =  $query->result_array();

            foreach($result as $value)
            {
                return $value['td_tk'];
            }
        }
        //*********************************************************************************************************************************** */
            public function request($tk,$data)
            {
                $today=date("Y-m-d");
                $this->db->where('td_visited_date',$today);
                $this->db->where('td_tk',$tk);
                $this->db->update('tokendetails',$data);
                return true;

            }

     //*********************************************************************************************************************************** */
     public function requested_tokens()
     {
        $today=date("Y-m-d");
        $query  =  "select td_tk,td_pk from tokendetails where td_request =1 and td_visited_date ='".$today."' ";
        $result = $this->db->query($query);
        return $result = $result->result_array();
     }
      //*********************************************************************************************************************************** */



        public function skipped_tokens()
        {
            $today=date("Y-m-d");
            $query  =  "select td_tk,td_pk from tokendetails where td_ss =1 and td_visited_date ='".$today."' ";
            $result = $this->db->query($query);
            return $result = $result->result_array();

        }
       
        //*********************************************************************************************************************************** */
        public function getmax_2()
        {
            $today=date("Y-m-d");
            $this->db->from('tokendetails');
            $this->db->where('td_visited_date',$today);

            $this->db->select_max('td_tk');
           
            

            $query = $this->db->get();
            $result =  $query->result_array();

            foreach($result as $value)
            {
                return $value['td_tk'];
            }
        }
        //*********************************************************************************************************************************** */
        public function history($ud_mob)
        {
            $query="select ud_name,ud_age,ud_gender,comment from userdetails where ud_mob = '".$ud_mob."'   ";
            $result = $this->db->query($query);
            return $result = $result->row();
        }

        //*********************************************************************************************************************************** */


        public function current_cs()
        {
            $today=date("Y-m-d");
            $query  =  "select min(td_pk) td_id,td_tk from tokendetails where td_cs =0 and td_visited_date ='".$today."' ";
            // return $query;
            $result = $this->db->query($query);
            return $result = $result->row();
            // return $this->db->last_query();
        }


        //*********************************************************************************************************************************** */
        public function current_cs_1($missed)
        {
            $query="select td_pk,td_tk from tokendetails where td_pk='".$missed."'     ";
            $result = $this->db->query($query);
            return $result = $result->row();
        }
        //*********************************************************************************************************************************** */
        public function skip_update($update_data,$missed)
        {
            $this->db->where('td_pk',$missed);
            $this->db->update('tokendetails',$update_data);
            return true;
        }
        //*********************************************************************************************************************************** */

        public function current_tk()
        {
            $query  =  "select td_tk from tokendetails";
            $result = $this->db->query($query);
            return $result = $result->result_array();
        } 
        //*********************************************************************************************************************************** */

        public function fetch()
        {

            $query  =  "select ud_otp from userdetails where ud_id_pk ='".$this->session->userdata('current_user')."' ";
            $result_1 = $this->db->query($query);
            return $result_1 = $result_1->row();
           
        }

        //*********************************************************************************************************************************** */

        public function saveData($data) 
        {
            log_message('debug','test');
           $result = $this->db->insert('userdetails',$data);

           return $this->db->insert_id();
            
        }

        //*********************************************************************************************************************************** */
        public function resend()
        {
            $this->db->where('td_tk', $this->session->userdata('token_generated'));
            $this->db->update('tokendetails', $data);
            return true;
        }
        //*********************************************************************************************************************************** */
        public function inserttime($data_1,$data_2)
        {
            $this->db->where('td_pk',$data_2 );
            $this->db->update('tokendetails', $data_1);
            return true;
        }
        //*********************************************************************************************************************************** */
        public function min($d)
        {
            // $query="select min(td_pk) td_id,td_tk from tokendetails where td_cs =0 and td_visited_date ='".$d."' ";
        }
        //*********************************************************************************************************************************** */
        public function man($d)
        {
            
        }
        //*********************************************************************************************************************************** */
        public function total_no($d)
        {
            
        }
        //*********************************************************************************************************************************** */
        public function fetch_time($tdid)
        {
            $query="select td_start_time from tokendetails where td_pk ='".$tdid."' ";
            $result_1 = $this->db->query($query);
            return $result_1 = $result_1->row();
        }
         //*********************************************************************************************************************************** */


        
    
        public function insert1($data)
        {
            $this->db->insert('tokendetails',$data);
            $last_id=$this->db->insert_id();
            log_message('debug','inserted'.$this->db->last_query());
            return $last_id;
        }

        //*********************************************************************************************************************************** */

        public function insert2($data) 
        {
            $this->db->where('ud_id_pk', $this->session->userdata('current_user'));
            $this->db->update('userdetails', $data);

            return $this->db->last_query();
        }


        //*********************************************************************************************************************************** */

        public function insert3($data) 
        {
            $this->db->where('ud_id_pk', $this->session->userdata('current_user'));
            $this->db->update('userdetails', $data);

            return true;
        }

        //*********************************************************************************************************************************** */
        public function update1($update_data,$data)
        {
            $this->db->where('td_pk',$data);
            $this->db->update('tokendetails',$update_data);
            return true;
        }
        //*********************************************************************************************************************************** */

        public function doctor_insert($darray,$tdid)
        {
            $today=date("Y-m-d");
            $query  =  "select ud_id_pk from userdetails where td_id_fk='".$tdid."'     ";
            $result = $this->db->query($query);
            $result = $result->row();

            if(isset($result))
            {
                $this->db->where('td_id_fk',$tdid);
                $this->db->update('userdetails',$darray);
            }
            else
            {
                $this->db->insert('userdetails',$darray);
            }
        }

        //*********************************************************************************************************************************** */
        public function update2_0($update_data_0,$data_0)
        {
            $this->db->where('td_tk',$data_0);
            $this->db->update('tokendetails',$update_data_0);
            return true;
        }
         //*********************************************************************************************************************************** */
         public function update2_1($update_data_1,$data_1)
        {
            $this->db->where('td_tk',$data_1);
            $this->db->update('tokendetails',$update_data_1);
            return true;
        }
         //*********************************************************************************************************************************** */
        public function select_User($data)
        {
            $query  =  "select * from userdetails where td_id_fk ='".$data."' ";
            $result_1 = $this->db->query($query);
            return $result_1 = $result_1->row(); 
        }


         //*********************************************************************************************************************************** */

         public function current_token_display()
         {
            $today=date("Y-m-d");
            $query = "select td_tk from tokendetails where td_cs =1 and td_visited_date ='".$today."' ";
            $result = $this->db->query($query);
            return $result = $result->row(); 
         }
          //*********************************************************************************************************************************** */
         public function update_otp($data)
         {
            $this->db->where('ud_mob',$this->session->userdata('mobile'));
            $this->db->update('userdetails',$data);
            return true;
         }
         //*********************************************************************************************************************************** */
         public function reset()
         {
            $today=date("Y-m-d");
            $data=array('td_cs'=>0,'td_ss'=>0,'td_request'=>0);
            $this->db->where('td_visited_date',$today);
            $this->db->update('tokendetails',$data);
            return true;
         }
         //*********************************************************************************************************************************** */
           public function skip_count()
           {
            $today=date("Y-m-d");
            $query  =  "select count(td_pk) as skip_count from tokendetails where td_ss =1 and td_visited_date ='".$today."' ";
            $result = $this->db->query($query);
            return $result = $result->row();
            
           }

           public function login_val($uname,$password)
           {
            $query = "select count(*) as count from login where username = '".$uname."'and password ='".$password."' ";
            $result = $this->db->query($query);
            return $result = $result->row(); 
           }
    }





?>    